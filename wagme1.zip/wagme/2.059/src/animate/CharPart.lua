local TAG_CHAR_ACTION = 100
local CharPart = class("CharPart", function()
  return cc.Sprite:create()
end)
function CharPart:ctor(icon, weapon, action, direction, basicPoint, interval, syncLoad, loadType)
  self.icon = icon or 0
  self.weapon = weapon or 0
  self.action = action or Const.SA_STAND
  self.direction = direction or 5
  self.basicPoint = basicPoint or cc.p(0, 0)
  self.interval = interval or Const.INTERVAL
  self.contentSize = cc.size(0, 0)
  self.firstFrame = Const.CHAR_FRAME_START_NO
  self.lastFrame = Const.CHAR_FRAME_START_NO + 99
  self.loopTimes = 0
  self.reverse = false
  self.syncLoad = syncLoad
  self.loadType = loadType
  self.frameIntervalRate = 1
  self.blendMode = nil
  self.firstNew = true
  local function onNodeEvent(event)
    if Const.NODE_CLEANUP == event then
      self:clearUpdateEvent()
    end
  end
  self:registerScriptHandler(onNodeEvent)
  self:setCascadeOpacityEnabled(true)
end
function CharPart:setBlendMode(blendMode)
  self.blendMode = blendMode
end
function CharPart:clearUpdateEvent()
  if self.updateEvent then
    EventDispatcher:removeEventListener(self.updateEvent.key, self.updateEvent.func)
    self.updateEvent = nil
  end
end
function CharPart:setFirstFrame(first)
  if first ~= self.firstFrame then
    self.firstFrame = first
    self.dirty = true
  end
end
function CharPart:setLastFrame(last)
  if last ~= self.lastFrame then
    self.lastFrame = last
    self.dirty = true
  end
end
function CharPart:setLoopTimes(times)
  if self.loopTimes ~= times then
    self.loopTimes = times
    self.dirty = true
  end
end
function CharPart:setReverse(reverse)
  if self.reverse ~= reverse then
    self.reverse = reverse
    self.dirty = true
  end
end
function CharPart:setCallback(cb)
  self.callback = cb
  if cb and self.loopTimes == 0 then
    self.loopTimes = 1
  end
  self.dirty = true
end
function CharPart:setIcon(icon, weapon)
  weapon = weapon or 0
  if self.icon == icon and self.weapon == weapon then
    return
  end
  self.icon = icon
  self.weapon = weapon
  self.dirty = true
end
function CharPart:setAction(act)
  if self.action == act then
    return
  end
  self.action = act
  self.dirty = true
end
function CharPart:setDirection(dir)
  if self.direction == dir then
    return
  end
  self.direction = dir
  self.dirty = true
end
function CharPart:setPetSwingInfo(info)
  self.swingInfo = info
end
function CharPart:setBasicPoint(point)
  if point == nil then
    return
  end
  self.basicPoint = point
  self.dirty = true
end
function CharPart:setInterval(interval)
  if interval == nil or self.interval == interval then
    return
  end
  self.interval = interval
  self.dirty = true
end
function CharPart:pausePlay()
  self:stopAllActions()
end
function CharPart:continuePlay()
  self.dirty = true
  self:updateNow()
  Log:D("char part children num" .. self:getChildrenCount())
end
function CharPart:recordCallIndex(index)
  if self.owner and self.owner.recordCallLog then
    self.owner:recordCallLog(index)
  end
end
function CharPart:updateNow()
  if self.dirty ~= true then
    return
  end
  self.dirty = false
  self:recordCallIndex(301)
  if self.icon == 0 or self.action == nil or self.action <= Const.SA_NONE or self.action >= Const.SA_NUM or self.direction == nil or 0 > self.direction or self.direction > 8 or self.basicPoint == nil or self.interval == nil then
    if self.callback then
      self.calback()
    end
    local parent = self:getParent()
    if parent then
      parent:setPartAniLoaded(self:getType())
    end
    return
  end
  self:recordCallIndex(302)
  local function updateNowEx(animation)
    if "function" ~= type(self.clearUpdateEvent) then
      return
    end
    self:recordCallIndex(310)
    self:clearUpdateEvent()
    self.firstNew = nil
    if not animation then
      if self.callback then
        self.callback(self)
      end
      self:recordCallIndex(311)
      return
    end
    self:recordCallIndex(312)
    local parent = self:getParent()
    if parent then
      parent:setPartAniLoaded(self:getType())
    end
    self:recordCallIndex(313)
    if self.delayAction then
      self:stopAction(self.delayAction)
      self.delayAction = nil
    end
    self:recordCallIndex(314)
  end
  self:recordCallIndex(303)
  if self.firstNew and self.syncLoad then
    self:recordCallIndex(304)
    self:clearUpdateEvent()
    self:recordCallIndex(305)
    local key = AnimationMgr:getKey(self.icon, self.weapon, self.action, self.direction, self.firstFrame, self.lastFrame)
    self.updateEvent = {key = key, func = updateNowEx}
    EventDispatcher:addEventListener(key, self.updateEvent.func)
    self:recordCallIndex(306)
    AnimationMgr:syncGetCharAnimation(self.icon, self.weapon, self.action, self.direction, self.firstFrame, self.lastFrame, self.loadType)
    self:recordCallIndex(307)
  else
    self:recordCallIndex(308)
    local animation = AnimationMgr:getCharAnimation(self.icon, self.weapon, self.action, self.direction, self.firstFrame, self.lastFrame)
    self:recordCallIndex(309)
    updateNowEx(animation)
  end
end
function CharPart:getTotalDelayUnits()
  local animation = AnimationMgr:getCharAnimation(self.icon, self.weapon, self.action, self.direction, self.firstFrame, self.lastFrame)
  if animation then
    return animation:getTotalDelayUnits()
  else
    return 0
  end
end
function CharPart:setFrameIntervalRate(rate)
  if rate <= 0 then
    return
  end
  self.frameIntervalRate = rate
end
function CharPart:playAnimation()
  local animation = AnimationMgr:getCharAnimation(self.icon, self.weapon, self.action, self.direction, self.firstFrame, self.lastFrame)
  if not animation then
    return
  end
  local frame = animation:getSpriteFrame(0)
  if nil == frame then
    return
  end
  if "function" ~= type(self.updateAnchorPoint) then
    return
  end
  self:updateAnchorPoint(frame)
  local interval = FightMgr:divideSpeedFactorIfInCombat(self.interval, self.action)
  interval = interval * self.frameIntervalRate
  animation:setDelayPerUnit(interval)
  local action
  local animate = cc.Animate:create(animation)
  if self.reverse then
    animate = animate:reverse()
  end
  if self.loopTimes == 0 then
    if self.swingInfo then
      if type(self.swingInfo.x) == "table" then
        local xn = self.swingInfo.x
        local yn = self.swingInfo.y
        local n = #xn
        local moveByActions = {}
        for i = 1, n - 1 do
          table.insert(moveByActions, cc.MoveBy:create(interval, cc.p(xn[i + 1] - xn[i], yn[i] - yn[i + 1])))
        end
        table.insert(moveByActions, cc.MoveBy:create(interval, cc.p(xn[1] - xn[n], yn[n] - yn[1])))
        action = cc.Sequence:create(moveByActions)
      else
        local tEnd = animation:getDuration()
        local tbegin = tEnd * self.swingInfo.percent / 100
        tEnd = tEnd - tbegin
        action = cc.Sequence:create(cc.MoveBy:create(tbegin, cc.p(self.swingInfo.x, self.swingInfo.y)), cc.MoveBy:create(tEnd, cc.p(-self.swingInfo.x, -self.swingInfo.y)))
      end
      action = cc.RepeatForever:create(cc.Spawn:create(animate, action))
    else
      action = cc.RepeatForever:create(animate)
    end
  else
    if self.loopTimes > 1 then
      animate = cc.Repeat:create(animate, self.loopTimes)
    end
    if self.callback then
      action = cc.Sequence:create(animate, cc.CallFunc:create(function()
        if self.callback then
          self.callback(self)
        end
      end))
    else
      action = animate
    end
  end
  self:stopActionByTag(TAG_CHAR_ACTION)
  action:setTag(TAG_CHAR_ACTION)
  self:runAction(action)
  action:step(0)
  if self.blendMode == "add" then
    self:setBlendFunc(gl.ONE, gl.ONE)
  end
end
function CharPart:clear()
end
function CharPart:updateAnchorPoint(frame)
  if frame == nil then
    return
  end
  local flip = self:isFlippedX()
  local size = frame:getOriginalSize()
  local basicX = self.basicPoint.x
  if flip then
    basicX = size.width - basicX
  end
  local basicY = size.height - self.basicPoint.y
  self:setAnchorPoint(basicX / size.width, basicY / size.height)
  self.contentSize = size
  local x = basicX
  local y = basicY
  self.anchorPoint = cc.p(basicX / size.width, basicY / size.height)
  self.offsetPos = cc.p(x, y)
  local rcTmp = frame:getRect()
  local offset = frame:getOffset()
  self.contentRect = cc.rect(offset.x + (size.width - rcTmp.width) / 2, offset.y + (size.height - rcTmp.height) / 2, rcTmp.width, rcTmp.height)
  if flip then
    self.contentRect.x = size.width - self.contentRect.x - self.contentRect.width
  end
end
function CharPart:setType(type)
  self.type = type
end
function CharPart:getType()
  return self.type
end
return CharPart
