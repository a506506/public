local TAG_MAGIC_ACTION = 100
local CartoonInfo = require("magic/Cartoon.lua") or {}
local CartoonNewInfo = require("magic_n/Cartoon.lua") or {}
local MapCartoonInfo = require("maps/magic/Cartoon") or {}
local function getNormalMagicInfo(icon)
  local info
  if ResMgr:useMagicNRes(icon) then
    info = CartoonNewInfo[string.format("%05d", icon)]
  end
  return info or CartoonInfo[string.format("%05d", icon)]
end
local function getInterval(icon, magicType)
  local info = {}
  if MAGIC_TYPE.NORMAL == magicType then
    info = getNormalMagicInfo(icon)
  elseif MAGIC_TYPE.MAP == magicType then
    info = MapCartoonInfo[string.format("%05d", icon)]
  end
  if nil == info then
    return 0.1
  end
  return (tonumber(info.rate) or 100) / 1000
end
local function getBasicPoint(icon, magicType)
  local info = {}
  if MAGIC_TYPE.NORMAL == magicType then
    info = getNormalMagicInfo(icon)
  elseif MAGIC_TYPE.MAP == magicType then
    info = MapCartoonInfo[string.format("%05d", icon)]
  end
  if info == nil then
    return cc.p(0, 0)
  end
  local x = info.centre_x or 0
  local y = info.centre_y or 0
  local scale = info.scale or 100
  return cc.p(x * scale / 100, y * scale / 100)
end
local Magic = class("Magic", function()
  return cc.Sprite:create()
end)
function Magic:ctor(icon, callbackOrRemoveSelf, magicType, extraPara)
  self.icon = icon or 0
  if nil == magicType then
    self.magicType = MAGIC_TYPE.NORMAL
  else
    self.magicType = magicType
  end
  local crType = type(callbackOrRemoveSelf)
  if crType == "function" then
    self.callback = callbackOrRemoveSelf
  elseif crType == "boolean" then
    self.removeSelf = callbackOrRemoveSelf
  end
  self:setScaleByIcon(icon)
  self.extraPara = extraPara
  self:processSomeExtraPara(extraPara)
  self:updateNow()
end
function Magic:processSomeExtraPara(extraPara)
  if not extraPara then
    return
  end
  if extraPara.rotation then
    self:setRotation(extraPara.rotation)
  end
  if extraPara.rotationX then
    self:setRotationSkewX(extraPara.rotationX)
  end
  if extraPara.rotationY then
    self:setRotationSkewY(extraPara.rotationY)
  end
  if extraPara.scaleX then
    self:setScaleX(extraPara.scaleX)
  end
  if extraPara.scaleY then
    self:setScaleY(extraPara.scaleY)
  end
  self:setAlpha(extraPara.alpha)
end
function Magic:setAlpha(alpha)
  if alpha then
    self:setCascadeOpacityEnabled(true)
    if alpha > 255 then
      alpha = 255
    elseif alpha < 0 then
      alpha = 0
    end
    self:setOpacity(alpha)
  end
end
function Magic:setScaleByIcon(icon)
  local scale
  local iconName = string.format("%05d", icon)
  if self.magicType == MAGIC_TYPE.MAP then
    scale = MapCartoonInfo[iconName] and MapCartoonInfo[iconName].scale
  else
    local info = getNormalMagicInfo(icon)
    scale = info and info.scale
  end
  if scale then
    self.scale = scale
    local scale = 100 / self.scale
    self:setScaleX(scale)
    self:setScaleY(scale)
  else
    self.scale = nil
    self:setScaleX(1)
    self:setScaleY(1)
  end
end
function Magic:setIcon(icon)
  if self.icon == icon then
    return
  end
  self:setScaleByIcon(icon)
  self.icon = icon
  self:updateNow()
end
function Magic:updateNow()
  if self.icon == nil or self.icon == 0 then
    if self.callback then
      self.callback(self)
    end
    return
  end
  local function updateNowEx(animation)
    if not animation then
      if self.callback then
        self.callback(self)
      end
      local tip = string.format(CHS[2100109], tostring(self.icon))
      gf:ShowSmallTips(tip)
      Log:F(tip)
      return
    end
    local frame = animation:getSpriteFrame(0)
    if nil == frame then
      return
    end
    if "function" ~= type(self.updateAnchorPoint) then
      return
    end
    self:updateAnchorPoint(frame)
    local interval = getInterval(self.icon, self.magicType)
    if self.extraPara and self.extraPara.frameInterval then
      interval = self.extraPara.frameInterval / 1000
    end
    interval = FightMgr:divideSpeedFactorIfInCombat(interval)
    animation:setDelayPerUnit(interval)
    local animate = cc.Animate:create(animation)
    local action
    if self.callback then
      action = cc.Sequence:create(animate, cc.CallFunc:create(self.callback, {
        icon = self.icon
      }))
    elseif self.removeSelf then
      action = cc.Sequence:create(animate, cc.RemoveSelf:create())
    else
      if self.extraPara and self.extraPara.loopInterval then
        if self.extraPara.notShowDuringDelay then
          action = cc.Sequence:create(cc.CallFunc:create(function()
            self:setVisible(false)
          end), cc.DelayTime:create(self.extraPara.loopInterval / 1000), cc.CallFunc:create(function()
            self:setVisible(true)
          end), animate)
        else
          action = cc.Sequence:create(animate, cc.DelayTime:create(self.extraPara.loopInterval / 1000))
        end
      else
        action = animate
      end
      action = cc.RepeatForever:create(action)
    end
    self.action = action
    self:stopActionByTag(TAG_MAGIC_ACTION)
    action:setTag(TAG_MAGIC_ACTION)
    self:runAction(action)
    if self.extraPara and self.extraPara.blendMode and not self.extraPara.skipTime then
      self.extraPara.skipTime = 0
    end
    if self.extraPara and self.extraPara.skipTime then
      action:step(0)
      action:step(self.extraPara.skipTime / 1000)
    end
    if self.extraPara and self.extraPara.blendMode and self.extraPara.blendMode == "add" then
      self:setBlendFunc(gl.ONE, gl.ONE)
    end
    if self.extraPara and self.extraPara.alpha then
      self:setAlpha(self.extraPara.alpha)
    end
  end
  if MAGIC_TYPE.MAP == self.magicType then
    AnimationMgr:syncGetMagicAnimation(self.icon, self.magicType, updateNowEx)
  else
    local animation = AnimationMgr:getMagicAnimation(self.icon, self.magicType, self.scale)
    updateNowEx(animation)
  end
end
function Magic:updateAnchorPoint(frame)
  if frame == nil then
    return
  end
  local basicPoint = getBasicPoint(self.icon, self.magicType)
  local size = frame:getOriginalSize()
  self:setAnchorPoint(basicPoint.x / size.width, 1 - basicPoint.y / size.height)
  if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_WINDOWS then
    local pt = cc.LayerColor:create(cc.c4b(255, 0, 0, 255))
    pt:setContentSize(2, 2)
    pt:setPosition(basicPoint.x, size.height - basicPoint.y)
    self:addChild(pt)
  end
end
function Magic:pausePlay()
  self:pause()
end
function Magic:continuePlay()
  self:resume()
end
return Magic
