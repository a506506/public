local CharAction = class("CharAction", function()
  return cc.Sprite:create()
end)
local CharPart = require("animate.CharPart")
local ActionReplaceCfg = require(ResMgr:getCfgPath("ActionReplaceCfg.lua"))
local CharDirection = {
  [50216] = {
    stand2 = {
      1,
      3,
      5,
      7
    }
  }
}
local TAG_CHAR = 100
local TAG_WEAPON = 101
local TAG_RIDE_BOTTOM = 103
local TAG_RIDE_TOP = 104
local TAG_CHAR_START = 1050000
local TAG_CHAR_MAX = 1089999
local TAG_CHAR_SHADOW = 109
local TAG_CHAR_PART_BEGIN = 1001
local TAG_CHAR_PART_END = 1010
local TAG_CHAR_PART_MAX = 1020
local ZORDER_CHAR_SHADOW = -15
local ZORDER_RIDE_BOTTOM = -1000
local ZORDER_CHAR = 0
local ZORDER_CHAR_START = 100
local ZORDER_CHAR_MAX = 400
local ZORDER_CHAR_PART_START = 1
local ZORDER_CHAR_PART_MAX = 10
local ZORDER_WEAPON = 11
local ZORDER_RIDE_TOP = 1000
local STATUS_TO_LOAD = 1
local STATUS_LOADED = 2
local GATHER_COUNT = 4
function CharAction:ctor(syncLoad, cb)
  self.icon = 0
  self.weaponIcon = 0
  self.direction = 5
  self.orgIcon = 0
  self.action = Const.SA_STAND
  self.rideIcon = 0
  self:setContentSize(cc.size(0, 0))
  self:ignoreAnchorPointForPosition(false)
  self:setScale(Const.MAP_SCALE)
  self.firstFrame = Const.CHAR_FRAME_START_NO
  self.lastFrame = Const.CHAR_FRAME_START_NO + 99
  self.loopTimes = 0
  self.reverse = false
  self.syncLoad = syncLoad
  self.rideOffsetX = 0
  self.rideOffsetY = 0
  self.petRideInfo = {}
  self.charOpacity = 255
  self.isPausePlay = false
  self.dirtyUpdate = nil
  self.curIsTestDist = DistMgr:curIsTestDist()
  for i = 1, GATHER_COUNT do
    self[string.format("icon%d", i)] = 0
  end
  self.partAniStatus = {}
  self:setVisible(false)
  self.loadComplateCallBack = nil
  self:setLoadComplateCallBack(cb)
  self:setCascadeOpacityEnabled(true)
  if self.curIsTestDist then
    self.sendDebugLog = true
    do
      local NODE_ENTER = Const.NODE_ENTER
      local NODE_EXIT = Const.NODE_EXIT
      local NODE_CLEAN = Const.NODE_CLEANUP
      local function onNodeEvent(event)
        if not self.sendDebugLog then
          return
        end
        if NODE_ENTER == event then
          DebugMgr:recordCharActionLog(tostring(self), "enter", debug.traceback())
        elseif NODE_EXIT == event then
          DebugMgr:recordCharActionLog(tostring(self), "exit", debug.traceback())
        elseif NODE_CLEANUP == event then
          DebugMgr:recordCharActionLog(tostring(self), "cleanup", debug.traceback())
        end
      end
      DebugMgr:recordCharActionLog(tostring(self), "ctor", debug.traceback())
      self:registerScriptHandler(onNodeEvent)
    end
  end
end
function CharAction:initFrame()
end
function CharAction:setLoadComplateCallBack(cb)
  self.loadComplateCallBack = cb
end
function CharAction:recordCallIndex(index)
  if self.owner and self.owner.recordCallLog then
    self.owner:recordCallLog(index)
  end
end
function CharAction:set(icon, weaponIcon, act, dir, rideIcon, gatherIcons, shadowIcon, partIndex, partColorIndex, gatherPartIndexs, gatherPartColorIndexs)
  self:setIcon(icon, true, rideIcon)
  self:setBodyPartIndex(partIndex, true)
  self:setBodyColorIndex(partColorIndex, true)
  self:setWeapon(weaponIcon, true)
  self:setAction(act, true)
  self:setDirection(dir, true)
  self:setRideIcon(rideIcon, true)
  self:setGatherIcons(gatherIcons, true, gatherPartIndexs, gatherPartColorIndexs)
  self:setShadowIcon(shadowIcon, true)
  self:updateNow()
end
function CharAction:setExtraScale(scale)
  if self.extraScale ~= scale then
    self.extraScale = scale
    if self.extraScale and self.extraScale > 0 then
      self:setScale(Const.MAP_SCALE * (self.extraScale / 100))
    end
  end
end
function CharAction:setFrames(first, last, noUpdateNow)
  self.firstFrame = first
  self.lastFrame = last
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:setFirstFrame(first)
      v:setLastFrame(last)
    end
  end
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
end
function CharAction:setReverse(reverse)
  if self.reverse == reverse then
    return
  end
  self.reverse = reverse
  local children = self:getChildren()
  for i = 1, #children do
    if children[i] and children[i].setReverse and "function" == type(children[i].setReverse) then
      children[i]:setReverse(reverse)
    end
  end
end
function CharAction:setIcon(icon, noUpdateNow, rideIcon)
  if icon == nil or self.icon == icon then
    return
  end
  self:recordCallIndex(201)
  self.icon = icon
  self.cartoonInfo = nil
  self:readCartoonInfo(rideIcon)
  self:setWeapon(0, true)
  self:setBodyPartIndex("", true)
  self:setBodyColorIndex("", true)
  self:recordCallIndex(202)
  self:initFrame()
  local act
  if not rideIcon or rideIcon == 0 then
    act = self:getRealAction(TAG_CHAR)
  else
    act = self:getRealAction(TAG_RIDE_BOTTOM)
  end
  self:recordCallIndex(203)
  local char = self:getChildByTag(TAG_CHAR)
  if nil == char then
    self:recordCallIndex(204)
    char = CharPart.new(self.icon, 0, act, self:getRealDirection(), self:getBasicPoint(TAG_CHAR), self:getInterval(), self.syncLoad, self:getLoadType())
    char.owner = self.owner
    self:recordCallIndex(205)
    self:addChild(char, ZORDER_CHAR, TAG_CHAR)
    self:recordCallIndex(206)
    self.char = char
    char:setType("icon")
  end
  self:recordCallIndex(207)
  char:setAction(act)
  self:recordCallIndex(208)
  char:setFirstFrame(self.firstFrame)
  char:setLastFrame(self.lastFrame)
  char:setLoopTimes(self.loopTimes)
  char:setReverse(self.reverse)
  char:setInterval(self:getInterval())
  char:setBasicPoint(self:getBasicPoint(TAG_CHAR))
  char:setIcon(self.icon, 0)
  char:setScale(1 / self:getCharScale())
  char:setPetSwingInfo(nil)
  self:recordCallIndex(209)
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
    self:recordCallIndex(210)
  end
  self:recordCallIndex(211)
end
function CharAction:setAnimationSpeed(speed)
  if speed <= 0 then
    return
  end
  local rate = 1 / speed
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:setFrameIntervalRate(rate)
    end
  end
  self:playAnimation()
end
function CharAction:setGatherIcons(gatherIcons, noUpdateNow, partIndexs, partColorIndexs)
  local gatherCount = 0
  if gatherIcons then
    if "table" == type(gatherIcons) then
      for i = 1, math.min(#gatherIcons, GATHER_COUNT) do
        local char = self:setGatherIcon(i, gatherIcons[i], noUpdateNow)
        if char then
          if partIndexs and partIndexs[i] then
            self:setBodyPartIndex(partIndexs[i], true, char:getTag(), char:getLocalZOrder(), char)
          else
            self:setBodyPartIndex("", true, char:getTag(), char:getLocalZOrder(), char)
          end
          if partColorIndexs and partColorIndexs[i] then
            self:setBodyColorIndex(partColorIndexs[i], true, nil, char:getTag(), char)
          else
            self:setBodyColorIndex("", true, nil, char:getTag(), char)
          end
        end
      end
      gatherCount = #gatherIcons
    else
      self:setGatherIcon(1, gatherIcons, noUpdateNow)
      gatherCount = 1
    end
  end
  for i = gatherCount + 1, GATHER_COUNT do
    self:setGatherIcon(i, 0, noUpdateNow)
  end
end
function CharAction:setGatherIcon(index, icon, noUpdateNow)
  local iKey = string.format("icon%d", index)
  if index > GATHER_COUNT or icon == nil or self[iKey] == icon then
    return self[string.format("char%02d", index)]
  end
  self[iKey] = icon
  if self.cartoonInfo == nil then
    return
  end
  local tagValue = TAG_CHAR_START + (index - 1) * 10000
  local char = self:getChildByTag(tagValue)
  if 0 == icon then
    self[string.format("char%02d", index)] = nil
    if char then
      self:setBodyPartIndex("", noUpdateNow, char:getTag(), char:getLocalZOrder(), char)
      self:setPartToBeRemoved(tagValue)
      self:setPartAniLoadedDelay(char:getType())
      return
    end
    self.dirtyUpdate = true
    if not noUpdateNow then
      self:updateNow()
    end
    return
  end
  local act
  act = self:getRealAction(TAG_CHAR)
  if nil == char then
    char = CharPart.new(icon, 0, act, self:getRealDirection(), self:getBasicPoint(TAG_CHAR), self:getInterval(), self.syncLoad, self:getLoadType())
    self:addChild(char, ZORDER_CHAR_START - (index + 1) * 100, tagValue)
    char:setType(string.format("char%02d", index))
  elseif self.toBeRemoveParts and self.toBeRemoveParts[tagValue] then
    self.toBeRemoveParts[tagValue] = nil
  end
  self[string.format("char%02d", index)] = char
  char:setFirstFrame(self.firstFrame)
  char:setLastFrame(self.lastFrame)
  char:setLoopTimes(self.loopTimes)
  char:setReverse(self.reverse)
  char:setInterval(self:getInterval())
  char:setBasicPoint(self:getBasicPoint(TAG_CHAR_START + (index - 1) * 10000))
  char:setIcon(self[iKey], 0)
  char:setScale(1 / self:getCharScale())
  char:setPetSwingInfo(nil)
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
  return char
end
function CharAction:setShadowIcon(icon, noUpdateNow)
  if not icon or self.shadowIcon == icon then
    return
  end
  self.shadowIcon = icon
  if self.cartoonInfo == nil then
    return
  end
  local tagValue = TAG_CHAR_SHADOW
  local char = self:getChildByTag(tagValue)
  if 0 == icon then
    self.shadowIcon = nil
    if char then
      self:setPartToBeRemoved(tagValue)
      self:setPartAniLoadedDelay(char:getType())
      self.shadow = nil
      return
    end
    self.dirtyUpdate = true
    if not noUpdateNow then
      self:updateNow()
    end
    return
  end
  local act
  act = self:getRealAction(TAG_CHAR)
  if nil == char then
    char = CharPart.new(icon, 0, act, self:getRealDirection(), self:getBasicPoint(TAG_CHAR_SHADOW), self:getInterval(), self.syncLoad, self:getLoadType())
    self:addChild(char, ZORDER_CHAR_SHADOW, tagValue)
    char:setType("shadow")
  elseif self.toBeRemoveParts and self.toBeRemoveParts[tagValue] then
    self.toBeRemoveParts[tagValue] = nil
  end
  self.shadow = char
  char:setFirstFrame(self.firstFrame)
  char:setLastFrame(self.lastFrame)
  char:setLoopTimes(self.loopTimes)
  char:setReverse(self.reverse)
  char:setInterval(self:getInterval())
  char:setBasicPoint(self:getBasicPoint(TAG_CHAR_SHADOW))
  char:setIcon(self.shadowIcon, 0)
  char:setScale(self:getShadowScale())
  char:setPetSwingInfo(nil)
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
end
function CharAction:setBodyPartIndex(index, noUpdateNow, tagBase, zBase, aChar)
  local charIcon, partIndex
  if aChar then
    charIcon = aChar.icon
    partIndex = aChar.partIndex
  else
    charIcon = self.icon
    partIndex = self.partIndex
  end
  if not charIcon or partIndex == index or string.isNilOrEmpty(index) and string.isNilOrEmpty(partIndex) then
    return
  end
  if aChar then
    aChar.partIndex = index
  else
    self.partIndex = index
  end
  self:setBodyColorIndex("", true, nil, tagBase, aChar)
  if not self.cartoonInfo then
    return
  end
  local count = index and math.floor(#index / 2) or 0
  tagBase = tagBase or 0
  zBase = zBase or 0
  for i = 1, count do
    local j = tonumber(string.sub(index, i * 2 - 1, i * 2))
    if j > 0 then
      local icon = self:getCharPartIcon(tonumber(string.format("%02d%03d", i, j)), charIcon)
      if icon then
        self:setBodyPart(string.format("charpart%d", tagBase + TAG_CHAR_PART_BEGIN + i - 1), icon, tagBase + TAG_CHAR_PART_BEGIN + i - 1, zBase + ZORDER_CHAR_PART_START + i - 1, aChar or self.char)
      end
    else
      self:setBodyPart(string.format("charpart%d", tagBase + TAG_CHAR_PART_BEGIN + i - 1), 0, tagBase + TAG_CHAR_PART_BEGIN + i - 1, 0, aChar or self.char)
    end
  end
  local fromTag = tagBase + TAG_CHAR_PART_BEGIN + count
  local children = self:getChildren()
  if children then
    for i, v in ipairs(children) do
      if v then
        local tag = v:getTag()
        if fromTag <= tag and tag <= tagBase + TAG_CHAR_PART_MAX then
          self:setBodyPart(string.format("charpart%d", tag), 0, tag, 0, aChar or self.char)
        end
      end
    end
  end
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
end
function CharAction:checkCharPartExist(icon, weapon, action)
  local actStr = gf:getActionStr(action or Const.SA_STAND)
  local plist = ResMgr:getCharPath(icon, weapon, actStr) .. ".plist"
  return cc.FileUtils:getInstance():isFileExist(plist)
end
function CharAction:getCharPartIcon(icon, realIcon)
  local realIcon = realIcon or self.icon
  local action = Const.SA_STAND
  if self:checkCharPartExist(realIcon, icon, action) then
    return icon
  else
    return 0
  end
end
function CharAction:setBodyPart(type, icon, tag, zorder, aChar)
  local part = self:getChildByTag(tag)
  if not part and 0 == icon then
    return
  end
  if part and part.icon == aChar.icon and part.weapon == icon then
    if self.toBeRemoveParts and self.toBeRemoveParts[tag] then
      self.toBeRemoveParts[tag] = nil
    end
    self:setPartAniLoadedDelay(part:getType())
    return
  end
  if part and 0 == icon then
    self:setPartToBeRemoved(tag)
    self:setPartAniLoadedDelay(part:getType())
    return
  end
  local realIcon = aChar.icon
  if not part then
    part = CharPart.new(realIcon, icon, self.action, self:getRealDirection(), self:getBasicPoint(tag), self:getInterval(), self.syncLoad, self:getLoadType())
    part.owner = self.owner
    self:addChild(part, zorder, tag)
    part:setType(type)
  elseif self.toBeRemoveParts and self.toBeRemoveParts[tag] then
    self.toBeRemoveParts[tag] = nil
  end
  part:setAction(aChar and aChar.action or Const.SA_STAND)
  part:setFirstFrame(self.firstFrame)
  part:setLastFrame(self.lastFrame)
  part:setLoopTimes(self.loopTimes)
  part:setReverse(self.reverse)
  part:setInterval(self:getInterval())
  part:setBasicPoint(self:getBasicPoint(tag))
  part:setIcon(realIcon, icon)
  part:setScale(self:getWeaponScale(icon))
  if aChar then
    if not aChar.parts then
      aChar.parts = {}
    end
    aChar.parts[tag] = part
  end
end
function CharAction:setBodyColorIndex(index, noUpdateNow, forceSet, tagBase, aChar)
  local partColorIndex
  if aChar then
    partColorIndex = aChar.partColorIndex
  else
    partColorIndex = self.partColorIndex
  end
  if not forceSet and (index == partColorIndex or string.isNilOrEmpty(index) and string.isNilOrEmpty(partColorIndex)) then
    return
  end
  index = index or ""
  if aChar then
    aChar.partColorIndex = index
  else
    self.partColorIndex = index
  end
  tagBase = tagBase or 0
  local function _setBodyColorIndex()
    local tag, part, colorIndex
    local children = self:getChildren()
    for i = 1, #children do
      part = children[i]
      tag = part:getTag()
      if part and (0 == tagBase and tag == TAG_CHAR or tag == tagBase or tag >= tagBase + TAG_CHAR_PART_BEGIN and tag <= tagBase + TAG_CHAR_PART_MAX) then
        local j
        tag = tag - tagBase
        if tag >= TAG_CHAR_PART_BEGIN and tag <= TAG_CHAR_PART_MAX then
          j = tag - TAG_CHAR_PART_BEGIN + 2
        elseif tag == TAG_CHAR or tagBase == tag then
          j = 1
        end
        if j then
          local colorIndex = tonumber(string.sub(index, j * 2 - 1, j * 2))
          if colorIndex and colorIndex > 0 then
            local path = ResMgr:getCharPartColorPath(part.icon, part.weapon)
            if not cc.FileUtils:getInstance():isFileExist(path) then
              path = ResMgr:getCharPartColorPath(part.icon, part.weapon, ".luac")
            end
            local colorCfg = cc.FileUtils:getInstance():isFileExist(path) and require(path)
            if colorCfg and colorCfg[colorIndex] then
              local shader = ShaderMgr:getSimpleColorChangeShader(tostring(colorCfg[colorIndex]))
              shader:setUniformVec3("delta", colorCfg[colorIndex].delta)
              shader:setUniformVec2("range", colorCfg[colorIndex].range)
              shader:setUniformVec2("range1", colorCfg[colorIndex].range1 or cc.p(1, 0))
              if colorCfg[colorIndex].rate then
                shader:setUniformMat4("rate", colorCfg[colorIndex].rate)
              end
              part:setGLProgramState(shader)
            else
              part:setGLProgramState(ShaderMgr:getRawShader())
            end
          else
            part:setGLProgramState(ShaderMgr:getRawShader())
          end
        end
      end
    end
    if self.refreshColorIndex then
      if aChar then
        self.refreshColorIndex[tostring(aChar)] = nil
      else
        self.refreshColorIndex[tostring(self.char)] = nil
      end
    end
  end
  if self:isAllPartLoaded() and not noUpdateNow then
    _setBodyColorIndex()
  else
    if not self.refreshColorIndex then
      self.refreshColorIndex = {}
    end
    if aChar then
      self.refreshColorIndex[tostring(aChar)] = _setBodyColorIndex
    else
      self.refreshColorIndex[tostring(self.char)] = _setBodyColorIndex
    end
    if noUpdateNow then
      self.dirtyUpdate = true
    end
  end
end
function CharAction:setWeapon(icon, noUpdateNow)
  if not icon or self.weaponIcon == icon then
    return
  end
  self:recordCallIndex(212)
  self.weaponIcon = icon
  if self.cartoonInfo == nil then
    return
  end
  local weapon = self:getChildByTag(TAG_WEAPON)
  if 0 == icon and weapon then
    self:setPartToBeRemoved(TAG_WEAPON)
    self:setPartAniLoadedDelay(weapon:getType())
    self.weapon = nil
    self:recordCallIndex(213)
    return
  end
  local realIcon = self.icon
  self:recordCallIndex(214)
  if nil == weapon then
    self:recordCallIndex(215)
    weapon = CharPart.new(realIcon, self.weaponIcon, self.action, self:getRealDirection(), self:getBasicPoint(TAG_WEAPON), self:getInterval(), self.syncLoad, self:getLoadType())
    weapon.owner = self.owner
    self:recordCallIndex(214)
    self:addChild(weapon, ZORDER_WEAPON, TAG_WEAPON)
    weapon:setType("weapon")
  elseif self.toBeRemoveParts and self.toBeRemoveParts[TAG_WEAPON] then
    self.toBeRemoveParts[TAG_WEAPON] = nil
  end
  self.weapon = weapon
  self:recordCallIndex(216)
  weapon:setFirstFrame(self.firstFrame)
  weapon:setLastFrame(self.lastFrame)
  weapon:setLoopTimes(self.loopTimes)
  weapon:setReverse(self.reverse)
  weapon:setInterval(self:getInterval())
  weapon:setBasicPoint(self:getBasicPoint(TAG_WEAPON))
  weapon:setIcon(realIcon, self.weaponIcon)
  weapon:setScale(1 / self:getWeaponScale(self.weaponIcon))
  local cfg = CharMgr:getCharCfg(realIcon)
  if cfg and cfg.weaponBlendMode then
    weapon:setBlendMode(cfg.weaponBlendMode[icon])
  end
  self:recordCallIndex(217)
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
    self:recordCallIndex(218)
  end
  self:recordCallIndex(219)
end
function CharAction:showClickRects()
  local cfg = CharMgr:getCharCfg(self.icon)
  if self.icon and cfg and self.char.contentRect then
    local allclickRect = cfg.someClickRects
    if allclickRect then
      for _, rect in pairs(allclickRect) do
        local colorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 153))
        colorLayer:setContentSize(rect.width, rect.height)
        colorLayer:setPosition(cc.p(rect.x, rect.y))
        self:addChild(colorLayer)
      end
    end
    local rect = cfg.clickRect
    if rect then
      local colorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 153))
      colorLayer:setContentSize(rect.width, rect.height)
      colorLayer:setPosition(cc.p(rect.x, rect.y))
      self:addChild(colorLayer)
    end
    gf:showTipAndMisMsg("  X = " .. self.char.contentRect.x .. "  Y = " .. self.char.contentRect.y .. "  WIDTH = " .. self.char.contentRect.width .. "  HEIGHT = " .. self.char.contentRect.height)
  end
end
function CharAction:containsTouchPos(touch)
  local localPos = self:convertTouchToNodeSpace(touch)
  local scale = self:getCharScale()
  local isContain = false
  local cfg = CharMgr:getCharCfg(self.icon)
  if self.icon and cfg and self.char.contentRect then
    local clickRect = cfg.clickRect
    if clickRect then
      self.char.contentRect.x = clickRect.x
      self.char.contentRect.y = clickRect.y
      self.char.contentRect.width = clickRect.width
      self.char.contentRect.height = clickRect.height
    end
  end
  if self.char.contentRect then
    local rec = cc.rect(self.char.contentRect.x * scale, self.char.contentRect.y * scale, self.char.contentRect.width * scale, self.char.contentRect.height * scale)
    local x, y = self:getRideOffset()
    rec.x = rec.x + x
    rec.y = rec.y + y
    isContain = cc.rectContainsPoint(rec, localPos)
  end
  if not isContain and self.icon and cfg and self.char.contentRect then
    local clickRects = cfg.someClickRects
    if clickRects then
      for _, cRect in pairs(clickRects) do
        local rec = cc.rect(cRect.x * scale, cRect.y * scale, cRect.width * scale, cRect.height * scale)
        isContain = cc.rectContainsPoint(rec, localPos)
        if isContain then
          break
        end
      end
    end
  end
  local cfg = CharMgr:getCharCfg(self.rideIcon)
  if self.rideIcon and cfg and self.rideBottom.contentRect then
    local clickRect = cfg.clickRect
    if clickRect then
      self.rideBottom.contentRect.x = clickRect.x
      self.rideBottom.contentRect.y = clickRect.y
      self.rideBottom.contentRect.width = clickRect.width
      self.rideBottom.contentRect.height = clickRect.height
    end
  end
  if not isContain and self.rideBottom and self.rideBottom.contentRect then
    local rec = cc.rect(self.rideBottom.contentRect.x * scale, self.rideBottom.contentRect.y * scale, self.rideBottom.contentRect.width * scale, self.rideBottom.contentRect.height * scale)
    isContain = cc.rectContainsPoint(rec, localPos)
  end
  local cfg = CharMgr:getCharCfg(self.rideIcon)
  if not isContain and not cfg and self.rideTop and self.rideTop.contentRect then
    local rec = cc.rect(self.rideTop.contentRect.x * scale, self.rideTop.contentRect.y * scale, self.rideTop.contentRect.width * scale, self.rideTop.contentRect.height * scale)
    isContain = cc.rectContainsPoint(rec, localPos)
  end
  if not isContain and self.char and self.char.parts then
    local rect
    for k, v in pairs(self.char.parts) do
      if k ~= TAG_CHAR_PART_BEGIN and k ~= TAG_CHAR_PART_END and v and v.contentRect then
        rect = cc.rect(v.contentRect.x * scale, v.contentRect.y * scale, v.contentRect.width * scale, v.contentRect.height * scale)
        isContain = cc.rectContainsPoint(rect, localPos)
        if isContain then
          break
        end
      end
    end
  end
  if not isContain then
    local charpart, rect, tagBase
    for i = 1, GATHER_COUNT do
      tagBase = TAG_CHAR_START + (i - 1) * 10000
      charpart = self:getChildByTag(tagBase)
      if charpart and charpart.contentRect then
        rect = cc.rect(charpart.contentRect.x * scale, charpart.contentRect.y * scale, charpart.contentRect.width * scale, charpart.contentRect.height * scale)
        isContain = cc.rectContainsPoint(rect, localPos)
        if isContain then
          break
        end
        if not isContain and charpart.parts then
          local rect
          for k, v in pairs(charpart.parts) do
            if k ~= tagBase + TAG_CHAR_PART_BEGIN and k ~= tagBase + TAG_CHAR_PART_END and v and v.contentRect then
              rect = cc.rect(v.contentRect.x * scale, v.contentRect.y * scale, v.contentRect.width * scale, v.contentRect.height * scale)
              isContain = cc.rectContainsPoint(rect, localPos)
              if isContain then
                break
              end
            end
          end
        end
        if isContain then
          break
        end
      end
      if isContain then
        break
      end
    end
  end
  return isContain
end
function CharAction:setRideIcon(icon, noUpdateNow)
  if not icon or self.rideIcon == icon then
    return
  end
  self.rideIcon = icon
  self:readCartoonInfo()
  if self.cartoonInfo == nil then
    return
  end
  if self.rideIcon > 0 then
    self.petRideInfo = PetMgr:getPetRideInfo(self.rideIcon)
  else
    self.petRideInfo = {}
    if self.char then
      self.char:setPetSwingInfo(nil)
    end
  end
  self:clearBasicPointRange()
  self:setRideBottom(icon, noUpdateNow)
  if self.petRideInfo.have_top_layer then
    self:setRideTop(icon, noUpdateNow)
  else
    self:setRideTop(0, noUpdateNow)
  end
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
end
function CharAction:setRideBottom(icon, noUpdateNow)
  local ride = self:getChildByTag(TAG_RIDE_BOTTOM)
  if 0 == icon then
    if ride then
      self:setPartToBeRemoved(TAG_RIDE_BOTTOM)
      self:setPartAniLoadedDelay(ride:getType())
      self.rideBottom = nil
    end
    self.dirtyUpdate = true
    if not noUpdateNow then
      self:updateNow()
    end
    return
  end
  local act = self:getRealAction(TAG_RIDE_BOTTOM)
  if nil == ride then
    ride = CharPart.new(icon, 0, act, self:getRealDirection(), self:getBasicPoint(TAG_RIDE_BOTTOM), self:getInterval(), self.syncLoad, self:getLoadType())
    self:addChild(ride, ZORDER_RIDE_BOTTOM, TAG_RIDE_BOTTOM)
    ride:setType("ride_bottom")
  elseif self.toBeRemoveParts and self.toBeRemoveParts[TAG_RIDE_BOTTOM] then
    self.toBeRemoveParts[TAG_RIDE_BOTTOM] = nil
  end
  self.rideBottom = ride
  ride:setAction(act)
  if self.char then
    self.char:setAction(act)
  end
  ride:setFirstFrame(self.firstFrame)
  ride:setLastFrame(self.lastFrame)
  ride:setLoopTimes(self.loopTimes)
  ride:setReverse(self.reverse)
  ride:setInterval(self:getInterval())
  ride:setBasicPoint(self:getBasicPoint(TAG_RIDE_BOTTOM))
  ride:setIcon(icon, 0)
  ride:setScale(1 / self:getCharScale())
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
end
function CharAction:setRideTop(icon, noUpdateNow)
  local ride = self:getChildByTag(TAG_RIDE_TOP)
  if 0 == icon then
    if ride then
      self:setPartToBeRemoved(TAG_RIDE_TOP)
      self:setPartAniLoadedDelay(ride:getType())
      self.rideTop = nil
    end
    return
  end
  local act = self:getRealAction(TAG_RIDE_TOP)
  if nil == ride then
    ride = CharPart.new(icon, 1, act, self:getRealDirection(), self:getBasicPoint(TAG_RIDE_TOP), self:getInterval(), self.syncLoad, self:getLoadType())
    self:addChild(ride, ZORDER_RIDE_TOP, TAG_RIDE_TOP)
    ride:setType("ride_top")
  elseif self.toBeRemoveParts and self.toBeRemoveParts[TAG_RIDE_TOP] then
    self.toBeRemoveParts[TAG_RIDE_TOP] = nil
  end
  self.rideTop = ride
  ride:setAction(act)
  ride:setFirstFrame(self.firstFrame)
  ride:setLastFrame(self.lastFrame)
  ride:setLoopTimes(self.loopTimes)
  ride:setReverse(self.reverse)
  ride:setInterval(self:getInterval())
  ride:setBasicPoint(self:getBasicPoint(TAG_RIDE_TOP))
  ride:setIcon(icon, 1)
  ride:setScale(1 / self:getCharScale())
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
end
function CharAction:tryToChangeCharWalkResPathForRide()
  if not self.char then
    return
  end
  local walkIcon = self.petRideInfo.walk_icon
  if self.rideIcon and self.rideIcon > 0 and self.action == Const.SA_WALK and walkIcon and walkIcon > 0 then
    if walkIcon > 10000 and not string.isNilOrEmpty(self.partIndex) and 0 < tonumber(self.partIndex) then
      walkIcon = walkIcon - 10000
      local checkUpdate = self.char.icon ~= self.icon * 10 + walkIcon
      if checkUpdate then
        self.char:setIcon(self.icon * 10 + walkIcon, 0)
        for i = 1, GATHER_COUNT do
          local char = self:getChildByTag(TAG_CHAR_START + (i - 1) * 10000)
          if char then
            local iKey = string.format("icon%d", i)
            char:setIcon(self[iKey] * 10 + walkIcon, 0)
          end
        end
        for i = TAG_CHAR_PART_BEGIN, TAG_CHAR_PART_MAX do
          local char = self:getChildByTag(i)
          if char then
            char:setIcon(self.icon * 10 + walkIcon, char.weapon)
          end
        end
        self:setBodyColorIndex(self.partColorIndex, self.icon * 10 + walkIcon, checkUpdate)
      end
    else
      self.char:setIcon(self.icon, walkIcon)
      for i = 1, GATHER_COUNT do
        local char = self:getChildByTag(TAG_CHAR_START + i - 1)
        if char then
          local iKey = string.format("icon%d", i)
          char:setIcon(self[iKey], walkIcon)
        end
      end
    end
  elseif not string.isNilOrEmpty(self.partIndex) and 0 < tonumber(self.partIndex) then
    local checkUpdate = self.char.icon ~= self.icon
    if checkUpdate then
      self.char:setIcon(self.icon, 0)
      for i = 1, GATHER_COUNT do
        local char = self[string.format("char%02d", i)]
        if char then
          local iKey = string.format("icon%d", i)
          char:setIcon(self[iKey], 0)
        end
      end
      for i = TAG_CHAR_PART_BEGIN, TAG_CHAR_PART_MAX do
        local char = self:getChildByTag(i)
        if char then
          char:setIcon(self.icon, char.weapon)
        end
      end
      self:setBodyColorIndex(self.partColorIndex, self.icon, checkUpdate)
    end
  else
    self.char:setIcon(self.icon, 0)
    for i = 1, GATHER_COUNT do
      local char = self[string.format("char%02d", i)]
      if char then
        local iKey = string.format("icon%d", i)
        char:setIcon(self[iKey], 0)
      end
    end
  end
end
function CharAction:tryToChangeCharOrder()
  if not self.char then
    return
  end
  local step = 100
  if 5 == self.direction or 7 == self.direction then
    step = -100
  end
  local curOrder = 0
  for i = 1, GATHER_COUNT do
    local char = self:getChildByTag(TAG_CHAR_START + (i - 1) * 10000)
    if char then
      curOrder = curOrder + step
      char:setLocalZOrder(curOrder)
    end
    for j = TAG_CHAR_PART_BEGIN, TAG_CHAR_PART_MAX do
      local char = self:getChildByTag(TAG_CHAR_START + (i - 1) * 10000 + j)
      if char then
        curOrder = curOrder + step
        char:setLocalZOrder(curOrder)
      end
    end
  end
end
function CharAction:setAction(act, noUpdateNow)
  if act == nil or self.action == act then
    return
  end
  local actOld = self:getRealAction(TAG_RIDE_BOTTOM)
  self.action = act
  local actNew = self:getRealAction(TAG_RIDE_BOTTOM)
  if self.rideIcon and self.rideIcon > 0 and actOld == actNew then
    return
  end
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:setInterval(self:getInterval())
      v:setBasicPoint(self:getBasicPoint(v:getTag()))
      v:setAction(self:getRealAction(v:getTag()))
    end
  end
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
  self.totalDelayUnits = self:getTotalDelayUnits()
end
function CharAction:removeUnUsedPart()
  if not self.toBeRemoveParts then
    return
  end
  local part
  for k, _ in pairs(self.toBeRemoveParts) do
    part = self:getChildByTag(k)
    if part then
      part:removeFromParent()
    end
  end
  self.toBeRemoveParts = null
end
function CharAction:getTotalDelayUnits()
  return self.char:getTotalDelayUnits()
end
function CharAction:tryToChangeCharResDirForRide()
  if not self.char or not self.rideIcon or self.rideIcon == 0 then
    return
  end
  local dir = PetMgr:tryToChangeCharResDirForRide(self.icon, self.rideIcon, self.direction)
  self.char:setDirection(dir or self:getRealDirection())
end
function CharAction:setDirection(dir, noUpdateNow)
  if dir == nil or self.direction == dir then
    return
  end
  self.direction = dir
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:setInterval(self:getInterval())
      v:setBasicPoint(self:getBasicPoint(v:getTag()))
      v:setDirection(self:getRealDirection())
    end
  end
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
end
function CharAction:setLoopTimes(times, noUpdateNow)
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:setLoopTimes(times)
    end
  end
  self.dirtyUpdate = true
  if not noUpdateNow then
    self:updateNow()
  end
end
function CharAction:isDirtyUpdate()
  return self.dirtyUpdate
end
function CharAction:updateNow()
  self.dirtyUpdate = nil
  self:recordCallIndex(107)
  self:setAllAniToLoad()
  self:tryToChangeCharResDirForRide()
  self:tryToChangeCharWalkResPathForRide()
  self:tryToChangeCharOrder()
  self:recordCallIndex(108)
  if self.rideBottom and self.petRideInfo then
    local act = self:getRealAction(TAG_RIDE_BOTTOM) == Const.SA_STAND and "stand" or "walk"
    local key = act .. "_swing" .. self.direction
    local swingInfo = self.petRideInfo[key]
    self.char:setPetSwingInfo(swingInfo)
    local char
    for i = 1, GATHER_COUNT do
      char = self:getChildByTag(TAG_CHAR_START + (i - 1) * 10000)
      if char then
        char:setPetSwingInfo(swingInfo)
      end
      for j = TAG_CHAR_PART_BEGIN, TAG_CHAR_PART_MAX do
        local part = self:getChildByTag(TAG_CHAR_START + (i - 1) * 10000 + j)
        if part then
          part:setPetSwingInfo(swingInfo)
        end
      end
    end
    for i = TAG_CHAR_PART_BEGIN, TAG_CHAR_PART_MAX do
      local part = self:getChildByTag(i)
      if part then
        part:setPetSwingInfo(swingInfo)
      end
    end
    if self.petRideInfo.use_swing_for_who == "char" then
      swingInfo = nil
    end
    self.rideBottom:setPetSwingInfo(swingInfo)
    if self.rideTop then
      self.rideTop:setPetSwingInfo(swingInfo)
    end
  else
    self.char:setPetSwingInfo(nil)
    for i = TAG_CHAR_PART_BEGIN, TAG_CHAR_PART_MAX do
      local part = self:getChildByTag(i)
      if part then
        part:setPetSwingInfo(nil)
      end
    end
    self:clearBasicPointRange()
  end
  self:recordCallIndex(109)
  local interval = self:getInterval()
  local realDir, flip = self:getRealDirection()
  local children = self:getChildren()
  local needs = {}
  for _, v in pairs(children) do
    if not self:isToBeRemove(v:getTag()) then
      table.insert(needs, v)
    end
  end
  for _, v in pairs(needs) do
    if self:isCharPart(v) then
      if v.setFlippedX then
        v:setFlippedX(flip)
      end
      v:setDirection(realDir)
      v:setInterval(interval)
      v.dirty = true
      v:updateNow()
    end
  end
  self:recordCallIndex(110)
  self:recordCallIndex(111)
end
function CharAction:resetAction()
  self.char:setCallback(nil)
  self:setLoopTimes(0)
  self:setAction(Const.SA_STAND)
end
function CharAction:clearEndActionCallBack()
  if self.char then
    self.char:setCallback(nil)
  end
end
function CharAction:playActionOnce(cb, action)
  self:playAction(cb, action, 1)
end
function CharAction:playAction(cb, action, time)
  if self.action ~= Const.SA_STAND then
    return
  end
  action = action or Const.SA_ATTACK
  local destActCartoonInfo = self.cartoonInfo[gf:getActionStr(action)]
  if not destActCartoonInfo and AnimationMgr:isReplaceAction(self.icon, action) then
    destActCartoonInfo = ActionReplaceCfg[self.icon].replaceAct[gf:getActionStr(action)]
  end
  if not destActCartoonInfo and not self.cartoonInfo.attack then
    Log:W(self.icon .. " no attack action!")
    return
  end
  self.char:setCallback(function()
    self:resetAction()
    if cb then
      cb()
    end
  end)
  self:setLoopTimes(time)
  self:setAction(action)
end
function CharAction:playWalkThreeTimes(cb)
  if not self.cartoonInfo.walk then
    Log:W(self.icon .. " no walk action!")
    return
  end
  self.char:setCallback(function()
    self:resetAction()
    if cb then
      cb()
    end
  end)
  self:setLoopTimes(3)
  self:setAction(Const.SA_WALK)
end
function CharAction:pausePlay()
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:pausePlay()
    end
  end
  self.isPausePlay = true
end
function CharAction:continuePlay()
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:continuePlay()
    end
  end
  self.isPausePlay = false
end
function CharAction:setRideOffset(x, y)
  self.rideOffsetX = x
  self.rideOffsetY = y
end
function CharAction:getGatherSuffix()
  local keys = {}
  for i = 1, GATHER_COUNT do
    local iKey = string.format("icon%d", i)
    if self[iKey] and self[iKey] > 0 then
      table.insert(keys, PetMgr:getCharIconForRideOffset(self[iKey]))
    end
  end
  return table.concat(keys, ":")
end
function CharAction:getRideOffset(icon, tag)
  if tag and (tag < TAG_CHAR_START or tag > TAG_CHAR_MAX) then
    tag = nil
  end
  icon = icon or self.icon
  local offsetX, offsetY
  offsetX, offsetY = PetMgr:getRideOffset(icon, self.rideIcon, self.direction, self:getRealAction(TAG_RIDE_BOTTOM), PetMgr:getCharIconForRideOffset(self.icon) .. ":" .. self:getGatherSuffix())
  if 0 == offsetX and 0 == offsetY then
    offsetX, offsetY = PetMgr:getRideOffset(icon, self.rideIcon, self.direction, self:getRealAction(TAG_RIDE_BOTTOM), tag)
  end
  if 0 == offsetX and 0 == offsetY then
    offsetX, offsetY = PetMgr:getRideOffset(icon, self.rideIcon, self.direction, self:getRealAction(TAG_RIDE_BOTTOM))
  end
  local x = (self.rideOffsetX or 0) + offsetX
  local y = (self.rideOffsetY or 0) + offsetY
  return x, y
end
function CharAction:resetArea()
  local char = self.char
  if self.rideBottom then
    char = self.rideBottom
    self:setRideOffset(self:getCfgInt("waist_x", self.action) - self:getCfgInt("centre_x", self.action), self:getCfgInt("centre_y", self.action) - self:getCfgInt("waist_y", self.action))
  else
    self:setRideOffset(0, 0)
  end
  if not char then
    return
  end
  self:setContentSize(char.contentSize or cc.size(0, 0))
  self:setAnchorPoint(char.anchorPoint or cc.p(0, 0))
  local pos = char.offsetPos or cc.p(0, 0)
  local children = self:getChildren()
  local offX, offY, tagValue
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      tagValue = v:getTag()
      if tagValue >= TAG_CHAR_START and tagValue <= TAG_CHAR_MAX then
        offX, offY = self:getRideOffset(v.icon, v:getTag())
      else
        offX, offY = self:getRideOffset()
      end
      v:setPosition(pos.x + offX, pos.y + offY)
    end
  end
  char:setPosition(char.offsetPos or cc.p(0, 0))
  if self.rideTop then
    self.rideTop:setPosition(char.offsetPos or cc.p(0, 0))
  end
  if self.shadow then
    self.shadow:setPosition(char.offsetPos or cc.p(0, 0))
  end
end
function CharAction:readCartoonInfo(rideIcon)
  local cartoonInfo = require(ResMgr:getCharCartoonPath(self.icon)) or {}
  self.charCartoonInfo = cartoonInfo
  self.cartoonInfo = cartoonInfo
  local useRideIcon = rideIcon or self.rideIcon
  if useRideIcon and useRideIcon > 0 then
    cartoonInfo = require(ResMgr:getCharCartoonPath(useRideIcon)) or {}
    self.cartoonInfo = cartoonInfo
  end
end
function CharAction:getCfgIntByInfo(key, act, dontChangeAct, cartoonInfo)
  local action = gf:getActionStr(act)
  if action == nil then
    return 0
  end
  local info = cartoonInfo[action]
  if not info and ActionReplaceCfg[self.icon] and ActionReplaceCfg[self.icon].replaceAct[action] then
    local destCartoon = require(ResMgr:getCharCartoonPath(ActionReplaceCfg[self.icon].icon))
    info = destCartoon[action]
    cartoonInfo[action] = info
  end
  if (not info or not info.centre_x) and not dontChangeAct then
    local reuseAct = ACTION_REUSE_MAP[act]
    if reuseAct then
      action = gf:getActionStr(reuseAct)
      info = cartoonInfo[action]
    end
  end
  if self:isCustomDressPlayAttack2() then
    info = cartoonInfo[gf:getActionStr(Const.SA_ATTACK2)]
  end
  if not info then
    return 0
  end
  local realDir, flip = self:getRealDirection()
  if info[key .. "_4"] then
    local realKey = string.format(key .. "_%d", realDir - 2)
    return tonumber(info[realKey])
  end
  if self:containsDirection(self.icon, self.curRealAction or self.action, self.dir) and info[key .. "_3"] then
    local realKey
    if realDir == 1 then
      realKey = string.format(key .. "_%d", 0)
    elseif realDir == 3 then
      realKey = string.format(key .. "_%d", 1)
    elseif realDir == 5 then
      realKey = string.format(key .. "_%d", 2)
    else
      realKey = string.format(key .. "_%d", 3)
    end
    return tonumber(info[realKey])
  end
  if realDir == 5 and info[key .. "_1"] then
    return tonumber(info[key .. "_1"])
  end
  if info[key .. "_0"] then
    return tonumber(info[key .. "_0"])
  end
  if info[key] then
    return tonumber(info[key])
  end
  return 0
end
function CharAction:getCfgInt(key, act, useCharCartoonInfo, dontChangeAct)
  if self.cartoonInfo == nil then
    self:readCartoonInfo()
  end
  act = act or self.action
  local cartoonInfo = self.cartoonInfo
  if useCharCartoonInfo then
    cartoonInfo = self.charCartoonInfo
  end
  return self:getCfgIntByInfo(key, act, dontChangeAct, cartoonInfo)
end
function CharAction:containsDirection(icon, action, dir)
  if not CharDirection then
    return
  end
  action = gf:getActionStr(action)
  if CharDirection[icon] and CharDirection[icon][action] then
    for i = 1, #CharDirection[icon][action] do
      if CharDirection[icon][action][i] == dir then
        return true
      end
    end
  end
end
function CharAction:getRealDirection()
  local dir = self.direction
  local action = self.action
  local flip = false
  if nil == dir or action == nil then
    return 5
  end
  if self:containsDirection(self.icon, self.curRealAction or action, dir) then
    return dir, false
  end
  if action == Const.SA_STAND or action == Const.FA_WALK then
    if dir == 1 then
      dir = 3
      flip = true
    elseif dir <= 0 then
      dir = 4
      flip = true
    elseif dir >= 7 then
      dir = 5
      flip = true
    end
  elseif dir <= 0 or dir == 1 then
    dir = 3
    flip = true
  elseif dir == 2 then
    dir = 3
  elseif dir == 4 then
    dir = 5
  elseif dir == 6 or dir >= 7 then
    dir = 5
    flip = true
  end
  return dir, flip
end
function CharAction:getDirPointRange()
  local points, flip = self:getBasicPointRange()
  if not points then
    return
  end
  if flip then
    local realPonits = {}
    for i = 1, #points do
      local point = {}
      point.x = 0 - points[i].x
      point.y = points[i].y
      table.insert(realPonits, point)
    end
    return realPonits
  else
    return points
  end
end
function CharAction:isCustomDressPlayAttack2()
  if self.action ~= Const.SA_ATTACK then
    return
  end
  if string.isNilOrEmpty(self.partIndex) then
    return
  end
  local len = #self.partIndex
  assert(20 == len or 16 == len, "part string must be equal to 20 or 16")
  local weaponIndex = tonumber(string.sub(self.partIndex, 1, 2))
  if (weaponIndex == 1 or weaponIndex == 4 or weaponIndex == 5 or weaponIndex == 6) and self.cartoonInfo[gf:getActionStr(Const.SA_ATTACK2)] then
    return true
  end
end
function CharAction:getRealAction(typeTag)
  local reuseAction = ACTION_REUSE_MAP[self.action]
  if reuseAction then
    local useCharInfo = typeTag == TAG_CHAR or typeTag == TAG_WEAPON or typeTag >= TAG_CHAR_START and typeTag <= TAG_CHAR_MAX or typeTag >= TAG_CHAR_PART_BEGIN and typeTag <= TAG_CHAR_PART_MAX
    if self:getCfgInt("centre_x", self.action, useCharInfo, true) == 0 then
      return reuseAction
    end
  end
  if self:isCustomDressPlayAttack2() then
    return Const.SA_ATTACK2
  end
  return self.action
end
function CharAction:clearBasicPointRange()
  self.dirBasicPointRange0 = nil
  self.dirBasicPointRange1 = nil
  self.dirBasicPointRange2 = nil
  self.dirBasicPointRange3 = nil
  self.dirBasicPointRange4 = nil
  self.dirBasicPointRange5 = nil
  self.dirBasicPointRange6 = nil
  self.dirBasicPointRange7 = nil
end
function CharAction:calcBasicPoints(points, lX, lY, rX, rY, x, y)
  if rX == 0 and rY == 0 and lX == 0 and lY == 0 then
    return
  end
  if math.abs(lY - rY) < math.abs(lX - rX) then
    local k = (lY - rY) / (lX - rX)
    local rangeX1 = (lX - x) / Const.PANE_WIDTH
    local rangeX2 = (rX - x) / Const.PANE_WIDTH
    local b = (rY - y - k * (rX - x)) / Const.PANE_WIDTH
    local step = rangeX1 < rangeX2 and 1 or -1
    for i = rangeX1, rangeX2, step do
      local point = {}
      point.x = self:getNearValue(i)
      point.y = self:getNearValue(k * i + b)
      table.insert(points, point)
    end
  else
    local k = (lX - rX) / (lY - rY)
    local rangeY1 = (lY - y) / Const.PANE_HEIGHT
    local rangeY2 = (rY - y) / Const.PANE_HEIGHT
    local b = (rX - x - k * (rY - y)) / Const.PANE_HEIGHT
    local step = rangeY1 < rangeY2 and 1 or -1
    for i = rangeY1, rangeY2, step do
      local point = {}
      point.y = self:getNearValue(i)
      point.x = self:getNearValue(k * i + b)
      table.insert(points, point)
    end
  end
end
function CharAction:getBasicPointRange()
  local dir, flip = self:getRealDirection()
  local key = "dirBasicPointRange" .. dir
  if self[key] then
    return self[key], flip
  end
  local scale = self:getCharScale()
  local act = self:getRealAction(TAG_RIDE_BOTTOM)
  local rX = self:getCfgInt("right_x", act) * scale
  local rY = self:getCfgInt("right_y", act) * scale
  local lX = self:getCfgInt("left_x", act) * scale
  local lY = self:getCfgInt("left_y", act) * scale
  local tX = self:getCfgInt("top_x", act) * scale
  local tY = self:getCfgInt("top_y", act) * scale
  local bX = self:getCfgInt("bottom_x", act) * scale
  local bY = self:getCfgInt("bottom_y", act) * scale
  if rX == 0 and rY == 0 and lX == 0 and lY == 0 and tX == 0 and tY == 0 and bX == 0 and bY == 0 then
    return
  end
  local x = self:getCfgInt("centre_x", act) * scale
  local y = self:getCfgInt("centre_y", act) * scale
  local points = {}
  self:calcBasicPoints(points, lX, lY, rX, rY, x, y)
  self:calcBasicPoints(points, tX, tY, bX, bY, x, y)
  local shelterInfo = self.petRideInfo["shelter_offset" .. dir]
  if shelterInfo then
    local pts = points
    points = {}
    for i = 1, #pts do
      table.insert(points, pts[i])
      table.insert(points, {
        x = pts[i].x + shelterInfo.x,
        y = pts[i].y + shelterInfo.y
      })
      table.insert(points, {
        x = pts[i].x - shelterInfo.x,
        y = pts[i].y - shelterInfo.y
      })
    end
  end
  self[key] = points
  return points, flip
end
function CharAction:getNearValue(value)
  local lastValue = value
  if value < 0 then
    lastValue = math.ceil(value - 0.5)
  else
    lastValue = math.floor(value + 0.5)
  end
  return lastValue
end
function CharAction:getBasicPoint(tag)
  local useCharCartoonInfo = tag == TAG_CHAR or tag == TAG_WEAPON or tag >= TAG_CHAR_PART_BEGIN and tag <= TAG_CHAR_PART_MAX
  local x, y
  if tag >= TAG_CHAR_START and tag <= TAG_CHAR_MAX then
    local iKey = string.format("icon%d", math.floor((tag - TAG_CHAR_START) / 10000) + 1)
    local icon = self[iKey]
    local cartoonInfo = require(ResMgr:getCharCartoonPath(icon)) or {}
    x = self:getCfgIntByInfo("centre_x", self.action, nil, cartoonInfo)
    y = self:getCfgIntByInfo("centre_y", self.action, nil, cartoonInfo)
  elseif tag == TAG_CHAR_SHADOW then
    local icon = self.shadowIcon
    local cartoonInfo = require(ResMgr:getCharCartoonPath(icon)) or {}
    x = self:getCfgIntByInfo("centre_x", self.action, nil, cartoonInfo)
    y = self:getCfgIntByInfo("centre_y", self.action, nil, cartoonInfo)
  else
    x = self:getCfgInt("centre_x", self.action, useCharCartoonInfo)
    y = self:getCfgInt("centre_y", self.action, useCharCartoonInfo)
  end
  local scale = 1
  if TAG_WEAPON == tag then
    scale = self:getWeaponScale(self.weaponIcon)
  elseif TAG_CHAR_SHADOW == tag then
  else
    scale = self:getCharScale()
  end
  return cc.p(x * scale, y * scale)
end
function CharAction:getCharScale()
  local scale = self:getCfgInt("scale", self.action)
  return scale > 0 and scale / 100 or 1
end
function CharAction:getWeaponScale(weaponIcon)
  local scale = 0
  if weaponIcon then
    scale = self:getCfgInt(string.format("%s_scale", tostring(weaponIcon)), self.action)
  end
  return scale > 0 and scale / 100 or 1
end
function CharAction:getShadowScale()
  local icon = self.shadowIcon
  local cartoonInfo = require(ResMgr:getCharCartoonPath(icon)) or {}
  local scale = self:getCfgIntByInfo("scale", self.action, nil, cartoonInfo)
  return scale > 0 and scale / 100 or 1
end
function CharAction:getWaistOffset()
  local fx = self:getCfgInt("centre_x", Const.SA_STAND, true)
  local fy = self:getCfgInt("centre_y", Const.SA_STAND, true)
  local wx = self:getCfgInt("waist_x", Const.SA_STAND, true)
  local wy = self:getCfgInt("waist_y", Const.SA_STAND, true)
  local scale = self:getScale()
  local _, flip = self:getRealDirection()
  local offX, offY = self:getRideOffset()
  local offHeadX, offHeadY = PetMgr:getRideWaistOffset(self.icon, self.rideIcon, self.direction, self:getRealAction(TAG_RIDE_BOTTOM))
  offX = offX + offHeadX
  offY = offY + offHeadY
  if flip then
    return (fx - wx + offX) * scale, (fy - wy + offY) * scale
  else
    return (wx - fx + offX) * scale, (fy - wy + offY) * scale
  end
end
function CharAction:getHeadOffset()
  local fx = self:getCfgInt("centre_x", Const.SA_STAND, true)
  local fy = self:getCfgInt("centre_y", Const.SA_STAND, true)
  local hx = self:getCfgInt("head_x", Const.SA_STAND, true)
  local hy = self:getCfgInt("head_y", Const.SA_STAND, true)
  local scale = self:getScale()
  local _, flip = self:getRealDirection()
  local offX, offY = self:getRideOffset()
  local offHeadX, offHeadY = PetMgr:getRideHeadOffset(self.icon, self.rideIcon, self.direction, self:getRealAction(TAG_RIDE_BOTTOM))
  offX = offX + offHeadX
  offY = offY + offHeadY
  if flip then
    return (fx - hx + offX) * scale, (fy - hy + offY) * scale
  else
    return (hx - fx + offX) * scale, (fy - hy + offY) * scale
  end
end
function CharAction:getInterval()
  if self.cartoonInfo == nil then
  else
    local action = gf:getActionStr(self:getRealAction(TAG_RIDE_BOTTOM))
    if action == nil then
    else
      local info = self.cartoonInfo[action]
      if info == nil then
      else
        local interval = (tonumber(info.rate) or 100) / 1000
        local rate = 1
        if action == "attack" or action == "attack2" then
          rate = 0.7
        elseif action == "defense" or action == "parry" or action == "die" then
          rate = 0.4
        end
        return interval * rate
      end
    end
  end
  return 0.1
end
function CharAction:setCharOpacity(opacity)
  local children = self:getChildren()
  self.charOpacity = opacity
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:setOpacity(opacity)
    end
  end
end
function CharAction:setShelter(shelter)
  local opacity = shelter and 127 or self.charOpacity
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:setOpacity(opacity)
    end
  end
end
function CharAction:haveAct(saAct)
  if not saAct then
    return false
  end
  if self.cartoonInfo == nil then
    self:readCartoonInfo()
  end
  local action = gf:getActionStr(saAct)
  if not action then
    return false
  end
  if self.cartoonInfo[action] then
    return true
  elseif AnimationMgr:isReplaceAction(self.icon, action) then
    return true
  end
  return false
end
function CharAction:getHeadPos()
  if self.char == nil then
    return
  end
  local size = self.char.contentSize
  local anchor = self.char.anchorPoint
  local x, y = self:getHeadOffset()
  return x + anchor.x * size.width, y + anchor.y * size.height
end
function CharAction:setGray(gray)
  local shader = gray and ShaderMgr:getGrayShader() or ShaderMgr:getRawShader()
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:setGLProgramState(shader)
    end
  end
end
function CharAction:setPartToBeRemoved(tag)
  if not self.toBeRemoveParts then
    self.toBeRemoveParts = {}
  end
  self.toBeRemoveParts[tag] = 1
end
function CharAction:isToBeRemove(tag)
  return self.toBeRemoveParts and self.toBeRemoveParts[tag]
end
function CharAction:setAllAniToLoad()
  self.partAniStatus = {}
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      self.partAniStatus[v:getType()] = STATUS_TO_LOAD
    end
  end
end
function CharAction:setPartAniToLoad(partType)
  self.partAniStatus[partType] = STATUS_TO_LOAD
end
function CharAction:setPartAniLoadedDelay(partType)
end
function CharAction:isAllPartLoaded()
  local isLoaded = true
  for k, v in pairs(self.partAniStatus) do
    if STATUS_TO_LOAD == v then
      isLoaded = false
      break
    end
  end
  return isLoaded
end
function CharAction:setPartAniLoaded(partType)
  if self.partAniStatus[partType] then
    self.partAniStatus[partType] = STATUS_LOADED
  end
  local isLoaded = self:isAllPartLoaded()
  if isLoaded then
    self:removeUnUsedPart()
    if "table" == type(self.refreshColorIndex) then
      for _, v in pairs(self.refreshColorIndex) do
        if "function" == type(v) then
          v()
        end
      end
    end
    self:playAnimation()
    self:setVisible(true)
    if "function" == type(self.loadComplateCallBack) then
      performWithDelay(self, function()
        if "function" == type(self.loadComplateCallBack) then
          self.loadComplateCallBack()
        end
      end, 0)
    end
  end
end
function CharAction:playAnimation()
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:playAnimation()
    end
  end
  self:resetArea()
  self.isPausePlay = false
end
function CharAction:clear()
  self.sendDebugLog = nil
  self:cleanUnPlayAnimation()
end
function CharAction:cleanUnPlayAnimation()
  local children = self:getChildren()
  for _, v in pairs(children) do
    if self:isCharPart(v) then
      v:clear()
    end
  end
end
function CharAction:isCharPart(v)
  if self.curIsTestDist and v and not v.setInterval then
    local m = {}
    table.insert(m, "----->invalid charpart:")
    table.insert(m, "type:" .. type(v))
    table.insert(m, "name:" .. tostring(v:getName()))
    table.insert(m, "cname:" .. tostring(v.__cname))
    table.insert(m, gfTraceback())
    gf:ftpUploadEx(table.concat(m, "\n"))
  end
  return v and "CharPart" == v.__cname and not self:isToBeRemove(v:getTag())
end
function CharAction:setLoadType(loadType)
  self.loadType = loadType
end
function CharAction:getLoadType()
  return self.loadType or LOAD_TYPE.CHAR
end
return CharAction
