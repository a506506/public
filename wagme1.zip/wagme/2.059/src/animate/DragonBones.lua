local DragonBones = class("DragonBones", function()
  return cc.Sprite:create()
end)
function DragonBones:ctor(icon, extraPara, resType)
  self.icon = icon or 0
  self.dbMagic = nil
  self.magic = nil
  self.rText = nil
  self.opacityLayer = nil
  self.rTextSize = nil
  self.activeName = nil
  self.resType = resType or "char"
  self:setAnchorPoint(cc.p(0, 0))
  self:updateNow()
  self:processSomeExtraPara(extraPara)
  local NODE_CLEANUP = Const.NODE_CLEANUP
  local function onNodeEvent(event)
    if NODE_CLEANUP == event then
      self:onNodeCleanup()
    end
  end
  self:registerScriptHandler(onNodeEvent)
end
function DragonBones:onNodeCleanup()
end
function DragonBones:processSomeExtraPara(extraPara)
  if not extraPara or not self.magic then
    return
  end
  if extraPara.rotation then
    self.magic:setRotation(extraPara.rotation)
  end
  if extraPara.rotationX then
    self.magic:setRotationSkewX(extraPara.rotationX)
  end
  if extraPara.rotationY then
    self.magic:setRotationSkewY(extraPara.rotationY)
  end
  if extraPara.scaleX then
    self.magic:setScaleX(extraPara.scaleX)
  end
  if extraPara.scaleY then
    self.magic:setScaleY(extraPara.scaleY)
  end
end
function DragonBones:setRTextSizeAndPos(size, pos)
  self.rTextSize = size
  self.magicPos = pos or cc.p(self:getPosition())
end
function DragonBones:setMaskPanel(sprite, subSprite)
  if not self.magic or not self.rTextSize or not self.magicPos then
    return
  end
  if not sprite then
    return
  end
  if not self.rText then
    self.rText = cc.RenderTexture:create(self.rTextSize.width, self.rTextSize.height)
    self.rText:setPosition(self.rTextSize.width / 2 - self.magicPos.x, self.rTextSize.height / 2 - self.magicPos.y)
    self.rText:setVisible(false)
    self:addChild(self.rText)
  end
  if self.activeName then
    DragonBonesMgr:toStop(self.dbMagic, self.activeName, 0)
  end
  self.rText:setVisible(true)
  self.magic:setVisible(true)
  self.magic:setPosition(self.magicPos.x, self.magicPos.y)
  self.rText:beginWithClear(0, 0, 0, 0)
  self.magic:visit()
  if subSprite then
    subSprite:visit()
  end
  sprite:visit()
  self.rText:endToLua()
  self.magic:setPosition(0, 0)
  self.magic:setVisible(false)
end
function DragonBones:setAlpha(alpha)
  if not self.magic or not self.rTextSize or not self.magicPos then
    return
  end
  if alpha then
    if alpha > 255 then
      alpha = 255
    elseif alpha < 0 then
      alpha = 0
    end
    if alpha == 255 then
      self.magic:setVisible(true)
      if self.rText then
        self.rText:setVisible(false)
      end
    else
      if not self.rText then
        self.rText = cc.RenderTexture:create(self.rTextSize.width, self.rTextSize.height)
        self.rText:setPosition(self.rTextSize.width / 2 - self.magicPos.x, self.rTextSize.height / 2 - self.magicPos.y)
        self.rText:setVisible(false)
        self:addChild(self.rText)
      end
      if not self.opacityLayer then
        self.opacityLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, alpha), self.rTextSize.width, self.rTextSize.height)
        self.opacityLayer:setBlendFunc(gl.ZERO, gl.SRC_ALPHA)
        self.opacityLayer:setVisible(false)
        self:addChild(self.opacityLayer)
      end
      self.opacityLayer:setOpacity(alpha)
      if self.activeName then
        DragonBonesMgr:toStop(self.dbMagic, self.activeName, 0)
      end
      self.rText:setVisible(true)
      self.magic:setVisible(true)
      self.opacityLayer:setVisible(true)
      self.rText:beginWithClear(0, 0, 0, 0)
      self.magic:setPosition(self.magicPos.x, self.magicPos.y)
      self.magic:visit()
      self.magic:setPosition(0, 0)
      self.opacityLayer:visit()
      self.rText:endToLua()
      self.magic:setVisible(false)
      self.opacityLayer:setVisible(false)
    end
  end
end
function DragonBones:setIcon(icon)
  if self.icon == icon then
    return
  end
  self.icon = icon
  self:updateNow()
end
function DragonBones:setMagicScale(scale)
  if not self.magic then
    return
  end
  self.magic:setScale(scale)
end
function DragonBones:updateNow()
  if self.magic then
    self.magic:removeFromParent()
  end
  self.magic = nil
  self.dbMagic = nil
  local dbMagic
  if self.resType == "ui" then
    dbMagic = DragonBonesMgr:createUIDragonBones(self.icon, string.format("%05d", self.icon))
  elseif self.resType == "map" then
    dbMagic = DragonBonesMgr:createMapDragonBones(self.icon, string.format("%05d", self.icon))
  else
    dbMagic = DragonBonesMgr:createCharDragonBones(self.icon, string.format("%05d", self.icon))
  end
  if not dbMagic then
    return
  end
  local magic = tolua.cast(dbMagic, "cc.Node")
  self:addChild(magic)
  self.dbMagic = dbMagic
  self.magic = magic
end
function DragonBones:toPlay(activeName, loopNum)
  if not self.dbMagic then
    return
  end
  self.activeName = activeName
  self.loopNum = loopNum
  DragonBonesMgr:toPlay(self.dbMagic, activeName, loopNum)
end
return DragonBones
