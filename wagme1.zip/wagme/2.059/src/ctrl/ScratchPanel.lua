local ScratchPanel = class("ScratchPanel")
function ScratchPanel:ctor(dlg, panel, shade, radius, desRate, rateCb, effectAareRate, eventCallback)
  self.canTouchFlag = true
  self.effectAareRate = effectAareRate or 1
  self.desRate = desRate or 0.8
  self.radius = radius or 10
  self.rateCb = rateCb
  local rText = cc.RenderTexture:create(panel:getContentSize().width, panel:getContentSize().height)
  rText:setPosition(panel:getContentSize().width / 2, panel:getContentSize().height / 2)
  panel:addChild(rText)
  local image
  if type(shade) == "string" then
    image = cc.Sprite:create(shade)
    image:setAnchorPoint(0, 0)
    image:setPosition(0, 0)
  else
    image = shade
  end
  rText:begin()
  image:visit()
  rText:endToLua()
  self.effectAareRate = self.effectAareRate or 1
  self.col = math.floor(panel:getContentSize().width * self.effectAareRate)
  self.row = math.floor(panel:getContentSize().height * self.effectAareRate)
  self.map = {}
  self.map.all = self.col * self.row
  self.map.part = 0
  for i = 1, self.row do
    self.map[i] = {}
    for j = 1, self.col do
      self.map[i][j] = 1
    end
  end
  local box = panel:getBoundingBox()
  box.x = 0
  box.y = 0
  local lastPos = {}
  local lastMoveTime = 0
  local function onErase(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
    local curPos = {}
    curPos.x = touchPos.x
    curPos.y = touchPos.y
    touchPos = rText:convertToNodeSpace(touchPos)
    touchPos.x = touchPos.x + box.width / 2
    touchPos.y = touchPos.y + box.height / 2
    if nil == box then
      return curPos
    end
    if not lastPos.x then
      lastPos.x = curPos.x
      lastPos.y = curPos.y
    end
    lastPos = rText:convertToNodeSpace(lastPos)
    lastPos.x = lastPos.x + box.width / 2
    lastPos.y = lastPos.y + box.height / 2
    local c = 0
    local pos = {}
    pos.x = lastPos.x - touchPos.x
    pos.y = lastPos.y - touchPos.y
    local nurmal = cc.pNormalize(pos)
    local lastDistance = cc.pGetDistance(touchPos, lastPos)
    if lastDistance > 2 then
      local line = gf:drawLineEx(self.radius, cc.c4b(0, 0, 0, 0), {
        gl.ONE,
        gl.ZERO
      }, touchPos, lastPos)
      rText:begin()
      line:visit()
      rText:endToLua()
    end
    while lastDistance >= 2 do
      touchPos.x = touchPos.x + nurmal.x * 2
      touchPos.y = touchPos.y + nurmal.y * 2
      if lastDistance <= cc.pGetDistance(touchPos, lastPos) then
        break
      end
      lastDistance = cc.pGetDistance(touchPos, lastPos)
      if cc.rectContainsPoint(box, touchPos) then
        local effectPos = {}
        effectPos.x = touchPos.x - (box.width - box.width * self.effectAareRate) / 2
        effectPos.y = touchPos.y - (box.height - box.height * self.effectAareRate) / 2
        local box2 = {}
        box2.width = box.width * self.effectAareRate
        box2.height = box.height * self.effectAareRate
        box2.x = 0
        box2.y = 0
        if cc.rectContainsPoint(box2, effectPos) then
          local x1 = math.floor(effectPos.x) - self.radius + 1
          local y1 = math.floor(effectPos.y) + self.radius - 1
          local x2 = x1 + self.radius + self.radius - 1
          local y2 = y1 - (self.radius + self.radius - 1)
          if x1 < 1 then
            x1 = 1
          end
          if y1 > self.row then
            y1 = self.row
          end
          if x2 > self.col then
            x2 = self.col
          end
          if y2 < 1 then
            y2 = 1
          end
          for i = y2, y1 do
            for j = x1, x2 do
              if self.map[i][j] == 1 then
                self.map[i][j] = 0
                self.map.part = self.map.part + 1
              end
            end
          end
        end
      end
    end
    if self.map.part / self.map.all >= self.desRate and self.rateCb then
      self.rateCb(dlg, ctrlName)
    end
    return curPos
  end
  self.canTouchFlag = true
  local function onTouchBegan(touch, event)
    if not self.canTouchFlag then
      return false
    end
    self.canTouchFlag = false
    local touchPos = touch:getLocation()
    lastPos = {}
    lastPos.x = touchPos.x
    lastPos.y = touchPos.y
    if "table" == type(eventCallback) and "function" == type(eventCallback.onTouchBegan) then
      eventCallback.onTouchBegan(dlg, touch)
    end
    return true
  end
  local function onTouchMove(touch, event)
    if lastMoveTime + 20 > gfGetTickCount() then
      return true
    end
    lastMoveTime = gfGetTickCount()
    lastPos = onErase(touch, event)
    if "table" == type(eventCallback) and "function" == type(eventCallback.onTouchMove) then
      eventCallback.onTouchMove(dlg, touch)
    end
    return true
  end
  local function onTouchEnd(touch, event)
    onErase(touch, event)
    lastPos = {}
    self.canTouchFlag = true
    if "table" == type(eventCallback) and "function" == type(eventCallback.onTouchEnd) then
      eventCallback.onTouchEnd(dlg, touch)
    end
  end
  local listener = cc.EventListenerTouchOneByOne:create()
  listener:setSwallowTouches(false)
  listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
  listener:registerScriptHandler(onTouchMove, cc.Handler.EVENT_TOUCH_MOVED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_ENDED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_CANCELLED)
  local dispatcher = panel:getEventDispatcher()
  dispatcher:addEventListenerWithSceneGraphPriority(listener, rText)
end
return ScratchPanel
