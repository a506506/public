local AddReducePanel = class("AddReducePanel")
function AddReducePanel:ctor(dlg, addBtnName, reduceBtnName, root, longClick, key, defNum, oneNum)
  self.dlg = dlg
  self.key = key
  self.num = defNum or 1
  self.oneNum = oneNum or 1
  self.addBtnName = addBtnName
  self.reduceBtnName = reduceBtnName
  self.hasLong = nil
  if longClick then
    dlg:bindPressForIntervalCallback(reduceBtnName, 0.1, function(dlg, ctrlName, times, sender, eventType)
      self:onSubOrAddNum(ctrlName, times, sender, eventType)
    end, "times", root)
    dlg:bindPressForIntervalCallback(addBtnName, 0.1, function(dlg, ctrlName, times, sender, eventType)
      self:onSubOrAddNum(ctrlName, times, sender, eventType)
    end, "times", root)
  else
    dlg:bindListener(addBtnName, function(dlg, sender, eventType)
      self:onAddButton(sender, eventType)
    end, root)
    dlg:bindListener(reduceBtnName, function(dlg, sender, eventType)
      self:onReduceButton(sender, eventType)
    end, root)
  end
  self:callBack("updateNum", self.num, key)
end
function AddReducePanel:setNum(num)
  self.num = num or 1
  self:callBack("updateNum", self.num, self.key)
end
function AddReducePanel:setClickBtnCallFunc(addLimitFunc, reduceLimitFunc)
  self.addLimitFunc = addLimitFunc
  self.reduceLimitFunc = reduceLimitFunc
end
function AddReducePanel:setClickLimitPara(minNum, maxNum, minTips, maxTips)
  self.minNum = minNum
  self.minTips = minTips
  self.maxNum = maxNum
  self.maxTips = maxTips
end
function AddReducePanel:bindNumInput(ctrlName, root, limitCallBack, key, isString, useBig, displayPosition)
  local panel = self.dlg:getControl(ctrlName, nil, root)
  local function openNumIuputDlg()
    if limitCallBack and "function" == type(limitCallBack) and limitCallBack(self.dlg) then
      return
    end
    local rect = self.dlg:getBoundingBoxInWorldSpace(panel)
    local dlg
    if useBig then
      dlg = DlgMgr:openDlg("NumInputExDlg")
    else
      dlg = DlgMgr:openDlg("SmallNumInputDlg")
    end
    dlg:setObj(self)
    dlg:setKey(key)
    dlg:setIsString(true == isString and true or false)
    dlg:updatePosition(rect, displayPosition)
    self:callBack("doWhenOpenNumInput", ctrlName, root)
  end
  self.dlg:bindListener(ctrlName, openNumIuputDlg, root)
  return openNumIuputDlg
end
function AddReducePanel:onSubOrAddNum(ctrlName, times, sender, eventType)
  if eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
    if self.hasLong then
      self.hasLong = nil
    elseif ctrlName == self.addBtnName then
      self:onAddButton(sender)
    elseif ctrlName == self.reduceBtnName then
      self:onReduceButton(sender)
    end
  else
    self.hasLong = true
    local falg = true
    if ctrlName == self.addBtnName then
      falg = self:onAddButton(sender)
    elseif ctrlName == self.reduceBtnName then
      falg = self:onReduceButton(sender)
    end
    if not falg then
      sender:stopAllActions()
    end
  end
end
function AddReducePanel:onAddButton(sender, eventType)
  if self.addLimitFunc then
    if not self.addLimitFunc(self.dlg, self.num + self.oneNum) then
      return false
    end
  elseif self.maxNum and self.num >= self.maxNum then
    if self.maxTips then
      gf:ShowSmallTips(self.maxTips)
    end
    return
  end
  self.num = math.min(self.maxNum, self.num + self.oneNum)
  self:callBack("updateNum", self.num, self.key)
  return true
end
function AddReducePanel:onReduceButton(sender, eventType)
  if self.reduceLimitFunc then
    if not self.reduceLimitFunc(self.dlg, self.num - self.oneNum) then
      return false
    end
  elseif self.minNum and self.num <= self.minNum then
    if self.minTips then
      gf:ShowSmallTips(self.minTips)
    end
    return
  end
  self.num = math.max(self.minNum, self.num - self.oneNum)
  self:callBack("updateNum", self.num, self.key)
  return true
end
function AddReducePanel:closeNumInputDlg()
  if self.minNum and self.num < self.minNum then
    if self.maxTips then
      gf:ShowSmallTips(self.minTips)
    end
    self.num = self.minNum
    self:callBack("updateNum", self.num, self.key)
  end
end
function AddReducePanel:insertNumber(num)
  if self.maxNum and num > self.maxNum then
    if self.maxTips then
      gf:ShowSmallTips(self.maxTips)
    end
    num = self.maxNum
  end
  self.num = num
  self:callBack("updateNum", self.num, self.key)
  DlgMgr:sendMsg("SmallNumInputDlg", "setInputValue", self.num)
end
function AddReducePanel:callBack(funcName, ...)
  if self.dlg == nil then
    return
  end
  local func = self.dlg[funcName]
  if func then
    return func(self.dlg, ...)
  end
end
return AddReducePanel
