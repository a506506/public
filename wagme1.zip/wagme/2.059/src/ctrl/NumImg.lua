local MINUS_KEY = 10
local PLUS_KEY = 11
local NOT_NUM = {
  ["*"] = 13,
  [","] = 12,
  ["/"] = 14,
  ["$"] = 15,
  ["-"] = 10,
  ["."] = 16,
  [":"] = 17,
  ["("] = 18,
  [")"] = 19,
  ["%"] = 20
}
local KEY_SUFFIX = ".png"
local NumImg = class("NumImg", function()
  return cc.Sprite:create()
end)
function NumImg:ctor(group, num, showSign, gap, signScale)
  if num == nil then
    return
  end
  self.gap = gap or 0
  self:setCascadeOpacityEnabled(true)
  self.showSign = false
  self.signScale = signScale or 1
  self:setGroup(group)
  if type(num) ~= "number" then
    self:setNumByString(num, showSign)
  else
    self:setNum(num, showSign)
  end
end
function NumImg:setGroup(group)
  if self.group and self.group == group then
    return
  end
  self.group = group
end
function NumImg:setNum(num, showSign)
  if not self.group then
    return
  end
  if showSign == nil then
    showSign = false
  end
  if self.num ~= nil and self.num == num and self.showSign == showSign then
    return
  end
  num = math.floor(num)
  self.num = num
  self.showSign = showSign
  self:removeAllChildren()
  local file = ResMgr:getNumImg(self.group)
  local prefix = file .. "/"
  gfAddFrames(file .. ".plist", prefix)
  local showPlus = showSign and num >= 0
  local showMinus = num < 0
  if showMinus then
    num = 0 - num
  end
  local key
  local keysArray = {}
  if num == 0 then
    key = self:getImageNmae(prefix, 0)
    table.insert(keysArray, key)
  end
  while num > 0 do
    key = self:getImageNmae(prefix, num % 10)
    num = math.floor(num / 10)
    table.insert(keysArray, key)
  end
  local w, h
  local totalW = 0
  local x = 0
  if showPlus then
    key = self:getImageNmae(prefix, PLUS_KEY)
    w, h = self:addFrame(key, x, true)
    x = x + w + self.gap
  elseif showMinus then
    key = self:getImageNmae(prefix, MINUS_KEY)
    w, h = self:addFrame(key, x, true)
    x = x + w + self.gap
  end
  for i = #keysArray, 1, -1 do
    w, h = self:addFrame(keysArray[i], x)
    x = x + w + self.gap
    if i > 1 then
      totalW = totalW + w + self.gap
    else
      totalW = totalW + w
    end
  end
  if totalW == 0 then
    return
  end
  self:setContentSize(totalW, h)
end
function NumImg:setNumByString(num, showSign)
  if not self.group then
    return
  end
  if showSign == nil then
    showSign = false
  end
  if self.num ~= nil and self.num == num and self.showSign == showSign then
    return
  end
  self.num = num
  self.showSign = showSign
  self:removeAllChildren()
  local file = ResMgr:getNumImg(self.group)
  local prefix = file .. "/"
  gfAddFrames(file .. ".plist", prefix)
  local key
  local keysArray = {}
  local index = 1
  local len = string.len(num)
  while index <= len do
    local char = string.sub(num, index, index)
    local num = tonumber(char)
    if num then
      key = self:getImageNmae(prefix, num)
    elseif NOT_NUM[char] then
      key = self:getImageNmae(prefix, NOT_NUM[char])
    else
      gf:ShowSmallTips(CHS[3002139])
      return
    end
    table.insert(keysArray, key)
    index = index + 1
  end
  local w, h
  local totalW = 0
  local x = 0
  for i = 1, #keysArray do
    w, h = self:addFrame(keysArray[i], x)
    x = x + w + self.gap
    if i > 1 then
      totalW = totalW + w + self.gap
    else
      totalW = totalW + w
    end
  end
  if totalW == 0 then
    return
  end
  self:setContentSize(totalW, h)
end
function NumImg:getImageNmae(prefix, num)
  return prefix .. num .. KEY_SUFFIX
end
function NumImg:startCountDown(callback, midCallBack)
  self.totalTime = self.num * 1000
  self.startTime = gf:getTickCount()
  self.pauseTime = 0
  self.isPause = false
  self:scheduleUpdateWithPriorityLua(function()
    if self.isPause then
      return
    end
    local t = gf:getTickCount()
    local num = math.ceil((self.totalTime - (t - self.startTime)) / 1000 + self.pauseTime / 1000)
    if num <= 0 then
      self:setNum(0, false)
      self:stopCountDown()
      callback(self)
    elseif num ~= self.num then
      self:setNum(num, false)
      if midCallBack then
        midCallBack(self)
      end
    end
  end, 0)
end
function NumImg:pauseCountDown()
  self.isPause = true
  self.pauseStartTime = gf:getTickCount()
end
function NumImg:continueCountDown()
  self.isPause = false
  self.pauseTime = self.pauseTime + gf:getTickCount() - self.pauseStartTime
end
function NumImg:stopCountDown()
  self:unscheduleUpdate()
end
function NumImg:setNumsColor(color)
  local childs = self:getChildren()
  for i = 1, #childs do
    if childs[i].setColor then
      childs[i]:setColor(color)
    end
  end
end
function NumImg:startMove(duration, pos)
  local action = cc.Spawn:create(cc.MoveTo:create(duration, pos), cc.FadeOut:create(duration))
  action = cc.Sequence:create(action, cc.RemoveSelf:create())
  self:runAction(action)
end
function NumImg:addFrame(key, x, isSigh)
  local frame = cc.SpriteFrameCache:getInstance():getSpriteFrame(key)
  local sp = cc.Sprite:createWithSpriteFrame(frame)
  if not sp then
    local sss
  end
  local sz = sp:getContentSize()
  if isSigh then
    sp:setAnchorPoint(0.5, 0.5)
    sp:setPosition(sz.width / 2, sz.height / 2)
    sp:setScale(self.sightScale)
  else
    sp:setAnchorPoint(0, 0)
    sp:setPosition(x, 0)
  end
  self:addChild(sp)
  return sz.width, sz.height
end
return NumImg
