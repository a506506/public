local Progress = class("Progress", function()
  return cc.Sprite:create()
end)
function Progress:ctor(bgImgFile, imgFile, topFile)
  local bg = cc.Sprite:create(bgImgFile)
  self:addChild(bg)
  local tc = cc.Director:getInstance():getTextureCache()
  tc:addImage(imgFile)
  self.progressBar = ccui.LoadingBar:create(imgFile, 100)
  self:addChild(self.progressBar)
  if topFile then
    self:addChild(cc.Sprite:create(topFile))
  end
end
function Progress:setPercent(percent)
  if self.progressBar then
    self.progressBar:setPercent(percent)
  end
end
function Progress:grayImageView()
  if self.progressBar then
    local ctrl = self.progressBar:getVirtualRenderer()
    if not ctrl then
      return
    end
    local childs = ctrl:getChildren()
    for i = 1, #childs do
      childs[i]:setGLProgramState(ShaderMgr:getGrayShader())
    end
    ctrl:setGLProgramState(ShaderMgr:getGrayShader())
  end
end
function Progress:resetImageView()
  if self.progressBar then
    local ctrl = self.progressBar:getVirtualRenderer()
    if not ctrl then
      return
    end
    local childs = ctrl:getChildren()
    for i = 1, #childs do
      childs[i]:setGLProgramState(ShaderMgr:getRawShader())
    end
    ctrl:setGLProgramState(ShaderMgr:getRawShader())
  end
end
return Progress
