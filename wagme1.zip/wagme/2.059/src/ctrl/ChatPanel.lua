local ChatPanel = class("ChatPanel", function()
  return ccui.Layout:create()
end)
local WORD_COLOR = cc.c3b(86, 41, 2)
local NumImg = require("ctrl/NumImg")
local TEXT_HEIGHT_MARGIN = 31
local TEXT_WIDTH_MARGIN = 31
local BUBBLE_HEIGHT_MIN = 82
local BUBBLE_WIDTH_MIN = 82
local BUBBLE_WIDTH_MIN_FOR_SPECIAL = 104
local CHAT_UP_OFFSET_HEIGHT = 15
local CHAT_DOWN_SHRINK_HEIGHT = 15
local SHOW_TIME_SPACE = 300
local CONST_DATA = {
  loadNumber = 10,
  initCanChatNumber = 15,
  initCannotChatNumber = 22,
  cellSpace = 8,
  containerTag = 999,
  CS_TYPE_STRING = 1,
  CS_TYPE_IMAGE = 2,
  CS_TYPE_BROW = 3,
  CS_TYPE_ANIMATE = 4,
  CS_TYPE_NPC = 5,
  CS_TYPE_ZOOM = 6,
  CS_TYPE_URL = 7,
  CS_TYPE_CARD = 8,
  CS_TYPE_CALL = 11
}
local CONST_WDAY = {
  [1] = CHS[4000160],
  [2] = CHS[6000055],
  [3] = CHS[6000056],
  [4] = CHS[6000057],
  [5] = CHS[6000058],
  [6] = CHS[6000059],
  [7] = CHS[6000060]
}
local curPlayRecord = {}
function ChatPanel:ctor(chatTabel, contentSize, iSCanChat, singleChatPanel, param)
  local keyName = string.format("ChatPanel_%s", tostring(self))
  DlgMgr:registPlistEx(keyName, "FriendChannelDlg.plist")
  local function onNodeEvent(event)
    if "destruct" == event then
      DlgMgr:unregistPlistEx(keyName, "FriendChannelDlg.plist")
    end
  end
  self:registerScriptHandler(onNodeEvent)
  self:setContentSize(contentSize)
  self.scroview = ccui.ScrollView:create()
  self.chatTabel = chatTabel
  self.lastChatNum = #chatTabel
  self.lastLoadIndex = 1
  self.lastUpLoadIndex = nil
  self.iSCanChat = iSCanChat
  self.singleChatPanel = singleChatPanel
  self:setParam(param)
  if self.iSCanChat then
    self.initNumber = CONST_DATA.initCanChatNumber
  else
    self.initNumber = CONST_DATA.initCannotChatNumber
  end
  self.needReset = nil
  local innerSizeheight = 0
  local container = ccui.Layout:create()
  self.loadCount = 0
  container:setPosition(0, 0)
  self.scroview:setContentSize(contentSize)
  self.scroview:setDirection(ccui.ScrollViewDir.vertical)
  self.scroview:addChild(container, 0, CONST_DATA.containerTag)
  self:loadInitData()
  local function scrollListener(sender, eventType)
    if eventType == ccui.ScrollviewEventType.scrollToBottom then
      self:loadMoreCell()
    elseif eventType == ccui.ScrollviewEventType.scrollToTop then
    elseif eventType == ccui.ScrollviewEventType.scrolling then
      local percent = self:getCurScrollPercent(self.scroview)
      Log:D("[ChatPanel] percent = %s, notCallScrollTop = %s", tostring(percent), tostring(self.notCallScrollTop))
      if not self.notCallScrollTop then
        if percent <= 1.0E-4 then
          if self.lastUpLoadIndex < #self.chatTabel then
            local nextIndex = math.min((self.lastUpLoadIndex or 0) + 1, #self.chatTabel)
            self:loadInitData(nextIndex)
            self.singleChatPanel.lastChatNum = nextIndex
            if "function" == type(self.singleChatPanel.refreshUnReadNote) then
              self.singleChatPanel:refreshUnReadNote(math.max(#self.chatTabel - nextIndex, 0))
            end
          else
            self.canRefreshByOther = true
          end
        else
          self.canRefreshByOther = false
        end
      end
    end
  end
  self.scroview:addEventListener(scrollListener)
  self:addChild(self.scroview)
  self.scroview:setPositionY(-2)
end
function ChatPanel:getCurScrollPercent(listView)
  if not listView then
    return 0
  end
  local listViewSize = listView:getContentSize()
  local isVertical = listView:getDirection() == ccui.ScrollViewDir.vertical
  if isVertical then
    local minY = listViewSize.height - listView:getInnerContainer():getContentSize().height
    local h = -1 * minY
    local curPosY = listView:getInnerContainer():getPositionY()
    if h == 0 then
      return 0
    end
    return (curPosY - minY) / h * 100
  else
    local minX = listViewSize.width - listView:getInnerContainer():getContentSize().width
    local h = -1 * minX
    local curPosX = listView:getInnerContainer():getPositionX()
    if h == 0 then
      return 0
    end
    return (curPosX - minX) / h * 100
  end
end
function ChatPanel:setParam(param)
  self.portraitScale = 1
  self.charFloatOffectX = 100
  if not param then
    return
  end
  if param.portraitScale then
    self.portraitScale = param.portraitScale
  end
  if param.charFloatOffectX then
    self.charFloatOffectX = param.charFloatOffectX
  end
end
function ChatPanel:canRefenshChat()
  return self.canRefreshByOther
end
function ChatPanel:resetView()
  self.needReset = true
  self:newMessage()
  self.needReset = nil
end
function ChatPanel:loadInitData(endIndex, notRefreshNewChat)
  local innerSizeheight = 0
  local container = self.scroview:getChildByTag(CONST_DATA.containerTag)
  if not endIndex then
    endIndex = #self.chatTabel
    self.canRefreshByOther = true
  else
    self.canRefreshByOther = false
  end
  local index = self.chatTabel[endIndex] and self.chatTabel[endIndex].index or 0
  if self.lastLoadData and (endIndex - #self.lastLoadData >= self.initNumber or index < self.lastLoadIndex) or self.needReset then
    container:removeAllChildren()
    self.lastPlayVoiceLayout = nil
    self.lastPalyVoiceCellTag = 0
  end
  self.lastLoadData = {}
  for i = 1, endIndex do
    table.insert(self.lastLoadData, self.chatTabel[i])
  end
  self.loadCount = 0
  local sartIndex = 0
  if endIndex - self.initNumber + 1 < 1 then
    sartIndex = 1
  else
    sartIndex = endIndex - self.initNumber + 1
  end
  local locationH
  local i = sartIndex
  local lastPosY = self.scroview:getInnerContainer():getPositionY()
  while endIndex >= i do
    local lastTime = 0
    local index = self.chatTabel[i].index
    if self.chatTabel[i - 1] then
      lastTime = self.chatTabel[i - 1].time
    end
    local cellPanel = container:getChildByTag(index)
    if cellPanel then
      if self.chatTabel[i].needFresh == true then
        local playTime = cellPanel.voiceLayout.playTime
        if cellPanel.voiceLayout == self.lastPlayVoiceLayout and playTime and playTime > 0 and playTime < self.chatTabel[i].voiceTime then
          if self.chatTabel[i].haveFilt then
            self.chatTabel[i].playTime = 0
            self:stopPlayVoice()
            SoundMgr:replayMusicAndSound()
          else
            self.chatTabel[i].playTime = playTime
          end
        end
        cellPanel:removeFromParent()
        local cellPanel = self:createOnechat(self.chatTabel[i], lastTime, index)
        cellPanel:setPosition(0, innerSizeheight)
        innerSizeheight = innerSizeheight + cellPanel:getContentSize().height + CONST_DATA.cellSpace
        container:addChild(cellPanel, 0, index)
        self.chatTabel[i].needFresh = false
        if self.lastPalyVoiceCellTag == index then
          self.lastPlayVoiceLayout = nil
          self.lastPalyVoiceCellTag = 0
        end
      else
        cellPanel:setPosition(0, innerSizeheight)
        innerSizeheight = innerSizeheight + cellPanel:getContentSize().height + CONST_DATA.cellSpace
      end
    elseif self.chatTabel[i].is_not_show_channel then
    else
      local cellPanel = self:createOnechat(self.chatTabel[i], lastTime, index)
      cellPanel:setPosition(0, innerSizeheight)
      innerSizeheight = innerSizeheight + cellPanel:getContentSize().height + CONST_DATA.cellSpace
      container:addChild(cellPanel, 0, index)
    end
    if i == endIndex and notRefreshNewChat and endIndex < #self.chatTabel and innerSizeheight < self.scroview:getContentSize().height + 5 then
      endIndex = endIndex + 1
      locationH = locationH or innerSizeheight
    end
    i = i + 1
  end
  local index = self.chatTabel[endIndex] and self.chatTabel[endIndex].index or 0
  if self.lastUpLoadIndex and index < self.lastUpLoadIndex then
    for j = self.lastUpLoadIndex, index + 1, -1 do
      local cellPanel = container:getChildByTag(j)
      if cellPanel then
        cellPanel:removeFromParent()
      end
      if self.lastPalyVoiceCellTag == j then
        self.lastPlayVoiceLayout = nil
        self.lastPalyVoiceCellTag = 0
      end
    end
  end
  local loadNum = endIndex - sartIndex
  for j = index - loadNum - 1, self.lastLoadIndex, -1 do
    local cellPanel = container:getChildByTag(j)
    if cellPanel then
      lastPosY = lastPosY + cellPanel:getContentSize().height + CONST_DATA.cellSpace
      cellPanel:removeFromParent()
    end
    if self.lastPalyVoiceCellTag == j then
      self.lastPlayVoiceLayout = nil
      self.lastPalyVoiceCellTag = 0
    end
  end
  if self.chatTabel[sartIndex] then
    self.lastLoadIndex = self.chatTabel[sartIndex].index
  end
  if index then
    self.lastUpLoadIndex = index
  end
  self.upLoadCount = 0
  self.lastUpLoadData = {}
  for i = endIndex + 1, #self.chatTabel do
    table.insert(self.lastUpLoadData, self.chatTabel[i])
  end
  container:setContentSize(self:getContentSize().width, innerSizeheight)
  if container:getContentSize().height < self.scroview:getContentSize().height then
    container:setPositionY(self.scroview:getContentSize().height - innerSizeheight)
  else
    container:setPositionY(0)
  end
  self.notCallScrollTop = true
  self.scroview:setInnerContainerSize(container:getContentSize())
  self.notCallScrollTop = false
  if not self.canRefreshByOther then
    self.scroview:getInnerContainer():setPositionY(lastPosY)
  else
    self.scroview:jumpToTop()
  end
  if notRefreshNewChat and container:getContentSize().height - self.scroview:getContentSize().height > 5 then
    if not locationH then
      self.scroview:getInnerContainer():setPositionY(-(container:getContentSize().height - self.scroview:getContentSize().height - 5))
    else
      self.scroview:getInnerContainer():setPositionY(0)
    end
  end
end
function ChatPanel:creatHeadFrame(cell, chatData)
  local itemInfo = InventoryMgr:getItemInfoByName(chatData.chat_head)
  if itemInfo and itemInfo.chat_icon then
    local framIcon = ccui.ImageView:create(itemInfo.chat_icon, itemInfo.chat_icon_res_type or 0)
    local size = cell:getContentSize()
    framIcon:setAnchorPoint(0.5, 0.5)
    framIcon:setPosition(size.width / 2, size.height / 2)
    framIcon:ignoreContentAdaptWithSize(false)
    framIcon:setContentSize(90, 90)
    cell:addChild(framIcon)
  end
end
function ChatPanel:getChatBubbleBack(chatData, isRedBag)
  local itemInfo = InventoryMgr:getItemInfoByName(chatData.chat_floor)
  local capRect = cc.rect(48, 40, 2, 2)
  if chatData.channel == CHAT_CHANNEL.HORN then
    local itemInfo = InventoryMgr:getItemInfoByName(chatData.horn_name)
    if itemInfo and itemInfo.chat_icon then
      return itemInfo.chat_icon, itemInfo.chat_icon_res_type or ccui.TextureResType.localType, capRect
    else
      return ResMgr.ui.chat_horn_back_groud, ccui.TextureResType.localType, capRect
    end
  elseif isRedBag then
    return ResMgr.ui.chat_red_bag_back_groud, ccui.TextureResType.localType, capRect
  elseif itemInfo and itemInfo.chat_icon then
    return itemInfo.chat_icon, itemInfo.chat_icon_res_type or ccui.TextureResType.localType, capRect
  else
    return ResMgr.ui.chat_def_back_groud, ccui.TextureResType.plistType, capRect
  end
end
function ChatPanel:createChatBubble(oneChatTable, isRedBag)
  local imgPath, resType, capRect = self:getChatBubbleBack(oneChatTable, isRedBag)
  local backSprite = ccui.ImageView:create(imgPath, resType)
  backSprite:setCapInsets(capRect)
  backSprite:ignoreContentAdaptWithSize(false)
  backSprite:setScale9Enabled(true)
  return backSprite
end
function ChatPanel:creatTimePanel(oneChatTable)
  local tiemLayout
  local tiemHeight = 0
  tiemLayout = ccui.Layout:create()
  tiemLayout:setAnchorPoint(0.5, 0)
  local lableText = CGAColorTextList:create()
  lableText:setFontSize(19)
  lableText:setString(self:getTiemStr(oneChatTable.time))
  lableText:setContentSize(self:getContentSize().width, 0)
  lableText:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
  lableText:updateNow()
  local timeW, tiemH = lableText:getRealSize()
  local timeColorLayer = tolua.cast(lableText, "cc.LayerColor")
  local tiemBackSprite = cc.Scale9Sprite:createWithSpriteFrameName(ResMgr.ui.chat_time_back_groud)
  tiemBackSprite:setLocalZOrder(-1)
  tiemBackSprite:setContentSize(timeW + 10, tiemBackSprite:getContentSize().height)
  tiemLayout:addChild(tiemBackSprite)
  local tiemSize = tiemBackSprite:getContentSize()
  tiemLayout:setContentSize(tiemSize)
  tiemBackSprite:setPosition(tiemSize.width / 2, tiemSize.height / 2)
  timeColorLayer:setPosition((tiemSize.width - timeW) / 2, (tiemSize.height + tiemH) / 2)
  tiemLayout:addChild(timeColorLayer)
  tiemLayout:setPosition(self:getContentSize().width / 2, 20)
  tiemHeight = tiemLayout:getContentSize().height + 30
  return tiemLayout, tiemHeight
end
function ChatPanel:createOnechat(oneChatTable, lastTime, i)
  local cellPanel
  if self.iSCanChat then
    if oneChatTable.c_suspect_warn then
      cellPanel = self.singleChatPanel:getControl("WarningLabelPanel"):clone()
      cellPanel:removeFromParent()
      cellPanel:setVisible(true)
      if type(oneChatTable.c_suspect_warn) == "string" then
        local widget = ccui.Helper:seekWidgetByName(cellPanel, "WarningLabel")
        widget:setString(oneChatTable.c_suspect_warn)
      end
    elseif ChatMgr:isRedBagMsg(oneChatTable.chatStr) then
      cellPanel = self:createRedBagCell(oneChatTable, lastTime, i)
    elseif oneChatTable.sysTipType then
      cellPanel = self:createSysTipCell(oneChatTable, lastTime, i)
    else
      cellPanel = self:createCanChatCell(oneChatTable, lastTime, i)
    end
  else
    cellPanel = self:createCanNotChatCell(oneChatTable)
  end
  if oneChatTable.is_suspect == 1 and oneChatTable.gid ~= Me:queryBasic("gid") then
    self.singleChatPanel:setWarningTip(true)
  end
  return cellPanel
end
function ChatPanel:createSysTipCell(oneChatTable, lastTime, i)
  local chatCellPanel = ccui.Layout:create()
  chatCellPanel:setPosition(0, 0)
  local chatLayout = ccui.Layout:create()
  chatLayout:setAnchorPoint(0.5, 0)
  chatCellPanel:addChild(chatLayout)
  local lableText = CGAColorTextList:create()
  lableText:setFontSize(19)
  lableText:setString(oneChatTable.chatStr, true)
  lableText:setContentSize(self:getContentSize().width, 0)
  lableText:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
  lableText:updateNow()
  local timeW, timeH = lableText:getRealSize()
  local colorLayer = tolua.cast(lableText, "cc.LayerColor")
  local backSprite = cc.Scale9Sprite:createWithSpriteFrameName(ResMgr.ui.chat_time_back_groud)
  backSprite:setLocalZOrder(-1)
  backSprite:setContentSize(timeW + 20, timeH + 10)
  chatLayout:addChild(backSprite)
  local chatSize = backSprite:getContentSize()
  chatLayout:setContentSize(chatSize)
  backSprite:setPosition(chatSize.width / 2, chatSize.height / 2)
  colorLayer:setPosition((chatSize.width - timeW) / 2, (chatSize.height + timeH) / 2)
  chatLayout:addChild(colorLayer)
  local tiemLayout
  local tiemHeight = 0
  if oneChatTable.time - lastTime > SHOW_TIME_SPACE then
    tiemLayout, tiemHeight = self:creatTimePanel(oneChatTable)
    chatCellPanel:addChild(tiemLayout)
  end
  local panelHeight = chatSize.height + tiemHeight
  chatCellPanel:setContentSize(self:getContentSize().width, panelHeight)
  chatLayout:setPosition(self:getContentSize().width / 2, tiemHeight)
  return chatCellPanel
end
function ChatPanel:createCanChatCell(oneChatTable, lastTime, i)
  if oneChatTable.gid == 0 and (not oneChatTable.icon or oneChatTable.icon == 0 or not oneChatTable.name or oneChatTable.name == "") then
    return self:createCanNotChatCell(oneChatTable)
  end
  local width = self:getContentSize().width
  local chatCellPanel = ccui.Layout:create()
  chatCellPanel:setPosition(0, 0)
  local iconImg = ccui.ImageView:create(ResMgr.ui.bag_item_bg_img, ccui.TextureResType.plistType)
  local function imgTouch(sender, eventType)
    if oneChatTable.gid == 0 then
      return
    end
    local canCall = false
    if self.singleChatPanel and (self.singleChatPanel.channelName == CHAT_CHANNEL.PARTY or self.singleChatPanel.channelName == CHAT_CHANNEL.CHAT_GROUP) then
      canCall = true
    end
    if ccui.TouchEventType.began == eventType then
      if canCall then
        sender.delayAction = performWithDelay(sender, function()
          if GuideMgr:isRunning() then
            return
          end
          sender.delayAction = nil
          if sender:isHighlighted() then
            local name = string.match(oneChatTable.name, "(.*) .*")
            name = name or oneChatTable.name
            self.singleChatPanel:addCallChar(self:getRealName(name, oneChatTable.ban_rule))
          end
        end, GameMgr:getLongPressTime())
      end
    elseif ccui.TouchEventType.ended == eventType then
      if sender.delayAction or not canCall then
        sender:stopAction(sender.delayAction)
        sender.delayAction = nil
        if FriendMgr:isNpcByGid(oneChatTable.gid) then
          return
        end
        if self.singleChatPanel.chatGid then
          if FriendMgr:isQmpkTeamGroup({
            group_id = self.singleChatPanel.chatGid
          }) then
            return
          end
        end
        FriendMgr:requestCharMenuInfo(oneChatTable.gid)
        ChatMgr:setTipData(oneChatTable)
        local name = string.match(oneChatTable.name, "(.*) .*")
        name = name or oneChatTable.name
        local char = {}
        char.gid = oneChatTable.gid
        char.name = name
        char.level = oneChatTable.level
        char.icon = oneChatTable.icon
        self:onCharInfo(char.gid, char)
      end
    elseif ccui.TouchEventType.canceled == eventType then
      sender:stopAction(sender.delayAction)
      sender.delayAction = nil
    end
  end
  iconImg:setTouchEnabled(true)
  iconImg:setScale(self.portraitScale)
  iconImg:setAnchorPoint(0, 1)
  chatCellPanel:addChild(iconImg)
  local imgPath = ResMgr:getSmallPortrait(tonumber(oneChatTable.npc_icon or oneChatTable.icon))
  local protriatIcon = ccui.ImageView:create(imgPath)
  protriatIcon:setAnchorPoint(0.5, 0.5)
  protriatIcon:setPosition(iconImg:getContentSize().width / 2, iconImg:getContentSize().height / 2)
  gf:setItemImageSize(protriatIcon)
  iconImg:addChild(protriatIcon)
  local channelSource = oneChatTable.channel_source
  if channelSource == CHANNEL_SOURCE.CHANNEL_SOURCE_APPLE_WATCH then
    local watchIcon = ccui.ImageView:create(ResMgr.ui.watch_image)
    watchIcon:setAnchorPoint(1, 0)
    watchIcon:setPosition(iconImg:getContentSize().width, 0)
    iconImg:addChild(watchIcon)
  end
  if FriendMgr:getKuafObjDist(oneChatTable.gid) then
    gf:addKuafLogo(iconImg)
  end
  self:creatHeadFrame(protriatIcon, oneChatTable)
  if oneChatTable.gid ~= 0 and not oneChatTable.npc_icon and oneChatTable.level and tonumber(oneChatTable.level) and 0 < tonumber(oneChatTable.level) then
    self:setNumImgForPanel(iconImg, ART_FONT_COLOR.NORMAL_TEXT, oneChatTable.level, false, LOCATE_POSITION.LEFT_TOP, 19)
  end
  local labelLayout
  local lableHeight = 0
  if not self:isMeMsg(oneChatTable) then
    local showName = self:getRealName(oneChatTable.npc_name or oneChatTable.name, oneChatTable.ban_rule)
    if oneChatTable.gid == 0 or oneChatTable.npc_name then
      showName = string.format("#i%s#i %s", ResMgr.ui.npc_word_chat, showName)
    end
    local patryJob = string.match(showName, " #B(.+)#n")
    if patryJob then
      showName = string.gsub(showName, " #B.+#n", "")
      local icon = ResMgr:getPartyJobWordImagePath(patryJob)
      if icon then
        showName = string.format("%s #i%s#i", showName, icon)
      end
    end
    labelLayout = ccui.Layout:create()
    labelLayout:setAnchorPoint(0, 1)
    chatCellPanel:addChild(labelLayout)
    local lableText = CGAColorTextList:create()
    lableText:setFontSize(21)
    lableText:setString(showName)
    lableText:setContentSize(self:getContentSize().width - iconImg:getContentSize().width, 0)
    lableText:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
    lableText:updateNow()
    local labelW, labelH = lableText:getRealSize()
    lableText:setPosition(0, labelH)
    labelLayout:addChild(tolua.cast(lableText, "cc.LayerColor"))
    lableHeight = labelH
    labelLayout:setContentSize(labelW, labelH)
    if oneChatTable.comeback_flag == 1 then
      local image = ccui.ImageView:create(ResMgr.ui.comeback_flag, ccui.TextureResType.plistType)
      image:setPosition(labelW + image:getContentSize().width * 0.5 + 3, image:getContentSize().height * 0.5)
      labelLayout:addChild(image)
    end
  end
  local chatLayout = ccui.Layout:create()
  chatCellPanel:addChild(chatLayout)
  local chatStr = oneChatTable.chatStr
  local articleId, articleTitle, comment
  if string.match(chatStr, "{\t.*\t}") then
    articleTitle, articleId, comment = string.match(chatStr, "{\t(.*)\027(.*)\027(.*)\t}")
    chatStr = ""
  end
  local textMaxWidth = self:getContentSize().width - iconImg:getContentSize().width - TEXT_WIDTH_MARGIN * 2
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(20)
  textCtrl:setString(chatStr, oneChatTable.show_extra)
  textCtrl:setContentSize(textMaxWidth, 0)
  textCtrl:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  local function ctrlTouch(sender, eventType)
    if ccui.TouchEventType.ended == eventType and textCtrl:getCsType() ~= CONST_DATA.CS_TYPE_ZOOM and textCtrl:getCsType() ~= CONST_DATA.CS_TYPE_NPC and textCtrl:getCsType() ~= CONST_DATA.CS_TYPE_CALL then
      gf:onCGAColorText(textCtrl, sender)
    end
  end
  local layer = tolua.cast(textCtrl, "cc.LayerColor")
  layer:setName("ChatContent")
  chatLayout:addChild(layer)
  chatLayout:setAnchorPoint(0, 1)
  chatLayout:setTouchEnabled(true)
  chatLayout:addTouchEventListener(ctrlTouch)
  local sqPanel = ccui.Layout:create()
  local sqSignImg, sqTitle, sendLabel
  sqPanel:setContentSize(cc.size(0, 0))
  if not string.isNilOrEmpty(articleId) and not string.isNilOrEmpty(articleTitle) then
    sqPanel:setAnchorPoint(0, 1)
    sqSignImg = ccui.ImageView:create("ui/Icon1630.png")
    sqSignImg:setAnchorPoint(0, 1)
    sqPanel:addChild(sqSignImg, 0, 996)
    sqTitle = CGAColorTextList:create()
    sqTitle:setFontSize(19)
    if gf:getTextLength(articleTitle) <= 40 then
      sqTitle:setString(articleTitle)
    else
      sqTitle:setString(gf:subString(articleTitle, 38) .. "...")
    end
    sqTitle:setContentSize(200, 0)
    sqTitle:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
    sqTitle:updateNow()
    sqPanel:addChild(tolua.cast(sqTitle, "cc.LayerColor"))
    local textW, textH = sqTitle:getRealSize()
    local lineImg = ccui.ImageView:create("Frame0020.png", ccui.TextureResType.plistType)
    lineImg:setAnchorPoint(0, 0.5)
    sqPanel:addChild(lineImg)
    sendLabel = ccui.Text:create()
    sendLabel:setAnchorPoint(0, 1)
    sendLabel:setString(CHS[2200081])
    sendLabel:setFontSize(15)
    sendLabel:setColor(cc.c3b(148, 122, 101))
    sqPanel:addChild(sendLabel)
    local function showMsg(sender, eventType)
      if ccui.TouchEventType.ended == eventType then
        if not articleId then
          return
        end
        CommunityMgr:openCommunityDlg(articleId)
      end
    end
    chatLayout:setTouchEnabled(true)
    chatLayout:addTouchEventListener(showMsg)
    sqPanel:setContentSize(cc.size(math.max(sqSignImg:getContentSize().width + 11 + 33 + 19 + textW, 210), 92))
    sqSignImg:setPosition(0, sqPanel:getContentSize().height - 19)
    sqTitle:setPosition(sqSignImg:getContentSize().width + 11, sqPanel:getContentSize().height - 23)
    lineImg:ignoreContentAdaptWithSize(false)
    lineImg:setContentSize(cc.size(sqPanel:getContentSize().width - TEXT_WIDTH_MARGIN * 2, 2))
    lineImg:setPosition(0, sqPanel:getContentSize().height - 19 - sqSignImg:getContentSize().height - 5)
    sendLabel:setPosition(0, sqPanel:getContentSize().height - 19 - sqSignImg:getContentSize().height - 10)
    chatLayout:addChild(sqPanel)
  end
  local voiceLayout = ccui.Layout:create()
  voiceLayout:setContentSize(0, 0)
  local vioceSignImg, vioceTimeLayout
  local voiceMoreWidth = 0
  if oneChatTable.token and 0 < string.len(oneChatTable.token) then
    voiceLayout:setAnchorPoint(0, 1)
    vioceSignImg = ccui.ImageView:create(ResMgr.ui.vioce_sign, ccui.TextureResType.plistType)
    vioceSignImg:setAnchorPoint(0, 1)
    voiceLayout:addChild(vioceSignImg, 0, 996)
    vioceTimeLayout = ccui.Layout:create()
    vioceTimeLayout:setAnchorPoint(0, 1)
    do
      local width = 46 + 12.714285714285714 * (tonumber(string.format("%d", oneChatTable.voiceTime)) - 1)
      local vioceTimeImg = cc.Scale9Sprite:createWithSpriteFrameName(ResMgr.ui.vioce_time_back)
      vioceTimeImg:setContentSize(width, vioceTimeImg:getContentSize().height)
      vioceTimeImg:setAnchorPoint(0, 0)
      vioceTimeLayout:addChild(vioceTimeImg)
      vioceTimeLayout:setContentSize(vioceTimeImg:getContentSize())
      voiceLayout:addChild(vioceTimeLayout)
      chatCellPanel.voiceLayout = voiceLayout
      voiceLayout.playTime = 0
      local function upadate()
        voiceLayout.playTime = voiceLayout.playTime + 0.1
        if voiceLayout.playTime > oneChatTable.voiceTime then
          vioceTimeLayout:stopAllActions()
          vioceSignImg:setVisible(true)
          local actionImg = voiceLayout:getChildByTag(997)
          if actionImg then
            actionImg:stopAllActions()
            actionImg:removeFromParent()
            ChatMgr:setIsPlayingVoice(false)
            SoundMgr:replayMusicAndSound()
          end
          voiceLayout.playTime = 0
          return
        end
      end
      local function doStopPlayRecord()
        if not curPlayRecord or #curPlayRecord <= 0 then
          return
        end
        if tostring(chatCellPanel) == curPlayRecord[1] and "function" == type(curPlayRecord[2]) then
          curPlayRecord[2]()
        end
        curPlayRecord = {}
      end
      local function palyVoice(sender, eventType)
        if ccui.TouchEventType.ended == eventType then
          local notPlay = false
          if oneChatTable.haveFilt then
            gf:ShowSmallTips(CHS[5410263])
            notPlay = true
          end
          if self.lastPalyVoiceCellTag == i and voiceLayout.playTime > 0 or notPlay then
            self:stopPlayVoice()
            vioceTimeLayout:stopAllActions()
            SoundMgr:replayMusicAndSound()
            voiceLayout.playTime = 0
            return
          end
          self:stopPlayVoice()
          vioceTimeLayout:stopAllActions()
          ChatMgr:stopPlayRecord()
          voiceLayout.playTime = 0.01
          ChatMgr:setIsPlayingVoice(true)
          ChatMgr:clearPlayVoiceList()
          schedule(vioceTimeLayout, upadate, 0.1)
          local actionImg = gf:createLoopMagic(ResMgr.magic.volume)
          actionImg:setPosition(vioceSignImg:getPosition())
          vioceSignImg:setVisible(false)
          voiceLayout:addChild(actionImg, 0, 997)
          if oneChatTable.gid == Me:queryBasic("gid") then
            actionImg:setFlippedX(true)
            actionImg:setAnchorPoint(1, 1)
          end
          ChatMgr:playRecord(oneChatTable.token, 0, oneChatTable.voiceTime, true, doStopPlayRecord)
          self.lastPlayVoiceLayout = voiceLayout
          self.lastPalyVoiceCellTag = i
        end
      end
      self:setStopPlayRecordCallback(chatCellPanel, function()
        self:stopPlayVoice()
        vioceTimeLayout:stopAllActions()
      end)
      chatLayout:setTouchEnabled(true)
      chatLayout:addTouchEventListener(palyVoice)
      local secondLabel = ccui.Text:create()
      secondLabel:setAnchorPoint(0.5, 0.5)
      secondLabel:setPosition(vioceTimeImg:getContentSize().width / 2, vioceTimeImg:getContentSize().height / 2)
      secondLabel:setString(string.format(CHS[3002134], oneChatTable.voiceTime))
      secondLabel:setFontSize(19)
      secondLabel:setColor(COLOR3.TEXT_DEFAULT)
      vioceTimeLayout:addChild(secondLabel)
      voiceLayout:setContentSize(textW, vioceSignImg:getContentSize().height + 8)
      vioceSignImg:setPosition(0, voiceLayout:getContentSize().height)
      vioceTimeLayout:setPosition(6 + vioceSignImg:getContentSize().width + vioceSignImg:getPositionX(), voiceLayout:getContentSize().height)
      chatLayout:addChild(voiceLayout)
      if textW < width + vioceSignImg:getContentSize().width + 6 then
        voiceMoreWidth = width + vioceSignImg:getContentSize().width + 6 - textW
      end
      if oneChatTable.playTime and 0 < oneChatTable.playTime then
        performWithDelay(vioceTimeLayout, function()
          voiceLayout.playTime = oneChatTable.playTime
          oneChatTable.playTime = 0
          schedule(vioceTimeLayout, upadate, 0.1)
          local actionImg = gf:createLoopMagic(ResMgr.magic.volume)
          actionImg:setPosition(vioceSignImg:getPosition())
          vioceSignImg:setVisible(false)
          voiceLayout:addChild(actionImg, 0, 997)
          if oneChatTable.gid == Me:queryBasic("gid") then
            actionImg:setFlippedX(true)
            actionImg:setAnchorPoint(1, 1)
          end
          self.lastPlayVoiceLayout = voiceLayout
          self.lastPalyVoiceCellTag = i
        end, 0)
      end
    end
  end
  local backSprite = self:createChatBubble(oneChatTable)
  local backSpriteW = math.max(BUBBLE_WIDTH_MIN, math.max(sqPanel:getContentSize().width, textW + voiceMoreWidth + TEXT_HEIGHT_MARGIN * 2))
  local backSpriteH = math.max(BUBBLE_HEIGHT_MIN, textH + sqPanel:getContentSize().height + voiceLayout:getContentSize().height + TEXT_HEIGHT_MARGIN * 2)
  local itemInfo = InventoryMgr:getItemInfoByName(oneChatTable.chat_floor)
  if oneChatTable.chat_floor == CHS[4200903] and itemInfo and itemInfo.chat_icon then
    backSpriteW = math.max(BUBBLE_WIDTH_MIN_FOR_SPECIAL, math.max(sqPanel:getContentSize().width, textW + voiceMoreWidth + TEXT_HEIGHT_MARGIN * 2))
  end
  if oneChatTable.chat_floor == CHS[4200904] then
    backSpriteW = math.max(BUBBLE_WIDTH_MIN_FOR_SPECIAL, math.max(sqPanel:getContentSize().width, textW + voiceMoreWidth + TEXT_HEIGHT_MARGIN * 2))
  end
  backSprite:setAnchorPoint(0, 0.5)
  backSprite:setLocalZOrder(-1)
  backSprite:setContentSize(backSpriteW, backSpriteH)
  chatLayout:setContentSize(backSpriteW, backSpriteH - CHAT_DOWN_SHRINK_HEIGHT)
  backSprite:setPosition(0, (chatLayout:getContentSize().height - CHAT_DOWN_SHRINK_HEIGHT) / 2)
  voiceLayout:setPosition(TEXT_WIDTH_MARGIN, chatLayout:getContentSize().height - TEXT_HEIGHT_MARGIN)
  sqPanel:setPosition(TEXT_WIDTH_MARGIN, backSpriteH - TEXT_HEIGHT_MARGIN)
  textCtrl:setPosition((chatLayout:getContentSize().width - textW) / 2, textH + (chatLayout:getContentSize().height - CHAT_DOWN_SHRINK_HEIGHT - textH) / 2 - voiceLayout:getContentSize().height / 2)
  chatLayout:addChild(backSprite)
  local tiemLayout
  local tiemHeight = 0
  if oneChatTable.time - lastTime > SHOW_TIME_SPACE then
    tiemLayout, tiemHeight = self:creatTimePanel(oneChatTable)
    chatCellPanel:addChild(tiemLayout)
  end
  local panelHeight = 0
  if iconImg:getContentSize().height > chatLayout:getContentSize().height + lableHeight - CHAT_UP_OFFSET_HEIGHT then
    panelHeight = iconImg:getContentSize().height
  else
    panelHeight = chatLayout:getContentSize().height + lableHeight - CHAT_UP_OFFSET_HEIGHT
  end
  panelHeight = panelHeight + tiemHeight
  chatCellPanel:setContentSize(self:getContentSize().width, panelHeight)
  if self:isMeMsg(oneChatTable) then
    iconImg:setPosition(self:getContentSize().width - iconImg:getContentSize().width, panelHeight)
    local posx, posy = iconImg:getPosition()
    chatLayout:setPosition(posx - chatLayout:getContentSize().width, posy + CHAT_UP_OFFSET_HEIGHT)
    if vioceSignImg then
      vioceSignImg:setFlippedX(true)
      vioceSignImg:setAnchorPoint(1, 1)
      vioceSignImg:setPositionX(textW + voiceMoreWidth)
      vioceTimeLayout:setAnchorPoint(1, 1)
      vioceTimeLayout:setPositionX(textW + voiceMoreWidth - vioceSignImg:getContentSize().width - 6)
    end
  else
    backSprite:setFlippedX(true)
    labelLayout:setPosition(iconImg:getContentSize().width + TEXT_HEIGHT_MARGIN / 2, panelHeight)
    iconImg:addTouchEventListener(imgTouch)
    iconImg:setPosition(0, panelHeight)
    chatLayout:setPosition(iconImg:getContentSize().width, panelHeight - lableHeight + CHAT_UP_OFFSET_HEIGHT)
  end
  if tiemLayout then
    tiemLayout:setPosition(self:getContentSize().width / 2, 20)
  end
  return chatCellPanel
end
function ChatPanel:isMeMsg(data)
  if data.gid == Me:queryBasic("gid") then
    return true
  end
  if data.gid and data.gid == 0 and data.id and data.id == BattleSimulatorMgr.NEWCOMBAT_ME_ID then
    return true
  end
  return false
end
function ChatPanel:updateRedbagStatus(oneChatTable)
  local container = self.scroview:getChildByTag(CONST_DATA.containerTag)
  if container then
    local childrens = container:getChildren()
    for i = 1, #childrens do
      if childrens[i]:getTag() == oneChatTable.index and childrens[i].redBagImage and childrens[i].statuslableText then
        childrens[i].redBagImage:loadTexture(ResMgr.ui.red_bag_open_image, ccui.TextureResType.localType)
        childrens[i].statuslableText:setString(CHS[5420489])
      end
    end
  end
end
function ChatPanel:createRedBagCell(oneChatTable, lastTime, i)
  local width = self:getContentSize().width
  local chatCellPanel = ccui.Layout:create()
  chatCellPanel:setPosition(0, 0)
  local iconImg = ccui.ImageView:create(ResMgr.ui.bag_item_bg_img, ccui.TextureResType.plistType)
  local function imgTouch(sender, eventType)
    local canCall = false
    if self.singleChatPanel and (self.singleChatPanel.channelName == CHAT_CHANNEL.PARTY or self.singleChatPanel.channelName == CHAT_CHANNEL.CHAT_GROUP) then
      canCall = true
    end
    if ccui.TouchEventType.began == eventType then
      if canCall then
        sender.delayAction = performWithDelay(sender, function()
          if GuideMgr:isRunning() then
            return
          end
          sender.delayAction = nil
          if sender:isHighlighted() then
            local name = string.match(self:getRealName(oneChatTable.name, oneChatTable.ban_rule), "#<(.*)#> .*")
            name = name or oneChatTable.name
            self.singleChatPanel:addCallChar(name)
          end
        end, GameMgr:getLongPressTime())
      end
    elseif ccui.TouchEventType.ended == eventType then
      if sender.delayAction or not canCall then
        sender:stopAction(sender.delayAction)
        sender.delayAction = nil
        FriendMgr:requestCharMenuInfo(oneChatTable.gid)
        local dlg = DlgMgr:openDlg("CharMenuContentDlg")
        if FriendMgr:getCharMenuInfoByGid(oneChatTable.gid) then
          dlg:setting(oneChatTable.gid)
        else
          local char = {}
          char.gid = oneChatTable.gid
          char.name = string.match(oneChatTable.name, "#<(.*)#> .*") or oneChatTable.name
          char.level = oneChatTable.level
          char.icon = oneChatTable.icon
          dlg:setInfo(char)
        end
        dlg.root:setPositionX(dlg.root:getPositionX() + self.charFloatOffectX)
      end
    elseif ccui.TouchEventType.canceled == eventType then
      sender:stopAction(sender.delayAction)
      sender.delayAction = nil
    end
  end
  iconImg:setTouchEnabled(true)
  iconImg:setScale(self.portraitScale)
  iconImg:setAnchorPoint(0, 1)
  chatCellPanel:addChild(iconImg)
  local imgPath = ResMgr:getSmallPortrait(oneChatTable.icon)
  local protriatIcon = ccui.ImageView:create(imgPath)
  protriatIcon:setAnchorPoint(0.5, 0.5)
  protriatIcon:setPosition(iconImg:getContentSize().width / 2, iconImg:getContentSize().height / 2)
  gf:setItemImageSize(protriatIcon)
  iconImg:addChild(protriatIcon)
  ChatPanel:creatHeadFrame(protriatIcon, oneChatTable)
  if oneChatTable.level then
    self:setNumImgForPanel(iconImg, ART_FONT_COLOR.NORMAL_TEXT, oneChatTable.level, false, LOCATE_POSITION.LEFT_TOP, 19)
  end
  local labelLayout
  local lableHeight = 0
  if oneChatTable.gid ~= Me:queryBasic("gid") then
    local showName = self:getRealName(oneChatTable.name, oneChatTable.ban_rule)
    local patryJob = string.match(showName, " #B(.+)#n")
    if patryJob then
      showName = string.gsub(showName, " #B.+#n", "")
      local icon = ResMgr:getPartyJobWordImagePath(patryJob)
      if icon then
        showName = string.format("%s #i%s#i", showName, icon)
      end
    end
    labelLayout = ccui.Layout:create()
    labelLayout:setAnchorPoint(0, 1)
    chatCellPanel:addChild(labelLayout)
    local lableText = CGAColorTextList:create()
    lableText:setFontSize(21)
    lableText:setString(showName)
    lableText:setContentSize(self:getContentSize().width - iconImg:getContentSize().width * 2, 0)
    lableText:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
    lableText:updateNow()
    local labelW, labelH = lableText:getRealSize()
    lableText:setPosition(0, labelH)
    labelLayout:addChild(tolua.cast(lableText, "cc.LayerColor"))
    lableHeight = labelH
    labelLayout:setContentSize(labelW, labelH)
  end
  local chatLayout = ccui.Layout:create()
  chatCellPanel:addChild(chatLayout)
  local contentLayout = ccui.Layout:create()
  contentLayout:setAnchorPoint(0, 1)
  local redBagImage
  if oneChatTable.redbagHasOpen then
    redBagImage = ccui.ImageView:create(ResMgr.ui.red_bag_open_image, ccui.TextureResType.localType)
  else
    redBagImage = ccui.ImageView:create(ResMgr.ui.red_bag_image, ccui.TextureResType.plistType)
  end
  redBagImage:setAnchorPoint(0, 0)
  contentLayout:addChild(redBagImage)
  chatCellPanel.redBagImage = redBagImage
  local redbag = ChatMgr:getRedbagIdByMsg(oneChatTable.chatStr)
  local text = gf:getTextByLenth(redbag.msg or "", 18)
  local textMaxWidth = self:getContentSize().width - iconImg:getContentSize().width - redBagImage:getContentSize().width - TEXT_WIDTH_MARGIN * 2
  local textCtrl = CGAColorTextList:create(true)
  textCtrl:setFontSize(19)
  textCtrl:setString(text, oneChatTable.show_extra)
  textCtrl:setContentSize(textMaxWidth, 0)
  textCtrl:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  local layer = tolua.cast(textCtrl, "cc.LayerColor")
  contentLayout:addChild(layer)
  local statuslableText = CGAColorTextList:create(true)
  statuslableText:setFontSize(19)
  statuslableText:setString(oneChatTable.redbagHasOpen and CHS[5420489] or CHS[2000199])
  statuslableText:setContentSize(textMaxWidth, 0)
  statuslableText:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
  statuslableText:updateNow()
  local labelW, labelH = statuslableText:getRealSize()
  statuslableText:setPosition(redBagImage:getContentSize().width + 10, labelH + 5)
  contentLayout:addChild(tolua.cast(statuslableText, "cc.LayerColor"))
  chatCellPanel.statuslableText = statuslableText
  local contentWidth = textMaxWidth + redBagImage:getContentSize().width + 10
  local contentHeight = redBagImage:getContentSize().height
  textCtrl:setPosition(redBagImage:getContentSize().width + 10, contentHeight - 1)
  contentLayout:setContentSize(contentWidth, contentHeight)
  local function openRedBag(sender, type)
    if ccui.TouchEventType.ended == type then
      PartyMgr:tryOpenRedBag(oneChatTable.chatStr)
    end
  end
  chatLayout:addChild(contentLayout)
  chatLayout:setAnchorPoint(0, 1)
  chatLayout:setTouchEnabled(true)
  chatLayout:addTouchEventListener(openRedBag)
  local backSprite = self:createChatBubble(oneChatTable, true)
  backSprite:setAnchorPoint(0, 0.5)
  backSprite:setLocalZOrder(-1)
  backSprite:setContentSize(contentWidth + TEXT_WIDTH_MARGIN * 2, contentHeight + TEXT_HEIGHT_MARGIN * 2)
  chatLayout:setContentSize(contentWidth + TEXT_WIDTH_MARGIN * 2, contentHeight + TEXT_HEIGHT_MARGIN * 2 - CHAT_DOWN_SHRINK_HEIGHT)
  backSprite:setPosition(0, (chatLayout:getContentSize().height - CHAT_DOWN_SHRINK_HEIGHT) / 2)
  contentLayout:setPosition((chatLayout:getContentSize().width - contentWidth) / 2, contentHeight + (chatLayout:getContentSize().height - CHAT_DOWN_SHRINK_HEIGHT - contentHeight) / 2)
  chatLayout:addChild(backSprite)
  local tiemLayout
  local tiemHeight = 0
  if oneChatTable.time - lastTime > SHOW_TIME_SPACE then
    tiemLayout, tiemHeight = self:creatTimePanel(oneChatTable)
    chatCellPanel:addChild(tiemLayout)
  end
  local panelHeight = 0
  if iconImg:getContentSize().height > chatLayout:getContentSize().height + lableHeight - CHAT_UP_OFFSET_HEIGHT then
    panelHeight = iconImg:getContentSize().height
  else
    panelHeight = chatLayout:getContentSize().height + lableHeight - CHAT_UP_OFFSET_HEIGHT
  end
  panelHeight = panelHeight + tiemHeight
  chatCellPanel:setContentSize(self:getContentSize().width, panelHeight)
  if oneChatTable.gid == Me:queryBasic("gid") then
    iconImg:setPosition(self:getContentSize().width - iconImg:getContentSize().width, panelHeight)
    local posx, posy = iconImg:getPosition()
    chatLayout:setPosition(posx - chatLayout:getContentSize().width, posy + CHAT_UP_OFFSET_HEIGHT)
  else
    backSprite:setFlippedX(true)
    labelLayout:setPosition(iconImg:getContentSize().width + TEXT_WIDTH_MARGIN / 2, panelHeight)
    iconImg:addTouchEventListener(imgTouch)
    iconImg:setPosition(0, panelHeight)
    chatLayout:setPosition(iconImg:getContentSize().width, panelHeight - lableHeight + CHAT_UP_OFFSET_HEIGHT)
  end
  if tiemLayout then
    tiemLayout:setPosition(self:getContentSize().width / 2, 20)
  end
  return chatCellPanel
end
function ChatPanel:createCanNotChatCell(oneChatTable)
  local chatLayout = ccui.Layout:create()
  chatLayout:setPosition(0, 0)
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(21)
  textCtrl:setString(self:getSystemTimeStr(oneChatTable.time) .. " " .. oneChatTable.chatStr, oneChatTable.show_extra)
  textCtrl:setContentSize(self:getContentSize().width, 0)
  textCtrl:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  textCtrl:setPosition(0, textH)
  local function ctrlTouch(sender, eventType)
    if ccui.TouchEventType.ended == eventType then
      gf:onCGAColorText(textCtrl, sender)
    end
  end
  local layer = tolua.cast(textCtrl, "cc.LayerColor")
  chatLayout:setContentSize(textW, textH)
  chatLayout:addChild(layer)
  chatLayout:setAnchorPoint(0, 0)
  chatLayout:setTouchEnabled(true)
  chatLayout:addTouchEventListener(ctrlTouch)
  return chatLayout
end
function ChatPanel:createOnechatCell(oneChatTable)
  local chatLayout = ccui.Layout:create()
  chatLayout:setPosition(0, 0)
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(21)
  textCtrl:setString(oneChatTable.chatStr, oneChatTable.show_extra)
  textCtrl:setContentSize(self:getContentSize().width, 0)
  textCtrl:setDefaultColor(WORD_COLOR.r, WORD_COLOR.g, WORD_COLOR.b)
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  textCtrl:setPosition(0, textH)
  local layer = tolua.cast(textCtrl, "cc.LayerColor")
  chatLayout:setContentSize(textW, textH)
  chatLayout:addChild(layer)
  chatLayout:setAnchorPoint(0, 0)
  chatLayout:setTouchEnabled(true)
  local function ctrlTouch(sender, eventType)
    if ccui.TouchEventType.ended == eventType then
      gf:onCGAColorText(textCtrl, sender)
    end
  end
  chatLayout:addTouchEventListener(ctrlTouch)
  return chatLayout
end
function ChatPanel:loadMoreCell()
  if (#self.lastLoadData - self.initNumber) / CONST_DATA.loadNumber < self.loadCount then
    return
  end
  local container = self.scroview:getChildByTag(CONST_DATA.containerTag)
  local innerSizeheight = 0
  local leftChatNum = #self.lastLoadData - self.initNumber - CONST_DATA.loadNumber * self.loadCount
  local endIndex = leftChatNum
  local starIndex = 1
  if leftChatNum > CONST_DATA.loadNumber then
    starIndex = leftChatNum - CONST_DATA.loadNumber + 1
  end
  for i = starIndex, endIndex do
    local lastTime = 0
    if self.lastLoadData[i - 1] then
      lastTime = self.lastLoadData[i - 1].time
    end
    local index = self.lastLoadData[i].index
    local cellPanel = self:createOnechat(self.lastLoadData[i], lastTime, index)
    cellPanel:setPosition(0, innerSizeheight)
    innerSizeheight = innerSizeheight + cellPanel:getContentSize().height + CONST_DATA.cellSpace
    container:addChild(cellPanel, 0, index)
  end
  self.lastLoadIndex = self.lastLoadData[starIndex].index
  self.loadCount = self.loadCount + 1
  for i = #self.lastLoadData, endIndex + 1, -1 do
    if self.lastLoadData[i] then
      local index = self.lastLoadData[i].index
      local cell = container:getChildByTag(index)
      if cell then
        local posx, posy = cell:getPosition()
        cell:setPosition(posx, posy + innerSizeheight)
      end
    end
  end
  for i = 1, #self.lastUpLoadData do
    if self.lastUpLoadData[i] then
      local index = self.lastUpLoadData[i].index
      local cell = container:getChildByTag(index)
      if cell then
        local posx, posy = cell:getPosition()
        cell:setPosition(posx, posy + innerSizeheight)
      end
      if index >= self.lastUpLoadIndex then
        break
      end
    end
  end
  container:setContentSize(self:getContentSize().width, container:getContentSize().height + innerSizeheight)
  self.scroview:setInnerContainerSize(container:getContentSize())
  if container:getContentSize().height < self.scroview:getContentSize().height then
    container:setPositionY(self.scroview:getContentSize().height - container:getContentSize().height)
  else
    container:setPositionY(0)
  end
end
function ChatPanel:upLoadMoreCell()
  if #self.lastUpLoadData <= self.upLoadCount then
    self.canRefreshByOther = true
    return
  end
  local container = self.scroview:getChildByTag(CONST_DATA.containerTag)
  local innerSizeheight = 0
  local allCou = #self.lastUpLoadData
  local hasLoadCou = self.upLoadCount
  local leftChatNum = allCou - hasLoadCou
  local endIndex = allCou
  local starIndex = hasLoadCou + 1
  if leftChatNum > CONST_DATA.loadNumber then
    endIndex = hasLoadCou + CONST_DATA.loadNumber
    self.upLoadCount = self.upLoadCount + CONST_DATA.loadNumber
  else
    self.upLoadCount = self.upLoadCount + leftChatNum
  end
  local containerSize = container:getContentSize()
  innerSizeheight = innerSizeheight + containerSize.height
  for i = starIndex, endIndex do
    local lastTime = 0
    if self.lastUpLoadData[i - 1] then
      lastTime = self.lastUpLoadData[i - 1].time
    elseif i == 1 then
      lastTime = next(self.lastLoadData) and (self.lastLoadData[#self.lastLoadData].time or 0)
    end
    innerSizeheight = innerSizeheight + CONST_DATA.cellSpace
    local index = self.lastUpLoadData[i].index
    local cellPanel = self:createOnechat(self.lastUpLoadData[i], lastTime, index)
    cellPanel:setPosition(0, innerSizeheight)
    innerSizeheight = innerSizeheight + cellPanel:getContentSize().height
    container:addChild(cellPanel, 0, index)
  end
  self.lastUpLoadIndex = self.lastUpLoadData[endIndex].index
  self.notCallScrollTop = true
  local posY = self.scroview:getInnerContainer():getPositionY()
  container:setContentSize(self:getContentSize().width, innerSizeheight)
  self.scroview:setInnerContainerSize(container:getContentSize())
  self.scroview:getInnerContainer():setPositionY(posY)
  self.notCallScrollTop = false
  if container:getContentSize().height < self.scroview:getContentSize().height then
    container:setPositionY(self.scroview:getContentSize().height - container:getContentSize().height)
  else
    container:setPositionY(0)
  end
end
function ChatPanel:getTotalIndex(dataTable)
  if dataTable[#dataTable] then
    return dataTable[#dataTable].index or 0
  else
    return 0
  end
end
function ChatPanel:newMessage()
  self:loadInitData()
  self.scroview:scrollToTop(0.01, false)
end
function ChatPanel:createChatTimeCell()
  local labelLayout = ccui.Layout:create()
  labelLayout:setAnchorPoint(0, 1)
  local lableText = CGAColorTextList:create()
  lableText:setFontSize(21)
  lableText:setString(oneChatTable.name)
  lableText:setContentSize(self:getContentSize().width, 0)
  lableText:updateNow()
  local labelW, labelH = lableText:getRealSize()
  lableText:setPosition(0, labelH)
  labelLayout:addChild(tolua.cast(lableText, "cc.LayerColor"))
  labelLayout:setContentSize(labelW, labelH)
end
function ChatPanel:getTiemStr(time)
  local timeStr = ""
  local timeTabel = gf:getServerDate("*t", time)
  local curtime = gf:getServerTime()
  local difDay = math.floor((curtime + 28800) / 86400) - math.floor((time + 28800) / 86400)
  if difDay == 0 then
    timeStr = string.format("%02d:%02d", timeTabel.hour, timeTabel.min)
  elseif difDay == 1 then
    timeStr = string.format("%s  %02d:%02d", CHS[6000134], timeTabel.hour, timeTabel.min)
  elseif difDay <= 7 and difDay > 1 then
    timeStr = string.format("%s%s  %02d:%02d", CHS[6000135], CONST_WDAY[timeTabel.wday], timeTabel.hour, timeTabel.min)
  elseif difDay > 7 then
    timeStr = string.format("%d-%02d-%02d  %02d:%02d", timeTabel.year, timeTabel.month, timeTabel.day, timeTabel.hour, timeTabel.min)
  end
  return timeStr
end
function ChatPanel:getSystemTimeStr(time)
  local tiemStr = ""
  local timeTabel = gf:getServerDate("*t", time)
  tiemStr = string.format("%02d:%02d:%02d", timeTabel.hour, timeTabel.min, timeTabel.sec)
  return tiemStr
end
function ChatPanel:stopPlayVoice()
  SoundMgr:stopMusicAndSound()
  ChatMgr:setIsPlayingVoice(false)
  if self.lastPlayVoiceLayout == nil then
    return
  end
  local actionImg = self.lastPlayVoiceLayout:getChildByTag(997)
  local vioceSignImg = self.lastPlayVoiceLayout:getChildByTag(996)
  if actionImg and vioceSignImg then
    actionImg:stopAllActions()
    actionImg:removeFromParent()
    vioceSignImg:setVisible(true)
    ChatMgr:stopPlayRecord()
  end
  self.lastPlayVoiceLayout = nil
  self.lastPalyVoiceCellTag = 0
end
function ChatPanel:getBoundingBoxInWorldSpace(node)
  if not node then
    return
  end
  local rect = node:getBoundingBox()
  local pt = node:convertToWorldSpace(cc.p(0, 0))
  rect.x = pt.x
  rect.y = pt.y
  rect.width = rect.width * Const.UI_SCALE
  rect.height = rect.height * Const.UI_SCALE
  return rect
end
function ChatPanel:setNumImgForPanel(panelNameOrPanel, imgName, amount, showSign, locate, fontSize, root)
  local panel = panelNameOrPanel
  if type(panelNameOrPanel) == "string" then
    root = root or self.root
    panel = self:getControl(panelNameOrPanel, nil, root)
  end
  if nil == panel then
    return
  end
  local tag = locate * 999
  local numImg = panel:getChildByTag(tag)
  if numImg then
    numImg:removeFromParent()
  end
  numImg = NumImg.new(imgName, amount, showSign, -1)
  numImg:setTag(tag)
  panel:addChild(numImg)
  local panelSize = panel:getContentSize()
  if locate == LOCATE_POSITION.RIGHT_BOTTOM then
    numImg:setAnchorPoint(1, 0)
    numImg:setPosition(panelSize.width - 5, 5)
  elseif locate == LOCATE_POSITION.LEFT_BOTTOM then
    numImg:setAnchorPoint(0, 0)
    numImg:setPosition(5, 5)
  elseif locate == LOCATE_POSITION.RIGHT_TOP then
    numImg:setAnchorPoint(1, 1)
    numImg:setPosition(panelSize.width - 5, panelSize.height - 5)
  elseif locate == LOCATE_POSITION.LEFT_TOP then
    numImg:setAnchorPoint(0, 1)
    numImg:setPosition(5, panelSize.height - 5)
  elseif locate == LOCATE_POSITION.CENTER then
    numImg:setAnchorPoint(0, 0.5)
    numImg:setPosition(0, panelSize.height / 2)
  elseif locate == LOCATE_POSITION.MID then
    numImg:setAnchorPoint(0.5, 0.5)
    numImg:setPosition(panelSize.width / 2, panelSize.height / 2)
  elseif locate == LOCATE_POSITION.MID_TOP then
    numImg:setAnchorPoint(0.5, 0.5)
    numImg:setPosition(panelSize.width / 2, panelSize.height - 5)
  elseif locate == LOCATE_POSITION.MID_BOTTOM then
    numImg:setAnchorPoint(0.5, 0.5)
    numImg:setPosition(panelSize.width / 2, 5)
  else
    Log:W("Location not expected!")
    return
  end
  if fontSize == 25 then
    numImg:setScale(1, 1)
  elseif fontSize == 23 then
    numImg:setScale(0.9333333333333333, 0.9090909090909091)
  elseif fontSize == 21 then
    numImg:setScale(0.8666666666666667, 0.8181818181818182)
  elseif fontSize == 19 then
    numImg:setScale(0.8, 0.7272727272727273)
  elseif fontSize == 17 then
    numImg:setScale(0.7333333333333333, 0.6363636363636364)
  elseif fontSize == 15 then
    numImg:setScale(0.6666666666666666, 0.5454545454545454)
  elseif fontSize == 12.5 then
    numImg:setScale(0.5, 0.5)
  else
    Log:W("Font Size not expected!")
    return
  end
  return numImg
end
function ChatPanel:scroviewllIsIntop()
  local container = self.scroview:getChildByTag(CONST_DATA.containerTag)
  local y = self.scroview:getInnerContainer():getPositionY()
  local offset = self.scroview:getContentSize().height - container:getContentSize().height
  if y == offset or offset > 0 then
    return true
  end
  return false
end
function ChatPanel:clear()
  self.lastLoadData = nil
  FriendMgr:unrequestCharMenuInfo(self.name)
end
function ChatPanel:setStopPlayRecordCallback(ctl, callback)
  curPlayRecord = {
    tostring(ctl),
    callback
  }
  local function onNodeEvent(event)
    if "cleanup" == event and #curPlayRecord > 0 and curPlayRecord[1] == tostring(ctl) then
      curPlayRecord = {}
    end
  end
  ctl:registerScriptHandler(onNodeEvent)
end
function ChatPanel:onCharInfo(gid, char)
  local dlg = DlgMgr:openDlg("CharMenuContentDlg")
  local distName = FriendMgr:getKuafObjDist(gid)
  if FriendMgr:isKuafDist(distName) then
    dlg:setMuneType(CHAR_MUNE_TYPE.KUAFU_BLOG)
  end
  if dlg then
    char.dist_name = distName
    if FriendMgr:getCharMenuInfoByGid(gid) then
      dlg:setting(gid)
    elseif char then
      dlg:setInfo(char)
    end
    dlg.root:setPositionX(dlg.root:getPositionX() + self.charFloatOffectX)
  end
end
function ChatPanel:getRealName(name, banRule)
  return gf:getShowName(gf:getRealName(name, true), banRule or "")
end
return ChatPanel
