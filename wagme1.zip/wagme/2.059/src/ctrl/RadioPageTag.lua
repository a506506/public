local RadioGroup = require("ctrl/RadioGroup")
local RadioPageTag = class("RadioPageTag")
function RadioPageTag:ctor(dlg, radioNames)
  self.group = RadioGroup.new()
  self.group:setItems(dlg, radioNames)
  local radios = self.group.radios
  for i = 1, #radios do
    radios[i]:setTouchEnabled(false)
  end
end
function RadioPageTag:setPage(page)
  self.page = page
  self.group:selectRadio(page)
end
function RadioPageTag:getPage()
  return self.page
end
return RadioPageTag
