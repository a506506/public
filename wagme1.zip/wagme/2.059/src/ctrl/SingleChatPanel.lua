local WORD_COLOR = cc.c3b(86, 41, 2)
local ChatPanel = require("ctrl/ChatPanel")
local SPACE = 10
local SingleChatPanel = class("SingleChatPanel", function()
  return ccui.Layout:create()
end)
function SingleChatPanel:ctor(data, iSCanChat, contantSize, channel, gid)
  local jsonName = ResMgr:getDlgCfg("SingleChatDlg")
  self.root = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonName)
  self:addChild(self.root)
  self:setAnchorPoint(0, 0)
  self.root:setContentSize(contantSize)
  self.root:setAnchorPoint(0, 0)
  self.root:setPosition(0, 0)
  self:setContentSize(contantSize)
  self.channelName = channel
  self.chatGid = gid
  self:init(data, iSCanChat, channel)
end
function SingleChatPanel:init(data, iSCanChat, channel)
  self.inputPanel = self:setInputPanel(channel)
  self:bindListener("DelButton", self.onDelButton, self.inputPanel)
  self:bindListener("ExpressionButton", self.onExpressionButton, self.inputPanel)
  self:bindListener("InputBKImage", self.onInputBKImage, self.inputPanel)
  self:bindListener("MenuButton", self.onMenuButton, self.inputPanel)
  self:bindListener("MenuButton1", self.onMenuButton1, "HornMenuPanel")
  self:bindListener("MenuButton2", self.onMenuButton2, "HornMenuPanel")
  self:bindListener("MenuButton3", self.onMenuButton3, "HornMenuPanel")
  self:bindListener("UnReadNotePanel", self.onUnReadNotePanel)
  self:bindListener("CallPromptPanel", self.onCallPromptPanel)
  self:bindListener("CloseImage", self.onCloseCallPrompt, "CallPromptPanel")
  self:bindListener("TouchPanel", self.onReportUser, "WarningFramePanel")
  self:setCtrlVisible("WarningLabelPanel", false)
  self:setWarningTip(false)
  local speakBtn = self:getControl("VoiceButton", nil, self.inputPanel)
  ChatMgr:blindSpeakBtn(speakBtn, self)
  self.textField = self:getControl("InputTextField", Const.UITextField)
  self.textField:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
  self.panel = self:getControl("ChatPanel", Const.UIPanel)
  local list = self:getControl("MessageListView")
  self.chatTable = data
  self.lastChatNum = #data
  self.panel:setContentSize(self:getContentSize())
  local size = cc.size(list:getContentSize().width, self:getContentSize().height - self.inputPanel:getContentSize().height - SPACE - 3)
  local backImg = self:getControl("MessageBKImage")
  list:setContentSize(size)
  if iSCanChat then
    self.chatPanel = ChatPanel.new(self.chatTable, size, iSCanChat, self)
    list:addChild(self.chatPanel)
    self.deleteBtn = self:getControl("DelButton", Const.UIButton, self.inputPanel)
    self:setDelVisible(false)
    self.editBox = self:createEditBox("InputTextPanel", self.inputPanel, cc.KEYBOARD_RETURNTYPE_SEND, self.editBoxListner)
    self.editBox:setFontColor(COLOR3.TEXT_DEFAULT)
    self.editBox:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
    self.editBox:setMaxLength(150)
    backImg:setContentSize(backImg:getContentSize().width, size.height + SPACE + 3)
  else
    self.chatPanel = ChatPanel.new(self.chatTable, size, iSCanChat, self)
    list:addChild(self.chatPanel)
    self.chatPanel:setPosition(0, 0)
    backImg:setContentSize(backImg:getContentSize().width, size.height + SPACE + 3)
    self.inputPanel:removeFromParentAndCleanup(true)
  end
  local function textFieldListener(sender, type)
    if type == ccui.TextFiledEventType.attach_with_ime then
      local len = string.len(self.textField:getStringValue())
    elseif type == ccui.TextFiledEventType.detach_with_ime then
    elseif type == ccui.TextFiledEventType.insert_text then
      local text = self.textField:getStringValue()
      local len = string.len(text)
      if len > self:getWorldLimit() then
        local newtext = string.sub(text, 0, self:getWorldLimit())
        local text = self.textField:getInsertText()
        self:setInputText("InputTextField", newtext)
        gf:ShowSmallTips(CHS[6000133])
      end
      if len > 0 then
        self:setDelVisible(true)
      end
    end
  end
  self.textField:addEventListener(textFieldListener)
  self.textField:setFocused(true)
  self.textField:setColor(WORD_COLOR)
  local function keyBoardListner(keycode, envent)
    if keycode == cc.KEYBOARD_RETURNTYPE_GO then
    elseif keycode == cc.KeyCode.KEY_KP_ENTER or keycode == cc.KeyCode.KEY_RETURN then
      self:sendMessage()
    end
  end
  local listener = cc.EventListenerKeyboard:create()
  listener:registerScriptHandler(keyBoardListner, cc.Handler.EVENT_KEYBOARD_PRESSED)
  local dispatcher = self.textField:getEventDispatcher()
  self.unReadNotePanel = self:getControl("UnReadNotePanel", Const.UILabel)
  self.unReadNotePanel:setVisible(false)
  self.unReadNoteLabel = self:getControl("UnReadNoteLabel", Const.UILabel)
  self:bindListener("RedBagPanel", self.onRedBagPanel)
  self:bindListener("CloseRedBagButton", self.onCloseRedBagButton)
  self.redBagPanel = self:getControl("RedBagPanel")
  self.closeRedBagButton = self:getControl("CloseRedBagButton")
  self.redBagPanel:setVisible(false)
  self.closeRedBagButton:setVisible(false)
  self.callPromptPanel = self:getControl("CallPromptPanel")
  self.callPromptPanel:setVisible(false)
  self.hasOneCallMe = false
  self:setCtrlVisible("HornMenuPanel", false)
  self:setDecorateBtnVisible(ChatDecorateMgr:isEntrenceOpend())
  local function refresh()
    self:refreshChatPanel()
  end
  schedule(self, refresh, 0.1)
end
function SingleChatPanel:setWarningTip(visible)
  self:setCtrlVisible("WarningFramePanel", visible)
end
function SingleChatPanel:setInputPanel(channel)
  local input
  if channel == CHAT_CHANNEL.WORLD then
    self:setCtrlVisible("InputPanel", false)
    input = self:getControl("WorldInputPanel", Const.UIPanel)
    input:setVisible(true)
    self:bindMenuPanel()
  else
    self:setCtrlVisible("WorldInputPanel", false)
    input = self:getControl("InputPanel", Const.UIPanel)
    input:setVisible(true)
  end
  return input
end
function SingleChatPanel:getInputStr()
  return self.editBox:getText()
end
function SingleChatPanel:setInputStr(text)
  self.editBox:setText(text)
end
function SingleChatPanel:getWorldLimit()
  return 60
end
function SingleChatPanel:setDelVisible(visible)
  self.deleteBtn:setVisible(visible)
end
function SingleChatPanel:bindMenuPanel()
  local panel = self:getControl("HornMenuPanel")
  local function onTouchBegan(touch, event)
    self:setCtrlVisible("HornMenuPanel", false)
    return false
  end
  gf:bindTouchListener(panel, onTouchBegan, nil, true)
end
function SingleChatPanel:setRedBagHasOpen(gid)
  local redbag = ChatMgr:getRedbagIdByMsg(msg)
  for i = #self.chatTable, 1, -1 do
    if string.match(self.chatTable[i].chatStr, gid) then
      if self.chatTable[i].chatStr and not self.chatTable[i].redbagHasOpen then
        self.chatTable[i].redbagHasOpen = true
        self.chatPanel:updateRedbagStatus(self.chatTable[i])
      end
      break
    end
  end
end
function SingleChatPanel:setOpenRedBag()
  local panel = self:getControl("RedBagPanel")
  self:onRedBagPanel(panel)
end
function SingleChatPanel:onRedBagPanel(sender, eventType)
  sender:setVisible(false)
  self.closeRedBagButton:setVisible(false)
  local num = self:findRedBaglastNum()
  if num > 0 then
    self.lastChatNum = self:getTotalIndex()
    self.chatPanel:loadInitData(num, true)
    PartyMgr:tryOpenRedBag(self.chatTable[num].chatStr)
  else
    gf:ShowSmallTips(CHS[5410031])
  end
  ChatMgr.hasRedBag = false
end
function SingleChatPanel:onCloseRedBagButton(sender, eventType)
  self.redBagPanel:setVisible(false)
  self.closeRedBagButton:setVisible(false)
  ChatMgr.hasRedBag = false
end
function SingleChatPanel:onCloseCallPrompt(sender, eventType)
  self.callPromptPanel:setVisible(false)
  self.chatTable[#self.chatTable].perCallMeHasLose = true
end
function SingleChatPanel:onReportUser(sender, eventType)
  local ob = FriendMgr:getFriendByGid(self.chatGid) or FriendMgr:getTemFriendByGid(self.chatGid)
  if not ob then
    return
  end
  local char = {
    name = ob:queryBasic("char"),
    dist_name = ob:queryBasic("dist_name"),
    icon = ob:queryBasicInt("icon"),
    level = ob:queryBasicInt("level")
  }
  local function doIt()
    if Me:queryInt("level") < 35 then
      gf:ShowSmallTips(CHS[4300312])
      return
    end
    ChatMgr:questOpenReportDlg(self.chatGid, char.name, char.dist_name)
    return
  end
  if ChatMgr.hasTipOffUser[self.chatGid] and ChatMgr.hasTipOffUser[self.chatGid] == 1 then
    if not FriendMgr:isBlackByGId(self.chatGid) then
      gf:confirm(string.format(CHS[4300318], char.name), function()
        FriendMgr:addBlack(char.name, char.icon, char.level, self.chatGid)
      end, function()
        doIt()
      end)
      return
    else
      doIt()
    end
  else
    doIt()
  end
end
function SingleChatPanel:findCallMeMsglastNum()
  local num = 0
  for i = #self.chatTable, 1, -1 do
    if self.chatTable[i].perCallMeHasLose then
      break
    end
    if self.chatTable[i].hasOneCallMe then
      num = i
      self.chatTable[i].hasOneCallMe = nil
    end
  end
  return num
end
function SingleChatPanel:onCallPromptPanel(sender, eventType)
  self.callPromptPanel:setVisible(false)
  self.hasOneCallMe = false
  local num = self:findCallMeMsglastNum()
  if num > 0 then
    self.lastChatNum = self:getTotalIndex()
    self.chatPanel:loadInitData(num, true)
  else
    gf:ShowSmallTips(CHS[5400305])
  end
  self.chatTable[#self.chatTable].perCallMeHasLose = true
end
function SingleChatPanel:findHornMsg()
  local num = 0
  for i = #self.chatTable, 1, -1 do
    if self.chatTable[i].channel == CHAT_CHANNEL.HORN then
      num = i
      break
    end
  end
  return num
end
function SingleChatPanel:moveToHornMsg()
  local num = self:findHornMsg()
  if num > 0 then
    self.lastChatNum = self:getTotalIndex()
    self.chatPanel:loadInitData(num, true)
  else
  end
end
function SingleChatPanel:setHasOneCallMe(flag)
  self.callPromptPanel:setVisible(flag)
  self.hasOneCallMe = flag
end
function SingleChatPanel:findRedBaglastNum()
  local index = 0
  for i = #self.chatTable, 1, -1 do
    if ChatMgr:isRedBagMsg(self.chatTable[i].chatStr) then
      index = i
      break
    end
  end
  return index
end
function SingleChatPanel:editBoxListner(event, sender)
  if event == "return" then
    self:sendMessage()
  elseif event == "changed" then
    local text = self:getInputStr()
    local len = string.len(text)
    if not self:checkStringLength() and string.match(text, "@$") and gf:isIos() and self:readyToAddCallChar() then
      self.editBox:closeKeyboard()
    end
    if len > 0 then
      self:setDelVisible(true)
    end
  elseif event == "ended" then
    SoundMgr:postEditing()
  end
end
function SingleChatPanel:checkStringLength()
  local text = self:getInputStr()
  local len = string.len(text)
  local leftString = text
  local filterStr = ""
  local index = 1
  if gf:getTextLength(text) > self:getWorldLimit() * 2 then
    gf:ShowSmallTips(CHS[4000224])
    text = gf:subString(text, self:getWorldLimit() * 2)
    self:setInputStr(tostring(text))
    return true
  end
end
function SingleChatPanel:getTotalIndex()
  if self.chatTable[#self.chatTable] then
    return self.chatTable[#self.chatTable].index or 0
  else
    return 0
  end
end
function SingleChatPanel:onUnReadNotePanel()
  self.unReadNotePanel:setVisible(false)
  self.lastChatNum = self:getTotalIndex()
  self.chatPanel:newMessage()
end
function SingleChatPanel:onInputBKImage()
  self.editBox:sendActionsForControlEvents(cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
end
function SingleChatPanel:onMenuButton(sender)
  if not DistMgr:checkCrossDist() then
    return
  end
  local menuPanel = self:getControl("HornMenuPanel")
  menuPanel:setVisible(not menuPanel:isVisible())
  if sender:getChildByTag(ResMgr.magic.world_chat_under_arrow) then
    sender:removeChildByTag(ResMgr.magic.world_chat_under_arrow)
    cc.UserDefault:getInstance():setIntegerForKey("worldDlgPlayGuideMagic" .. gf:getShowId(Me:queryBasic("gid")), 1)
  end
end
function SingleChatPanel:onMenuButton1()
  if not DistMgr:checkCrossDist() then
    return
  end
  gf:CmdToServer("CMD_TRY_USE_LABA", {})
  self:setCtrlVisible("HornMenuPanel", false)
end
function SingleChatPanel:onMenuButton2()
  if not DlgMgr:getDlgByName("HornRecordDlg") then
    DlgMgr:openDlg("HornRecordDlg")
  else
    DlgMgr:reorderDlgByName("HornRecordDlg")
  end
  self:setCtrlVisible("HornMenuPanel", false)
end
function SingleChatPanel:onMenuButton3()
  DlgMgr:openDlg("ChatDecorateDlg")
  self:setCtrlVisible("HornMenuPanel", false)
end
function SingleChatPanel:setDecorateBtnVisible(flag)
  local panel = self:getControl("HornMenuPanel")
  local panelSz = panel:getContentSize()
  local decBtn = self:getControl("MenuButton3")
  local decBtnSz = decBtn:getContentSize()
  if flag then
    if not decBtn:isVisible() then
      panel:setContentSize(panelSz.width, panelSz.height + decBtnSz.height + 2)
    end
  elseif decBtn:isVisible() then
    panel:setContentSize(panelSz.width, panelSz.height - decBtnSz.height - 2)
  end
  self:setCtrlVisible("MenuButton3", flag)
end
function SingleChatPanel:setCallBack(obj, funcName, channelName)
  self.func = nil
  self.func = obj[funcName]
  self.obj = nil
  self.obj = obj
  self.channelName = channelName
end
function SingleChatPanel:getListData()
  return self.chatTable
end
function SingleChatPanel:sendVoiceMsg()
  local voiceData = ChatMgr:getVoiceData()
  if voiceData then
    self.func(self.obj, voiceData.text, voiceData.voiceTime, voiceData.token, self.channelName)
  end
end
function SingleChatPanel:sendVoiceMsgError()
  local voiceData = ChatMgr:getVoiceData()
  if not self.channelName or not voiceData then
    return
  end
  local data = {}
  data.voiceTime = voiceData.voiceTime or 0
  data.token = voiceData.token or ""
  data.channel = self.channelName
  gf:CmdToServer("CMD_CHAT_GET_VOICE_TEXT_FAILED", data)
end
function SingleChatPanel:onDelButton(sender, eventType)
  self:setInputStr("")
  self:setDelVisible(false)
end
function SingleChatPanel:onExpressionButton(sender, eventType)
  local dlg = DlgMgr:getDlgByName("LinkAndExpressionDlg")
  if dlg then
    DlgMgr:closeDlg("LinkAndExpressionDlg")
    return
  end
  dlg = DlgMgr:openDlg("LinkAndExpressionDlg")
  dlg:setCallObj(self, self.channelName, self.chatGid)
end
function SingleChatPanel:sendMessage()
  local txt = self:getInputStr()
  if txt == nil or string.len(txt) == 0 then
    self:setDelVisible(false)
    return
  end
  if gf.clipBoardPara and (not self.sendInfo or not string.match(txt, "{\029(..-)\029}")) and gf:findStrByByte(txt, gf.clipBoardPara.copyInfo) and not gf:findStrByByte(txt, "@" .. gf.clipBoardPara.copyInfo) then
    self.sendInfo = gf.clipBoardPara.sendInfo
    txt = gf:replaceStr(txt, gf.clipBoardPara.copyInfo, gf.clipBoardPara.showInfo)
  end
  if not string.match(txt, "{\029(..-)\029}") then
    self.sendInfo = nil
  end
  txt = self:checkCardInfoLegal(txt)
  if self.sendInfo and not string.match(self.sendInfo, "{\t..-=..-=..-=(.-)}") then
    local type, idStr = string.match(self.sendInfo, "{\t..-=(..-)=(..-)}")
    if type == CHS[3000015] or type == CHS[3001218] then
      local iid
      if type == CHS[3001218] then
        local pet = PetMgr:getPetById(tonumber(idStr))
        if pet then
          iid = pet:queryBasic("iid_str")
        else
          iid = ""
        end
      elseif type == CHS[3000015] then
        local item = InventoryMgr:getItemByIdFromAll(tonumber(idStr))
        if item then
          iid = item.iid_str or ""
        else
          iid = ""
        end
      end
      self.sendInfo = string.gsub(self.sendInfo, "}", "=" .. iid .. "}")
    end
  end
  ChatMgr:setHistoryMsg({
    sendInfo = self.sendInfo or txt,
    showInfo = txt
  })
  if self.sendInfo then
    if string.match(self.sendInfo, "{\t..-=..-=..-=(.-)}") then
      local name, type, idStr, iidStr = string.match(self.sendInfo, "{\t(..-)=(..-)=(..-)=(.-)}")
      if type == CHS[3000015] or type == CHS[3001218] then
        local id
        if type == CHS[3001218] then
          local pet = PetMgr:getPetByIId(iidStr)
          if not pet then
            id = idStr
          else
            id = pet:queryBasicInt("id")
          end
        elseif type == CHS[3000015] then
          local item = InventoryMgr:getItemByIIdFromAll(iidStr)
          if not item then
            id = idStr
          else
            id = item.item_unique
          end
        end
        self.sendInfo = string.format("{\t%s=%s=%s}", name, type, id)
      end
    end
    if string.match(txt, CHS[4200663]) and string.match(txt, ".*{\029(..-)\029}.*") then
      local cardtext = string.match(self.sendInfo, ".*({\t..-=(..-=..-)}).*")
      txt = string.gsub(txt, "{\029(..-)\029}", cardtext)
    elseif string.match(self.sendInfo, "{\t..-=(..-=..-)}") and string.match(txt, ".*{\029(..-)\029}.*") then
      local sendInfoFlag = string.match(self.sendInfo, "{\t(..-)=..-=..-}")
      local sendInfoFlag2 = string.match(self.sendInfo, "{\t..-=(..-)=..-}")
      local txtFlag = string.match(txt, ".*{\029(..-)\029}.*")
      if string.match(txtFlag, "(..-)=teacher_2018") == sendInfoFlag then
        txt = string.gsub(txt, "{\029", "{\t")
        txt = string.gsub(txt, "\029}", "}")
      end
      if self:hasLegalCardInfo(txtFlag, sendInfoFlag, sendInfoFlag2) then
        local cardtext = string.match(self.sendInfo, ".*({\t..-=(..-=..-)}).*")
        txt = string.gsub(txt, "{\029(..-)\029}", cardtext)
      end
    else
      txt = string.gsub(txt, "\t", "")
    end
  end
  txt = ChatMgr:checkCallMsgLegal(txt)
  if self.func(self.obj, txt) then
    self:setInputStr("")
    self:setDelVisible(false)
    self.sendInfo = nil
    return true
  end
end
function SingleChatPanel:hasLegalCardInfo(txtFlag, sendInfoFlag, sendInfoFlag2)
  if string.match(txtFlag, CHS[4101136]) == sendInfoFlag then
    return true
  end
  if sendInfoFlag2 == CHS[7000012] and txtFlag == CHS[7000012] or sendInfoFlag == txtFlag then
    return true
  end
  if sendInfoFlag2 == CHS[2100146] and string.match(txtFlag, CHS[2100147]) then
    return true
  end
  if sendInfoFlag2 == CHS[2100149] and string.match(txtFlag, CHS[2100150]) then
    return true
  end
  if sendInfoFlag2 == CHS[4100443] and txtFlag == CHS[4100443] then
    return true
  end
  if sendInfoFlag2 == CHS[6000165] and CharMgr:getChengweiShowName(sendInfoFlag) == txtFlag then
    return true
  end
  if sendInfoFlag2 == CHS[7190483] and string.match(txtFlag, CHS[7190483]) then
    return true
  end
  if sendInfoFlag2 == CHS[7190487] and string.match(txtFlag, CHS[7190487]) then
    return true
  end
  if sendInfoFlag2 == CHS[7150217] and string.match(txtFlag, CHS[7150220]) then
    return true
  end
end
function SingleChatPanel:checkCardInfoLegal(text)
  if not self.sendInfo then
    return text
  end
  local oldText = text
  local sendInfoFlag = string.match(self.sendInfo, "{\t(..-)=..-=..-}")
  local sendInfoFlag2 = string.match(self.sendInfo, "{\t..-=(..-)=..-}")
  local legalCardInfo
  for subStr in string.gfind(text, "{(\029..-\029)}") do
    local str = string.gsub(subStr, "\029", "")
    if not legalCardInfo and self:hasLegalCardInfo(str, sendInfoFlag, sendInfoFlag2) then
      legalCardInfo = subStr
      text = gf:replaceStr(text, subStr, "\029\t\029")
    else
      text = gf:replaceStr(text, subStr, str)
    end
  end
  if legalCardInfo then
    return gf:replaceStr(text, "\029\t\029", legalCardInfo)
  else
    return oldText
  end
end
function SingleChatPanel:isFriendDlg()
  if self.channelName == CHAT_CHANNEL.CHAT_GROUP or self.channelName == CHAT_CHANNEL.FRIEND then
    return true
  end
end
function SingleChatPanel:resetMessagePanel()
  self.unReadNotePanel:setVisible(false)
  self.chatPanel:resetView()
  self.lastChatNum = self:getTotalIndex()
end
function SingleChatPanel:refreshChatPanel(needFresh)
  if ChatMgr.hasRedBag and self.chatTable and self.chatTable[1] then
    local isVisible = false
    if ChatMgr.hasRedBag == "PARTY" and self.chatTable[1].channel == CHAT_CHANNEL.PARTY then
      isVisible = true
    end
    if ChatMgr.hasRedBag == "WORLD" and self.chatTable[1].channel == CHAT_CHANNEL.WORLD then
      isVisible = true
    end
    self.redBagPanel:setVisible(isVisible)
    self.closeRedBagButton:setVisible(isVisible)
  end
  if not self.unReadNotePanel then
    return
  end
  local unreadNumber = self:getTotalIndex() - self.lastChatNum
  if self.chatPanel:scroviewllIsIntop() == true and (not ChatMgr:channelDlgIsOutsideWin() or self:isFriendDlg()) and self:isVisible() and (unreadNumber ~= 0 or needFresh) and self.chatPanel:canRefenshChat() then
    self.unReadNotePanel:setVisible(false)
    self.chatPanel:newMessage()
    self.lastChatNum = self:getTotalIndex()
  else
    self:refreshUnReadNote(unreadNumber)
  end
end
function SingleChatPanel:refreshUnReadNote(unreadNumber)
  if unreadNumber ~= 0 then
    self.unReadNoteLabel:setString(string.format(CHS[6000209], unreadNumber))
    self.unReadNotePanel:setVisible(true)
    self.unReadNotePanel:requestDoLayout()
  else
    self.unReadNotePanel:setVisible(false)
  end
end
function SingleChatPanel:deleteWord()
  local text = self:getInputStr()
  local len = string.len(text)
  local deletNum = 0
  if len > 0 then
    if string.byte(text, len) < 128 then
      deletNum = 1
    elseif 128 <= string.byte(text, len - 1) and string.byte(text, len - 2) >= 224 then
      deletNum = 3
    elseif string.byte(text, len - 1) >= 192 then
      deletNum = 2
    end
    local newtext = string.sub(text, 0, len - deletNum)
    self:setInputStr(newtext)
    if string.len(newtext) == 0 then
      self:setDelVisible(false)
    end
  else
    self:setDelVisible(false)
  end
end
function SingleChatPanel:addSpace()
  local text = self:getInputStr()
  self:setInputStr(text .. " ")
  self:checkStringLength()
end
function SingleChatPanel:swichWordInput()
  self.editBox:sendActionsForControlEvents(cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
end
function SingleChatPanel:addCardInfo(...)
  local sendInfo, showInfo, canNotBeReplaced = ...
  local text = self:getInputStr()
  if string.match(text, ".*{\029(..-)\029}.*") and string.match(showInfo, ".*{\029(..-)\029}.*") then
    if canNotBeReplaced then
      gf:ShowSmallTips(CHS[3002179])
    else
      text = string.gsub(text, "{\029(..-)\029}", showInfo)
      self.sendInfo = sendInfo
      self:setInputStr(text)
      self:checkCardInfoLength()
      self:setDelVisible(true)
    end
  else
    if sendInfo and string.match(sendInfo, "{\t(..-)}") then
      self.sendInfo = sendInfo
    end
    local str = text .. showInfo
    self:setInputStr(str)
    self:checkCardInfoLength()
    self:setDelVisible(string.len(str) > 0)
    if string.match(showInfo, "@$") then
      self:readyToAddCallChar()
    end
  end
end
function SingleChatPanel:checkCardInfoLength()
  if self:checkStringLength() then
    local text = self:getInputStr()
    if string.match(text, ".*{\029(..-)\029}.*") then
      local cardtext = string.match(self.sendInfo, ".*({\t..-=(..-=..-)}).*")
      text = string.gsub(text, "{\029(..-)\029}", cardtext)
    end
    self.sendInfo = text
  end
end
function SingleChatPanel:addExpression(exrepssion)
  local text = self:getInputStr()
  local len = gf:getTextLength(text .. exrepssion)
  if len > self:getWorldLimit() * 2 then
    gf:ShowSmallTips(CHS[6000133])
  else
    self:setInputStr(text .. exrepssion)
  end
  self:setDelVisible(len > 0)
end
function SingleChatPanel:addCallSign()
  local text = self:getInputStr()
  if gf:getTextLength(text .. "@") > self:getWorldLimit() * 2 then
    gf:ShowSmallTips(CHS[6000133])
  else
    self:setInputStr(text .. "@")
    self:readyToAddCallChar()
  end
  self:setDelVisible(true)
end
function SingleChatPanel:readyToAddCallChar()
  if self.channelName ~= CHAT_CHANNEL.PARTY and self.channelName ~= CHAT_CHANNEL.CHAT_GROUP then
    return
  end
  if self.channelName == CHAT_CHANNEL.PARTY and Me:queryBasic("party/name") == "" then
    return
  end
  local dlg = DlgMgr:openDlg("CallMemberDlg")
  dlg:setCallObj(self, self.channelName)
  return true
end
function SingleChatPanel:addCallChar(name)
  local text = self:getInputStr()
  local callStr
  text = string.gsub(text, "@$", "")
  callStr = "\029@" .. name .. "\029 "
  if gf:getTextLength(text .. callStr) > self:getWorldLimit() * 2 then
    gf:ShowSmallTips(CHS[6000133])
  else
    ChatMgr:addHadCallOne(name)
    self:setInputStr(text .. callStr)
  end
  self:setDelVisible(true)
end
function SingleChatPanel:getControl(name, widgetType, root)
  local widget
  if type(root) == "string" then
    root = self:getControl(root, "ccui.Widget")
    widget = ccui.Helper:seekWidgetByName(root, name)
  else
    root = root or self.root
    widget = ccui.Helper:seekWidgetByName(root, name)
  end
  return widget
end
function SingleChatPanel:setCtrlVisible(ctrlName, visible, root)
  local ctrl = self:getControl(ctrlName, nil, root)
  if ctrl then
    ctrl:setVisible(visible)
  end
  return ctrl
end
function SingleChatPanel:bindListener(name, func, root)
  if nil == func then
    Log:W("Dialog:bindListener no function.")
    return
  end
  local widget = self:getControl(name, nil, root)
  if nil == widget then
    if name ~= "CloseButton" then
      Log:W("Dialog:bindListener no control " .. name)
    end
    return
  end
  self:bindTouchEndEventListener(widget, func)
end
function SingleChatPanel:bindTouchEndEventListener(ctrl, func)
  if not ctrl then
    Log:W("Dialog:bindTouchEndEventListener no control ")
    return
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
      SoundMgr:playEffect("button")
      func(self, sender, eventType)
    end
  end
  ctrl:addTouchEventListener(listener)
end
function SingleChatPanel:createEditBox(name, root, returnType, func)
  local function editBoxListner(envent, sender)
    if func ~= nil then
      func(self, envent, sender)
    end
  end
  local backSprite = cc.Scale9Sprite:createWithSpriteFrameName("TextField0011.png")
  backSprite:setOpacity(0)
  local panel = self:getControl(name, nil, root)
  local editBox = cc.EditBox:create(panel:getContentSize(), backSprite)
  editBox:registerScriptEditBoxHandler(editBoxListner)
  editBox:setReturnType(returnType or cc.KEYBOARD_RETURNTYPE_DEFAULT)
  editBox:setAnchorPoint(0, 0.5)
  editBox:setPosition(5, panel:getContentSize().height / 2)
  local cfg = DeviceMgr:getUIScale()
  if cfg and "function" == type(editBox.setMargin) then
    editBox:setMargin(cfg.ebLeftMargin, cfg.ebRightMargin)
  end
  panel:addChild(editBox)
  return editBox
end
function SingleChatPanel:getInputText(name, root)
  local textField = self:getControl(name, Const.UITextField, root)
  if textField == nil then
    return ""
  else
    return textField:getStringValue()
  end
end
function SingleChatPanel:setInputText(name, text, root)
  local ctl = self:getControl(name, Const.UITextField, root)
  if nil ~= ctl and text ~= nil then
    ctl:setText(tostring(text))
  end
end
function SingleChatPanel:isCanSpeak()
  if self:callBack("isCanSpeak") then
    return true
  else
    return false
  end
end
function SingleChatPanel:callBack(funcName, ...)
  local func = self.obj[funcName]
  if self.obj and func then
    return func(self.obj, ...)
  end
end
function SingleChatPanel:clear()
  self:cleanup()
  if self.chatPanel then
    self.chatPanel:clear()
    self.chatPanel = nil
  end
  if self.inputPanel then
    local arrowBtn = self:getControl("MenuButton", nil, self.inputPanel)
    if arrowBtn then
      arrowBtn:removeChildByTag(ResMgr.magic.world_chat_under_arrow)
    end
  end
end
return SingleChatPanel
