local GeneralGuidePanel = class("GeneralGuidePanel", function()
  return ccui.Layout:create()
end)
local MAX_WIDTH = 432
local MIN_WIDTH = 18
local MIN_HEIGHT = 18
local DEFAULT_FONT = 18
function GeneralGuidePanel:ctor(text)
  self:setAnchorPoint(0, 0)
  self:setName("GeneralGuidePanel")
  local jsonName = ResMgr:getDlgCfg("GeneralGuideDlg")
  self.root = ccs.GUIReader:getInstance():widgetFromJsonFile(jsonName)
  self:setContentSize(self.root:getContentSize())
  self:addChild(self.root)
  local fontSize = 18
  local color = RULE_DLG_CFG.CONTENT_COLOR
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(fontSize)
  textCtrl:setContentSize(MAX_WIDTH, 0)
  textCtrl:setString(text, true)
  textCtrl:setDefaultColor(color.r, color.g, color.b)
  if textCtrl.setPunctTypesetting then
    textCtrl:setPunctTypesetting(true)
  end
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  local panel = self:getControl("TextPanel")
  panel:addChild(tolua.cast(textCtrl, "cc.LayerColor"))
  local size = panel:getContentSize()
  local newSize = cc.size(math.max(textW, MIN_WIDTH), math.max(textH, MIN_HEIGHT))
  panel:setContentSize(newSize)
  textCtrl:setPosition((newSize.width - textW) * 0.5, (newSize.height + textH) * 0.5)
  local cw = newSize.width - size.width
  local ch = newSize.height - size.height
  local function updateSize(ctrl)
    local size = ctrl:getContentSize()
    ctrl:setContentSize(size.width + cw, size.height + ch)
  end
  updateSize(self.root)
  updateSize(self:getControl("BKImage"))
  updateSize(self)
  self.root:requestDoLayout()
end
function GeneralGuidePanel:getControl(name, widgetType, root)
  local widget
  if type(root) == "string" then
    root = self:getControl(root, "ccui.Widget")
    widget = ccui.Helper:seekWidgetByName(root, name)
  else
    root = root or self.root
    widget = ccui.Helper:seekWidgetByName(root, name)
  end
  return widget
end
function GeneralGuidePanel:setCtrlVisible(ctrlName, visible, root)
  local ctrl = self:getControl(ctrlName, nil, root)
  if ctrl then
    ctrl:setVisible(visible)
  end
  return ctrl
end
function GeneralGuidePanel:setFloatingFramePos(rect, pos)
  self:setCtrlVisible("RightArrowImage", false)
  self:setCtrlVisible("LeftArrowImage", false)
  self:setCtrlVisible("DownArrowImage", false)
  self:setCtrlVisible("UpArrowImage", false)
  local x, y = rect.x, rect.y
  local space = 5 * Const.UI_SCALE
  local panelSize = self:getContentSize()
  local arrow, align
  if pos == "up" then
    x = rect.x - (panelSize.width - rect.width) / 2
    y = rect.y + rect.height + space
    self:setCtrlVisible("DownArrowImage", true)
    arrow = self:getControl("DownArrowImage")
    align = ccui.RelativeAlign.alignParentLeftBottom
  elseif pos == "down" then
    x = rect.x - (panelSize.width - rect.width) / 2
    y = rect.y - panelSize.height - space
    self:setCtrlVisible("UpArrowImage", true)
    arrow = self:getControl("UpArrowImage")
    align = ccui.RelativeAlign.alignParentTopLeft
  elseif pos == "left" then
    x = rect.x - panelSize.width - space
    y = rect.y - (panelSize.height - rect.height) / 2
    self:setCtrlVisible("RightArrowImage", true)
    arrow = self:getControl("RightArrowImage")
    align = ccui.RelativeAlign.alignParentRightBottom
  elseif pos == "right" then
    x = rect.x + rect.width + space
    y = rect.y - (panelSize.height - rect.height) / 2
    self:setCtrlVisible("LeftArrowImage", true)
    arrow = self:getControl("LeftArrowImage")
    align = ccui.RelativeAlign.alignParentLeftBottom
  end
  local winSize = Dialog.getWinSize()
  local cx, cy = x, y
  local offset = 8
  if y + panelSize.height > winSize.oy + winSize.height then
    y = Const.WINSIZE.height - panelSize.height - offset * Const.UI_SCALE
  elseif y < winSize.oy then
    y = offset * Const.UI_SCALE + winSize.oy
  end
  if x < winSize.ox then
    x = winSize.ox + offset * Const.UI_SCALE
  elseif x + panelSize.width > winSize.width + winSize.ox then
    x = winSize.width + winSize.ox - offset * Const.UI_SCALE - panelSize.width
  end
  if arrow then
    local lp = arrow:getLayoutParameter()
    local margin = lp:getMargin()
    lp:setAlign(align)
    if align == ccui.RelativeAlign.alignParentLeftBottom or align == ccui.RelativeAlign.alignParentTopLeft then
      lp:setMargin({
        left = panelSize.width / 2 - (x - cx) - arrow:getContentSize().width / 2
      })
    elseif align == ccui.RelativeAlign.alignParentRightBottom or align == ccui.RelativeAlign.alignParentLeftBottom then
      lp:setMargin({
        bottom = panelSize.height / 2 - (y - cy) - arrow:getContentSize().height / 2
      })
    end
  end
  local parent = self:getParent()
  if parent then
    local pos = parent:convertToNodeSpace(cc.p(x, y))
    self:setPosition(pos)
  else
    self:setPosition(x, y)
  end
end
return GeneralGuidePanel
