local RadioGroup = class("RadioGroup")
function RadioGroup:ctor()
  self.radios = {}
end
function RadioGroup:setItemsByButton(dlg, radioNames, func, root, selectSameFunc, notDef, limitFun)
  local function cb(dlg, sender, eventType)
    if limitFun and not limitFun(dlg, sender, curIdx) then
      return
    end
    local curIdx = 1
    for j = 1, #self.radios do
      local radio = self.radios[j]
      local ctlName = radio:getName()
      local key = string.match(ctlName, "(.+)Button")
      local selectImageName = key .. "Image"
      dlg:setCtrlVisible(selectImageName, radio == sender, root)
      if radio ~= sender then
      else
        curIdx = j
      end
    end
    if func then
      func(dlg, sender, curIdx)
    end
    Dialog.removeRedDot(dlg, sender)
  end
  self.radios = {}
  self.dlg = dlg
  self.cb = func
  for i = 1, #radioNames do
    local radio
    if type(radioNames[i]) == "userdata" then
      radio = radioNames[i]
    else
      radio = dlg:getControl(radioNames[i], nil, root)
    end
    dlg:bindTouchEndEventListener(radio, cb)
    table.insert(self.radios, radio)
  end
  if not notDef then
    local key = string.match(radioNames[1], "(.+)Button")
    local selectImageName = key .. "Image"
    dlg:setCtrlVisible(selectImageName, true, root)
  end
  self.radioType = RADIO_TYPE.BUTTON
end
function RadioGroup:setItemsByPanel(dlg, radioNames, func, root, selectSameFunc, selectFunc)
  local function cb(dlg, sender, eventType)
    if eventType == ccui.TouchEventType.ended and ("function" ~= type(selectFunc) or selectFunc(dlg, sender.radio)) then
      local curIdx = 1
      local panel = sender.radio
      local hasSelect = false
      for j = 1, #self.radios do
        local radio = self.radios[j]
        if radio ~= panel then
          dlg:setCtrlVisible("PressedPanel", false, radio)
        else
          hasSelect = dlg:getCtrlVisible("PressedPanel", radio)
          dlg:setCtrlVisible("PressedPanel", true, radio)
          curIdx = j
        end
      end
      if not hasSelect then
        if func then
          func(dlg, panel, curIdx)
        end
      elseif selectSameFunc then
        selectSameFunc(dlg, panel, curIdx)
      end
      Dialog.removeRedDot(dlg, panel)
    end
  end
  self.radios = {}
  self.dlg = dlg
  self.cb = func
  local btn
  for i = 1, #radioNames do
    local radio
    if type(radioNames[i]) == "userdata" then
      radio = radioNames[i]
    else
      radio = dlg:getControl(radioNames[i], nil, root)
    end
    btn = dlg:getControl("Button", nil, radio)
    btn.radio = radio
    dlg:setCtrlVisible("PressedPanel", false, radio)
    dlg:bindTouchEventListener(btn, cb)
    table.insert(self.radios, radio)
  end
  self.radioType = RADIO_TYPE.PANEL
end
function RadioGroup:setItems(dlg, radioNames, func, root, selectSameFunc, selectFunc)
  local function cb(sender, eventType)
    local isRemovedRed = Dialog.removeRedDot(dlg, sender)
    if eventType == ccui.CheckBoxEventType.selected then
      if "function" ~= type(selectFunc) or selectFunc(dlg, sender) then
        local curIdx = 1
        for j = 1, #self.radios do
          local radio = self.radios[j]
          if radio ~= sender then
            radio:setSelectedState(false)
          else
            curIdx = j
          end
        end
        if dlg.name then
          RecordLogMgr:isMeetPlugOrder(dlg.name .. "_" .. sender:getName())
        end
        if func then
          func(dlg, sender, curIdx, isRemovedRed)
        end
      else
        sender:setSelectedState(false)
      end
    else
      sender:setSelectedState(true)
      if selectSameFunc then
        selectSameFunc(dlg, sender)
      end
    end
    SoundMgr:playEffect("button")
  end
  self.radios = {}
  self.dlg = dlg
  self.cb = func
  for i = 1, #radioNames do
    local radio
    if type(radioNames[i]) == "userdata" then
      radio = radioNames[i]
    else
      radio = dlg:getControl(radioNames[i], Const.UICheckBox, root)
    end
    radio:addEventListener(cb)
    table.insert(self.radios, radio)
  end
  self.radioType = RADIO_TYPE.CHECK
end
function RadioGroup:setItemsCanReClick(dlg, radioNames, func, root, selectFunc)
  local function cb(sender, eventType)
    local isRemovedRed = Dialog.removeRedDot(dlg, sender)
    if "function" ~= type(selectFunc) or selectFunc(dlg, sender) then
      local curIdx = 1
      for j = 1, #self.radios do
        local radio = self.radios[j]
        if radio ~= sender then
          radio:setSelectedState(false)
        else
          curIdx = j
        end
      end
      local rState = 0
      if sender:getSelectedState() then
        rState = 1
      end
      if dlg.name then
        RecordLogMgr:isMeetPlugOrder(dlg.name .. "_" .. sender:getName())
      end
      sender:setSelectedState(true)
      SoundMgr:playEffect("button")
      if func then
        func(dlg, sender, curIdx, isRemovedRed, rState)
      end
    else
      sender:setSelectedState(false)
    end
  end
  self.radios = {}
  self.dlg = dlg
  self.cb = func
  for i = 1, #radioNames do
    local radio = dlg:getControl(radioNames[i], Const.UICheckBox, root)
    radio:addEventListener(cb)
    table.insert(self.radios, radio)
  end
end
function RadioGroup:setSetlctButtonByName(name)
  local num = #self.radios
  for j = 1, num do
    local radio = self.radios[j]
    local ctlName = radio:getName()
    local key = string.match(ctlName, "(.+)Button")
    local selectImageName = key .. "Image"
    self.dlg:setCtrlVisible(selectImageName, radio:getName() == name)
  end
end
function RadioGroup:setSetlctByName(name, noCallback)
  local num = #self.radios
  local idx
  for j = 1, num do
    local radio = self.radios[j]
    if radio:getName() == name then
      radio:setSelectedState(true)
      idx = j
    else
      radio:setSelectedState(false)
    end
  end
  if self.cb and not noCallback then
    self.cb(self.dlg, self.radios[idx], idx)
  end
end
function RadioGroup:setSetlctButton(idx, noCallback)
  local num = #self.radios
  for j = 1, num do
    local radio = self.radios[j]
    local ctlName = radio:getName()
    local key = string.match(ctlName, "(.+)Button")
    local selectImageName = key .. "Image"
    self.dlg:setCtrlVisible(selectImageName, idx == j)
  end
  if self.cb and not noCallback then
    self.cb(self.dlg, self.radios[idx], idx)
  end
end
function RadioGroup:selectRadio(idx, noCallback)
  local num = #self.radios
  if idx > num or idx < 1 then
    return
  end
  if self.radioType == RADIO_TYPE.PANEL then
    for j = 1, num do
      local radio = self.radios[j]
      self.dlg:setCtrlVisible("PressedPanel", idx == j, radio)
    end
  else
    for j = 1, num do
      local radio = self.radios[j]
      radio:setSelectedState(j == idx)
    end
  end
  if self.cb and not noCallback then
    self.cb(self.dlg, self.radios[idx], idx)
  end
end
function RadioGroup:unSelectedRadio()
  local num = #self.radios
  if self.radioType == RADIO_TYPE.PANEL then
    for j = 1, num do
      local radio = self.radios[j]
      self.dlg:setCtrlVisible("PressedPanel", false, radio)
    end
  else
    for j = 1, num do
      local radio = self.radios[j]
      radio:setSelectedState(false)
    end
  end
end
function RadioGroup:getSelectedRadio()
  if self.radioType == RADIO_TYPE.PANEL then
    for j = 1, #self.radios do
      local radio = self.radios[j]
      if self.dlg:getCtrlVisible("PressedPanel", radio) then
        return radio
      end
    end
  else
    for j = 1, #self.radios do
      local radio = self.radios[j]
      if radio:getSelectedState() then
        return radio
      end
    end
  end
end
function RadioGroup:getSelectedRadioIndex()
  if self.radioType == RADIO_TYPE.PANEL then
    for j = 1, #self.radios do
      local radio = self.radios[j]
      if self.dlg:getCtrlVisible("PressedPanel", radio) then
        return j
      end
    end
  else
    for j = 1, #self.radios do
      local radio = self.radios[j]
      if radio:getSelectedState() then
        return j
      end
    end
  end
end
function RadioGroup:getSelectedRadioName()
  local radio = self:getSelectedRadio()
  if radio then
    return radio:getName()
  end
end
function RadioGroup:getRadioNameIndex(index)
  return self.radios[index]
end
return RadioGroup
