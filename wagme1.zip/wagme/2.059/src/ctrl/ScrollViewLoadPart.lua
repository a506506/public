local ScrollViewLP = class("ScrollViewLoadPart")
local CONTENTLAYER_TAG = 9999
local CLICKLAYRE_TAG = 8888
function ScrollViewLP:ctor(dlg, scrollView, cloneCtrl, func, col, lineSpace, columnSpace, leftMargin, TopMargin)
  self.dlg = dlg
  self.cloneCtrl = cloneCtrl
  self.col = col
  self.lineSpace = lineSpace or 0
  self.columnSpace = columnSpace or 0
  self.leftMargin = leftMargin or 0
  self.TopMargin = TopMargin or 0
  self.cellViewCallback = func
  self.eventCallback = nil
  self.cellNotUseCallback = nil
  self.notCallScrollView = nil
  self.data = nil
  self.multData = nil
  self.chosenCtrl = nil
  if type(scrollView) == "string" then
    scrollView = dlg:getControl(scrollView)
  end
  self.scrollView = scrollView
  self.usingCells = {}
  self.notUseCells = {}
  local size = scrollView:getContentSize()
  if type(cloneCtrl) == "table" then
    self.loadLine = math.ceil(size.height / 2 / (cloneCtrl[1]:getContentSize().height + lineSpace)) + 1
  else
    self.loadLine = math.ceil(size.height / 2 / (cloneCtrl:getContentSize().height + lineSpace)) + 1
  end
  self.scrollView:addEventListener(function(sender, eventType)
    self:onScrollView(sender, eventType)
  end)
end
function ScrollViewLP:setChosenCtrl(chosenCtrl)
  if type(chosenCtrl) == "table" then
    self.chosenCtrl = chosenCtrl
  else
    self.chosenCtrl = {}
    self.chosenCtrl[1] = chosenCtrl
  end
end
function ScrollViewLP:setBounceEnabled(enabled)
  self.scrollView:setBounceEnabled(enabled)
end
function ScrollViewLP:setTopMargin(margin)
  self.TopMargin = margin
end
function ScrollViewLP:getTopMargin()
  return self.TopMargin
end
function ScrollViewLP:setBottomMargin(margin)
  self.bottomMargin = margin
end
function ScrollViewLP:setCellViewCallBack(callback)
  self.cellViewCallback = callback
end
function ScrollViewLP:setCellNotUseCallback(callback)
  self.cellNotUseCallback = callback
end
function ScrollViewLP:bindEventCallback(callback)
  self.eventCallback = callback
end
function ScrollViewLP:bindClickEventCallback(callback)
  self.clickEventCallback = callback
  local layout = self.scrollView:getChildByTag(CLICKLAYRE_TAG)
  if not layout then
    layout = ccui.Layout:create()
    layout:setPosition(0, 0)
    layout:setAnchorPoint(0, 0)
    layout:setTouchEnabled(false)
    layout:setContentSize(self.scrollView:getContentSize())
    local function touch(touch, event)
      if self.clickEventCallback then
        return self.clickEventCallback(self.dlg, touch, event, self)
      end
    end
    self.scrollView:getParent():addChild(layout, 100, CLICKLAYRE_TAG)
    gf:bindTouchListener(layout, touch, {
      cc.Handler.EVENT_TOUCH_BEGAN,
      cc.Handler.EVENT_TOUCH_MOVED,
      cc.Handler.EVENT_TOUCH_ENDED,
      cc.Handler.EVENT_TOUCH_CANCELLED
    }, true)
  end
end
function ScrollViewLP:setNotCallScrollView(flag)
  self.notCallScrollView = flag
end
function ScrollViewLP:onScrollView(sender, eventType)
  if self.notCallScrollView then
    return
  end
  local scrollViewCtrl = sender
  local listInnerContent = scrollViewCtrl:getInnerContainer()
  local innerSize = listInnerContent:getContentSize()
  local scrollViewSize = scrollViewCtrl:getContentSize()
  local contentLayer = scrollViewCtrl:getChildByTag(CONTENTLAYER_TAG)
  if not contentLayer then
    return
  end
  local innerPosY = math.floor(listInnerContent:getPositionY() + 0.5)
  local totalHeight = innerSize.height - scrollViewSize.height
  if self.data and #self.data > 0 and math.abs(self.lastLoadContentY - innerPosY) > 5 then
    self:updateList(self.data)
  end
  if self.eventCallback then
    self.eventCallback(self.dlg, sender, eventType)
  end
end
function ScrollViewLP:pushNotUseList(cell)
  if not cell.lpMenuLeval then
    return
  end
  if not self.notUseCells[cell.lpMenuLeval] then
    self.notUseCells[cell.lpMenuLeval] = {}
  end
  if self.cellNotUseCallback then
    self.cellNotUseCallback(self.dlg, cell)
  end
  if self.chosenCtrl and self.chosenCtrl[cell.lpMenuLeval] and self.chosenCtrl[cell.lpMenuLeval]:getParent() == cell then
    self.chosenCtrl[cell.lpMenuLeval]:removeFromParent()
  end
  cell:setVisible(false)
  table.insert(self.notUseCells[cell.lpMenuLeval], cell)
end
function ScrollViewLP:pushAllNotUseList()
  for key, v in pairs(self.usingCells) do
    self:pushNotUseList(v)
    self.usingCells[key] = nil
  end
end
function ScrollViewLP:getOneCell(lpMenuLeval)
  lpMenuLeval = lpMenuLeval or 1
  if not self.notUseCells[lpMenuLeval] or #self.notUseCells[lpMenuLeval] == 0 then
    local cellColne = type(self.cloneCtrl) == "table" and self.cloneCtrl[lpMenuLeval] or self.cloneCtrl
    if type(self.cloneCtrl) == "table" then
      cellColne = self.cloneCtrl[lpMenuLeval] or self.cloneCtrl[1]
    else
      cellColne = self.cloneCtrl
    end
    local cell = cellColne:clone()
    cell:setAnchorPoint(0, 1)
    cell.lpMenuLeval = lpMenuLeval
    return cell
  else
    local cell = table.remove(self.notUseCells[lpMenuLeval])
    cell:setVisible(true)
    return cell
  end
end
function ScrollViewLP:setLoadCallBack(cell, oneData, tag)
  if type(self.cellViewCallback) == "table" then
    if self.cellViewCallback[cell.lpMenuLeval] then
      self.cellViewCallback[cell.lpMenuLeval](self.dlg, cell, oneData, tag)
    end
  elseif cell.lpMenuLeval == 1 then
    self.cellViewCallback(self.dlg, cell, oneData, tag)
  end
end
function ScrollViewLP:getLoadDataByMultData(data)
  local loadData = {}
  local function func(data, level)
    for i = 1, #data do
      if data[i].tagInfo then
        data[i].tagInfo.lpMenuLeval = level
        table.insert(loadData, data[i].tagInfo)
        if data[i].tagInfo and data[i].tagInfo.isOpen then
          func(data[i], level + 1)
        end
      else
        data[i].lpMenuLeval = level
        table.insert(loadData, data[i])
      end
    end
  end
  func(data, 1)
  return loadData
end
function ScrollViewLP:initList(data, isReset)
  if data and data.isMultTag then
    self.multData = data
    self.data = self:getLoadDataByMultData(data)
  else
    data = data or {}
    self.multData = nil
    self.data = data
  end
  self:pushAllNotUseList()
  self:updateList(self.data, isReset, true)
end
function ScrollViewLP:refresh()
  if not self.data and not self.multData then
    return
  end
  if self.multData then
    self.data = self:getLoadDataByMultData(self.multData)
  end
  self:pushAllNotUseList()
  self:updateList(self.data)
end
function ScrollViewLP:locateToBottom()
  local listInnerContent = self.scrollView:getInnerContainer()
  listInnerContent:setPositionY(0)
  self:refresh()
end
function ScrollViewLP:locateToItem(index)
  index = math.max(1, index)
  local cellColne = type(self.cloneCtrl) == "table" and self.cloneCtrl[1] or self.cloneCtrl
  local scrollView = self.scrollView
  local contentLayer = scrollView:getChildByTag(CONTENTLAYER_TAG)
  local moveHeight = contentLayer:getContentSize().height - scrollView:getContentSize().height
  local cellSize = cellColne:getContentSize()
  local y = math.min(0, (math.max(-moveHeight, (index - 1) * (cellSize.height + self.lineSpace) + self.TopMargin - moveHeight)))
  local listInnerContent = scrollView:getInnerContainer()
  listInnerContent:setPositionY(y)
  self:refresh()
end
function ScrollViewLP:getContentLayer()
  return self.scrollView:getChildByTag(CONTENTLAYER_TAG)
end
function ScrollViewLP:setVisible(visible)
  self.scrollView:setVisible(visible)
end
function ScrollViewLP:getShowItems()
  return self.usingCells
end
function ScrollViewLP:getData()
  return self.data
end
function ScrollViewLP:setDirection(dir)
  self.scrollView:setDirection(dir)
end
function ScrollViewLP:updateList(data, isReset)
  if not data then
    return
  end
  local lineSpace = self.lineSpace
  local columnSpace = self.columnSpace
  local TopMargin = self.TopMargin
  local leftMargin = self.leftMargin
  local rightMargin = self.rightMargin or 0
  local bottomMargin = self.bottomMargin or 0
  local loadLine = self.loadLine
  local column = self.col
  local cellColne = type(self.cloneCtrl) == "table" and self.cloneCtrl[1] or self.cloneCtrl
  local totalCount = #data
  local line = math.floor(totalCount / column)
  local left = totalCount % column
  if left ~= 0 then
    line = line + 1
  end
  local cellSize = cellColne:getContentSize()
  local totalHeight = line * (cellSize.height + lineSpace) + TopMargin + bottomMargin
  local totalWidth = column * (cellSize.width + columnSpace) + leftMargin + rightMargin
  local scrollView = self.scrollView
  local scrollViewSize = scrollView:getContentSize()
  local contentLayer = scrollView:getChildByTag(CONTENTLAYER_TAG)
  local contentY = math.min(0, scrollViewSize.height - totalHeight)
  local oldHeight = 0
  if not contentLayer then
    contentLayer = ccui.Layout:create()
    scrollView:addChild(contentLayer, 0, CONTENTLAYER_TAG)
  elseif isReset then
    local listInnerContent = scrollView:getInnerContainer()
    listInnerContent:setPositionY(contentY)
  else
    local listInnerContent = scrollView:getInnerContainer()
    contentY = listInnerContent:getPositionY()
    oldHeight = contentLayer:getContentSize().height
    contentY = math.min(0, math.max(contentY - (totalHeight - oldHeight), scrollViewSize.height - totalHeight))
  end
  local curLoadY = -contentY + scrollViewSize.height / 2 - bottomMargin
  local curLine = math.min(math.max(line - math.floor(curLoadY / (cellSize.height + lineSpace)), loadLine + 1), math.max(line - loadLine, 1))
  for key, v in pairs(self.usingCells) do
    local l = math.ceil(key / column)
    if l > curLine + loadLine or l < curLine - loadLine then
      self:pushNotUseList(v)
      self.usingCells[key] = nil
    end
  end
  local curColunm = 0
  for i = 1, line do
    if i == line and left ~= 0 then
      curColunm = left
    else
      curColunm = column
    end
    for j = 1, curColunm do
      local tag = j + (i - 1) * column
      local y = totalHeight - (i - 1) * (cellSize.height + lineSpace) - TopMargin
      if data[tag] and i <= curLine + loadLine and i >= curLine - loadLine then
        local cell
        if not self.usingCells[tag] then
          cell = self:getOneCell(data[tag].lpMenuLeval)
          if not cell:getParent() then
            contentLayer:addChild(cell)
          end
          self:setLoadCallBack(cell, data[tag], tag)
          self.usingCells[tag] = cell
        else
          cell = self.usingCells[tag]
        end
        local x = (j - 1) * (cellSize.width + columnSpace) + leftMargin
        if cell.isNotSetPosX then
          cell:setPositionY(y)
        else
          cell:setPosition(x, y)
        end
        cell:setTag(tag)
      end
    end
  end
  if totalHeight ~= oldHeight then
    self:setNotCallScrollView(true)
    contentLayer:setContentSize(scrollViewSize.width, totalHeight)
    scrollView:setInnerContainerSize(contentLayer:getContentSize())
    if totalHeight < scrollViewSize.height then
      contentLayer:setPositionY(scrollViewSize.height - totalHeight)
    else
      contentLayer:setPositionY(0)
    end
    local listInnerContent = scrollView:getInnerContainer()
    listInnerContent:setPositionY(contentY)
    self:setNotCallScrollView(false)
    if self.delayInitList then
      self.scrollView:stopAction(self.delayInitList)
    end
    self.delayInitList = performWithDelay(self.scrollView, function()
      if self.data and #self.data > 0 then
        self:updateList(self.data)
        self.delayInitList = nil
      end
    end, 0)
  end
  self.lastLoadContentY = contentY
end
return ScrollViewLP
