local CONFIG_DATA = {
  [CHS[6000041]] = "",
  [CHS[6000042]] = "",
  [CHS[6000078]] = "",
  [CHS[6000079]] = ""
}
local CONST_DATA = {
  CellHeight = 44,
  CellWidth = 246,
  LineSpace = 5,
  ColunmSpace = 7,
  Colunm = 2,
  Space = 10,
  WordWidth = 200,
  Line = 1,
  BigCellHeight = 74,
  BigCellWidth = 74
}
local DISPLAY_AMOUNT_TYPE = {
  [CHS[6000078]] = 1,
  [CHS[6200002]] = 1,
  [CHS[3001096]] = 1,
  [CHS[3001114]] = 1,
  [CHS[3002169]] = 1,
  [CHS[3002170]] = 1,
  [CHS[3002234]] = 1,
  [CHS[4300255]] = 1,
  [CHS[5420176]] = 1,
  [CHS[4100655]] = 1,
  [CHS[5420251]] = 1,
  [CHS[5420252]] = 1,
  [CHS[2200077]] = 1,
  [CHS[2200073]] = 1,
  [CHS[5400811]] = 1,
  [CHS[5400438]] = 1,
  [CHS[5400439]] = 1,
  [CHS[5450185]] = 1,
  [CHS[5400801]] = 1,
  [CHS[4200798]] = 1,
  [CHS[5401005]] = 1
}
local MARGIN = 10
local SKILL_NUM = {
  [0] = "",
  [1] = CHS[3002140],
  [2] = CHS[3002141],
  [3] = CHS[3002142]
}
local REWAR_DESC = {
  [CHS[3002143]] = CHS[3002144],
  [CHS[3002145]] = CHS[3002146],
  [CHS[3002147]] = CHS[3002148],
  [CHS[3002149]] = CHS[3002150],
  [CHS[5400594]] = CHS[5400595],
  [CHS[3002151]] = CHS[3002152],
  [CHS[3002153]] = CHS[3002154],
  [CHS[3002155]] = CHS[3002156],
  [CHS[3002157]] = CHS[3002158],
  [CHS[3002159]] = CHS[3002160],
  [CHS[3002161]] = CHS[3002162],
  [CHS[3002163]] = CHS[3002164],
  [CHS[6000260]] = CHS[6000261],
  [CHS[4300075]] = CHS[4300077],
  [CHS[7000282]] = CHS[7000283],
  [CHS[7000284]] = CHS[7000285],
  [CHS[4200315]] = CHS[4200317],
  [CHS[4200316]] = CHS[4200318],
  [CHS[5450185]] = CHS[5450184],
  [CHS[5400801]] = CHS[5400802],
  [CHS[5450506]] = CHS[5450507],
  [CHS[5410345]] = CHS[5410347],
  [CHS[5410346]] = CHS[5410348],
  [CHS[7100257]] = CHS[7100258],
  [CHS[5420304]] = CHS[5420306],
  [CHS[7190229]] = CHS[7190230],
  [CHS[7190534]] = CHS[7190535],
  [CHS[7190523]] = CHS[7190593],
  [CHS[7190524]] = CHS[7190594],
  [CHS[7190525]] = CHS[7190595],
  [CHS[7190526]] = CHS[7190596],
  [CHS[7190527]] = CHS[7190597],
  [CHS[4101247]] = CHS[4101253],
  [CHS[4101248]] = CHS[4101254],
  [CHS[4101249]] = CHS[4101255],
  [CHS[4101250]] = CHS[4101256],
  [CHS[4101251]] = CHS[4101257],
  [CHS[4101252]] = CHS[4101258],
  [CHS[4200712]] = CHS[4200713],
  [CHS[2500093]] = CHS[2500094],
  [CHS[2500095]] = CHS[2500096],
  [CHS[5410471]] = CHS[5410472],
  [CHS[7100975]] = CHS[7100976],
  [CHS[5420524]] = CHS[5420534]
}
local ARTIFACT_SPSKILL = {
  "diandao_qiankun",
  "jingangquan",
  "wuji_bifan",
  "tianyan",
  "chaofeng",
  "qinmi_wujian"
}
local ITEMNAME_UI_ICONPATH = {
  [CHS[5420179]] = ResMgr.ui.shiwu1,
  [CHS[5420189]] = ResMgr.ui.shiwu2,
  [CHS[5420180]] = ResMgr.ui.shiwu3,
  [CHS[5420190]] = ResMgr.ui.shiwu4,
  [CHS[5420181]] = ResMgr.ui.shiwu5,
  [CHS[5420182]] = ResMgr.ui.shiwu6,
  [CHS[5420191]] = ResMgr.ui.shiwu7,
  [CHS[5420183]] = ResMgr.ui.shiwu8,
  [CHS[5420192]] = ResMgr.ui.shiwu9,
  [CHS[5420184]] = ResMgr.ui.shiwu10,
  [CHS[5420193]] = ResMgr.ui.shiwu11,
  [CHS[5420185]] = ResMgr.ui.huafei,
  [CHS[5420186]] = ResMgr.ui.shiwu12,
  [CHS[5420196]] = ResMgr.ui.shiwu13,
  [CHS[5420288]] = ResMgr.ui.huafei100,
  [CHS[5420289]] = ResMgr.ui.shiwu14,
  [CHS[5420290]] = ResMgr.ui.shiwu15,
  [CHS[5420291]] = ResMgr.ui.shiwu16,
  [CHS[5420292]] = ResMgr.ui.shiwu17,
  [CHS[5420293]] = ResMgr.ui.shiwu18,
  [CHS[5420294]] = ResMgr.ui.shiwu19,
  [CHS[5420295]] = ResMgr.ui.shiwu20,
  [CHS[8000014]] = ResMgr.ui.shiwu21,
  [CHS[8000015]] = ResMgr.ui.shiwu22,
  [CHS[8000016]] = ResMgr.ui.shiwu23,
  [CHS[8000017]] = ResMgr.ui.shiwu24,
  [CHS[8000018]] = ResMgr.ui.shiwu25
}
local RewardContainer = class("RewardContainer", function()
  return ccui.Layout:create()
end)
RewardContainer.parentScale = 1
function RewardContainer:ctor(str, contentSize, defaultColor, obj, isBigIcon, margin, notAddScrollView, paras)
  local classList = TaskMgr:getRewardList(str)
  self:setContentSize(contentSize)
  self.defaultColor = defaultColor or COLOR3.TEXT_DEFAULT
  self.obj = obj
  self.imgCtrls = {}
  if type(paras) == "number" then
    self.parentScale = parentScale or 1
  elseif type(paras) == "table" then
    self.backType = paras.backType
    self.allShowNum = paras.allShowNum
    self.clickCallBack = paras.clickCallBack
  end
  local contentLayer = ccui.Layout:create()
  local totalHight = 0
  local width = 0
  if isBigIcon then
    if #classList > 0 then
      local cell = self:createOneBigIconContent(classList[1], margin)
      totalHight = totalHight + cell:getContentSize().height + CONST_DATA.ColunmSpace
      width = cell:getContentSize().width
      contentLayer:addChild(cell)
    end
    if totalHight > CONST_DATA.ColunmSpace then
      totalHight = totalHight - CONST_DATA.ColunmSpace
    end
    contentLayer:setContentSize(width, totalHight)
    if width < contentSize.width then
      contentSize.width = width
      self:setContentSize(contentSize)
    end
  else
    for i = #classList, 1, -1 do
      local cell
      if classList[i].isClass then
        cell = self:createOneTitle(classList[i].class)
      else
        cell = self:createOneContent(classList[i], margin)
        width = cell:getContentSize().width
      end
      cell:setPosition(0, totalHight)
      cell:setAnchorPoint(0, 0)
      totalHight = totalHight + cell:getContentSize().height + CONST_DATA.ColunmSpace
      contentLayer:addChild(cell)
    end
    if totalHight > CONST_DATA.ColunmSpace then
      totalHight = totalHight - CONST_DATA.ColunmSpace
    end
    contentLayer:setContentSize(contentSize.width, totalHight)
  end
  if notAddScrollView then
    self:addChild(contentLayer)
  else
    do
      local scroview = ccui.ScrollView:create()
      scroview:setContentSize(contentSize)
      scroview:addChild(contentLayer)
      scroview:setInnerContainerSize(contentLayer:getContentSize())
      scroview:setTouchEnabled(true)
      self:addChild(scroview)
      if isBigIcon then
        scroview:setDirection(ccui.ScrollViewDir.horizontal)
      else
        scroview:setDirection(ccui.ScrollViewDir.vertical)
        if totalHight <= scroview:getContentSize().height then
          contentLayer:setPositionY(scroview:getContentSize().height - totalHight)
        else
          self:callBack("addMagicIcon")
        end
        local function scrollListener(sender, eventType)
          if eventType == ccui.ScrollviewEventType.scrolling then
            local y = scroview:getInnerContainer():getPositionY()
            if y < 0 then
              self:callBack("addMagicIcon")
            else
              self:callBack("removeMagicIcon")
            end
          end
        end
        scroview:addEventListener(scrollListener)
      end
    end
  end
end
function RewardContainer:createOneTitle(title)
  local lableText = CGAColorTextList:create()
  local width = self:getContentSize().width
  lableText:setFontSize(19)
  lableText:setContentSize(width - MARGIN, 30)
  lableText:setString(title)
  lableText:setDefaultColor(self.defaultColor.r, self.defaultColor.g, self.defaultColor.b)
  lableText:updateNow()
  local _, height = lableText:getRealSize()
  lableText:setPosition(MARGIN, height + 5)
  local colorTextLayout = tolua.cast(lableText, "cc.LayerColor")
  local layout = ccui.Layout:create()
  layout:addChild(colorTextLayout)
  layout:setContentSize(width, height + 5)
  return layout
end
function RewardContainer:createOneContent(rewardList, margin)
  local layout = ccui.Layout:create()
  local line = math.floor(#rewardList / CONST_DATA.Colunm)
  local left = #rewardList % CONST_DATA.Colunm
  if left ~= 0 then
    line = line + 1
  end
  margin = margin or CONST_DATA.ColunmSpace
  local curColunm = 0
  local totalHeight = line * (CONST_DATA.CellHeight + CONST_DATA.LineSpace) - CONST_DATA.LineSpace
  local totalWidth = 0
  if line == 1 and left ~= 0 then
    totalWidth = left * (CONST_DATA.CellWidth + margin)
  else
    totalWidth = CONST_DATA.Colunm * (CONST_DATA.CellWidth + margin)
  end
  for i = 1, line do
    if i == line and left ~= 0 then
      curColunm = left
    else
      curColunm = CONST_DATA.Colunm
    end
    for j = 1, curColunm do
      local cell = ccui.Layout:create()
      cell:setContentSize(CONST_DATA.CellWidth, CONST_DATA.CellHeight)
      cell:setTouchEnabled(true)
      cell:setAnchorPoint(0, 1)
      local x = (j - 1) * (CONST_DATA.CellWidth + margin)
      local y = totalHeight - (i - 1) * (CONST_DATA.CellHeight + CONST_DATA.LineSpace)
      cell:setPosition(x, y)
      self:setCellData(cell, rewardList[(i - 1) * CONST_DATA.Colunm + j])
      layout:addChild(cell, 0, i)
    end
  end
  layout:setContentSize(totalWidth, totalHeight)
  return layout
end
function RewardContainer:createOneBigIconContent(rewardList, margin)
  local layout = ccui.Layout:create()
  local colunm = math.floor(#rewardList / CONST_DATA.Line)
  local left = #rewardList % CONST_DATA.Line
  if left ~= 0 then
    colunm = colunm + 1
  end
  margin = margin or CONST_DATA.ColunmSpace
  local cellW = CONST_DATA.BigCellWidth
  local cellH = CONST_DATA.BigCellHeight
  local curLine = 0
  local totalHeight = CONST_DATA.Line * (cellH + CONST_DATA.LineSpace) - CONST_DATA.LineSpace
  local totalWidth = colunm * (cellW + margin) - margin
  for i = 1, colunm do
    if i == colunm and left ~= 0 then
      curLine = left
    else
      curLine = CONST_DATA.Line
    end
    for j = 1, curLine do
      local cell = ccui.Layout:create()
      cell:setContentSize(cellW, cellH)
      cell:setTouchEnabled(true)
      cell:setAnchorPoint(0, 1)
      if self.backType == 2 then
        cell:setBackGroundImage(ResMgr.ui.item_bg_img, ccui.TextureResType.localType)
        cell:setBackGroundImageCapInsets(cc.rect(8, 8, 64, 64))
        cell:setBackGroundImageScale9Enabled(true)
        local sprite = ccui.ImageView:create(ResMgr.ui.item_front_img)
        sprite:setCapInsets(cc.rect(8, 8, 16, 16))
        local size = sprite:getContentSize()
        sprite:setContentSize(cellW, cellH)
        sprite:ignoreContentAdaptWithSize(false)
        sprite:setScale9Enabled(true)
        sprite:setAnchorPoint(0, 0)
        cell:addChild(sprite, 100, 100)
      else
        cell:setBackGroundImage(ResMgr.ui.bag_item_bg_img, ccui.TextureResType.plistType)
      end
      local x = (i - 1) * (cellW + margin)
      local y = totalHeight - (j - 1) * (cellH + CONST_DATA.LineSpace)
      cell:setPosition(x, y)
      self:setBigCellData(cell, rewardList[(i - 1) * CONST_DATA.Line + j])
      layout:addChild(cell, 0, i)
    end
  end
  layout:setContentSize(totalWidth, totalHeight)
  return layout
end
function RewardContainer:imagePanelTouch(sender, eventType)
  local reward = sender.reward
  if not reward then
    return
  end
  if ccui.TouchEventType.ended == eventType then
    if self.clickCallBack and self.clickCallBack(sender, eventType) then
      return
    end
    local rect = self:getBoundingBoxInWorldSpace(sender)
    rect.height = rect.height * self.parentScale
    rect.width = rect.width * self.parentScale
    if TaskMgr:isItemType(reward[1]) then
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = TaskMgr:spliteItemInfo(itemInfoList)
      if string.match(item.name, ".+=(F)") then
        self:showCommonReward(sender, reward)
      else
        local dlg = DlgMgr:openDlg("ItemInfoDlg")
        if item.name == CHS[5410026] then
          item.name = CHS[6400035]
        end
        if item.name == CHS[5410028] then
          item.name = CHS[6400034]
        end
        if item.name == CHS[5410029] then
          item.name = CHS[6400035]
        end
        if item.name == CHS[5400202] then
          item.name = CHS[5400196]
        end
        if item.name == CHS[4100230] then
          item.name = CHS[5440003]
        end
        if item.name == CHS[4100234] then
          item.name = CHS[5440004]
        end
        item.isGuard = InventoryMgr:getIsGuard(item.name)
        dlg:setInfoFormCard(item)
        dlg:setFloatingFramePos(rect)
      end
    elseif reward[1] == CHS[7000144] then
      if string.match(reward[2], ".+=(F)") then
        self:showCommonReward(sender, reward)
      elseif string.match(reward[2], "$id=") then
        self:showCommonReward(sender, reward)
      else
        local artifact = self:buildArtifact(reward[2])
        InventoryMgr:showArtifact(artifact, rect, true)
      end
    elseif reward[1] == CHS[7190683] then
      if string.match(reward[2], ".+=(F)") then
        self:showCommonReward(sender, reward)
      elseif string.match(reward[2], "$id=") then
        self:showCommonReward(sender, reward)
      else
        local horcrux = self:buildHorcrux(reward[2])
        InventoryMgr:showHorcurx(horcrux, rect, true)
      end
    elseif reward[1] == CHS[6200002] then
      self:showChangeCard(sender, reward)
    elseif reward[1] == CHS[3002169] then
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local itemInfo = TaskMgr:spliteItemInfo(itemInfoList)
      if string.match(itemInfoList[1], ".+=(T)") then
        local item = {}
        item.item_type = ITEM_TYPE.EQUIPMENT
        item.unidentified = 1
        item.name = itemInfo.name or ""
        item.level = itemInfo.level or 0
        item.req_level = itemInfo.level or 0
        item.limted = itemInfo.limted
        item.unidentified = 1
        item.color = CHS[3004104]
        local ItemInfo = InventoryMgr:getItemInfoByName(item.name)
        if ItemInfo and ItemInfo.req_level then
          item.req_level = ItemInfo.req_level
        end
        local dlg = DlgMgr:openDlg("ItemInfoDlg")
        dlg:setInfoFormCard(item)
        dlg:setFloatingFramePos(rect)
      else
        self:showCommonReward(sender, reward)
      end
    elseif reward[1] == CHS[3002174] then
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = self:buildItemForHSJ(itemInfoList)
      local dlg = DlgMgr:openDlg("ItemInfoDlg")
      dlg:setInfoFormCard(item)
      dlg:setFloatingFramePos(rect)
    elseif reward[1] == CHS[4100655] then
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
      InventoryMgr:showFashioEquip(item, rect, true)
    elseif reward[1] == CHS[5420176] then
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
      local furn = HomeMgr:getFurnitureInfo(item.name)
      if string.match(item.name, ".+=(F)") or not furn then
        self:showCommonReward(sender, reward)
      else
        item.item_type = ITEM_TYPE.FURNITURE
        InventoryMgr:showItemByItemData(item, rect)
      end
    elseif TaskMgr:isAboutMajorR(reward[1]) then
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
      local dlg = DlgMgr:openDlg("ItemInfoDlg")
      dlg:setInfoFormCard(item)
      dlg:setFloatingFramePos(rect)
    elseif reward[1] == CHS[2500097] then
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
      InventoryMgr:showItemByItemData(item, rect)
    else
      self:showCommonReward(sender, reward)
    end
  end
end
function RewardContainer:setBigCellData(cell, reward)
  local function imagePanelTouch(sender, eventType)
    self:imagePanelTouch(sender, eventType)
  end
  cell:addTouchEventListener(imagePanelTouch)
  cell.reward = reward
  local imgPath, textureResType = self:getRewardPath(reward)
  local iconImg = ccui.ImageView:create(imgPath, textureResType)
  iconImg:setPosition(cell:getContentSize().width / 2, cell:getContentSize().height / 2)
  iconImg:setAnchorPoint(0.5, 0.5)
  gf:setItemImageSize(iconImg)
  cell:addChild(iconImg)
  if self.imgCtrls then
    table.insert(self.imgCtrls, iconImg)
  end
  local itemInfoList = gf:splitBydelims(reward[2], {
    "%",
    "$",
    "#r"
  })
  local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
  if (DISPLAY_AMOUNT_TYPE[reward[1]] or self.allShowNum) and item.number and 1 < tonumber(item.number) and item.name ~= CHS[3002145] then
    Dialog.setNumImgForPanel(nil, cell, ART_FONT_COLOR.NORMAL_TEXT, item.number, false, LOCATE_POSITION.RIGHT_BOTTOM, 19)
  end
  if reward[1] == CHS[7000144] then
    item = self:buildArtifact(reward[2])
  end
  if reward[1] == CHS[3002169] then
    InventoryMgr:addLogoUnidentified(iconImg)
  end
  if item and item.time_limited then
    InventoryMgr:addLogoTimeLimit(iconImg)
  elseif item and item.limted then
    InventoryMgr:addLogoBinding(iconImg)
  end
  if reward[1] == CHS[7000144] and item.item_polar then
    InventoryMgr:addArtifactPolarImage(iconImg, item.item_polar)
  end
  if item.level and tonumber(item.level) > 0 then
    Dialog.setNumImgForPanel(nil, iconImg, ART_FONT_COLOR.NORMAL_TEXT, item.level, false, LOCATE_POSITION.LEFT_TOP, 19)
  end
end
function RewardContainer:showChangeCard(cell, reward)
  reward[2] = string.gsub(reward[2], "$%d+", "")
  local itemInfoList = gf:splitBydelims(reward[2], {
    "%",
    "$",
    "#r"
  })
  local item = TaskMgr:spliteChangeCardInfo(itemInfoList)
  if string.match(item.name, ".+=(F)") then
    self:showCommonReward(cell, reward)
  else
    local dlg = DlgMgr:openDlg("ChangeCardInfoDlg")
    item.icon = PetMgr:getPetIcon(item.name)
    dlg:setInfoFromItem(item, true)
    local rect = self:getBoundingBoxInWorldSpace(cell)
    dlg:setFloatingFramePos(rect)
  end
end
function RewardContainer:buildItemForHSJ(itemInfoList)
  local item = {}
  item.name = itemInfoList[1]
  item.level = tonumber(string.sub(itemInfoList[2], 2, -1))
  item.req_level = item.level
  item.upgrade_type = tonumber(string.sub(itemInfoList[3], 2, -1))
  item.extra = {}
  local field = string.sub(itemInfoList[4], 2, -1)
  local value
  if itemInfoList[5] == "$max" then
    value = EquipmentMgr:getAttribMaxValueByField(item, field)
  elseif itemInfoList[5] == "$min" then
    value = EquipmentMgr:getAttribMinValueByField(item, field)
  elseif itemInfoList[5] == "$std" then
    value = EquipmentMgr:getAttribStdValueByField(item, field)
  else
    value = tonumber(string.sub(itemInfoList[5], 2, -1))
    local max = EquipmentMgr:getAttribMaxValueByField(item, field)
    if value > max then
      value = max
    end
    local min = EquipmentMgr:getAttribMinValueByField(item, field)
    if value < min then
      value = min
    end
  end
  for i = 1, #itemInfoList do
    if string.match(itemInfoList[i], "%%bind") then
      item.limted = true
      if string.match(itemInfoList[i], "%%bind=(.*)") then
        item.gift = -tonumber(string.match(itemInfoList[i], "%%bind=(.*)")) - (gf:getServerTime() + Const.DELAY_TIME_BALANCE)
      else
        item.gift = 2
      end
    elseif string.match(itemInfoList[i], "%%deadline") then
      item.time_limited = true
      item.deadline = gf:convertStrToTime(string.match(itemInfoList[i], "%%deadline=(.*)"))
      local deadlineStr = string.match(itemInfoList[i], "%%deadline=(.*)")
      if tonumber(deadlineStr) then
        item.showLeftTime = tonumber(deadlineStr)
      end
      item.gift = 2
      item.limted = true
    end
  end
  item.extra[field .. "_2"] = value
  return item
end
function RewardContainer:buildArtifact(rewardStr)
  local artifact = {intimacy = 0, exp = 0}
  local hasLevelAlready = false
  local artifactInfoList = gf:splitBydelims(rewardStr, {"%", "$"})
  for i = 1, #artifactInfoList do
    if string.match(artifactInfoList[i], "%%bind") then
      artifact.limted = true
      if string.match(artifactInfoList[i], "%%bind=(.*)") then
        artifact.gift = -tonumber(string.match(artifactInfoList[i], "%%bind=(.*)")) - (gf:getServerTime() + Const.DELAY_TIME_BALANCE)
      else
        artifact.gift = 2
      end
    elseif string.match(artifactInfoList[i], "%%deadline") then
      artifact.time_limited = true
      artifact.deadline = gf:convertStrToTime(string.match(artifactInfoList[i], "%%deadline=(.*)"))
      local deadlineStr = string.match(artifactInfoList[i], "%%deadline=(.*)")
      if tonumber(deadlineStr) then
        artifact.showLeftTime = tonumber(deadlineStr)
      end
      artifact.gift = 2
      artifact.limted = true
    elseif string.match(artifactInfoList[i], "$friendliness=(.*)") then
      artifact.intimacy = tonumber(string.match(artifactInfoList[i], "$friendliness=(.*)"))
    elseif string.match(artifactInfoList[i], "$spskill=(.*)") then
      local skillNo = tonumber(string.match(artifactInfoList[i], "$spskill=(.*)"))
      artifact.extra_skill = ARTIFACT_SPSKILL[skillNo]
    elseif string.match(artifactInfoList[i], "$spskillLV=(.*)") then
      artifact.extra_skill_level = tonumber(string.match(artifactInfoList[i], "$spskillLV=(.*)"))
    elseif string.match(artifactInfoList[i], "$(%d)") then
      if hasLevelAlready then
        artifact.item_polar = tonumber(string.match(artifactInfoList[i], "$(.+)"))
      else
        artifact.level = tonumber(string.match(artifactInfoList[i], "$(.+)"))
        hasLevelAlready = true
      end
    elseif string.match(artifactInfoList[i], "$id=") then
    elseif string.match(artifactInfoList[i], "$nimbus=") then
      artifact.nimbus = tonumber(string.match(artifactInfoList[i], "$nimbus=(.*)"))
    elseif string.match(artifactInfoList[i], "$exp=") then
      artifact.exp = tonumber(string.match(artifactInfoList[i], "$exp=(.*)"))
    elseif string.match(artifactInfoList[i], "%%showdeadline") then
    else
      local name = artifactInfoList[i]
      if string.match(name, ".+=(F)") then
        name = string.match(name, "(.+)=F")
      end
      artifact.name = artifactInfoList[i]
    end
  end
  if artifact.level then
    artifact.exp_to_next_level = 30 * math.pow(artifact.level, 5) + 300 * math.pow(artifact.level, 3) + 1500
    if artifact.exp >= artifact.exp_to_next_level then
      artifact.exp = artifact.exp_to_next_level - 1
    end
    local maxNimbus = Formula:getArtifactMaxNimbus(artifact.level)
    if not artifact.nimbus then
      artifact.nimbus = maxNimbus
    end
    if maxNimbus < artifact.nimbus then
      artifact.nimbus = maxNimbus
    end
  end
  if artifact.extra_skill and not artifact.extra_skill_level then
    artifact.extra_skill_level = 1
  end
  return artifact
end
function RewardContainer:buildHorcrux(rewardStr)
  local horcrux = {
    skill_level = 1,
    upgrade_degree = 0,
    req_level = 75,
    horcrux_prop_count = 0,
    horcrux_prop_list = {}
  }
  local horcruxInfoList = gf:splitBydelims(rewardStr, {"%", "$"})
  for i = 1, #horcruxInfoList do
    if string.match(horcruxInfoList[i], "%%bind") then
      horcrux.limted = true
      if string.match(horcruxInfoList[i], "%%bind=(.*)") then
        horcrux.gift = -tonumber(string.match(horcruxInfoList[i], "%%bind=(.*)")) - (gf:getServerTime() + Const.DELAY_TIME_BALANCE)
      else
        horcrux.gift = 2
      end
    elseif string.match(horcruxInfoList[i], "%%deadline") then
      horcrux.time_limited = true
      horcrux.deadline = gf:convertStrToTime(string.match(horcruxInfoList[i], "%%deadline=(.*)"))
      local deadlineStr = string.match(horcruxInfoList[i], "%%deadline=(.*)")
      if tonumber(deadlineStr) then
        horcrux.showLeftTime = tonumber(deadlineStr)
      end
      horcrux.gift = 2
      horcrux.limted = true
    elseif string.match(horcruxInfoList[i], "$(%d)") then
      horcrux.req_level = tonumber(string.match(horcruxInfoList[i], "$(.+)"))
    elseif string.match(horcruxInfoList[i], "$slevel=(.*)") then
      horcrux.skill_level = tonumber(string.match(horcruxInfoList[i], "$slevel=(.*)"))
    elseif string.match(horcruxInfoList[i], "$id=") then
    else
      local name = horcruxInfoList[i]
      if string.match(name, ".+=(F)") then
        name = string.match(name, "(.+)=F")
      end
      horcrux.name = name
    end
  end
  return horcrux
end
function RewardContainer:setCellData(cell, reward)
  local function imagePanelTouch(sender, eventType)
    if ccui.TouchEventType.ended == eventType then
      if self.clickCallBack and self.clickCallBack(sender, eventType) then
        return
      end
      local rect = self:getBoundingBoxInWorldSpace(sender)
      rect.height = rect.height * self.parentScale
      rect.width = rect.width * self.parentScale
      if TaskMgr:isItemType(reward[1]) then
        local itemInfoList = gf:splitBydelims(reward[2], {
          "%",
          "$",
          "#r"
        })
        local item = TaskMgr:spliteItemInfo(itemInfoList)
        if string.match(item.name, ".+=(F)") then
          self:showCommonReward(cell, reward)
        else
          local dlg = DlgMgr:openDlg("ItemInfoDlg")
          dlg:setInfoFormCard(item)
          dlg:setFloatingFramePos(rect)
        end
      elseif reward[1] == CHS[7000144] then
        if string.match(reward[2], ".+=(F)") then
          self:showCommonReward(cell, reward)
        else
          local artifact = self:buildArtifact(reward[2])
          InventoryMgr:showArtifact(artifact, rect, true)
        end
      elseif reward[1] == CHS[7190683] then
        if string.match(reward[2], ".+=(F)") then
          self:showCommonReward(cell, reward)
        else
          local horcrux = self:buildHorcrux(reward[2])
          InventoryMgr:showHorcurx(horcrux, rect, true)
        end
      elseif reward[1] == CHS[6200002] then
        self:showChangeCard(cell, reward)
      elseif reward[1] == CHS[3002169] then
        local itemInfoList = gf:splitBydelims(reward[2], {
          "%",
          "$",
          "#r"
        })
        local itemInfo = TaskMgr:spliteItemInfo(itemInfoList)
        if string.match(itemInfo.name, ".+=(T)") then
          local item = {}
          item.item_type = ITEM_TYPE.EQUIPMENT
          item.unidentified = 1
          item.name = string.gsub(itemInfo.name, "=T", "")
          item.level = itemInfo.level or 0
          item.req_level = itemInfo.level or 0
          item.limted = itemInfo.limted
          item.color = CHS[3004104]
          local dlg = DlgMgr:openDlg("ItemInfoDlg")
          dlg:setInfoFormCard(item)
          dlg:setFloatingFramePos(rect)
        else
          self:showCommonReward(cell, reward)
        end
      elseif reward[1] == CHS[5420176] then
        local itemInfoList = gf:splitBydelims(reward[2], {
          "%",
          "$",
          "#r"
        })
        local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
        local furn = HomeMgr:getFurnitureInfo(item.name)
        if string.match(item.name, ".+=(F)") or not furn then
          self:showCommonReward(sender, reward)
        else
          item.item_type = ITEM_TYPE.FURNITURE
          InventoryMgr:showItemByItemData(item, rect)
        end
      elseif reward[1] == CHS[4100655] then
        local itemInfoList = gf:splitBydelims(reward[2], {
          "%",
          "$",
          "#r"
        })
        local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
        InventoryMgr:showFashioEquip(item, rect, true)
      elseif TaskMgr:isAboutMajorR(reward[1]) then
        local itemInfoList = gf:splitBydelims(reward[2], {
          "%",
          "$",
          "#r"
        })
        local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
        local dlg = DlgMgr:openDlg("ItemInfoDlg")
        dlg:setInfoFormCard(item)
        dlg:setFloatingFramePos(rect)
      elseif reward[1] == CHS[2500097] then
        local itemInfoList = gf:splitBydelims(reward[2], {
          "%",
          "$",
          "#r"
        })
        local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
        InventoryMgr:showItemByItemData(item, rect)
      else
        self:showCommonReward(cell, reward)
      end
    end
  end
  cell:addTouchEventListener(imagePanelTouch)
  local imgPath = self:getSamllImage(reward[1])
  local iconImg = ccui.ImageView:create(imgPath, ccui.TextureResType.plistType)
  iconImg:setPosition(0, cell:getContentSize().height / 2)
  iconImg:setAnchorPoint(0, 0.5)
  table.insert(self.imgCtrls, iconImg)
  cell:addChild(iconImg)
  gf:setSmallRewardImageSize(iconImg)
  local descStr = self:getRewardDesc(reward)
  local text = ccui.Text:create()
  text:setColor(self.defaultColor)
  text:setAnchorPoint(0, 0.5)
  text:setPosition(iconImg:getContentSize().width + 1, cell:getContentSize().height / 2)
  text:setString(descStr)
  text:setFontSize(19)
  cell:addChild(text)
end
function RewardContainer:getRewardInfo(reward)
  local rewardInfo = {}
  rewardInfo.imagePath, rewardInfo.resType = self:getRewardPath(reward)
  rewardInfo.basicInfo = self:getTextList(reward)
  rewardInfo.desc = rewardInfo.basicInfo[1] and REWAR_DESC[rewardInfo.basicInfo[1]] or REWAR_DESC[reward[1]]
  rewardInfo.time_limited, rewardInfo.time_limitedStr = TaskMgr:isTimeLimited(reward[2])
  if rewardInfo.time_limited then
    rewardInfo.limted, rewardInfo.limitedStr = TaskMgr:isLimited("%bind")
  else
    rewardInfo.limted, rewardInfo.limitedStr = TaskMgr:isLimited(reward[2])
  end
  return rewardInfo
end
function RewardContainer:showCommonReward(cell, reward)
  local rect = self:getBoundingBoxInWorldSpace(cell)
  rect.height = rect.height * self.parentScale
  rect.width = rect.width * self.parentScale
  local rewardInfo = self:getRewardInfo(reward)
  local dlg
  if rewardInfo.desc then
    dlg = DlgMgr:openDlg("BonusInfoDlg")
  else
    dlg = DlgMgr:openDlg("BonusInfo2Dlg")
  end
  dlg:setRewardInfo(rewardInfo)
  dlg.root:setAnchorPoint(0, 0)
  dlg:setFloatingFramePos(rect)
end
function RewardContainer:createRewardCell(reward)
  local layout = ccui.Layout:create()
  layout:setAnchorPoint(0.5, 0.5)
  local imgPath, textureResType = self:getRewardPath(reward)
  local iconImg = ccui.ImageView:create(imgPath, textureResType)
  iconImg:setAnchorPoint(0, 1)
  gf:setItemImageSize(iconImg)
  layout:addChild(iconImg)
  if reward[1] == CHS[3002170] or reward[1] == CHS[3002168] or reward[1] == CHS[3002169] or reward[1] == CHS[3002172] or reward[1] == CHS[3002166] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList)
    if item and item.time_limited then
      InventoryMgr:addLogoTimeLimit(iconImg)
    elseif item and item.limted then
      InventoryMgr:addLogoBinding(iconImg)
    end
  end
  if reward[1] == CHS[7000144] then
    local item = self:buildArtifact(reward[2])
    if item and item.time_limited then
      InventoryMgr:addLogoTimeLimit(iconImg)
    elseif item and item.limted then
      InventoryMgr:addLogoBinding(iconImg)
    end
  elseif reward[1] == CHS[7190683] then
    local item = self:buildHorcrux(reward[2])
    if item and item.time_limited then
      InventoryMgr:addLogoTimeLimit(iconImg)
    elseif item and item.limted then
      InventoryMgr:addLogoBinding(iconImg)
    end
  end
  if reward[1] == CHS[3002172] then
    if string.match(reward[2], "$Valid") then
      InventoryMgr:addLogoTimeLimit(iconImg)
    elseif string.match(reward[2], "%%bind") then
      InventoryMgr:addLogoBinding(iconImg)
    end
  end
  local textList = self:getTextList(reward)
  local textLayout = ccui.Layout:create()
  local textMaxWidth = 0
  local innerHeight = 0
  local colorListTable = {}
  for i = #textList, 1, -1 do
    if reward[1] == CHS[6000080] and i == 2 then
      textList[i] = gf:getMoneyDesc(tonumber(textList[i]))
    end
    local lableText = CGAColorTextList:create()
    lableText:setFontSize(18)
    lableText:setString(textList[i])
    lableText:setContentSize(CONST_DATA.WordWidth, 0)
    lableText:updateNow()
    local labelW, labelH = lableText:getRealSize()
    local colorLayer = tolua.cast(lableText, "cc.LayerColor")
    colorLayer:setAnchorPoint(0, 0)
    colorLayer:setPosition(0, innerHeight)
    textLayout:addChild(colorLayer)
    innerHeight = innerHeight + labelH
    table.insert(colorListTable, colorLayer)
    if textMaxWidth < labelW then
      textMaxWidth = labelW
    end
    if reward[1] == CHS[3002170] then
      lableText:setDefaultColor(textList.color.r, textList.color.g, textList.color.b)
    else
      lableText:setDefaultColor(COLOR3.TEXT_DEFAULT.r, COLOR3.TEXT_DEFAULT.g, COLOR3.TEXT_DEFAULT.b)
    end
  end
  textLayout:setContentSize(textMaxWidth, innerHeight)
  textLayout:setAnchorPoint(0, 0.5)
  layout:addChild(textLayout)
  for i = 1, #colorListTable do
    local lableText = tolua.cast(colorListTable[i], "CGAColorTextList")
    local x, y = colorListTable[i]:getPosition()
    local labelW, labelH = lableText:getRealSize()
    colorListTable[i]:setPosition((textMaxWidth - labelW) / 2, y)
  end
  local height = 0
  if innerHeight < iconImg:getContentSize().height then
    height = iconImg:getContentSize().height
  else
    height = innerHeight
  end
  iconImg:setPosition(0, height)
  textLayout:setPosition(iconImg:getContentSize().width + CONST_DATA.Space, height / 2)
  layout:setContentSize(iconImg:getContentSize().width + textMaxWidth + CONST_DATA.Space, height)
  return layout
end
function RewardContainer:getBoundingBoxInWorldSpace(node)
  if not node then
    return
  end
  local rect = node:getBoundingBox()
  local pt = node:convertToWorldSpace(cc.p(0, 0))
  rect.x = pt.x
  rect.y = pt.y
  return rect
end
function RewardContainer:getRewardPath(reward)
  local imgPath = ""
  local textureResType = ccui.TextureResType.plistType
  if reward[1] == CHS[6000079] then
    local isRidePet = false
    local rank = string.match(reward[2], ".+%((.+)%).*")
    if rank == CHS[6000519] or rank == CHS[6000520] then
      isRidePet = true
    end
    if string.match(reward[2], ".+=(F)") then
      if isRidePet then
        imgPath = ResMgr.ui.ride_pet_common
      else
        imgPath = ResMgr.ui.pet_common
      end
    else
      reward[2] = string.gsub(reward[2], CHS[6000310], CHS[5440001])
      reward[2] = string.gsub(reward[2], CHS[6000324], CHS[5440002])
      local content = gf:split(reward[2], "(")
      imgPath = ResMgr:getSmallPortrait(PetMgr:getPetIcon(content[1]))
      textureResType = ccui.TextureResType.localType
    end
  elseif TaskMgr:isItemType(reward[1]) then
    if string.match(reward[2], ".+=(F)") then
      imgPath = ResMgr.ui.item_common
    else
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = TaskMgr:spliteItemInfo(itemInfoList)
      if item.name == CHS[5410026] then
        item.name = CHS[6400035]
      end
      if item.name == CHS[5410028] then
        item.name = CHS[6400034]
      end
      if item.name == CHS[5410029] then
        item.name = CHS[6400035]
      end
      local icon = InventoryMgr:getIconByName(item.name)
      if InventoryMgr:getIsGuard(item.name) then
        imgPath = ResMgr:getSmallPortrait(icon)
      else
        imgPath = ResMgr:getItemIconPath(icon)
      end
      textureResType = ccui.TextureResType.localType
    end
  elseif reward[1] == CHS[7000144] then
    if string.match(reward[2], ".+=(F)") then
      imgPath = ResMgr.ui.big_artifact
    else
      local artifact = self:buildArtifact(reward[2])
      local icon = InventoryMgr:getIconByName(artifact.name)
      imgPath = ResMgr:getItemIconPath(icon)
      textureResType = ccui.TextureResType.localType
    end
  elseif reward[1] == CHS[7190683] then
    if string.match(reward[2], ".+=(F)") then
      imgPath = ResMgr.ui.big_horcrux
    else
      local horcrux = self:buildHorcrux(reward[2])
      local icon = InventoryMgr:getIconByName(horcrux.name)
      imgPath = ResMgr:getItemIconPath(icon)
      textureResType = ccui.TextureResType.localType
    end
  elseif reward[1] == CHS[6000041] then
    imgPath = ResMgr.ui.big_gold
  elseif reward[1] == CHS[6000042] then
    imgPath = ResMgr.ui.big_yinyuanbao
  elseif reward[1] == CHS[6000080] then
    imgPath = ResMgr.ui.big_cash
  elseif reward[1] == CHS[3002145] then
    imgPath = ResMgr.ui.voucher
  elseif string.match(reward[1], CHS[6000081]) then
    imgPath = ResMgr.ui.experience
  elseif reward[1] == CHS[3000049] then
    imgPath = ResMgr.ui.daohang
  elseif reward[1] == CHS[3000050] then
    imgPath = ResMgr.ui.big_wuxue
  elseif reward[1] == CHS[5400594] then
    imgPath = ResMgr.ui.big_tao_wu
  elseif reward[1] == CHS[4300075] then
    imgPath = ResMgr.ui.shuadao_jifen
  elseif reward[1] == CHS[3002151] then
    imgPath = ResMgr.ui.pot_icon
  elseif reward[1] == CHS[7000282] then
    imgPath = ResMgr.ui.big_daofa
  elseif reward[1] == CHS[7000284] then
    imgPath = ResMgr.ui.big_ziqihongmeng
  elseif reward[1] == CHS[4300527] then
    imgPath = ResMgr.ui.small_gaojituoguan
  elseif reward[1] == CHS[3002169] or reward[1] == CHS[3002168] or reward[1] == CHS[3002170] then
    if string.match(reward[2], ".+=(T)") then
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = TaskMgr:spliteItemInfo(itemInfoList)
      item.name = string.gsub(item.name, "=T", "")
      local icon = InventoryMgr:getIconByName(item.name)
      imgPath = ResMgr:getItemIconPath(icon)
      textureResType = ccui.TextureResType.localType
    elseif reward[1] == CHS[3002169] then
      imgPath = ResMgr.ui.big_identify_equip
    elseif reward[1] == CHS[3002168] then
      imgPath = ResMgr.ui.big_jewelry
    elseif reward[1] == CHS[3002170] then
      imgPath = ResMgr.ui.big_equip
    end
  elseif reward[1] == CHS[3002171] or reward[1] == CHS[4100818] then
    imgPath = ResMgr.ui.title
  elseif reward[1] == CHS[3002157] then
    imgPath = ResMgr.ui.big_banggong
  elseif reward[1] == CHS[3002159] then
    imgPath = ResMgr.ui.big_party_active
  elseif reward[1] == CHS[3002163] then
    imgPath = ResMgr.ui.big_reputation
  elseif reward[1] == CHS[3002161] then
    imgPath = ResMgr.ui.big_party_contribution
  elseif reward[1] == CHS[3002173] then
    imgPath = ResMgr.ui.reward_big_VIP
  elseif reward[1] == CHS[3002174] then
    imgPath = ResMgr:getIconPathByName(CHS[3002174])
    textureResType = ccui.TextureResType.localType
  elseif reward[1] == CHS[6000222] then
    imgPath = ResMgr.ui.jdong_card
  elseif reward[1] == CHS[6400008] then
    imgPath = ResMgr.ui.get_reward_icon
  elseif reward[1] == CHS[6200002] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteChangeCardInfo(itemInfoList)
    if string.match(reward[2], ".+=(F)") then
      imgPath = ResMgr.ui.big_change_card
    else
      local icon = InventoryMgr:getIconByName(item.name)
      imgPath = ResMgr:getItemIconPath(icon)
      textureResType = ccui.TextureResType.localType
    end
  elseif reward[1] == CHS[6000260] then
    imgPath = ResMgr.ui.big_friendly_icon
  elseif reward[1] == CHS[6400052] then
    imgPath = ResMgr.ui.big_skill_icon
  elseif reward[1] == CHS[6200024] then
    imgPath = ResMgr.ui.big_off_line_time
  elseif reward[1] == CHS[5420113] then
    imgPath = ResMgr.ui.big_gold_rose
  elseif reward[1] == CHS[4200315] then
    imgPath = ResMgr.ui.huiguiScore
  elseif reward[1] == CHS[4200316] then
    imgPath = ResMgr.ui.zhaohuiScore
  elseif reward[1] == CHS[2000244] then
    imgPath = ResMgr.ui.big_polar_upper
  elseif reward[1] == CHS[2000245] then
    imgPath = ResMgr.ui.big_level_upper
  elseif reward[1] == CHS[4100655] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
    local icon = InventoryMgr:getIconByName(item.name)
    imgPath = ResMgr:getItemIconPath(icon)
    textureResType = ccui.TextureResType.localType
  elseif TaskMgr:isAboutMajorR(reward[1]) then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
    local icon = InventoryMgr:getIconByName(item.name)
    imgPath = ResMgr:getItemIconPath(icon)
    textureResType = ccui.TextureResType.localType
  elseif reward[1] == CHS[5420169] then
    local itemInfoList = gf:splitBydelims(reward[2], {"#r"})
    if itemInfoList[1] == CHS[5420535] then
      imgPath = ResMgr.ui.big_qmpk_jiangjin
    else
      local icon = ITEMNAME_UI_ICONPATH[itemInfoList[1]]
      if icon then
        imgPath = icon
        textureResType = ccui.TextureResType.localType
      else
        imgPath = ResMgr.ui.big_object_reward
      end
    end
  elseif reward[1] == CHS[5420170] then
    local itemInfoList = gf:splitBydelims(reward[2], {"#r"})
    local icon = ITEMNAME_UI_ICONPATH[itemInfoList[1]]
    if icon then
      imgPath = icon
      textureResType = ccui.TextureResType.localType
    else
      imgPath = ResMgr.ui.big_call_cost_reward
    end
  elseif reward[1] == CHS[4101785] then
    imgPath = ResMgr.ui.big_change_polar
  elseif reward[1] == CHS[7100152] then
    imgPath = ResMgr.ui.big_attrib_point
  elseif reward[1] == CHS[7100153] then
    imgPath = ResMgr.ui.big_polar_point
  elseif reward[1] == CHS[4010118] then
    imgPath = ResMgr.ui.big_xianmo_point
  elseif reward[1] == CHS[5450185] then
    imgPath = ResMgr.ui.big_jewelry_essence
  elseif reward[1] == CHS[5400801] then
    imgPath = ResMgr.ui.big_item_lingchen
    textureResType = ccui.TextureResType.localType
  elseif reward[1] == CHS[5450506] then
    imgPath = ResMgr.ui.big_item_guiqi
  elseif reward[1] == CHS[5410345] then
    imgPath = ResMgr.ui.big_item_digongmoney
  elseif reward[1] == CHS[5410346] then
    imgPath = ResMgr.ui.big_item_yangqizhi
  elseif reward[1] == CHS[5420524] then
    imgPath = ResMgr.ui.big_qmpk_jcb
  elseif reward[1] == CHS[5420304] then
    imgPath = ResMgr.ui.big_chongfengsan
  elseif reward[1] == CHS[7100257] then
    imgPath = ResMgr.ui.big_inn_coin
  elseif reward[1] == CHS[7190229] then
    imgPath = ResMgr.ui.big_tan_an_score
  elseif reward[1] == CHS[4200712] then
    imgPath = ResMgr.ui.small_child_qinmidu
  elseif reward[1] == CHS[2500093] then
    imgPath = ResMgr.ui.small_shenhun_yqzc
  elseif reward[1] == CHS[2500095] then
    imgPath = ResMgr.ui.small_shenhun_yd
  elseif reward[1] == CHS[5410471] then
    imgPath = ResMgr.ui.big_mjsl_score
  elseif reward[1] == CHS[2500097] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
    imgPath = ResMgr:getItemIconPath(item.icon)
    textureResType = ccui.TextureResType.localType
  elseif reward[1] == CHS[7190534] then
    imgPath = ResMgr.ui.big_qinmidu
  elseif reward[1] == CHS[7190592] then
    imgPath = PetExploreTeamMgr:getMaterialIconByName(reward[2])
    textureResType = ccui.TextureResType.localType
  elseif reward[1] == CHS[7120211] then
    imgPath = ResMgr.ui.big_wawazizhi
  elseif reward[1] == CHS[7190683] then
    imgPath = ResMgr.ui.big_horcrux
  elseif reward[1] == CHS[7100975] then
    imgPath = ResMgr.ui.big_party_gongxun
  elseif reward[1] == CHS[5420176] then
    if string.match(reward[2], ".+=(F)") then
      imgPath = ResMgr.ui.item_common
    else
      local itemInfoList = gf:splitBydelims(reward[2], {
        "%",
        "$",
        "#r"
      })
      local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
      local icon = HomeMgr:getFurnitureIcon(item.name)
      if not icon then
        imgPath = ResMgr.ui.item_common
      else
        imgPath = ResMgr:getItemIconPath(icon)
        textureResType = ccui.TextureResType.localType
      end
    end
  else
    imgPath = ResMgr.ui.others_icon
  end
  return imgPath, textureResType
end
function RewardContainer:getTextList(reward)
  local textList = {}
  if reward[1] == CHS[6000079] then
    if string.match(reward[2], ".+=(F)") then
      textList[1] = string.match(reward[2], "(.+)=F.*")
      local petName, petRank, skillNum = string.match(textList[1], "(.+)%((.+)%).*$.*$(.).*")
      if not petName then
        petName, petRank = string.match(reward[2], "(.+)%((.+)%)")
      end
      if petName then
        textList[1] = petName
      end
    else
      local petName, petRank, skillNum = string.match(reward[2], "(.+)%((.+)%).*$.*$(.).*")
      if not petName then
        petName, petRank = string.match(reward[2], "(.+)%((.+)%)")
      end
      skillNum = tonumber(skillNum)
      if nil == skillNum then
        skillNum = 0
      end
      textList[1] = string.format("%s%s", SKILL_NUM[skillNum], petName)
      textList[2] = string.format("(%s)", petRank)
    end
  elseif reward[1] == CHS[7000144] then
    if string.match(reward[2], ".+=(F)") then
      textList[1] = string.match(reward[2], "(.+)=F.*")
    else
      local artifact = self:buildArtifact(reward[2])
      textList[1] = artifact.name
    end
  elseif reward[1] == CHS[7190683] then
    if string.match(reward[2], ".+=(F)") then
      textList[1] = CHS[7190683]
    else
      local horcrux = self:buildHorcrux(reward[2])
      textList[1] = horcrux.name
    end
  elseif reward[1] == CHS[6200002] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteChangeCardInfo(itemInfoList)
    textList[1] = string.match(item.name, "(.+)=F.*") or item.name
  elseif reward[1] == CHS[6000082] then
    textList[1] = reward[2]
  elseif reward[1] == CHS[3002168] or reward[1] == CHS[3002169] or reward[1] == CHS[3002170] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList)
    textList[1] = item.name
    textList.color = item.color
  elseif reward[1] == CHS[3002171] or reward[1] == CHS[4100818] then
    textList = gf:split(reward[2], "#r")
    local content = gf:split(textList[1], "$")
    textList[1] = content[1]
    if textList[2] then
      local content2 = gf:split(textList[2], "$")
      textList[2] = content2[1]
    end
  elseif reward[1] == CHS[3002166] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList)
    textList[1] = item.name
    textList[1] = string.gsub(textList[1], "=F", "")
  elseif reward[1] == CHS[3002173] then
    textList[1] = string.match(reward[2], "(.*)$Time=%d+")
    if textList[1] then
      textList[1] = gf:replaceVipStr(textList[1])
      local pos = gf:findStrByByte(reward[2], "$Time=")
      if nil ~= pos then
        textList[2] = string.sub(reward[2], pos + 6, -1) .. CHS[3002175]
      else
        gf:ShowSmallTips(CHS[3002176])
        textList[2] = CHS[3002177]
      end
    else
      textList[1] = gf:replaceVipStr(reward[2])
    end
  elseif reward[1] == CHS[6000041] then
    textList = gf:split(reward[2], "#r")
    if string.match(textList[2], "(%d+)+(%d+)") then
      local A, B = string.match(textList[2], "(%d+)+(%d+)")
      textList[2] = tonumber(A) + tonumber(B)
    end
  elseif reward[1] == CHS[6000260] then
    local list = gf:splitBydelims(reward[2], {"$", "#r"})
    local friendlyInfo = TaskMgr:spliteFriendlyInfo(list)
    textList[1] = friendlyInfo.name
    textList[2] = friendlyInfo.number
  elseif reward[1] == CHS[6200024] then
    textList = gf:split(reward[2], "#r")
    if textList[2] then
      local time = tonumber(textList[2])
      textList[2] = SystemMessageMgr:getTimeStr(time)
    end
  elseif reward[1] == CHS[3000059] then
    textList[1] = string.match(reward[2], "(.+)=F.*") or reward[2]
  elseif reward[1] == CHS[5420176] then
    local list = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local str = string.match(list[1], "(.+)=F.*")
    str = str or list[1]
    textList[1] = str
  elseif reward[1] == CHS[3002147] then
    textList = gf:split(reward[2], "#r")
    if textList[2] then
      textList[2] = gf:getTaoStr(tonumber(textList[2]), 0)
    end
  elseif string.match(reward[1], CHS[6000081]) then
    local list = gf:splitBydelims(reward[2], {"$", "#r"})
    local item = TaskMgr:spliteExpCardInfo(list)
    textList[1] = item.name
    textList[2] = item.number
  elseif reward[1] == CHS[4300527] then
    textList = gf:split(reward[2], "#r")
    textList[2] = GetTaoMgr:getLeftSuperTrusteeshipTime(tonumber(textList[2]))
  else
    textList = gf:split(reward[2], "#r")
  end
  return textList
end
function RewardContainer:getSamllImage(name)
  return TaskMgr:getSamllImage(name)
end
function RewardContainer:getRewardDesc(reward)
  local descStr = ""
  if reward[1] == CHS[6000079] then
    if string.match(reward[2], ".+=(F)") then
      descStr = string.match(reward[2], "(.+)=F.*")
    else
      descStr = string.match(reward[2], "(.+%(.+%)).*")
    end
  elseif reward[1] == CHS[7190683] then
    if string.match(reward[2], ".+=(F)") then
      descStr = string.match(reward[2], "(.+)=F.*")
    else
      local artifact = self:buildArtifact(reward[2])
      descStr = artifact.name
    end
  elseif reward[1] == CHS[7000144] then
    if string.match(reward[2], ".+=(F)") then
      descStr = string.match(reward[2], "(.+)=F.*")
    else
      local horcrux = self:buildHorcrux(reward[2])
      descStr = horcrux.name
    end
  elseif reward[1] == CHS[6200002] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteChangeCardInfo(itemInfoList)
    descStr = string.match(item.name, "(.+)=F.*") or item.name
  elseif reward[1] == CHS[3002166] or reward[1] == CHS[3002170] or reward[1] == CHS[3002168] or reward[1] == CHS[3002169] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "$",
      "%",
      "#r"
    })
    descStr = itemInfoList[1]
    if itemInfoList[2] and string.match(itemInfoList[2], "$Alias=") then
      descStr = string.match(itemInfoList[2], "$Alias=(.+)")
    end
    if reward[1] == CHS[3002170] or reward[1] == CHS[3002168] or reward[1] == CHS[3002169] then
      descStr = string.gsub(descStr, "=T", "")
    elseif reward[1] == CHS[3002166] then
      descStr = string.gsub(descStr, "=F", "")
    end
  elseif reward[1] == CHS[3002171] or reward[1] == CHS[4100818] then
    local textList = gf:split(reward[2], "#r")
    local content = gf:split(textList[1], "$")
    descStr = content[1] .. (textList[2] or "")
  elseif reward[1] == CHS[3002173] then
    descStr = string.match(reward[2], "(.*)$Time=%d+") or descStr
  elseif reward[1] == CHS[6000260] then
    local list = gf:splitBydelims(reward[2], {"$", "#r"})
    local friendlyInfo = TaskMgr:spliteFriendlyInfo(list)
    if friendlyInfo.number then
      descStr = friendlyInfo.name .. "*" .. friendlyInfo.number
    else
      descStr = friendlyInfo.name
    end
  elseif reward[1] == CHS[5420176] then
    local list = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    descStr = string.match(list[1], "(.+)=F.*")
    descStr = descStr or list[1]
  elseif reward[1] == CHS[5000280] then
    local list = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(list, reward)
    descStr = item.name
  elseif TaskMgr:isAboutMajorR(reward[1]) then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
    descStr = item.name
  elseif reward[1] == CHS[2500097] then
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteChangeCardInfo(itemInfoList)
    descStr = string.match(item.name, "(.+)=F.*") or item.name
  else
    descStr = string.gsub(reward[2], "#r", "*")
  end
  return descStr
end
function RewardContainer:callBack(funcName, ...)
  if not self.obj then
    return
  end
  local func = self.obj[funcName]
  if self.obj and func then
    func(self.obj, ...)
  end
end
function RewardContainer:grayAllReward()
  for i = 1, #self.imgCtrls do
    gf:grayImageView(self.imgCtrls[i])
  end
end
function RewardContainer:grayOneReward(rewardName)
  for i = 1, #self.imgCtrls do
    local reward = self.imgCtrls[i]:getParent().reward
    if reward and reward[2] and string.match(reward[2], rewardName) then
      gf:grayImageView(self.imgCtrls[i])
    end
  end
end
function RewardContainer:resetAllReward()
  for i = 1, #self.imgCtrls do
    gf:resetImageView(self.imgCtrls[i])
  end
end
return RewardContainer
