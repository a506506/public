local PartyDailyTaskTest = Singleton("PartyDailyTaskTest", DebugBase)
function PartyDailyTaskTest:init()
end
function PartyDailyTaskTest:cleanup()
end
function PartyDailyTaskTest:run()
  self:log("帮派日常挑战测试略过")
  self:finish()
end
return PartyDailyTaskTest
