local CardTest = Singleton("CardTest", DebugBase)
function CardTest:init()
end
function CardTest:cleanup()
  DlgMgr:closeDlg("UserCardDlg")
  DlgMgr:closeDlg("ChannelDlg")
  DlgMgr:closeDlg("LinkAndExpressionDlg")
end
function CardTest:run()
  self:log("开始名片测试")
  if not DlgMgr:isDlgOpened("ChatDlg") then
    self:log("#R无法找到聊天界面#n")
    self:finish()
    return
  end
  DlgMgr:sendMsg("ChatDlg", "onChatButton")
  if not DlgMgr:isDlgOpened("ChannelDlg") then
    self:log("#R无法找到频道界面#n")
    self:finish()
    return
  end
  local dlg = DlgMgr:getDlgByName("ChannelDlg")
  if not dlg then
    return
  end
  local radioGroup = dlg.radioGroup
  radioGroup:selectRadio(1)
  DlgMgr:sendMsg("ChannelDlg", "setChannelInputChat", 1, "onExpressionButton")
  self:checkDlg(function(s, e)
    if 1 == s then
      self:sendCard()
    else
      self:log(e)
      self:finish()
    end
  end, "LinkAndExpressionDlg")
end
function CardTest:sendCard()
  DlgMgr:sendMsg("LinkAndExpressionDlg", "onCharButton")
  DlgMgr:sendMsg("LinkAndExpressionDlg", "onSendButton")
  DlgMgr:sendMsg("LinkAndExpressionDlg", "onCloseButton")
  self:checkData()
end
function CardTest:checkData(checkStartTime)
  checkStartTime = checkStartTime or gf:getServerTime()
  local dlg = DlgMgr:getDlgByName("ChannelDlg")
  if not dlg then
    self:log("#R无法完成名片测试(1)#n")
    finish()
    return
  end
  local singleChatPanel = dlg.channelPanelTable.CurrentCheckBox
  if not singleChatPanel then
    self:log("#R无法完成名片测试(2)#n")
    self:finish()
    return
  end
  local chatPanel = singleChatPanel.chatPanel
  if not chatPanel then
    self:log("#R无法完成名片测试(3)#n")
    self:finish()
    return
  end
  local scrollview = chatPanel.scroview
  if not scrollview then
    if gf:getServerTime() - checkStartTime < 30 then
      self:delay(function()
        self:checkData(checkStartTime)
      end, 1)
    else
      self:log("#R无法完成名片测试(4)#n")
      self:finish()
    end
    return
  end
  local content = scrollview:getChildByTag(999)
  if not content then
    self:log("#R无法完成名片测试(5)#n")
    self:finish()
    return
  end
  for i = 1, #chatPanel.chatTabel do
    local sc = content:getChildByTag(i)
    if not sc then
      if gf:getServerTime() - checkStartTime < 30 then
        self:delay(function()
          self:checkData(checkStartTime)
        end, 1)
      else
        self:log("#R无法完成名片测试(6)#n")
        self:finish()
      end
      return
    end
    local children = sc:getChildren()
    if #children >= 2 then
      local textCtrl = children[2]:getChildByName("ChatContent")
      local csType = tolua.cast(textCtrl, "CGAColorTextList"):getCsType()
      local str = tolua.cast(textCtrl, "CGAColorTextList"):getString()
      if csType == 8 and string.match(str, string.format("{\t%s=", Me:getName())) then
        self:tapCtrl(textCtrl)
      end
    end
  end
  local isFound = DlgMgr:isDlgOpened("UserCardDlg")
  if not isFound then
    if gf:getServerTime() - checkStartTime < 30 then
      self:delay(function()
        self:checkData(checkStartTime)
      end, 1)
    else
      self:log("#R无法完成名片测试#n, %d, %d, %d", gf:getServerTime(), checkStartTime, gf:getServerTime() - checkStartTime)
      self:finish()
    end
  else
    self:delay(function()
      self:log("完成名片测试")
      self:finish()
    end, 0)
  end
end
return CardTest
