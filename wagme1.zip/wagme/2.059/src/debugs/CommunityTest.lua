local CommunityTest = Singleton("CommunityTest", DebugBase)
function CommunityTest:run()
  if not DlgMgr:isDlgOpened("SystemFunctionDlg") then
    self:log("无法打开微社区！")
  else
    self:log("开始打开微社区")
    DlgMgr:sendMsg("SystemFunctionDlg", "onCommunityButton", DlgMgr:getDlgByName("SystemFunctionDlg"):getControl("CommunityButton"))
    self:checkFinish()
  end
end
function CommunityTest:checkFinish(t)
  if self.isPaused then
    return
  end
  if gf:isWindows() then
    self:log("打开微社区成功")
    self:finish()
    return
  end
  t = t or gf:getServerTime()
  local dlg = DlgMgr:getDlgByName("CommunityDlg")
  if not dlg then
    if t - gf:getServerTime() < 30 then
      self:delay(function()
        self:checkFinish()
      end, 0)
    else
      self:log("打开微社区失败")
      self:finish()
    end
    return
  end
  if dlg.webView:isVisible() then
    self:log("打开微社区成功")
    self:delay(function()
      dlg:onCloseButton()
      self:finish()
    end, 1)
  elseif t - gf:getServerTime() < 30 then
    self:delay(function()
      self:checkFinish()
    end, 0)
  else
    self:log("打开微社区失败")
    self:finish()
  end
end
function CommunityTest:onResume()
  self:checkFinish()
end
return CommunityTest
