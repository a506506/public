local JubaoZhaiTest = Singleton("JubaoZhaiTest", DebugBase)
function JubaoZhaiTest:init()
  self.isFinish = nil
  self:hookMsg("MSG_TRADING_GOODS_LIST")
end
function JubaoZhaiTest:cleanup()
  self.isFinish = nil
  self.isPaused = nil
end
function JubaoZhaiTest:run()
  local dlg = DlgMgr:getDlgByName("SystemFunctionDlg")
  if not dlg then
    self:log("聚宝斋测试失败")
    self:finish()
    return
  end
  local showButton = dlg:getControl("ShowTradeButton")
  if showButton:isVisible() then
    DlgMgr:sendMsg("SystemFunctionDlg", "onTradeButton")
  end
  DlgMgr:sendMsg("SystemFunctionDlg", "onJubaoButton")
  local tabDlg = DlgMgr:getDlgByName("JuBaoZhaiTabDlg")
  local ctrl = tabDlg:getControl("JuBaoZhaiSellDlgCheckBox")
  self:tapCtrl(ctrl)
  dlg = DlgMgr:getDlgByName("JuBaoZhaiSellDlg")
  if not dlg then
    self:log("聚宝斋测试失败")
    self:finish()
    return
  end
  local list = dlg:getControl("GoodsTypeListView", nil, "SellPanel")
  local items = list:getItems()
  for i = 1, #items do
    local item = items[i]
    if item:getName() == "角  色" then
      DlgMgr:sendMsg("JuBaoZhaiSellDlg", "onClickBigMenu", item)
      break
    end
  end
end
function JubaoZhaiTest:MSG_TRADING_GOODS_LIST(data)
  self.isFinish = true
  if not self.isPaused then
    self:log("聚宝斋测试成功")
    self:delay(function()
      DlgMgr:sendMsg("JuBaoZhaiSellDlg", "onCloseButton")
    end, 0)
    self:finish()
  end
end
function JubaoZhaiTest:onResume()
  if self.isFinish then
    self:MSG_TRADING_GOODS_LIST()
  end
end
return JubaoZhaiTest
