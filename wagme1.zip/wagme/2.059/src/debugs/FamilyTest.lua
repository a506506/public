local FamilyTest = Singleton("FamilyTest", DebugBase)
function FamilyTest:init()
  self:hookMsg("MSG_TASK_PROMPT")
  self:hookMsg("MSG_PLAY_SCENARIOD")
  self:hookMsg("MSG_GENERAL_NOTIFY")
  self:hookMsg("MSG_C_WAIT_COMMAND")
  self:hookMsg("MSG_GOODS_LIST")
  self:hookMsg("MSG_MENU_LIST")
  self:hookMsg("MSG_OPEN_EXCHANGE_SHOP")
  self:hookMsg("MSG_SUBMIT_PET")
  self:hookMsg("MSG_LIVENESS_INFO")
  self:hookMsg("MSG_ICON_CARTOON")
  EventDispatcher:addEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:addEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function FamilyTest:cleanup()
  EventDispatcher:removeEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:removeEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function FamilyTest:run()
  self:log("开始师门任务测试")
  if not PracticeMgr:getIsUseExorcism() then
    gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_OPEN_EXORCISM)
    self:checkExorcism()
  else
    self:doTask()
  end
end
function FamilyTest:checkExorcism()
  if not PracticeMgr:getIsUseExorcism() then
    self:delay(function()
      self:checkExorcism()
    end, 0)
  else
    self:doTask()
  end
end
function FamilyTest:doTask()
  if TaskMgr:getSMTask() then
    decStr = TaskMgr:getSMTask()
  else
    local npcName = gf:getPolarNPC(tonumber(Me:queryBasic("polar")))
    decStr = string.format(CHS[3002200], npcName)
  end
  local dest = gf:findDest(decStr)
  if dest then
    AutoWalkMgr:beginAutoWalk(dest)
    self:checkNpc(dest.npc, 1)
  else
    local tempStr = string.match(decStr, "#@.+#@")
    tempStr = tempStr and string.match(decStr, "|.+=.+")
    if tempStr then
      tempStr = string.sub(tempStr, 2)
      tempStr = string.sub(tempStr, 1, -3)
      DlgMgr:openDlgWithParam(tempStr)
      if DlgMgr:isDlgOpened("FastUseItemDlg") then
        DlgMgr:sendMsg("FastUseItemDlg", "onUseButton")
      end
    end
  end
end
function FamilyTest:checkTask()
  local decStr
  if TaskMgr:getSMTask() then
    decStr = TaskMgr:getSMTask()
    self:log("当前任务：%s", decStr)
  else
    ActivityMgr:getActiviInfo()
  end
end
function FamilyTest:MSG_TASK_PROMPT()
  self:checkTask()
  self.curMoney = 1500
end
function FamilyTest:MSG_GENERAL_NOTIFY(data)
  if NOTIFY.NOTIFY_OPEN_DLG == data.notify and data.para == "DonateDlgDlg" then
    self:delay(function()
      DlgMgr:getDlgByName("DonateDlgDlg").totalMoney = self.curMoney
      DlgMgr:sendMsg("DonateDlgDlg", "setNumber")
      DlgMgr:sendMsg("DonateDlgDlg", "onDonateButton")
      self.curMoney = self.curMoney + 100
    end, 0)
  end
end
function FamilyTest:MSG_MENU_LIST(data)
  local npcName = data.name
  local menuIndex = 1
  if not CharMgr:getCharByName(npcName) then
    self:delay(function()
      if DlgMgr:isDlgOpened("NpcDlg") then
        self:log("和#Y%s#n对话，选择菜单:%s", tostring(npcName), tostring(menuIndex))
        self:selectMenu(menuIndex)
        if "function" == type(callback) then
          callback()
        end
      else
        self:log("#R没有找到菜单界面#n")
      end
    end, 0.1)
  else
    self:delay(function()
      if DlgMgr:isDlgOpened("NpcDlg") then
        self:log("和#Y%s#n对话，选择菜单:%s", tostring(npcName), tostring(menuIndex))
        self:selectMenu(menuIndex)
        if "function" == type(callback) then
          callback()
        end
      end
    end, 0.3)
  end
end
function FamilyTest:MSG_LIVENESS_INFO()
  if ActivityMgr:getActivityCurTimes("师门任务") >= 10 then
    self:log("完成师门任务测试")
    self:finish()
  end
end
return FamilyTest
