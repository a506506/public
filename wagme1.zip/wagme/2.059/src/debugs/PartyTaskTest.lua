local PartyTaskTest = Singleton("PartyTaskTest", DebugBase)
function PartyTaskTest:init()
  self:hookMsg("MSG_TASK_PROMPT")
  self:hookMsg("MSG_PLAY_SCENARIOD")
  self:hookMsg("MSG_GOODS_LIST")
  self:hookMsg("MSG_OPEN_EXCHANGE_SHOP")
  self:hookMsg("MSG_SUBMIT_PET")
  self:hookMsg("MSG_LIVENESS_INFO")
  self:hookMsg("MSG_C_WAIT_COMMAND")
  EventDispatcher:addEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:addEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function PartyTaskTest:cleanup()
  EventDispatcher:removeEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:removeEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function PartyTaskTest:checkParty(time)
  time = time or gf:getServerTime()
  if string.isNilOrEmpty(Me:queryBasic("party")) then
    if time - gf:getServerTime() < 30 then
      self:delay(function()
        self:checkParty(time)
      end, 1)
    else
      self:log("#R无法完成帮派任务(缺少帮派)#n")
      self:finish()
    end
  else
    self:doTask()
  end
end
function PartyTaskTest:run()
  local decStr
  if string.isNilOrEmpty(Me:queryBasic("party")) then
    PartyMgr:queryPartyInfo()
    self:checkParty()
    return
  end
  self:doTask()
end
function PartyTaskTest:doTask()
  if TaskMgr:getPartyTask() then
    decStr = TaskMgr:getPartyTask()
  else
    decStr = CHS[3002215]
  end
  local dest = gf:findDest(decStr)
  AutoWalkMgr:beginAutoWalk(dest)
  self:checkNpc(dest.npc, 1, function(menuText)
    if string.match(menuText, "扫荡帮派任务") then
      self:log("完成帮派扫荡任务")
      self:finish()
    end
  end)
end
function PartyTaskTest:checkTask()
  local task = TaskMgr:getPartyTask()
  if task then
    self:log("当前任务：%s", task)
  else
    gf:CmdToServer("CMD_ACTIVITY_LIST")
    ActivityMgr:getActiviInfo()
  end
end
function PartyTaskTest:MSG_TASK_PROMPT()
  self:checkTask()
end
function PartyTaskTest:MSG_GOODS_LIST()
  self:delay(function()
    if DlgMgr:isDlgOpened("PharmacyDlg") then
      DlgMgr:sendMsg("PharmacyDlg", "onBuyButton")
    elseif DlgMgr:isDlgOpened("GroceryStoreDlg") then
      DlgMgr:sendMsg("GroceryStoreDlg", "onBuyButton")
    end
  end, 0)
end
function PartyTaskTest:MSG_OPEN_EXCHANGE_SHOP()
  self:delay(function()
    if DlgMgr:isDlgOpened("RowSkillShopDlg") then
      DlgMgr:sendMsg("RowSkillShopDlg", "onBuyButton")
    elseif DlgMgr:isDlgOpened("PetShopDlg") then
      DlgMgr:sendMsg("PetShopDlg", "onBuyButton")
    elseif DlgMgr:isDlgOpened("GoodValueDlg") then
      DlgMgr:sendMsg("GoodValueDlg", "onBuyButton")
    elseif DlgMgr:isDlgOpened("JungongShopDlg") then
      DlgMgr:sendMsg("JungongShopDlg", "onBuyButton")
    end
  end, 0)
end
function PartyTaskTest:MSG_SUBMIT_PET()
  self:delay(function()
    if DlgMgr:isDlgOpened("SubmitPetDlg") then
      DlgMgr:sendMsg("SubmitPetDlg", "onSubmitButton")
    end
  end, 0)
end
function PartyTaskTest:MSG_LIVENESS_INFO()
  if ActivityMgr:getActivityCurTimes("帮派任务") >= 10 then
    self:log("完成帮派任务测试")
    self:finish()
  end
end
return PartyTaskTest
