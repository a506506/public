local SwitchLine = Singleton("SwitchLine", DebugBase)
function SwitchLine:init()
  self:hookMsg("MSG_ENTER_GAME")
end
function SwitchLine:cleanup()
  self.toServerName = nil
end
function SwitchLine:run()
  DlgMgr:sendMsg("SystemFunctionDlg", "onDistPanel")
  local dlg = DlgMgr:getDlgByName("SystemSwitchLineDlg")
  if not dlg then
    self:log("#R无法进行换线操作#n")
    self:finish()
    return
  end
  local scrollview = dlg.scroview
  local contentLayer = scrollview:getChildren()[1]
  local children = contentLayer:getChildren()
  for i = 1, #children do
    local child = children[i]
    self:tapCtrl(child)
    local selectServerName = dlg.lineList[dlg.selectServerName]
    if selectServerName and GameMgr:getServerName() ~= selectServerName then
      break
    end
  end
  self.toServerName = dlg.lineList[dlg.selectServerName]
  DlgMgr:sendMsg("SystemSwitchLineDlg", "onConfrimButton")
  self:log("开始从%s换线到%s", GameMgr:getServerName(), self.toServerName)
end
function SwitchLine:MSG_ENTER_GAME(data)
  if self.toServerName and self.toServerName == GameMgr:getServerName() then
    self:log("成功换线到%s", GameMgr:getServerName())
    self:finish()
  end
end
return SwitchLine
