local AutoWalk = Singleton("AutoWalk", DebugBase)
local MAP_IDS = {
  1000,
  2000,
  3000,
  4000,
  24000,
  5000,
  6000,
  7000,
  8000,
  8100,
  8200,
  8300,
  9000,
  10000,
  10001,
  11000,
  12000,
  13000,
  13001,
  14000,
  14001,
  15000,
  15001,
  16000,
  16001,
  16100,
  17000,
  17100,
  17200,
  17300,
  17400,
  17500,
  17600,
  17700,
  23000
}
function AutoWalk:init()
end
function AutoWalk:walk(str)
  local dest = gf:findDest(str)
  dest.action = "$2"
  dest.destCallback = {
    func = function()
      self:log("寻路到#Y%s#n完成", self.checkNpc)
      self:finish()
    end,
    para = ""
  }
  AutoWalkMgr:beginAutoWalk(dest)
end
function AutoWalk:run()
  local MapInfo = require("cfg/MapInfo")
  local ids = MAP_IDS
  local index, id, map_id
  local curMapId = MapMgr:getCurrentMapId()
  repeat
    index = math.ceil(math.random() * #ids)
    id = ids[index]
    map_id = MapInfo[id].map_id
  until curMapId ~= ids[index] and id == map_id
  local npcs = MapMgr:getNpcs(ids[index])
  local npc = npcs[math.ceil(math.random() * #npcs)]
  local npcName = npc and npc.name or "多闻道人"
  self.checkNpc = npcName
  self:walk(string.format("#P%s#P", self.checkNpc))
  self:log("开始寻路到#Y%s#n", self.checkNpc)
end
function AutoWalk:onPause()
  AutoWalkMgr:stopAutoWalk()
end
function AutoWalk:onResume()
  if not self.checkNpc then
    self.finish()
    return
  end
  self:walk(string.format("#P%s#P", self.checkNpc))
end
return AutoWalk
