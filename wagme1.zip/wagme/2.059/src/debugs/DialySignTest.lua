local DialySignTest = Singleton("DialySignTest", DebugBase)
function DialySignTest:init()
end
function DialySignTest:cleanup()
  DlgMgr:sendMsg("DailySignDlg", "onCloseButton")
end
function DialySignTest:run()
  self:log("开始每日签到领取测试")
  DlgMgr:sendMsg("SystemFunctionDlg", "onGiftsButton")
  self:checkDlg(function(state, msg)
    if 1 == state then
      local dlg = DlgMgr:getDlgByName("WelfareDlg")
      if not dlg then
        self:log("#R无法找到对话框:%s#n", "WelfareDlg")
        self:finish()
        return
      end
      DlgMgr:sendMsg("WelfareDlg", "onButtonClick", dlg:getControl("WelfareButton2"))
      self:checkDlg(function(s, e)
        if 1 == s then
          self:checkDailySign(function(s)
            if s == 1 then
              local signData = GiftMgr:getDailySignData()
              self.signDays = signData.signDays
              GiftMgr:dailySign()
              self:checkBonus()
            else
              self:log("#R获取每日签到数据超时#n")
              self:finish()
            end
          end)
        else
          self:log(msg)
          self:finish()
        end
      end, "DailySignDlg")
    else
      self:log(msg)
      self:finish()
    end
  end, "WelfareDlg")
end
function DialySignTest:checkDailySign(callback, time)
  time = time or gf:getServerTime()
  local signData = GiftMgr:getDailySignData()
  if not signData then
    if gf:getServerTime() - time < 30 then
      self:checkDailySign(callback, time)
    else
      callback(0)
    end
  else
    callback(1)
  end
end
function DialySignTest:checkBonus(time)
  time = time or gf:getServerTime()
  local signData = GiftMgr:getDailySignData()
  local signDays = signData.signDays
  if signDays <= self.signDays then
    if gf:getServerTime() - time < 30 then
      self:delay(function()
        self:checkBonus(time)
      end, 1)
    else
      self:log("#R无法正常签到#n")
      self:finish()
    end
  else
    self:log("完成每日签到测试")
    self:finish()
  end
end
return DialySignTest
