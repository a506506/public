local PracticeTest = Singleton("PracticeTest", DebugBase)
function PracticeTest:init()
  self:hookMsg("MSG_C_WAIT_COMMAND")
  EventDispatcher:addEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:addEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function PracticeTest:cleanup()
  EventDispatcher:removeEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:removeEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function PracticeTest:run()
  if not DlgMgr:isDlgOpened("PracticeDlg") then
    DlgMgr:openDlg("PracticeDlg")
  end
  if PracticeMgr:getIsUseExorcism() then
    gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_CLOSE_EXORCISM)
    self:checkExorcism()
  else
    self:tryToPractice()
  end
end
function PracticeTest:checkExorcism()
  if PracticeMgr:getIsUseExorcism() then
    self:delay(function()
      self:checkExorcism()
    end, 0)
  else
    self:tryToPractice()
  end
end
function PracticeTest:tryToPractice()
  local dlg = DlgMgr:getDlgByName("PracticeDlg")
  local monsterListTable = dlg:getMonsterList()
  table.sort(monsterListTable, function(a, b)
    return a.minLevel < b.minLevel
  end)
  DlgMgr:sendMsg("PracticeDlg", "gotoPractice", monsterListTable[3])
end
function PracticeTest:MSG_C_WAIT_COMMAND()
  if DlgMgr:isDlgOpened("FightPlayerMenuDlg") then
    DlgMgr:sendMsg("FightPlayerMenuDlg", "onAutoFightButton")
  end
end
function PracticeTest:onEnterCombat()
  DlgMgr:sendMsg("ScriptTestDlg", "setVisible", false)
end
function PracticeTest:onEndCombat()
  DlgMgr:sendMsg("ScriptTestDlg", "setVisible", true)
  AutoWalkMgr:stopAutoWalk()
  self:finish()
end
return PracticeTest
