local StallTest = Singleton("StallTest", DebugBase)
function StallTest:init()
  self:hookMsg("MSG_STALL_MINE")
  self.isStallMine = nil
end
function StallTest:cleanup()
  DlgMgr:sendMsg("MarketSellDlg", "onCloseButton")
  self.isStallMine = nil
end
function StallTest:run()
  self:log("开始摆摊测试")
  DlgMgr:sendMsg("SystemFunctionDlg", "onMarketButton")
  self:checkDlg(function(s, e)
    if s == 1 then
      local dlg = DlgMgr:getDlgByName("MarketTabDlg")
      DlgMgr:showDlg("ScriptTestDlg", false)
      self:tapCtrl(dlg:getControl("MarketSellDlgCheckBox"))
      DlgMgr:showDlg("ScriptTestDlg", true)
      self:checkMarketSellDlg()
    else
      self:log(e)
      self:finish()
    end
  end, "MarketTabDlg")
end
function StallTest:checkMarketSellDlg(time)
  time = time or gf:getServerTime()
  if not DlgMgr:getDlgByName("MarketSellDlg") or not self.isStallMine then
    if gf:getServerTime() - time < 30 then
      self:delay(function()
        self:checkMarketSellDlg(time)
      end, 1)
    else
      self:log("#R等待界面和数据时超时#n")
      self:finish()
    end
  else
    self:doBag()
  end
end
function StallTest:doBag()
  local dlg = DlgMgr:getDlgByName("MarketSellDlg")
  local view = dlg:getControl("BagItemsScrollView")
  local children = view:getChildren()
  if #children <= 0 then
    self:log("#R包裹缺少道具#n")
    self:finish()
    return
  end
  self:tapCtrl(children[1], 5, 5)
  self:checkDlg(function(s, e)
    self:checkSellItem()
    self:delay(function()
      DlgMgr:sendMsg("MarketSellItemDlg", "onSellButton")
    end, 3)
  end, "MarketSellItemDlg")
end
function StallTest:checkSellItem(time, num)
  time = time or gf:getServerTime()
  local dlg = DlgMgr:getDlgByName("MarketSellDlg")
  local listPanel = dlg:getControl("ItemListPanel")
  local children = listPanel:getChildren()
  if not children then
    if gf:getServerTime() - time < 30 then
      self:delay(function()
        self:checkSellItem(time, num)
      end, 1)
    else
      self:log("#R无法完成摆摊测试(摆摊超时1)#n")
      self:finish()
    end
    return
  end
  local scrollview = children[1]
  if not scrollview then
    if gf:getServerTime() - time < 30 then
      self:delay(function()
        self:checkSellItem(time, num)
      end, 1)
    else
      self:log("#R无法完成摆摊测试(摆摊超时1)#n")
      self:finish()
    end
    return
  end
  children = scrollview:getChildren()
  if not num then
    num = #children
    self:delay(function()
      self:checkSellItem(time, num)
    end, 0.1)
  elseif num <= #children then
    self:log("完成摆摊测试")
    self:finish()
  elseif gf:getServerTime() - time < 30 then
    self:delay(function()
      self:checkSellItem(time, num)
    end, 1)
  else
    self:log("#R无法完成摆摊测试(摆摊超时2)#n")
    self:finish()
  end
end
function StallTest:MSG_STALL_MINE()
  self.isStallMine = true
end
return StallTest
