local LivenessRewardTest = Singleton("LivenessRewardTest", DebugBase)
function LivenessRewardTest:init()
end
function LivenessRewardTest:cleanup()
  DlgMgr:sendMsg("ActivitiesDlg", "onCloseButton")
end
function LivenessRewardTest:run()
  DlgMgr:sendMsg("SystemFunctionDlg", "onActivityButton")
  self:delay(function()
    self:checkActivityDlg()
  end, 0.1)
end
function LivenessRewardTest:checkActivityDlg(startTime)
  startTime = startTime or gf:getServerTime()
  if not DlgMgr:isDlgOpened("ActivitiesDlg") then
    if gf:getServerTime() - startTime < 30 then
      self:delay(function()
        self:checkActivityDlg(startTime)
      end, 0)
    else
      self:log("#R无法完成领取活跃度奖励具测试(无法打开界面)#n")
      self:finish()
    end
  else
    local dlg = DlgMgr:getDlgByName("ActivitiesDlg")
    local rewardStatusTable = ActivityMgr:getRewardStatus() or {}
    local reward = ActivityMgr:getActivityReward()
    local isGet
    for i = 1, #reward do
      local rewardPanel = dlg:getControl(string.format("RewardPanel%d", i), Const.UIPanel)
      local rewardItemPanel = dlg:getControl("RewardItemPanel", Const.UIPanel, rewardPanel)
      local key = reward[i].activity
      if rewardStatusTable[key] and rewardStatusTable[key].status == 2 then
        self:tapCtrl(rewardItemPanel)
        isGet = true
        break
      end
    end
    if not isGet then
      self:log("#R无法找到可领取的奖励#n")
      self:finish()
    else
      self:checkBonus()
    end
  end
end
function LivenessRewardTest:checkBonus()
  self:log("完成领取活跃度奖励")
  self:finish()
end
return LivenessRewardTest
