local HouseTest = Singleton("HouseTest", DebugBase)
function HouseTest:init()
end
function HouseTest:cleanup()
  self.isInHouse = nil
end
function HouseTest:run()
  self:log("开始居所测试")
  if string.isNilOrEmpty(Me:queryBasic("house/id")) then
    self:log("居所测试失败(%s)", "角色没有居所")
    self:finish()
    return
  end
  if not DlgMgr:isDlgOpened("HomeInDlg") then
    DlgMgr:sendMsg("GameFunctionDlg", "onHomeButton")
  end
  self:checkHomeIn()
end
function HouseTest:checkHomeIn()
  if not DlgMgr:isDlgOpened("HomeInDlg") then
    self:delay(function()
      self:checkHomeIn()
    end, 0)
    return
  end
  DlgMgr:sendMsg("HomeInDlg", "onHomeInButton")
  self:checkInHouse()
end
function HouseTest:checkHomeOut()
  if not DlgMgr:isDlgOpened("HomeInDlg") then
    self:delay(function()
      self:checkHomeOut()
    end, 0)
    return
  end
  DlgMgr:sendMsg("HomeInDlg", "onHomeOutButton")
  self:checkOutHouse()
end
function HouseTest:onResume()
end
function HouseTest:checkOutHouse(time)
  local mapName = MapMgr:getCurrentMapName()
  if mapName and not string.match(mapName, ".*-房屋") then
    self:log("完成居所测试")
    self:finish()
  else
    time = time or gf:getServerTime()
    if gf:getServerTime() - time < 30 then
      self:delay(function()
        self:checkOutHouse(time)
      end, 0)
    else
      self:log("#R离开居所超时#n")
      self:finish()
    end
  end
end
function HouseTest:checkInHouse(time)
  local mapName = MapMgr:getCurrentMapName()
  if mapName and string.match(mapName, ".*-房屋") then
    self.isInHouse = true
    self:delay(function()
      if not DlgMgr:isDlgOpened("HomeInDlg") then
        DlgMgr:sendMsg("GameFunctionDlg", "onHomeButton")
      end
      self:checkHomeOut()
    end, 5)
  else
    time = time or gf:getServerTime()
    if gf:getServerTime() - time < 30 then
      self:delay(function()
        self:checkInHouse()
      end, 0)
    else
      self:log("#R进入居所超时#n")
      self:finish()
    end
  end
end
return HouseTest
