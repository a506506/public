local GuideTest = Singleton("GuideTest", DebugBase)
function GuideTest:init()
  self.curTask = nil
  self.npcTaskPrompt = nil
  self.npcCheckDelay = nil
  self:hookMsg("MSG_MENU_LIST")
  self:hookMsg("MSG_TASK_PROMPT")
  self:hookMsg("MSG_PLAY_SCENARIOD")
  self:hookMsg("MSG_C_WAIT_COMMAND")
  self:hookMsg("MSG_PLAY_INSTRUCTION")
  self:hookMsg("MSG_GENERAL_NOTIFY")
end
function GuideTest:cleanup()
  self.npcTaskPrompt = nil
  self.curTask = nil
  self.npcCheckDelay = nil
end
function GuideTest:pause()
  AutoWalkMgr:stopAutoWalk()
end
function GuideTest:getTaskCtrl()
  local dlg = DlgMgr:getDlgByName("MissionDlg")
  if not dlg then
    return
  end
  local list = dlg:getControl("MissionListView")
  for i = 1, #list:getItems() do
    local item = list:getItem(i - 1)
    if item.task_type == "主线—浮生若梦" then
      local row = item:getChildByName("OneRowMissionPanel_1")
      return row
    end
  end
end
function GuideTest:run()
  self:log("开始主线任务测试")
  self:checkTaskCtrl()
end
function GuideTest:checkVisible(callback, dlgName, time)
  time = time or gf:getServerTime()
  if DlgMgr:isVisible(dlgName) then
    callback(1)
  elseif gf:getServerTime() - time < 30 then
    self:checkVisible(callback, dlgName, time)
  else
    callback(0)
  end
end
function GuideTest:checkTask(time)
  time = time or gf:getServerTime()
  local task = TaskMgr:getTaskByName("主线—浮生若梦")
  local taskPromprt = task.task_prompt
  if string.match(taskPromprt, "E=【主线】") then
    local dest = gf:findDest(taskPromprt)
    if taskPromprt == self.npcTaskPrompt then
      return
    end
    self.npcTaskPrompt = taskPromprt
    self:checkNpc(dest.npc, 1, function()
      self.npcCheckDelay = self:delay(function()
        local task = TaskMgr:getTaskByName("主线—浮生若梦")
        local prompt = task and task.task_prompt
        if prompt == taskPromprt then
          self:log("#R任务状态长时间未发生变化，结束新手测试#n")
          self:finish()
          self.npcCheckDelay = nil
        end
      end, 30)
    end)
  else
  end
end
function GuideTest:checkTaskCtrl()
  if DlgMgr:isVisible("DramaDlg") or GuideMgr.guideLayer and GuideMgr.guideLayer:isVisible() then
    self:delay(function()
      self:checkTaskCtrl()
    end, 0.1)
    return
  end
  local ctrl = self:getTaskCtrl()
  if not ctrl then
    self:log("#R无法找到主线任务#n")
    self:finish()
    return
  end
  local task = TaskMgr:getTaskByName("主线—浮生若梦")
  if not task then
    self:log("#RR无法找到主线任务#n")
    self:finish()
    return
  end
  self.curTask = task.task_prompt
  self:checkTask()
  DlgMgr:showDlg("ScriptTestDlg", false)
  self:tapCtrl(ctrl, 10, -10)
  DlgMgr:showDlg("ScriptTestDlg", true)
end
function GuideTest:checkGuideCtrl()
  if not GuideMgr.guideLayer then
    self:delay(function()
      self:checkGuideCtrl()
    end, 0.1)
    return
  end
  if GuideMgr.guideLayer:isVisible() then
    self:tapCtrl(GuideMgr.guideLayer:getChildren()[1])
    self:delay(function()
      if GuideMgr.guideLayer:isVisible() then
        self:checkGuideCtrl()
      else
        self:checkTask()
        GuideTest:checkTaskCtrl()
      end
    end, 0.2)
  else
    self:delay(function()
      self:checkGuideCtrl()
    end, 0.1)
  end
end
function GuideTest:MSG_GENERAL_NOTIFY(data)
  if NOTIFY.NOTICE_FETCH_BONUS == data.notify then
    DlgMgr:sendMsg("GetPetDlg", "onGetButton")
  end
end
function GuideTest:MSG_TASK_PROMPT(data)
  local task = TaskMgr:getTaskByName("主线—浮生若梦")
  if self.npcCheckDelay then
    self:cancelDelay(self.npcCheckDelay)
    self.npcCheckDelay = nil
  end
  if task then
    local curTask = task.task_prompt
    if curTask ~= self.curTask then
      self:checkTaskCtrl()
    end
  elseif Me:queryBasicInt("level") >= 10 then
    self:log("完成主线任务测试")
    self:finish()
  end
end
function GuideTest:MSG_PLAY_INSTRUCTION()
  self:delay(function()
    self:checkGuideCtrl()
  end, 0)
end
return GuideTest
