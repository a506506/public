local WorldChannelTest = Singleton("WorldChannelTest", DebugBase)
function WorldChannelTest:init()
end
function WorldChannelTest:cleanup()
end
function WorldChannelTest:run()
  if not DlgMgr:isDlgOpened("ChatDlg") then
    self:log("#R无法找到聊天界面#n")
    self:finish()
    return
  end
  DlgMgr:sendMsg("ChatDlg", "onChatButton")
  if not DlgMgr:isDlgOpened("ChannelDlg") then
    self:log("#R无法找到频道界面#n")
    self:finish()
    return
  end
  local dlg = DlgMgr:getDlgByName("ChannelDlg")
  if not dlg then
    return
  end
  local radioGroup = dlg.radioGroup
  radioGroup:selectRadio(2)
  self.content = string.format("$测试世界频道(%s)$", tostring(gf:getServerTime()))
  DlgMgr:sendMsg("ChannelDlg", "setChannelInputChat", 1, "addCardInfo", "", self.content)
  DlgMgr:sendMsg("ChannelDlg", "setChannelInputChat", 1, "sendMessage")
  self:checkData()
end
function WorldChannelTest:checkData(checkStartTime)
  local chatData = ChatMgr:getAllChatData().worldChatData
  checkStartTime = checkStartTime or gf:getServerTime()
  local isFound
  for i = 1, #chatData do
    local data = chatData[i]
    if data.msg == self.content then
      isFound = true
      break
    end
  end
  if not isFound then
    if gf:getServerTime() - checkStartTime < 30 then
      self:delay(function()
        self:checkData(checkStartTime)
      end, 1)
    else
      self:log("#R无法完成世界频道聊天#n, %d, %d, %d", gf:getServerTime(), checkStartTime, gf:getServerTime() - checkStartTime)
      DlgMgr:sendMsg("ChannelDlg", "onCloseButton")
      self:finish()
    end
  else
    DlgMgr:sendMsg("ChannelDlg", "onCloseButton")
    self:log("完成世界频道聊天")
    self:finish()
  end
end
return WorldChannelTest
