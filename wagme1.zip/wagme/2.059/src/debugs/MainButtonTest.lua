local MainButtonTest = Singleton("MainButtonTest", DebugBase)
local TEST_BUTTONS = {
  {
    "SystemFunctionDlg",
    "onGiftsButton",
    "WelfareDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onShuadaoButton",
    "GetTaoTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onRankingListButton",
    "GongceRankingListDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onFamousButton",
    "FamousDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onMallButton",
    "OnlineMallTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onActivityButton",
    "ActivitiesDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onSmallMapButton",
    "SmallMapDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onWorldMapButton",
    "WorldMapDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onMarketButton",
    "MarketTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onTreasureButton",
    "MarketGoldTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onAuctionButton",
    "MarketAuctionDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onJubaoButton",
    "JuBaoZhaiTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onTradingSpotButton",
    "TradingSpotTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onAnniversaryButton",
    "AnniversaryTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "SystemFunctionDlg",
    "onCommunityButton",
    "CommunityDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish",
    "openCommunity"
  },
  {
    "SystemFunctionDlg",
    "onPromoteButton",
    "PromoteDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onAchievementButton",
    "AchievementTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onPartyButton",
    {
      "InviteJoinPartyDlg",
      "JoinPartyDlg",
      "PartyInfoTabDlg"
    },
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onEquipButton",
    "EquipmentTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onHorcruxButton",
    "HorcruxTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onGuardButton",
    "GuardAttribDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onSystemButton",
    "SystemConfigTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onBagButton",
    "BagDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onWatchCenterButton",
    "WatchCentreDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onHomeButton",
    "HomeInDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onMarryBookButton",
    "WeddingBookDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onTeachButton",
    {
      "MasterRelationDlg",
      "MasterDlg"
    },
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onJewelryButton",
    "JewelryTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onArtifactButton",
    "ArtifactTabDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  },
  {
    "GameFunctionDlg",
    "onAdministratorsButton",
    "AdministratorsDlg",
    "checkDlgOpened",
    "closeDlgWhenFinish"
  }
}
function MainButtonTest:init()
end
function MainButtonTest:cleanup()
end
function MainButtonTest:run()
  self:doNext(1)
end
function MainButtonTest:doNext(index)
  local item = TEST_BUTTONS[index]
  if not item then
    self:finish()
  else
    self:log("开始测试按钮:%s", item[2])
    if string.isNilOrEmpty(item[6]) then
      DlgMgr:sendMsg(item[1], item[2])
    else
      self[item[6]](self)
    end
    self[item[4]](self, item[3], function(state)
      self:delay(function()
        if item[5] then
          self[item[5]](self, item[3])
        end
        if 1 == state then
          self:log("按钮(%s)点击测试成功", item[2])
        else
          self:log("#R按钮(%s)点击测试失败#n", item[2])
        end
        self:doNext(index + 1)
      end, 1)
    end)
  end
end
function MainButtonTest:openCommunity()
  DlgMgr:sendMsg("SystemFunctionDlg", "onCommunityButton", DlgMgr:getDlgByName("SystemFunctionDlg"):getControl("CommunityButton"))
end
function MainButtonTest:isDlgOpened(dlgName)
  if "table" == type(dlgName) then
    for i = 1, #dlgName do
      if DlgMgr:isDlgOpened(dlgName[i]) then
        return true
      end
    end
  else
    return DlgMgr:isDlgOpened(dlgName)
  end
end
function MainButtonTest:checkDlgOpened(dlgName, callback, time)
  if self:isDlgOpened(dlgName) then
    callback(1)
  else
    time = time or gf:getServerTime()
    if gf:getServerTime() - time < 30 then
      self:delay(function()
        self:checkDlgOpened(dlgName, callback, time)
      end, 0.5)
    else
      callback(0)
    end
  end
end
function MainButtonTest:closeDlgWhenFinish(dlgName)
  if "table" == type(dlgName) then
    for i = 1, #dlgName do
      DlgMgr:sendMsg(dlgName[i], "onCloseButton")
    end
  else
    DlgMgr:sendMsg(dlgName, "onCloseButton")
  end
end
function MainButtonTest:checkButtonVisible(args, callback)
  if "table" ~= type(args) then
    return
  end
  if self:getCtrlVisible(args[2], args[1]) then
    callback()
  else
    self:delay(function()
      self:checkButtonVisible(args, callback)
    end, 0)
  end
end
return MainButtonTest
