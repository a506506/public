DebugBase = Singleton("DebugBase")
local NPC_CHECK_TIME = 360
function DebugBase:construct(callback)
  self.callback = callback
end
function DebugBase:hookMsg(msg)
  MessageMgr:hook(msg, self, self.name)
end
function DebugBase:unhookMsg()
  MessageMgr:unhookByHooker(self.name)
end
function DebugBase:pause()
  self.isPaused = true
  if "function" == type(self.onPause) then
    self:onPause()
  end
end
function DebugBase:resume()
  self.isPaused = nil
  if "function" == type(self.onResume) then
    self:onResume()
  end
end
function DebugBase:stop()
  if "function" == type(self.cleanup) then
    self:cleanup()
  end
  self:unhookMsg()
  self.isPaused = nil
  self.callback = nil
end
function DebugBase:log(...)
  local msg = string.format(...)
  DlgMgr:sendMsg("ScriptTestDlg", "addLog", msg)
end
function DebugBase:finish(...)
  if "function" == type(self.callback) then
    self.callback(self, ...)
  end
  self:stop()
end
function DebugBase:checkDlg(callback, ...)
  self:checkDlgEx(callback, gf:getServerTime(), {
    ...
  })
end
function DebugBase:checkDlgEx(callback, startTime, dlgs)
  local startTime = startTime or gf:getServerTime()
  for i = 1, #dlgs do
    if not DlgMgr:isDlgOpened(dlgs[i]) then
      if gf:getServerTime() - startTime < 30 then
        self:delay(function()
          self:checkDlgEx(callback, startTime, dlgs)
        end, 0)
        return
      else
        callback(0, string.format("无法找到指定界面：%s", dlgs[i]))
        return
      end
    end
  end
  callback(1)
end
function DebugBase:tapCtrl(ctrl, dx, dy)
  if not ctrl then
    return
  end
  local x, y = ctrl:getPosition()
  local wp = ctrl:getParent():convertToWorldSpace(cc.p(x, y))
  local frameSize = cc.Director:getInstance():getOpenGLView():getFrameSize()
  local resolutionSize = cc.Director:getInstance():getOpenGLView():getDesignResolutionSize()
  local pt = cc.p(wp.x / resolutionSize.width * frameSize.width, (resolutionSize.height - wp.y) / resolutionSize.height * frameSize.height)
  gfSimulateTouch(pt.x + (dx or 0), pt.y + (dy or 0))
end
function DebugBase:tapCtrlEx(dlgName, ctrlName, root)
  local dlg = DlgMgr:getDlgByName(dlgName)
  if not dlg then
    return
  end
  local ctrl = dlg:getControl(ctrlName, nil, root)
  self:tapCtrl(ctrl)
end
function DebugBase:delay(func, time)
  local dlg = DlgMgr:getDlgByName("ScriptTestDlg")
  if not dlg or not dlg.root or "function" ~= type(func) then
    return
  end
  local root
  root = dlg.root
  return performWithDelay(root, func, time)
end
function DebugBase:cancelDelay(action)
  local dlg = DlgMgr:getDlgByName("ScriptTestDlg")
  if not dlg or not dlg.root or not action then
    return
  end
  dlg.root:stopAction(action)
end
function DebugBase:MSG_PLAY_SCENARIOD()
  self:delay(function()
    if DlgMgr:isDlgOpened("DramaDlg") then
      DlgMgr:sendMsg("DramaDlg", "onNextScene")
    end
  end, 0.1)
end
function DebugBase:MSG_C_WAIT_COMMAND()
  if DlgMgr:isDlgOpened("FightPlayerMenuDlg") then
    DlgMgr:sendMsg("FightPlayerMenuDlg", "onAutoFightButton")
  end
  if gf:isWindows() then
    ChatMgr:sendCurChannelMsg("win")
  end
end
function DebugBase:onEnterCombat()
  DlgMgr:sendMsg("ScriptTestDlg", "setVisible", false)
end
function DebugBase:onEndCombat()
  DlgMgr:sendMsg("ScriptTestDlg", "setVisible", true)
end
function DebugBase:selectMenu(index)
  local npcDlg = DlgMgr:getDlgByName("NpcDlg")
  if not npcDlg then
    self:log("缺少NpcDlg")
    self:finish()
    return
  end
  local menuList = npcDlg:getControl("MenuListView")
  if not menuList then
    self:log("缺少菜单控件")
    self:finish()
    return
  end
  local items = menuList:getChildren()
  if not items or index > #items then
    self:log("菜单项缺失，期望菜单项：%d, 实际：%d", index, items and #items or 0)
    self:finish()
    return
  end
  items[index]:procMenuItem()
  self:log("处理菜单项:%s", tostring(items[index].text))
  return items[index].text
end
function DebugBase:checkNpc(npcName, menuIndex, callback, time)
  time = time or gf:getServerTime()
  if Me.faAct ~= Const.FA_STAND then
    if gf:getServerTime() - time < NPC_CHECK_TIME then
      self:delay(function()
        self:checkNpc(npcName, menuIndex, callback, time)
      end, 0)
    else
      self:log("#R无法寻路到NPC(%s)#n", npcName)
      self:finish()
    end
  else
    local npc = CharMgr:getCharByName(npcName)
    if not npc or not DlgMgr:isVisible("NpcDlg") then
      if gf:getServerTime() - time < NPC_CHECK_TIME then
        self:delay(function()
          self:checkNpc(npcName, menuIndex, callback, time)
        end, 0)
      else
        self:log("#R无法找到NPC(%s)#n", npcName)
        self:finish()
      end
    else
      self:log("和#Y%s#n对话，选择菜单:%s", tostring(npcName), tostring(menuIndex))
      local menuText = self:selectMenu(menuIndex)
      if "function" == type(callback) then
        callback(menuText)
      end
    end
  end
end
function DebugBase:MSG_GOODS_LIST()
  self:delay(function()
    if DlgMgr:isDlgOpened("PharmacyDlg") then
      DlgMgr:sendMsg("PharmacyDlg", "onBuyButton")
    elseif DlgMgr:isDlgOpened("GroceryStoreDlg") then
      DlgMgr:sendMsg("GroceryStoreDlg", "onBuyButton")
    end
  end, 0)
end
function DebugBase:MSG_OPEN_EXCHANGE_SHOP()
  self:delay(function()
    if DlgMgr:isDlgOpened("RowSkillShopDlg") then
      DlgMgr:sendMsg("RowSkillShopDlg", "onBuyButton")
    elseif DlgMgr:isDlgOpened("PetShopDlg") then
      DlgMgr:sendMsg("PetShopDlg", "onBuyButton")
    elseif DlgMgr:isDlgOpened("GoodValueDlg") then
      DlgMgr:sendMsg("GoodValueDlg", "onBuyButton")
    elseif DlgMgr:isDlgOpened("JungongShopDlg") then
      DlgMgr:sendMsg("JungongShopDlg", "onBuyButton")
    end
  end, 0)
end
function DebugBase:MSG_SUBMIT_PET()
  self:delay(function()
    if DlgMgr:isDlgOpened("SubmitPetDlg") then
      DlgMgr:sendMsg("SubmitPetDlg", "onSubmitButton")
    end
  end, 0)
end
function DebugBase:MSG_ICON_CARTOON()
  self:delay(function()
    if DlgMgr:isDlgOpened("FastUseItemDlg") then
      DlgMgr:sendMsg("FastUseItemDlg", "onUseButton")
    end
  end, 0)
end
