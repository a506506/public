local BBMTest = Singleton("BBMTest", DebugBase)
function BBMTest:init()
  self.nextMenuCallback = nil
  self:hookMsg("MSG_MENU_LIST")
  self:hookMsg("MSG_TASK_PROMPT")
  self:hookMsg("MSG_PLAY_SCENARIOD")
  self:hookMsg("MSG_C_WAIT_COMMAND")
  EventDispatcher:addEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:addEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function BBMTest:cleanup()
  self.nextMenuCallback = nil
  AutoWalkMgr:stopAutoWalk()
  EventDispatcher:removeEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:removeEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function BBMTest:run()
  self:log("开始白邦忙测试")
  if TaskMgr:getZhuRenWeiLeTask() then
    self:checkTask()
  else
    AutoWalkMgr:beginAutoWalk(gf:findDest(CHS[3002207]))
    self:checkNpc("白邦芒", 1, function()
      function self.nextMenuCallback()
        self:checkNpc("白邦芒", 1, function()
          function self.nextMenuCallback()
            self:checkNpc("白邦芒", 2, function()
              self:log("完成白邦芒扫荡测试")
              self:finish()
              return
            end)
          end
        end)
      end
    end)
  end
end
function BBMTest:checkTask()
  local task = TaskMgr:getZhuRenWeiLeTask()
  if task then
    do
      local dest = gf:findDest(TaskMgr:getZhuRenWeiLeTask())
      AutoWalkMgr:setNextDest(dest)
      self:log("当前任务：%s", tostring(task))
      if "找#P白邦芒#P领赏" == task then
        self:checkNpc(dest.npc, 2, function()
          function self.nextMenuCallback()
            self:checkNpc(dest.npc, 2)
            self:log("完成白邦忙任务测试")
            self:finish()
          end
        end)
      elseif "帮助#P冯喜来|E=【助人】帮助冯喜来#P" == task or "找#P无名剑客|E=【助人】比试过招#P比试" == task or "找#P帮派使者|E=【助人】询问帮派使者#P问问" == task or "解救#P茅山道士|E=【助人】解救茅山道士#P" == task then
        self.nextMenuCallback = nil
        self:checkNpc(dest.npc, 1)
      elseif "帮助#P茅山道士|M=【助人】帮助茅山道士#P" == task or "帮助#P杨镖头|M=【助人】帮助杨镖头#P" == task or "回复#P冯喜来|M=【助人】回复冯喜来#P" == task then
      elseif string.match(task, "乞丐") then
        self:checkNpc(dest.npc, 1, function()
          function self.nextMenuCallback()
            self:checkNpc(dest.npc, 2)
          end
        end)
      end
    end
  else
    self:delay(function()
      self:checkTask()
    end, 0)
  end
end
function BBMTest:MSG_MENU_LIST()
  if "function" == type(self.nextMenuCallback) then
    do
      local callback = self.nextMenuCallback
      self:delay(function()
        callback()
      end, 0)
      self.nextMenuCallback = nil
    end
  end
end
function BBMTest:MSG_TASK_PROMPT(data)
  local isRefreshTask
  for k, v in ipairs(data) do
    if not string.isNilOrEmpty(v.task_prompt) and string.match(v.task_type, CHS[3004378]) then
      isRefreshTask = true
      break
    end
  end
  if isRefreshTask and TaskMgr:getZhuRenWeiLeTask() then
    self:checkTask()
  end
end
return BBMTest
