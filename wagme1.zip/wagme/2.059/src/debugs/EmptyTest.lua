local EmptyTest = Singleton("EmptyTest", DebugBase)
function EmptyTest:init()
end
function EmptyTest:cleanup()
end
function EmptyTest:run()
end
return EmptyTest
