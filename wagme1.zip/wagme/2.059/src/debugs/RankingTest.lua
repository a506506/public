local RankingTest = Singleton("RankingTest", DebugBase)
function RankingTest:init()
  self.recvData = nil
  self:hookMsg("MSG_TOP_USER")
end
function RankingTest:cleanup()
  self.recvData = nil
end
function RankingTest:run()
  self:log("开始排行榜测试")
  DlgMgr:sendMsg("SystemFunctionDlg", "onRankingListButton")
  self:checkDataList()
end
function RankingTest:checkDataList(time)
  time = time or gf:getServerTime()
  if not DlgMgr:isDlgOpened("GongceRankingListDlg") and not DlgMgr:isDlgOpened("RankingListDlg") or not self.recvData then
    if time - gf:getServerTime() < 30 then
      self:delay(function()
        self:checkDataList(time)
      end, 0)
    else
      self:log("#R排行榜测试失败#n")
      self:finish()
    end
  else
    local dlg = DlgMgr:getDlgByName("GongceRankingListDlg") or DlgMgr:getDlgByName("RankingListDlg")
    if #dlg.listView:getItems() >= 10 then
      self:log("排行榜测试成功")
    else
      self:log("#R排行榜测试失败#n")
    end
    DlgMgr:sendMsg("GongceRankingListDlg", "onCloseButton")
    DlgMgr:sendMsg("RankingListDlg", "onCloseButton")
    self:finish()
  end
end
function RankingTest:MSG_TOP_USER()
  self:delay(function()
    self.recvData = true
  end, 0)
end
return RankingTest
