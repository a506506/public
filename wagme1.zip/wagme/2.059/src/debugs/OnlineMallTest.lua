local OnlineMallTest = Singleton("OnlineMallTest", DebugBase)
local ITEM_NAME = "超级仙风散"
function OnlineMallTest:init()
end
function OnlineMallTest:cleanup()
  DlgMgr:sendMsg("OnlineMallDlg", "onCloseButton")
end
function OnlineMallTest:run()
  self:log("开始商城购买道具测试")
  self.itemCount = InventoryMgr:getAmountByName(ITEM_NAME)
  OnlineMallMgr:openOnlineMall("OnlineMallDlg", nil, {
    [ITEM_NAME] = 1
  })
  self:checkDlg()
end
function OnlineMallTest:checkDlg(startTime)
  startTime = startTime or gf:getServerTime()
  if not DlgMgr:isDlgOpened("OnlineMallDlg") then
    if gf:getServerTime() - startTime < 30 then
      self:delay(function()
        self:checkDlg(startTime)
      end, 0)
    else
      self:log("#R无法完成商城购买道具测试(无法打开界面)#n")
      self:finish()
    end
  else
    DlgMgr:sendMsg("OnlineMallDlg", "onBuyButton")
    if DlgMgr:isDlgOpened("ConfirmDlg") then
      DlgMgr:sendMsg("ConfirmDlg", "onConfirmButton")
    end
    self:checkGoods()
  end
end
function OnlineMallTest:checkGoods(startTime)
  startTime = startTime or gf:getServerTime()
  local amount = InventoryMgr:getAmountByName(ITEM_NAME)
  if amount > self.itemCount then
    self:log("完成商城购买道具测试")
    self:finish()
  elseif gf:getServerTime() - startTime < 30 then
    self:delay(function()
      self:checkGoods(startTime)
    end, 0)
  else
    self:log("#R无法完成商城购买道具测试（无法获取购买道具）#n")
    self:finish()
  end
end
return OnlineMallTest
