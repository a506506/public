local GiftRewardTest = Singleton("GiftRewardTest", DebugBase)
function GiftRewardTest:init()
end
function GiftRewardTest:cleanup()
  DlgMgr:sendMsg("OnlineGiftDlg", "onCloseButton")
end
function GiftRewardTest:run()
  self:log("开始神秘大礼领取测试")
  DlgMgr:sendMsg("SystemFunctionDlg", "onGiftsButton")
  self:checkDlg(function(state, msg)
    if 1 == state then
      DlgMgr:sendMsg("WelfareDlg", "onlineGift")
      self:checkDlg(function(s, e)
        if 1 == s then
          self:tryToBuy()
        else
          self:log(msg)
          self:finish()
        end
      end, "OnlineGiftDlg")
    else
      self:log(msg)
      self:finish()
    end
  end, "WelfareDlg")
end
function GiftRewardTest:tryToBuy(time)
  local dlg = DlgMgr:getDlgByName("OnlineGiftDlg")
  if not dlg then
    self:log("#R无法找到神秘大礼界面#n")
    self:finish()
    return
  end
  time = time or gf:getServerTime()
  if not dlg.isInited then
    if gf:getServerTime() - time < 30 then
      self:delay(function()
        self:tryToBuy(time)
      end, 1)
    else
      self:log("#R界面无法正常初始化#n")
      self:finish()
    end
    return
  end
  DlgMgr:sendMsg("OnlineGiftDlg", "onDrawButton")
  self:log("完成神秘大礼领取测试")
  self:finish()
end
return GiftRewardTest
