local CBTaskTest = Singleton("CBTaskTest", DebugBase)
function CBTaskTest:init()
  self:hookMsg("MSG_TASK_PROMPT")
  self:hookMsg("MSG_PLAY_SCENARIOD")
  self:hookMsg("MSG_C_WAIT_COMMAND")
  self:hookMsg("MSG_LIVENESS_INFO")
end
function CBTaskTest:cleanup()
end
function CBTaskTest:run()
  self:log("开始除暴任务测试")
  if not PracticeMgr:getIsUseExorcism() then
    gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_OPEN_EXORCISM)
    self:checkExorcism()
  else
    self:doTask()
  end
end
function CBTaskTest:checkExorcism()
  if not PracticeMgr:getIsUseExorcism() then
    self:delay(function()
      self:checkExorcism()
    end, 0)
  else
    self:doTask()
  end
end
function CBTaskTest:doTask()
  local decStr
  if TaskMgr:getCBTask() then
    decStr = TaskMgr:getCBTask()
  else
    decStr = CHS[3002221]
  end
  local dest = gf:findDest(decStr)
  if dest then
    AutoWalkMgr:beginAutoWalk(dest)
    self:checkNpc(dest.npc, 1)
  end
end
function CBTaskTest:checkTask()
  local decStr
  if TaskMgr:getCBTask() then
    decStr = TaskMgr:getCBTask()
    local dest = gf:findDest(decStr)
    self:log("当前任务：%s", decStr)
    AutoWalkMgr:setNextDest(dest)
  else
    ActivityMgr:getActiviInfo()
  end
end
function CBTaskTest:MSG_TASK_PROMPT()
  self:checkTask()
  ActivityMgr:getActiviInfo()
end
function CBTaskTest:MSG_LIVENESS_INFO()
  if ActivityMgr:getActivityCurTimes("除暴任务") >= 10 then
    self:log("完成除暴任务测试")
    self:finish()
  end
end
return CBTaskTest
