require("socket")
local Msg = require("comm/global_send")
local CmdParser = require("comm/SCmdParser")
local MsgParser = require("comm/SMsgParser")
local GlobalSendNoPacket = require("cfg/GlobalSendNoPacket")
local PACKET_READ = 1
local PACKET_WRITE = 2
local CONNECT_OUT_TIME = 10
local SEND_BUFFER_SIZE = 5120
local g_socket_no = 100
local multiPacketInfo
local SConnection = class("SConnection")
local isIos = function()
  local platform = cc.Application:getInstance():getTargetPlatform()
  return platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_IPHONE
end
local isAndroid = function()
  local platform = cc.Application:getInstance():getTargetPlatform()
  return platform == cc.PLATFORM_OS_ANDROID
end
local isWindows = function()
  local platform = cc.Application:getInstance():getTargetPlatform()
  return platform == cc.PLATFORM_OS_WINDOWS
end
local isDisableIPv6 = function()
  local userDefault = cc.UserDefault:getInstance()
  if userDefault then
    return userDefault:getBoolForKey("disable_ipv6")
  end
end
local function checkIpv6(host)
  local isIpv6 = false
  if isIos() and not isDisableIPv6() then
    local addrInfo, err = socket.dns.getaddrinfo(host)
    if addrInfo then
      for k, v in pairs(addrInfo) do
        if v.family == "inet6" then
          isIpv6 = true
          host = v.addr
          Log:I("Use IPv6!")
          break
        end
      end
    end
  end
  return isIpv6, host
end
function SConnection:ctor()
  self._socketObject = nil
  self._nextReceiveSize = Packet:GetHeaderLen()
  self._processHeader = true
  self._socketNo = g_socket_no
  self._cacheData = nil
  g_socket_no = g_socket_no + 1
  self.sendBuf = string.rep("\000", SEND_BUFFER_SIZE)
  self.callbacks = {}
end
local _connect = function(tcp, host, port, onConnected, onDisconnected)
  if not tcp then
    return
  end
  tcp:settimeout(0)
  local startTime = os.time()
  local function _checkConn()
    local r, err = tcp:connect(host, port)
    if "closed" == err then
      if onDisconnected then
        onDisconnected()
      end
      return false, true
    elseif 1 == r or "already connected" == err then
      if onConnected then
        onConnected()
      end
      return true, false
    elseif os.time() - startTime >= 10 then
      if onDisconnected then
        onDisconnected()
      end
      tcp:close()
      return false, true
    end
    return false, false
  end
  local checkLoop
  function checkLoop()
    local scheduler = cc.Director:getInstance():getScheduler()
    local entryId
    entryId = scheduler:scheduleScriptFunc(function()
      local conn, timeout = _checkConn()
      if conn or timeout then
        scheduler:unscheduleScriptEntry(entryId)
      end
    end, 0, false)
  end
  checkLoop()
end
function SConnection:connect(host, port)
  self.curHost = host
  local isIpv6 = false
  local netCheckLog = {}
  if isIos() and not isDisableIPv6() then
    do
      local newHost
      local r, e = pcall(function()
        isIpv6, newHost = checkIpv6(host)
      end)
      if not r then
        isIpv6 = false
        self:pushDebugInfo("checkIpv6 error: " .. tostring(e))
        netCheckLog.getInto = "ipv4"
      else
        netCheckLog.memo = string.format("ipv4:%s:%s", tostring(host), tostring(port))
        host = newHost
        netCheckLog.getInto = "ipv6"
      end
    end
  else
    netCheckLog.getInto = "ipv4"
  end
  local tcp, e
  if isIpv6 then
    tcp, e = socket.tcp6()
  else
    tcp, e = socket.tcp()
  end
  netCheckLog.getIntoIp = host
  netCheckLog.getIntoPort = port
  if not tcp then
    Log:E(string.format("connection create tcp socket failed(error : %s)!", e))
    return
  end
  _connect(tcp, host, port, function()
    self:disconnect()
    self._socketObject = tcp
    tcp:settimeout(60)
    self:pushMsg({MSG = 4966, result = true})
    Log:D("Connect to " .. host .. ":" .. port .. " successfully")
  end, function()
    self:pushMsg({
      MSG = 4968,
      result = false,
      netCheckLog = netCheckLog
    })
  end)
  return true
end
function SConnection:disconnect()
  if nil == self._socketObject then
    return
  end
  self._socketObject:close()
  self._socketObject = nil
  Log:D("disconnect socket.")
end
function SConnection:isConnected()
  return self._socketObject ~= nil
end
function SConnection:sendBuffer(buffer, length)
  local sock = self._socketObject
  if nil == sock then
    return
  end
  if not sock:send(buffer, 1, length) then
    self._socketObject = nil
    self:pushMsg({MSG = 4968})
    return
  end
end
function SConnection:receive()
  local sock = self._socketObject
  if sock == nil then
    return
  end
  if not isWindows() and sock:getfd() >= socket._SETSIZE then
    Log:D(string.format("Socket fd(%d) is larger then %d", sock:getfd(), socket._SETSIZE))
    self:pushDebugInfo(string.format("Socket fd(%d) is larger then %d", sock:getfd(), socket._SETSIZE))
    self._socketObject = nil
    self:pushMsg({MSG = 4968})
    return
  end
  local forread, _, _ = socket.select({sock}, nil, 0)
  for _, v in ipairs(forread) do
    if v ~= sock then
      Log:D("COM DEBUG: SConnection:receive[Socket:select]")
      return
    end
    local maxSizePerTime = 6144
    local canReceiveSize = maxSizePerTime
    local cacheDataLen = 0
    if nil ~= self._cacheData then
      cacheDataLen = string.len(self._cacheData)
    else
      cacheDataLen = 0
    end
    if maxSizePerTime >= self._nextReceiveSize - cacheDataLen then
      canReceiveSize = self._nextReceiveSize - cacheDataLen
    else
      canReceiveSize = maxSizePerTime
    end
    local s, e, s2 = sock:receive(canReceiveSize)
    if e == "closed" then
      Log:D("Socket status is : " .. e)
      self:pushDebugInfo("Socket status is : " .. e)
      self._socketObject = nil
      self:pushMsg({MSG = 4968})
      return
    end
    if e ~= nil then
      s = s2
    else
    end
    if s == nil then
      return
    end
    if self._cacheData == nil then
      self._cacheData = s
    else
      self._cacheData = self._cacheData .. s
    end
    if self._cacheData == nil then
      return
    end
    if string.len(self._cacheData) < self._nextReceiveSize then
      return
    end
    return self:onReceiveData(self._cacheData)
  end
end
function SConnection:pushMsg(map)
  if not map then
    return
  end
  local str = Msg[map.MSG]
  if str ~= nil then
    local callback = self.callbacks[str]
    if callback ~= nil and type(callback) == "function" then
      callback(map)
    else
      Log:W(str .. " has no callback func.")
    end
  end
end
function SConnection:onReceiveData(data)
  if nil == data then
    return 0
  end
  local size = self._nextReceiveSize
  if string.len(self._cacheData) == size then
    self._cacheData = nil
  else
    self._cacheData = string.sub(self._cacheData, size + 1, -1)
  end
  if self._processHeader then
    self._nextReceiveSize = string.byte(data, -2) * 256 + string.byte(data, -1)
    self._processHeader = false
    return size
  else
    self._nextReceiveSize = Packet:GetHeaderLen()
    self._processHeader = true
    return size, self:parseData(data)
  end
end
function SConnection:MSG_PREPARE_MULTI_PACKET(pkt, data)
  if multiPacketInfo then
    Log:W("MSG_PREPARE_MULTI_PACKET error")
    return
  end
  local msg = pkt:GetShort()
  local totalNum = pkt:GetShort()
  local totalLen = pkt:GetLong()
  multiPacketInfo = {}
  multiPacketInfo.msg = msg
  multiPacketInfo.totalNum = totalNum
  multiPacketInfo.totalLen = totalLen
  multiPacketInfo.buf = {}
  multiPacketInfo.receiveLen = 0
end
function SConnection:MSG_SEND_MULTI_PACKET(data)
  if not multiPacketInfo or not next(multiPacketInfo) then
    Log:W("MSG_SEND_MULTI_PACKET error")
    return
  end
  local b3, b4 = string.byte(data, 3, 4)
  local bufLen = (b3 or 0) * 256 + (b4 or 0)
  local binaryStr = string.sub(data, 5, 4 + bufLen)
  table.insert(multiPacketInfo.buf, binaryStr)
  multiPacketInfo.receiveLen = multiPacketInfo.receiveLen + #binaryStr
  if multiPacketInfo.receiveLen == multiPacketInfo.totalLen then
    multiPacketInfo.buf = table.concat(multiPacketInfo.buf)
    local data = SConnection:parseData(multiPacketInfo.buf)
    multiPacketInfo = nil
    return data
  end
end
function SConnection:parseData(data)
  local b1, b2 = string.byte(data, 1, 2)
  local msg = b1 * 256 + b2
  local msgStr = Msg[msg]
  if msgStr == "MSG_SEND_MULTI_PACKET" then
    return self:MSG_SEND_MULTI_PACKET(data)
  end
  local pkt = Packet:New(data, string.len(data), PACKET_READ)
  local ret = self:parsePacket(pkt, data)
  pkt:Destroy()
  return ret
end
function SConnection:parsePacket(pkt, rawData)
  local msg = pkt:GetShort()
  local msgStr = Msg[msg]
  if nil == msgStr then
    Log:W(string.format("No msg %04X in global_send.", msg))
    return
  end
  if ATM_IS_DEBUG_VER and msgStr ~= "MSG_REPLY_ECHO" then
    Log:D("[RECV MSG : " .. msgStr .. "]")
  end
  if msgStr == "MSG_PREPARE_MULTI_PACKET" then
    return self:MSG_PREPARE_MULTI_PACKET(pkt, {})
  end
  local func = MsgParser[msgStr]
  if nil == func then
    if GlobalSendNoPacket[msgStr] then
      func = MsgParser.MSG_NO_PACKET
    else
      Log:W(msgStr .. " has no parser in MsgParser.")
      return
    end
  end
  local data = {
    MSG = msg,
    socket_no = self._socketNo,
    timestamp = gfGetTickCount()
  }
  func(MsgParser, pkt, data, rawData)
  return data
end
function SConnection:sendCmdToServer(cmd, data)
  local size = SEND_BUFFER_SIZE
  local buf = self.sendBuf
  local pkt = Packet:New(buf, size, PACKET_WRITE)
  pkt:PutChar(string.byte("M"))
  pkt:PutChar(string.byte("Z"))
  pkt:PutShort(0)
  pkt:PutLong(gfGetTickCount())
  pkt:PutShort(0)
  local cmd_int = Cmd[cmd]
  if nil == cmd_int then
    Log:W("No cmd " .. cmd .. " in global_send.")
    pkt:Destroy()
    return
  end
  pkt:PutShort(cmd_int)
  if ATM_IS_DEBUG_VER and cmd ~= "CMD_ECHO" then
    Log:D("[SEND CMD : " .. cmd .. "]")
  end
  local func = CmdParser[cmd]
  if nil == func then
    if GlobalSendNoPacket[cmd] then
      func = CmdParser.CMD_NO_PACKET
    else
      Log:W(cmd .. " has no parser in CmdParser.")
      pkt:Destroy()
      return
    end
  end
  if nil ~= data then
    func(CmdParser, pkt, data)
  end
  pkt:SetMsgLen()
  local len = Packet:GetHeaderLen() + pkt:GetMsgLen()
  self:sendBuffer(buf, len)
  pkt:Destroy()
end
function SConnection:regist(msg, func)
  if type(func) == "function" then
    self.callbacks[msg] = func
  end
end
function SConnection:pushDebugInfo(info)
end
return SConnection
