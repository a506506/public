local Connection = require("comm/Connection")
CommThread = {}
CommThread._connection = {}
CommThread._connectionAAA = {}
function CommThread:loop(isAll)
  for _, v in pairs(self._connection) do
    self:receiveMsg(v, isAll)
  end
  for _, v in pairs(self._connectionAAA) do
    self:receiveMsg(v, isAll)
  end
end
function CommThread:getConnection(type)
  type = type or CONNECT_TYPE.NORMAL
  return self._connection[type]
end
function CommThread:getConnectionAAA(type)
  type = type or CONNECT_TYPE.NORMAL
  return self._connectionAAA[type]
end
function CommThread:receiveMsg(conn, isAll)
  while true do
    if conn == nil then
      break
    end
    local size = 0
    local maxSize = 6144
    local data
    while size ~= nil and (isAll or maxSize > 0) do
      size, data = conn:receive()
      MessageMgr:pushMsg(data)
      maxSize = maxSize - (size or 0)
    end
    if conn.type == CONNECT_TYPE.NORMAL then
      Client:tryToKeepAlive(conn)
    end
    return
  end
end
function CommThread:start(ip, port, type)
  type = type or CONNECT_TYPE.NORMAL
  MessageMgr:deleteMsg("MSG_CLIENT_DISCONNECTED", type)
  self._connection[type] = Connection.new(nil, type)
  if GameMgr:isInBackground() then
    self._connection[type]:connect(ip, port)
  else
    DlgMgr:openDlg("WaitDlg")
    performWithDelay(gf:getUILayer(), function()
      if self._connection[type] then
        self._connection[type]:connect(ip, port)
      end
    end, 0.2)
  end
end
function CommThread:getConnectionIp(type)
  type = type or CONNECT_TYPE.NORMAL
  if self._connection[type] and self._connection[type]._socketObject then
    return self._connection[type].curHost
  end
end
function CommThread:stop(type)
  type = type or CONNECT_TYPE.NORMAL
  if self._connection[type] ~= nil then
    self._connection[type]:disconnect()
    self._connection[type] = nil
    if type == CONNECT_TYPE.NORMAL then
      Client._isConnectingGS = false
    end
  end
end
function CommThread:isConnectAAA(type)
  type = type or CONNECT_TYPE.NORMAL
  if not self._connectionAAA[type] or not self._connectionAAA[type]:isConnected() then
    return false
  end
  return true
end
function CommThread:startAAA(ip, port, type)
  type = type or CONNECT_TYPE.NORMAL
  MessageMgr:deleteMsg("MSG_CLIENT_DISCONNECTED", type)
  DlgMgr:openDlg("WaitDlg")
  self._connectionAAA[type] = Connection.new(true, type)
  performWithDelay(gf:getUILayer(), function()
    if self._connectionAAA[type] then
      self._connectionAAA[type]:connect(ip, port)
    end
  end, 0.2)
end
function CommThread:stopAAA(type)
  type = type or CONNECT_TYPE.NORMAL
  if self._connectionAAA[type] ~= nil then
    self._connectionAAA[type]:disconnect()
    self._connectionAAA[type] = nil
  end
end
function CommThread:getConnectionAAAIp(type)
  type = type or CONNECT_TYPE.NORMAL
  if self._connectionAAA[type] and self._connectionAAA[type]._socketObject then
    return self._connectionAAA[type].curHost
  end
end
return CommThread
