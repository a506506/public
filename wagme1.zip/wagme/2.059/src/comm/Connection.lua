require("socket")
local Msg = require("comm/global_send")
local CmdParser = require("comm/CmdParser")
local MsgParser = require("comm/MsgParser")
local GlobalSendNoPacket = require("cfg/GlobalSendNoPacket")
local PACKET_READ = 1
local PACKET_WRITE = 2
local CONNECT_OUT_TIME = 10
local SEND_BUFFER_SIZE = 5120
local g_socket_no = 100
local multiPacketInfo
local Connection = class("Connection")
local isDisableIPv6 = function()
  local userDefault = cc.UserDefault:getInstance()
  if userDefault then
    return userDefault:getBoolForKey("disable_ipv6")
  end
end
local function checkIpv6(host)
  local isIpv6 = false
  if gf:isIos() and not isDisableIPv6() then
    local addrInfo, err = socket.dns.getaddrinfo(host)
    if addrInfo then
      for k, v in pairs(addrInfo) do
        if v.family == "inet6" then
          isIpv6 = true
          host = v.addr
          Log:I("Use IPv6!")
          break
        end
      end
    end
  end
  return isIpv6, host
end
function Connection:ctor(isAAA, type)
  self.type = type or CONNECT_TYPE.NORMAL
  self.isAAA = isAAA
  self._socketObject = nil
  self._nextReceiveSize = Packet:GetHeaderLen()
  self._processHeader = true
  self._header = ""
  self._socketNo = g_socket_no
  self._cacheData = nil
  g_socket_no = g_socket_no + 1
  self.sendBuf = string.rep("\000", SEND_BUFFER_SIZE)
end
local _connect = function(tcp, host, port, onConnected, onDisconnected)
  if not tcp then
    return
  end
  tcp:settimeout(0)
  local startTime = os.time()
  local function _checkConn()
    local r, err = tcp:connect(host, port)
    if "closed" == err then
      if onDisconnected then
        onDisconnected()
      end
      return false, true
    elseif 1 == r or "already connected" == err then
      if onConnected then
        onConnected()
      end
      return true, false
    elseif os.time() - startTime >= 10 then
      if onDisconnected then
        onDisconnected()
      end
      tcp:close()
      return false, true
    end
    return false, false
  end
  local checkLoop
  function checkLoop()
    GameMgr:registFrameFunc(FRAME_FUNC_TAG.CHECK_CONNECT, function()
      local conn, timeout = _checkConn()
      if conn or timeout then
        GameMgr:unRegistFrameFunc(FRAME_FUNC_TAG.CHECK_CONNECT)
      end
    end)
  end
  checkLoop()
end
function Connection:connect(host, port)
  self.curHost = host
  local isIpv6 = false
  local netCheckLog = {}
  if gf:isIos() and not isDisableIPv6() then
    do
      local newHost
      local r, e = pcall(function()
        isIpv6, newHost = checkIpv6(host)
      end)
      if not r then
        isIpv6 = false
        Client:pushDebugInfo("checkIpv6 error: " .. tostring(e))
        netCheckLog.getInto = "ipv4"
      else
        netCheckLog.memo = string.format("ipv4:%s:%s", tostring(host), tostring(port))
        host = newHost
        netCheckLog.getInto = "ipv6"
      end
    end
  else
    netCheckLog.getInto = "ipv4"
  end
  local tcp, e
  if isIpv6 then
    tcp, e = socket.tcp6()
  else
    tcp, e = socket.tcp()
  end
  netCheckLog.getIntoIp = host
  netCheckLog.getIntoPort = port
  if not tcp then
    self._socketObject = nil
    self:pushMsg({
      MSG = 4968,
      isAAA = self.isAAA
    })
    Log:E(string.format("connection create tcp socket failed(error : %s)!", e))
    return
  end
  _connect(tcp, host, port, function()
    self:disconnect()
    self._socketObject = tcp
    tcp:settimeout(60)
    if self.isAAA then
      self:pushMsg({MSG = 45110, result = true})
    else
      self:pushMsg({MSG = 4966, result = true})
    end
    Log:D(":Connect to " .. host .. ":" .. port .. " successfully. [ConnectType:" .. self.type .. "]")
  end, function()
    if self.isAAA then
      if CommThread:getConnectionAAA(self.type) == self then
        self:pushMsg({
          MSG = 45110,
          result = false,
          netCheckLog = netCheckLog
        })
      end
    elseif CommThread:getConnection(self.type) == self then
      self:pushMsg({
        MSG = 4966,
        result = false,
        netCheckLog = netCheckLog
      })
    end
  end)
  return true
end
function Connection:disconnect()
  if nil == self._socketObject then
    return
  end
  self._socketObject:shutdown("send")
  local size = 0
  while size ~= nil do
    size, _ = self:receive()
  end
  if self._socketObject then
    self._socketObject:close()
  end
  self._socketObject = nil
  Log:D("disconnect socket.")
end
function Connection:isConnected()
  return self._socketObject ~= nil
end
function Connection:sendBuffer(buffer, length)
  local sock = self._socketObject
  if nil == sock then
    return
  end
  if not sock:send(buffer, 1, length) then
    self._socketObject = nil
    self:pushMsg({
      MSG = 4968,
      isAAA = self.isAAA
    })
    return
  end
end
function Connection:getCacheDataLen()
  if nil ~= self._cacheData then
    return string.len(self._cacheData)
  end
  return 0
end
function Connection:appendCacheData(s)
  if nil ~= self._cacheData then
    self._cacheData = self._cacheData .. s
    return
  end
  self._cacheData = s
end
function Connection:popFrontCacheData(size)
  local data = self._cacheData
  if size >= self:getCacheDataLen() then
    self._cacheData = nil
  else
    self._cacheData = string.sub(data, size + 1, -1)
  end
  return data
end
function Connection:receive()
  local sock = self._socketObject
  if sock == nil then
    return
  end
  if not gf:isWindows() and sock:getfd() >= socket._SETSIZE then
    Log:D(string.format("Socket fd(%d) is larger then %d", sock:getfd(), socket._SETSIZE))
    Client:pushDebugInfo(string.format("Socket fd(%d) is larger then %d", sock:getfd(), socket._SETSIZE))
    self._socketObject = nil
    self:pushMsg({
      MSG = 4968,
      isAAA = self.isAAA
    })
    return
  end
  local forread, _, _ = socket.select({sock}, nil, 0)
  for _, v in ipairs(forread) do
    if v ~= sock then
      Log:D("COM DEBUG: Connection:receive[Socket:select]")
      return
    end
    local maxSizePerTime = 6144
    local canReceiveSize = maxSizePerTime
    local cacheDataLen = self:getCacheDataLen()
    if maxSizePerTime >= self._nextReceiveSize - cacheDataLen then
      canReceiveSize = self._nextReceiveSize - cacheDataLen
    else
      canReceiveSize = maxSizePerTime
    end
    local s, e, s2 = sock:receive(canReceiveSize)
    if e == "closed" then
      Log:D("Socket status is : " .. e .. " [ConnectType:" .. tostring(self.type) .. "]")
      Client:pushDebugInfo("Socket status is : " .. e .. " [ConnectType:" .. tostring(self.type) .. "]")
      self._socketObject = nil
      self:pushMsg({
        MSG = 4968,
        isAAA = self.isAAA
      })
      return
    end
    if e ~= nil then
      s = s2
    else
    end
    if s == nil then
      return
    end
    self:appendCacheData(s)
    if self:getCacheDataLen() < self._nextReceiveSize then
      return
    end
    local data = self:popFrontCacheData(self._nextReceiveSize)
    return self:onReceiveData(data)
  end
end
function Connection:pushMsg(msg)
  msg.connect_type = self.type
  MessageMgr:pushMsg(msg)
end
function Connection:onReceiveData(data)
  if nil == data then
    return 0
  end
  local size = self._nextReceiveSize
  Client:addRecvDataSize(size)
  if self._processHeader then
    self._nextReceiveSize = string.byte(data, -2) * 256 + string.byte(data, -1)
    self._processHeader = false
    self._header = data
    return size
  else
    self._nextReceiveSize = Packet:GetHeaderLen()
    self._processHeader = true
    if Packet.ParseHead then
      local ret = Packet:ParseHead(self._header, data)
      if ret then
        data = ret
      end
    end
    self._header = ""
    return size, self:parseData(data)
  end
end
function Connection:MSG_PREPARE_MULTI_PACKET(pkt, data)
  if multiPacketInfo then
    Log:W("MSG_PREPARE_MULTI_PACKET error")
    return
  end
  local msg = pkt:GetShort()
  local totalNum = pkt:GetShort()
  local totalLen = pkt:GetLong()
  multiPacketInfo = {}
  multiPacketInfo.msg = msg
  multiPacketInfo.totalNum = totalNum
  multiPacketInfo.totalLen = totalLen
  multiPacketInfo.buf = {}
  multiPacketInfo.receiveLen = 0
end
function Connection:MSG_SEND_MULTI_PACKET(data)
  if not multiPacketInfo or not next(multiPacketInfo) then
    Log:W("MSG_SEND_MULTI_PACKET error")
    return
  end
  local b3, b4 = string.byte(data, 3, 4)
  local bufLen = (b3 or 0) * 256 + (b4 or 0)
  local binaryStr = string.sub(data, 5, 4 + bufLen)
  table.insert(multiPacketInfo.buf, binaryStr)
  multiPacketInfo.receiveLen = multiPacketInfo.receiveLen + #binaryStr
  if multiPacketInfo.receiveLen == multiPacketInfo.totalLen then
    multiPacketInfo.buf = table.concat(multiPacketInfo.buf)
    local data = self:parseData(multiPacketInfo.buf)
    multiPacketInfo = nil
    return data
  end
end
function Connection:parseData(data)
  local b1, b2 = string.byte(data, 1, 2)
  local msg = b1 * 256 + b2
  local msgStr = Msg[msg]
  if msgStr == "MSG_SEND_MULTI_PACKET" then
    return self:MSG_SEND_MULTI_PACKET(data)
  end
  local pkt = Packet:New(data, string.len(data), PACKET_READ)
  local ret = self:parsePacket(pkt, data)
  pkt:Destroy()
  return ret
end
function Connection:parsePacket(pkt, rawData)
  local msg = pkt:GetShort()
  local msgStr = Msg[msg]
  if nil == msgStr then
    Log:W(string.format("No msg %04X in global_send.", msg))
    return
  end
  if ATM_IS_DEBUG_VER and msgStr ~= "MSG_REPLY_ECHO" then
    Log:D("[RECV MSG : " .. msgStr .. "]" .. "  [ConnectType:" .. tostring(self.type) .. "]")
  end
  if msgStr == "MSG_PREPARE_MULTI_PACKET" then
    return self:MSG_PREPARE_MULTI_PACKET(pkt, {})
  end
  local data = {
    MSG = msg,
    socket_no = self._socketNo,
    timestamp = gfGetTickCount(),
    connect_type = self.type
  }
  if type(As) == "table" then
    if 0 <= As:call(msgStr, pkt, msg, self._socketNo or 0, self.type or CONNECT_TYPE.NORMAL) then
      data = __as_data__
    end
  else
    local func = MsgParser[msgStr]
    if nil == func then
      if GlobalSendNoPacket[msgStr] then
        func = MsgParser.MSG_NO_PACKET
      else
        Log:W(msgStr .. " has no parser in MsgParser.")
        return
      end
    end
    func(MsgParser, pkt, data, rawData)
  end
  if ATM_IS_DEBUG_VER and msgStr ~= "MSG_REPLY_ECHO" and msgStr ~= "MSG_ACHIEVE_CONFIG" then
    gf:PrintMap(data)
  end
  return data
end
function Connection:sendCmdToServer(cmd, data)
  local size = SEND_BUFFER_SIZE
  local buf = self.sendBuf
  local pkt = Packet:New(buf, size, PACKET_WRITE)
  pkt:PutChar(string.byte("M"))
  pkt:PutChar(string.byte("Z"))
  pkt:PutShort(0)
  pkt:PutLong(gfGetTickCount())
  pkt:PutShort(0)
  local cmd_int = Cmd[cmd]
  if nil == cmd_int then
    Log:W("No cmd " .. cmd .. " in global_send.")
    pkt:Destroy()
    return
  end
  pkt:PutShort(cmd_int)
  if ATM_IS_DEBUG_VER and cmd ~= "CMD_ECHO" then
    Log:D("[SEND CMD : " .. cmd .. "]" .. "  [ConnectType:" .. tostring(self.type) .. "]")
  end
  local func = CmdParser[cmd]
  if nil == func then
    if GlobalSendNoPacket[cmd] then
      func = CmdParser.CMD_NO_PACKET
    else
      Log:W(cmd .. " has no parser in CmdParser.")
      pkt:Destroy()
      return
    end
  end
  if nil ~= data then
    func(CmdParser, pkt, data)
  end
  pkt:SetMsgLen()
  local len = Packet:GetHeaderLen() + pkt:GetMsgLen()
  self:sendBuffer(buf, len)
  Client:addSendDataSize(len)
  if ATM_IS_DEBUG_VER and cmd ~= "CMD_ECHO" then
    gf:PrintMap(data)
  end
  pkt:Destroy()
end
return Connection
