local SMsgParser = {}
local Msg = require("comm/global_send")
SMsgParser.__index = SMsgParser
local adjustDir = function(dir)
  if dir <= 0 then
    return 0
  elseif dir >= 7 then
    return 7
  else
    return dir
  end
end
local isNilOrEmpty = function(s)
  return nil == s or "" == s
end
function SMsgParser:MSG_L_LOGIN_PREVIEW_PLAYER(pkt, data)
  data.account = pkt:GetLenString()
  data.gid = pkt:GetLenString()
  data.time = pkt:GetLong()
  data.cookie = pkt:GetLenString()
  data.server_name = pkt:GetLenString()
  data.ip = pkt:GetLenString()
  data.port = pkt:GetShort()
end
function SMsgParser:MSG_LOGIN_PREVIEW_DATA(pkt, data)
  data.gid = pkt:GetLenString()
  data.name = pkt:GetLenString()
  data.server_name = pkt:GetLenString()
  data.extra_life = pkt:GetLong()
  data.extra_mana = pkt:GetLong()
  data.backup_loyalty = pkt:GetLong()
  data.double_point = pkt:GetLong()
  data.double_point_open = pkt:GetChar()
  data.jiji_point = pkt:GetLong()
  data.jiji_point_open = pkt:GetChar()
  data.ruyi_point = pkt:GetLong()
  data.ruyi_point_open = pkt:GetChar()
  data.pet_double_point = pkt:GetLong()
  data.pet_double_point_open = pkt:GetChar()
  data.ziq_point = pkt:GetLong()
  data.ziq_point_open = pkt:GetChar()
  data.tao_type = pkt:GetLenString()
  data.tao_speed = pkt:GetLong()
  data.change_card_time = pkt:GetLong()
  data.deposit_time = pkt:GetLong()
  data.deposit_use_time = pkt:GetLong()
  data.leader_gid = pkt:GetLenString()
  data.cur_life = pkt:GetLong()
  data.max_life = pkt:GetLong()
  data.cur_mana = pkt:GetLong()
  data.max_mana = pkt:GetLong()
  data.cur_exp = pkt:GetLong()
  data.max_exp = pkt:GetLong()
  data.is_real_body = pkt:GetChar()
  data.me_level = pkt:GetShort()
  data.me_icon = pkt:GetShort()
  data.upgrade_type = pkt:GetChar()
  data.upgrade_level = pkt:GetShort()
  data.upgrade_exp = pkt:GetLong()
  data.upgrade_max_exp = pkt:GetLong()
  data.inner_exp = pkt:GetLong()
  data.inner_max_exp = pkt:GetLong()
  data.pet_icon = pkt:GetShort()
  data.pet_level = pkt:GetShort()
  data.pet_life = pkt:GetLong()
  data.pet_max_life = pkt:GetLong()
  data.pet_mana = pkt:GetLong()
  data.pet_max_mana = pkt:GetLong()
  data.pet_exp = pkt:GetLong()
  data.pet_max_exp = pkt:GetLong()
  data.map_id = pkt:GetLong()
  data.x = pkt:GetShort()
  data.y = pkt:GetShort()
  data.in_combat = pkt:GetChar()
  data.is_my_house = pkt:GetChar()
  data.combat_pet_longevity = pkt:GetSignedLong()
  data.wait_time = pkt:GetLong()
  data.tao_times = pkt:GetLong()
  data.artifact_nimbus = pkt:GetLong()
  data.token = pkt:GetLenString()
end
function SMsgParser:MSG_LOGIN_PREVIEW_UNCOMBAT_DATA(pkt, data)
  data.leader_gid = pkt:GetLenString()
  data.team_size = pkt:GetChar()
  data.sight_scope_setting = pkt:GetChar()
  data.task_count = pkt:GetShort()
  data.task_list = {}
  for i = 1, data.task_count do
    local tmp = {}
    tmp.task_name = pkt:GetLenString()
    tmp.task_desc = pkt:GetLenString()
    data.task_list[i] = tmp
  end
  data.member_count = pkt:GetShort()
  data.member_list = {}
  for i = 1, data.member_count do
    local tmp = {}
    pkt:GetShort()
    self:MSG_UPDATE_APPEARANCE(pkt, tmp)
    data.member_list[i] = tmp
  end
end
function SMsgParser:MSG_LOGIN_PREVIEW_COMBAT_DATA(pkt, data)
  data.round = pkt:GetShort()
  data.user_is_multi = pkt:GetChar()
  data.user_round = pkt:GetChar()
  data.my_action = pkt:GetChar()
  data.user_next_action = pkt:GetChar()
  data.my_para = pkt:GetSignedLong()
  data.user_next_para = pkt:GetSignedLong()
  data.pet_is_multi = pkt:GetChar()
  data.pet_round = pkt:GetChar()
  data.pet_action = pkt:GetChar()
  data.pet_next_action = pkt:GetChar()
  data.pet_para = pkt:GetSignedLong()
  data.pet_next_para = pkt:GetSignedLong()
  data.fight_friend_count = pkt:GetShort()
  data.fight_friend_list = {}
  for i = 1, data.fight_friend_count do
    local tmp = {}
    tmp.combat_pos = 21 - pkt:GetChar()
    tmp.is_died = pkt:GetChar()
    tmp.life = pkt:GetLong()
    tmp.max_life = pkt:GetLong()
    tmp.mana = pkt:GetLong()
    tmp.max_mana = pkt:GetLong()
    tmp.rank = pkt:GetShort()
    pkt:GetShort()
    self:MSG_UPDATE_APPEARANCE(pkt, tmp)
    data.fight_friend_list[i] = tmp
  end
  data.fight_opponent_count = pkt:GetShort()
  data.fight_opponent_list = {}
  for i = 1, data.fight_opponent_count do
    local tmp = {}
    tmp.combat_pos = pkt:GetChar()
    tmp.is_died = pkt:GetChar()
    tmp.rank = pkt:GetShort()
    pkt:GetShort()
    self:MSG_UPDATE_APPEARANCE(pkt, tmp)
    data.fight_opponent_list[i] = tmp
  end
end
function SMsgParser:MSG_UPDATE_APPEARANCE(pkt, data)
  data.id = pkt:GetLong()
  data.x = pkt:GetShort()
  data.y = pkt:GetShort()
  data.dir = adjustDir(pkt:GetShort())
  data.icon = pkt:GetLong()
  data.weapon_icon = pkt:GetLong()
  data.type = pkt:GetShort()
  data.sub_type = pkt:GetLong()
  data.owner_id = pkt:GetLong()
  data.leader_id = pkt:GetLong()
  data.name = pkt:GetLenString()
  data.level = pkt:GetShort()
  data.title = pkt:GetLenString()
  data.family = pkt:GetLenString()
  data["party/name"] = pkt:GetLenString()
  data.status = pkt:GetLong()
  data.special_icon = pkt:GetLong()
  if pkt:GetDataLen() >= 4 then
    data.org_icon = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.suit_icon = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.suit_light_effect = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.guard_icon = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.pet_icon = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.shadow_icon = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.shelter_icon = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.mount_icon = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 1 then
    data.alicename = pkt:GetLenString()
  end
  data.gid = pkt:GetLenString()
  data.camp = pkt:GetLenString()
  data.vip_type = pkt:GetChar()
  data.isHide = pkt:GetChar()
  data.moveSpeedPercent = pkt:GetSignedChar()
  data["ct_data/score"] = pkt:GetSignedLong()
  data.opacity = pkt:GetChar()
  data.masquerade = pkt:GetLong()
  data["upgrade/state"] = pkt:GetChar()
  data["upgrade/type"] = pkt:GetChar()
  data.obstacle = pkt:GetChar()
  data.light_effect_count = pkt:GetShort()
  data.light_effect = {}
  for i = 1, data.light_effect_count do
    local effect = pkt:GetLong()
    table.insert(data.light_effect, effect)
  end
  if pkt:GetDataLen() >= 4 then
    data.share_mount_icon = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.share_mount_leader_id = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 4 then
    data.share_mount_shadow = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 2 then
    data.gather_count = math.max(pkt:GetShort() - 1, 0)
    data.gather_icons = {}
    if pkt:GetDataLen() >= 4 * data.gather_count and 1 <= data.gather_count then
      data.mount_icon = pkt:GetLong()
      for i = 1, data.gather_count do
        table.insert(data.gather_icons, pkt:GetLong())
      end
    end
    if pkt:GetDataLen() >= 2 then
      data.gather_name_num = pkt:GetShort()
    end
    data.gather_names = {}
    if pkt:GetDataLen() > 0 then
      for i = 1, data.gather_name_num do
        table.insert(data.gather_names, pkt:GetLenString())
      end
    end
  end
  if pkt:GetDataLen() >= 4 then
    data.portrait = pkt:GetLong()
  end
  if pkt:GetDataLen() >= 1 then
    local customIcon = pkt:GetLenString()
    if not isNilOrEmpty(customIcon) then
      data.part_index, data.part_color_index = string.match(customIcon, "(.+):(.+)")
    else
      data.part_index, data.part_color_index = "", ""
    end
  end
  if pkt:GetDataLen() >= 2 then
    data.team_icon = pkt:GetShort()
  end
  if pkt:GetDataLen() >= 2 then
    data.extra_scale = pkt:GetShort()
  end
  if pkt:GetDataLen() >= 2 then
    local gather_count = math.max(pkt:GetShort() - 1, 0)
    data.gather_suit_icons = {}
    if pkt:GetDataLen() >= 4 * gather_count and gather_count >= 1 then
      data.mount_suit_icon = pkt:GetLong()
      for i = 1, gather_count do
        table.insert(data.gather_suit_icons, pkt:GetLong())
      end
    end
  end
  if pkt:GetDataLen() >= 1 then
    data.ban_rule = pkt:GetLenString()
  end
  if pkt:GetDataLen() >= 1 then
    data.title_ban_rule = pkt:GetLenString()
  end
end
return SMsgParser
