local SCmdParser = {}
SCmdParser.__index = SCmdParser
function SCmdParser:CMD_L_QUICK_LOGIN_PREVIEW_PLAYER(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutLenString(data.token)
end
return SCmdParser
