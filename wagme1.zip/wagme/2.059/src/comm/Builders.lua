local Builders = {}
Builders._fields = require("comm/Fields")
Builders._objectDefaultFields = require("comm/ObjectDefaultFields")
local FIELD_INT8 = 1
local FIELD_INT16 = 2
local FIELD_INT32 = 3
local FIELD_STRING = 4
local FIELD_LONG_STRING = 5
local FIELD_UINT8 = 6
local FIELD_UINT16 = 7
local FIELD_UINT32 = 8
local FIELDS_BASIC = 1
local FIELDS_VALUE = 2
local FIELDS_SCALE = 3
local FIELDS_HORCRUX = 4
local FIELDS_HORCRUX_PREVIEW = 5
local FIELDS_GHOST_PEIYUAN = 24
local FIELDS_GHOST_NINGSHEN = 25
local FIELDS_GHOST_GONGSHENG = 26
local STONE_START = 12
local STONE_END = 22
local FIELDS_MOUNT_ATTRIB = 23
local FIELDS_TEMP_PROP = 27
function Builders:BuildFields(pkt, data, suffix)
  local count = pkt:GetShort()
  for i = 1, count do
    local no = pkt:GetShort()
    local key = self._fields[no]
    if suffix ~= nil then
      key = key .. suffix
    end
    if not key then
      assert(nil, "BuildFields no find field " .. no)
    end
    if key ~= nil then
      local type = pkt:GetChar()
      if type == FIELD_INT8 then
        data[key] = pkt:GetSignedChar()
      elseif type == FIELD_UINT8 then
        data[key] = pkt:GetChar()
      elseif type == FIELD_INT16 then
        data[key] = pkt:GetSignedShort()
      elseif type == FIELD_UINT16 then
        data[key] = pkt:GetShort()
      elseif type == FIELD_INT32 then
        data[key] = pkt:GetSignedLong()
      elseif type == FIELD_UINT32 then
        data[key] = pkt:GetLong()
      elseif type == FIELD_STRING then
        data[key] = pkt:GetLenString()
      elseif type == FIELD_LONG_STRING then
        data[key] = pkt:GetLenString2()
      end
      if no == 879 then
        data[key] = string.gsub(data[key], CHS[6000310], CHS[5440001])
        data[key] = string.gsub(data[key], CHS[6000324], CHS[5440002])
      end
    end
  end
end
function Builders:BuildItemInfo(pkt, data)
  local extra = {}
  local groupCount = pkt:GetShort()
  for i = 1, groupCount do
    local groupNo = pkt:GetChar()
    local groupType = pkt:GetChar()
    if groupType == FIELDS_BASIC then
      Builders:BuildFields(pkt, data)
    elseif groupType == FIELDS_HORCRUX then
      Builders:BuildHorcruxPropInfo(pkt, data)
    elseif groupType == FIELDS_HORCRUX_PREVIEW then
      Builders:BuildHorcruxPreviewPropInfo(pkt, data)
    else
      local suffix
      if groupType == FIELDS_VALUE then
        suffix = string.format("_%d", groupNo)
      elseif groupType == FIELDS_SCALE then
        suffix = string.format("_scale_%d", groupNo)
      end
      extra[string.format("%d_group", groupNo)] = 1
      Builders:BuildFields(pkt, extra, suffix)
    end
  end
  data.extra = extra
  if self._objectDefaultFields[data.item_type] then
    for k, v in pairs(self._objectDefaultFields[data.item_type]) do
      if not data[k] then
        data[k] = v
      end
    end
  end
end
function Builders:BuildHorcruxPropInfo(pkt, data)
  data.horcrux_prop_count = pkt:GetChar()
  data.horcrux_prop_list = {}
  for i = 1, data.horcrux_prop_count do
    local tmpInfo = {}
    tmpInfo.chaos_value = pkt:GetChar()
    tmpInfo.yang_percent = pkt:GetChar()
    tmpInfo.yang_prop = pkt:GetLenString()
    tmpInfo.yang_prop_value = pkt:GetShort()
    tmpInfo.ying_prop = pkt:GetLenString()
    tmpInfo.ying_prop_value = pkt:GetShort()
    table.insert(data.horcrux_prop_list, tmpInfo)
  end
end
function Builders:BuildHorcruxPreviewPropInfo(pkt, data)
  data.horcrux_prop_preview_count = pkt:GetChar()
  data.horcrux_prop_preview_list = {}
  for i = 1, data.horcrux_prop_preview_count do
    local tmpInfo = {}
    tmpInfo.index = pkt:GetChar()
    tmpInfo.chaos_value = pkt:GetChar()
    tmpInfo.yang_percent = pkt:GetChar()
    tmpInfo.yang_prop = pkt:GetLenString()
    tmpInfo.yang_prop_value = pkt:GetShort()
    tmpInfo.ying_prop = pkt:GetLenString()
    tmpInfo.ying_prop_value = pkt:GetShort()
    table.insert(data.horcrux_prop_preview_list, tmpInfo)
  end
end
function Builders:BuildSkillBasicInfo(pkt, data)
  data.skill_no = pkt:GetShort()
  data.skill_attrib = pkt:GetShort()
  data.skill_level = pkt:GetShort()
  data.level_improved = pkt:GetShort()
  data.skill_mana_cost = pkt:GetShort()
  data.skill_nimbus = pkt:GetLong()
  data.skill_disabled = pkt:GetChar()
  data.range = pkt:GetShort()
  data.max_range = pkt:GetShort()
  local count = pkt:GetShort()
  for i = 1, count do
    data["cost_" .. pkt:GetLenString()] = pkt:GetLong()
  end
  if not data.cost_voucher_or_cash then
    data.cost_voucher_or_cash = 0
  end
  data.isTempSkill = pkt:GetChar()
end
function Builders:BuildPeiYuanInfo(pkt, data)
  data.peiyuan_attrib_count = pkt:GetChar()
  data.petyuan_cur_state_info = {}
  for i = 1, data.peiyuan_attrib_count do
    local attrib_key = pkt:GetLenString()
    data.petyuan_cur_state_info[attrib_key] = {}
    data.petyuan_cur_state_info[attrib_key].active = true
  end
  data.peiyuan_add_info = {}
  data.add_attrib_count = pkt:GetChar()
  for i = 1, data.add_attrib_count do
    local attrib_key = pkt:GetLenString()
    data.peiyuan_add_info[attrib_key] = pkt:GetLong()
  end
  data.pre_attrib_count = pkt:GetChar()
  for i = 1, data.pre_attrib_count do
    local attrib_key = pkt:GetLenString()
    if not data.petyuan_cur_state_info[attrib_key] then
      data.petyuan_cur_state_info[attrib_key] = {}
    end
    data.petyuan_cur_state_info[attrib_key].value = pkt:GetLong()
  end
  data.cost_ghost_gas = pkt:GetLong()
end
function Builders:BuildNingShenInfo(pkt, data)
  data.ningshen_max = pkt:GetChar()
  data.ningshen_info = {}
  for i = 1, data.ningshen_max do
    local index = pkt:GetChar()
    local attrib_count = pkt:GetChar()
    data.ningshen_info[index] = {}
    for i = 1, attrib_count do
      local info = {}
      info.attrib_key = pkt:GetLenString()
      info.value = pkt:GetLong()
      info.max_value = pkt:GetLong()
      table.insert(data.ningshen_info[index], info)
    end
  end
end
function Builders:BuildGongShengInfo(pkt, data)
  data.gongsheng_pet_name = pkt:GetLenString()
  data.gongsheng_peiyuan_stage = pkt:GetChar()
  data.gongsheng_peiyuan_level = pkt:GetChar()
  data.gongsheng_add_life = pkt:GetLong()
  data.gongsheng_add_mana = pkt:GetLong()
  data.gongsheng_add_speed = pkt:GetLong()
  data.gongsheng_add_phy = pkt:GetLong()
  data.gongsheng_add_mag = pkt:GetLong()
  data.gongsheng_all_shape = pkt:GetLong()
end
function Builders:BuildPetInfo(pkt, data)
  local count = pkt:GetShort()
  data.stone_num = 0
  local j = 1
  for i = 1, count do
    local no = pkt:GetChar()
    local type = pkt:GetChar()
    if type == FIELDS_BASIC then
      self:BuildFields(pkt, data)
    elseif no == FIELDS_GHOST_PEIYUAN then
      self:BuildPeiYuanInfo(pkt, data)
    elseif no == FIELDS_GHOST_NINGSHEN then
      self:BuildNingShenInfo(pkt, data)
    elseif no == FIELDS_GHOST_GONGSHENG then
      self:BuildGongShengInfo(pkt, data)
    elseif no == FIELDS_TEMP_PROP then
      local groupData = {no = no}
      self:BuildFields(pkt, groupData)
      data["group_" .. no] = groupData
    else
      local groupData = {no = no}
      self:BuildFields(pkt, groupData)
      data["group_" .. no] = groupData
      if no >= STONE_START and no <= STONE_END then
        data.stone_num = data.stone_num + 1
      end
      j = j + 1
    end
  end
  data.group_num = j - 1
end
return Builders
