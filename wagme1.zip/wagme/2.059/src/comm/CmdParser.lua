local CmdParser = {}
setmetatable(CmdParser, SCmdParser)
function CmdParser:CMD_ADMIN_TEST_SKILL(pkt, data)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_ECHO(pkt, data)
  pkt:PutLong(data.current_time)
  pkt:PutLong(data.peer_time)
end
function CmdParser:MSG_REPLY_ECHO(pkt, data)
  pkt:PutLong(data.reply_time)
end
function CmdParser:CMD_L_GET_ANTIBOT_QUESTION(pkt, data)
  pkt:PutLenString(data.account)
end
function CmdParser:CMD_L_CHECK_USER_DATA(pkt, data)
  pkt:PutLenString4(data.data)
end
function CmdParser:CMD_L_ACCOUNT(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.account)
  pkt:PutLenString(data.password)
  pkt:PutLenString(data.mac)
  pkt:PutLenString(data.oaid)
  pkt:PutLenString(data.data)
  pkt:PutLenString(data.lock)
  pkt:PutLenString(data.dist)
  pkt:PutChar(data.from3rdSdk)
  pkt:PutLenString(data.channel)
  pkt:PutLenString(data.os_ver)
  pkt:PutLenString(data.term_info)
  pkt:PutLenString(data.imei)
  pkt:PutLenString(data.client_original_ver)
  pkt:PutChar(data.not_replace)
  pkt:PutChar(data.oper_type or 0)
  pkt:PutLenString(data.m_value or "")
  pkt:PutLenString2(data.device_info or "")
end
function CmdParser:CMD_L_GET_SERVER_LIST(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutLong(data.auth_key)
  pkt:PutLenString(data.dist)
end
function CmdParser:CMD_L_CLIENT_CONNECT_AGENT(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutLong(data.auth_key)
  pkt:PutLenString(data.server)
end
function CmdParser:CMD_LOGIN(pkt, data)
  pkt:PutLenString(data.user)
  pkt:PutLong(data.auth_key)
  pkt:PutLong(data.seed)
  pkt:PutChar(data.emulator)
  pkt:PutChar(data.sight_scope)
  pkt:PutLenString(data.version)
  pkt:PutLenString(data.clientid)
  pkt:PutShort(data.netStatus)
  pkt:PutChar(data.adult)
  pkt:PutLenString(data.signature)
  pkt:PutLenString(data.clientname)
  pkt:PutChar(data.redfinger and 1 or 0)
  if not data.loginType then
    data.loginType = 0
  end
  pkt:PutLong(data.loginType)
  pkt:PutChar(data.root and 1 or 0)
end
function CmdParser:CMD_LOAD_EXISTED_CHAR(pkt, data)
  pkt:PutLenString(data.char_name)
  pkt:PutChar(data.play_combat or 0)
end
function CmdParser:CMD_LOGOUT(pkt, data)
  pkt:PutChar(data.reason)
end
function CmdParser:CMD_CHAT_EX(pkt, data)
  pkt:PutShort(data.channel)
  pkt:PutShort(data.compress or 0)
  pkt:PutShort(data.orgLength or 0)
  pkt:PutLenString2(data.msg)
  pkt:PutShort(data.cardCount or 0)
  for i = 1, data.cardCount or 0 do
    pkt:PutLenString(data.cardParam)
  end
  pkt:PutLong(data.voiceTime or 0)
  pkt:PutLenString2(data.token or "")
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_SELECT_MENU_ITEM(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.menu_item)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_C_END_ANIMATE(pkt, data)
  pkt:PutLong(data.answer)
end
function CmdParser:CMD_C_DO_ACTION(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLong(data.victim_id)
  pkt:PutLong(data.action)
  pkt:PutLong(data.para)
  pkt:PutLenString(data.para1)
  pkt:PutLenString(data.para2)
  pkt:PutLenString(data.para3)
  pkt:PutLenString(data.skill_talk)
end
function CmdParser:CMD_C_CATCH_PET(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_MULTI_MOVE_TO(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLong(data.map_id)
  pkt:PutLong(data.map_index)
  local count = data.count
  pkt:PutShort(count)
  for i = 1, count do
    pkt:PutShort(data[string.format("x%d", i)])
    pkt:PutShort(data[string.format("y%d", i)])
  end
  pkt:PutShort(data.dir)
  pkt:PutLong(data.send_time)
end
function CmdParser:CMD_OTHER_MOVE_TO(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLong(data.map_id)
  pkt:PutShort(data[string.format("x%d", data.count)])
  pkt:PutShort(data[string.format("y%d", data.count)])
  pkt:PutShort(data.dir)
end
function CmdParser:CMD_REQUEST_ITEM_INFO(pkt, data)
  pkt:PutLenString(data.item_cookie)
end
function CmdParser:CMD_ENTER_ROOM(pkt, data)
  pkt:PutLenString(data.room_name)
  pkt:PutChar(data.isTaskWalk or 0)
end
function CmdParser:CMD_GENERAL_NOTIFY(pkt, data)
  pkt:PutShort(data.type)
  pkt:PutLenString(data.para1 or "")
  pkt:PutLenString(data.para2 or "")
end
function CmdParser:CMD_CHANGE_TITLE(pkt, data)
  pkt:PutLenString(data.select)
end
function CmdParser:CMD_OPEN_MENU(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.type or 1)
end
function CmdParser:CMD_NO_PACKET(pkt, data)
end
function CmdParser:CMD_KICKOUT(pkt, data)
  pkt:PutLenString(data.peer_name)
end
function CmdParser:CMD_ACCEPT(pkt, data)
  pkt:PutLenString(data.peer_name)
  pkt:PutLenString(data.ask_type)
end
function CmdParser:CMD_REJECT(pkt, data)
  pkt:PutLenString(data.peer_name)
  pkt:PutLenString(data.ask_type)
end
function CmdParser:CMD_REQUEST_JOIN(pkt, data)
  pkt:PutLenString(data.peer_name)
  pkt:PutLong(data.id or 0)
  pkt:PutLenString(data.ask_type)
end
function CmdParser:CMD_CHANGE_TEAM_LEADER(pkt, data)
  pkt:PutLenString(data.new_leader_id)
  pkt:PutChar(data.type or 0)
end
function CmdParser:CMD_C_SELECT_MENU_ITEM(pkt, data)
  pkt:PutLenString(data.menu_item)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_OPER_TELEPORT_ITEM(pkt, data)
  pkt:PutLong(data.id or 0)
  pkt:PutShort(data.oper)
  pkt:PutShort(data.para1 or 0)
  pkt:PutLenString(data.para2 or "")
end
function CmdParser:CMD_ASSIGN_ATTRIB(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.type)
  pkt:PutShort(data.para1)
  pkt:PutShort(data.para2)
  pkt:PutShort(data.para3)
  pkt:PutShort(data.para4)
  pkt:PutShort(data.para5 or 0)
  pkt:PutShort(data.para6 or 0)
end
function CmdParser:CMD_PRE_ASSIGN_ATTRIB(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.type)
  pkt:PutShort(data.para1)
  pkt:PutShort(data.para2)
  pkt:PutShort(data.para3)
  pkt:PutShort(data.para4)
  pkt:PutShort(data.para5 or 0)
end
function CmdParser:CMD_SET_RECOMMEND_ATTRIB(pkt, data)
  pkt:PutLong(data.id or 0)
  pkt:PutChar(data.con or 0)
  pkt:PutChar(data.wiz or 0)
  pkt:PutChar(data.str or 0)
  pkt:PutChar(data.dex or 0)
  pkt:PutChar(data.auto_add or 0)
  pkt:PutChar(data.plan or 0)
end
function CmdParser:CMD_SELECT_VISIBLE_PET(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.capcity_type)
end
function CmdParser:CMD_SELECT_CURRENT_PET(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.pet_status)
end
function CmdParser:CMD_DROP_PET(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_SET_PET_NAME(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_LEARN_SKILL(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.skill_no)
  pkt:PutShort(data.up_level)
end
function CmdParser:CMD_DOWNGRADE_SKILL(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLong(data.skill_no)
end
function CmdParser:CMD_APPLY(pkt, data)
  pkt:PutChar(data.pos)
  pkt:PutShort(data.amount)
end
function CmdParser:CMD_APPLY_EX(pkt, data)
  pkt:PutChar(data.pos)
  pkt:PutShort(data.amount)
  pkt:PutLenString(data.str or "")
end
function CmdParser:CMD_FEED_PET(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutChar(data.pos)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_APPLY_CHONGWU_JINGYANDAN(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutShort(data.num1)
  pkt:PutShort(data.num2)
end
function CmdParser:CMD_FEED_GUARD(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.pos)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_SORT_PACK(pkt, data)
  pkt:PutShort(data.count)
  pkt:PutLenString2(data.range)
  pkt:PutShort(data.start_pos)
  pkt:PutLenString2(data.to_store_cards or "")
end
function CmdParser:CMD_TELEPORT(pkt, data)
  pkt:PutLong(data.map_id)
  pkt:PutLong(data.x or 0)
  pkt:PutLong(data.y or 0)
  pkt:PutChar(data.isTaskWalk or 0)
end
function CmdParser:CMD_SET_RECOMMEND_POLAR(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.para1)
  pkt:PutChar(data.para2)
  pkt:PutChar(data.para3)
  pkt:PutChar(data.para4)
  pkt:PutChar(data.para5)
  pkt:PutChar(data.auto_add)
  pkt:PutChar(data.plan)
end
function CmdParser:CMD_REFRESH_SERVICE_LOG(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_REFRESH_TASK_LOG(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_GET(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_MOVE_ON_CARPET(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_SHIFT(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.x)
  pkt:PutShort(data.y)
  pkt:PutShort(data.dir)
end
function CmdParser:CMD_SET_SHAPE_TEMP(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutChar(data.is_set)
end
function CmdParser:CMD_PRE_UPGRADE_EQUIP(pkt, data)
  pkt:PutShort(data.pos)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_UPGRADE_EQUIP(pkt, data)
  pkt:PutShort(data.pos)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_GUARDS_CHANGE_NAME(pkt, data)
  pkt:PutLong(data.guard_id)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_GUARDS_CHEER(pkt, data)
  pkt:PutLong(data.guard_id)
  pkt:PutChar(data.cheer)
end
function CmdParser:CMD_BATCH_BUY(pkt, data)
  pkt:PutLong(data.cash or 0)
  local count = data.count
  pkt:PutChar(count)
  for name, num in pairs(data) do
    if name ~= "cash" and name ~= "count" then
      pkt:PutLenString(name)
      pkt:PutLong(num)
    end
  end
end
function CmdParser:CMD_VERIFY_FRIEND(pkt, data)
  pkt:PutLenString(data.char_name)
  pkt:PutLenString(data.char_gid)
  pkt:PutLenString(data.message)
end
function CmdParser:CMD_ADD_FRIEND(pkt, data)
  pkt:PutLenString(data.group)
  pkt:PutLenString(data.char)
  pkt:PutLong(data.icon or 0)
  pkt:PutShort(data.level or 0)
end
function CmdParser:CMD_REMOVE_FRIEND(pkt, data)
  pkt:PutLenString(data.group)
  pkt:PutLenString(data.char)
end
function CmdParser:CMD_REFRESH_FRIEND(pkt, data)
  pkt:PutLenString(data.group)
  pkt:PutLenString(data.char)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_FINGER(pkt, data)
  pkt:PutLenString(data.char)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.from)
end
function CmdParser:CMD_CREATE_NEW_CHAR(pkt, data)
  pkt:PutLenString(data.char_name)
  pkt:PutShort(data.gender)
  pkt:PutShort(data.polar)
end
function CmdParser:CMD_KILL(pkt, data)
  pkt:PutLong(data.victim_id)
  pkt:PutShort(data.flag or 0)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_CLEAN_REQUEST(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_FRIEND_TELL_EX(pkt, data)
  pkt:PutShort(data.flag)
  pkt:PutLenString(data.name)
  pkt:PutShort(data.compress)
  pkt:PutShort(data.orgLength)
  pkt:PutLenString2(data.msg)
  pkt:PutShort(data.cardCount or 0)
  for i = 1, data.cardCount or 0 do
    pkt:PutLenString(data.cardParam)
  end
  pkt:PutLong(data.voiceTime or 0)
  pkt:PutLenString2(data.token or "")
  pkt:PutLenString(data.receive_gid)
  pkt:PutLenString2(data.push_msg)
end
function CmdParser:CMD_PARTY_MEMBERS(pkt, data)
  pkt:PutShort(data.page or 0)
  pkt:PutLenString(data.name or "")
  pkt:PutLenString(data.gid or "")
end
function CmdParser:CMD_QUERY_PARTY(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_MODIFY_PARTY_QUANQL(pkt, data)
  pkt:PutChar(data.hours)
  pkt:PutChar(data.minutes)
end
function CmdParser:CMD_PARTY_ZHIDUOXING_SKILL(pkt, data)
  pkt:PutLenString(data.skill_name)
end
function CmdParser:CMD_PARTY_ZHIDUOXING_SETUP(pkt, data)
  pkt:PutChar(data.oper_type)
  pkt:PutLenString(data.oper_para)
end
function CmdParser:CMD_PARTY_MODIFY_MEMBER(pkt, data)
  pkt:PutLenString(data.name or "")
  pkt:PutLenString(data.gid or "")
  pkt:PutLenString(data.partyDesc or "")
  pkt:PutShort(data.job or 0)
  pkt:PutShort(data.changeBangZhu or 0)
end
function CmdParser:CMD_CREATE_PARTY(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.announce)
end
function CmdParser:CMD_QUERY_PARTYS(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_PARTY_REJECT_LEVEL(pkt, data)
  pkt:PutShort(data.minLevel)
  pkt:PutShort(data.maxLevel)
  pkt:PutLong(data.minTao)
  pkt:PutChar(data.isWork)
  pkt:PutChar(data.isChange)
end
function CmdParser:CMD_DEVELOP_SKILL(pkt, data)
  pkt:PutLong(data.point)
  pkt:PutShort(data.skill_no)
end
function CmdParser:CMD_GET_PARTY_LOG(pkt, data)
  pkt:PutLong(data.start)
  pkt:PutLong(data.limit)
end
function CmdParser:CMD_BUY_FROM_ELITE_PET_SHOP(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_OPEN_ONLINE_MALL(pkt, data)
  pkt:PutLenString(data.name or "")
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_BUY_FROM_ONLINE_MALL(pkt, data)
  pkt:PutLenString(data.barcode)
  pkt:PutShort(data.amount)
  pkt:PutLenString(data.coin_pwd)
  pkt:PutLenString(data.coin_type)
end
function CmdParser:CMD_MAILBOX_OPERATE(pkt, data)
  pkt:PutShort(data.type)
  pkt:PutLenString2(data.id)
  pkt:PutShort(data.operate)
end
function CmdParser:CMD_FRIEND_VERIFY_RESULT(pkt, data)
  pkt:PutLenString(data.verifyId)
  pkt:PutLenString(data.charName)
  pkt:PutLenString(data.charGid)
  pkt:PutChar(data.result)
end
function CmdParser:CMD_OPER_SCENARIOD(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.type)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_ANSWER_QUESTIONNAIRE(pkt, data)
  pkt:PutShort(data.id)
  pkt:PutLenString2(data.answer)
  pkt:PutLong(data.time_used)
end
function CmdParser:CMD_SET_LEADER_DECLARATION(pkt, data)
  pkt:PutLenString(data.declaration)
end
function CmdParser:CMD_SET_PARTY_QUANQL(pkt, data)
  pkt:PutChar(data.openType)
  pkt:PutChar(data.select_id)
end
function CmdParser:CMD_PARTY_MODIFY_ANNOUNCE(pkt, data)
  pkt:PutLenString2(data.annouce)
end
function CmdParser:CMD_PARTY_GET_BONUS(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_CONTROL_PARTY_CHANNEL(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.type)
  pkt:PutShort(data.hours)
end
function CmdParser:CMD_REFRESH_PARTY_SHOP(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_BUY_FROM_PARTY_SHOP(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_PARTY_SEND_MESSAGE(pkt, data)
  pkt:PutLenString(data.title)
  pkt:PutLenString(data.msg)
end
function CmdParser:CMD_CLOSE_MENU(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_ADD_PARTY_WAR_MONEY(pkt, data)
  pkt:PutLong(data.cash)
end
function CmdParser:CMD_VIEW_PARTY_WAR_HISTORY(pkt, data)
  pkt:PutLong(data.no)
  pkt:PutChar(data.zone)
end
function CmdParser:CMD_START_AWARD(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutChar(data.step)
end
function CmdParser:CMD_BUY_FESTIVAL_GIFT(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_OPEN_FESTIVAL_TREASURE(pkt, data)
  pkt:PutChar(data.boxId)
end
function CmdParser:CMD_FETCH_LOTTERY_ZNQ_2017(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_OPEN_FESTIVAL_LOTTERY(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_FETCH_SSNYF_BONUS(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_SPRING_2019_ZSQF_FETCH(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_SPRING_2019_ZSQF_START_GAME(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_SPRING_2019_ZSQF_COMMIT_GAME(pkt, data)
  pkt:PutChar(data.index)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_GATHER_USER_INFO(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.qq)
  pkt:PutLenString(data.tel)
  pkt:PutLenString2(data.address)
end
function CmdParser:CMD_UPGRADE_PET(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLong(data.no)
  pkt:PutLenString(data.pos)
  pkt:PutLenString(data.other_pet)
  pkt:PutLenString(data.cost_type)
  pkt:PutLenString(data.ids)
end
function CmdParser:CMD_MAKE_PILL(pkt, data)
  pkt:PutLong(data.index)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_SET_STALL_GOODS(pkt, data)
  pkt:PutLong(data.inventoryPos)
  pkt:PutLong(data.price)
  pkt:PutShort(data.pos)
  pkt:PutShort(data.type)
  pkt:PutShort(data.amount or 1)
end
function CmdParser:CMD_BUY_FROM_STALL(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.key)
  pkt:PutLenString(data.pageStr)
  pkt:PutLong(data.price)
  pkt:PutChar(data.type)
  pkt:PutShort(data.amount or 1)
end
function CmdParser:CMD_START_MATCH_TEAM_LEADER(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutShort(data.minLevel)
  pkt:PutShort(data.maxLevel)
end
function CmdParser:CMD_GOODS_BUY(pkt, data)
  pkt:PutLong(data.shipper)
  pkt:PutShort(data.pos)
  pkt:PutShort(data.amount)
  pkt:PutShort(data.to_pos)
end
function CmdParser:CMD_SET_SETTING(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutShort(data.value)
end
function CmdParser:CMD_EXCHANGE_GOODS(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.name)
  pkt:PutShort(data.amount)
end
function CmdParser:CMD_UNEQUIP(pkt, data)
  pkt:PutChar(data.from_pos)
  pkt:PutChar(data.to_pos)
end
function CmdParser:CMD_EQUIP(pkt, data)
  pkt:PutChar(data.pos)
  pkt:PutChar(data.equip_part)
end
function CmdParser:CMD_RANDOM_NAME(pkt, data)
  pkt:PutChar(data.gender)
end
function CmdParser:CMD_STORE(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.from_pos)
  pkt:PutShort(data.to_pos)
  pkt:PutShort(data.amount)
  pkt:PutLenString(data.container)
end
function CmdParser:CMD_TAKE(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.from_pos)
  pkt:PutShort(data.to_pos)
  pkt:PutShort(data.amount)
end
function CmdParser:CMD_OPERATE_PET_STORE(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutShort(data.pos)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_MARKET_SEARCH_ITEM(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutLenString2(data.eatra)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_MARKET_CHECK_RESULT(pkt, data)
  pkt:PutLenString2(data.goodStr)
end
function CmdParser:CMD_L_GET_ACCOUNT_CHARS(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutLong(data.auth_key)
  pkt:PutLenString(data.dist)
end
function CmdParser:CMD_CREATE_LOAD_CHAR(pkt, data)
  pkt:PutLenString(data.char_name)
  pkt:PutShort(data.gender)
  pkt:PutShort(data.polar)
end
function CmdParser:CMD_SWITCH_SERVER(pkt, data)
  pkt:PutLenString(data.serverName)
end
function CmdParser:CMD_ASSIGN_RESIST(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.attribValues)
end
function CmdParser:CMD_FETCH_GIFT(pkt, data)
  pkt:PutLenString(data.code)
end
function CmdParser:CMD_SYS_AUCTION_BID_GOODS(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutLong(data.bid_price)
  pkt:PutLong(data.price)
end
function CmdParser:CMD_STALL_RUSH_BUY_OPEN(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutChar(data.is_start)
  pkt:PutLenString(data.path_str)
  pkt:PutLenString(data.page_str)
end
function CmdParser:CMD_GOLD_STALL_RUSH_BUY_OPEN(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutChar(data.is_start)
  pkt:PutLenString(data.path_str)
  pkt:PutLenString(data.page_str)
end
function CmdParser:CMD_TRADING_SELL_ROLE(pkt, data)
  pkt:PutLong(data.price)
  pkt:PutLenString(data.appointee)
  pkt:PutLenString(data.income)
  pkt:PutChar(data.is_bundle)
end
function CmdParser:CMD_TRADING_CANCEL_ROLE(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_TRADING_CHANGE_PRICE_ROLE(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLong(data.price)
end
function CmdParser:CMD_TRADING_SELL_ROLE_AGAIN(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLong(data.price)
  pkt:PutLenString(data.income)
end
function CmdParser:CMD_TRADING_SNAPSHOT(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutLenString(data.snapshot_type)
  pkt:PutChar(data.isSync)
  pkt:PutChar(data.isShowCard)
end
function CmdParser:CMD_TRADING_FAVORITE_LIST(pkt, data)
  pkt:PutChar(data.list_type)
end
function CmdParser:CMD_TRADING_GOODS_LIST(pkt, data)
  pkt:PutChar(data.list_type)
  pkt:PutShort(data.goods_type)
  pkt:PutLong(data.key)
end
function CmdParser:CMD_TRADING_CHANGE_FAVORITE(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutChar(data.is_favorite)
  pkt:PutChar(data.auto_favorite)
end
function CmdParser:CMD_TRADING_SELL_GOODS(pkt, data)
  pkt:PutLong(data.price)
  pkt:PutChar(data.type)
  pkt:PutLong(data.para)
  pkt:PutLenString(data.appointee)
  pkt:PutChar(data.sell_type)
  pkt:PutLenString(data.income)
end
function CmdParser:CMD_TRADING_CANCEL_GOODS(pkt, data)
  pkt:PutLenString(data.goods_gid)
end
function CmdParser:CMD_TRADING_CHANGE_PRICE_GOODS(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutLong(data.price)
end
function CmdParser:CMD_TRADING_SELL_GOODS_AGAIN(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutLong(data.price)
  pkt:PutChar(data.sell_type)
  pkt:PutLenString(data.income)
end
function CmdParser:CMD_ADMIN_BLOCK_USER(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.gid)
  pkt:PutLong(data.ti)
  pkt:PutLenString(data.reason)
  pkt:PutChar(data.remove_goods)
end
function CmdParser:CMD_ADMIN_QUERY_PLAYER(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_ADMIN_KICKOFF(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_ADMIN_SHUT_CHANNEL(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.gid)
  pkt:PutLong(data.ti)
  pkt:PutLenString(data.channel)
  pkt:PutLenString(data.reason)
end
function CmdParser:CMD_ADMIN_BLOCK_ACCOUNT(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutLong(data.ti)
  pkt:PutLenString(data.reason)
  pkt:PutChar(data.remove_goods)
end
function CmdParser:CMD_ADMIN_THROW_IN_JAIL(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.gid)
  pkt:PutLong(data.ti)
  pkt:PutLenString(data.reason)
end
function CmdParser:CMD_ADMIN_SNIFF_AT(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_ADMIN_QUERY_ACCOUNT(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_ADMIN_WARN_PLAYER(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.title)
  pkt:PutLenString(data.content)
  pkt:PutChar(data.valid_day)
end
function CmdParser:CMD_ADMIN_STOP_COMBAT(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_ADMIN_MOVE_TO_TARGET(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_ADMIN_SEARCH_PROCESS(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_ADMIN_BLOCK_MAC(pkt, data)
  pkt:PutLenString(data.mac)
  pkt:PutLong(data.interval)
  pkt:PutLenString(data.reason)
end
function CmdParser:CMD_ADMIN_SET_USER_LEVEL(pkt, data)
  pkt:PutShort(data.level)
end
function CmdParser:CMD_ADMIN_SET_USER_ATTRIB(pkt, data)
  pkt:PutLenString(data.attrib)
end
function CmdParser:CMD_ADMIN_SET_PET_LEVEL(pkt, data)
  pkt:PutChar(data.petNo)
  pkt:PutShort(data.petLevel)
end
function CmdParser:CMD_ADMIN_SET_PET_ATTRIB(pkt, data)
  pkt:PutLenString(data.petType)
  pkt:PutLenString(data.info)
  pkt:PutLenString(data.attrib)
  pkt:PutLenString(data.skills)
  pkt:PutLenString(data.morph)
  pkt:PutChar(data.rebuild)
  pkt:PutChar(data.isDianhua)
  pkt:PutLenString(data.godBooks)
  pkt:PutChar(data.isYuhua)
  pkt:PutLong(data.intimacy)
  pkt:PutChar(data.isFly)
  pkt:PutLenString(data.peiyuan_attrib)
  pkt:PutLenString(data.ningshen_attrib)
end
function CmdParser:CMD_ADMIN_MAKE_EQUIPMENT(pkt, data)
  pkt:PutLenString(data.equipType)
  pkt:PutShort(data.req_level)
  pkt:PutChar(data.rebuildLevel)
  pkt:PutLenString(data.blue)
  pkt:PutLenString(data.pink)
  pkt:PutLenString(data.yellow)
  pkt:PutLenString(data.green)
  pkt:PutLenString(data.black)
  pkt:PutLenString(data.gongming)
end
function CmdParser:CMD_ADMIN_MAKE_ITEM(pkt, data)
  pkt:PutLenString(data.itemName)
  pkt:PutLong(data.amount)
end
function CmdParser:CMD_L_REQUEST_LINE_INFO(pkt, data)
  pkt:PutLenString(data.account)
end
function CmdParser:CMD_LOOK_ON(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.is_bad_resolution)
end
function CmdParser:CMD_OPER_MASTER(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.para)
  pkt:PutLenString(data.msg)
end
function CmdParser:CMD_APPLY_CARD(pkt, data)
  pkt:PutShort(data.pos)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_CL_CARD_TOP_ONE(pkt, data)
  pkt:PutLenString(data.card_name)
end
function CmdParser:CMD_CL_CARD_ADD_SIZE(pkt, data)
  pkt:PutShort(data.count)
end
function CmdParser:CMD_SHIMEN_TASK_DONATE(pkt, data)
  pkt:PutLong(data.money)
end
function CmdParser:CMD_GATHER_UP(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.para)
end
function CmdParser:CMD_SCREEN_RECORD_END(pkt, data)
  pkt:PutLong(data.start_time)
  pkt:PutLong(data.duration)
end
function CmdParser:CMD_PHONE_VERIFY_CODE(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.phone)
end
function CmdParser:CMD_PHONE_BIND(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.phone)
  pkt:PutLenString(data.verifyCode)
end
function CmdParser:CMD_SMS_VERIFY_CHECK_CODE(pkt, data)
  pkt:PutLenString(data.verifyCode)
end
function CmdParser:CMD_ANSWER_SECURITY_CODE(pkt, data)
  pkt:PutLenString(data.answer)
  local count = #data.scratchMap
  pkt:PutShort(count)
  for i = 1, count do
    pkt:PutLong(data.scratchMap[i])
  end
end
function CmdParser:CMD_SHARE_WITH_FRIENDS(pkt, data)
  pkt:PutLenString(data.actName)
end
function CmdParser:CMD_PET_SPECIAL_SKILL(pkt, data)
  pkt:PutLong(data.petId)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_LOG_ANTI_CHEATER(pkt, data)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString(data[i].action)
    pkt:PutLenString(data[i].para1)
    pkt:PutLenString(data[i].para2)
    pkt:PutLenString(data[i].para3)
    pkt:PutLenString2(data[i].memo)
  end
end
function CmdParser:CMD_LOG_ANTI_PLUGIN_SCRIPT(pkt, data)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString(data[i].action)
    pkt:PutLenString(data[i].para1)
    pkt:PutLenString(data[i].para2)
    pkt:PutLenString(data[i].para3)
    pkt:PutLenString2(data[i].memo)
  end
end
function CmdParser:CMD_WRITE_YYQ(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutChar(data.type)
  pkt:PutLenString2(data.text)
  pkt:PutChar(data.isShowName)
end
function CmdParser:CMD_SEARCH_YYQ(pkt, data)
  pkt:PutLong(data.yyq_no)
end
function CmdParser:CMD_REQUEST_YYQ_PAGE(pkt, data)
  pkt:PutLong(data.page)
end
function CmdParser:CMD_COMMENT_YYQ(pkt, data)
  pkt:PutLong(data.yyq_no)
  pkt:PutChar(data.oper)
end
function CmdParser:CMD_WRITE_ZFQ(pkt, data)
  pkt:PutLenString(data.gid or "")
  pkt:PutChar(data.type)
  pkt:PutLenString2(data.text)
  pkt:PutChar(data.isShowName)
end
function CmdParser:CMD_SEARCH_ZFQ(pkt, data)
  self:CMD_SEARCH_YYQ(pkt, data)
end
function CmdParser:CMD_REQUEST_ZFQ_PAGE(pkt, data)
  self:CMD_REQUEST_YYQ_PAGE(pkt, data)
end
function CmdParser:CMD_COMMENT_ZFQ(pkt, data)
  self:CMD_COMMENT_YYQ(pkt, data)
end
function CmdParser:CMD_REBUILD_PET(pkt, data)
  pkt:PutLong(data.petId)
  pkt:PutShort(data.rebLevel)
  pkt:PutLenString(data.para)
  pkt:PutLenString(data.useType)
end
function CmdParser:CMD_REQUEST_APPRENTICE_INFO(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_SEARCH_MASTER(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.msg)
end
function CmdParser:CMD_SEARCH_APPRENTICE(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.msg)
end
function CmdParser:CMD_APPLY_FOR_MASTER(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.message)
end
function CmdParser:CMD_APPLY_FOR_APPRENTICE(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.message)
end
function CmdParser:CMD_RELEASE_APPRENTICE_RELATION(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_CHANGE_MASTER_MESSAGE(pkt, data)
  pkt:PutLenString(data.msg)
end
function CmdParser:CMD_REQUEST_CDSY_TODAY_TASK(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_PUBLISH_CDSY_TASK(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_FETCH_CHUSHI_TASK(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_LOG_LJCG_EXCEPTION(pkt, data)
  pkt:PutLenString(data.answer)
  pkt:PutLong(data.tactics)
  pkt:PutLong(data.value)
  pkt:PutLenString(data.sa)
  pkt:PutLenString(data.ca)
end
function CmdParser:CMD_GOLD_STALL_OPEN(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutLenString(data.page_str)
end
function CmdParser:CMD_GOLD_STALL_PUT_GOODS(pkt, data)
  pkt:PutLong(data.inventoryPos)
  pkt:PutLong(data.price)
  pkt:PutShort(data.pos)
  pkt:PutShort(data.type)
  pkt:PutLenString(data.appointee)
  pkt:PutChar(data.sell_type)
end
function CmdParser:CMD_GOLD_STALL_RESTART_GOODS(pkt, data)
  pkt:PutLenString(data.goodId)
  pkt:PutLong(data.price)
  pkt:PutChar(data.sell_type)
end
function CmdParser:CMD_GOLD_STALL_REMOVE_GOODS(pkt, data)
  pkt:PutLenString(data.goodId)
end
function CmdParser:CMD_GOLD_STALL_BUY_GOODS(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.key)
  pkt:PutLenString(data.pageStr)
  pkt:PutLong(data.price)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_GOLD_STALL_CHANGE_PRICE(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutLong(data.price)
end
function CmdParser:CMD_GOLD_STALL_GOODS_STATE(pkt, data)
  self:CMD_MARKET_CHECK_RESULT(pkt, data)
end
function CmdParser:CMD_GOLD_STALL_SEARCH_GOODS(pkt, data)
  self:CMD_MARKET_SEARCH_ITEM(pkt, data)
end
function CmdParser:CMD_GOLD_STALL_GOODS_INFO(pkt, data)
  pkt:PutLenString(data.goodId)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_SAFE_LOCK_OPEN_DLG(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_SAFE_LOCK_SET(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutLenString(data.pwd)
end
function CmdParser:CMD_SAFE_LOCK_CHANGE(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutLenString(data.old_pwd)
  pkt:PutLenString(data.new_pwd)
end
function CmdParser:CMD_SAFE_LOCK_UNLOCK(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutLenString(data.pwd)
end
function CmdParser:CMD_SAFE_LOCK_RESET(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_PREVIEW_PET_EVOLVE(pkt, data)
  pkt:PutChar(data.mainPetNo)
  pkt:PutChar(data.otherPetNo)
end
function CmdParser:CMD_SET_OFFLINE_DOUBLE_STATUS(pkt, data)
  pkt:PutChar(data.enble)
end
function CmdParser:CMD_SET_SHUADAO_RUYI_STATE(pkt, data)
  pkt:PutChar(data.state)
end
function CmdParser:CMD_BUY_SHUADAO_RUYI_POINT(pkt, data)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_SHUAD_SMART_TRUSTEESHIP(pkt, data)
  pkt:PutChar(data.is_smart)
end
function CmdParser:CMD_BUY_SHUAD_TRUSTEESHIP_TIME(pkt, data)
  pkt:PutLong(data.ti)
end
function CmdParser:CMD_SET_SHUAD_TRUSTEESHIP_TASK(pkt, data)
  pkt:PutLenString(data.taskName)
end
function CmdParser:CMD_SET_OFFLINE_JIJI_STATUS(pkt, data)
  pkt:PutChar(data.enble)
end
function CmdParser:CMD_SET_OFFLINE_CHONGFS_STATUS(pkt, data)
  pkt:PutChar(data.enble)
end
function CmdParser:CMD_SET_OFFLINE_ZIQIHONGMENG_STATUS(pkt, data)
  pkt:PutChar(data.enble)
end
function CmdParser:CMD_FETCH_SHUADAO_SCORE_ITEM(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_SET_SHUAD_TRUSTEESHIP_STATE(pkt, data)
  pkt:PutChar(data.state)
end
function CmdParser:CMD_OPEN_SHUAD_TRUSTEESHIP(pkt, data)
  pkt:PutLong(data.ti)
end
function CmdParser:CMD_START_GUESS(pkt, data)
  pkt:PutLong(data.amount)
  pkt:PutChar(data.choice)
end
function CmdParser:CMD_APPLY_FRIEND_ITEM(pkt, data)
  pkt:PutLenString(data.items)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_RESPONSE_TIQIN(pkt, data)
  pkt:PutChar(data.result)
end
function CmdParser:CMD_REQUEST_GIVING(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_SUBMIT_GIVING_ITEM(pkt, data)
  if not data.type or not data.pos then
    return
  end
  pkt:PutChar(data.type)
  pkt:PutLong(data.pos)
end
function CmdParser:CMD_REQUEST_TASK_STATUS(pkt, data)
  pkt:PutLenString(data.taskName)
end
function CmdParser:CMD_BUY_WEDDING_LIST(pkt, data)
  pkt:PutLenString2(data.weddinglist)
end
function CmdParser:CMD_SET_RED_PACKET(pkt, data)
  pkt:PutShort(data.each_time_num)
  pkt:PutLong(data.cash)
  pkt:PutShort(data.last_time)
end
function CmdParser:CMD_PARTY_RENAME(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_USER_AGREEMENT(pkt, data)
  pkt:PutLong(data.time)
  pkt:PutLenString(data.version)
end
function CmdParser:CMD_REPLY_SUBMIT_ZIKA(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.operType)
end
function CmdParser:CMD_ADD_FRIEND_GROUP(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_REMOVE_FRIEND_GROUP(pkt, data)
  pkt:PutLenString(data.groupId)
end
function CmdParser:CMD_MOVE_FRIEND_GROUP(pkt, data)
  pkt:PutLenString(data.formGroupId)
  pkt:PutLenString(data.toGroupId)
  pkt:PutLenString2(data.gidListStr)
  pkt:PutLenString2(data.nameListStr)
end
function CmdParser:CMD_MODIFY_FRIEND_GROUP(pkt, data)
  pkt:PutLenString(data.groupId)
  pkt:PutLenString(data.newName)
end
function CmdParser:CMD_SET_REFUSE_STRANGER_CONFIG(pkt, data)
  pkt:PutShort(data.level)
end
function CmdParser:CMD_SET_AUTO_REPLY_MSG_CONFIG(pkt, data)
  pkt:PutLenString(data.content)
end
function CmdParser:CMD_SET_REFUSE_BE_ADD_CONFIG(pkt, data)
  pkt:PutShort(data.level)
end
function CmdParser:CMD_ADD_CHAT_GROUP(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_REMOVE_CHAT_GROUP(pkt, data)
  pkt:PutLenString(data.groupId)
end
function CmdParser:CMD_MODIFY_CHAT_GROUP_NAME(pkt, data)
  pkt:PutLenString(data.groupId)
  pkt:PutLenString(data.newName)
end
function CmdParser:CMD_INVENTE_CHAT_GROUP_MEMBER(pkt, data)
  pkt:PutLenString(data.groupId)
  pkt:PutLenString2(data.gidsListStr)
end
function CmdParser:CMD_REMOVE_MEMBER_TO_CHAT_GROUP(pkt, data)
  pkt:PutLenString(data.groupId)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_MODIFY_CHAT_GROUP_ANNOUS(pkt, data)
  pkt:PutLenString(data.groupId)
  pkt:PutLenString(data.content)
end
function CmdParser:CMD_SET_CHAT_GROUP_SETTING(pkt, data)
  pkt:PutLenString(data.groupId)
  pkt:PutLong(data.setting)
end
function CmdParser:CMD_QUIT_CHAT_GROUP(pkt, data)
  pkt:PutLenString(data.groupId)
end
function CmdParser:CMD_ACCEPT_CHAT_GROUP_INVENTE(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_REFUSE_CHAT_GROUP_INVENTE(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_CHAT_GROUP_TELL(pkt, data)
  pkt:PutShort(data.flag)
  pkt:PutLenString(data.name)
  pkt:PutShort(data.compress)
  pkt:PutShort(data.orgLength)
  pkt:PutLenString2(data.msg)
  pkt:PutShort(data.cardCount or 0)
  for i = 1, data.cardCount or 0 do
    pkt:PutLenString(data.cardParam)
  end
  pkt:PutLong(data.voiceTime or 0)
  pkt:PutLenString2(data.token or "")
  pkt:PutLenString(data.receive_gid)
end
function CmdParser:CMD_MODIFY_FRIEND_MEMO(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.memo)
end
function CmdParser:CMD_PARTY_HELP(pkt, data)
  pkt:PutLenString(data.keyStr)
end
function CmdParser:CMD_MOONCAKE_GAMEBLING(pkt, data)
  pkt:PutChar(data.oper)
end
function CmdParser:CMD_REQUEST_PH_CARD_INFO(pkt, data)
  pkt:PutLenString(data.keyStr)
end
function CmdParser:CMD_MAILING_ITEM(pkt, data)
  pkt:PutShort(data.pos or 0)
  pkt:PutShort(data.amount or 0)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_PT_RB_SEND_REDBAG(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutShort(data.money)
  pkt:PutShort(data.num)
  pkt:PutLenString(data.msg)
  pkt:PutLenString(data.format)
  pkt:PutLenString(data.actName)
  pkt:PutLenString(data.actId)
end
function CmdParser:CMD_PT_RB_RECV_REDBAG(pkt, data)
  pkt:PutLenString(data.redbag_gid)
end
function CmdParser:CMD_PT_RB_SHOW_REDBAG(pkt, data)
  pkt:PutLenString(data.redbag_gid)
end
function CmdParser:CMD_PT_RB_RECORD(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_SET_PUSH_SETTINGS(pkt, data)
  pkt:PutChar(data.key)
  pkt:PutChar(data.value)
end
function CmdParser:CMD_COMPETE_TOURNAMENT_TOP_USER_INFO(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_KILL_COMPETE_TOURNAMENT_TARGET(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_SEND_DEVICE_TOKEN(pkt, data)
  pkt:PutLenString(data.token)
end
function CmdParser:CMD_SHOCK(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_REQUEST_PK_INFO(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.para1 or "")
  pkt:PutLenString(data.para2 or "")
end
function CmdParser:CMD_GOTO_PK(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_SUBMIT_MULTI_ITEM(pkt, data)
  pkt:PutChar(data.petNum)
  for i = 1, data.petNum do
    pkt:PutLong(data.petList[i] or 0)
  end
  pkt:PutChar(data.itemNum)
  for i = 1, data.itemNum do
    pkt:PutLong(data.itemList[i] or 0)
  end
end
function CmdParser:CMD_ZUOLAO_PLEAD(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_ZUOLAO_RELEASE(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_SELECT_CURRENT_MOUNT(pkt, data)
  pkt:PutLong(data.pet_id or 0)
end
function CmdParser:CMD_ADD_FENGLINGWAN(pkt, data)
  pkt:PutChar(data.no or 0)
  pkt:PutLenString(data.type or "")
end
function CmdParser:CMD_HIDE_MOUNT(pkt, data)
  pkt:PutLong(data.petId or 0)
  pkt:PutChar(data.isHide or 0)
end
function CmdParser:CMD_NOTIFY_ITEM_TIMEOUT(pkt, data)
  pkt:PutLenString(data.str)
  pkt:PutShort(data.pos)
end
function CmdParser:CMD_QUERY_MOUNT_MERGE_RATE(pkt, data)
  pkt:PutShort(data.main_pet_no)
  pkt:PutLenString(data.items_no)
  pkt:PutLenString(data.pets_no)
  pkt:PutChar(data.cost_num)
end
function CmdParser:CMD_PREVIEW_MOUNT_ATTRIB(pkt, data)
  pkt:PutShort(data.pet_no)
  pkt:PutChar(data.target_level)
end
function CmdParser:CMD_MAILBOX_GATHER(pkt, data)
  pkt:PutShort(data.mail_type)
  pkt:PutLenString(data.mail_id)
  pkt:PutShort(data.mail_oper)
  pkt:PutLenString(data.name or "")
  pkt:PutLenString(data.qq or "")
  pkt:PutLenString(data.tel or "")
  pkt:PutLenString2(data.addr or "")
  pkt:PutLenString(data.id or "")
  pkt:PutLenString(data.bank_id or "")
  pkt:PutLenString(data.bank_name or "")
  pkt:PutLenString(data.bank_city or "")
  pkt:PutLenString(data.we_chat or "")
  pkt:PutLenString(data.char_name or "")
  pkt:PutLenString(data.char_id or "")
end
function CmdParser:CMD_CONFIRM_RESULT(pkt, data)
  pkt:PutLenString(data.select or "")
end
function CmdParser:CMD_GODBOOK_BUY_NIMBUS(pkt, data)
  pkt:PutShort(data.pet_no)
  pkt:PutLenString(data.skill_name)
  pkt:PutLenString(data.coin_type)
  pkt:PutShort(data.nimbus)
end
function CmdParser:CMD_DEPOSIT(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLong(data.money)
end
function CmdParser:CMD_WITHDRAW(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLong(data.money)
end
function CmdParser:CMD_REQUEST_FUZZY_IDENTITY(pkt, data)
  pkt:PutChar(data.force_request)
end
function CmdParser:CMD_IDENTITY_BIND(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.verifyCode)
end
function CmdParser:CMD_COUPON_BUY_FROM_MALL(pkt, data)
  pkt:PutLenString(data.barcode)
  pkt:PutShort(data.amount)
  pkt:PutLenString(data.coin_pwd)
  pkt:PutLenString(data.coin_type)
  pkt:PutLenString(data.coupon_str)
end
function CmdParser:CMD_MOUNT_CONVERT(pkt, data)
  pkt:PutShort(data.pet_no)
end
function CmdParser:CMD_SUMMON_MOUNT_REQUEST(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_LH_GUESS_RACE_INFO(pkt, data)
  pkt:PutLong(data.last_ti)
end
function CmdParser:CMD_LH_GUESS_PLANS(pkt, data)
  pkt:PutLenString(data.race_name)
  pkt:PutLenString(data.race_index)
  pkt:PutChar(data.day)
  pkt:PutLong(data.last_ti)
end
function CmdParser:CMD_LH_GUESS_TEAM_INFO(pkt, data)
  pkt:PutLenString(data.race_name)
  pkt:PutLenString(data.camp_type)
  pkt:PutChar(data.camp_index)
  pkt:PutLong(data.last_ti)
end
function CmdParser:CMD_LH_GUESS_CAMP_SCORE(pkt, data)
  pkt:PutLenString(data.race_name)
end
function CmdParser:CMD_LH_GUESS_INFO(pkt, data)
  pkt:PutLenString(data.race_name)
  pkt:PutLenString(data.race_index)
end
function CmdParser:CMD_LH_MODIFY_GUESS(pkt, data)
  pkt:PutLenString(data.race_name)
  pkt:PutLenString(data.race_index)
  pkt:PutLenString(data.camp_type)
end
function CmdParser:CMD_LOOKON_BROADCAST_COMBAT(pkt, data)
  pkt:PutLenString(data.combat_id)
  pkt:PutChar(data.combat_type)
end
function CmdParser:CMD_LOOKON_COMBAT_RECORD_DATA(pkt, data)
  pkt:PutLenString(data.combat_id)
  pkt:PutShort(data.page)
end
function CmdParser:CMD_REQUEST_BROADCAST_COMBAT_DATA(pkt, data)
  pkt:PutLenString(data.combat_id)
end
function CmdParser:CMD_LOOKON_CHANNEL_MESSAGE(pkt, data)
  pkt:PutLenString(data.combat_id)
  pkt:PutLong(data.interval_tick)
  pkt:PutLenString(data.msg)
end
function CmdParser:CMD_LOOKON_COMBAT_CHANNEL_DATA(pkt, data)
  pkt:PutLenString(data.combat_id)
  pkt:PutShort(data.page)
end
function CmdParser:CMD_REFILL_ARTIFACT_NIMBUS(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_ADD_DUNWU_NIMBUS(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.skill_no)
  pkt:PutChar(data.type)
  pkt:PutShort(data.pos)
end
function CmdParser:CMD_ADD_DUNWU_TIMES(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.pos)
end
function CmdParser:CMD_VIEW_DDQK_ATTRIB(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_SUBMIT_ICON(pkt, data)
  pkt:PutChar(data.oper_type)
  pkt:PutLenString(data.md5_value)
  if pkt.PutLenBuffer2 then
    pkt:PutLenBuffer2(data.file_data)
  else
    pkt:PutLenString2("")
  end
end
function CmdParser:CMD_REQUEST_ICON(pkt, data)
  pkt:PutLenString(data.md5_value)
end
function CmdParser:CMD_SET_FOOL_GIFT_RESULT(pkt, data)
  pkt:PutLong(data.money)
  pkt:PutLenString(data.message)
end
function CmdParser:CMD_RECEIVE_FOOL_GIFT(pkt, data)
  pkt:PutLong(data.pos)
end
function CmdParser:CMD_PERFORMANCE(pkt, data)
  pkt:PutChar(data.fr)
  pkt:PutLong(data.spf)
  pkt:PutLong(data.mapId)
  pkt:PutLenString(data.pos)
  pkt:PutChar(data.act)
  pkt:PutChar(data.state)
  pkt:PutLong(data.am)
  pkt:PutLong(data.tm)
  pkt:PutChar(data.bg)
  pkt:PutLong(data.rds)
  pkt:PutLong(data.sds)
  pkt:PutLenString(data.ti)
  pkt:PutLenString(data.os)
  pkt:PutLenString(data.bv)
  pkt:PutLenString(data.cv)
  pkt:PutLong(data.tcs)
end
function CmdParser:CMD_REFRESH_CS_SHIDAO_INFO(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_REQUEST_CS_SHIDAO_HISTORY(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLong(data.session)
  pkt:PutLenString(data.levelRange)
  pkt:PutLenString(data.area)
end
function CmdParser:CMD_WXLL_SUBMIT_CHANGECARD(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_BUY_RECHARGE_SCORE_GOODS(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_BUY_CONSUME_SCORE_GOODS(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_ZNQ_FETCH_LOGIN_GIFT(pkt, data)
  pkt:PutLenString(data.index)
end
function CmdParser:CMD_ZNQ_FETCH_LOGIN_GIFT_2018(pkt, data)
  pkt:PutLenString(data.index)
end
function CmdParser:CMD_ZNQ_FETCH_LOGIN_GIFT_2020(pkt, data)
  pkt:PutLenString(data.index)
end
function CmdParser:CMD_PKM_RESET_POINT(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_PKM_SET_DUNWU_SKILL(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.skill)
end
function CmdParser:CMD_PKM_RECYCLE_ITEM(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_PKM_FETCH_ITEM(pkt, data)
  pkt:PutLenString(data.itemName)
  pkt:PutChar(data.count)
end
function CmdParser:CMD_PKM_GEN_PET(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_PKM_GEN_EQUIPMENT(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.blue)
  pkt:PutLenString(data.pink)
  pkt:PutLenString(data.yellow)
  pkt:PutLenString(data.green)
  pkt:PutLenString(data.black)
  pkt:PutLenString(data.gongming)
end
function CmdParser:CMD_WUXING_SHOP_EXCHANGE(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutShort(data.count)
end
function CmdParser:CMD_GET_FRIEND_BAOSHU_INFO(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_DO_ACTION_ON_BAOSHU(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_WATER_FRIEND(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_LEAVE_ROOM(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.extra)
end
function CmdParser:CMD_CLICK_QQ_GIFT_BTN(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_QMPK_MATCH_TEAM_INFO(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_YISHI_DISMISS(pkt, data)
  pkt:PutLong(data.npc_id)
end
function CmdParser:CMD_RECALL_USER_ACTIVITY_OPER(pkt, data)
  pkt:PutLenString(data.oper)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_ADJUST_BROTHER_ORDER(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.target_gid)
end
function CmdParser:CMD_SET_BROTHER_APPELLATION(pkt, data)
  pkt:PutLenString(data.prefix)
  pkt:PutLenString(data.suffix)
end
function CmdParser:CMD_YISHI_RECRUIT(pkt, data)
  pkt:PutLenString(data.npc_name)
end
function CmdParser:CMD_YISHI_EXCHANGE(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.amount)
end
function CmdParser:CMD_YISHI_IMPROVE(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.type)
  pkt:PutChar(data.atk_count)
  pkt:PutChar(data.spd_count)
  pkt:PutChar(data.tao_count)
  pkt:PutChar(data.def_count)
end
function CmdParser:CMD_YISHI_SEARCH_MONSTER(pkt, data)
  pkt:PutLenString(data.monster_name)
end
function CmdParser:CMD_YISHI_SWITCH_STATUS(pkt, data)
  pkt:PutChar(data.status)
end
function CmdParser:CMD_CHANGE_CHAR_UPGRADE_STATE(pkt, data)
  pkt:PutChar(data.state)
end
function CmdParser:CMD_SET_GODBOOK_SKILL_STATE(pkt, data)
  pkt:PutChar(data.pos)
  pkt:PutLenString(data.godbook)
  pkt:PutChar(data.disabled)
end
function CmdParser:CMD_SET_DUNWU_SKILL_STATE(pkt, data)
  pkt:PutChar(data.pos)
  pkt:PutLong(data.dunwu)
  pkt:PutChar(data.disabled)
end
function CmdParser:CMD_CHILD_DAY_2017_POKE(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_CHILD_DAY_2017_QUIT(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_CHILD_DAY_2017_REMOVE(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_SUBMIT_PET_UPGRADE_ITEM(pkt, data)
  pkt:PutLenString(data.posString)
end
function CmdParser:CMD_FETCH_SD_2017_LOTTERY(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLong(data.curTime)
end
function CmdParser:CMD_REQUEST_BUY_RARE_ITEM(pkt, data)
  pkt:PutLenString(data.barcode)
  pkt:PutLong(data.num)
end
function CmdParser:CMD_AUTO_TALK_DATA(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_AUTO_TALK_SAVE(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString2(data.content)
end
function CmdParser:CMD_APPLY_JIUQU_LINGLONGBI(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.type)
  pkt:PutLong(data.pos)
end
function CmdParser:CMD_BUY_HOUSE(pkt, data)
  pkt:PutLenString(data.action)
  pkt:PutLenString(data.house_name)
  pkt:PutChar(data.bedroom_level)
  pkt:PutChar(data.store_level)
  pkt:PutChar(data.lianqs_level)
  pkt:PutChar(data.xiulians_level)
end
function CmdParser:CMD_CS_SHIDAO_ZONE_INFO(pkt, data)
  pkt:PutLenString(data.level_index)
  pkt:PutLenString(data.zone)
end
function CmdParser:CMD_DESTROY_VALUABLE(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_DESTROY_VALUABLE_CONFIRM(pkt, data)
  pkt:PutLong(data.life)
end
function CmdParser:CMD_HOUSE_PLACE_FURNITURE(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutLong(data.furniture_pos)
  pkt:PutShort(data.bx)
  pkt:PutShort(data.by)
  pkt:PutChar(data.flip)
  pkt:PutChar(data.x)
  pkt:PutChar(data.y)
end
function CmdParser:CMD_HOUSE_TAKE_FURNITURE(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutLong(data.furniture_pos)
end
function CmdParser:CMD_HOUSE_MOVE_FURNITURE(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutLong(data.furniture_pos)
  pkt:PutShort(data.bx)
  pkt:PutShort(data.by)
  pkt:PutChar(data.flip)
  pkt:PutChar(data.x)
  pkt:PutChar(data.y)
end
function CmdParser:CMD_HOUSE_DRAG_FURNITURE(pkt, data)
  pkt:PutLong(data.furniture_pos)
end
function CmdParser:CMD_HOUSE_TRY_MANAGE(pkt, data)
  pkt:PutLenString(data.dlg_para or "")
end
function CmdParser:CMD_HOUSE_BUY_FURNITURE(pkt, data)
  pkt:PutLong(data.furniture_id)
  pkt:PutChar(data.num)
  pkt:PutLong(data.cost)
end
function CmdParser:CMD_REQUEST_HOUSE_DATA(pkt, data)
  pkt:PutLenString(data.dlg)
end
function CmdParser:CMD_HOUSE_CLEAN(pkt, data)
  pkt:PutLenString(data.house_id)
end
function CmdParser:CMD_HOUSE_REPAIR_FURNITURE(pkt, data)
  pkt:PutLong(data.furniture_pos)
  pkt:PutLong(data.cost)
end
function CmdParser:CMD_HOUSE_USE_FURNITURE(pkt, data)
  pkt:PutLong(data.furniture_pos)
  pkt:PutLenString(data.action)
  pkt:PutLenString(data.para1)
  pkt:PutLenString(data.para2)
end
function CmdParser:CMD_REQUEST_FURNITURE_APPLY_DATA(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_HOUSE_SHOW_DATA(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.queryType)
end
function CmdParser:CMD_HOUSE_ROOM_SHOW_DATA(pkt, data)
  pkt:PutLenString(data.house_id)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_HOUSE_FRIEND_VISIT(pkt, data)
  pkt:PutLenString(data.char_gid)
end
function CmdParser:CMD_HOUSE_GOTO_CLEAN(pkt, data)
  pkt:PutLenString(data.char_gid)
end
function CmdParser:CMD_HOUSE_RENAME(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_HOUSE_AUTOWALK(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.autoWalkStr)
end
function CmdParser:CMD_CACHE_AUTO_WALK_MSG(pkt, data)
  pkt:PutLenString(data.autoWalkStr)
  pkt:PutLenString(data.homeId or "")
  pkt:PutLenString(data.taskType or "")
  pkt:PutLenString(data.mapName or "")
  pkt:PutLenString(data.serverName or "")
end
function CmdParser:CMD_FINISH_JINGUANGFU(pkt, data)
  pkt:PutChar(data.perfect)
end
function CmdParser:CMD_HOUSE_PLAYER_PRACTICE(pkt, data)
  pkt:PutLenString(data.action)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_WELCOME_DRAW_REQUEST(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_RESPONSE_CLIENT_SIGNATURE(pkt, data)
  pkt:PutLenString2(data.signature)
  pkt:PutLenString(data.package_name)
  pkt:PutChar(data.isEmulator and 1 or 0)
end
function CmdParser:CMD_AUTUMN_2017_QUIT(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_AUTUMN_2017_PLAY(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_HOUSE_REQUEST_PET_FEED_INFO(pkt, data)
  pkt:PutLenString(data.furniture_iid)
end
function CmdParser:CMD_HOUSE_FARM_GOTO_HELP(pkt, data)
  pkt:PutLenString(data.friend_gid)
end
function CmdParser:CMD_RECORD_SHUAD_LOG(pkt, data)
  pkt:PutLenString(data.action)
  pkt:PutLenString2(data.log_str)
end
function CmdParser:CMD_SET_CLIENT_USER_STATE(pkt, data)
  pkt:PutLenString(data.state)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_HOUSE_FARM_ACTION(pkt, data)
  pkt:PutChar(data.action)
  pkt:PutChar(data.farm_index - 1)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_CSL_LEAGUE_DATA(pkt, data)
  pkt:PutShort(data.season_no)
  pkt:PutShort(data.level_section)
  pkt:PutChar(data.league_no)
end
function CmdParser:CMD_CSL_MATCH_DATA(pkt, data)
  pkt:PutShort(data.level)
  pkt:PutLenString(data.match_name)
end
function CmdParser:CMD_CSL_CONTRIB_TOP_DATA(pkt, data)
  pkt:PutShort(data.level)
end
function CmdParser:CMD_HOUSE_START_COOKING(pkt, data)
  pkt:PutLong(data.furniture_pos)
  pkt:PutLenString(data.cooking_name)
  pkt:PutLong(data.num)
end
function CmdParser:CMD_HOUSE_ENTRUST(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_HOUSE_START_MAKE_FURNITURE(pkt, data)
  pkt:PutLong(data.furniture_pos)
  pkt:PutLenString(data.furniture_name)
  pkt:PutChar(data.is_use_limit)
end
function CmdParser:CMD_REFRESH_REQUEST_INFO(pkt, data)
  pkt:PutLenString(data.ask_type or "")
end
function CmdParser:CMD_HOUSE_TIGAN(pkt, data)
  pkt:PutChar(data.no)
end
function CmdParser:CMD_HOUSE_LACHE(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_HOUSE_ADD_POLE_NUM(pkt, data)
  pkt:PutLenString(data.pole_name)
  pkt:PutLong(data.num)
end
function CmdParser:CMD_HOUSE_ADD_BAIT_NUM(pkt, data)
  pkt:PutLenString(data.bait_name)
  pkt:PutLong(data.num)
end
function CmdParser:CMD_HOUSE_SELECT_TOOLS(pkt, data)
  pkt:PutLenString(data.pole_name)
  pkt:PutLenString(data.bait_name)
end
function CmdParser:CMD_SUBMIT_NEED_EXCHANGE_MATERIAL(pkt, data)
  pkt:PutChar(data.index)
  pkt:PutLenString(data.item_name)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_SUBMIT_GIFT_EXCHANGE_MATERIAL(pkt, data)
  pkt:PutChar(data.index)
  pkt:PutLong(data.item_pos)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_UNSUBMIT_NEED_EXCHANGE_MATERIAL(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_UNSUBMIT_GIFT_EXCHANGE_MATERIAL(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_PUBLISH_EXCHANGE_MATERIAL(pkt, data)
  pkt:PutLenString(data.msg)
end
function CmdParser:CMD_FRIEND_EXCHANGE_MATERIAL_DATA(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_EXCHANGE_MATERIAL(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutChar(data.pos)
  pkt:PutLong(data.item_pos)
end
function CmdParser:CMD_AUTUMN_2017_BUY(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_CHONGYANG_2017_TASTE(pkt, data)
  pkt:PutLong(data.npc_id)
  pkt:PutChar(data.no)
end
function CmdParser:CMD_PARTY_PYJS_SELECT_ATTRIB(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_PARTY_PYJS_FETCH_TASK(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_PARTY_PYJS_FINISH_TASK(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_QUERY_PYJS(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_PARTY_YZXL_POKE(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_PARTY_YZXL_QUIT(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_PARTY_YZXL_REMOVE(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_PARTY_YZXL_REPLAY(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_QUERY_TZJS(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_HOUSE_BUY_GUANJIA(pkt, data)
  pkt:PutLenString(data.gj_type)
end
function CmdParser:CMD_HOUSE_SELECT_GUANJIA(pkt, data)
  pkt:PutLenString(data.gj_type)
end
function CmdParser:CMD_HOUSE_CHANGE_GUANJIA_NAME(pkt, data)
  pkt:PutLenString(data.gj_type)
  pkt:PutLenString(data.new_name)
end
function CmdParser:CMD_HOUSE_ADD_YH_INFO(pkt, data)
  pkt:PutLenString(data.yh_type)
end
function CmdParser:CMD_HOUSE_CHANGE_YH_NAME(pkt, data)
  pkt:PutLenString(data.yh_type)
  pkt:PutLenString(data.new_name)
end
function CmdParser:CMD_HOUSE_CHANGE_YD_NAME(pkt, data)
  pkt:PutLenString(data.yd_type)
  pkt:PutLenString(data.new_name)
end
function CmdParser:CMD_REQUEST_TEMP_FRIEND_STATE(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.dist_name)
end
function CmdParser:CMD_SINGLES_2017_GOODS_BUY(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.amount)
  pkt:PutChar(data.quota)
end
function CmdParser:CMD_SINGLES_2017_GOODS_REFRESH(pkt, data)
  pkt:PutChar(data.auto)
end
function CmdParser:CMD_ACHIEVE_VIEW(pkt, data)
  pkt:PutChar(data.category)
end
function CmdParser:CMD_EXCHANGE_CONTACT_SELLER(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.goods_gid)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_STALL_CHANGE_PRICE(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutLong(data.price)
end
function CmdParser:CMD_HOUSE_OPER_XYFT(pkt, data)
  pkt:PutLong(data.furniture_pos)
end
function CmdParser:CMD_BLOG_CHANGE_ICON(pkt, data)
  pkt:PutLenString(data.icon_img)
end
function CmdParser:CMD_BLOG_CHANGE_LOCATION(pkt, data)
  pkt:PutLenString(data.location)
end
function CmdParser:CMD_BLOG_CHANGE_SIGNATURE(pkt, data)
  pkt:PutLenString(data.text)
  pkt:PutLenString(data.voice)
  pkt:PutChar(data.voice_duraction)
end
function CmdParser:CMD_BLOG_CHANGE_TAG(pkt, data)
  pkt:PutLenString(data.tag)
end
function CmdParser:CMD_BLOG_RESOURE_GID(pkt, data)
  pkt:PutChar(data.op_type)
  pkt:PutShort(#data.suffixs)
  for i = 1, #data.suffixs do
    pkt:PutLenString(data.suffixs[i])
  end
  pkt:PutLenString(data.cookie)
end
function CmdParser:CMD_BLOG_OPEN_BLOG(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.user_gid)
  pkt:PutChar(data.openType)
end
function CmdParser:CMD_BLOG_REPORT(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.user_gid)
  pkt:PutChar(data.op_type)
  pkt:PutLenString(data.text)
end
function CmdParser:CMD_BLOG_MESSAGE_VIEW(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.host_gid)
  pkt:PutLenString(data.message_iid)
  pkt:PutLong(data.message_time)
  pkt:PutChar(data.message_num)
  pkt:PutChar(data.query_type)
end
function CmdParser:CMD_BLOG_MESSAGE_WRITE(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.host_gid)
  pkt:PutLenString(data.target_gid)
  pkt:PutLenString(data.target_iid)
  pkt:PutLenString(data.target_dist)
  pkt:PutLenString2(data.msg)
end
function CmdParser:CMD_BLOG_MESSAGE_DELETE(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.host_gid)
  pkt:PutLenString(data.message_iid)
end
function CmdParser:CMD_BLOG_FLOWER_PRESENT(pkt, data)
  pkt:PutLenString(data.host_gid)
  pkt:PutLenString(data.flower)
end
function CmdParser:CMD_BLOG_FLOWER_OPEN(pkt, data)
  pkt:PutLenString(data.host_gid)
end
function CmdParser:CMD_BLOG_FLOWER_VIEW(pkt, data)
  pkt:PutLenString(data.host_gid)
  pkt:PutLenString(data.note_iid)
  pkt:PutLong(data.note_time)
  pkt:PutChar(data.note_num)
end
function CmdParser:CMD_BLOG_FLOWER_UPDATE(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.char_gid)
end
function CmdParser:CMD_BLOG_PUBLISH_ONE_STATUS(pkt, data)
  pkt:PutLenString(data.text)
  pkt:PutLenString(data.img_str)
  pkt:PutChar(data.viewType)
end
function CmdParser:CMD_BLOG_DELETE_ONE_STATUS(pkt, data)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BLOG_REQUEST_STATUS_LIST(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.user_gid)
  pkt:PutLenString(data.last_sid)
  pkt:PutChar(data.viewType)
end
function CmdParser:CMD_BLOG_STATUS_LIST_ABOUT_ME(pkt, data)
  pkt:PutLenString(data.last_sid)
end
function CmdParser:CMD_BLOG_MESSAGE_LIST_ABOUT_ME(pkt, data)
  pkt:PutLenString(data.last_sid)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_BLOG_REQUEST_LIKE_LIST(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BLOG_LIKE_ONE_STATUS(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.uid)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BLOG_PUBLISH_ONE_COMMENT(pkt, data)
  pkt:PutLenString(data.status_dist)
  pkt:PutLenString(data.uid)
  pkt:PutLenString(data.sid)
  pkt:PutShort(data.reply_cid)
  pkt:PutLenString(data.reply_gid)
  pkt:PutLenString(data.reply_dist)
  pkt:PutLenString(data.text)
  pkt:PutChar(data.is_expand)
end
function CmdParser:CMD_BLOG_REPORT_ONE_STATUS(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.uid)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BLOG_SWITCH_VIEW_SETTING(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_BLOG_ALL_COMMENT_LIST(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BLOG_DELETE_ONE_COMMENT(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.sid)
  pkt:PutShort(data.cid)
  pkt:PutChar(data.isExpand)
end
function CmdParser:CMD_HMAC_SHA1_BASE64(pkt, data)
  pkt:PutLenString2(data.key)
  local count = data.contents and #data.contents or 0
  pkt:PutShort(count)
  for i = 1, count do
    pkt:PutLenString2(data.contents[i])
  end
end
function CmdParser:CMD_SHOUCHONG_CARD_INFO(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_DC_CONFIRM_PETS(pkt, data)
  count = 6
  pkt:PutShort(count)
  for i = 1, count do
    if data[i] then
      local pet = PetMgr:getPetById(data[i])
      if pet then
        pkt:PutChar(pet:queryBasicInt("no"))
        pkt:PutLenString(pet:queryBasic("name"))
      else
        pkt:PutChar(0)
        pkt:PutLenString("")
      end
    else
      pkt:PutChar(0)
      pkt:PutLenString("")
    end
  end
end
function CmdParser:CMD_DC_CHALLENGE_OPPONENT(pkt, data)
  pkt:PutChar(data.no)
end
function CmdParser:CMD_PREVIEW_PET_INHERIT(pkt, data)
  pkt:PutChar(data.no1)
  pkt:PutChar(data.no2)
end
function CmdParser:CMD_NEW_LOTTERY_DRAW(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_TRADING_SELL_CASH(pkt, data)
  pkt:PutLenString(data.goods_gid)
end
function CmdParser:CMD_SIMULATOR_LOGIN(pkt, data)
  self:CMD_LOGIN(pkt, data)
end
function CmdParser:CMD_CLIENT_ERR_OCCUR(pkt, data)
  pkt:PutShort(data.errType)
  pkt:PutLenString2(data.msg)
end
function CmdParser:CMD_NEWYEAR_2018_HYJB(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_CHAT_GROUP_AITE_INFO(pkt, data)
  pkt:PutLenString(data.group_id)
end
function CmdParser:CMD_NEWYEAR_2018_LPXZ(pkt, data)
  pkt:PutLenString(data.status)
end
function CmdParser:CMD_TRADING_HOUSE_DATA(pkt, data)
  pkt:PutLenString(data.house_id)
end
function CmdParser:CMD_SET_RECOMMEND_XMD(pkt, data)
  pkt:PutChar(data.addType)
  pkt:PutChar(data.isOpen)
end
function CmdParser:CMD_ASSIGN_XMD(pkt, data)
  pkt:PutShort(data.xian)
  pkt:PutShort(data.mo)
end
function CmdParser:CMD_WINTER2018_DAXZ_OPER(pkt, data)
  pkt:PutChar(data.oper)
end
function CmdParser:CMD_WINTER_2018_HJZY(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.answer)
  pkt:PutLenString(data.opType)
end
function CmdParser:CMD_DONGSZ_2018_EAT(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_DONGSZ_2018_SELECT(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_SHENMI_DALI_PICK(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_SEVENDAY_GIFT_FETCH(pkt, data)
  pkt:PutChar(data.day)
end
function CmdParser:CMD_SUBMIT_XUEJING_ITEM(pkt, data)
  pkt:PutLenString(data.items_pos)
end
function CmdParser:CMD_AUTO_FIGHT_SET_DATA(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.auto_select)
  pkt:PutChar(data.multi_index)
  pkt:PutChar(data.action)
  pkt:PutLong(data.para)
  pkt:PutShort(data.multi_count)
  for i = 1, data.multi_count do
    pkt:PutChar(data.autoFightData[i].action)
    pkt:PutLong(data.autoFightData[i].para)
    pkt:PutChar(data.autoFightData[i].round)
  end
end
function CmdParser:CMD_MAILBOX_GATHER_PRIVILEGE(pkt, data)
  pkt:PutLenString(data.mail_id)
  pkt:PutShort(data.mail_oper)
  pkt:PutLenString(data.name or "")
  pkt:PutLenString(data.idcard or "")
  pkt:PutLenString(data.phone or "")
  pkt:PutLenString(data.wechat or "")
  pkt:PutLenString2(data.address or "")
  pkt:PutLenString(data.birth or "")
end
function CmdParser:CMD_SELECT_BONUS_RESULT(pkt, data)
  pkt:PutLenString(data.source)
  pkt:PutLenString(data.select)
end
function CmdParser:CMD_GOLD_STALL_CASH_PRICE(pkt, data)
  pkt:PutLong(data.name)
end
function CmdParser:CMD_GOLD_STALL_BUY_CASH(pkt, data)
  pkt:PutLong(data.name)
  pkt:PutLong(data.expect_price)
end
function CmdParser:CMD_REPORT_USER(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.user_gid)
  pkt:PutLenString(data.user_name)
  pkt:PutLenString(data.type)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString2(data.content[i].reason)
    pkt:PutLenString(data.content[i].para1)
    pkt:PutLenString(data.content[i].para2)
    pkt:PutLenString(data.content[i].para3)
    pkt:PutLenString(data.content[i].para4 or "")
  end
end
function CmdParser:CMD_STALL_RECORD_DETAIL(pkt, data)
  pkt:PutLenString(data.record_id)
end
function CmdParser:CMD_GOLD_STALL_RECORD_DETAIL(pkt, data)
  pkt:PutLenString(data.record_id)
end
function CmdParser:CMD_DECORATION_APPLY(pkt, data)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString(data.list[i].type)
    pkt:PutLenString(data.list[i].name)
  end
end
function CmdParser:CMD_BLOG_DECORATION_LIST(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.user_gid)
end
function CmdParser:CMD_EXECUTE_RESULT(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutLenString2(data.result)
  pkt:PutChar(data.finish or 1)
end
function CmdParser:CMD_AUTO_FIGHT_SET_VICTIM(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.friend_id)
  pkt:PutLenString(data.enemy_id)
end
function CmdParser:CMD_ADMIN_BROADCAST_COMBAT_LIST(pkt, data)
  pkt:PutLenString(data.dist)
  pkt:PutLenString(data.combat_type)
  pkt:PutLenString(data.name_or_gid)
  pkt:PutLong(data.begin_time)
  pkt:PutLong(data.end_time)
end
function CmdParser:CMD_ADMIN_REQUEST_LOOKON_GDDB_COMBAT(pkt, data)
  pkt:PutLenString(data.combat_id)
end
function CmdParser:CMD_FETCH_STORE_SURPLUS(pkt, data)
end
function CmdParser:CMD_CSNC_RANK_DATA_TOP(pkt, data)
  pkt:PutShort(data.season)
  pkt:PutShort(data.min_level)
  pkt:PutShort(data.zone)
end
function CmdParser:CMD_CSNC_RANK_DATA_STAGE(pkt, data)
  pkt:PutShort(data.season)
  pkt:PutShort(data.min_level)
  pkt:PutShort(data.zone)
end
function CmdParser:CMD_CSC_SET_COMBAT_MODE(pkt, data)
  pkt:PutLenString(data.combat_mode)
end
function CmdParser:CMD_CSC_SET_AUTO_MATCH(pkt, data)
  pkt:PutChar(data.enable)
end
function CmdParser:CMD_START_MATCH_TEAM_LEADER_KFJJC(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutShort(data.minLevel)
  pkt:PutShort(data.maxLevel)
  pkt:PutLong(data.minTao * Const.ONE_YEAR_TAO)
  pkt:PutLong(data.maxTao * Const.ONE_YEAR_TAO)
  pkt:PutShort(#data.polars)
  for i = 1, #data.polars do
    pkt:PutChar(data.polars[i])
  end
end
function CmdParser:CMD_QUICK_USE_ITEM(pkt, data)
  pkt:PutShort(data.pos)
  pkt:PutChar(data.doubleEnabel)
  pkt:PutChar(data.chongfsEnable)
end
function CmdParser:CMD_HOUSE_REMOTE_USE_FURNITURE(pkt, data)
  pkt:PutLong(data.furniture_pos)
  pkt:PutLenString(data.action)
  pkt:PutLenString(data.para1)
  pkt:PutLenString(data.para2)
end
function CmdParser:CMD_TEAM_CHANGE_SEQUENCE(pkt, data)
  pkt:PutLong(data.old_id)
  pkt:PutLong(data.new_id)
  pkt:PutLong(data.old_pos)
  pkt:PutLong(data.new_pos)
end
function CmdParser:CMD_LDJ_2018_NOTIFY_COMBAT(pkt, data)
  pkt:PutShort(data.meX)
  pkt:PutShort(data.meY)
  pkt:PutLong(data.npcId)
  pkt:PutShort(data.npcX)
  pkt:PutShort(data.npcY)
  pkt:PutChar(data.npcDir)
end
function CmdParser:CMD_LINGMAO_FANPAI_OPER(pkt, data)
  pkt:PutChar(data.oper)
  pkt:PutChar(data.para)
end
function CmdParser:CMD_TRADING_SEARCH_GOODS(pkt, data)
  pkt:PutChar(data.list_type)
  pkt:PutLenString(data.path_str)
  pkt:PutLenString2(data.extra)
  pkt:PutLenString2(data.sub_extra)
end
function CmdParser:CMD_ZNQ_2018_OPER_LINGMAO(pkt, data)
  pkt:PutLenString(data.oper)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_ZNQ_2018_LINGMAO_FIGHT(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_ZNQ_2018_LOOKON(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_ZNQ_2018_REQ_LINGMAO_FRIENDS(pkt, data)
  pkt:PutLenString(data.gids)
end
function CmdParser:CMD_SHOCK_FRIEND(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_CG_REQUEST_DAY_INFO(pkt, data)
  pkt:PutChar(data.day)
end
function CmdParser:CMD_CG_REQUEST_TEAM_INFO(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_CG_LOOKON_GDDB_COMBAT(pkt, data)
  pkt:PutLenString(data.competName)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_CG_SUPPORT_TEAM(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.id)
  pkt:PutLong(data.supports)
end
function CmdParser:CMD_CG_REQUEST_SCHEDULE(pkt, data)
  pkt:PutChar(data.openFlag)
end
function CmdParser:CMD_LBS_CHANGE_LOCATION(pkt, data)
  pkt:PutLenString(data.location)
  pkt:PutChar(data.type)
  pkt:PutChar(data.result)
end
function CmdParser:CMD_LBS_CHANGE_GENDER(pkt, data)
  pkt:PutChar(data.sex)
end
function CmdParser:CMD_LBS_CHANGE_AGE(pkt, data)
  pkt:PutChar(data.age)
end
function CmdParser:CMD_LBS_SEARCH_NEAR(pkt, data)
  pkt:PutChar(data.sex)
end
function CmdParser:CMD_LBS_ADD_FRIEND(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutChar(data.from_type)
end
function CmdParser:CMD_LBS_VERIFY_FRIEND(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.message)
end
function CmdParser:CMD_LBS_FRIEND_VERIFY_RESULT(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.char_name)
  pkt:PutLenString(data.char_gid)
  pkt:PutChar(data.result)
end
function CmdParser:CMD_LBS_FRIEND_TELL(pkt, data)
  self:CMD_FRIEND_TELL_EX(pkt, data)
end
function CmdParser:CMD_LBS_ADD_BLACKLIST_FRIEND(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.gid)
  pkt:PutLong(data.icon or 0)
  pkt:PutShort(data.level or 0)
end
function CmdParser:CMD_LBS_REMOVE_FRIEND(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_LBS_RANK_INFO(pkt, data)
  pkt:PutShort(data.type)
end
function CmdParser:CMD_HANDBOOK_COMMENT_QUERY_LIST(pkt, data)
  pkt:PutLenString(data.key_name)
  pkt:PutLong(data.last_time)
  pkt:PutLenString(data.last_id)
end
function CmdParser:CMD_HANDBOOK_COMMENT_PUBLISH(pkt, data)
  pkt:PutLenString(data.key_name)
  pkt:PutLenString(data.comment)
end
function CmdParser:CMD_HANDBOOK_COMMENT_DELETE(pkt, data)
  pkt:PutLenString(data.key_name)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_HANDBOOK_COMMENT_LIKE(pkt, data)
  pkt:PutLenString(data.key_name)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_PET_DELETE_SOUL(pkt, data)
  pkt:PutChar(data.no)
end
function CmdParser:CMD_DAXZ_OPER(pkt, data)
  pkt:PutChar(data.oper)
end
function CmdParser:CMD_DIVINE_START_GAME(pkt, data)
  pkt:PutChar(data.stick)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_DIVINE_END_GAME(pkt, data)
  pkt:PutChar(data.stick)
  pkt:PutChar(data.type)
  pkt:PutChar(data.isOk)
end
function CmdParser:CMD_MERGE_DURABLE_ITEM(pkt, data)
  local count = #data
  pkt:PutShort(data.index)
  pkt:PutShort(count)
  for i = 1, count do
    local count = #data[i]
    local str = ""
    for j = 1, count do
      str = str .. data[i][j]
      if j < count then
        str = str .. "|"
      end
    end
    pkt:PutLenString2(str)
  end
end
function CmdParser:CMD_APPLY_INSIDER_GIFT(pkt, data)
  pkt:PutShort(data.pos)
  pkt:PutLenString(data.fasion_name)
end
function CmdParser:CMD_GET_CHAR_INFO(pkt, data)
  pkt:PutLenString(data.char_gid)
  pkt:PutLenString(data.dlg_type)
  pkt:PutChar(data.offline)
  pkt:PutLenString(data.para)
  pkt:PutLenString(data.user_dist)
end
function CmdParser:CMD_DUANWU_2018_COLLISION(pkt, data)
  pkt:PutLong(data.monster_id)
  pkt:PutShort(data.x)
  pkt:PutShort(data.y)
  pkt:PutChar(data.dir)
end
function CmdParser:CMD_SUMMER_2018_HQZM_INDEX(pkt, data)
  pkt:PutChar(data.no)
end
function CmdParser:CMD_SUMMER_2018_HQZM_GAME_END(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_YUANSGW_ACCEPTED_COMMAND(pkt, data)
  pkt:PutLong(data.victim_id)
  pkt:PutChar(data.action)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_TRADING_AUTO_LOGIN_TOKEN(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_OVERCOME_SET_SIGNATURE(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.signature)
end
function CmdParser:CMD_TRADING_BUY_GOODS(pkt, data)
  pkt:PutLenString(data.goods_gid)
end
function CmdParser:CMD_SUMMER_2018_PUZZLE(pkt, data)
  pkt:PutChar(data.isSubmit)
  pkt:PutLenString(data.mapName)
  pkt:PutChar(data.count)
  for i = 1, data.count do
    pkt:PutChar(data.list[i])
  end
end
function CmdParser:CMD_SUMMER_2018_CHIGUA_ACCELERATE(pkt, data)
  pkt:PutLenString(data.text)
end
function CmdParser:CMD_WB_DIARY_SUMMARY(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutShort(data.page)
end
function CmdParser:CMD_WB_DIARY(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.diary_id)
end
function CmdParser:CMD_WB_DIARY_ADD(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString2(data.content)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_WB_DIARY_EDIT(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.diary_id)
  pkt:PutLenString2(data.content)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_WB_DIARY_DELETE(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.diary_id)
end
function CmdParser:CMD_WB_DAY_SUMMARY(pkt, data)
  pkt:PutLenString(data.book_id)
end
function CmdParser:CMD_WB_DAY_ADD(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.icon)
  pkt:PutLenString(data.name)
  pkt:PutLenString(tostring(data.day_time))
  pkt:PutLong(data.flag)
end
function CmdParser:CMD_WB_DAY_EDIT(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.day_id)
  pkt:PutLenString(data.icon)
  pkt:PutLenString(data.name)
  pkt:PutLenString(tostring(data.day_time))
  pkt:PutLong(data.flag)
end
function CmdParser:CMD_WB_DAY_DELETE(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.day_id)
end
function CmdParser:CMD_WB_CLOSE_BOOK(pkt, data)
  pkt:PutLenString(data.book_id)
end
function CmdParser:CMD_WB_HOME_PIC(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.img or "")
end
function CmdParser:CMD_WB_PHOTO_COMMIT(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.img)
  pkt:PutLenString(data.memo)
  pkt:PutChar(data.flag or 0)
end
function CmdParser:CMD_WB_PHOTO_EDIT_MEMO(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.photo_id)
  pkt:PutLenString(data.memo)
  pkt:PutChar(data.flag or 0)
end
function CmdParser:CMD_WB_PHOTO_DELETE(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.photo_id)
end
function CmdParser:CMD_WB_PHOTO_SUMMARY(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutShort(data.page)
end
function CmdParser:CMD_LCHJ_REQUEST_PETS_INFO(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.stage)
end
function CmdParser:CMD_LCHJ_CONFIRM_PETS_INFO(pkt, data)
  pkt:PutShort(data.count)
  local petList = data.list
  for i = 1, data.count do
    pkt:PutChar(petList[i].no)
    pkt:PutLenString(petList[i].name)
    pkt:PutChar(petList[i].pos)
  end
end
function CmdParser:CMD_LCHJ_SET_DISABLE_SKILLS(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutShort(data.count)
  local skillList = data.list
  for i = 1, data.count do
    pkt:PutShort(skillList[i])
  end
end
function CmdParser:CMD_LCHJ_CHALLENGE(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.stage)
end
function CmdParser:CMD_MERGE_LOGIN_GIFT_FETCH(pkt, data)
  pkt:PutChar(data.day)
end
function CmdParser:CMD_RECV_HUOYUE_JIANGLI(pkt, data)
  pkt:PutLong(data.open_time)
end
function CmdParser:CMD_CSB_GM_CONFIRM_COMBAT_RESULT(pkt, data)
  pkt:PutChar(data.result)
end
function CmdParser:CMD_CSB_GM_COMMIT_FINAL_WINNER(pkt, data)
  pkt:PutLenString(data.team_id)
end
function CmdParser:CMD_LBS_ADD_FRIEND_TO_TEMP(pkt, data)
  pkt:PutLenString(data.user_gid)
end
function CmdParser:CMD_WB_REPORT_HOME_PIC(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.img_path)
end
function CmdParser:CMD_WB_REPORT_PHOTO(pkt, data)
  pkt:PutLenString(data.book_id)
  pkt:PutLenString(data.photo_id)
end
function CmdParser:CMD_INN_UPGRADE_ROOM(pkt, data)
  pkt:PutChar(data.id)
end
function CmdParser:CMD_INN_UPGRADE_TABLE(pkt, data)
  pkt:PutChar(data.id)
end
function CmdParser:CMD_INN_GUEST_COME_IN(pkt, data)
  pkt:PutChar(data.isAuto)
end
function CmdParser:CMD_INN_CHANGE_GUEST_STATE(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutChar(data.id)
  pkt:PutChar(data.pos)
  pkt:PutChar(data.state)
  pkt:PutLong(data.curTime)
end
function CmdParser:CMD_INN_ENTERTAIN_GUEST(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutChar(data.id)
  pkt:PutChar(data.pos)
  pkt:PutLong(data.startTime)
  pkt:PutChar(data.duration)
end
function CmdParser:CMD_HEISHI_KANJIA(pkt, data)
  pkt:PutChar(data.kanjia)
end
function CmdParser:CMD_BUY_CHAR_ITEM_CB(pkt, data)
  pkt:PutLenString(data.from)
  pkt:PutChar(data.result)
end
function CmdParser:CMD_WORLD_CUP_2018_SELECT_TEAM(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_WORLD_CUP_2018_FETCH_BONUS(pkt, data)
  pkt:PutLenString(data.stage)
end
function CmdParser:CMD_INN_TASK_FETCH_BONUS(pkt, data)
  pkt:PutShort(data.id)
end
function CmdParser:CMD_INN_CHANGE_NAME(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_FASION_CUSTOM_SWITCH(pkt, data)
  pkt:PutChar(data.fasion_label)
end
function CmdParser:CMD_FASION_CUSTOM_EQUIP(pkt, data)
  pkt:PutLenString(data.equip_str)
end
function CmdParser:CMD_FASION_CUSTOM_BUY(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_FASION_CUSTOM_UNEQUIP(pkt, data)
  pkt:PutShort(data.pos)
end
function CmdParser:CMD_FASION_FAVORITE_ADD(pkt, data)
  pkt:PutLenString(data.fav_name)
  pkt:PutLenString(data.fav_plan)
end
function CmdParser:CMD_FASION_FAVORITE_DEL(pkt, data)
  pkt:PutLong(data.fav_id)
end
function CmdParser:CMD_FASION_FAVORITE_RENAME(pkt, data)
  pkt:PutLong(data.fav_id)
  pkt:PutLenString(data.new_name)
end
function CmdParser:CMD_FASION_FAVORITE_APPLY(pkt, data)
  pkt:PutLong(data.fav_id)
end
function CmdParser:CMD_FASION_CUSTOM_DISABLE(pkt, data)
  pkt:PutChar(data.value)
end
function CmdParser:CMD_FASION_EFFECT_DISABLE(pkt, data)
  pkt:PutChar(data.disable)
end
function CmdParser:CMD_FASION_CUSTOM_EQUIP_EX(pkt, data)
  pkt:PutChar(data.is_buy)
  pkt:PutLenString(data.item_names)
  pkt:PutLenString(data.effect_name or "")
end
function CmdParser:CMD_REPORT_DEVICE(pkt, data)
  pkt:PutLenString(data.device_name)
end
function CmdParser:CMD_HERO_SET_SIGNATURE(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.signature)
end
function CmdParser:CMD_LD_CHECK_CONDITION(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.para1)
  pkt:PutLenString(data.para2)
end
function CmdParser:CMD_LD_START_LIFEDEATH(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLong(data.time)
  pkt:PutLenString(data.mode)
  pkt:PutLenString(data.bet_type)
  pkt:PutLong(data.bet_num)
end
function CmdParser:CMD_LD_MATCH_LIFEDEATH_COST(pkt, data)
  pkt:PutShort(data.level)
end
function CmdParser:CMD_LD_MATCH_DATA(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_LD_ACCEPT_MATCH(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_LD_LOOKON_MATCH(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_LD_REFUSE_MATCH(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_LD_ENTER_ZHANC(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_LD_HISTORY_PAGE(pkt, data)
  pkt:PutLong(data.last_time)
end
function CmdParser:CMD_LD_MY_HISTORY_PAGE(pkt, data)
  pkt:PutLong(data.pos)
  pkt:PutLong(data.last_time)
  pkt:PutChar(data.needGenaral)
end
function CmdParser:CMD_HERO_SET_SIGNATURE(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.signature)
end
function CmdParser:CMD_APPLY_CHAOJISHENSHOUDAN(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutShort(data.num)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_ONE_KEY_ADD_PET_INTIMACY(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutLong(data.num)
  pkt:PutChar(data.coin)
end
function CmdParser:CMD_ONE_KEY_ADD_GHOST_PET_INTIMACY(pkt, data)
  pkt:PutChar(data.no)
  pkt:PutLong(data.num)
  pkt:PutChar(data.coin)
end
function CmdParser:CMD_DETECTIVE_TASK_CLUE(pkt, data)
  pkt:PutLenString(data.taskName)
end
function CmdParser:CMD_RKSZ_PAPER_MESSAGE(pkt, data)
  pkt:PutLenString(data.taskName)
end
function CmdParser:CMD_DETECTIVE_TASK_CLUE_MEMO(pkt, data)
  pkt:PutLenString(data.taskName)
  pkt:PutLenString(data.state)
  pkt:PutLenString(data.remarks)
end
function CmdParser:CMD_RKSZ_ANSWER_CODE(pkt, data)
  pkt:PutLenString(data.code)
end
function CmdParser:CMD_TANAN_JHLL_GAME_XY(pkt, data)
  pkt:PutChar(data.isFinish)
end
function CmdParser:CMD_TANAN_JHLL_GAME_GZ(pkt, data)
  pkt:PutChar(data.isStart)
  pkt:PutChar(data.isFinish)
end
function CmdParser:CMD_TEACHER_2018_GAME_S6_SELECT(pkt, data)
  pkt:PutChar(data.answer)
end
function CmdParser:CMD_TEACHER_2018_GAME_S2_SELECT(pkt, data)
  pkt:PutChar(data.power)
end
function CmdParser:CMD_TWZM_BOX_ANSWER(pkt, data)
  local cou = #data
  pkt:PutShort(cou)
  for i = 1, cou do
    pkt:PutChar(data[i])
  end
end
function CmdParser:CMD_TWZM_FINISH_JIGSAW(pkt, data)
  pkt:PutLenString(data.key)
end
function CmdParser:CMD_TWZM_JIGSAW_STATE(pkt, data)
  pkt:PutLenString2(data.status)
end
function CmdParser:CMD_TWZM_START_PICK_PEACH(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_TWZM_QUIT_PICK_PEACH(pkt, data)
  pkt:PutShort(data.score)
end
function CmdParser:CMD_TWZM_MATRIX_ANSWER(pkt, data)
  local cou = #data
  pkt:PutShort(cou)
  for i = 1, cou do
    pkt:PutChar(data[i])
  end
end
function CmdParser:CMD_TWZM_MATRIX_STATE(pkt, data)
  pkt:PutLenString2(data.status)
end
function CmdParser:CMD_TWZM_CHUANYINFU_ANSWER(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutChar(data.type)
  pkt:PutLong(data.num)
end
function CmdParser:CMD_CSQ_SCORE_TEAM_DATA(pkt, data)
  pkt:PutLenString(data.teamId)
end
function CmdParser:CMD_CSQ_CITY_SCORE_TEAM_DATA(pkt, data)
  pkt:PutLenString(data.teamId)
end
function CmdParser:CMD_CSQ_GM_SELECT_CITY_RAISE_TEAM(pkt, data)
  pkt:PutLenString(data.teamId)
end
function CmdParser:CMD_CSQ_CITY_SCORE_RANK(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_CSQ_CITY_SIGNUP_COLLECT(pkt, data)
  pkt:PutLenString(data.real_name)
  pkt:PutLenString(data.is_card)
  pkt:PutLenString(data.phone)
  pkt:PutLenString(data.qq)
end
function CmdParser:CMD_CSQ_KICKOUT_TEAM_DATA(pkt, data)
  pkt:PutLenString(data.teamId)
end
function CmdParser:CMD_CSQ_GM_START_COMBAT(pkt, data)
  pkt:PutChar(data.matchId)
end
function CmdParser:CMD_CSQ_GM_CONFIRM_COMBAT_RESULT(pkt, data)
  pkt:PutChar(data.matchId)
  pkt:PutChar(data.isOk)
end
function CmdParser:CMD_CSQ_GM_COMMIT_WINNER(pkt, data)
  pkt:PutChar(data.matchId)
  pkt:PutLenString(data.teamId)
end
function CmdParser:CMD_PREVIEW_RESONANCE_ATTRIB(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutShort(data.level)
  pkt:PutLenString(data.attrib)
  pkt:PutChar(data.rebuildLevel)
end
function CmdParser:CMD_TEACHER_2018_HELP(pkt, data)
  pkt:PutLenString(data.desc)
end
function CmdParser:CMD_REMOVE_NPC_TEMP_MSG(pkt, data)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLong(data[i])
  end
end
function CmdParser:CMD_LEARN_UPPER_STD_SKILL_COST(pkt, data)
  pkt:PutShort(data.skill_no)
  pkt:PutShort(data.up_level)
end
function CmdParser:CMD_LEARN_UPPER_STD_SKILL(pkt, data)
  pkt:PutShort(data.skill_no)
  pkt:PutShort(data.up_level)
end
function CmdParser:CMD_NATIONAL_2018_SFQJ(pkt, data)
  pkt:PutLenString(data.op_type)
end
function CmdParser:CMD_MXAZ_USE_EXHIBIT(pkt, data)
  pkt:PutLong(data.npcId)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_NATIONAL_2018_SFQJ_MOVE(pkt, data)
  pkt:PutChar(data.x)
  pkt:PutChar(data.y)
  pkt:PutChar(data.dir)
end
function CmdParser:CMD_AUTUMN_2018_GAME_START(pkt, data)
  pkt:PutChar(data.step)
end
function CmdParser:CMD_AUTUMN_2018_GAME_FINISH(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_AUTUMN_2018_DWW_SELECT_ICON(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_AUTUMN_2018_DWW_PROGRESS(pkt, data)
  pkt:PutLenString(data.text)
end
function CmdParser:CMD_TASK_TIP_EX(pkt, data)
  pkt:PutLenString(data.taskName)
end
function CmdParser:CMD_CHONGYANG_2018_GAME_FINISH(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_CLICK_NPC(pkt, data)
  pkt:PutLong(data.npcId)
end
function CmdParser:CMD_REQUEST_ZZQN_CARD_INFO(pkt, data)
  pkt:PutShort(data.pos)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_HALLOWMAX_2018_LYZM_STUDY_RESULT(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_HALLOWMAX_2018_LYZM_GAME_RESULT(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_CHECK_SERVER(pkt, data)
  pkt:PutLenBuffer2(data.buf)
  pkt:PutLong(data.cookie)
end
function CmdParser:CMD_QYGD_SELECT_ANSWER_2018(pkt, data)
  pkt:PutChar(data.titleNum)
  pkt:PutChar(data.option)
end
function CmdParser:CMD_FASION_CUSTOM_BUY_EFFECT(pkt, data)
  pkt:PutLenString(data.item_name)
end
function CmdParser:CMD_BUY_FASHION_PET(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_SET_ACTION_STATUS(pkt, data)
  pkt:PutLong(data.status)
end
function CmdParser:CMD_CLOSE_DIALOG(pkt, data)
  pkt:PutLenString(data.para1)
  pkt:PutLenString(data.para2)
end
function CmdParser:CMD_SXYS_ANSWER_2019(pkt, data)
  pkt:PutChar(data.select_num)
end
function CmdParser:CMD_BWSWZ_NOTIFY_RESULT_2019(pkt, data)
  pkt:PutLenString(data.checksum)
end
function CmdParser:CMD_WINTER_2019_BX21D_ACTION_END(pkt, data)
  pkt:PutLenString(data.status)
end
function CmdParser:CMD_WINTER_2019_BX21D_OPER(pkt, data)
  pkt:PutChar(data.oper)
end
function CmdParser:CMD_WINTER_2019_BX21D_QUIT(pkt, data)
  pkt:PutLenString(data.status)
end
function CmdParser:CMD_CXK_START_GAME_2019(pkt, data)
  pkt:PutChar(data.oper)
end
function CmdParser:CMD_CXK_FINISH_GAME_2019(pkt, data)
  pkt:PutChar(data.isQuit)
  pkt:PutLenString(data.des)
end
function CmdParser:CMD_L_START_RECHARGE(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutShort(data.charge_type)
end
function CmdParser:CMD_L_START_BUY_INSIDER(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_L_CHARGE_LIST(pkt, data)
  pkt:PutLenString(data.account)
end
function CmdParser:CMD_L_LINE_DATA(pkt, data)
  pkt:PutLenString(data.account)
end
function CmdParser:CMD_HOUSE_PET_STORE_ADD_SIZE(pkt, data)
  pkt:PutLong(data.furniture_pos)
  pkt:PutShort(data.count)
end
function CmdParser:CMD_HOUSE_PET_STORE_OPERATE(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutShort(data.pos)
end
function CmdParser:CMD_EXCHANGE_EPIC_PET_SUBMIT_DLG(pkt, data)
  pkt:PutLenString(data.target_name)
end
function CmdParser:CMD_EXCHANGE_EPIC_PET_EXCHANGE(pkt, data)
  pkt:PutLenString(data.target)
  pkt:PutShort(#data.pos)
  for i = 1, #data.pos do
    pkt:PutShort(data.pos[i])
  end
end
function CmdParser:CMD_GIVING_RECORD(pkt, data)
end
function CmdParser:CMD_GIVING_RECORD_CARD(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_KICK_OFF_CLIENT(pkt, data)
  pkt:PutLenString(data.reason)
end
function CmdParser:CMD_MXZA_EXHIBIT_ITEM_LIST(pkt, data)
end
function CmdParser:CMD_MXZA_SUBMIT_EXHIBIT(pkt, data)
  pkt:PutLenString(data.state)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_SET_FIXED_TEAM_APPELLATION(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_FIXED_TEAM_OPEN_SUPPLY_DLG(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_FIXED_TEAM_SUPPLY(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.item_name)
end
function CmdParser:CMD_REQUEST_USER_REALTIME_CARD(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutChar(data.include_temp_effect)
end
function CmdParser:CMD_REQUEST_USER_RECRUIT_REALTIME_CARD(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.team_id)
end
function CmdParser:CMD_FIXED_TEAM_ONE_KEY(pkt, data)
  pkt:PutLenString(data.gid or "")
end
function CmdParser:CMD_FIXED_TEAM_RECRUIT_SINGLE(pkt, data)
  pkt:PutChar(data.oper)
  pkt:PutLenString2(data.para)
  pkt:PutLenString(data.para2)
end
function CmdParser:CMD_FIXED_TEAM_RECRUIT_SINGLE_QUERY_LIST(pkt, data)
  pkt:PutLenString(data.iid)
  pkt:PutLong(data.time)
  pkt:PutChar(data.polar)
  pkt:PutChar(data.pt_type)
end
function CmdParser:CMD_FIXED_TEAM_RECRUIT_TEAM(pkt, data)
  pkt:PutChar(data.oper)
  pkt:PutLenString2(data.para)
  pkt:PutLenString(data.para2)
  pkt:PutLenString(data.para3)
end
function CmdParser:CMD_FIXED_TEAM_RECRUIT_TEAM_QUERY_LIST(pkt, data)
  pkt:PutLenString(data.iid)
  pkt:PutLong(data.time)
  pkt:PutChar(data.polar)
  pkt:PutChar(data.pt_type)
end
function CmdParser:CMD_USE_TONGTIAN_LINGPAI(pkt, data)
  pkt:PutShort(data.pos)
  pkt:PutLenString(data.name1)
  pkt:PutLenString(data.name2)
end
function CmdParser:CMD_SET_SHUADAO_RUYI_AMT_STATE(pkt, data)
  pkt:PutChar(data.state)
end
function CmdParser:CMD_MATCH_MAKING_REQ_LIST(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutChar(data.source)
end
function CmdParser:CMD_MATCH_MAKING_REQ_DETAIL(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutChar(data.isOpen or 0)
end
function CmdParser:CMD_MATCH_MAKING_PUBLISH(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString2(data.message)
end
function CmdParser:CMD_MATCH_MAKING_OPER_ICON(pkt, data)
  pkt:PutLenString(data.portrait or "")
end
function CmdParser:CMD_MATCH_MAKING_OPER_MESSAGE(pkt, data)
  pkt:PutLenString2(data.message)
end
function CmdParser:CMD_MATCH_MAKING_OPER_VOICE(pkt, data)
  pkt:PutLenString(data.voice_addr)
  pkt:PutChar(data.voice_time)
end
function CmdParser:CMD_MATCH_MAKING_OPER_RECV_MSG(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_MATCH_MAKING_OPER_GENDER(pkt, data)
  pkt:PutChar(data.gender)
end
function CmdParser:CMD_MATCH_MAKING_ADD_FAVORITE(pkt, data)
  pkt:PutChar(data.oper)
  pkt:PutLenString(data.gid or "")
end
function CmdParser:CMD_GOLD_STALL_BID_GOODS(pkt, data)
  pkt:PutLenString(data.goods_id)
  pkt:PutLenString(data.path_str)
  pkt:PutLenString(data.page_str)
  pkt:PutLong(data.old_price)
  pkt:PutLong(data.new_price)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_GOLD_STALL_BUY_AUCTION_GOODS(pkt, data)
  pkt:PutLenString(data.goods_id)
  pkt:PutLenString(data.path_str)
  pkt:PutLenString(data.page_str)
  pkt:PutLong(data.price)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_YUANXJ_2019_SELECT_TARGET_NPC(pkt, data)
  pkt:PutLenString(data.target_npc)
end
function CmdParser:CMD_YUANXJ_2019_MAKE_TASK_ITEM(pkt, data)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_SPRING_2019_XCXB_USE_TOOL(pkt, data)
  pkt:PutShort(data.x)
  pkt:PutShort(data.y)
  pkt:PutChar(data.tool_type)
end
function CmdParser:CMD_SPRING_2019_XCXB_BUY_TOOL(pkt, data)
  pkt:PutChar(data.tool_type)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_SPRING_2019_XCXB_GET_BONUS(pkt, data)
  pkt:PutShort(data.x)
  pkt:PutShort(data.y)
  pkt:PutShort(data.layer_count)
end
function CmdParser:CMD_SPRING_2019_XTCL_COMMIT(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_GOLD_STALL_PAY_DEPOSIT(pkt, data)
  pkt:PutLenString(data.goods_gid)
  pkt:PutLong(data.expect_price)
  pkt:PutLong(data.deposit)
  pkt:PutLenString(data.path_str)
  pkt:PutLenString(data.page_str)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_BJTX_FETCH_BONUS(pkt, data)
  pkt:PutLenString(data.char_gid)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_MAP_DECORATION_BUY(pkt, data)
  pkt:PutLenString(data.item_name)
end
function CmdParser:CMD_MAP_DECORATION_PLACE(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutLenString(data.item_name)
  pkt:PutShort(data.x)
  pkt:PutShort(data.y)
  pkt:PutShort(data.dir)
  pkt:PutChar(data.ox)
  pkt:PutChar(data.oy)
end
function CmdParser:CMD_MAP_DECORATION_MOVE(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutLong(data.id)
  pkt:PutShort(data.x)
  pkt:PutShort(data.y)
  pkt:PutShort(data.dir)
  pkt:PutChar(data.ox)
  pkt:PutChar(data.oy)
end
function CmdParser:CMD_MAP_DECORATION_REMOVE(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_MAP_DECORATION_CHECK(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_USE_FOOLS_DAY_LABA(pkt, data)
  pkt:PutLenString(data.npc)
  pkt:PutLenString(data.content)
  pkt:PutShort(data.cardCount or 0)
  for i = 1, data.cardCount or 0 do
    pkt:PutLenString(data.cardParam)
  end
end
function CmdParser:CMD_FOOLS_DAY_2019_FINISH_GAME(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_2019ZNQFP_COMMIT(pkt, data)
  pkt:PutLenString(data.result)
  pkt:PutChar(data.bonus_flag)
end
function CmdParser:CMD_SMDG_MOVE(pkt, data)
  pkt:PutChar(data.level)
  pkt:PutShort(data.pos)
  pkt:PutLenString(data.has_walk_str)
end
function CmdParser:CMD_SMDG_TRIGGER_EVENT(pkt, data)
  pkt:PutChar(data.level)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.right_dir)
  pkt:PutLenString(data.err_dir)
  pkt:PutLenString(data.trea_dir)
  pkt:PutShort(data.pos)
  pkt:PutLenString(data.has_walk_str)
end
function CmdParser:CMD_SMDG_PASS_GAME(pkt, data)
  pkt:PutChar(data.level)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_SMDG_QUIT_GAME(pkt, data)
end
function CmdParser:CMD_CHILD_DAY_2019_RESULT(pkt, data)
  pkt:PutChar(data.result)
  pkt:PutLenString(data.checkSum)
end
function CmdParser:CMD_CHILD_DAY_2019_TRIGGER_EVENT(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutShort(data.x)
  pkt:PutShort(data.y)
end
function CmdParser:CMD_CHILD_DAY_2019_START_MSJ_FAIL(pkt, data)
end
function CmdParser:CMD_CHILD_DAY_2019_NOTIFY_DATA(pkt, data)
  pkt:PutLenString(data.gameData)
end
function CmdParser:CMD_TEAM_COMMANDER_GET_CMD_LIST(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_TEAM_COMMANDER_SET_CMD_LIST(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutChar(data.isReset)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString(data[i])
  end
end
function CmdParser:CMD_TEAM_COMMANDER_ASSIGN(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_TEAM_COMMANDER_COMBAT_COMMAND(pkt, data)
  pkt:PutChar(data.toAll)
  pkt:PutLong(data.id)
  pkt:PutLenString(data.command)
end
function CmdParser:CMD_2019ZNQ_CWTX_CLICK(pkt, data)
  pkt:PutShort(data.layer)
  pkt:PutChar(data.x)
  pkt:PutChar(data.y)
end
function CmdParser:CMD_2019ZNQ_CWTX_BONUS_TYPE(pkt, data)
  pkt:PutLenString(data.bonus_type)
end
function CmdParser:CMD_2019ZNQ_CWTX_BACK(pkt, data)
  pkt:PutShort(data.layer)
end
function CmdParser:CMD_DW_2019_ZDBC_COMMIT(pkt, data)
  pkt:PutLenString(data.answer)
end
function CmdParser:CMD_RANDOM_TTTD_XINGJUN(pkt, data)
  pkt:PutLong(data.pos)
end
function CmdParser:CMD_FASION_CUSTOM_VIEW(pkt, data)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_SMFJ_BXF_REPORT_RESULT(pkt, data)
  pkt:PutLenString(data.str)
end
function CmdParser:CMD_SMFJ_YLMB_MOVE_STEP(pkt, data)
  pkt:PutChar(data.step)
  pkt:PutChar(data.cmd_no)
end
function CmdParser:CMD_SMFJ_SWZD_MOVE_STEP(pkt, data)
  pkt:PutChar(data.step)
  pkt:PutChar(data.cmd_no)
end
function CmdParser:CMD_SET_PET_FASION_VISIBLE(pkt, data)
  pkt:PutLong(data.no)
  pkt:PutChar(data.visible)
end
function CmdParser:CMD_CHANGE_CHAT_GROUP_LEADER(pkt, data)
  pkt:PutLenString(data.changer_gid)
  pkt:PutLenString(data.group_id)
end
function CmdParser:CMD_SMFJ_BSWH_PLAYER_ICON(pkt, data)
  pkt:PutLenString(data.str)
end
function CmdParser:CMD_SMFJ_CJDWW_ADD_PROGRESS(pkt, data)
  pkt:PutLenString(data.str)
end
function CmdParser:CMD_SUMMER_2019_SMSZ_SMHJ_COMMIT(pkt, data)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_LOG_INN_EXCEPTION(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString2(data.log)
end
function CmdParser:CMD_REQUEST_AUTO_WALK_LINE(pkt, data)
  pkt:PutChar(data.line_type)
  pkt:PutLenString(data.auto_walk_info)
end
function CmdParser:CMD_LOG_CLIENT_ACTION(pkt, data)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString(data[i].action)
    pkt:PutLenString(data[i].para1)
    pkt:PutLenString(data[i].para2)
    pkt:PutLenString(data[i].para3)
    pkt:PutLenString2(data[i].memo)
  end
end
function CmdParser:CMD_SUMMER_2019_SMSZ_SMBH_COMMIT(pkt, data)
  pkt:PutLenString(data.num_str)
end
function CmdParser:CMD_TRADING_SPOT_DATA(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_TRADING_SPOT_COLLECT(pkt, data)
  pkt:PutShort(data.id)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_TRADING_SPOT_GOODS_DETAIL(pkt, data)
  pkt:PutShort(data.id)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_TRADING_SPOT_PROFIT(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_TRADING_SPOT_BUY_GOODS(pkt, data)
  pkt:PutShort(data.id)
  pkt:PutShort(data.num)
  pkt:PutLong(data.price)
end
function CmdParser:CMD_TRADING_SPOT_BID_ONE_PLAN(pkt, data)
  pkt:PutLenString(data.trading_no)
  pkt:PutLenString(data.plan)
  pkt:PutLong(data.total_price)
  pkt:PutLenString(data.char_gid)
  pkt:PutLenString(data.char_name)
end
function CmdParser:CMD_CSML_LEAGUE_DATA(pkt, data)
  pkt:PutShort(data.season_no)
end
function CmdParser:CMD_CSML_MATCH_DATA(pkt, data)
  pkt:PutLenString(data.match_name)
end
function CmdParser:CMD_BBS_PUBLISH_ONE_STATUS(pkt, data)
  pkt:PutLenString(data.catalog)
  pkt:PutLenString(data.text)
end
function CmdParser:CMD_BBS_DELETE_ONE_STATUS(pkt, data)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BBS_REQUEST_STATUS_LIST(pkt, data)
  pkt:PutLenString(data.catalog)
  pkt:PutLenString(data.last_sid)
end
function CmdParser:CMD_BBS_REQUEST_LIKE_LIST(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BBS_PUBLISH_ONE_COMMENT(pkt, data)
  pkt:PutLenString(data.status_dist)
  pkt:PutLenString(data.uid)
  pkt:PutLenString(data.sid)
  pkt:PutShort(data.reply_cid)
  pkt:PutLenString(data.reply_gid)
  pkt:PutLenString(data.reply_dist)
  pkt:PutLenString(data.text)
  pkt:PutChar(data.is_expand)
end
function CmdParser:CMD_BBS_DELETE_ONE_COMMENT(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.sid)
  pkt:PutShort(data.cid)
  pkt:PutChar(data.isExpand)
end
function CmdParser:CMD_BBS_ALL_COMMENT_LIST(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BBS_REPORT_ONE_STATUS(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.uid)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_BBS_LIKE_ONE_STATUS(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.uid)
  pkt:PutLenString(data.sid)
end
function CmdParser:CMD_SUMMER_2019_SSWG_END_ACTION(pkt, data)
  pkt:PutLenString(data.status)
end
function CmdParser:CMD_SUMMER_2019_SSWG_OPER(pkt, data)
  pkt:PutChar(data.oper)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_SUMMER_2019_BHKY_RESULT(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_SUMMER_2019_SXDJ_OPERATE(pkt, data)
  pkt:PutChar(data.index)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_SUMMER_2019_SXDJ_END_ACTION(pkt, data)
  pkt:PutLenString(data.status)
end
function CmdParser:CMD_WQX_ANSWER_QUESTION(pkt, data)
  pkt:PutLenString(data.stage)
  pkt:PutChar(data.question_no)
  pkt:PutLenString(data.answer)
end
function CmdParser:CMD_WQX_CLOSE_DLG(pkt, data)
  pkt:PutLenString(data.stage)
end
function CmdParser:CMD_WQX_APPLY_ITEM(pkt, data)
  pkt:PutLenString(data.item_name)
end
function CmdParser:CMD_WQX_HELP_ANSWER_QUESTION(pkt, data)
  pkt:PutLenString(data.char_gid)
  pkt:PutLenString(data.help_id)
  pkt:PutChar(data.select_index)
end
function CmdParser:CMD_PET_EXPLORE_MAP_PET_DATA(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutChar(data.map_index)
end
function CmdParser:CMD_PET_EXPLORE_OPER(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutChar(data.type)
  pkt:PutChar(data.map_index)
end
function CmdParser:CMD_PET_EXPLORE_LEARN_SKILL(pkt, data)
  pkt:PutLong(data.pet_id)
  pkt:PutChar(data.skill_id)
end
function CmdParser:CMD_PET_EXPLORE_REPLACE_SKILL(pkt, data)
  pkt:PutLong(data.pet_id)
  pkt:PutChar(data.old_skill_id)
  pkt:PutChar(data.new_skill_id)
end
function CmdParser:CMD_PET_EXPLORE_USE_ITEM(pkt, data)
  pkt:PutLong(data.pet_id)
  pkt:PutChar(data.item_id)
  pkt:PutShort(data.count)
end
function CmdParser:CMD_PET_EXPLORE_MAP_CONDITION_DATA(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutChar(data.map_index)
  pkt:PutLong(data.pet_id1)
  pkt:PutLong(data.pet_id2)
  pkt:PutLong(data.pet_id3)
end
function CmdParser:CMD_PET_EXPLORE_START(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutChar(data.map_index)
  pkt:PutLong(data.pet_id1)
  pkt:PutLong(data.pet_id2)
  pkt:PutLong(data.pet_id3)
end
function CmdParser:CMD_XCWQ_ADJUST_TEMPERATURE(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_XCWQ_MASSAGE_BACK(pkt, data)
  pkt:PutLong(data.to_id)
  pkt:PutShort(data.to_x)
  pkt:PutShort(data.to_y)
  pkt:PutLong(data.cookie)
end
function CmdParser:CMD_XCWQ_THROW_SOAP(pkt, data)
  pkt:PutLong(data.to_id)
  pkt:PutShort(data.to_x)
  pkt:PutShort(data.to_y)
  pkt:PutLong(data.cookie)
end
function CmdParser:CMD_DECOMPOSE_LINGCHEN_ITEM(pkt, data)
  local count = #data
  pkt:PutShort(count)
  for i = 1, count do
    pkt:PutLong(data[i])
  end
end
function CmdParser:CMD_BUY_LINGCHEN_ITEM(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_SUMMER_2019_XZJS_OPERATE(pkt, data)
  pkt:PutLong(data.no)
  local count = #data
  pkt:PutShort(count)
  for i = 1, count do
    pkt:PutChar(data[i])
  end
end
function CmdParser:CMD_WQX_FINISH_QUESTION(pkt, data)
  pkt:PutLenString(data.stage)
  pkt:PutChar(data.question_no)
end
function CmdParser:CMD_CHILD_CARE(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_L_GET_GOLD_COIN_DATA(pkt, data)
  pkt:PutLenString(data.account)
end
function CmdParser:CMD_L_PRECHARGE_PRESS_BTN(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_CHILD_BIRTH(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_CHILD_RENAME(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.new_name)
  pkt:PutChar(data.isFirst)
end
function CmdParser:CMD_HOUSE_TDLS_INJECT_ENERGY(pkt, data)
  pkt:PutLong(data.pos)
end
function CmdParser:CMD_CHILD_BIRTH_ADD_LOG(pkt, data)
  pkt:PutLenString(data.birth_log)
end
function CmdParser:CMD_CHILD_BIRTH_ADD_PROGRESS(pkt, data)
  pkt:PutChar(data.process)
end
function CmdParser:CMD_HOUSE_TDLS_CHILD_BIRTH(pkt, data)
  pkt:PutLong(data.furniture_id)
end
function CmdParser:CMD_HOUSE_TDLS_VIEW(pkt, data)
  pkt:PutLong(data.furniture_id)
end
function CmdParser:CMD_CHILD_PUT_MONEY(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutLenString(data.child_name)
  pkt:PutLong(data.money)
end
function CmdParser:CMD_CHILD_BIRTH_WATER(pkt, data)
  pkt:PutChar(data.state)
end
function CmdParser:CMD_CHILD_REQUEST_RAISE_INFO(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_CHILD_RAISE(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutChar(data.fy_type)
  pkt:PutLenString(data.fy_para)
end
function CmdParser:CMD_CHILD_SET_SCHEDULE_LIST(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutLong(data.time)
  pkt:PutLong(data.cookie)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLong(data[i].startTime)
    pkt:PutChar(data[i].sch_type)
  end
end
function CmdParser:CMD_CHILD_REQUEST_SCHEDULE(pkt, data)
  pkt:PutLenString(data.child_id)
end
function CmdParser:CMD_HOUSE_CRADLE_TALK(pkt, data)
  pkt:PutLong(data.pos)
end
function CmdParser:CMD_CHILD_CHECK_SET_SCHEDULE(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutLong(data.start_time)
  pkt:PutChar(data.op_type)
  pkt:PutLong(data.cookie)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_CHILD_CHECK_CHANGE_SCHEDULE(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutLong(data.record_time)
  pkt:PutLong(data.cookie)
end
function CmdParser:CMD_CHILD_SELECT(pkt, data)
  pkt:PutLenString(data.child_id)
end
function CmdParser:CMD_GOOD_VOICE_SHOW_LIST(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_GOOD_VOICE_QUERY_VOICE(pkt, data)
  pkt:PutLenString(data.voice_id)
  pkt:PutChar(data.requestSeasonData or 0)
  pkt:PutChar(data.open_type or 0)
end
function CmdParser:CMD_GOOD_VOICE_COLLECT(pkt, data)
  pkt:PutLenString(data.voice_id)
  pkt:PutChar(data.is_favorite)
end
function CmdParser:CMD_GOOD_VOICE_SEARCH(pkt, data)
  pkt:PutLenString(data.search_text)
end
function CmdParser:CMD_GOOD_VOICE_REPORT(pkt, data)
  pkt:PutLenString(data.voice_id)
  pkt:PutLenString(data.reason)
  pkt:PutChar(data.rp_type)
end
function CmdParser:CMD_GOOD_VOICE_LIKE(pkt, data)
  pkt:PutLenString(data.voice_id)
end
function CmdParser:CMD_GOOD_VOICE_GIVE_FLOWER(pkt, data)
  pkt:PutLenString(data.voice_id)
  pkt:PutLenString(data.flower)
end
function CmdParser:CMD_GOOD_VOICE_ADD_JUDGE(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLenString(data.desc)
  pkt:PutLenString(data.icon_addr)
end
function CmdParser:CMD_GOOD_VOICE_FINAL_VOICES(pkt, data)
  pkt:PutChar(data.day_index)
end
function CmdParser:CMD_GOOD_VOICE_SCORE_DATA(pkt, data)
  pkt:PutShort(data.season_no)
  pkt:PutLenString(data.voice_id)
end
function CmdParser:CMD_GOOD_VOICE_JUDGE_GIVE_SCORE(pkt, data)
  pkt:PutLenString(data.voice_id)
  pkt:PutChar(data.score)
  pkt:PutLenString(data.comment)
end
function CmdParser:CMD_GOOD_VOICE_RANK_LIST(pkt, data)
  pkt:PutShort(data.season_no)
end
function CmdParser:CMD_ADMIN_GOOD_VOICE_DELETE_JUDGE(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_ADMIN_GOOD_VOICE_DELETE_SCORE(pkt, data)
  pkt:PutLenString(data.voice_id)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_LEAVE_MESSAGE_VIEW(pkt, data)
  self:CMD_BLOG_MESSAGE_VIEW(pkt, data)
  pkt:PutChar(data.type or LEAVE_MESSAGE_TYPE.GOOD_VOICE)
end
function CmdParser:CMD_LEAVE_MESSAGE_WRITE(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.host_gid)
  pkt:PutLenString(data.target_gid)
  pkt:PutLenString(data.target_iid)
  pkt:PutLenString(data.target_dist)
  pkt:PutLenString2(data.msg)
  pkt:PutLenString(data.para)
  pkt:PutChar(data.type or LEAVE_MESSAGE_TYPE.GOOD_VOICE)
end
function CmdParser:CMD_LEAVE_MESSAGE_DELETE(pkt, data)
  self:CMD_BLOG_MESSAGE_DELETE(pkt, data)
  pkt:PutChar(data.type or LEAVE_MESSAGE_TYPE.GOOD_VOICE)
end
function CmdParser:CMD_LEAVE_MESSAGE_LIKE(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.char_gid)
  pkt:PutLenString(data.message_id)
  pkt:PutChar(data.type or LEAVE_MESSAGE_TYPE.GOOD_VOICE)
  pkt:PutChar(data.is_like or 1)
end
function CmdParser:CMD_LEAVE_MESSAGE_REPORT(pkt, data)
  pkt:PutLenString(data.user_dist)
  pkt:PutLenString(data.char_gid)
  pkt:PutLenString(data.message_id)
  pkt:PutChar(data.type or LEAVE_MESSAGE_TYPE.GOOD_VOICE)
end
function CmdParser:CMD_GOOD_VOICE_UPLOAD(pkt, data)
  pkt:PutLenString(data.title)
  pkt:PutLenString(data.voice_desc)
  pkt:PutLenString(data.voice_addr)
  pkt:PutChar(data.voice_dur)
end
function CmdParser:CMD_ADMIN_GOOD_VOICE_DELETE_VOICE(pkt, data)
  pkt:PutLenString(data.voice_id)
end
function CmdParser:CMD_L_PRECHARGE_CHARGE(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutShort(data.charge_type)
end
function CmdParser:CMD_CHOOSE_FASION(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_VOICE_STAT(pkt, data)
  pkt:PutChar(data.op_type)
  pkt:PutShort(data.duration)
end
function CmdParser:CMD_TRADING_SPOT_GOODS_VOLUME(pkt, data)
  pkt:PutLenString(data.trading_no)
end
function CmdParser:CMD_TRADING_SPOT_LARGE_ORDER_DATA(pkt, data)
  pkt:PutLenString(data.trading_no)
  pkt:PutLenString(data.last_order_id)
  pkt:PutChar(data.page)
end
function CmdParser:CMD_QIXI_2019_LMQG_SELECT(pkt, data)
  pkt:PutChar(data.martial_no)
end
function CmdParser:CMD_CHILD_JOIN_FAMILY(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_CHILD_HOUSEWORK(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_CHILD_SUPPLY_ENERGY(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutChar(data.energy)
end
function CmdParser:CMD_CHILD_FOLLOW_ME(pkt, data)
  pkt:PutLenString(data.cid)
  pkt:PutChar(data.flag)
  pkt:PutChar(data.out_combat)
end
function CmdParser:CMD_CHILD_VISIBLE(pkt, data)
  pkt:PutLenString(data.cid)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_CHILD_PRE_ASSIGN_ATTRIB(pkt, data)
  pkt:PutLenString(data.cid)
  pkt:PutLenString(data.plan)
end
function CmdParser:CMD_CHILD_SURE_ASSIGN_ATTRIB(pkt, data)
  pkt:PutLenString(data.cid)
  pkt:PutLenString(data.plan)
end
function CmdParser:CMD_CHILD_FETCH_TASK(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.task_name)
end
function CmdParser:CMD_CHILD_QUIT_GAME(pkt, data)
  pkt:PutChar(data.is_get_reward or 0)
end
function CmdParser:CMD_CHILD_SYNC_GAME_DATA(pkt, data)
  pkt:PutLenString(data.task_name)
  pkt:PutLenString2(data.para)
end
function CmdParser:CMD_CHILD_FINISH_GAME(pkt, data)
  pkt:PutLenString(data.task_name)
  pkt:PutLenString(data.result or "")
  pkt:PutLenString(data.socre or "")
  pkt:PutChar(data.guanka or 0)
end
function CmdParser:CMD_CHILD_CLICK_TASK_LOG(pkt, data)
  pkt:PutLenString(data.task_name)
end
function CmdParser:CMD_HOUSE_TDLS_MENU(pkt, data)
  pkt:PutLong(data.no)
end
function CmdParser:CMD_SUBMIT_CHILD_UPGRADE_ITEM(pkt, data)
  pkt:PutLenString(data.itemPosStr)
end
function CmdParser:CMD_CHILD_SUPPLY_TOY_DURABILITY(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutLenString(data.toy_name)
  pkt:PutLong(data.toy_id)
end
function CmdParser:CMD_CHILD_DROP_TOY(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutLenString(data.toy_name)
end
function CmdParser:CMD_CHILD_EQUIP_TOY(pkt, data)
  pkt:PutLenString(data.child_id)
  pkt:PutLenString(data.toy_name)
  pkt:PutLong(data.toy_id)
end
function CmdParser:CMD_CHILD_PRACTICE(pkt, data)
  pkt:PutChar(data.stage)
  pkt:PutLenString(data.child_id)
  pkt:PutLenString(data.xiulian_type)
end
function CmdParser:CMD_MERGE_CHILD_TOY(pkt, data)
  pkt:PutLong(data.no)
  pkt:PutChar(data.hecheng)
end
function CmdParser:CMD_CHILD_REQUEST_CULTIVATE_INFO(pkt, data)
  pkt:PutLenString(data.child_id)
end
function CmdParser:CMD_STOP_COMMON_PROGRESS(pkt, data)
  pkt:PutLenString(data.process_type)
end
function CmdParser:CMD_QUERY_CHILD_CARD(pkt, data)
  pkt:PutLenString(data.cid)
  pkt:PutChar(data.from or 1)
end
function CmdParser:CMD_CROSS_RANK_VIEW(pkt, data)
  pkt:PutShort(data.rank_type)
  pkt:PutLenString(data.level_limit)
  pkt:PutLong(data.cookie)
end
function CmdParser:CMD_FETCH_ZODIAC_SURPLUS(pkt, data)
  pkt:PutLong(data.value)
end
function CmdParser:CMD_FETCH_ZODIAC_MONEY(pkt, data)
  pkt:PutLong(data.value)
end
function CmdParser:CMD_START_ZODIAC_GUESS(pkt, data)
  pkt:PutLong(data.amount)
  pkt:PutChar(data.choice)
end
function CmdParser:CMD_BUY_ADVANCE_TRUSTEESHIP_TIME(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_SET_ADVANCE_TRUSTEESHIP_CONFIG(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutChar(data.stage)
  pkt:PutLong(data.time)
end
function CmdParser:CMD_AUTO_TASK_STATE(pkt, data)
  pkt:PutChar(data.actionType)
  pkt:PutChar(data.stage)
end
function CmdParser:CMD_L_LOGIN_PREVIEW_PLAYER(pkt, data)
  pkt:PutLenString(data.account)
end
function CmdParser:CMD_LOGIN_PREVIEW_DATA(pkt, data)
  pkt:PutLenString(data.account)
  pkt:PutLenString(data.gid)
  pkt:PutLong(data.time)
  pkt:PutLenString(data.cookie)
  pkt:PutLong(data.open_time)
  pkt:PutChar(data.refreshType)
end
function CmdParser:CMD_REDHAND_LOGIN(pkt, data)
  self:CMD_LOGIN(pkt, data)
end
function CmdParser:CMD_CONTINUE_LOOK_ON(pkt, data)
  pkt:PutLenString(data.combat_id)
  pkt:PutChar(data.corps)
end
function CmdParser:CMD_AUTUMN_2019_ZQTY_MAKE(pkt, data)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_AUTUMN_2019_ZQTY_GET_SCORE(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_AUTUMN_2019_ZQTY_QUIT(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_JIAOSJ_MPMZ_MOVE(pkt, data)
  pkt:PutChar(data.pos_x)
  pkt:PutChar(data.pos_y)
  pkt:PutChar(data.dir)
  pkt:PutShort(data.cookie)
end
function CmdParser:CMD_JIAOSJ_MPMZ_APPLY_ITEM(pkt, data)
  pkt:PutLenString(data.item_name)
end
function CmdParser:CMD_FETCH_TEST_LIVENESS_BONUS(pkt, data)
  pkt:PutChar(data.key)
end
function CmdParser:CMD_JIAOSJ_MPMZ_SET_STATUS(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_CSMC_RANK_DATA_TOP(pkt, data)
  pkt:PutShort(data.season)
  pkt:PutShort(data.min_level)
  pkt:PutShort(data.zone)
end
function CmdParser:CMD_CSMC_RANK_DATA_STAGE(pkt, data)
  pkt:PutShort(data.season)
  pkt:PutShort(data.min_level)
  pkt:PutShort(data.zone)
end
function CmdParser:CMD_CHONGYANG_2019_DGQX_ITEM(pkt, data)
  pkt:PutLenString(data.item_name)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLong(data[i].npc_id)
    pkt:PutLong(data[i].start_x)
    pkt:PutLong(data[i].start_y)
    pkt:PutLong(data[i].end_x)
    pkt:PutLong(data[i].end_y)
  end
end
function CmdParser:CMD_CHONGYANG_2019_FZLR_PLAY(pkt, data)
  pkt:PutLenString(data.text)
end
function CmdParser:CMD_GHOST_REFRESH_PEIYUAN(pkt, data)
  pkt:PutShort(data.pet_no)
end
function CmdParser:CMD_GHOST_START_PEIYUAN(pkt, data)
  pkt:PutShort(data.pet_no)
end
function CmdParser:CMD_GHOST_START_NINGSHEN(pkt, data)
  pkt:PutShort(data.pet_no)
  pkt:PutChar(data.index)
  pkt:PutChar(data.use_limit)
end
function CmdParser:CMD_GHOST_REFRESH_NINGSHEN(pkt, data)
  pkt:PutShort(data.pet_no)
end
function CmdParser:CMD_GHOST_START_REFINE(pkt, data)
  pkt:PutShort(data.pet_no)
  pkt:PutChar(data.type or 1)
  pkt:PutShort(data.attach_no)
end
function CmdParser:CMD_APPLY_GUICHONGQINMIDAN(pkt, data)
  pkt:PutShort(data.pet_no)
  pkt:PutShort(data.amount)
  pkt:PutChar(data.use_limit_item)
end
function CmdParser:CMD_SHENHUN_EQUIP_TAIYINZHIQI(pkt, data)
  pkt:PutChar(data.pos)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_SHENHUN_YQZC_BUY_ITEM(pkt, data)
  pkt:PutLenString(data.item_name)
  pkt:PutChar(data.item_count)
end
function CmdParser:CMD_SHENHUN_RECYCLE_ITEM(pkt, data)
  pkt:PutLenString(data.item_ids)
end
function CmdParser:CMD_ADMIN_MAKE_HORCRUX(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutShort(data.req_level)
  pkt:PutChar(data.skill_level)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    local prop = data.list[i]
    pkt:PutChar(i)
    pkt:PutChar(prop.chaos)
    pkt:PutChar(prop.yang_percent)
    pkt:PutLenString(prop.yang_prop)
    pkt:PutLenString(prop.yin_prop)
  end
end
function CmdParser:CMD_GHOST_SET_GONGSHENG(pkt, data)
  pkt:PutShort(data.no1)
  pkt:PutShort(data.no2)
end
function CmdParser:CMD_GHOST_UNSET_GONGSHENG(pkt, data)
  pkt:PutShort(data.no)
end
function CmdParser:CMD_LURE_SOUL_BANNER(pkt, data)
  pkt:PutChar(data.curPos - 1)
end
function CmdParser:CMD_LURE_SOUL_CARD(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutChar(data.para)
  pkt:PutChar(data.curPos - 1)
end
function CmdParser:CMD_LURE_SOUL_GAME(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_LURE_SOUL_STEP_BONUS(pkt, data)
  pkt:PutChar(data.pos)
end
function CmdParser:CMD_DROP_DGXN_ITEM(pkt, data)
  pkt:PutShort(data.pos)
end
function CmdParser:CMD_DIGONG_ENTER(pkt, data)
  pkt:PutChar(data.flag or 0)
end
function CmdParser:CMD_DG_REQUEST_RETINUE_DATA(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_DG_RECRUIT_RETINUE(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_DG_SET_RETINUE_COMBAT_POS(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.pos)
end
function CmdParser:CMD_DG_UPGRADE_RETINUE_RANK(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.count)
  for i = 1, #data.list do
    pkt:PutLong(data.list[i])
  end
end
function CmdParser:CMD_DG_RETINUE_DETAIL_DATA(pkt, data)
  pkt:PutLenString(data.str)
end
function CmdParser:CMD_DG_SELL_RETINUE(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_DIGONG_SHADOW(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutShort(data[i].c)
    pkt:PutShort(data[i].r)
  end
end
function CmdParser:CMD_DIGONG_CHANGE_YANGQI(pkt, data)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_XIAYUAN_JBSG(pkt, data)
  pkt:PutChar(data.pos)
end
function CmdParser:CMD_GUOQJ_BYXH_GAME_RESULT(pkt, data)
  pkt:PutChar(data.gate_index)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutChar(data[i])
  end
end
function CmdParser:CMD_DIGONG_BUY_GOODS(pkt, data)
  pkt:PutLenString(data.goodName)
end
function CmdParser:CMD_DIGONG_UPGRADE(pkt, data)
  pkt:PutChar(data.nextLevel)
end
function CmdParser:CMD_USE_DIGNONG_ITEM(pkt, data)
  pkt:PutShort(data.pos)
end
function CmdParser:CMD_CLOSE_LIMIT_RULE_DLG(pkt, data)
  pkt:PutLenString(data.dlg_name)
end
function CmdParser:CMD_FFA_REQUEST_RETINUE_DATA(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_FFA_RECRUIT_RETINUE(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_FFA_SET_RETINUE_COMBAT_POS(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.pos)
end
function CmdParser:CMD_FFA_UPGRADE_RETINUE_RANK(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutShort(data.count)
  for i = 1, #data.list do
    pkt:PutLong(data.list[i])
  end
end
function CmdParser:CMD_FFA_SELL_RETINUE(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_FFA_UPGRADE_PROP_LEVEL(pkt, data)
  pkt:PutChar(data.level)
end
function CmdParser:CMD_FFA_BUY_BAG_LEVEL_EXP(pkt, data)
  pkt:PutChar(data.exp_num)
end
function CmdParser:CMD_FFA_LOCK_RECRUIT_LIST(pkt, data)
  pkt:PutChar(data.is_lock)
end
function CmdParser:CMD_FFA_OVER_INSTRUCTION(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_GHOST_YIHUN(pkt, data)
  pkt:PutShort(data.no1)
  pkt:PutShort(data.no2)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_CLICK_TASK_LOG(pkt, data)
  pkt:PutLenString(data.task_name)
end
function CmdParser:CMD_NATIONAL_2019_BSJC_CANG(pkt, data)
  pkt:PutShort(data.index)
end
function CmdParser:CMD_NATIONAL_2019_BSJC_FIND(pkt, data)
  pkt:PutShort(data.index)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_XIAYUAN_2019_XLMZ_ATTACK(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_XIAYUAN_2019_XLMZ_REVIVE(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_GHOSTDOM_CHALLENGE(pkt, data)
  pkt:PutChar(data.cengshu)
end
function CmdParser:CMD_FENGSHOU_2019_COLLISION(pkt, data)
  pkt:PutLong(data.monster_id)
end
function CmdParser:CMD_ADMIN_MAKE_TAIYINZHIQI(pkt, data)
  pkt:PutLenString(data.prop)
  pkt:PutLenString(data.prop2)
  pkt:PutLenString(data.prop3)
end
function CmdParser:CMD_EXCHANGE_WZW_GOODS(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.name)
  pkt:PutLong(data.count)
end
function CmdParser:CMD_GHOST_START_REFINE_GODSKILL(pkt, data)
  pkt:PutShort(data.pet_no)
  pkt:PutChar(data.type or 1)
  pkt:PutShort(data.attach_no)
end
function CmdParser:CMD_PKM_GEN_HORCRUX(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutShort(data.req_level)
  pkt:PutChar(data.skill_level)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    local prop = data.list[i]
    pkt:PutChar(i)
    pkt:PutChar(prop.chaos)
    pkt:PutChar(prop.yang_percent)
    pkt:PutLenString(prop.yang_prop)
    pkt:PutLenString(prop.yin_prop)
  end
end
function CmdParser:CMD_QMPK_SIGNUP(pkt, data)
  pkt:PutLenString(data.sign_type)
  pkt:PutLenString(data.city_key)
  pkt:PutChar(data.cost_type or 1)
  pkt:PutLenString(data.bonus_gid or "")
end
function CmdParser:CMD_QMPK_SWITCH_SIGNUP(pkt, data)
  pkt:PutLenString(data.sign_type)
  pkt:PutLenString(data.city_key)
end
function CmdParser:CMD_QMPK_RECRUIT_SINGLE(pkt, data)
  pkt:PutChar(data.oper)
  pkt:PutLenString2(data.para)
  pkt:PutLenString(data.para2 or "0")
end
function CmdParser:CMD_QMPK_RECRUIT_SINGLE_QUERY_LIST(pkt, data)
  pkt:PutLenString(data.iid)
  pkt:PutLong(data.time)
  pkt:PutChar(data.polar)
  pkt:PutChar(data.pt_type)
end
function CmdParser:CMD_QMPK_RECRUIT_TEAM(pkt, data)
  pkt:PutChar(data.oper)
  pkt:PutLenString2(data.para)
  pkt:PutLenString(data.para2)
  pkt:PutLenString(data.para3 or "0")
end
function CmdParser:CMD_QMPK_RECRUIT_TEAM_QUERY_LIST(pkt, data)
  pkt:PutLenString(data.iid)
  pkt:PutLong(data.time)
  pkt:PutChar(data.polar)
  pkt:PutChar(data.pt_type)
end
function CmdParser:CMD_ADD_FABAO_INTIMACY_COUNT(pkt, data)
  pkt:PutShort(data.pos)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_SHIDAO_HISTORY_SCORE_INFO(pkt, data)
  pkt:PutLong(data.time)
  pkt:PutShort(data.level)
end
function CmdParser:CMD_COMMUNITY_COST_COIN(pkt, data)
  pkt:PutLenString(data.no)
  pkt:PutLenString2(data.para)
end
function CmdParser:CMD_PARTY_VIEW_MEMBER_DESC(pkt, data)
  pkt:PutLenString(data.member_gid)
end
function CmdParser:CMD_PARTY_MODIFY_MEMBER_DESC(pkt, data)
  pkt:PutLenString(data.member_gid)
  pkt:PutLenString(data.memo)
end
function CmdParser:CMD_LOG_END_COMBAT_EXCEPTION(pkt, data)
  pkt:PutLenString2(data.memo)
end
function CmdParser:CMD_COMMUNITY_IDENTITY(pkt, data)
  pkt:PutLenString(data.action)
  pkt:PutLenString(data.source)
  pkt:PutLenString(data.goods_id)
  pkt:PutLenString(data.message)
end
function CmdParser:CMD_WORKROOM_AUTHENTICATE_PHONE(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_TEAM_COMMANDER_SET_ATTACK_TARGET(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_CSQ_COMBAT_STAT(pkt, data)
  pkt:PutLenString(data.combat_id)
end
function CmdParser:CMD_DIGONG_BUY_CHARGE_GOODS(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.amount)
end
function CmdParser:CMD_DIGONG_BUY_MEDICINE_GOODS(pkt, data)
  pkt:PutLenString(data.item_name)
end
function CmdParser:CMD_DIGONG_SCTL_BUY_RETINUE(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_DIGONG_QUIT_GAME(pkt, data)
  pkt:PutChar(data.game_type)
end
function CmdParser:CMD_DIGONG_FINISH_GAME(pkt, data)
  pkt:PutChar(data.game_type)
  pkt:PutLenString(data.key)
end
function CmdParser:CMD_GHOST_ZHUANHUA(pkt, data)
  pkt:PutShort(data.ghost_no)
end
function CmdParser:CMD_QMPK_LOTTERY(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_FETCH_DIFU_LILIAN_BONUS(pkt, data)
  pkt:PutChar(data.rewardNo)
end
function CmdParser:CMD_INN_AUTO_TREAT_DATA(pkt, data)
  pkt:PutChar(data.in_work)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutChar(data.list[i])
  end
end
function CmdParser:CMD_INN_WAITER_CHANGE_NAME(pkt, data)
  pkt:PutLenString(data.text)
end
function CmdParser:CMD_YANLUO_MIBAO_SIGN(pkt, data)
  pkt:PutChar(data.is_can_fill_sign)
end
function CmdParser:CMD_REFRESH_USER_DATA(pkt, data)
  pkt:PutChar(data.reset_under_flag)
end
function CmdParser:CMD_REPORT_NETWORK_DELAY(pkt, data)
  pkt:PutLenString2(data.memo)
end
function CmdParser:CMD_FACE_VERIFY_RESULT(pkt, data)
  pkt:PutLenString(data.uid)
  pkt:PutLong(data.code)
end
function CmdParser:CMD_BLOG_OSS_TOKEN(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_OPEN_FAMOUS_RED_BAG(pkt, data)
  pkt:PutLenString(data.text)
end
function CmdParser:CMD_FAMOUS_OPEN_UI(pkt, data)
  pkt:PutShort(data.famous_type)
  pkt:PutLenString(data.level_index)
end
function CmdParser:CMD_FAMOUS_WORSHIP(pkt, data)
  pkt:PutShort(data.famous_type)
  pkt:PutLenString(data.level_index)
  pkt:PutLenString(data.char_gid)
end
function CmdParser:CMD_SWITCH_SHUADAO_LEVEL(pkt, data)
  pkt:PutChar(data.tao_stage)
end
function CmdParser:CMD_REQUEST_SIMULATE_DATA(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_CALC_SIMULATE_USER_DATA(pkt, data)
  pkt:PutLenString(data.value)
  pkt:PutLenString(data.value1)
  pkt:PutChar(data.show_tip)
end
function CmdParser:CMD_SIMULATE_USER_DATA(pkt, data)
  pkt:PutChar(data.apply)
  pkt:PutLenString(data.value)
end
function CmdParser:CMD_SIMULATE_PET_DATA(pkt, data)
  pkt:PutChar(data.apply)
  pkt:PutLenString(data.value)
end
function CmdParser:CMD_CALC_FINAL_USER_DATA(pkt, data)
  pkt:PutChar(data.save)
  pkt:PutLenString(data.value)
  pkt:PutChar(data.use_combat)
  pkt:PutChar(data.not_tips or 1)
end
function CmdParser:CMD_REQUEST_RAW_PET_DATA(pkt, data)
  pkt:PutChar(data.rank)
  pkt:PutLenString(data.name)
  pkt:PutShort(data.level)
end
function CmdParser:CMD_CALC_FINAL_PET_DATA(pkt, data)
  pkt:PutChar(data.save)
  pkt:PutLenString2(data.value)
  pkt:PutChar(data.use_combat)
  pkt:PutLenString(data.iid)
  pkt:PutChar(data.not_tips or 1)
end
function CmdParser:CMD_SET_SIMULATE_USER(pkt, data)
  pkt:PutChar(data.is_use and 1 or 0)
end
function CmdParser:CMD_SET_SIMULATE_PET(pkt, data)
  pkt:PutChar(data.is_use and 1 or 0)
end
function CmdParser:CMD_OPEN_MRT_EXCHANGE_SHOP(pkt, data)
end
function CmdParser:CMD_LOTTO_BID_BUY(pkt, data)
  pkt:PutChar(data.num)
  pkt:PutChar(data.auto_no)
  pkt:PutShort(#data.plan)
  for i = 1, #data.plan do
    pkt:PutChar(tonumber(data.plan[i]))
  end
end
function CmdParser:CMD_LOTTO_DRAW_RESULT(pkt, data)
  pkt:PutLenString(data.lotto_no)
end
function CmdParser:CMD_LOTTO_SUPER_BONUS_RESULT(pkt, data)
  pkt:PutLenString(data.lotto_no)
end
function CmdParser:CMD_LOTTO_PRE_BID_PLAN_DATA(pkt, data)
  pkt:PutShort(#data.plan)
  for i = 1, #data.plan do
    pkt:PutChar(tonumber(data.plan[i]))
  end
end
function CmdParser:CMD_JIUTIAN_ZHENJUN(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_START_SIMULATE_COMBAT(pkt, data)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_TRY_ENTER_YANWUCHANG(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_LANTERN2020_YXQJ_FALLING(pkt, data)
  pkt:PutShort(data.index)
end
function CmdParser:CMD_FAMOUS_CHAR_INFO(pkt, data)
  pkt:PutLenString(data.dist)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_DG_RETINUE_USAGE_RECORD(pkt, data)
  pkt:PutChar(data.dg_level)
end
function CmdParser:CMD_START_QUESTIONNAIRE(pkt, data)
  pkt:PutLong(data.id)
end
function CmdParser:CMD_SHIELD_LOG(pkt, data)
  pkt:PutLenString(data.action)
  pkt:PutShort(data.para1)
  pkt:PutLenString2(data.message)
end
function CmdParser:CMD_ANTI_CHEATER_UPLOAD_RECORD(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutLenString2(data.record)
end
function CmdParser:CMD_ANTI_CHEATER_REQUEST_CONFIG(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_VOICE_STAT_CONVERT_ID(pkt, data)
  pkt:PutChar(data.is_duplicate)
  pkt:PutLenString(data.convert_id)
end
function CmdParser:CMD_JIARPM_ROUND_TOUCH_INFO(pkt, data)
  pkt:PutLong(data.price)
end
function CmdParser:CMD_PARTY_BPYH_SETUP(pkt, data)
  pkt:PutChar(data.opType)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_PARTY_BPYH_SUBMIT(pkt, data)
  pkt:PutChar(data.dishNo)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString(data.foodMaterial[i].name)
    pkt:PutChar(data.foodMaterial[i].amount)
  end
end
function CmdParser:CMD_PARTY_BPWQ_SETUP(pkt, data)
  pkt:PutChar(data.opType)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_PARTY_BPQQL_SETUP(pkt, data)
  pkt:PutChar(data.opType)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_RXJ2019_XQDZ_YIDONG(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_YUANDJ_MCQH_SET_HIDE_POS(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLong(data.x)
  pkt:PutLong(data.y)
  pkt:PutChar(data.dir)
end
function CmdParser:CMD_YUANDJ_MCQH_SET_GAME_RESULT(pkt, data)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_START_MATCH_TEAM_LEADER_DFJJC(pkt, data)
  pkt:PutShort(data.minLevel)
  pkt:PutShort(data.maxLevel)
  pkt:PutLong(data.minTao * Const.ONE_YEAR_TAO)
  pkt:PutLong(data.maxTao * Const.ONE_YEAR_TAO)
  pkt:PutShort(#data.polars)
  for i = 1, #data.polars do
    pkt:PutChar(data.polars[i])
  end
end
function CmdParser:CMD_DFJJC_SET_AUTO_MATCH(pkt, data)
  pkt:PutChar(data.status)
end
function CmdParser:CMD_LANTERN2020_CDM_ANSWER(pkt, data)
  pkt:PutShort(data.question_id)
  pkt:PutLenString(data.answer)
end
function CmdParser:CMD_LANTERN2020_CDM_SET_STATUS(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_DFJJC_ONE_KEY_SHOUT(pkt, data)
  pkt:PutLenString(data.tip)
end
function CmdParser:CMD_WINTER_2020_XZDZZ_OPER_XZ(pkt, data)
  pkt:PutChar(data.state)
  pkt:PutChar(data.lineIndex)
end
function CmdParser:CMD_WINTER_2020_XZDZZ_OPER_GAME(pkt, data)
  pkt:PutChar(data.action)
end
function CmdParser:CMD_YUANDJ_MCQH_SELECT_FURNITURE(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_REBIRTH_PET_TRY(pkt, data)
  pkt:PutLenString(data.pet_iid)
end
function CmdParser:CMD_REBIRTH_PET_CONFIRM(pkt, data)
  pkt:PutLenString(data.pet_iid)
  pkt:PutLong(data.need_coin)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_XRBLQ_TOUQIU(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_XRBLQ_MOVE(pkt, data)
  pkt:PutChar(data.dir)
end
function CmdParser:CMD_SPRING_2020_BZQY_FINISH(pkt, data)
  pkt:PutLenString(data.stage)
  pkt:PutLenString(data.score)
end
function CmdParser:CMD_GET_AAA_CHARGE_BONUS(pkt, data)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_SPRING_2020_XCXB_DIG(pkt, data)
  pkt:PutChar(data.tool_type)
  pkt:PutChar(data.x)
  pkt:PutChar(data.y)
  pkt:PutChar(data.is_guide)
end
function CmdParser:CMD_SPRING_2020_XCXB_FETCH(pkt, data)
  pkt:PutChar(data.x)
  pkt:PutChar(data.y)
end
function CmdParser:CMD_SPRING_2020_XCXB_BUY_ITEM(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_WEDDING_RUNNING_REDBAG_SETTING(pkt, data)
  pkt:PutShort(data.num)
  pkt:PutLong(data.cash)
  pkt:PutChar(data.status)
  pkt:PutChar(data.not_tips or 0)
end
function CmdParser:CMD_WEDDING_RUNNING_REDBAG_SA(pkt, data)
  pkt:PutLong(data.x)
  pkt:PutLong(data.y)
end
function CmdParser:CMD_WEDDING_SCHEDULE(pkt, data)
  pkt:PutLong(data.start_time)
end
function CmdParser:CMD_SPRING_2020_BZQY_QUIT(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_NEW_YEAR_BLESS_CONGRATULATION(pkt, data)
  pkt:PutChar(data.bless_type)
end
function CmdParser:CMD_NEW_YEAR_BLESS_BLESS(pkt, data)
  pkt:PutChar(data.bless_type)
end
function CmdParser:CMD_SWITCH_BACK_HUNQIAO(pkt, data)
  pkt:PutChar(data.page)
end
function CmdParser:CMD_WD_RB_SEND_REDBAG(pkt, data)
  pkt:PutLong(data.coin)
  pkt:PutShort(data.count)
  pkt:PutChar(data.text_no)
end
function CmdParser:CMD_WD_RB_RECV_REDBAG(pkt, data)
  pkt:PutLenString(data.redbag_gid)
end
function CmdParser:CMD_WD_RB_SHOW_REDBAG(pkt, data)
  pkt:PutLenString(data.redbag_gid)
end
function CmdParser:CMD_NEWYEAR_REDBAG_2020_OPEN_DLG(pkt, data)
  pkt:PutChar(data.flag or 1)
  pkt:PutLenString(data.id or "")
end
function CmdParser:CMD_TXJ2020_QLXH_LOG_COMMON(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_TONGXIN2020_TXJY_LINE(pkt, data)
  pkt:PutShort(data.from)
  pkt:PutShort(data.to)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_TEAM_ASSESS_INFO(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_TEAM_ASSESS_SET(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_CSPW_REQUEST_MATCH_DATA(pkt, data)
  pkt:PutLong(data.session)
  pkt:PutChar(data.zone)
end
function CmdParser:CMD_SSWD_QUIT_GAME(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_SSWD_PLAY_CHESS(pkt, data)
  pkt:PutChar(data.pos)
  pkt:PutChar(data.level)
end
function CmdParser:CMD_SSWD_SELECT_ANSWER(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_SSWD_USE_TASK_ITEM(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutLong(data.npcId)
end
function CmdParser:CMD_QINGMING2020_SLQX_STATUS(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_QINGMING2020_SLQX_ARCHERY_OXYGEN_NUM(pkt, data)
  pkt:PutLenString(data.oxygen_num)
  pkt:PutChar(data.arrow_num)
end
function CmdParser:CMD_QINGMING2020_SLQX_RESULT(pkt, data)
  pkt:PutChar(data.level)
  pkt:PutLenString(data.result)
end
function CmdParser:CMD_TANAN_SMFJ_CHANGE_DIRECTION(pkt, data)
  pkt:PutLong(data.furniture_pos)
  pkt:PutChar(data.dir)
end
function CmdParser:CMD_TANAN_SMFJ_SEARCH_FURNITURE(pkt, data)
  pkt:PutLong(data.furniture_pos)
end
function CmdParser:CMD_TANAN_SMFJ_GET_TASK_ITEM(pkt, data)
  pkt:PutLenString(data.type)
end
function CmdParser:CMD_TANAN_SMFJ_SUBMIT_ITEM(pkt, data)
  pkt:PutLenString(data.npc_name)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString(data.items[i])
  end
end
function CmdParser:CMD_TANAN_SMFJ_USE_ITEM(pkt, data)
  pkt:PutLenString(data.item_name)
end
function CmdParser:CMD_ZHENMOLU_CHANGE(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.item_name)
end
function CmdParser:CMD_ZHENMOLU_BUY(pkt, data)
  pkt:PutShort(data.count)
end
function CmdParser:CMD_ZHENMOLU_START(pkt, data)
  pkt:PutChar(data.level)
end
function CmdParser:CMD_TANAN_SMFJ_MARK_FLAG(pkt, data)
  pkt:PutLenString(data.flag)
end
function CmdParser:CMD_QINGMING2020_QMDJ_USE_CARD(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_QINGMING2020_QMDJ_CONTINUE(pkt, data)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_LANTERN2020_XYHD_ACT_DATA(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_LANTERN2020_XYHD_LIGHTEN(pkt, data)
  pkt:PutLenString(data.pet_name)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_LANTERN2020_XYHD_DRAW(pkt, data)
  pkt:PutLenString(data.pet_name)
end
function CmdParser:CMD_LANTERN2020_XYHD_PROGRESS_BONUS(pkt, data)
  pkt:PutChar(data.times)
end
function CmdParser:CMD_LANTERN2020_XYHD_LARGE_BONUS_LIST(pkt, data)
  pkt:PutLenString(data.pet_name)
  pkt:PutShort(data.from)
end
function CmdParser:CMD_L_LANTERN2020_XYHD_OPER(pkt, data)
  pkt:PutLenString(data.para1 or "")
  pkt:PutLenString(data.para2 or "")
  pkt:PutLenString(data.para3 or "")
  pkt:PutLenString(data.para4 or "")
end
function CmdParser:CMD_CHARGE_PET_DEFAULT_CARD_INFO(pkt, data)
  pkt:PutLenString(data.pet_name)
  pkt:PutChar(data.special_skill_num or 0)
end
function CmdParser:CMD_BUY_RA_HELP_GIFT(pkt, data)
  pkt:PutLenString(data.gift_name)
end
function CmdParser:CMD_TANAN_MSHC_RESULT(pkt, data)
  pkt:PutLenString(data.result)
  pkt:PutLenString(data.memo)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_STMZ_SELECT_GIFT(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_STMZ_USE_ITEM(pkt, data)
  pkt:PutLenString(data.item_name)
  pkt:PutLenString(data.npc_name)
end
function CmdParser:CMD_MIJING_SHILIAN_CLICK(pkt, data)
  pkt:PutShort(data.layer)
  pkt:PutChar(data.x)
  pkt:PutChar(data.y)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_MIJING_SHILIAN_BACK(pkt, data)
  pkt:PutShort(data.layer)
end
function CmdParser:CMD_MIJING_SHILIAN_FETCH_DAILY_BONUS(pkt, data)
  pkt:PutChar(data.task_index)
end
function CmdParser:CMD_MIJING_SHILIAN_BUY_ITEM(pkt, data)
  pkt:PutChar(data.index)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_MIJING_SHILIAN_EQUIP(pkt, data)
  pkt:PutChar(data.pos)
  pkt:PutShort(data.equip_id)
end
function CmdParser:CMD_MIJING_SHILIAN_UPGRADE(pkt, data)
  pkt:PutChar(data.pos)
end
function CmdParser:CMD_JNSZ_SWITCH_TASK_STATE(pkt, data)
  pkt:PutLenString(data.state)
end
function CmdParser:CMD_JNSZ_FINISH_GAME(pkt, data)
  pkt:PutChar(data.result)
end
function CmdParser:CMD_JNSZ_SAVE_PUZZLE_POS(pkt, data)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutChar(data.list[i])
  end
end
function CmdParser:CMD_JNSZ_SUBMIT_CLUE(pkt, data)
  pkt:PutLenString(data.anwser)
end
function CmdParser:CMD_DIGONG_INSTANT_TRANSFER(pkt, data)
  pkt:PutShort(data.x)
  pkt:PutShort(data.y)
end
function CmdParser:CMD_SET_TAIYINZHIQI_LOCKED(pkt, data)
  pkt:PutLong(data.id)
  pkt:PutChar(data.flag)
end
function CmdParser:CMD_FIREWORKS_PARTY_USE_ITEM(pkt, data)
  pkt:PutChar(data.index)
  pkt:PutChar(data.isOpenFast or 0)
end
function CmdParser:CMD_FIREWORKS_PARTY_BUY(pkt, data)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_ZNQ_2020_XDHX_SET_NIMBUS_LIST(pkt, data)
  pkt:PutShort(#data)
  for i = 1, #data do
    pkt:PutChar(data[i])
  end
end
function CmdParser:CMD_ZNQ_2020_XDHX_HELP(pkt, data)
  pkt:PutLenString(data.friend_gid)
end
function CmdParser:CMD_ZNQ_2020_XDHX_DATA(pkt, data)
  pkt:PutChar(data.need_open_dlg or 0)
end
function CmdParser:CMD_ZNQ_2020_XDHX_SET_NIMBUS_TYPE(pkt, data)
  pkt:PutChar(data.nimbus_type)
end
function CmdParser:CMD_ZNQ_2020_XDHX_FRIEND_DATA(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_ZNQ_2020_XDHX_APPLY_ITEM(pkt, data)
  pkt:PutChar(data.item_type)
end
function CmdParser:CMD_ZZJ2020_YGYS_GAME_OPER(pkt, data)
  pkt:PutChar(data.type1)
  pkt:PutChar(data.type2)
end
function CmdParser:CMD_LOOK_ON_ESCAPE(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_STMZ_SUBMIT_NAME(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_LABOR2020_ZRSC_DATA(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLong(data.cut_num or 0)
end
function CmdParser:CMD_AAA_EXISTED_CHAR_LIST(pkt, data)
  pkt:PutLenString(data.account)
end
function CmdParser:CMD_ZNQ2020_TZZRY_DATA(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutChar(data.question_index or 0)
  pkt:PutChar(data.select_id or 0)
end
function CmdParser:CMD_NEW_DIST_CHONG_BANG_DATA(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutShort(data.startIdx)
  pkt:PutShort(data.endIdx)
end
function CmdParser:CMD_NEW_DIST_ONLINEMALL_BUY_ITEM(pkt, data)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_LOG_AUTO_TEST_TOOL_LOG(pkt, data)
  pkt:PutLenString(data.script_name)
  pkt:PutLenString(data.action)
end
function CmdParser:CMD_USER_LOGIN_RENAME(pkt, data)
  pkt:PutLenString(data.name)
end
function CmdParser:CMD_USER_AGREEMENT_PRIVACY(pkt, data)
  pkt:PutLong(data.time)
  pkt:PutLenString(data.version)
end
function CmdParser:CMD_PARTY_BLACK_LIST(pkt, data)
  pkt:PutShort(data.page)
end
function CmdParser:CMD_PARTY_BLACK_MEMO(pkt, data)
  pkt:PutShort(data.page)
  pkt:PutLenString(data.char_gid)
  pkt:PutLenString(data.memo)
end
function CmdParser:CMD_PARTY_BLACK_REMOVE(pkt, data)
  pkt:PutShort(data.page)
  pkt:PutLenString(data.char_gid)
end
function CmdParser:CMD_FIREWORKS_PARTY_INFO(pkt, data)
  pkt:PutChar(data.is_open or 0)
end
function CmdParser:CMD_GET_CHAR_TITLE(pkt, data)
  pkt:PutLenString(data.gid)
end
function CmdParser:CMD_CHANGE_CUSTOM_APPELLATION(pkt, data)
  pkt:PutChar(data.type)
  pkt:PutLenString(data.title)
end
function CmdParser:CMD_EQUIP_TASK_GET_GOODS(pkt, data)
  pkt:PutLenString(data.taskType)
  pkt:PutLenString(data.goods_name)
end
function CmdParser:CMD_REPORT_MAIL(pkt, data)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_RADIO_VOICE_RANK_LIST(pkt, data)
  pkt:PutChar(data.rank_type)
end
function CmdParser:CMD_RADIO_VOICE_MY_DATA(pkt, data)
end
function CmdParser:CMD_RADIO_VOICE_OTHER_DATA(pkt, data)
  pkt:PutLenString(data.singer_dist)
  pkt:PutLenString(data.singer_gid)
  pkt:PutChar(data.need_open_dlg)
end
function CmdParser:CMD_RADIO_VOICE_PLAYLIST(pkt, data)
  pkt:PutLong(data.client_ver)
end
function CmdParser:CMD_RADIO_VOICE_PLAYLIST_OPER(pkt, data)
  pkt:PutLenString(data.action)
  pkt:PutLenString(data.para or "")
end
function CmdParser:CMD_RADIO_VOICE_OPEN_SERVICE(pkt, data)
  pkt:PutLenString(data.radio_name)
  pkt:PutLenString(data.radio_desc)
  pkt:PutLenString(data.icon_img)
  pkt:PutChar(data.expect_discount_percent)
end
function CmdParser:CMD_RADIO_VOICE_RENEW_SERVICE(pkt, data)
  pkt:PutChar(data.use_popular)
  pkt:PutLenString(data.radio_desc)
  pkt:PutLenString(data.icon_img)
  pkt:PutChar(data.expect_discount_percent)
end
function CmdParser:CMD_RADIO_VOICE_CHANGE_INTRO(pkt, data)
  pkt:PutLenString(data.radio_desc)
end
function CmdParser:CMD_RADIO_VOICE_CHANGE_IMAGE(pkt, data)
  pkt:PutLenString(data.project_id)
  pkt:PutLenString(tostring(data.icon_img))
end
function CmdParser:CMD_RADIO_VOICE_FOLLOW_RADIO_LIST(pkt, data)
  pkt:PutLenString(data.singer_dist)
  pkt:PutLenString(data.singer_gid)
  pkt:PutLong(data.from_time)
  pkt:PutLenString(data.from_gid)
end
function CmdParser:CMD_RADIO_VOICE_FANS_LIST(pkt, data)
  pkt:PutLenString(data.singer_dist)
  pkt:PutLenString(data.singer_gid)
  pkt:PutLong(data.from_time)
  pkt:PutLenString(data.from_gid)
end
function CmdParser:CMD_RADIO_VOICE_FOLLOW(pkt, data)
  pkt:PutLenString(data.singer_dist)
  pkt:PutLenString(data.singer_gid)
end
function CmdParser:CMD_RADIO_VOICE_CANCEL_FOLLOW(pkt, data)
  pkt:PutLenString(data.singer_dist)
  pkt:PutLenString(data.singer_gid)
end
function CmdParser:CMD_RADIO_VOICE_PLAY_VOICE(pkt, data)
  pkt:PutLenString(data.singer_dist)
  pkt:PutLenString(data.project_id)
end
function CmdParser:CMD_RADIO_VOICE_CANCEL_VOICE(pkt, data)
  pkt:PutLenString(data.project_id)
end
function CmdParser:CMD_ADMIN_RADIO_VOICE_DELETE_VOICE(pkt, data)
  pkt:PutLenString(data.dist)
  pkt:PutLenString(data.project_id)
end
function CmdParser:CMD_RADIO_VOICE_OPEN_GIVE_FLOWER_DLG(pkt, data)
  pkt:PutLenString(data.dist)
  pkt:PutLenString(data.project_id)
end
function CmdParser:CMD_RADIO_VOICE_GIVE_FLOWER(pkt, data)
  pkt:PutLenString(data.dist)
  pkt:PutLenString(data.project_id)
  pkt:PutLenString(data.flower)
end
function CmdParser:CMD_RADIO_VOICE_VOICE_DATA(pkt, data)
  pkt:PutLenString(data.dist)
  pkt:PutLenString(data.project_id)
  pkt:PutChar(data.need_open_dlg or 0)
end
function CmdParser:CMD_RADIO_VOICE_UPLOAD_IMAGE(pkt, data)
  pkt:PutLenString(data.icon_img)
end
function CmdParser:CMD_RADIO_VOICE_REPORT_VOICE(pkt, data)
  pkt:PutLenString(data.dist)
  pkt:PutLenString(data.project_id)
  pkt:PutLenString(data.reason)
  pkt:PutChar(data.rp_type)
end
function CmdParser:CMD_RADIO_OFFICIAL_VOICE_LIST(pkt, data)
  pkt:PutLenString(data.album_id)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_RADIO_OFFICIAL_VOICE_DATA(pkt, data)
  pkt:PutLenString(data.project_id)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_RADIO_VOICE_OPEN_DLG(pkt, data)
  pkt:PutLenString(data.dist or "")
  pkt:PutLenString(data.id or "")
  pkt:PutChar(data.type or 0)
  pkt:PutChar(data.log_type or 0)
end
function CmdParser:CMD_RADIO_VOICE_CHANGE_SHOW_MODE(pkt, data)
  pkt:PutLenString(data.project_id)
  pkt:PutChar(data.is_show)
end
function CmdParser:CMD_RADIO_VOICE_SET_MESSAGE_VER(pkt, data)
  pkt:PutLong(data.message_ver)
end
function CmdParser:CMD_RADIO_VOICE_UPLOAD_VOICE(pkt, data)
  pkt:PutLenString(data.title or "")
  pkt:PutLenString(data.voice_desc or "")
  pkt:PutLenString(data.voice_addr or "")
  pkt:PutChar(data.voice_dur)
  pkt:PutLenString(data.icon_img or "")
  pkt:PutChar(data.is_show)
end
function CmdParser:CMD_CHILD2020_TZHJ_GAME_DATA(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutChar(data.idx)
end
function CmdParser:CMD_DUANWU2020_GAME_DATA(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutChar(data.from_x or 0)
  pkt:PutChar(data.from_y or 0)
  pkt:PutChar(data.to_x or 0)
  pkt:PutChar(data.to_y or 0)
end
function CmdParser:CMD_RADIO_VOICE_FAVORITE_OPER(pkt, data)
  pkt:PutLenString(data.action)
  pkt:PutLenString(data.para)
end
function CmdParser:CMD_BLOG_DELETE_ALL_COMMENT_AND_MESSAGE(pkt, data)
  pkt:PutLenString(data.send_gid)
end
function CmdParser:CMD_RADIO_VOICE_CHANGE_FAVORITE(pkt, data)
  pkt:PutLenString(data.id)
  pkt:PutLenString(data.dist)
  pkt:PutChar(data.is_favorite)
  pkt:PutChar(data.ctype)
  pkt:PutLenString(data.fav_id)
end
function CmdParser:CMD_RADIO_VOICE_CHANGE_NAME(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.is_free)
end
function CmdParser:CMD_PARTY_CONTRIBUTOR_SHOP_BUY(pkt, data)
  pkt:PutShort(data.goods_id)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_SOUL_ACTIVE_FULINGZHEN(pkt, data)
  pkt:PutChar(data.oper)
end
function CmdParser:CMD_SOUL_IMPROVE_ZHENLING_LEVEL(pkt, data)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_SOUL_ZHENLING_FUSHEN(pkt, data)
  pkt:PutChar(data.obj_type)
  pkt:PutLenString(data.id)
  pkt:PutChar(data.type)
end
function CmdParser:CMD_SOUL_CANCEL_ZHENLING_FUSHEN(pkt, data)
  pkt:PutChar(data.obj_type)
  pkt:PutLenString(data.id)
end
function CmdParser:CMD_SUMMER2020_DKFZ_FETCH_BONUS(pkt, data)
  pkt:PutChar(data.quit_flag)
  pkt:PutLenString(data.score_result)
end
function CmdParser:CMD_SET_CHAT_USEFUL_PHRASE(pkt, data)
  pkt:PutShort(data.count)
  for i = 1, data.count do
    pkt:PutLenString(data[i])
  end
  pkt:PutChar(data.index)
end
function CmdParser:CMD_CHAT_GET_VOICE_TEXT_FAILED(pkt, data)
  pkt:PutShort(data.channel)
  pkt:PutLong(data.voiceTime or 0)
  pkt:PutLenString2(data.token or "")
end
function CmdParser:CMD_PET_ADD_LONGEVITY(pkt, data)
  pkt:PutChar(data.pet_no)
  pkt:PutShort(data.ssd_amount)
  pkt:PutShort(data.cjssd_amount)
  pkt:PutChar(data.use_limit_item)
end
function CmdParser:CMD_AUTO_CANGBAOTU_STOP(pkt, data)
  pkt:PutChar(data.not_tip)
  pkt:PutLenString(data.reason)
end
function CmdParser:CMD_CHILD_SWITCH_DFCJ_AND_XFCJ(pkt, data)
  pkt:PutLenString(data.cid)
  pkt:PutChar(data.flag)
  pkt:PutLong(data.cost_count)
end
function CmdParser:CMD_BAIBAODAI_BUY_ITEM(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_BAIBAODAI_BONUS_LIST(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_AUTO_CANGBAOTU_START(pkt, data)
  pkt:PutLenString(data.itemName)
end
function CmdParser:CMD_STALL_REQUEST_FROZEN_RECORD(pkt, data)
  pkt:PutShort(data.from_pos)
end
function CmdParser:CMD_FIXED_TEAM_RECRUIT_CHANGE_SHOW_CARD(pkt, data)
  pkt:PutChar(data.is_show)
end
function CmdParser:CMD_STOP_GATHER(pkt, data)
  pkt:PutLenString(data.gather_key)
end
function CmdParser:CMD_QIXI_YFSG_SET_TITLE(pkt, data)
  pkt:PutLenString(data.gid)
  pkt:PutLenString(data.title)
end
function CmdParser:CMD_GHOST2020_OPEN_BAOSHI(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_GHOST2020_BUY_TANGGUO(pkt, data)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_GHOST2020_BUY_ITEM(pkt, data)
  pkt:PutLenString(data.item_name)
  pkt:PutChar(data.num)
end
function CmdParser:CMD_TEACHER2020_HYXZ_GAME_DATA(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutLenString(data.result)
  pkt:PutShort(data.num or 0)
  pkt:PutShort(data.hq_num or 0)
  pkt:PutShort(data.hylj_num or 0)
  pkt:PutShort(data.lyhh_num or 0)
end
function CmdParser:CMD_SHISHENJI_XE_SOUXUN(pkt, data)
  pkt:PutShort(data.use_tili)
end
function CmdParser:CMD_SHISHENJI_CY_SET(pkt, data)
  pkt:PutLenString(data.caipu_key_name)
end
function CmdParser:CMD_SHISHENJI_SSDZF_GET(pkt, data)
  pkt:PutChar(data.index)
end
function CmdParser:CMD_SHISHENJI_SHOP_BUY(pkt, data)
  pkt:PutLong(data.cookie)
  pkt:PutChar(data.pos)
end
function CmdParser:CMD_SHISHENJI_SHOP_SALE(pkt, data)
  pkt:PutLenString(data.shicai_key_name)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_SHISHENJI_CY_USE(pkt, data)
  pkt:PutLenString(data.caiyao_key_name)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_SHISHENJI_DATA(pkt, data)
  pkt:PutLenString(data.is_open_dlg and 1 or 0)
end
function CmdParser:CMD_SHISHENJI_CP_UNLOCK(pkt, data)
  pkt:PutLenString(data.shipu_key_name)
  pkt:PutLenString(data.shicai_1)
  pkt:PutShort(data.num_1)
  pkt:PutLenString(data.shicai_2)
  pkt:PutShort(data.num_2)
  pkt:PutLenString(data.shicai_3)
  pkt:PutShort(data.num_3)
end
function CmdParser:CMD_SHISHENJI_CY_START(pkt, data)
  pkt:PutShort(data.num or 1)
end
function CmdParser:CMD_CHALLENGE_GUARDIAN_ICON(pkt, data)
  pkt:PutLenString(data.map_name)
end
function CmdParser:CMD_TEACHER2020_WXDJ_GAME_DATA(pkt, data)
  pkt:PutLenString(data.type)
  pkt:PutShort(data.num or 0)
end
function CmdParser:CMD_HOUSE_JCX_OPERATE(pkt, data)
  pkt:PutLong(data.pos)
  pkt:PutChar(data.oper_type)
  pkt:PutLong(data.money)
end
function CmdParser:CMD_HOUSE_JCX_OPEN(pkt, data)
  pkt:PutLong(data.pos)
end
function CmdParser:CMD_ADMIN_MAKE_ARTIFACT(pkt, data)
  pkt:PutLenString(data.name)
  pkt:PutChar(data.level)
  pkt:PutChar(data.polar)
  pkt:PutLong(data.intimacy)
  pkt:PutLenString(data.skill)
  pkt:PutChar(data.skill_level)
end
function CmdParser:CMD_KSDZ_BS_USE(pkt, data)
  pkt:PutLenString(data.baoshi_name)
end
function CmdParser:CMD_QMPK_GUESS(pkt, data)
  pkt:PutLenString(data.match_id)
  pkt:PutChar(data.index)
  pkt:PutLenString(data.team_id)
  pkt:PutLong(data.amount)
end
function CmdParser:CMD_QMPK_TEAM_RECORDS(pkt, data)
  pkt:PutLenString(data.team_id)
end
function CmdParser:CMD_QMPK_COB_RECORD(pkt, data)
  pkt:PutLenString(data.record_id)
end
function CmdParser:CMD_QMPK_GUESS_SHOP_BUY(pkt, data)
  pkt:PutLong(data.cookies)
  pkt:PutLenString(data.item_name)
  pkt:PutShort(data.num)
end
function CmdParser:CMD_WAITING_RANDOM_NAME(pkt, data)
  pkt:PutChar(data.gender)
end
function CmdParser:CMD_CREATE_WAITING_CHAR(pkt, data)
  pkt:PutLenString(data.char_name)
  pkt:PutChar(data.gender)
  pkt:PutChar(data.polar)
end
function CmdParser:CMD_SWITCH_WAITING_CHAR(pkt, data)
  pkt:PutLenString(data.char)
end
function CmdParser:CMD_PING_CLIENT(pkt, data)
  pkt:PutLenString(data.key)
  pkt:PutChar(data.times)
end
function CmdParser:CMD_WORKROOM_AUTHENTICATE_FACE(pkt, data)
  pkt:PutLenString(data.check_type or "")
  pkt:PutChar(data.open_dlg or 0)
end
function CmdParser:CMD_FACE_VERIFY_EWM(pkt, data)
  pkt:PutLenString(data.check_type)
end
function CmdParser:CMD_BIRTHDAY_GIFT_FASION(pkt, data)
  pkt:PutLenString(data.fasion_name)
end
function CmdParser:CMD_NEIDAN_TASK_DESC(pkt, data)
  pkt:PutChar(data.state)
  pkt:PutChar(data.stage)
end
function CmdParser:CMD_REFRESH_CS_SHIDAO_PLAN(pkt, data)
  pkt:PutChar(data.type)
end
return CmdParser
