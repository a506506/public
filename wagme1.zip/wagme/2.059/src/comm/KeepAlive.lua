local KeepAlive = class("KeepAlive")
local ECHO_INTERVAL = 10
local ECHO_MILSEC_INTERVAL = ECHO_INTERVAL * 1000
local lastDelayTime = 0
function KeepAlive:ctor()
  self._lastSendTime = 0
  self._lastRecvTime = 0
  self._replyTime = 0
  self._peerTime = 0
  self._checkDelay = nil
end
function KeepAlive:sendCmdEcho(conn, checkDelay)
  local currentTime = gfGetTickCount()
  if currentTime - self._lastSendTime < ECHO_MILSEC_INTERVAL then
    return
  end
  self._lastSendTime = currentTime
  self._checkDelay = checkDelay
  gf:CmdToServer("CMD_ECHO", {
    current_time = self._lastSendTime,
    peer_time = self._peerTime
  })
end
function KeepAlive:onRecvCmdEcho()
  self._replyTime = gfGetTickCount()
  gf:CmdToServer("MSG_REPLY_ECHO", {
    reply_time = self._replyTime
  })
end
function KeepAlive:onRecvMsgReplyEcho(peer_time)
  self._peerTime = peer_time
  self._lastRecvTime = gfGetTickCount()
  if self._checkDelay then
    lastDelayTime = self._lastRecvTime - self._lastSendTime
    self.checkDelay = nil
  end
end
function KeepAlive:getLastDelayTime()
  return lastDelayTime
end
return KeepAlive
