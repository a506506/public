function Singleton(name, super)
  local obj = {
    var = {}
  }
  if name then
    obj.var.name = name
    obj.__cls_type__ = name
  end
  local met = {}
  function met.__index(tbl, key)
    if tbl.var[key] ~= nil then
      return tbl.var[key]
    elseif super then
      return super[key]
    else
      return nil
    end
  end
  function met.__newindex(tbl, key, value)
    if type(value) ~= "function" then
      assert("name" ~= key)
      tbl.var[key] = value
    else
      rawset(tbl, key, value)
    end
  end
  setmetatable(obj, met)
  if cc.PLATFORM_OS_WINDOWS == cc.Application:getInstance():getTargetPlatform() then
    obj.__super = super
  end
  return obj
end
