Log = {}
Log.emsg = ""
local log = gfLog
local LOG_SUB_PATH = "/logs"
local LOG_PATH = cc.FileUtils:getInstance():getWritablePath() .. LOG_SUB_PATH
function Log:D(...)
  if ATM_IS_DEBUG_VER then
    print("DEBUG : " .. string.format(...))
  end
  Log:printStack()
end
function Log:I(...)
  gfLog("INF : " .. string.format(...))
  Log:printStack()
end
function Log:W(...)
  gfLog("WARNNING : " .. string.format(...))
  Log:printStack()
end
function Log:E(...)
  local msg = string.format(...)
  self.emsg = self.emsg .. "\n" .. msg
  gfLog("ERROR : " .. msg)
  self:logToFile(msg)
  Log:printStack()
end
function Log:logToFile(msg)
  if not lfs.attributes(LOG_PATH) then
    lfs.mkdir(LOG_PATH)
  end
  local time = math.floor(os.time() / 3600 / 24) * 3600 * 24
  local filePath = LOG_PATH .. "/" .. tostring(os.date("%Y-%m-%d", time)) .. ".log"
  local f = io.open(filePath, "a")
  if not f then
    return
  end
  f:write(string.format("%s    %s\n", tostring(os.date("%Y-%m-%d %H:%M:%S", os.time())), msg))
  f:close()
end
function Log:F(...)
  local msg = string.format(...)
  self:logToFile(msg)
  self:I(...)
end
function Log:CF(time)
  time = math.floor(time / 3600 / 24) * 3600 * 24
  local lfs = require("lfs")
  if not lfs.attributes(LOG_PATH) then
    return
  end
  for i in lfs.dir(LOG_PATH) do
    local attr = lfs.attributes(LOG_PATH .. "/" .. i)
    if attr and time > attr.modification then
      os.remove(LOG_PATH .. "/" .. i)
    end
  end
end
function Log:printStack()
  if not ATM_IS_DEBUG_VER or not self.enablePrintStack then
    return
  end
  local ret = ""
  local level = 3
  ret = ret .. "stack traceback: \n"
  while true do
    local info = debug.getinfo(level, "Sln")
    if not info then
      break
    end
    if info.what == "C" then
      ret = ret .. tostring(level) .. "C function\n"
    else
      ret = ret .. string.format("%s:%d in `%s`\n", info.short_src, info.currentline, info.name or "")
    end
    level = level + 1
  end
  print(ret)
end
function Log:Traceback()
  gfLog("INF : " .. debug.traceback())
end
function Log:T(...)
  if ATM_IS_DEBUG_VER then
    print("trace : ", ...)
  end
end
Log:CF(os.time() - 259200)
return Log
