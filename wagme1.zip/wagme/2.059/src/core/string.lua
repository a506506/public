if string then
  function string.split(s, p)
    local rt = {}
    string.gsub(s, "[^" .. p .. "]+", function(w)
      table.insert(rt, w)
    end)
    return rt
  end
  function string.trim(s)
    return string.gsub(s, "^%s*(.-)%s*$", "%1")
  end
  function string.isNilOrEmpty(s)
    return nil == s or "" == s
  end
end
