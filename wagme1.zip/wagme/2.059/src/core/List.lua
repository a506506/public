local List = class("List")
function List:ctor()
  self.first = 1
  self.last = 0
end
function List:pushFront(value)
  local first = self.first - 1
  self.first = first
  self[first] = value
end
function List:pushBack(value)
  local last = self.last + 1
  self.last = last
  self[last] = value
end
function List:popFront()
  local first = self.first
  if first > self.last then
    error("List is empty")
  end
  local value = self[first]
  self[first] = nil
  self.first = first + 1
  if self:size() == 0 then
    self.first = 1
    self.last = 0
  end
  return value
end
function List:popBack()
  local last = self.last
  if last < self.first then
    error("List is empty")
  end
  local value = self[last]
  self[last] = nil
  self.last = last - 1
  if self:size() == 0 then
    self.first = 1
    self.last = 0
  end
  return value
end
function List:size()
  return self.last - self.first + 1
end
function List:get(idx)
  if idx < 1 or idx > self:size() then
    return nil
  end
  return self[self.first + idx - 1]
end
function List:removeSomeBySubkey(subkey, value)
  if type(self[self.first]) ~= "table" or self.first > self.last then
    return
  end
  local cou = 0
  for i = self.first, self.last do
    self[i - cou] = self[i]
    if self[i] and self[i][subkey] == value then
      cou = cou + 1
    end
  end
  self.last = self.last - cou
end
return List
