local Random = class("Random")
local RANDOM_MAX = 2147483647
function Random:ctor(seed)
  self._seed = seed or os.time()
end
function Random:seed(seed)
  self._seed = seed
end
function Random:random()
  local m = RANDOM_MAX
  local a = 9
  local b = 7
  self._seed = (a * self._seed + b) % m
  return self._seed / RANDOM_MAX
end
function Random:range(s, e)
  return math.floor(s + math.floor(self:random() * RANDOM_MAX + 0.5) % (e - s + 1))
end
return Random
