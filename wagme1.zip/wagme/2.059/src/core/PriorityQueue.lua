local PriorityQueue = class("PriorityQueue")
PriorityQueue.n = 0
function PriorityQueue.cmpFunc(x, y)
  return y < x
end
function PriorityQueue:ctor(cmp)
  self.n = 0
  if not cmp then
    Log:W("PriorityQueue: not cmp")
  else
    self.cmpFunc = cmp
  end
end
function PriorityQueue:up(i)
  local value = self[i]
  local j = math.floor(i / 2)
  while j >= 1 and self.cmpFunc(self[j], value) do
    self[i] = self[j]
    i = j
    if self.needFlagIndex then
      self[i].index = i
      do break end
      break
    end
    j = math.floor(j / 2)
  end
  self[i] = value
  if self.needFlagIndex then
    self[i].index = i
  end
end
function PriorityQueue:down(i)
  local value = self[i]
  local j = i * 2
  while j <= self.n do
    if j < self.n and self.cmpFunc(self[j], self[j + 1]) then
      j = j + 1
    end
    if not self.cmpFunc(self[j], value) then
      self[i] = self[j]
      i = j
      if self.needFlagIndex then
        self[i].index = i
      end
    else
      break
    end
    j = j * 2
  end
  self[i] = value
  if self.needFlagIndex then
    self[i].index = i
  end
end
function PriorityQueue:push(value)
  self.n = self.n + 1
  self[self.n] = value
  self:up(self.n)
end
function PriorityQueue:pop()
  if self.n == 0 then
    return
  end
  local value = self[1]
  self[1] = self[self.n]
  self.n = self.n - 1
  self:down(1)
  return value
end
function PriorityQueue:top()
  return self[1]
end
function PriorityQueue:size()
  return self.n
end
function PriorityQueue:setNeedFlagIndex(flag)
  self.needFlagIndex = flag
end
return PriorityQueue
