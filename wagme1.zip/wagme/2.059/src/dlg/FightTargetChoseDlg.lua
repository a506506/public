local FightTargetChoseDlg = Singleton("FightTargetChoseDlg", Dialog)
local PANEL_MAX_HEIGHT = 52.5
local TEXT_STATUS = {MINIUM = 1, MAXIUM = 2}
local textStatus
function FightTargetChoseDlg:init()
  self:setFullScreen()
  self:bindListener("ReturnButton", self.onReturnButton)
  self:bindListener("UpButton", self.onUpButton)
  self:bindListener("DownButton", self.onDownButton)
  self.hasHideFriendDlg = nil
  self.hasHideChannelDlg = nil
  self:hideChatDlg()
  if not textStatus then
    textStatus = TEXT_STATUS.MINIUM
  end
end
function FightTargetChoseDlg:setVisible(show)
  Dialog.setVisible(self, show)
  if show then
    self:hideChatDlg()
  else
    self:showChatDlg()
  end
end
function FightTargetChoseDlg:hideChatDlg()
  local dlg = DlgMgr:getDlgByName("FriendDlg")
  if dlg and not dlg:isOutsideWin() and dlg:isVisible() then
    dlg:setVisible(false)
    self.hasHideFriendDlg = true
    local sysMessageShowDlg = DlgMgr:getDlgByName("SystemMessageShowDlg")
    if sysMessageShowDlg then
      sysMessageShowDlg:setVisible(false)
    end
  end
  local dlg = DlgMgr:getDlgByName("ChannelDlg")
  if dlg and not dlg:isOutsideWin() and dlg:isVisible() then
    dlg:setVisible(false)
    self.hasHideChannelDlg = true
  end
end
function FightTargetChoseDlg:showChatDlg()
  if self.hasHideFriendDlg then
    DlgMgr:sendMsg("FriendDlg", "setVisible", true)
    self.hasHideFriendDlg = nil
    local sysMessageShowDlg = DlgMgr:getDlgByName("SystemMessageShowDlg")
    if sysMessageShowDlg then
      sysMessageShowDlg:setVisible(true)
    end
  end
  if self.hasHideChannelDlg then
    DlgMgr:sendMsg("ChannelDlg", "setVisible", true)
    self.hasHideChannelDlg = nil
  end
end
function FightTargetChoseDlg:cleanup()
  self:showChatDlg()
end
function FightTargetChoseDlg:onUpButton()
  textStatus = TEXT_STATUS.MAXIUM
  self:setTips(self.dlgData[1], self.dlgData[2])
end
function FightTargetChoseDlg:onDownButton()
  textStatus = TEXT_STATUS.MINIUM
  self:setTips(self.dlgData[1], self.dlgData[2])
end
function FightTargetChoseDlg:onReturnButton()
  if FightMgr.useFastSkill then
    if Me:queryBasicInt("c_attacking_id") == Me:getId() then
      local dlg = DlgMgr:showDlg("FightPlayerMenuDlg", true)
      if dlg then
        dlg:updateFastSkillButton()
      end
    else
      local dlg = DlgMgr:showDlg("FightPetMenuDlg", true)
      if dlg then
        dlg:updateFastSkillButton()
      end
    end
    Me.op = ME_OP.FIGHT_ATTACK
    self:setVisible(false)
    FightMgr.useFastSkill = false
    return
  end
  if Me.op == ME_OP.FIGHT_CATCH then
    local dlg = DlgMgr:showDlg("FightPlayerMenuDlg", true)
    if dlg then
      dlg:updateFastSkillButton()
    end
  elseif Me.op == ME_OP.FIGHT_SKILL or Me.op == ME_OP.FIGHT_ATTACK then
    local skillDlg = "FightPetSkillDlg"
    if Me:queryBasicInt("c_attacking_id") == Me:getId() then
      skillDlg = "FightPlayerSkillDlg"
    elseif HomeChildMgr:getFightKid() then
      skillDlg = "FightChildSkillDlg"
    end
    DlgMgr:showDlg(skillDlg, true)
  else
    if Me.op == ME_OP.FIGHTING_PROPERTY_ME then
      DlgMgr:showDlg("FightUseResDlg", true)
    else
    end
  end
  FightMgr.useFastSkill = false
  self:setVisible(false)
  Me.op = ME_OP.FIGHT_ATTACK
end
function FightTargetChoseDlg:updateUpDownButton(hide)
  if hide then
    self:setCtrlVisible("UpButton", false)
    self:setCtrlVisible("DownButton", false)
  elseif textStatus == TEXT_STATUS.MINIUM then
    self:setCtrlVisible("UpButton", true)
    self:setCtrlVisible("DownButton", false)
  else
    self:setCtrlVisible("UpButton", false)
    self:setCtrlVisible("DownButton", true)
  end
end
function FightTargetChoseDlg:getShowDesc()
  local showText = self.dlgData[2]
  local width = self:getControl("DescPanel", nil, "MainPanel"):getContentSize().width
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(20)
  textCtrl:setString(showText)
  textCtrl:setContentSize(width, 0)
  textCtrl:setDefaultColor(COLOR3.WHITE.r, COLOR3.WHITE.g, COLOR3.WHITE.b)
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  if textH > PANEL_MAX_HEIGHT then
    if textStatus == TEXT_STATUS.MINIUM then
      local textLenth, _ = gf:getTextLength(showText)
      local newText = showText
      for i = textLenth - 1, 1, -1 do
        newText = gf:getTextByLenth(showText, i)
        textCtrl:setString(newText)
        textCtrl:updateNow()
        local _, height = textCtrl:getRealSize()
        if height <= PANEL_MAX_HEIGHT then
          break
        end
      end
      showText = newText
    end
    self:updateUpDownButton()
  else
    self:updateUpDownButton(true)
  end
  return showText
end
function FightTargetChoseDlg:setTips(tips, cmdDesc)
  self.dlgData = {tips, cmdDesc}
  self:setLabelText("SkillNameLabel", tips, "MainPanel")
  if not cmdDesc then
    return
  end
  local descLen = string.len(cmdDesc)
  local mainPanel = self:getControl("MainPanel")
  local mainSize = mainPanel:getContentSize()
  local descPanel = self:getControl("DescPanel", nil, mainPanel)
  local size = descPanel:getContentSize()
  local width = 0
  if descLen < 30 then
    width = 162
  elseif descLen < 90 then
    width = 320
  else
    width = 430
  end
  descPanel:setContentSize(width, size.height)
  local showDesc = self:getShowDesc()
  local newH, oldH = self:setColorText(showDesc, descPanel, nil, nil, nil, COLOR3.WHITE, 20, LOCATE_POSITION.MID_BOTTOM)
  mainPanel:setContentSize(mainSize.width + width - size.width, mainSize.height + newH - oldH)
  self:getControl("BackImage", nil, mainPanel):setContentSize(mainPanel:getContentSize())
  self.root:requestDoLayout()
end
return FightTargetChoseDlg
