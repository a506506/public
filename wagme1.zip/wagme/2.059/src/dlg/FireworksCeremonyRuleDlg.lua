local FireworksCeremonyRuleDlg = Singleton("FireworksCeremonyRuleDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
function FireworksCeremonyRuleDlg:init()
  self.listPanel1 = self:retainCtrl("ListPanel01")
  self.listPanel2 = self:retainCtrl("ListPanel02")
  local listView = self:getControl("ListView")
  listView:addScrollViewEventListener(function(sender, eventType)
    self:updateArrow(sender, eventType)
  end)
  self.radioGroup = RadioGroup.new()
  self.radioGroup:setItemsByPanel(self, {
    "InfoPanel01",
    "InfoPanel02"
  }, self.onCheckBox)
  self.radioGroup:selectRadio(1)
  local NUMS = {
    10000,
    300,
    150,
    50,
    1,
    1
  }
  for i = 7, 12 do
    local panel = self:getControl(string.format("InfoPanel0%d", i), nil, self.listPanel1)
    local num = DistMgr:curIsTestDist() and math.ceil(NUMS[i - 6] / 20) or NUMS[i - 6]
    self:setLabelText("Label2", string.format(CHS[2300028], num), panel)
  end
end
function FireworksCeremonyRuleDlg:updateArrow(sender, eventType)
  if ccui.ScrollviewEventType.scrolling == eventType or ccui.ScrollviewEventType.scrollToTop == eventType or ccui.ScrollviewEventType.scrollToBottom == eventType then
    local scrollViewCtrl = sender
    local listInnerContent = scrollViewCtrl:getInnerContainer()
    local innerSize = listInnerContent:getContentSize()
    local scrollViewSize = scrollViewCtrl:getContentSize()
    local totalHeight = innerSize.height - scrollViewSize.height
    local innerPosY = listInnerContent:getPositionY()
    local persent = 1 - -innerPosY / totalHeight
    persent = math.floor(persent * 100)
    self:setCtrlVisible("DownArrowPanel", persent < 95)
    self:setCtrlVisible("UpArrowPanel", persent > 5)
  end
end
function FireworksCeremonyRuleDlg:onCheckBox(sender, idx)
  local num
  local listView = self:getControl("ListView")
  listView:removeAllItems()
  listView:setInnerContainerSize(cc.size(0, 0))
  if idx == 1 then
    listView:pushBackCustomItem(self.listPanel1)
  else
    listView:pushBackCustomItem(self.listPanel2)
  end
  listView:requestRefreshView()
  listView:doLayout()
  self:setCtrlVisible("DownArrowPanel", true)
  self:setCtrlVisible("UpArrowPanel", false)
end
return FireworksCeremonyRuleDlg
