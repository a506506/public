local CaseTWPaperDlg = Singleton("CaseTWPaperDlg", Dialog)
function CaseTWPaperDlg:init(param)
  self:setFullScreen()
  self:setLabelText("Label1", param, "MainPanel")
  self:setLabelText("Label2", param, "MainPanel")
end
return CaseTWPaperDlg
