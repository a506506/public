local ForeverCustomTitleSznDlg = Singleton("ForeverCustomTitleSznDlg", Dialog)
local MAX_LENTH = 12
local CUSTOM_TITLE_CFG = {
  [1] = {
    titleName = CHS[8000028],
    prefix = CHS[8000029],
    buttonName = CHS[8000030]
  },
  [4] = {
    titleName = CHS[8000031],
    prefix = CHS[8000032],
    buttonName = CHS[8000033]
  }
}
function ForeverCustomTitleSznDlg:init()
  self:bindListener("FreechangeButton", self.onExchangeButton)
  self.inputEditBox = self:createEditBox("EnterNamePanel", nil, nil, function(dlg, event, sender)
    if "ended" == event then
      local text = sender:getText()
      if gf:getTextLength(text) > MAX_LENTH then
        text = gf:subString(text, MAX_LENTH)
        sender:setText(text)
        gf:ShowSmallTips(CHS[7150594])
      end
      sender:setText(text)
    end
  end)
  self.inputEditBox:setPlaceholderFont(CHS[3002184], 23)
  self.inputEditBox:setFont(CHS[3002184], 23)
  self.inputEditBox:setFontColor(COLOR3.TEXT_DEFAULT)
  self.inputEditBox:setPlaceHolder(CHS[7150593])
  self.inputEditBox:setPlaceholderFontColor(COLOR3.GRAY)
  self:setCtrlVisible("FreechangeButton", true)
  self:setCtrlVisible("ExchangeButton", false)
end
function ForeverCustomTitleSznDlg:onDlgOpened(para)
  self.type = para[1]
  local cfg = CUSTOM_TITLE_CFG[tonumber(self.type)]
  self:setLabelText("TitleLabel_1", cfg.titleName)
  self:setLabelText("TitleLabel_2", cfg.titleName)
  self:setLabelText("BeforeTitleLabel", cfg.prefix)
  self:setLabelText("Label1", cfg.buttonName, "FreechangeButton")
  self:setLabelText("Label2", cfg.buttonName, "FreechangeButton")
end
function ForeverCustomTitleSznDlg:getCfgFileName()
  return ResMgr:getDlgCfg("ForeverCustomTitleDlg")
end
function ForeverCustomTitleSznDlg:onExchangeButton(sender, eventType)
  if self:checkSafeLockRelease("onExchangeButton") then
    return
  end
  local text = self.inputEditBox:getText()
  local _, fitStr = gf:filtTextEx(text, nil, nil, true)
  if fitStr then
    return
  end
  local cfg = CUSTOM_TITLE_CFG[tonumber(self.type)]
  _, fitStr = gf:filtTextByTwo(string.format("%s%s", cfg.prefix, text))
  if fitStr then
    return
  end
  gf:CmdToServer("CMD_CHANGE_CUSTOM_APPELLATION", {
    title = text,
    type = tonumber(self.type)
  })
end
return ForeverCustomTitleSznDlg
