local DaluandouppDlg = Singleton("DaluandouppDlg", Dialog)
local TIPS = {
  CHS[7100732],
  CHS[7100732] .. ".",
  CHS[7100732] .. "..",
  CHS[7100732] .. "..."
}
function DaluandouppDlg:init()
  self:setFullScreen()
  self:setCtrlFullClientEx("BKPanel_1")
  self:bindListener("OutButton", self.onOutButton)
  self:clearSchedule()
  local startTime = 1
  self.scheduleId = self:startSchedule(function()
    local index = startTime % 4
    if index == 0 then
      self:setLabelText("InfoLabel", TIPS[4])
    else
      self:setLabelText("InfoLabel", TIPS[index])
    end
    startTime = startTime + 1
  end, 0.2)
  self:hookMsg("MSG_ENTER_ROOM")
end
function DaluandouppDlg:clearSchedule()
  if self.scheduleId then
    self:stopSchedule(self.scheduleId)
    self.scheduleId = nil
  end
end
function DaluandouppDlg:onOutButton()
  gf:confirm(CHS[5420396], function()
    gf:CmdToServer("CMD_FFA_QUIT", {})
  end, nil, nil, nil, nil, nil, nil, "DaluandouppDlg")
end
function DaluandouppDlg:cleanup()
  self:clearSchedule()
  gf:closeConfirmByType("DaluandouppDlg")
end
function DaluandouppDlg:MSG_ENTER_ROOM()
  DlgMgr:closeDlg(self.name)
end
return DaluandouppDlg
