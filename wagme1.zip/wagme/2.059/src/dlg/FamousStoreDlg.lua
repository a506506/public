local FamousStoreDlg = Singleton("FamousStoreDlg", Dialog)
local PageTag = require("ctrl/PageTag")
local FOLLOW_SPRITE_OFFPOS = {
  [1] = cc.p(-40, -60),
  [3] = cc.p(40, -60),
  [5] = cc.p(-40, -60),
  [7] = cc.p(40, -60)
}
function FamousStoreDlg:init(data)
  self:bindListener("AddButton", self.onAddButton, "001_BtnSmallPanel")
  self:bindListener("ReduceButton", self.onReduceButton, "002_BtnSmallPanel")
  self:bindListener("CloseButton", self.onCloseButton)
  self:blindPress("AddButton", "001_BtnSmallPanel")
  self:blindPress("ReduceButton", "002_BtnSmallPanel")
  self:bindListener("Button", self.onBuyButton, "BuyButtonPanel")
  self:bindNumInput("GoodsQuantityPanel")
  self.item = self:retainCtrl("FamousGoodsPanel_1", "GoodsPanel")
  self.goodsPanel = self:retainCtrl("GoodsPanel")
  self.checkBox = self:retainCtrl("CheckBox", nil, "PageTagPanel")
  self:setLabelText("TitleLabel", CHS[7260049], "TitlePanel")
  self:setLabelText("ValueLabel", gf:getArtFontMoneyDesc(data.score), "FamousMoneyPanel")
  self.descPanel = self:retainCtrl("DescriptionPanel", nil, "GoodsAttribInfoPanel")
  self.havePageView = nil
  self.selectItem = 1
  self.checkBoxIdx = 1
  self.dir = 5
  self.itemInfos = data.goods
  self.sellListView = self:resetListView("ListView", nil, nil, "GoodsFamePanel")
  self:createPage()
  self:initGoodsInfo()
  self:updateGoodsShowPanel(1)
  self:setLabelText("TextBMFont", 1, "GoodsQuantityPanel")
  self:setLabelText("TextBMFont", self.itemInfos[self.selectItem].price, "MoneyLaluePanel")
  self:hookMsg("MSG_OPEN_MRT_EXCHANGE_SHOP")
end
function FamousStoreDlg:initGoodsInfo()
  self.sellListView:removeAllChildren()
  local count = #self.itemInfos
  local goodPanel = self.goodsPanel:clone()
  for i = 1, count do
    local item = self:setItemInfo(i, self.itemInfos)
    goodPanel:addChild(item)
    if i % 2 == 0 then
      self.sellListView:pushBackCustomItem(goodPanel)
      goodPanel = self.goodsPanel:clone()
    end
  end
  if count % 2 == 1 then
    self.sellListView:pushBackCustomItem(goodPanel)
  end
end
function FamousStoreDlg:setItemInfo(index, itemInfo)
  local item = self.item:clone()
  self:setImage("ItemImageView", ResMgr:getItemIconPath(InventoryMgr:getIconByName(itemInfo[index].name)), item)
  local showName = itemInfo[index].name
  if string.match(showName, "(.*)·") then
    showName = string.match(showName, "(.*)·")
  end
  self:setLabelText("ItemNameLabel", showName, item)
  local remainDays = string.match(itemInfo[index].name, CHS[7260051])
  if remainDays then
    self:setLabelText("RemainDaysLabel", remainDays, item)
  end
  self:setLabelText("ItemRemainNumLabel", itemInfo[index].left_count, item)
  if itemInfo[index].left_count == 0 then
    self:setCtrlVisible("ItemStatusImageView", true, item)
    self:setLabelText("ItemRemainNumLabel", 0, item, COLOR3.RED)
    self:setCtrlEnabled("ItemImageView", false, item)
  else
    self:setCtrlVisible("ItemStatusImageView", false, item)
    self:setCtrlEnabled("ItemImageView", true, item)
  end
  self:setLabelText("TextBMFont", gf:getArtFontMoneyDesc(itemInfo[index].price), item)
  local btn = self:getControl("NormalButton", nil, item)
  btn:setTag(index)
  if index == self.selectItem then
    self:setCtrlVisible("PressedPanel", true, item)
    self:selectedItem(btn)
  else
    self:setCtrlVisible("PressedPanel", false, item)
  end
  self:bindTouchEndEventListener(btn, self.onClickItem)
  return item
end
function FamousStoreDlg:onClickItem(sender)
  local curNum
  local oldSelected = self.selectItem
  self.selectItem = sender:getTag()
  if oldSelected == self.selectItem then
    curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
    curNum = tonumber(curNum)
    if curNum == 0 or curNum == nil then
      self:setLabelText("TextBMFont", 1, "GoodsQuantityPanel")
    else
      if not self:isCanAdd() then
        return
      end
      self:setLabelText("TextBMFont", curNum + 1, "GoodsQuantityPanel")
    end
  else
    self:setLabelText("TextBMFont", 1, "GoodsQuantityPanel")
  end
  curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
  curNum = tonumber(curNum)
  self:setMoneyLaluePanel(curNum * self.itemInfos[self.selectItem].price)
  self:selectedItem(sender)
end
function FamousStoreDlg:selectedItem(sender)
  local parentPanel = sender:getParent()
  for k, v in pairs(self.sellListView:getChildren()) do
    for k1, v1 in pairs(v:getChildren()) do
      self:setCtrlVisible("PressedPanel", false, v1)
    end
  end
  self.dir = 5
  self:setCtrlVisible("PressedPanel", true, parentPanel)
  self:updateGoodsShowPanel(sender:getTag())
end
function FamousStoreDlg:updateGoodsShowPanel(index)
  self:updateGoodsShowVisible(false)
  local curItem = self.itemInfos[self.selectItem]
  local remainTime = self:getLabelText("TimeLabel", "DescPanelOld")
  local itemInfo = InventoryMgr:getItemInfoByName(curItem.name)
  remainTime = string.gsub(remainTime, "30", curItem.deadline / 86400)
  self:setCtrlVisible("GoodsNameTitlePanel", true, "GoodsAttribInfoPanel")
  self:setLabelText("TitleLabel", curItem.name, "GoodsNameTitlePanel")
  if self:isFashion(curItem.name) or self:isEffect(curItem.name) or self:isFollowPet(curItem.name) then
    self:updateGoodsShowVisible(true)
    if self:isFashion(curItem.name) then
      self.curFashion = InventoryMgr:getFashionShapeIcon(curItem.name)
    else
      self.curFashion = curItem.name
    end
    self:setFashionAndDir(self.curFashion)
    self:setCtrlVisible("DescPanelOld", false, "GoodsAttribInfoPanel")
    self:setColorText(itemInfo.descript, "TextLabelPanel", "DescriptionPanel", nil, nil, cc.c3b(128, 89, 51), 16)
    self:setLabelText("TimeLabel", remainTime, "DescriptionPanel")
    self:initCheckBox(2, self.checkBoxIdx)
  else
    self:setCtrlVisible("DescPanelOld", true, "GoodsAttribInfoPanel")
    self:setCtrlVisible("DescriptionPanel", true, "GoodsAttribInfoPanel")
    self:setColorText(itemInfo.descript, "TextLabelPanel", "DescPanelOld", nil, nil, cc.c3b(128, 89, 51), 16)
    self:setLabelText("TimeLabel", remainTime, "DescPanelOld")
  end
  local curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
  curNum = tonumber(curNum)
  curNum = math.max(1, math.min(curNum, curItem.left_count))
  self:setLabelText("TextBMFont", curNum, "GoodsQuantityPanel")
  self:setMoneyLaluePanel(curNum * curItem.price)
end
function FamousStoreDlg:updateGoodsShowVisible(bool)
  local GoodsAttrib = self:getControl("GoodsAttribInfoPanel")
  for k, v in pairs(GoodsAttrib:getChildren()) do
    v:setVisible(bool)
  end
end
function FamousStoreDlg:onCloseButton()
  DlgMgr:sendMsg("FamousDlg", "changeTopyPanelStatus", true)
  DlgMgr:closeDlg(self.name)
end
function FamousStoreDlg:setFashionAndDir(iconId)
  local charAction
  local curItem = self.itemInfos[self.selectItem]
  if not curItem then
    return
  end
  if self:isFashion(curItem.name) then
    charAction = self:setPortrait("UserPanel", iconId, nil, "UserMainPanel", nil, nil, nil, nil, nil, nil, self.dir)
  else
    charAction = self:setPortrait("UserPanel", Me:getDlgIcon(true), Me:getDlgWeaponIcon(true), "UserMainPanel", nil, nil, nil, nil, Me:queryBasicInt("icon"), nil, self.dir, nil, nil, Me:getDlgPartIndex(true), Me:getDlgPartColorIndex(true))
  end
  local userPanel = self:getControl("UserPanel", nil, "UserMainPanel")
  if userPanel.magic then
    userPanel.magic:removeFromParent()
    userPanel.magic = nil
  end
  if userPanel.followPet then
    userPanel.followPet:removeFromParent()
    userPanel.followPet = nil
  end
  if self:isFollowPet(curItem.name) then
    local petIcon = 50215
    userPanel.followPet = self:setPortrait("UserPanel", petIcon, 0, "UserMainPanel", nil, nil, nil, FOLLOW_SPRITE_OFFPOS[self.dir], nil, nil, self.dir, Dialog.TAG_PORTRAIT1)
    local acts = gf:getAllActionByIcon(petIcon, {
      [Const.SA_STAND] = true,
      [Const.SA_DIE] = true
    })
    self:displayPlayActions("UserPanel", "UserMainPanel", FOLLOW_SPRITE_OFFPOS[self.dir], Dialog.TAG_PORTRAIT1, acts)
  elseif self:isEffect(curItem.name) then
    local lightEffects = require("cfg/LightEffect")
    local magicIcon = 1375
    local magicCfg = lightEffects[magicIcon]
    local size = userPanel:getContentSize()
    local pos = cc.p(charAction:getPosition())
    local x, y = charAction:getWaistOffset()
    pos = cc.p(pos.x + x, pos.y + y)
    userPanel.magic = gf:createLoopMagic(magicIcon, nil, magicCfg.extraPara)
    userPanel.magic:setPosition(pos)
    userPanel:addChild(userPanel.magic, magicCfg.behind and -1 or 1, magicIcon)
  end
  self:displayPlayActions("UserPanel", "UserMainPanel", -36)
end
function FamousStoreDlg:onRightButton()
  self.dir = self.dir + 2
  if self.dir > 7 then
    self.dir = 1
  end
  if self.curFashion then
    self:setFashionAndDir(self.curFashion)
  end
end
function FamousStoreDlg:onLeftButton()
  self.dir = self.dir - 2
  if self.dir < 0 then
    self.dir = 7
  end
  if self.curFashion then
    self:setFashionAndDir(self.curFashion)
  end
end
function FamousStoreDlg:createPage()
  if self.havePageView then
    return
  end
  local pageView = self:getControl("PageView", Const.UIPageView, "GoodsAttribInfoPanel")
  pageView:setMoveDistanceToChangePage(128)
  pageView:setTouchEnabled(true)
  pageView:stopAllActions()
  pageView:removeAllPages()
  local fashionPanel = self:getControl("FashionShapePanel", nil, "GoodsAttribInfoPanel")
  self:bindListener("RightButton", self.onRightButton, fashionPanel)
  self:bindListener("LeftButton", self.onLeftButton, fashionPanel)
  local descPanelOld = self.descPanel:clone()
  descPanelOld:setName("DescPanelOld")
  local GoodsAttrib = self:getControl("GoodsAttribInfoPanel")
  GoodsAttrib:addChild(descPanelOld)
  local descPanel = self.descPanel:clone()
  fashionPanel:removeFromParent()
  descPanel:removeFromParent()
  pageView:addPage(fashionPanel)
  pageView:addPage(descPanel)
  pageView:setVisible(false)
  pageView:addEventListener(function(sender, eventType)
    local index = pageView:getCurPageIndex()
    self.checkBoxIdx = index + 1
    self:initCheckBox(2, index + 1)
  end)
  self.havePageView = 1
  return pageView
end
function FamousStoreDlg:initCheckBox(count, index)
  local pageTagPanel = self:getControl("PageTagPanel", nil, "GoodsAttribInfoPanel")
  pageTagPanel:removeAllChildren()
  local curCount = 2
  if count then
    curCount = count
  end
  for i = 1, curCount do
    local checkBox = self.checkBox:clone()
    local iniPos = checkBox:getPositionX() - (count - 1) * 12
    checkBox:setPositionX(iniPos + (i - 1) * 24)
    checkBox:setSelectedState(false)
    checkBox:setTouchEnabled(false)
    if index and index == i then
      checkBox:setSelectedState(true)
    end
    pageTagPanel:addChild(checkBox)
  end
end
function FamousStoreDlg:onAddButton()
  local curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
  curNum = tonumber(curNum)
  if not self:isCanAdd() then
    return
  end
  self:setLabelText("TextBMFont", curNum + 1, "GoodsQuantityPanel")
  self:setMoneyLaluePanel((curNum + 1) * self.itemInfos[self.selectItem].price)
end
function FamousStoreDlg:onReduceButton()
  local curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
  curNum = tonumber(curNum)
  if 1 <= curNum - 1 then
    self:setLabelText("TextBMFont", curNum - 1, "GoodsQuantityPanel")
    self:setMoneyLaluePanel((curNum - 1) * self.itemInfos[self.selectItem].price)
  else
    gf:ShowSmallTips(CHS[4000206])
    return
  end
end
function FamousStoreDlg:onBuyButton()
  local curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
  curNum = tonumber(curNum)
  local curMoney = self:getLabelText("ValueLabel", "FamousMoneyPanel")
  curMoney = string.gsub(curMoney, ",", "")
  curMoney = tonumber(curMoney)
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  elseif tonumber(curNum) < 1 then
    gf:ShowSmallTips(CHS[4000206])
    return
  elseif curNum > self.itemInfos[self.selectItem].left_count then
    gf:ShowSmallTips(CHS[4200308])
    return
  elseif curNum > 10 then
    gf:ShowSmallTips(CHS[6000035])
    return
  elseif curMoney < self.itemInfos[self.selectItem].price * curNum then
    gf:ShowSmallTips(CHS[7260041])
    return
  elseif self:checkSafeLockRelease("onBuyButton") then
    return
  end
  gf:CmdToServer("CMD_EXCHANGE_GOODS", {
    type = 5,
    name = self.itemInfos[self.selectItem].name,
    amount = curNum
  })
end
function FamousStoreDlg:isCanAdd(num)
  local bagLimit = InventoryMgr:isCanAddToBag(self.itemInfos[self.selectItem].name, 100000)
  if bagLimit == 0 then
    gf:ShowSmallTips(CHS[4200300])
    return false
  end
  local curNum
  if num then
    curNum = num
  else
    curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
  end
  curNum = tonumber(curNum)
  local curMoney = self:getLabelText("ValueLabel", "FamousMoneyPanel")
  curMoney = string.gsub(curMoney, ",", "")
  curMoney = tonumber(curMoney)
  local needMoney = self:getLabelText("TextBMFont", "MoneyLaluePanel")
  needMoney = string.gsub(needMoney, ",", "")
  needMoney = tonumber(needMoney)
  if curNum + 1 > self.itemInfos[self.selectItem].left_count then
    gf:ShowSmallTips(CHS[4200308])
    return false
  elseif curNum + 1 > 10 then
    gf:ShowSmallTips(CHS[6000035])
    return false
  elseif curMoney < needMoney + self.itemInfos[self.selectItem].price then
    gf:ShowSmallTips(CHS[7260041])
    return false
  end
  return true
end
function FamousStoreDlg:blindPress(name, curRoot)
  local widget = self:getControl(name, nil, curRoot)
  if not widget then
    Log:W("Dialog:bindListViewListener no control " .. name)
    return
  end
  local function updataCount(longClick)
    if self.touchStatus == TOUCH_BEGAN then
      if self.clickBtn == "AddButton" then
        self:onAddButton(longClick)
      elseif self.clickBtn == "ReduceButton" then
        self:onReduceButton(longClick)
      end
    elseif self.touchStatus == TOUCH_END then
    end
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.began then
      self.clickBtn = sender:getName()
      self.touchStatus = TOUCH_BEGAN
      schedule(widget, function()
        updataCount(true)
      end, 0.1)
    elseif eventType == ccui.TouchEventType.moved then
    else
      updataCount()
      self.touchStatus = TOUCH_END
      widget:stopAllActions()
    end
  end
  widget:addTouchEventListener(listener)
end
function FamousStoreDlg:setMoneyLaluePanel(num)
  self:setLabelText("TextBMFont", num, "MoneyLaluePanel")
  local curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
  curNum = tonumber(curNum)
  local curValue = self:getLabelText("TextBMFont", "MoneyLaluePanel")
  local oldValue = curValue
  oldValue = tonumber(oldValue)
  curValue = gf:getArtFontMoneyDesc(oldValue)
  local curMoney = self:getLabelText("ValueLabel", "FamousMoneyPanel")
  curMoney = string.gsub(curMoney, ",", "")
  curMoney = tonumber(curMoney)
  if curMoney < tonumber(self.itemInfos[self.selectItem].price * curNum) then
    self:setLabelText("TextBMFont", curValue, "MoneyLaluePanel", cc.c3b(204, 51, 21))
  else
    self:setLabelText("TextBMFont", curValue, "MoneyLaluePanel", COLOR3.WHITE)
  end
end
function FamousStoreDlg:insertNumber(num)
  local curItem = self.itemInfos[self.selectItem]
  if curItem.left_count == 0 then
    gf:ShowSmallTips(CHS[4200308])
    return
  end
  local bagLimit = InventoryMgr:isCanAddToBag(curItem.name, 100000)
  if bagLimit < curItem.left_count and num > bagLimit then
    num = bagLimit
    if num > 10 then
      num = 10
    end
    gf:ShowSmallTips(CHS[7250013])
    return
  end
  curNum = self:getLabelText("TextBMFont", "GoodsQuantityPanel")
  curNum = tonumber(curNum)
  local curMoney = self:getLabelText("ValueLabel", "FamousMoneyPanel")
  curMoney = string.gsub(curMoney, ",", "")
  curMoney = tonumber(curMoney)
  local needMoney = self:getLabelText("TextBMFont", "MoneyLaluePanel")
  needMoney = string.gsub(needMoney, ",", "")
  needMoney = tonumber(needMoney)
  local tips = ""
  if num > curItem.left_count then
    tips = CHS[4200308]
    num = curItem.left_count
  end
  if num > 10 then
    tips = CHS[6000035]
    num = 10
  end
  if curMoney < num * self.itemInfos[self.selectItem].price then
    tips = CHS[7260041]
    num = math.floor(curMoney / curItem.price)
  end
  if num < 1 then
    tips = CHS[4000206]
    num = 1
  end
  if tips ~= "" then
    gf:ShowSmallTips(tips)
  end
  local dlg = DlgMgr.dlgs.SmallNumInputDlg
  if dlg then
    dlg:setInputValue(num)
  end
  self:setLabelText("TextBMFont", num, "GoodsQuantityPanel")
  self:setMoneyLaluePanel(num * curItem.price)
  return
end
function FamousStoreDlg:isFashion(name)
  local itemInfo = InventoryMgr:getItemInfoByName(name)
  if itemInfo and itemInfo.item_class == ITEM_CLASS.FASHION then
    return true
  end
end
function FamousStoreDlg:isEffect(name)
  if string.match(name, CHS[7120370]) then
    return true
  end
end
function FamousStoreDlg:isFollowPet(name)
  if string.match(name, CHS[4200898]) then
    return true
  end
end
function FamousStoreDlg:MSG_OPEN_MRT_EXCHANGE_SHOP(data)
  if DlgMgr:getDlgByName("FamousStoreDlg") then
    self.itemInfos = data.goods
    self:setLabelText("ValueLabel", gf:getArtFontMoneyDesc(data.score), "FamousMoneyPanel")
    self:initGoodsInfo()
    self:setMoneyLaluePanel(self.itemInfos[self.selectItem].price)
  end
end
return FamousStoreDlg
