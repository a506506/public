local DaluandouscxqDlg = Singleton("DaluandouscxqDlg", Dialog)
local RANK_CHAR_ACTION_SCALE = {
  0.74,
  0.86,
  1
}
function DaluandouscxqDlg:init()
  self.starSelectImage = self:retainCtrl("SelectImage", nil, "XingPanel")
  for i = 1, 3 do
    self:getControl("Button" .. i).starType = i
    self:bindListener("Button" .. i, self.onStarButton)
  end
  self:bindListener("LeftButton", self.onLeftButton)
  self:bindListener("RightButton", self.onRightButton)
end
function DaluandouscxqDlg:setData(data)
  self.retinueName = data.name
  self:refreshLeftAndRightButton()
  local cfg = UndergroundMgr:getRetinueCfg(self.retinueName)
  self:setPortrait("ModelPanel", cfg.icon)
  if cfg.color == 1 then
    self:setLabelText("NameLabel", cfg.name, nil, COLOR3.BLUE)
  elseif cfg.color == 2 then
    self:setLabelText("NameLabel", cfg.name, nil, COLOR3.PURPLE)
  elseif cfg.color == 3 then
    self:setLabelText("NameLabel", cfg.name, nil, COLOR3.YELLOW)
  end
  local typeDes, polarDes, fightDes = UndergroundMgr:getRetinueDesChs(cfg.type, cfg.polar, cfg.fightType)
  self:setImage("RaceImage", ResMgr:getRetinueTypeTag(cfg.type))
  self:setLabelText("RaceLabel", typeDes)
  self:setImage("PolarImage", ResMgr:getRetinuePolarTag(cfg.polar))
  self:setLabelText("PolarLabel", polarDes)
  self:setImage("TypeImage", ResMgr:getRetinueAttackTag(cfg.fightType))
  self:setLabelText("TypeLabel", fightDes)
  self:setLabelText("Label1", cfg.effect1, "EffectPanel")
  self:setLabelText("Label2", cfg.effect2, "EffectPanel")
  local skillPanel = self:getControl("SkillPanel")
  UndergroundMgr:setRetinueSkillInfo(self, "SkillPanel1", skillPanel)
  UndergroundMgr:setRetinueSkillInfo(self, "SkillPanel2", skillPanel, cfg.skillList[1], cfg.polar)
  UndergroundMgr:setRetinueSkillInfo(self, "SkillPanel3", skillPanel, cfg.skillList[2], cfg.polar)
  self:setLabelText("NumLabel", data.life, "LifePanel")
  self:setLabelText("NumLabel", data.mana, "ManaPanel")
  self:setLabelText("NumLabel", data.phy, "PhyPowerPanel")
  self:setLabelText("NumLabel", data.mag, "MagPowerPanel")
  self:setLabelText("NumLabel", data.speed, "SpeedPanel")
  self:setLabelText("NumLabel", data.defence, "DefencePanel")
  if not self.starType then
    self.starType = 1
    self:getControl("ModelPanel"):setScale(RANK_CHAR_ACTION_SCALE[self.starType])
    self:onStarButton(self:getControl("Button1"))
  end
end
function DaluandouscxqDlg:refreshLeftAndRightButton()
  local lastName, _, nextName = DlgMgr:sendMsg("DaluandoutjDlg", "getRetinueByName", self.retinueName)
  if lastName then
    self:setCtrlVisible("LeftButton", true)
  else
    self:setCtrlVisible("LeftButton", false)
  end
  if nextName then
    self:setCtrlVisible("RightButton", true)
  else
    self:setCtrlVisible("RightButton", false)
  end
end
function DaluandouscxqDlg:onStarButton(sender, eventType)
  if self.starSelectImage:getParent() then
    self.starSelectImage:removeFromParent()
  end
  sender:addChild(self.starSelectImage)
  local sz = sender:getContentSize()
  self.starSelectImage:setPosition(sz.width / 2, sz.height / 2)
  if not self.starType or self.starType ~= sender.starType then
    self.starType = sender.starType
    self:getControl("ModelPanel"):setScale(RANK_CHAR_ACTION_SCALE[self.starType])
    UndergroundMgr:requestRetinueInfo(string.format("%s:%d", self.retinueName, self.starType))
  end
end
function DaluandouscxqDlg:cleanup()
  self.starType = nil
end
function DaluandouscxqDlg:onLeftButton(sender, eventType)
  local lastName, _, nextName = DlgMgr:sendMsg("DaluandoutjDlg", "getRetinueByName", self.retinueName)
  if lastName then
    UndergroundMgr:requestRetinueInfo(string.format("%s:%d", lastName, self.starType))
  end
end
function DaluandouscxqDlg:onRightButton(sender, eventType)
  local lastName, _, nextName = DlgMgr:sendMsg("DaluandoutjDlg", "getRetinueByName", self.retinueName)
  if nextName then
    UndergroundMgr:requestRetinueInfo(string.format("%s:%d", nextName, self.starType))
  end
end
return DaluandouscxqDlg
