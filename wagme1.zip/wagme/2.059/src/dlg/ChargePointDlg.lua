local ChargePointDlg = Singleton("ChargePointDlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
local itemPanels = {}
function ChargePointDlg:init()
  self:bindListener("AddButton", self.onAddButton)
  self:bindListener("InfoButton", self.onInfoButton)
  self.listUnitPanel = self:getControl("ListUnitMidPanel1")
  self.listUnitPanel:retain()
  self.listUnitPanel:removeFromParent()
  self:bindTouchEndEventListener(self.listUnitPanel, self.onBuyItem)
  self:blindLongPress("ItemPanel", self.onShowItemInfo, self.onBuyItem, self.listUnitPanel)
  self:bindInfoPanel("InfoPanel")
  self:bindInfoPanel("InfoPanel2")
  self.type = GiftMgr:getPointWelfareType()
  if self.type == "charge" then
    self.chargePointInfo = GiftMgr.chargePointInfo or {}
    if next(self.chargePointInfo) then
      self:initData(self.chargePointInfo)
      self:initScrollView(self.chargePointInfo)
    end
    GiftMgr:requestChargePointInfo()
  elseif self.type == "consume" then
    self.consumePointInfo = GiftMgr.consumePointInfo or {}
    if next(self.consumePointInfo) then
      self:initData(self.consumePointInfo)
      self:initScrollView(self.consumePointInfo)
    end
    GiftMgr:requestConsumePointInfo()
  end
  self.curGoldNum = Me:queryInt("gold_coin")
  self:hookMsg("MSG_RECHARGE_SCORE_GOODS_LIST")
  self:hookMsg("MSG_RECHARGE_SCORE_GOODS_INFO")
  self:hookMsg("MSG_CONSUME_SCORE_GOODS_LIST")
  self:hookMsg("MSG_CONSUME_SCORE_GOODS_INFO")
  self:hookMsg("MSG_UPDATE")
  self:showUI()
end
function ChargePointDlg:showUI()
  self:setCtrlVisible("InfoLabelPanel1", self.type == "charge")
  self:setCtrlVisible("InfoLabelPanel2", self.type == "consume")
end
function ChargePointDlg:initData(data)
  local mainPanel
  if self.type == "charge" then
    mainPanel = "InfoPanel"
  elseif self.type == "consume" then
    mainPanel = "InfoPanel2"
  end
  self:setLabelText("Label2", data.totalPoint .. "/3000", self:getControl("TotalPointPanel", nil, mainPanel))
  local curTime = gf:getServerTime()
  if curTime < data.endTime then
    local startTimeStr = gf:getServerDate(CHS[5420147], tonumber(data.startTime))
    local endTimeStr = gf:getServerDate(CHS[5420147], tonumber(data.endTime))
    self:setLabelText("TitleLabel", CHS[5420137] .. startTimeStr .. " - " .. endTimeStr)
    self:setCtrlVisible("AddButton", true)
    self:setCtrlVisible("PointValuePanel", true, "PointPanel")
    self:setCtrlVisible("PointValuePanel2", false, "PointPanel")
    local pointDesc = gf:getArtFontMoneyDesc(data.ownPoint, true)
    self:setNumImgForPanel("PointValuePanel", ART_FONT_COLOR.DEFAULT, pointDesc, false, LOCATE_POSITION.MID, 23, "PointPanel")
  else
    local deadlineStr = gf:getServerDate(CHS[5420147], tonumber(data.deadline))
    self:setLabelText("TitleLabel", CHS[5420138] .. deadlineStr .. " " .. CHS[5420133])
    for i = 1, 2 do
      local mainPanel = self:getControl("InfoLabelPanel" .. i)
      self:setCtrlVisible("InfoLabel1", false, mainPanel)
      self:setCtrlVisible("InfoLabel2", false, mainPanel)
      self:setCtrlVisible("InfoLabel3", false, mainPanel)
      self:setCtrlVisible("InfoLabel4", true, mainPanel)
    end
    self:setCtrlVisible("AddButton", false)
    self:setCtrlVisible("PointValuePanel", false, "PointPanel")
    self:setCtrlVisible("PointValuePanel2", true, "PointPanel")
    local pointDesc = gf:getArtFontMoneyDesc(data.ownPoint, true)
    self:setNumImgForPanel("PointValuePanel2", ART_FONT_COLOR.DEFAULT, pointDesc, false, LOCATE_POSITION.MID, 23, "PointPanel")
  end
end
function ChargePointDlg:initScrollView(data)
  self.scrollView = self:getControl("ItemListScrollView")
  self:initScrollViewPanel(data, self.listUnitPanel, self.setItemInfo, self.scrollView, 4, 0, 0)
end
function ChargePointDlg:onAddButton(sender, eventType)
  if self.type == "charge" then
    OnlineMallMgr:openOnlineMall("OnlineRechargeDlg")
  elseif self.type == "consume" then
    OnlineMallMgr:openOnlineMall("OnlineMallDlg")
  end
end
function ChargePointDlg:onInfoButton(sender, eventType)
  self:setCtrlVisible("InfoPanel", self.type == "charge")
  self:setCtrlVisible("InfoPanel2", self.type == "consume")
end
function ChargePointDlg:onBuyItem(sender, eventType)
  local info
  if self.type == "charge" then
    info = self.chargePointInfo
  elseif self.type == "consume" then
    info = self.consumePointInfo
  end
  local curTime = gf:getServerTime()
  if curTime > info.deadline then
    gf:ShowSmallTips(CHS[5420148])
    ChatMgr:sendMiscMsg(CHS[5420148])
    DlgMgr:closeDlg("ChargePointDlg")
    return
  end
  local tag = sender:getTag()
  local itemInfo = info[tag]
  if not itemInfo then
    local unitPanel = sender:getParent()
    local unitMidPanel = unitPanel:getParent()
    tag = unitMidPanel:getTag()
    itemInfo = info[tag]
  end
  if itemInfo.num == 0 then
    gf:ShowSmallTips(CHS[5420135])
    return
  end
  self.selectTag = tag
  local dlg = DlgMgr:openDlg("ChargePointBuyItemDlg")
  dlg:setData(itemInfo, info.ownPoint, info.deadline)
end
function ChargePointDlg:onShowItemInfo(sender, eventType)
  RewardContainer:imagePanelTouch(sender, 2)
end
function ChargePointDlg:setItemInfo(cell, data)
  local itemPanel = self:getControl("ItemPanel", nil, cell)
  local classList = TaskMgr:getRewardList(data.rewardStr)
  itemPanels[cell:getTag()] = cell
  local reward
  if #classList > 0 and classList[1] and classList[1][1] then
    reward = classList[1][1]
    data.reward = reward
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
    data.name = RewardContainer:getTextList(reward)[1]
    data.level = item.level
    data.limted = item.limted
    data.type = reward[1]
    data.deadline = item.deadline
    data.alias = item.alias
    data.limit_use_time = item.alias
  end
  itemPanel.reward = reward
  local imgPath, textureResType = RewardContainer:getRewardPath(reward)
  if textureResType == ccui.TextureResType.plistType then
    self:setImagePlist("IconImage", imgPath, cell)
  else
    self:setImage("IconImage", imgPath, cell)
  end
  local img = self:getControl("IconImage", nil, cell)
  if data.deadline then
    InventoryMgr:addLogoTimeLimit(img)
  elseif data.limted then
    InventoryMgr:addLogoBinding(img)
  end
  if data.level and 1 < tonumber(data.level) then
    self:setNumImgForPanel(img, ART_FONT_COLOR.NORMAL_TEXT, tonumber(data.level), false, LOCATE_POSITION.LEFT_TOP, 19, cell)
  end
  data.imgPath = imgPath
  data.textureResType = textureResType
  local num = data.num
  self:setLabelText("NumLabel", CHS[3003274] .. " " .. num, cell)
  if num <= 0 then
    self:setCtrlVisible("SellOutImage", true, cell)
    gf:grayImageView(img)
  else
    self:setCtrlVisible("SellOutImage", false, cell)
    gf:resetImageView(img)
  end
  local pointDesc = gf:getArtFontMoneyDesc(data.point, true)
  self:setNumImgForPanel("PointValuePanel", ART_FONT_COLOR.DEFAULT, pointDesc, false, LOCATE_POSITION.MID, 23, cell)
end
function ChargePointDlg:bindInfoPanel(panelName)
  local panel = self:getControl(panelName)
  local function onTouchBegan(touch, event)
    if not panel:isVisible() then
      return false
    end
    return true
  end
  local onTouchMove = function(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
  end
  local function onTouchEnd(touch, event)
    panel:setVisible(false)
  end
  local listener = cc.EventListenerTouchOneByOne:create()
  listener:setSwallowTouches(true)
  listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
  listener:registerScriptHandler(onTouchMove, cc.Handler.EVENT_TOUCH_MOVED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_ENDED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_CANCELLED)
  local dispatcher = panel:getEventDispatcher()
  dispatcher:addEventListenerWithSceneGraphPriority(listener, panel)
end
function ChargePointDlg:MSG_RECHARGE_SCORE_GOODS_LIST(data)
  if self.chargePointInfo and next(self.chargePointInfo) then
    self:initData(data)
    for i = 1, data.count do
      local cell = itemPanels[i]
      self:setItemInfo(cell, data[i])
    end
  else
    self:initData(data)
    self:initScrollView(data)
  end
  self.chargePointInfo = data
end
function ChargePointDlg:MSG_RECHARGE_SCORE_GOODS_INFO(data)
  self.chargePointInfo.ownPoint = data.ownPoint
  self.chargePointInfo[data.no] = data
  local cell = itemPanels[data.no]
  self:setItemInfo(cell, data)
  local pointDesc = gf:getArtFontMoneyDesc(data.ownPoint, true)
  self:setNumImgForPanel("PointValuePanel", ART_FONT_COLOR.DEFAULT, pointDesc, false, LOCATE_POSITION.MID, 23, "PointPanel")
  self:setNumImgForPanel("PointValuePanel2", ART_FONT_COLOR.DEFAULT, pointDesc, false, LOCATE_POSITION.MID, 23, "PointPanel")
end
function ChargePointDlg:MSG_CONSUME_SCORE_GOODS_LIST(data)
  if self.consumePointInfo and next(self.consumePointInfo) then
    self:initData(data)
    for i = 1, data.count do
      local cell = itemPanels[i]
      self:setItemInfo(cell, data[i])
    end
  else
    self:initData(data)
    self:initScrollView(data)
  end
  self.consumePointInfo = data
end
function ChargePointDlg:MSG_CONSUME_SCORE_GOODS_INFO(data)
  self.consumePointInfo.ownPoint = data.ownPoint
  self.consumePointInfo[data.no] = data
  local cell = itemPanels[data.no]
  self:setItemInfo(cell, data)
  local pointDesc = gf:getArtFontMoneyDesc(data.ownPoint, true)
  self:setNumImgForPanel("PointValuePanel", ART_FONT_COLOR.DEFAULT, pointDesc, false, LOCATE_POSITION.MID, 23, "PointPanel")
  self:setNumImgForPanel("PointValuePanel2", ART_FONT_COLOR.DEFAULT, pointDesc, false, LOCATE_POSITION.MID, 23, "PointPanel")
end
function ChargePointDlg:MSG_UPDATE(data)
  if data.gold_coin and data.gold_coin > self.curGoldNum then
    self.curGoldNum = data.gold_coin
    GiftMgr:requestChargePointInfo()
  elseif data.gold_coin and data.gold_coin < self.curGoldNum then
    self.curGoldNum = data.gold_coin
    GiftMgr:requestConsumePointInfo()
  end
end
function ChargePointDlg:cleanup()
  self:releaseCloneCtrl("listUnitPanel")
  self.chargePointInfo = {}
end
return ChargePointDlg
