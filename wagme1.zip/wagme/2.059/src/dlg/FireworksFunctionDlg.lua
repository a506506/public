local FireworksFunctionDlg = Singleton("FireworksFunctionDlg", Dialog)
local ITEMS = {
  CHS[5410475],
  CHS[5410476],
  CHS[5410477],
  CHS[5410478]
}
function FireworksFunctionDlg:init()
  self:setFullScreen()
  for i = 1, 4 do
    local cell = self:getControl(string.format("ItemPanel_%d", i))
    self:setImage("ItemImage", ResMgr:getIconPathByName(ITEMS[i]), cell)
    cell.itemName = ITEMS[i]
  end
  GameMgr:hideAllUI(nil, {ChatDlg = true})
  DlgMgr:sendMsg("FireworksMainDlg", "onCloseButton2")
  self.lastUse = nil
  self:updateItem()
  self:hookMsg("MSG_FIREWORKS_PARTY_INFO")
end
function FireworksFunctionDlg:updateItem()
  local totalNum = 0
  for i = 1, 4 do
    do
      local cell = self:getControl(string.format("ItemPanel_%d", i))
      local amount = InventoryMgr:getAmountByName(cell.itemName)
      local img = self:getControl("ItemImage", nil, cell)
      if amount > 1 then
        self:setNumImgForPanel("NumPanel", ART_FONT_COLOR.DEFAULT, amount, false, LOCATE_POSITION.RIGHT_BOTTOM, 21, cell, nil, 7, -10)
      else
        self:removeNumImgForPanel("NumPanel", LOCATE_POSITION.RIGHT_BOTTOM, cell)
      end
      if amount > 0 then
        gf:resetImageView(img)
      else
        gf:grayImageView(img)
      end
      totalNum = totalNum + amount
      self:blindLongPress("ItemPanel", function(dlg, sender)
        local rect = self:getBoundingBoxInWorldSpace(sender)
        InventoryMgr:showBasicMessageDlg(cell.itemName, rect)
      end, function(dlg, sender)
        if sender.countdown == 1 then
          gf:ShowSmallTips(CHS[5420448])
          return
        end
        local amount = InventoryMgr:getAmountByName(cell.itemName)
        if amount == 0 and cell.itemName == CHS[5410478] then
          local data = ActivityHelperMgr.fireworksData
          if not data then
            self:onCloseButton()
            return
          end
          local time = gf:getServerTime()
          if time < data.shoot_start_time or time > data.shoot_end_time then
            gf:ShowSmallTips(CHS[5410481])
            return
          end
          local dlg = DlgMgr:openDlg("GetTaoBuyDlg")
          dlg:setInfoByType("fireworks")
        else
          if Me:isInJail() then
            gf:ShowSmallTips(CHS[5000228])
            return
          end
          if GameMgr.inCombat then
            gf:ShowSmallTips(CHS[4000223])
            return
          end
          if Me:isLookOn() then
            gf:ShowSmallTips(CHS[5420353])
            return
          end
          if PlayActionsMgr:isPlayLiHua() then
            gf:ShowSmallTips(CHS[5420354])
            return
          end
          if amount == 0 then
            gf:ShowSmallTips(CHS[5420447])
            return
          end
          local pos = InventoryMgr:getItemPosByName(cell.itemName)
          InventoryMgr:applyItem(pos, 1)
          self.lastUse = {
            cell.itemName,
            amount,
            i
          }
        end
      end, cell)
    end
  end
end
function FireworksFunctionDlg:playCountDown(index)
  local panel = self:getControl(string.format("ItemPanel_%d", index))
  local itemPanel = self:getControl("ItemPanel", nil, panel)
  itemPanel:removeChildByTag(999)
  itemPanel:stopAllActions()
  local progressTimer = cc.ProgressTimer:create(cc.Sprite:create(ResMgr.ui.ore_progress_timer))
  progressTimer:setReverseDirection(true)
  progressTimer:setTag(999)
  itemPanel:addChild(progressTimer)
  local contentSize = itemPanel:getContentSize()
  progressTimer:setPosition(contentSize.width / 2, contentSize.height / 2)
  progressTimer:setPercentage(100)
  local progressTo = cc.ProgressTo:create(5, 0)
  local endAction = cc.CallFunc:create(function()
    progressTimer:removeFromParent()
  end)
  progressTimer:runAction(cc.Sequence:create(progressTo, endAction))
  local sec = 5
  self:setCtrlVisible("TimePanel", true, panel)
  self:setNumImgForPanel("TimePanel", ART_FONT_COLOR.NORMAL_TEXT, sec, false, LOCATE_POSITION.MID, COUNT_DOWN_FONT_SIZE, itemPanel)
  itemPanel.countdown = 1
  schedule(panel, function()
    sec = sec - 1
    if sec > 0 then
      self:setNumImgForPanel("TimePanel", ART_FONT_COLOR.NORMAL_TEXT, sec, false, LOCATE_POSITION.MID, COUNT_DOWN_FONT_SIZE, itemPanel)
    else
      self:setCtrlVisible("TimePanel", false, panel)
      panel:stopAllActions()
      itemPanel.countdown = nil
    end
  end, 1)
end
function FireworksFunctionDlg:MSG_FIREWORKS_PARTY_INFO(data)
  local curTime = gf:getServerTime()
  if curTime >= data.shoot_end_time then
    DlgMgr:closeDlg(self.name)
    return
  end
  if self.lastUse then
    local amount = InventoryMgr:getAmountByName(self.lastUse[1])
    if amount == self.lastUse[2] - 1 then
      for i = 1, #ITEMS do
        self:playCountDown(i)
      end
      self.lastUse = nil
    end
  end
  self:updateItem()
end
function FireworksFunctionDlg:onDlgOpened(list)
  if list and list[1] then
    for i = 1, #ITEMS do
      self:playCountDown(i)
    end
  end
end
return FireworksFunctionDlg
