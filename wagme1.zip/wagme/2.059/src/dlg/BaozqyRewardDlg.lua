local BaozqyRewardDlg = Singleton("BaozqyRewardDlg", Dialog)
local NumImg = require("ctrl/NumImg")
local SOCRE_ARRAY = {
  11165,
  46850,
  74655
}
local REWARD_ITEM = {
  CHS[7120405],
  CHS[7120406],
  CHS[7120407]
}
function BaozqyRewardDlg:getCfgFileName()
  return ResMgr:getDlgCfg("AnniversaryPetCardrewDlg")
end
function BaozqyRewardDlg:init()
  self:bindListener("CloseImage", self.onCloseButton)
  self:setCtrlFullClient("BlackPanel")
  self:setCtrlVisible("ScorePanel", false)
  self:setCtrlVisible("AgainPanel", false)
  self:setCtrlVisible("ScorePanel2", true)
end
function BaozqyRewardDlg:setData(data)
  local root = self:getControl("ScorePanel2")
  local bonusLevel = 0
  if data.cur_score >= SOCRE_ARRAY[3] then
    bonusLevel = 3
  elseif data.cur_score >= SOCRE_ARRAY[2] then
    bonusLevel = 2
  elseif data.cur_score >= SOCRE_ARRAY[1] then
    bonusLevel = 1
  end
  for i = 1, 3 do
    self:setCtrlVisible("StarImage_" .. i, i <= bonusLevel, "StarPanel")
  end
  self:setLabelText("HighestNumLabel", string.format(CHS[4101200], data.max_score), root)
  local numPanel = self:getControl("NumPanel", nil, root)
  local sz = numPanel:getContentSize()
  local numImg = NumImg.new("bfight_num", 5, false, -5)
  numImg:setPosition(sz.width / 2, sz.height / 2)
  numImg:setScale(0.5, 0.5)
  numImg:setNum(data.cur_score, false)
  numPanel:addChild(numImg)
  self:setCtrlVisible("DaoPanel", false, root)
  self:setCtrlVisible("ExpPanel", false, root)
  if data.bonus_type == "exp" then
    self:setCtrlVisible("ExpPanel", true, root)
    self:setLabelText("NumLabel_1", data.bonus_value, self:getControl("ExpPanel", nil, root))
  else
    self:setCtrlVisible("DaoPanel", true, root)
    self:setLabelText("NumLabel_1", string.format(CHS[7120408], gf:getTaoStr(data.bonus_value), data.tao), self:getControl("DaoPanel", nil, root))
  end
  local noItem = true
  for i = 1, 3 do
    local panel = self:getControl("RewardPanel" .. i, nil, root)
    panel.itemName = REWARD_ITEM[i]
    self:bindListener("RewardPanel" .. i, self.onShowItemInfo, root)
    self:setLabelText("NumLabel_1", data["bonusCount" .. i], panel)
    if 0 < data["bonusCount" .. i] then
      noItem = false
    end
  end
  self:setCtrlVisible("NoRewardLabel", false, root)
  if noItem then
    self:setCtrlVisible("RewardPanel1", false, root)
    self:setCtrlVisible("RewardPanel2", false, root)
    self:setCtrlVisible("RewardPanel3", false, root)
    self:setCtrlVisible("NoRewardLabel", true, root)
    self:setCtrlVisible("ExpPanel", false, root)
    self:setCtrlVisible("TaoPanel", false, root)
  end
end
function BaozqyRewardDlg:onShowItemInfo(sender, eventType)
  local itemPos = InventoryMgr:getItemPosByName(sender.itemName)
  if itemPos then
    local rect = self:getBoundingBoxInWorldSpace(sender)
    InventoryMgr:showItemDlg(itemPos, rect)
  end
end
function BaozqyRewardDlg:onCloseButton(sender, eventType)
  gf:CmdToServer("CMD_SPRING_2020_BZQY_QUIT", {type = 1})
  DlgMgr:closeDlg(self.name)
  DlgMgr:closeDlg("BaozqyDlg")
end
return BaozqyRewardDlg
