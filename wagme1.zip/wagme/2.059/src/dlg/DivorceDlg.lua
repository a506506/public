local DugeonVoteDlg = require("dlg/DugeonVoteDlg")
local DivorceDlg = Singleton("DivorceDlg", DugeonVoteDlg)
function DivorceDlg:getCfgFileName()
  return ResMgr:getDlgCfg("DivorceDlg")
end
function DivorceDlg:setUiInfo()
end
function DivorceDlg:sendTimeoutCmd()
  gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_TEAM_ASK_REFUSE)
end
return DivorceDlg
