local EquipmentInheritDlg = Singleton("EquipmentInheritDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
local RewardContainer = require("ctrl/RewardContainer")
function EquipmentInheritDlg:init()
  self:bindListener("InheritButton", self.onInheritButton)
  self:bindListener("NoneEquipImage", self.onNoneEquipImage)
  self:bindListener("InfoButton", self.onInfoButton)
  self:bindListener("EquipmentImagePanel", self.onNoneEquipImage, "RightEquipmentPanel")
  self:bindListener("EquipmentImagePanel", self.onMainEquipImage, "LeftEquipmentPanel")
  self:bindCheckBoxListener("CheckBox", self.onCoinCheckBox)
  self:bindListener("SliverCoinPanel", self.onSliverCoinImage, "HavePanel")
  self:bindListener("CashPanel", self.onCashPanel, "HavePanel")
  self:bindListener("GoldCoinPanel", self.onGoldCoinPanel, "HavePanel")
  self:onCoinCheckBox(self:getControl("CheckBox"), nil, true)
  self.mainEquip = nil
  self.oEquip = nil
  self.keyStr = nil
  self.equipAtt = {}
  self:hookMsg("MSG_UPDATE")
  self:hookMsg("MSG_UPGRADE_INHERIT_PREVIEW")
end
function EquipmentInheritDlg:onGoldCoinPanel(sender, eventType)
  DlgMgr:openDlg("OnlineRechargeDlg")
end
function EquipmentInheritDlg:onInfoButton(sender, eventType)
  local data = {
    one = CHS[4200592],
    two = CHS[4200593],
    isScrollToDef = true
  }
  DlgMgr:openDlgEx("EquipmentRuleNewDlg", data)
end
function EquipmentInheritDlg:onCashPanel(sender, eventType)
  local rect = self:getBoundingBoxInWorldSpace(sender)
  local rewardInfo = RewardContainer:getRewardInfo({
    CHS[6000080],
    CHS[6000080]
  })
  local dlg
  if rewardInfo.desc then
    dlg = DlgMgr:openDlg("BonusInfoDlg")
  else
    dlg = DlgMgr:openDlg("BonusInfo2Dlg")
  end
  dlg:setRewardInfo(rewardInfo)
  dlg.root:setAnchorPoint(0, 0)
  dlg:setFloatingFramePos(rect)
end
function EquipmentInheritDlg:onSliverCoinImage(sender, eventType)
  InventoryMgr:openItemRescourse(CHS[3002297])
end
function EquipmentInheritDlg:onMainEquipImage(sender, eventType)
  if not self.mainEquip then
    return
  end
  local rect = self:getBoundingBoxInWorldSpace(sender)
  InventoryMgr:showEquipByEquipment(self.mainEquip, rect, true)
end
function EquipmentInheritDlg:onNoneEquipImage(sender, eventType)
  local equips = self:getSubmitEquipments(self.mainEquip)
  if #equips == 0 then
    gf:ShowSmallTips(CHS[4101113])
    return
  end
  local dlg = DlgMgr:openDlg("SubmitEquipDlg")
  dlg:setData(equips, "EquipmentInheritDlg", self.mainEquip.pos)
end
function EquipmentInheritDlg:onCoinCheckBox(sender, eventType, notTips)
  local panel = self:getControl("CoinPanel", nil, "CostPanel")
  self:setCtrlVisible("SliverCoinImage", sender:getSelectedState(), panel)
  self:setCtrlVisible("GoldCoinImage", not sender:getSelectedState(), panel)
  if notTips then
    return
  end
  if sender:getSelectedState() then
    gf:ShowSmallTips(CHS[4101114])
  else
    gf:ShowSmallTips(CHS[4101115])
  end
end
function EquipmentInheritDlg:refreshCost()
  local havePanel = self:getControl("HavePanel")
  local meMoneyStr, meFontColor = gf:getArtFontMoneyDesc(Me:queryBasicInt("cash"))
  self:setNumImgForPanel("CashValuePanel", meFontColor, meMoneyStr, false, LOCATE_POSITION.CENTER, 23, havePanel)
  local silver_coin = Me:queryBasicInt("silver_coin")
  local silverText = gf:getArtFontMoneyDesc(silver_coin)
  self:setNumImgForPanel("SilverCoinValuePanel", ART_FONT_COLOR.DEFAULT, silverText, false, LOCATE_POSITION.MID, 23, havePanel)
  gold_coin = Me:queryBasicInt("gold_coin")
  local goldText = gf:getArtFontMoneyDesc(gold_coin)
  self:setNumImgForPanel("GoldCoinValuePanel", ART_FONT_COLOR.DEFAULT, goldText, false, LOCATE_POSITION.MID, 23, havePanel)
end
function EquipmentInheritDlg:setData(mainEquip)
  self.mainEquip = mainEquip
  self:setEquip(mainEquip, self:getControl("LeftEquipmentPanel"))
  self:refreshCost()
end
function EquipmentInheritDlg:setEquip(equip, panel)
  local namePanel = self:getControl("NamePanel", nil, panel)
  if equip == nil then
    self:setImagePlist("EquipmentImage", ResMgr.ui.touming, panel)
    self:setLabelText("NameLabel", "", namePanel)
    return
  end
  self:setImage("EquipmentImage", ResMgr:getItemIconPath(equip.icon), panel)
  self:setItemImageSize("EquipmentImage", panel)
  self:setLabelText("NameLabel", equip.name, namePanel)
  self:setNumImgForPanel("EquipmentImagePanel", ART_FONT_COLOR.NORMAL_TEXT, equip.req_level, false, LOCATE_POSITION.LEFT_TOP, 21, panel)
  self.equipAtt[panel:getName()] = {}
  local rebuldLevel = equip.rebuild_level
  local degree = equip.degree_32
  local degreeStr = ""
  local rebuildStr = ""
  if degree and degree ~= 0 then
    local degressFloatValue = math.floor(equip.degree_32 / 100) * 100 / 1000000
    degreeStr = string.format(" (+%0.4f%%)", degressFloatValue)
    rebuildStr = string.format("%d%s", equip.rebuild_level, degreeStr)
    local value = equip.rebuild_level + degressFloatValue * 0.01
    table.insert(self.equipAtt[panel:getName()], value)
  else
    rebuildStr = string.format("%d", equip.rebuild_level)
    local value = equip.rebuild_level
    table.insert(self.equipAtt[panel:getName()], value)
  end
  self:setLabelText("OldNumLabel", rebuildStr, panel, COLOR3.TEXT_DEFAULT)
  local upgradeLevelPanel = self:getControl("UpgradeLevelPanel", nil, panel)
  self:setLabelText("NameLabel", CHS[4101116], upgradeLevelPanel)
  local attPanel1 = self:getControl("Attribute1Panel", nil, panel)
  if self:isWeapon(equip) then
    self:setLabelText("NameLabel", CHS[3002580], attPanel1)
    local value = equip.extra.phy_power_10 or 0
    self:setLabelText("OldNumLabel", value, attPanel1)
    table.insert(self.equipAtt[panel:getName()], value)
  else
    self:setLabelText("NameLabel", CHS[3002582], attPanel1)
    local value = equip.extra.def_10 or 0
    self:setLabelText("OldNumLabel", value, attPanel1)
    table.insert(self.equipAtt[panel:getName()], value)
  end
  local attPanel2 = self:getControl("Attribute2Panel", nil, panel)
  if self:isWeapon(equip) then
    self:setLabelText("NameLabel", CHS[3002581], attPanel2)
    local value = equip.extra.all_attrib_10 or 0
    self:setLabelText("OldNumLabel", value, attPanel2)
    table.insert(self.equipAtt[panel:getName()], value)
  else
    self:setLabelText("NameLabel", CHS[3002583], attPanel2)
    local value = equip.extra.max_life_10 or 0
    self:setLabelText("OldNumLabel", value, attPanel2)
    table.insert(self.equipAtt[panel:getName()], value)
  end
  local gongmPanel = self:getControl("GongmingPanel", nil, panel)
  local gongmAttrib = EquipmentMgr:getGongmingAttrib(equip)
  self:setCtrlVisible("NameLabel", true, gongmPanel)
  self:setCtrlVisible("OldNumLabel", true, gongmPanel)
  self:setCtrlVisible("NoGongmingLabel", true, gongmPanel)
  self:setLabelText("NameLabel", "", gongmPanel)
  self:setLabelText("OldNumLabel", "", gongmPanel)
  self:setLabelText("NoGongmingLabel", "", gongmPanel)
  if not gongmAttrib or not next(gongmAttrib) then
    self:setLabelText("NoGongmingLabel", CHS[7190139], gongmPanel)
    table.insert(self.equipAtt[panel:getName()], 0)
  else
    self:setLabelText("NameLabel", EquipmentMgr:getAttribChsOrEng(gongmAttrib.field), gongmPanel)
    self:setLabelText("OldNumLabel", gongmAttrib.value .. EquipmentMgr:getPercentSymbolByField(gongmAttrib.field), gongmPanel)
    table.insert(self.equipAtt[panel:getName()], gongmAttrib.value)
  end
end
function EquipmentInheritDlg:isWeapon(equip)
  if EQUIP_TYPE.WEAPON == equip.equip_type then
    return true
  else
    return false
  end
end
function EquipmentInheritDlg:getSubmitEquipments(mEquip)
  local inventory = InventoryMgr:getAllInventory()
  local equips = {}
  for _, v in pairs(inventory) do
    local level = v.req_level
    if v.evolve_level then
      level = v.req_level - v.evolve_level
    end
    local rebuildLevel = v.rebuild_level or 0
    if mEquip.pos ~= v.pos and v.item_type == ITEM_TYPE.EQUIPMENT and level >= 70 and not InventoryMgr:isLimitedItemForever(v) and rebuildLevel >= 5 and mEquip.equip_type == v.equip_type then
      table.insert(equips, v)
    end
  end
  return equips
end
function EquipmentInheritDlg:getResultValue(key, value, vStr, idx, field)
  if not self.equipAtt[key] then
    return
  end
  field = field or ""
  local data = self.equipAtt[key]
  if data[idx] == value then
    return vStr .. EquipmentMgr:getPercentSymbolByField(field), COLOR3.TEXT_DEFAULT
  elseif value < data[idx] then
    return vStr .. EquipmentMgr:getPercentSymbolByField(field) .. "↓", COLOR3.RED
  else
    return vStr .. EquipmentMgr:getPercentSymbolByField(field) .. "↑", COLOR3.GREEN
  end
end
function EquipmentInheritDlg:setPreEquip(equip, panel)
  local rebuldLevel = equip.rebuild_level
  local degree = equip.degree_32
  local degreeStr = ""
  local rebuildStr = ""
  local value1 = 0
  if degree and degree ~= 0 then
    degreeStr = string.format(" (+%0.4f%%)", math.floor(equip.degree_32 / 100) * 100 / 1000000)
    rebuildStr = string.format("%d%s", equip.rebuild_level, degreeStr)
    value1 = equip.rebuild_level + math.floor(equip.degree_32 / 100) * 100 / 1000000 * 0.01
  else
    rebuildStr = string.format("%d", equip.rebuild_level)
    value1 = equip.rebuild_level
  end
  local retStr, color = self:getResultValue(panel:getName(), value1, rebuildStr, 1)
  self:setLabelText("NewNumLabel", retStr, panel, color)
  local upgradeLevelPanel = self:getControl("UpgradeLevelPanel", nil, panel)
  self:setLabelText("NewNameLabel", CHS[4101116], upgradeLevelPanel)
  self:setNumImgForPanel("EquipmentImagePanel", ART_FONT_COLOR.NORMAL_TEXT, equip.req_level, false, LOCATE_POSITION.LEFT_TOP, 21, panel)
  local attPanel1 = self:getControl("Attribute1Panel", nil, panel)
  if self:isWeapon(equip) then
    self:setLabelText("NewNameLabel", CHS[3002580], attPanel1)
    local value = equip.extra.phy_power_10 or 0
    local retStr, color = self:getResultValue(panel:getName(), value, value, 2)
    self:setLabelText("NewNumLabel", retStr, attPanel1, color)
  else
    self:setLabelText("NewNameLabel", CHS[3002582], attPanel1)
    local value = equip.extra.def_10 or 0
    local retStr, color = self:getResultValue(panel:getName(), value, value, 2)
    self:setLabelText("NewNumLabel", retStr, attPanel1, color)
  end
  local attPanel2 = self:getControl("Attribute2Panel", nil, panel)
  if self:isWeapon(equip) then
    self:setLabelText("NewNameLabel", CHS[3002581], attPanel2)
    local value = equip.extra.all_attrib_10 or 0
    local retStr, color = self:getResultValue(panel:getName(), value, value, 3)
    self:setLabelText("NewNumLabel", retStr, attPanel2, color)
  else
    self:setLabelText("NewNameLabel", CHS[3002583], attPanel2)
    local value = equip.extra.max_life_10 or 0
    local retStr, color = self:getResultValue(panel:getName(), value, value, 3)
    self:setLabelText("NewNumLabel", retStr, attPanel2, color)
  end
  local gongmPanel = self:getControl("GongmingPanel", nil, panel)
  local gongmAttrib = EquipmentMgr:getGongmingAttrib(equip)
  self:setCtrlVisible("NewNameLabel", true, gongmPanel)
  self:setCtrlVisible("NewNumLabel", true, gongmPanel)
  self:setCtrlVisible("NoGongmingLabel_1", true, gongmPanel)
  self:setLabelText("NewNameLabel", "", gongmPanel)
  self:setLabelText("NewNumLabel", "", gongmPanel)
  self:setLabelText("NoGongmingLabel_1", "", gongmPanel)
  if not gongmAttrib or not next(gongmAttrib) then
    self:setLabelText("NoGongmingLabel_1", CHS[7190139], gongmPanel)
  else
    self:setLabelText("NewNameLabel", EquipmentMgr:getAttribChsOrEng(gongmAttrib.field), gongmPanel)
    local value = gongmAttrib.value
    local retStr, color = self:getResultValue(panel:getName(), value, value, 4, gongmAttrib.field)
    self:setLabelText("NewNumLabel", retStr, gongmPanel)
  end
end
function EquipmentInheritDlg:onInheritButton(sender, eventType)
  if not self.mainEquip then
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  if Me:queryBasicInt("level") < 70 then
    gf:ShowSmallTips(CHS[4200158])
    return
  end
  if not self.oEquip then
    gf:ShowSmallTips(CHS[4101118])
    return
  end
  local attrib = EquipmentMgr:getAttrib(self.mainEquip.pos, 1)
  local rebuildLevel = self.mainEquip.rebuild_level or 0
  if #attrib < 3 and rebuildLevel == 0 then
    gf:ShowSmallTips(CHS[4101119])
    return
  end
  local gAttrib = EquipmentMgr:getAttrib(self.mainEquip.pos, 4)
  if #gAttrib < 1 then
    gf:ShowSmallTips(CHS[4101119])
    return
  end
  if rebuildLevel > 5 then
    gf:ShowSmallTips(CHS[4200529])
    return
  end
  if Me:isInCombat() and (self.mainEquip.pos <= 10 or self.oEquip.pos <= 10) then
    gf:ShowSmallTips(CHS[4101120])
    return
  end
  if self:checkSafeLockRelease("onInheritButton") then
    return
  end
  local costCash = self.data.money
  if costCash > Me:queryBasicInt("cash") then
    gf:askUserWhetherBuyCash()
    return
  end
  local flag = self:isCheck("CheckBox") and 0 or 1
  if flag == 1 and Me:queryBasicInt("gold_coin") < self.data.coin then
    gf:askUserWhetherBuyCoin()
    return
  end
  if Me:getTotalCoin() < self.data.coin then
    gf:askUserWhetherBuyCoin()
    return
  end
  local tips = self:getTipsForConfirm()
  gf:confirm(tips, function()
    gf:CmdToServer("CMD_UPGRADE_EQUIP", {
      pos = self.mainEquip.pos,
      type = Const.EQUIP_UPGRADE_INHERIT,
      para = tostring(self.oEquip.pos) .. "|" .. flag
    })
    self:onCloseButton()
  end)
end
function EquipmentInheritDlg:getTipsForConfirm()
  local flag = self:isCheck("CheckBox") and 1 or 0
  local _, mLimitDays = gf:converToLimitedTimeDay(self.data.mEquip.gift)
  local _, oLimitDays = gf:converToLimitedTimeDay(self.data.oEquip.gift)
  local _, mOldEquipLimitDays = gf:converToLimitedTimeDay(self.mainEquip.gift)
  local _, oOldEquipLimitDays = gf:converToLimitedTimeDay(self.oEquip.gift)
  local moneyStr = gf:getMoneyDesc(self.data.money)
  local costSCoin = 0
  local costGCoin = 0
  local tips = ""
  if flag == 1 then
    if 0 < Me:queryBasicInt("silver_coin") then
      mLimitDays = math.min(mLimitDays + 10, 60)
      oLimitDays = math.min(oLimitDays + 10, 60)
      costSCoin = math.min(Me:queryBasicInt("silver_coin"), self.data.coin)
      costGCoin = self.data.coin - costSCoin
      if costGCoin ~= 0 then
        tips = string.format(CHS[4101121], moneyStr, costSCoin, costGCoin)
      else
        tips = string.format(CHS[4101122], moneyStr, costSCoin)
      end
      if mLimitDays ~= mOldEquipLimitDays and oLimitDays ~= oOldEquipLimitDays then
        local str = string.format(CHS[4101123], mLimitDays, oLimitDays)
        tips = tips .. str
      elseif mLimitDays ~= mOldEquipLimitDays then
        local str = string.format(CHS[4101124], mLimitDays)
        tips = tips .. str
      elseif oLimitDays ~= oOldEquipLimitDays then
        local str = string.format(CHS[4101125], oLimitDays)
        tips = tips .. str
      end
    else
      costSCoin = 0
      costGCoin = self.data.coin
      tips = string.format(CHS[4101126], moneyStr, costGCoin)
      if mLimitDays ~= mOldEquipLimitDays then
        local str = string.format(CHS[4101127], mLimitDays)
        tips = tips .. str
      end
    end
  else
    costSCoin = 0
    costGCoin = self.data.coin
    tips = string.format(CHS[4101128], moneyStr, costGCoin)
    if mLimitDays ~= mOldEquipLimitDays then
      local str = string.format(CHS[4101129], mLimitDays)
      tips = tips .. str
    end
  end
  return tips
end
function EquipmentInheritDlg:setCheckData(keyStr)
  self.keyStr = keyStr
end
function EquipmentInheritDlg:MSG_UPDATE()
  self:refreshCost()
end
function EquipmentInheritDlg:MSG_UPGRADE_INHERIT_PREVIEW(data)
  if self.keyStr ~= data.pos .. data.para then
    return
  end
  if data.flag ~= 1 then
    return
  end
  self.data = data
  self:setCtrlVisible("PlusImage", false)
  self:setCtrlVisible("NoneEquipImage", false)
  local costPanel = self:getControl("CostPanel")
  local meMoneyStr, meFontColor = gf:getArtFontMoneyDesc(data.money)
  self:setNumImgForPanel("CashValuePanel", meFontColor, meMoneyStr, false, LOCATE_POSITION.CENTER, 23, costPanel)
  local silverText = gf:getArtFontMoneyDesc(data.coin)
  self:setNumImgForPanel("CoinValuePanel", ART_FONT_COLOR.DEFAULT, silverText, false, LOCATE_POSITION.MID, 23, costPanel)
  self.oEquip = InventoryMgr:getItemByPos(tonumber(data.para))
  self:setEquip(self.oEquip, self:getControl("RightEquipmentPanel"))
  self:setPreEquip(data.mEquip, self:getControl("LeftEquipmentPanel"))
  self:setPreEquip(data.oEquip, self:getControl("RightEquipmentPanel"))
end
return EquipmentInheritDlg
