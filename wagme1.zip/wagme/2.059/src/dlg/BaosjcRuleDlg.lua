local BaosjcRuleDlg = Singleton("BaosjcRuleDlg", Dialog)
function BaosjcRuleDlg:init()
end
return BaosjcRuleDlg
