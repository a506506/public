local ArtifactSkillUpDlg = Singleton("ArtifactSkillUpDlg", Dialog)
local ARTIFACT_SPSKILL_LEVELUP_MIN_LEVEL = 70
function ArtifactSkillUpDlg:init()
  self:bindListener("ArtifactImagePanel_2", self.onSelectSecondaryArtifact, "ArtifactPanel_1")
  self:bindListener("ArtifactImagePanel_1", self.onSelectSecondaryArtifact, "ArtifactPanel_2")
  self:bindListener("ArtifactImagePanel_2", self.onSelectSecondaryArtifact, "ArtifactPanel_2")
  self:bindListener("SkillUpButton", self.onSkillUpButton)
  self:bindListener("InfoButton", self.onRuleButton)
  self:bindListener("BindCheckBox", self.onLimitedCheckBox)
  self:setCtrlVisible("NoneArtifactImage", true, "ArtifactImagePanel")
  self:setCtrlVisible("FrameImage", false, "ArtifactImagePanel")
  self.selectArtifact = nil
  self.submitArtifactNum = 0
  self.chosenArtifacts = {}
  self.costItem = {}
  local artifactPanel1 = self:getControl("ArtifactPanel_1")
  local artifactPanel2 = self:getControl("ArtifactPanel_2")
  if InventoryMgr.UseLimitItemDlgs[self.name] == 1 then
    self:setCheck("BindCheckBox", true)
  elseif InventoryMgr.UseLimitItemDlgs[self.name] == 0 then
    self:setCheck("BindCheckBox", false)
  end
  self:refreshSecondaryArtifactPanel()
  self:refreshCostItemPanel()
  self:refreshLevelUpButton()
  self:hookMsg("MSG_INVENTORY")
end
function ArtifactSkillUpDlg:chosenArfactsIsExist()
  if not next(self.chosenArtifacts) then
    return false
  end
  for i = 1, #self.chosenArtifacts do
    if not InventoryMgr:getItemById(self.chosenArtifacts[i].item_unique) then
      return false
    end
  end
  return true
end
function ArtifactSkillUpDlg:setArtifactInfo(artifact)
  if not artifact or artifact.item_type ~= ITEM_TYPE.ARTIFACT then
    return
  end
  self:setCtrlVisible("NoneArtifactImage", false, "ArtifactImagePanel")
  self:setCtrlVisible("FrameImage", true, "ArtifactImagePanel")
  local lastArtifact = self.selectArtifact
  self.selectArtifact = artifact
  self:setImage("ArtifactImage", InventoryMgr:getIconFileByName(artifact.name), "ArtifactImagePanel")
  self:setItemImageSize("ArtifactImage", "ArtifactImagePanel")
  self:setCtrlVisible("ArtifactImage", true, "ArtifactImagePanel")
  self:setNumImgForPanel("ArtifactImagePanel", ART_FONT_COLOR.NORMAL_TEXT, artifact.level, false, LOCATE_POSITION.LEFT_TOP, 21)
  local img = self:getControl("ArtifactImage", nil, "ArtifactImagePanel")
  InventoryMgr:removeArtifactPolarImage(img)
  if artifact.item_polar then
    InventoryMgr:addArtifactPolarImage(img, artifact.item_polar)
  end
  if InventoryMgr:isTimeLimitedItem(artifact) then
    InventoryMgr:removeLogoBinding(img)
    InventoryMgr:addLogoTimeLimit(img)
  elseif InventoryMgr:isLimitedItem(artifact) then
    InventoryMgr:removeLogoTimeLimit(img)
    InventoryMgr:addLogoBinding(img)
  else
    InventoryMgr:removeLogoTimeLimit(img)
    InventoryMgr:removeLogoBinding(img)
  end
  local function func(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
      local rect = self:getBoundingBoxInWorldSpace(sender)
      local selectArtifact = self.selectArtifact
      InventoryMgr:showArtifact(selectArtifact, rect, true)
    end
  end
  local artifactImage = self:getControl("ArtifactImage", nil, "ArtifactImagePanel")
  artifactImage:addTouchEventListener(func)
  self:setLabelText("ArtifactNameLabel", artifact.name)
  local artifactSpSkillName = SkillMgr:getArtifactSpSkillName(artifact.extra_skill)
  if artifactSpSkillName then
    local artifactSpSkillLevel = artifact.extra_skill_level
    self:setLabelText("SkillNameLabel", artifactSpSkillName, "OldArtifactSkillPanel", COLOR3.TEXT_DEFAULT)
    self:setLabelText("SkillNLabel", string.format(CHS[2000131], artifactSpSkillLevel), "OldArtifactSkillPanel")
    self:setLabelText("SkillNameLabel", artifactSpSkillName, "NewArtifactSkillPanel", COLOR3.GREEN)
    self:setLabelText("SkillNLabel", string.format(CHS[2000131], artifactSpSkillLevel + 1) .. CHS[7002014], "NewArtifactSkillPanel", COLOR3.GREEN)
    if artifactSpSkillLevel >= Const.ARTIFACT_MAX_LEVEL then
      self:setLabelText("SkillNameLabel", CHS[7002015], "NewArtifactSkillPanel", COLOR3.GREEN)
      self:setLabelText("SkillNLabel", "", "NewArtifactSkillPanel")
    end
  else
    self:setLabelText("SkillNameLabel", CHS[7000329], "OldArtifactSkillPanel", COLOR3.GRAY)
    self:setLabelText("SkillNLabel", "", "OldArtifactSkillPanel")
    self:setLabelText("SkillNameLabel", CHS[7002002], "NewArtifactSkillPanel", COLOR3.GRAY)
    self:setLabelText("SkillNLabel", "", "NewArtifactSkillPanel")
  end
  if lastArtifact and self.selectArtifact and lastArtifact.iid_str == self.selectArtifact.iid_str and self:chosenArfactsIsExist() then
    self:refreshSecondaryArtifactPanel(self.chosenArtifacts)
  else
    self:refreshSecondaryArtifactPanel()
  end
  self:refreshCostItemPanel()
  self:refreshLevelUpButton()
end
function ArtifactSkillUpDlg:refreshSecondaryArtifactPanel(chosenArtifacts)
  local artifact = self.selectArtifact
  if not artifact then
    return
  end
  local skillName = SkillMgr:getArtifactSpSkillName(artifact.extra_skill)
  if not skillName then
    self:setCtrlVisible("ArtifactPanel_1", true, "CostPanel")
    self:setCtrlVisible("ArtifactPanel_2", false, "CostPanel")
    self:setArtifactImage(nil, self:getControl("ArtifactImagePanel_2", nil, "ArtifactPanel_1"))
    return
  end
  if artifact.extra_skill_level < 10 then
    self.submitArtifactNum = 1
    self:setCtrlVisible("ArtifactPanel_1", true, "CostPanel")
    self:setCtrlVisible("ArtifactPanel_2", false, "CostPanel")
    local rootName = "ArtifactPanel_1"
    if chosenArtifacts and #chosenArtifacts == 1 then
      self.chosenArtifacts = chosenArtifacts
      self:setArtifactImage(chosenArtifacts[1], self:getControl("ArtifactImagePanel_2", nil, rootName))
    else
      self.chosenArtifacts = {}
      self:setArtifactImage(nil, self:getControl("ArtifactImagePanel_2", nil, rootName))
    end
  else
    self.submitArtifactNum = 2
    self:setCtrlVisible("ArtifactPanel_1", false, "CostPanel")
    self:setCtrlVisible("ArtifactPanel_2", true, "CostPanel")
    local rootName = "ArtifactPanel_2"
    if chosenArtifacts and #chosenArtifacts == 2 then
      self.chosenArtifacts = chosenArtifacts
      self:setArtifactImage(chosenArtifacts[1], self:getControl("ArtifactImagePanel_1", nil, rootName))
      self:setArtifactImage(chosenArtifacts[2], self:getControl("ArtifactImagePanel_2", nil, rootName))
    else
      self.chosenArtifacts = {}
      self:setArtifactImage(nil, self:getControl("ArtifactImagePanel_1", nil, rootName))
      self:setArtifactImage(nil, self:getControl("ArtifactImagePanel_2", nil, rootName))
    end
  end
end
function ArtifactSkillUpDlg:setArtifactImage(artifact, root)
  if artifact then
    self:setCtrlVisible("ArtifactPanel", true, root)
    self:setCtrlVisible("NoneImage", false, root)
    self:setImage("ArtifactImage", InventoryMgr:getIconFileByName(artifact.name), root)
    self:setItemImageSize("ArtifactImage", root)
    self:setNumImgForPanel("ArtifactPanel", ART_FONT_COLOR.NORMAL_TEXT, artifact.level, false, LOCATE_POSITION.LEFT_TOP, 21, root)
    local img = self:getControl("ArtifactImage", nil, root)
    InventoryMgr:removeArtifactPolarImage(img)
    if artifact.item_polar then
      InventoryMgr:addArtifactPolarImage(img, artifact.item_polar)
    end
    if artifact and InventoryMgr:isLimitedItem(artifact) then
      InventoryMgr:addLogoBinding(img)
    else
      InventoryMgr:removeLogoBinding(img)
    end
  else
    self:setCtrlVisible("ArtifactPanel", false, root)
    self:setCtrlVisible("NoneImage", true, root)
  end
end
function ArtifactSkillUpDlg:refreshCostItemPanel()
  local artifact = self.selectArtifact
  local costItem = EquipmentMgr:getArtifactSpSkillLevelUpCost(artifact)
  local costItemName = costItem.name
  local costItemNum = costItem.num
  self.costItem = costItem
  self:setImage("CostImage", InventoryMgr:getIconFileByName(costItemName), "CostImagePanel")
  self:setItemImageSize("CostImage", "CostImagePanel")
  self:setLabelText("CostItemLabel", costItemName, "CostImagePanel")
  self:setLabelText("CostNumLabel", "/" .. costItemNum, "CostImagePanel")
  local isUseLimited = false
  if self:isCheck("BindCheckBox") then
    isUseLimited = true
  else
    isUseLimited = false
  end
  local amount = InventoryMgr:getAmountByNameIsForeverBind(costItemName, isUseLimited)
  if costItemNum > amount then
    self:setLabelText("HaveNumLabel", amount, "CostImagePanel", COLOR3.RED)
  elseif amount <= 999 then
    self:setLabelText("HaveNumLabel", amount, "CostImagePanel", COLOR3.GREEN)
  else
    self:setLabelText("HaveNumLabel", "*", "CostImagePanel", COLOR3.GREEN)
  end
  local costImagePanel = self:getControl("CostImage", nil, "CostImagePanel")
  local function listener(sender, eventType)
    if ccui.TouchEventType.ended == eventType then
      local name = self.costItem.name
      local rect = self:getBoundingBoxInWorldSpace(sender)
      InventoryMgr:showBasicMessageDlg(name, rect)
    end
  end
  costImagePanel:addTouchEventListener(listener)
end
function ArtifactSkillUpDlg:refreshLevelUpButton()
  local artifact = self.selectArtifact
  if not artifact then
    self:setCtrlVisible("SkillUpButton", true)
    self:setCtrlVisible("MarkPanel", false)
    self:setCtrlEnabled("SkillUpButton", false)
    return
  end
  local artifactSpSkillName = SkillMgr:getArtifactSpSkillName(artifact.extra_skill)
  if not artifactSpSkillName then
    self:setCtrlVisible("SkillUpButton", true)
    self:setCtrlVisible("MarkPanel", false)
    self:setCtrlEnabled("SkillUpButton", false)
  else
    local artifactSpSkillLevel = artifact.extra_skill_level
    if artifactSpSkillLevel >= artifact.level then
      self:setCtrlVisible("SkillUpButton", false)
      self:setCtrlVisible("MarkPanel", true)
    else
      self:setCtrlVisible("SkillUpButton", true)
      self:setCtrlVisible("MarkPanel", false)
      self:setCtrlEnabled("SkillUpButton", true)
    end
  end
end
function ArtifactSkillUpDlg:onSelectSecondaryArtifact(sender, eventType)
  local mainArtifact = self.selectArtifact
  if not mainArtifact then
    gf:ShowSmallTips(CHS[7002011])
    return
  end
  local artifactSpSkillName = SkillMgr:getArtifactSpSkillName(mainArtifact.extra_skill)
  if not artifactSpSkillName then
    gf:ShowSmallTips(CHS[7002013])
    return
  end
  local artifacts = InventoryMgr:getBagAllArtifacts()
  local count = 0
  for i = 1, #artifacts do
    if artifacts[i].name == self.selectArtifact.name and not InventoryMgr:isTimeLimitedItem(artifacts[i]) and artifacts[i].pos ~= mainArtifact.pos then
      count = count + 1
    end
  end
  if 0 < self.submitArtifactNum and count < self.submitArtifactNum then
    gf:ShowSmallTips(string.format(CHS[7002003], self.submitArtifactNum))
    return
  end
  local dlg = DlgMgr:openDlg("ArtifactSubmitDlg")
  dlg:setMainArtifact(self.selectArtifact)
  dlg:setSubmitType("skillup")
  dlg:setSubmitNum(self.submitArtifactNum)
end
function ArtifactSkillUpDlg:onSkillUpButton()
  if not DistMgr:checkCrossDist() then
    return
  end
  local artifact = self.selectArtifact
  if not artifact then
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  if Me:isInCombat() and InventoryMgr:isEquipPos(artifact.pos) then
    gf:ShowSmallTips(CHS[3002430])
    return
  end
  if Me:getLevel() < ARTIFACT_SPSKILL_LEVELUP_MIN_LEVEL then
    gf:ShowSmallTips(string.format(CHS[3004067], ARTIFACT_SPSKILL_LEVELUP_MIN_LEVEL))
    return
  end
  if InventoryMgr:isTimeLimitedItem(artifact) then
    gf:ShowSmallTips(CHS[7002004])
    return
  end
  if not SkillMgr:getArtifactSpSkillName(artifact.extra_skill) then
    gf:ShowSmallTips(CHS[7002005])
    return
  end
  local isUseLimited = false
  if self:isCheck("BindCheckBox") then
    isUseLimited = true
  else
    isUseLimited = false
  end
  local costItem = EquipmentMgr:getArtifactSpSkillLevelUpCost(artifact)
  local amount = InventoryMgr:getAmountByNameIsForeverBind(costItem.name, isUseLimited)
  if amount < costItem.num then
    gf:ShowSmallTips(string.format(CHS[7002007], costItem.name))
    return
  end
  if not self.chosenArtifacts or #self.chosenArtifacts < self.submitArtifactNum then
    gf:ShowSmallTips(string.format(CHS[7002008], self.submitArtifactNum))
    return
  end
  if self:checkSafeLockRelease("onSkillUpButton") then
    return
  end
  self:skillLevelUp()
end
function ArtifactSkillUpDlg:skillLevelUp()
  local artifact = self.selectArtifact
  if not artifact then
    return
  end
  local costItemName = self.costItem.name
  local costItemNum = self.costItem.num
  if not costItemName or not costItemNum then
    return
  end
  local isUseLimited = false
  if self:isCheck("BindCheckBox") then
    isUseLimited = true
  else
    isUseLimited = false
  end
  local str, day = gf:converToLimitedTimeDay(artifact.gift)
  local count = 0
  if InventoryMgr:isLimitedItemForever(self.chosenArtifacts[1]) then
    count = count + 10
  end
  if InventoryMgr:isLimitedItemForever(self.chosenArtifacts[2]) then
    count = count + 10
  end
  local data = {}
  data.pos = artifact.pos
  data.type = Const.UPGRADE_ARTIFACT_EXTRA_SKILL
  if self.submitArtifactNum == 2 then
    local item = InventoryMgr:getPriorityUseInventoryByName(costItemName, isUseLimited)
    if InventoryMgr:isLimitedItemForever(item) then
      count = count + 10
    end
    data.para = self.chosenArtifacts[1].pos .. "|" .. self.chosenArtifacts[2].pos .. "|" .. item.pos
    if day <= Const.LIMIT_TIPS_DAY and count > 0 then
      gf:confirm(string.format(CHS[7002012], count), function()
        gf:CmdToServer("CMD_UPGRADE_EQUIP", data)
      end)
      return
    end
    gf:CmdToServer("CMD_UPGRADE_EQUIP", data)
  else
    local itemArray = InventoryMgr:getItemArrayByCostOrder(costItemName, isUseLimited)
    if not itemArray[1] then
      return
    end
    local firstItem = itemArray[1]
    if InventoryMgr:isLimitedItemForever(firstItem) then
      count = count + 10
    end
    local secondItem
    if itemArray[1].amount == 1 then
      secondItem = itemArray[2]
    else
      secondItem = itemArray[1]
    end
    if not secondItem then
      return
    end
    if InventoryMgr:isLimitedItemForever(secondItem) then
      count = count + 10
    end
    data.para = self.chosenArtifacts[1].pos .. "|" .. firstItem.pos .. "|" .. secondItem.pos
    if day <= Const.LIMIT_TIPS_DAY and count > 0 then
      gf:confirm(string.format(CHS[7002012], count), function()
        gf:CmdToServer("CMD_UPGRADE_EQUIP", data)
      end)
      return
    end
    gf:CmdToServer("CMD_UPGRADE_EQUIP", data)
  end
end
function ArtifactSkillUpDlg:onLimitedCheckBox(sender, eventType)
  if sender:getSelectedState() == true then
    InventoryMgr:setLimitItemDlgs(self.name, 1)
    gf:ShowSmallTips(CHS[6000525])
  else
    InventoryMgr:setLimitItemDlgs(self.name, 0)
  end
  self:refreshCostItemPanel()
end
function ArtifactSkillUpDlg:onRuleButton()
  local data = {
    one = CHS[4200590],
    isScrollToDef = true
  }
  DlgMgr:openDlgEx("ArtifactRuleNewDlg", data)
end
function ArtifactSkillUpDlg:cleanup()
  self.selectArtifact = nil
  self.submitArtifactNum = 0
  self.chosenArtifacts = {}
end
return ArtifactSkillUpDlg
