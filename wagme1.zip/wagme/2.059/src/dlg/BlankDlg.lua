local BlankDlg = Singleton("BlankDlg", Dialog)
function BlankDlg:init()
  self.root:setContentSize(Const.WINSIZE.width / Const.UI_SCALE, Const.WINSIZE.height / Const.UI_SCALE)
  self:align(ccui.RelativeAlign.centerInParent)
  self:bindListener("BlankDlg", self.dlgButton)
end
function BlankDlg:dlgButton()
  if nil == self.dlg then
    return
  end
  DlgMgr:closeDlg(self.dlg.name)
end
function BlankDlg:setChildDlg(dlg)
  self.dlg = dlg
end
return BlankDlg
