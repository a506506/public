local BasicShopDlg = require("dlg/BasicShopDlg")
local BaoscclShopDlg = Singleton("BaoscclShopDlg", BasicShopDlg)
function BaoscclShopDlg:init()
  self:setShopLimit(100)
  BasicShopDlg.init(self)
  cc.SpriteFrameCache:getInstance():addSpriteFrames("ui/Baosccl.plist")
  DlgMgr:registPlistEx(self.name, "Baosccl.plist")
  local goodsPanel1 = self:getControl("GoodsPanel1", Const.UIPanel, self.goodsPanel)
  local goodsPanel2 = self:getControl("GoodsPanel2", Const.UIPanel, self.goodsPanel)
  self:setImagePlist("CashImage", ResMgr.ui.bsccl_tongbao, goodsPanel1)
  self:setImagePlist("CashImage", ResMgr.ui.bsccl_tongbao, goodsPanel2)
  self:setLabelText("TitleLabel1", CHS[5410655])
  self:setLabelText("TitleLabel2", CHS[5410655])
  self:setLabelText("NumberLabel", CHS[5410501], "BuyNumberPanel")
  self:setLabelText("Label_1", CHS[5410656], "HavePanel")
  self:setImagePlist("HaveCashImage", ResMgr.ui.bsccl_tongbao)
  self:setImagePlist("TotalValueCashImage", ResMgr.ui.bsccl_tongbao)
  self.hasSet = false
  self:setEndTime()
  if ActivityHelperMgr.baoscclShopData then
    self:MSG_GHOST_2020_BSCCL_SHOP(ActivityHelperMgr.baoscclShopData)
  end
end
function BaoscclShopDlg:hookMsgs()
  self:hookMsg("MSG_GHOST_2020_BSCCL_SHOP")
  self:hookMsg("MSG_GHOST_2020_BSCCL_DATA")
end
function BaoscclShopDlg:cleanup()
  BasicShopDlg.cleanup(self)
  self.hasSet = nil
  DlgMgr:unregistPlistEx(self.name, "Baosccl.plist")
end
function BaoscclShopDlg:setEndTime()
  if self.hasSet then
    return
  end
  local function func(name, root)
    local panel = self:getControl(name, nil, root)
    local size = panel:getContentSize()
    panel:setContentSize(size.width, size.height - 30)
  end
  local time = self:getEndTime()
  if time then
    self:setLabelText("TimeValueLabel", gf:getServerDate(CHS[5410193], time), "TimePanel")
    self:setCtrlVisible("TimePanel", true)
    self.hasSet = true
    func("PharmacyPanel")
    func("PharmacyListView")
    func("BKImage1", "PharmacyPanel")
  end
end
function BaoscclShopDlg:getOwnNum()
  return ActivityHelperMgr.baoscclData and ActivityHelperMgr.baoscclData.tb_num or 0
end
function BaoscclShopDlg:getEndTime()
  return ActivityHelperMgr.baoscclData and ActivityHelperMgr.baoscclData.act_bonus_time
end
function BaoscclShopDlg:setTips(mTips)
  mTips.minNumTip = CHS[5410379]
  mTips.maxNumTip1 = CHS[5410382]
  mTips.maxNumTip2 = CHS[5410381]
  mTips.maxNumTip3 = CHS[5410657]
  mTips.costTip = CHS[5410658]
end
function BaoscclShopDlg:onBuyButton(sender, eventType)
  local time = self:getEndTime()
  if time and time <= gf:getServerTime() then
    gf:ShowSmallTips(CHS[5401034])
    DlgMgr:closeDlg("BaoscclDlg")
    DlgMgr:closeDlg("BaoscclShopDlg")
    return
  end
  if not self.goods then
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  if not self.pickGoods then
    gf:ShowSmallTips(CHS[3003269])
    return
  end
  local info = self.goods[self.pickGoods]
  if not info then
    return
  end
  local countPanel = self:getControl("BuyNumberPanel")
  local num = tonumber(self:getLabelText("NumberValueLabel", countPanel))
  if num < 1 then
    gf:ShowSmallTips(CHS[5410379])
    return
  end
  if num * info.cost > self:getOwnNum() then
    gf:ShowSmallTips(CHS[5410658])
    return
  end
  local cout = InventoryMgr:getCountCanAddToBag(info.name, num, info.bind == 1)
  if num > cout then
    gf:ShowSmallTips(CHS[5410381])
    return
  end
  if self:checkSafeLockRelease("onBuyButton") then
    return
  end
  gf:CmdToServer("CMD_GHOST2020_BUY_ITEM", {
    item_name = info.name,
    num = num
  })
end
function BaoscclShopDlg:MSG_GHOST_2020_BSCCL_SHOP(data)
  if self.goods == nil then
    self.goods = data
    self:setStore()
  else
    self.goods = data
    self:setStoreItemsNum()
  end
end
function BaoscclShopDlg:MSG_GHOST_2020_BSCCL_DATA(data)
  self:setHavePanel()
  self:setCost()
  self:setEndTime()
end
return BaoscclShopDlg
