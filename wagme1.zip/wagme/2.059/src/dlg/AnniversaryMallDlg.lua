local AnniversaryMallDlg = Singleton("AnniversaryMallDlg", Dialog)
local ITEM_CFG = {
  {
    name = CHS[7150577],
    iconPath = ResMgr:getItemIconPath(8001),
    showLimit = true
  },
  {
    name = CHS[7150578],
    iconPath = ResMgr:getItemIconPath(9109),
    showLimit = true
  },
  {
    name = CHS[7150579],
    iconPath = ResMgr:getItemIconPath(2067),
    showLimit = true
  },
  {
    name = CHS[7150580],
    iconPath = ResMgr:getItemIconPath(2172),
    showLimit = false
  },
  {
    name = CHS[7150581],
    iconPath = ResMgr:getItemIconPath(2307),
    showLimit = true
  },
  {
    name = CHS[7150582],
    iconPath = ResMgr:getItemIconPath(2171),
    showLimit = true
  },
  {
    name = CHS[7150584],
    iconPath = ResMgr:getItemIconPath(2099),
    showLimit = true
  },
  {
    name = CHS[7150583],
    iconPath = ResMgr:getItemIconPath(2098),
    showLimit = true
  }
}
local ITEM_POS = cc.p(145, 172)
function AnniversaryMallDlg:init()
  self:bindListener("InfoButton", self.onInfoButton)
  self.itemPanel = self:retainCtrl("ListUnitPanel")
  self.scorllView = self:getControl("ItemListScrollView")
  GiftMgr:requestAnniversaryMallInfo()
  self:hookMsg("MSG_NEW_DIST_ONLINEMALL_ITEM_LIST")
end
function AnniversaryMallDlg:setData(data)
  self.dlgData = data
  self:refreshCoin(data.coin)
  self:refreshActivityTime(data.act_end_time, data.shop_end_time)
  self:refreshItemList(data)
end
function AnniversaryMallDlg:refreshItemList(data)
  self.scorllView:removeAllChildren()
  for i = 1, data.count do
    local info = data[i]
    local itemPanel = self.itemPanel:clone()
    info.index = i
    self:setSingleItemInfo(itemPanel, info)
    if i <= 4 then
      itemPanel:setPosition(ITEM_POS.x * (i - 1), ITEM_POS.y)
    else
      itemPanel:setPosition(ITEM_POS.x * (i - 5), 0)
    end
    self.scorllView:addChild(itemPanel)
  end
end
function AnniversaryMallDlg:setSingleItemInfo(panel, info)
  local itemCfg = ITEM_CFG[info.index]
  info.coin = self.dlgData.coin
  info.name = itemCfg.name
  info.showLimit = itemCfg.showLimit
  if info.name == CHS[7150582] then
    info.bind = 1
  end
  self:setImage("IconImage", itemCfg.iconPath, panel)
  info.iconPath = itemCfg.iconPath
  local image = self:getControl("IconImage", nil, panel)
  if info.showLimit then
    if info.bind > 0 then
      InventoryMgr:addLogoTimeLimit(image)
    else
      InventoryMgr:addLogoBinding(image)
    end
  end
  local numText, fontColor = gf:getArtFontMoneyDesc(tonumber(info.amount))
  local iconImage = self:getControl("IconImage", nil, panel)
  if 0 < info.amount then
    self:setNumImgForPanel("LastNumPanel", fontColor, numText, false, LOCATE_POSITION.MID, 23, panel)
    self:setCtrlVisible("SellOutImage", false, panel)
    gf:resetImageView(iconImage)
  else
    self:setNumImgForPanel("LastNumPanel", ART_FONT_COLOR.RED, numText, false, LOCATE_POSITION.MID, 23, panel)
    self:setCtrlVisible("SellOutImage", true, panel)
    gf:grayImageView(iconImage)
  end
  local coinText, fontColor = gf:getArtFontMoneyDesc(tonumber(info.price))
  self:setNumImgForPanel("CoinValuePanel", fontColor, coinText, false, LOCATE_POSITION.MID, 23, panel)
  self:getControl("ItemPanel", nil, panel).info = info
  self:blindLongPress("ItemPanel", self.onItemPanel, self.onClickItem, panel)
  panel.info = info
  self:bindTouchEndEventListener(panel, function()
    self:onBuyItemPanel(panel.info)
  end)
end
function AnniversaryMallDlg:refreshCoin(num)
  local coinText, fontColor = gf:getArtFontMoneyDesc(tonumber(num))
  self:setNumImgForPanel("CoinValuePanel", fontColor, coinText, false, LOCATE_POSITION.MID, 23, "ListTitlePanel")
end
function AnniversaryMallDlg:refreshActivityTime(actEndTime, exchangeEndTime)
  local root = self:getControl("TimePanel")
  local curTime = gf:getServerTime()
  if actEndTime == 0 or actEndTime < curTime then
    self:setLabelText("TimeLabel_1", CHS[7150585], root)
    self:setLabelText("TimeLabel_1_1", "", root)
    if exchangeEndTime == 0 or exchangeEndTime < curTime then
    else
      self:setCtrlVisible("InfoLabelPanel1", false)
      self:setCtrlVisible("InfoLabelPanel2", true)
    end
  else
    local endTimeStr1 = gf:getServerDate("%Y-%m-%d ", actEndTime)
    local endTimeStr2 = gf:getServerDate("%H:%M", actEndTime)
    self:setLabelText("TimeLabel_1", endTimeStr1, root)
    self:setLabelText("TimeLabel_1_1", endTimeStr2, root)
  end
  if exchangeEndTime == 0 or exchangeEndTime < curTime then
    self:setLabelText("TimeLabel_2", CHS[7150585], root)
    self:setLabelText("TimeLabel_2_1", "", root)
  else
    local exchangeTimeStr1 = gf:getServerDate("%Y-%m-%d ", exchangeEndTime)
    local exchangeTimeStr2 = gf:getServerDate("%H:%M", exchangeEndTime)
    self:setLabelText("TimeLabel_2", exchangeTimeStr1, root)
    self:setLabelText("TimeLabel_2_1", exchangeTimeStr2, root)
  end
end
function AnniversaryMallDlg:cleanup()
  self.dlgData = nil
  DlgMgr:closeDlg("ExchangeMementoDlg")
  DlgMgr:closeDlg("ForeverCustomTitleDlg")
end
function AnniversaryMallDlg:onBuyItemPanel(info)
  if not self.dlgData then
    return
  end
  if self.dlgData.shop_end_time == 0 then
    gf:ShowSmallTips(CHS[7150586])
    return
  end
  if 0 >= info.amount then
    gf:ShowSmallTips(CHS[7150587])
    return
  end
  if info.name == CHS[7150580] then
    local titleDlg = DlgMgr:openDlg("ForeverCustomTitleDlg")
    titleDlg:setData(info)
  else
    local exchangeDlg = DlgMgr:openDlg("ExchangeMementoDlg")
    exchangeDlg:setData(info)
  end
end
function AnniversaryMallDlg:onClickItem(sender, eventType)
  self:onBuyItemPanel(sender.info)
end
function AnniversaryMallDlg:onItemPanel(sender, eventType)
  local rect = self:getBoundingBoxInWorldSpace(sender)
  local itemInfo = gf:deepCopy(sender.info)
  if itemInfo.name == CHS[7150580] or itemInfo.name == CHS[7150582] then
    local dlg = DlgMgr:openDlg("BonusInfo2Dlg")
    if itemInfo.name == CHS[7150580] then
      dlg:setRewardInfo({
        basicInfo = {
          itemInfo.name,
          CHS[7150600]
        },
        imagePath = ResMgr.ui.small_title,
        limted = true,
        resType = 1,
        time_limited = false
      })
    else
      dlg:setRewardInfo({
        basicInfo = {
          CHS[7150598],
          string.format("“%s”", itemInfo.name)
        },
        imagePath = ResMgr.ui.small_title,
        limted = false,
        resType = 1,
        time_limited = true
      })
    end
    dlg.root:setAnchorPoint(0, 0)
    dlg:setFloatingFramePos(rect)
  else
    local dlg = DlgMgr:openDlg("ItemInfoDlg")
    itemInfo.isGuard = false
    itemInfo.gift = 2
    itemInfo.not_sell = 1
    itemInfo.deadline = itemInfo.bind
    if itemInfo.name == CHS[7150578] then
      itemInfo.limit_use_time = 0
    end
    dlg:setInfoFormCard(itemInfo)
    dlg:setFloatingFramePos(rect)
  end
end
function AnniversaryMallDlg:onInfoButton(sender, eventType)
  if not self.dlgData then
    return
  end
  local dlg = DlgMgr:openDlg("AnniversaryMallDlgRuleDlg")
  local titleRoot = dlg.scrollView
  local image = ccui.ImageView:create(ResMgr.ui.reward_big_anniversary, ccui.TextureResType.plistType)
  image:setPosition(110, 205)
  image:setScale(0.35)
  titleRoot:addChild(image)
  local label = ccui.Text:create()
  local coinText, _ = gf:getArtFontMoneyDesc(tonumber(self.dlgData.allCoin))
  label:setString(coinText .. "/6,666")
  label:setAnchorPoint(0, 0.5)
  label:setFontSize(18)
  label:setColor(RULE_DLG_CFG.CONTENT_COLOR)
  label:setPosition(130, 208)
  titleRoot:addChild(label)
end
function AnniversaryMallDlg:MSG_NEW_DIST_ONLINEMALL_ITEM_LIST(data)
  self:setData(data)
end
return AnniversaryMallDlg
