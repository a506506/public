local BaoscclgmDlg = Singleton("BaoscclgmDlg", Dialog)
local ARPanel = require("ctrl/AddReducePanel")
local MIN_NUM = 1
local MAX_NUM = 10
local PRICE = 60
function BaoscclgmDlg:init()
  self:bindListener("ExchangeButton", self.onExchangeButton)
  self.limitNum = MAX_NUM
  self.arPanel2 = ARPanel.new(self, "AddButton", "ReduceButton", nil, true, nil, 1, 1)
  self.arPanel2:setClickLimitPara(MIN_NUM, self.limitNum, nil, nil)
  self.arPanel2:bindNumInput("MoneyValueLabel", "ExchangeNumPanel")
  self:setNumImgForPanel("CoinNumPanel", ART_FONT_COLOR.DEFAULT, PRICE, false, LOCATE_POSITION.CENTER, 23, "ItemPanel")
  self.num = 1
  self:hookMsg("MSG_GHOST_2020_BSCCL_DATA")
end
function BaoscclgmDlg:setData(data)
  self.limitNum = data.tg_max_buy_time - data.tg_buy_time
  MAX_NUM = data.tg_max_buy_time
  self.arPanel2:setClickLimitPara(MIN_NUM, self.limitNum, nil, nil)
  if self.limitNum == 0 then
    self:setLabelText("NumLabel", CHS[5401030], "ItemPanel")
  else
    self:setLabelText("NumLabel", string.format(CHS[5401029], self.limitNum), "ItemPanel")
  end
  self:updateNum(math.max(math.min(self.num, self.limitNum), MIN_NUM))
end
function BaoscclgmDlg:onExchangeButton(sender, eventType)
  if DlgMgr:sendMsg("BaoscclDlg", "checkEndTime") then
    return
  end
  if self.num == 0 or self.num > self.limitNum then
    gf:ShowSmallTips(string.format(CHS[5401028], MAX_NUM))
    return
  end
  if self:checkSafeLockRelease("onExchangeButton", sender) then
    return
  end
  local tips = gf:getCostCoinTips(CHS[5401032], PRICE * self.num, self.num)
  if not tips then
    gf:CmdToServer("CMD_GHOST2020_BUY_TANGGUO", {
      num = self.num
    })
  else
    gf:confirm(tips, function()
      gf:CmdToServer("CMD_GHOST2020_BUY_TANGGUO", {
        num = self.num
      })
    end)
  end
end
function BaoscclgmDlg:updateNum(num, key)
  self:setLabelText("MoneyValueLabel", num, "ExchangeNumPanel")
  self:setCtrlEnabled("AddButton", num < self.limitNum)
  self:setCtrlEnabled("ReduceButton", num > MIN_NUM)
  local strMoney, color = gf:getMoneyDesc(PRICE * num, true)
  self:setNumImgForPanel("Label1", ART_FONT_COLOR.DEFAULT, strMoney, false, LOCATE_POSITION.CENTER, 23, "ExchangeButton")
  self.num = num
end
function BaoscclgmDlg:MSG_GHOST_2020_BSCCL_DATA(data)
  self:setData(data)
end
return BaoscclgmDlg
