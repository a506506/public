local CockFightingBasicDlg = Singleton("CockFightingBasicDlg", Dialog)
local CHICKEN_RES_CFG = {
  XiaPanel = {
    imgPath1 = "CockFightImage/SmallCockImage00001.png",
    imgPath2 = "CockFightImage/BigCockImage00001.png"
  },
  ZhongPanel = {
    imgPath1 = "CockFightImage/SmallCockImage00002.png",
    imgPath2 = "CockFightImage/BigCockImage00002.png"
  },
  ShangPanel = {
    imgPath1 = "CockFightImage/SmallCockImage00003.png",
    imgPath2 = "CockFightImage/BigCockImage00003.png"
  },
  BaoPanel = {
    imgPath1 = "CockFightImage/SmallCockImage00004.png",
    imgPath2 = "CockFightImage/BigCockImage00004.png"
  },
  LaoPanel = {
    imgPath1 = "CockFightImage/SmallCockImage00005.png",
    imgPath2 = "CockFightImage/BigCockImage00005.png"
  }
}
function CockFightingBasicDlg:init()
  cc.SpriteFrameCache:getInstance():addSpriteFrames("ui/CockFightImage.plist")
end
function CockFightingBasicDlg:getBasicCardChick(panelName)
  local magic = ArmatureMgr:createArmature(ResMgr.ArmatureMagic.qmdz_card_effect.name)
  local bone = magic:getBone("smallz")
  if bone then
    local skin = ccs.Skin:createWithSpriteFrameName(CHICKEN_RES_CFG[panelName].imgPath1)
    bone:addDisplay(skin, 1)
    bone:changeDisplayWithIndex(1, true)
  end
  return magic
end
function CockFightingBasicDlg:setMyChickenIn(panelName, callBack)
  local magic = self:getBasicCardChick(panelName)
  local panel = self:getControl(panelName, nil, "MyselfCockPanel")
  panel = self:getControl("SmallCockActionPanel", nil, panel)
  if panel:getChildByName("Chick") then
    panel:removeChildByName("Chick")
  end
  panel:addChild(magic)
  local size = panel:getContentSize()
  magic:setPosition(size.width * 0.5, size.height * 0.5)
  magic:setAnchorPoint(0.5, 0.5)
  magic:setName("Chick")
  magic:getAnimation():play("Top101", -1, 0)
  magic:setLocalZOrder(100)
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete then
      magic:getAnimation():play("Top102", -1, -1)
      if callBack then
        callBack()
      end
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
function CockFightingBasicDlg:setOppChickenIn(panelName, callBack)
  local magic = self:getBasicCardChick(panelName)
  local panel = self:getControl(panelName, nil, "CompetitorCockPanel")
  panel = self:getControl("SmallCockActionPanel", nil, panel)
  if panel:getChildByName("Chick") then
    panel:removeChildByName("Chick")
  end
  panel:addChild(magic)
  local size = panel:getContentSize()
  magic:setPosition(size.width * 0.5, size.height * 0.5)
  magic:setAnchorPoint(0.5, 0.5)
  magic:setName("Chick")
  magic:getAnimation():play("Top201", -1, 0)
  magic:setLocalZOrder(100)
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete then
      magic:getAnimation():play("Top202", -1, -1)
      if callBack then
        callBack()
      end
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
function CockFightingBasicDlg:setMyChickenOut(panelName, callBack)
  local panel = self:getControl(panelName, nil, "MyselfCockPanel")
  panel = self:getControl("SmallCockActionPanel", nil, panel)
  local magic = panel:getChildByName("Chick")
  if not magic then
    return
  end
  magic:getAnimation():play("Top103", -1, 0)
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete and callBack then
      callBack()
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
function CockFightingBasicDlg:setOppChickenOut(panelName, callBack)
  local panel = self:getControl(panelName, nil, "CompetitorCockPanel")
  panel = self:getControl("SmallCockActionPanel", nil, panel)
  local magic = panel:getChildByName("Chick")
  if not magic then
    return
  end
  magic:getAnimation():play("Top203", -1, 0)
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete and callBack then
      callBack()
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
function CockFightingBasicDlg:setFightChickMagic(panelName, actionName, myType, oppType, callBack)
  local panel = self:getControl(panelName)
  local magic = ArmatureMgr:createArmature(ResMgr.ArmatureMagic.qmdz_card_effect.name)
  local bone1 = magic:getBone("Rightbigz")
  local bone2 = magic:getBone("Leftbigz")
  if actionName == "Top303" then
    if bone1 then
      local skin = ccs.Skin:createWithSpriteFrameName(CHICKEN_RES_CFG[oppType].imgPath2)
      bone1:addDisplay(skin, 1)
      bone1:changeDisplayWithIndex(1, true)
    end
    if bone2 then
      local skin = ccs.Skin:createWithSpriteFrameName(CHICKEN_RES_CFG[myType].imgPath2)
      bone2:addDisplay(skin, 1)
      bone2:changeDisplayWithIndex(1, true)
    end
  else
    if bone1 then
      local skin = ccs.Skin:createWithSpriteFrameName(CHICKEN_RES_CFG[myType].imgPath2)
      bone1:addDisplay(skin, 1)
      bone1:changeDisplayWithIndex(1, true)
    end
    if bone2 then
      local skin = ccs.Skin:createWithSpriteFrameName(CHICKEN_RES_CFG[oppType].imgPath2)
      bone2:addDisplay(skin, 1)
      bone2:changeDisplayWithIndex(1, true)
    end
  end
  panel:addChild(magic)
  local size = panel:getContentSize()
  magic:setPosition(size.width * 0.5, size.height * 0.5)
  magic:setAnchorPoint(0.5, 0.5)
  magic:setName("Chick")
  magic:getAnimation():play(actionName, -1, 0)
  magic:setLocalZOrder(100)
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete and callBack then
      callBack(magic)
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
function CockFightingBasicDlg:setFightChickIn(myType, oppType, callBack)
  self:getControl("BottomFightingActionPanel"):removeAllChildren()
  self:getControl("TopFightingActionPanel01"):removeAllChildren()
  self:setFightChickMagic("BottomFightingActionPanel", "Top301", myType, oppType, callBack)
end
function CockFightingBasicDlg:setChickFightResult(result, myType, oppType, callBack)
  self:getControl("BottomFightingActionPanel"):removeAllChildren()
  self:getControl("TopFightingActionPanel01"):removeAllChildren()
  if result == 1 then
    self:setFightChickMagic("TopFightingActionPanel01", "Top302", myType, oppType, callBack)
  elseif result == 2 then
    self:setFightChickMagic("TopFightingActionPanel01", "Top303", myType, oppType, callBack)
  elseif result == 3 then
    self:setFightChickMagic("TopFightingActionPanel01", "Top304", myType, oppType, callBack)
  end
end
function CockFightingBasicDlg:setChickFightOut(result, myType, oppType, callBack)
  self:getControl("BottomFightingActionPanel"):removeAllChildren()
  self:getControl("TopFightingActionPanel01"):removeAllChildren()
  if result == 1 then
    self:setFightChickMagic("BottomFightingActionPanel", "Top401", myType, oppType, function(magic)
      magic:removeFromParent()
      if callBack then
        callBack()
      end
    end)
  elseif result == 2 then
    self:setFightChickMagic("BottomFightingActionPanel", "Top402", myType, oppType, function(magic)
      magic:removeFromParent()
      if callBack then
        callBack()
      end
    end)
  elseif result == 3 then
    self:setFightChickMagic("BottomFightingActionPanel", "Top403", myType, oppType, function(magic)
      magic:removeFromParent()
      if callBack then
        callBack()
      end
    end)
  end
end
function CockFightingBasicDlg:setMyChickenFailIn(panelName, callBack)
  local magic = self:getBasicCardChick(panelName)
  local panel = self:getControl(panelName, nil, "MyselfCockPanel")
  panel = self:getControl("SmallCockActionPanel", nil, panel)
  if panel:getChildByName("Chick") then
    panel:removeChildByName("Chick")
  end
  panel:addChild(magic)
  local size = panel:getContentSize()
  magic:setPosition(size.width * 0.5, size.height * 0.5)
  magic:setAnchorPoint(0.5, 0.5)
  magic:setName("Chick")
  magic:getAnimation():play("Top104", -1, 0)
  magic:setLocalZOrder(100)
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete then
      magic:getAnimation():play("Top105", -1, -1)
      if callBack then
        callBack()
      end
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
function CockFightingBasicDlg:setOppChickenFailIn(panelName)
  local magic = self:getBasicCardChick(panelName)
  local panel = self:getControl(panelName, nil, "CompetitorCockPanel")
  panel = self:getControl("SmallCockActionPanel", nil, panel)
  if panel:getChildByName("Chick") then
    panel:removeChildByName("Chick")
  end
  panel:addChild(magic)
  local size = panel:getContentSize()
  magic:setPosition(size.width * 0.5, size.height * 0.5)
  magic:setAnchorPoint(0.5, 0.5)
  magic:setName("Chick")
  magic:getAnimation():play("Top204", -1, 0)
  magic:setLocalZOrder(100)
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete then
      magic:getAnimation():play("Top205", -1, -1)
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
function CockFightingBasicDlg:setChickBackToCard(result, myType, oppType, callBack)
  if result == 1 then
    self:setMyChickenIn(myType, callBack)
    self:setOppChickenFailIn(oppType)
  elseif result == 2 then
    self:setMyChickenFailIn(myType, callBack)
    self:setOppChickenIn(oppType)
  elseif result == 3 then
    self:setMyChickenFailIn(myType, callBack)
    self:setOppChickenFailIn(oppType)
  end
end
function CockFightingBasicDlg:playChickFight(result, myType, oppType, callBack)
  self:setFightChickIn(myType, oppType, function()
    self:setChickFightResult(result, myType, oppType, function()
      self:setChickFightOut(result, myType, oppType, function()
        if callBack then
          callBack()
        end
      end)
    end)
  end)
end
function CockFightingBasicDlg:setRoundOverMyChidckOut(panelName, result, callBack)
  local panel = self:getControl(panelName, nil, "MyselfCockPanel")
  panel = self:getControl("SmallCockActionPanel", nil, panel)
  local magic = panel:getChildByName("Chick")
  if not magic then
    return
  end
  if result == 1 then
    magic:getAnimation():play("Top103", -1, 0)
  else
    magic:getAnimation():play("Top106", -1, 0)
  end
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete and callBack then
      callBack()
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
function CockFightingBasicDlg:setRoundOverOppChidckOut(panelName, result, callBack)
  local panel = self:getControl(panelName, nil, "CompetitorCockPanel")
  panel = self:getControl("SmallCockActionPanel", nil, panel)
  local magic = panel:getChildByName("Chick")
  if not magic then
    return
  end
  if result == 1 then
    magic:getAnimation():play("Top203", -1, 0)
  else
    magic:getAnimation():play("Top206", -1, 0)
  end
  local function func(sender, etype, id)
    if etype == ccs.MovementEventType.complete and callBack then
      callBack()
    end
  end
  magic:getAnimation():setMovementEventCallFunc(func)
end
return CockFightingBasicDlg
