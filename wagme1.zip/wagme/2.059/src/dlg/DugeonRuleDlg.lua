local DugeonRuleDlg = Singleton("DugeonRuleDlg", Dialog)
function DugeonRuleDlg:init()
  self.type = nil
end
function DugeonRuleDlg:setType(type)
  self.type = type
  self:setCtrlVisible("DugeonRulePanel", type == "fuben")
  self:setCtrlVisible("ActivityRulePanel", type == "zhishujiefuben")
  self:setCtrlVisible("ManbuhuacongPanel", type == "manbuhuacong")
  self:setCtrlVisible("ZongLiaoPanel", type == "ZongLiao")
  self:setCtrlVisible("CaiJiMeiGuiPanel", type == "valentine_2019_cjmg")
  self:setCtrlVisible("AprilFoolsDayPanel", type == "qmjh")
  self:setCtrlVisible("CaseMiaoshcPanel", type == "TanAnMshc")
  if type == "qmjh" then
    local task = TaskMgr:getTaskByName(CHS[5450341])
    if task and task.task_extra_para then
      local info = gf:split(task.task_extra_para, "|")
      for i = 1, 5 do
        if string.isNilOrEmpty(info[i]) then
          self:setLabelText("Label_" .. i, CHS[5450346], "AprilFoolsDayPanel")
        else
          self:setLabelText("Label_" .. i, info[i], "AprilFoolsDayPanel")
        end
      end
    end
  end
end
function DugeonRuleDlg:cleanup()
  if self.type == "ZongLiao" then
    gf:CmdToServer("CMD_DUANWU_2018_EXPLAIN")
  elseif self.type == "valentine_2019_cjmg" then
    local task = TaskMgr:getTaskByName(CHS[4101237])
    if task and task.task_extra_para == "2" then
      gf:CmdToServer("CMD_VALENTINE_2019_PREPARE_START_GAME")
    end
  end
end
function DugeonRuleDlg:onDlgOpened(type)
  self:setType(type[1])
end
return DugeonRuleDlg
