local FamousDlg = Singleton("FamousDlg", Dialog)
local MENU_ONE = {
  CHS[7260012],
  CHS[7260013],
  CHS[7260014],
  CHS[7260015],
  CHS[7260016]
}
local SHARE_POS = cc.p(957, 288)
local FAMOUS_TYPE = {
  FAMOUS_RANK_TAO_WIN = 1,
  FAMOUS_RANK_PHY_POWER = 3,
  FAMOUS_RANK_MAG_POWER = 4,
  FAMOUS_RANK_DEF = 5,
  FAMOUS_RANK_SPEED = 6,
  FAMOUS_RANK_ACHIEVE = 7,
  FAMOUS_RANK_POPULAR = 8,
  FAMOUS_RANK_WORSHIP = 9
}
local MENU_TWO = {
  [CHS[7260012]] = {
    CHS[2000745],
    CHS[7260022],
    CHS[7260021],
    CHS[7260020],
    CHS[7260019],
    CHS[7260018],
    CHS[7260017]
  },
  [CHS[7260013]] = {
    CHS[7260023],
    CHS[7260024],
    CHS[7260025],
    CHS[7260026]
  }
}
local ATTRIBUTION = {
  [CHS[7260012]] = {
    CHS[7260033],
    ResMgr.ui.famous_paibian_no1,
    FAMOUS_TYPE.FAMOUS_RANK_TAO_WIN
  },
  [CHS[7260023]] = {
    CHS[7260037],
    ResMgr.ui.famous_paibian_no2,
    FAMOUS_TYPE.FAMOUS_RANK_PHY_POWER
  },
  [CHS[7260024]] = {
    CHS[7260038],
    ResMgr.ui.famous_paibian_no3,
    FAMOUS_TYPE.FAMOUS_RANK_MAG_POWER
  },
  [CHS[7260025]] = {
    CHS[7260039],
    ResMgr.ui.famous_paibian_no4,
    FAMOUS_TYPE.FAMOUS_RANK_DEF
  },
  [CHS[7260026]] = {
    CHS[7260040],
    ResMgr.ui.famous_paibian_no5,
    FAMOUS_TYPE.FAMOUS_RANK_SPEED
  },
  [CHS[7260014]] = {
    CHS[7260034],
    ResMgr.ui.famous_paibian_no6,
    FAMOUS_TYPE.FAMOUS_RANK_ACHIEVE
  },
  [CHS[7260015]] = {
    CHS[7260035],
    ResMgr.ui.famous_paibian_no7,
    FAMOUS_TYPE.FAMOUS_RANK_POPULAR
  },
  [CHS[7260016]] = {
    CHS[7260036],
    ResMgr.ui.famous_paibian_no8,
    FAMOUS_TYPE.FAMOUS_RANK_WORSHIP
  }
}
local SCALE = 1.1
function FamousDlg:init()
  self.usersPosition = {
    {x = 960, y = 415},
    {x = 780, y = 301},
    {x = 1140, y = 301},
    {x = 654, y = 179},
    {x = 1266, y = 179}
  }
  self.paibian = {x = 960, y = 640}
  SHARE_POS = cc.p(960, 288)
  self.charLayer = ccui.Layout:create()
  self:setFullScreen()
  self:setImgFullScreen()
  self.paibianName = nil
  self:setCtrlContentSize("TopyPanel", self.root:getContentSize().width)
  self:createShareButton(self:getControl("SharePanel", Const.UIButton, "TopyPanel"), SHARE_FLAG.FAMOUS, nil, function()
    self:hideTipsPanel()
    self:showSharePanel(true)
  end, function()
    self:showSharePanel(false)
  end)
  self:bindListener("ClosePanel", self.onClickPanel, "TopyPanel", true)
  self:bindListener("InfoPanel", self.onClickPanel, "TopyPanel", true)
  self:bindListener("Button", self.onBuyBtnButton, "BuyBtnPanel")
  self:bindListener("TypeButton", self.onTypeButton, "TypeButtonPanel")
  self:getControl("TopyPanel"):setVisible(false)
  self:setCtrlVisible("PressedImageView", false)
  self:bindFloatingEvent("ListPanel", nil, function()
    self:setCtrlVisible("NormalImageView", true)
    self:setCtrlVisible("PressedImageView", false)
  end)
  self:bindFloatingEvent("InformationPanel")
  self:setCtrlVisible("TimePanel", false, "LikePanel")
  self:setCtrlVisible("ValuePanel", false, "RankingPanel")
  self:setCtrlVisible("ValuePanel", false, "PointsPanel")
  self.item1 = self:retainCtrl("202_PartsTipsPanel", "ListPanel1")
  self.item2 = self:retainCtrl("201_PartsTipsPanel", "ListPanel1")
  self.listPanel1 = self:getControl("ListPanel1")
  self.listPanel2 = self:getControl("ListPanel2")
  self.listView1 = self:getControl("101_PartsTipsPanel", nil, "ListPanel1")
  self.listView2 = self:getControl("PartsTipsPanel", nil, "ListPanel2")
  self.heightInterval = self.listPanel1:getContentSize().height - self.listView1:getContentSize().height
  self.widthInterval = self.listPanel1:getContentSize().width - self.listView1:getContentSize().width
  self.ListView2Open = {false, false}
  self.listView1:removeAllChildren()
  self.listView2:removeAllChildren()
  self.famousTipsPanel = self:retainCtrl("FamousTipsPanel")
  local guideKey = string.format("famouse_dlg_show_guide_%s", Me:queryBasic("gid"))
  local userDefault = cc.UserDefault:getInstance()
  if not userDefault:getBoolForKey(guideKey, false) then
    userDefault:setBoolForKey(guideKey, true)
    self:showFamousTipsPanel()
  end
  self:hookMsg("MSG_FAMOUS_YESTODAY_DATA")
  self:hookMsg("MSG_FAMOUS_OPEN_UI")
  self:hookMsg("MSG_FAMOUS_WORSHIP")
  self:hookMsg("MSG_OPEN_MRT_EXCHANGE_SHOP")
  self:hookMsg("MSG_CHAR_INFO")
  self:hookMsg("MSG_CHAR_INFO_EX")
  self:hookMsg("MSG_CROSS_SERVER_CHAR_INFO")
  self:hookMsg("MSG_FAMOUS_CHAR_INFO")
  self:hookMsg("MSG_OFFLINE_CHAR_INFO")
  self:initPanelList()
  self:initUserPanel()
end
function FamousDlg:createShareButton(btnCtrl, typeStr, fun, preFun, backFun)
  if nil == btnCtrl then
    return
  end
  if ShareMgr:isShowShareBtn() then
    btnCtrl:setVisible(true)
  else
    btnCtrl:setVisible(false)
    return
  end
  self:bindTouchEventListener(btnCtrl, function(widget, sender, eventType)
    local button = self:getControl("Button", nil, sender:getName())
    if eventType == ccui.TouchEventType.began then
      button:setScale(SCALE)
    elseif eventType == ccui.TouchEventType.canceled then
      button:setScale(1)
    elseif eventType == ccui.TouchEventType.ended then
      button:setScale(1)
      if "function" == type(fun) then
        fun(self)
      else
        ShareMgr:share(typeStr, preFun, backFun)
      end
    end
  end)
end
function FamousDlg:showFamousTipsPanel()
  local panel = self.famousTipsPanel:clone()
  local pos = cc.p(self.usersPosition[1].x + 48, self.usersPosition[1].y + 8)
  panel:setPosition(pos)
  panel:setVisible(true)
  self:setColorText(CHS[7120369], "TextPanel", panel, nil, nil, COLOR3.WHITE, 17)
  local famousTipsPanel = ccui.Layout:create()
  famousTipsPanel:setContentSize(self.root:getContentSize())
  self.root:addChild(famousTipsPanel, 2)
  famousTipsPanel:addChild(panel)
  self.famousTipsPanel = famousTipsPanel
end
function FamousDlg:hideTipsPanel()
  if self.famousTipsPanel then
    self.famousTipsPanel:setVisible(false)
  end
end
function FamousDlg:initPanelList()
  if DistMgr:curIsTestDist() and MENU_ONE[1] == CHS[7260012] then
    table.remove(MENU_ONE, 1)
  end
  local count = #MENU_ONE
  self.listView1:setContentSize(self.listView1:getContentSize().width, count * self.item1:getContentSize().height)
  self.listPanel1:setContentSize(self.listPanel1:getContentSize().width, count * self.item1:getContentSize().height + self.heightInterval)
  local random1 = math.random(1, count - 1)
  local random2
  if MENU_TWO[MENU_ONE[random1]] then
    random2 = math.random(1, #MENU_TWO[MENU_ONE[random1]])
  end
  for i = 1, count do
    local itemPanel, btn
    if MENU_TWO[MENU_ONE[i]] then
      itemPanel = self.item1:clone()
      btn = self:getControl("Button", nil, itemPanel)
    else
      itemPanel = self.item2:clone()
      btn = self:getControl("Button", nil, itemPanel)
    end
    btn:setTag(i)
    self:bindTouchEndEventListener(btn, self.selectedItem1)
    self:setLabelText("TextLabel", MENU_ONE[i], itemPanel)
    self:setCtrlVisible("PressedPanel", false, itemPanel)
    if i == random1 then
      self:setCtrlVisible("PressedPanel", true, itemPanel)
      self:setLabelText("TypeLabel", MENU_ONE[random1], "TypeButtonPanel")
      self:selectedItem1(btn, nil, nil, nil, true)
      if random2 then
        for k, v in pairs(self.listView2:getChildren()) do
          if k == random2 then
            self:selectedItem2(v:getChildren()[1])
          end
        end
      end
    end
    self.listView1:addChild(itemPanel)
  end
end
function FamousDlg:selectedItem1(sender, eventType, data, isRedDotRemoved, notChooseItem2)
  self:hideAllInvoded1()
  local curIdx = sender:getTag()
  local root = sender:getParent()
  if self.curSelectedItem1 ~= curIdx then
    self.paibianName = nil
  end
  self.curSelectedItem1 = curIdx
  if MENU_TWO[MENU_ONE[curIdx]] then
    self:setCtrlVisible("PressedPanel", true, root)
    if self.ListView2Open[curIdx] then
      self:setCtrlVisible("PressedPanel", false, root)
      self:setCtrlVisible("ListPanel2", false)
      self.ListView2Open[curIdx] = false
    elseif not self.paibianName then
      self:openListView2(curIdx)
      if not notChooseItem2 then
        if MENU_ONE[curIdx] == CHS[7260012] then
          self:sendReqFamousPersonInfoCmd(1, "130-139")
          self.paibianName = MENU_TWO[MENU_ONE[curIdx]][1]
        elseif MENU_ONE[curIdx] == CHS[7260013] then
          self:sendReqFamousPersonInfoCmd(3, "")
          self.paibianName = MENU_TWO[CHS[7260013]][1]
        end
      end
    else
      self:setCtrlVisible("PressedPanel", true, root)
      self:setCtrlVisible("ListPanel2", true)
      self.ListView2Open[curIdx] = true
    end
  else
    self:sendReqFamousPersonInfoCmd(ATTRIBUTION[MENU_ONE[curIdx]][3], "")
    self:setCtrlVisible("PressedPanel", true, root)
    self:setCtrlVisible("ListPanel2", false)
    self.ListView2Open = {false, false}
    self.paibianName = MENU_ONE[curIdx]
  end
  self:setLabelText("TypeLabel", MENU_ONE[curIdx], "TypeButtonPanel")
  if not notChooseItem2 then
    self:hideTipsPanel()
  end
end
function FamousDlg:selectedItem2(sender, eventType)
  for k, v in pairs(self.listView2:getChildren()) do
    self:setCtrlVisible("PressedPanel", false, v)
  end
  local root = sender:getParent()
  self:setCtrlVisible("PressedPanel", true, root)
  local tag = sender:getTag()
  local name = sender:getName()
  local curSelectedItem1 = tonumber(string.sub(tag, 0, 1))
  local curSelectedItem2 = tonumber(string.sub(tag, -1))
  local famous_type
  local level_index = ""
  if MENU_ONE[curSelectedItem1] == CHS[7260012] then
    famous_type = 1
    level_index = string.gsub(MENU_TWO[MENU_ONE[curSelectedItem1]][curSelectedItem2], "~", "-")
  elseif MENU_ONE[curSelectedItem1] == CHS[7260013] then
    famous_type = ATTRIBUTION[MENU_TWO[MENU_ONE[curSelectedItem1]][curSelectedItem2]][3]
  end
  self:sendReqFamousPersonInfoCmd(famous_type, level_index)
  self.curSelectedItem1 = curSelectedItem1
  self.paibianName = name
  if eventType then
    self:hideTipsPanel()
  end
end
function FamousDlg:addPaiBian(curSelectedItem1, paibianName)
  local imgRes
  if MENU_ONE[curSelectedItem1] ~= CHS[7260012] then
    imgRes = ATTRIBUTION[paibianName][2]
  else
    imgRes = ATTRIBUTION[CHS[7260012]][2]
  end
  self.paibianImg:loadTexture(imgRes)
end
function FamousDlg:hideAllInvoded1()
  for k, v in pairs(self.listView1:getChildren()) do
    self:setCtrlVisible("PressedPanel", false, v)
  end
end
function FamousDlg:sendReqFamousPersonInfoCmd(famous_type, level_index)
  gf:CmdToServer("CMD_FAMOUS_OPEN_UI", {famous_type = famous_type, level_index = level_index})
end
function FamousDlg:openListView2(curIdx)
  local count = #MENU_TWO[MENU_ONE[curIdx]]
  self.listView2:removeAllChildren()
  self.listView2:setContentSize(self.listView2:getContentSize().width, count * self.item2:getContentSize().height)
  self.listPanel2:setContentSize(self.listPanel2:getContentSize().width, count * self.item2:getContentSize().height + self.heightInterval)
  for k, v in pairs(MENU_TWO[MENU_ONE[curIdx]]) do
    local itemPanel = self.item2:clone()
    local btn = self:getControl("Button", nil, itemPanel)
    btn:setTag(curIdx .. k)
    btn:setName(v)
    self:bindTouchEndEventListener(btn, self.selectedItem2)
    self:setLabelText("TextLabel", v, itemPanel)
    self:setCtrlVisible("PressedPanel", false, itemPanel)
    self.listView2:addChild(itemPanel)
  end
  self:setCtrlVisible("PressedPanel", true, self.listView2:getChildren()[1])
  self:setCtrlVisible("ListPanel2", true)
  self.ListView2Open = {false, false}
  self.ListView2Open[curIdx] = true
  local itemPanel1Begin = self.listPanel1:getPositionY() + self.listPanel1:getContentSize().height
  local curPosY = itemPanel1Begin - self.listPanel2:getContentSize().height
  self.listPanel2:setPositionY(curPosY)
end
function FamousDlg:initUserPanel()
  local root = self:getControl("FamousDlg")
  local sz = root:getContentSize()
  if self.charLayer then
    self.charLayer:removeAllChildren()
    self.charLayer:removeFromParent()
    self.charLayer = nil
  end
  self.charLayer = ccui.Layout:create()
  self.charLayer:setContentSize(sz)
  root:addChild(self.charLayer, 1)
  self:setCtrlVisible("SharePanel", false)
end
function FamousDlg:initUser(idx)
  local iniIdx = 0
  if idx then
    iniIdx = idx
  end
  local count
  if #self.famousInfo > 5 then
    count = 5
  else
    count = #self.famousInfo
  end
  self.charLayer:removeAllChildren()
  local isInFamous = false
  for i = 1, count do
    if self.famousInfo[i].gid == Me:queryBasic("gid") then
      isInFamous = true
    end
    self:createChar(self.famousInfo[i].dist .. " - " .. gf:getRealName(self.famousInfo[i].name), self:getAttributionByFamousType(self.famousType) .. "：" .. self.famousInfo[i].val, self.usersPosition[i].x - 0, self.usersPosition[i].y - 0, i, iniIdx, self.charLayer)
  end
  self:setCtrlVisible("SharePanel", isInFamous)
  self:addPaiBian(self.curSelectedItem1, self.paibianName)
end
function FamousDlg:onClickPanel(sender, eventType)
  local ctrlName = sender:getName()
  local button = self:getControl("Button", nil, ctrlName)
  if eventType == ccui.TouchEventType.began then
    button:setScale(SCALE)
  elseif eventType == ccui.TouchEventType.canceled then
    button:setScale(1)
  elseif eventType == ccui.TouchEventType.ended then
    button:setScale(1)
    if ctrlName == "ClosePanel" then
      self:onCloseButton()
    elseif ctrlName == "InfoPanel" then
      self:onInfoButton()
    end
  end
end
function FamousDlg:onCloseButton()
  self:playAnim(0)
end
function FamousDlg:showSharePanel(isShow)
  self:setCtrlVisible("TopyPanel", not isShow)
  self.charLayer:setVisible(not isShow)
  if self.shareLayer then
    self.shareLayer:setVisible(isShow)
  end
  if isShow then
    self.charLayer:setVisible(false)
    if not self.shareLayer then
      local root = self:getControl("FamousDlg")
      local sz = root:getContentSize()
      self.shareLayer = ccui.Layout:create()
      self.shareLayer:setContentSize(sz)
      root:addChild(self.shareLayer, 1)
    end
    self.shareLayer:removeAllChildren()
    local charInfo, rank
    for _, info in pairs(self.famousInfo) do
      if info.gid == Me:queryBasic("gid") then
        charInfo = info
        rank = _
      end
    end
    if not charInfo then
      return
    end
    local idx
    if self.famousType == FAMOUS_TYPE.FAMOUS_RANK_TAO_WIN then
      idx = 1
    elseif self.famousType == FAMOUS_TYPE.FAMOUS_RANK_WORSHIP then
      idx = 2
    else
      idx = 0
    end
    self:createChar(charInfo.dist .. " - " .. gf:getRealName(charInfo.name), self:getAttributionByFamousType(self.famousType) .. "：" .. charInfo.val, SHARE_POS.x, SHARE_POS.y, rank, idx, self.shareLayer, true)
  end
end
function FamousDlg:cleanup()
  if self.shareLayer then
    self.shareLayer:removeAllChildren()
    self.shareLayer:removeFromParent()
  end
  self.shareLayer = nil
  self.charWorShipData = nil
end
function FamousDlg:onInfoButton()
  if DistMgr:curIsTestDist() then
    DlgMgr:openDlg("FamousNeiceDlgRuleDlg")
  else
    DlgMgr:openDlg("FamousDlgRuleDlg")
  end
end
function FamousDlg:playAnim(frameNum)
  local sz = self.root:getContentSize()
  local magic = ArmatureMgr:createArmature(ResMgr.ArmatureMagic.famous_entry.name)
  magic:setPosition(sz.width / 2, sz.height / 2)
  gf:getTopLayer():addChild(magic, 3)
  local anim = magic:getAnimation()
  anim:play("Top")
  local function callback(sender, etype, id)
    if etype == ccs.MovementEventType.complete then
      self:getControl("TopyPanel"):setVisible(true)
    end
  end
  local frame = cc.Director:getInstance():getAnimationInterval()
  if frameNum == 0 then
    self:getControl("TopyPanel"):setVisible(false)
    performWithDelay(self.root, function()
      DlgMgr:sendMsg("SystemFunctionDlg", "playAnim", 30)
      DlgMgr:closeDlg(self.name)
    end, frame * 30)
  elseif frameNum == 30 then
    anim:gotoAndPlay(30)
    performWithDelay(self.root, function()
      self:getControl("TopyPanel"):setVisible(true)
    end, frame * 23)
  end
end
function FamousDlg:onBuyBtnButton()
  gf:CmdToServer("CMD_OPEN_MRT_EXCHANGE_SHOP")
end
function FamousDlg:changeTopyPanelStatus(bool)
  local topyPanel = self:getControl("TopyPanel")
  topyPanel:setVisible(bool)
end
function FamousDlg:onTypeButton()
  if self:getCtrlVisible("ListPanel") then
    self:setCtrlVisible("ListPanel", false)
  else
    self:setCtrlVisible("ListPanel", true)
    self:setCtrlVisible("NormalImageView", false)
    self:setCtrlVisible("PressedImageView", true)
  end
end
function FamousDlg:addShadow(suit_light_effect, x, y, layer)
  local magic
  if nil == suit_light_effect or 0 == suit_light_effect then
    magic = cc.Sprite:create(ResMgr.ui.char_shadow_img)
  else
    magic = gf:createLoopMagic(suit_light_effect)
  end
  magic:setPosition(x, y)
  layer:addChild(magic)
end
function FamousDlg:setCharNameLabel(color, str, fontSize, x, y, offsetSize, layer)
  local label = ccui.Text:create()
  label:setFontSize(fontSize)
  label:setColor(color)
  label:setString(str)
  local size = label:getContentSize()
  local bgImage = ccui.ImageView:create(ResMgr.ui.chenwei_name_bgimg)
  local bgImgSize = bgImage:getContentSize()
  bgImage:setScale9Enabled(true)
  bgImage:setContentSize(size.width + offsetSize, size.height)
  label:setPosition(size.width / 2 + offsetSize / 2, size.height / 2)
  local label2 = label:clone()
  label2:setPosition(size.width / 2 + offsetSize / 2 + 1, size.height / 2)
  label2:setColor(COLOR3.BLACK)
  bgImage:addChild(label2)
  bgImage:addChild(label)
  bgImage:setPosition(x, y)
  layer:addChild(bgImage, 2)
end
function FamousDlg:addLight(x, y, isUp, layer)
  local iconImg
  if isUp then
    iconImg = ccui.ImageView:create(ResMgr.ui.light_top)
  else
    iconImg = ccui.ImageView:create(ResMgr.ui.light_bottm)
  end
  iconImg:setPosition(x, y + 50)
  layer:addChild(iconImg)
end
function FamousDlg:createChar(name, attr, x, y, curIdx, daoAndFamousFlag, layer, isLight)
  local dir = 7
  if curIdx % 2 == 0 or curIdx == 1 then
    dir = 5
  end
  if isLight then
    self:addLight(x, y, nil, layer)
  end
  self:addShadow(self.famousInfo[curIdx].bottom_light_effect, x, y, layer)
  local char = self:setPortrait(layer, self.famousInfo[curIdx].icon, self.famousInfo[curIdx].weapon_icon, nil, true, nil, function()
  end, nil, self.famousInfo[curIdx].org_icon, nil, dir, nil, nil, self.famousInfo[curIdx].part_index, self.famousInfo[curIdx].part_color_index)
  char:setTag(curIdx)
  char:setPosition(x, y)
  local gid = self.famousInfo[curIdx].gid
  local dist = self.famousInfo[curIdx].dist
  if not isLight then
    gf:bindTouchListener(char, function(touch, event)
      if event:getEventCode() == cc.EventCode.BEGAN and char:containsTouchPos(touch) then
        self:requestWorShipData(dist, gid)
        FriendMgr:requestCharMenuInfo(gid, nil, nil, 1, nil, dist)
        self:hideTipsPanel()
        return true
      end
    end, cc.Handler.EVENT_TOUCH_ENDED, false)
  end
  if daoAndFamousFlag and daoAndFamousFlag ~= 2 and not isLight then
    self:createButton(x, y - 9 - 28 - 38, self.famousInfo[curIdx].gid)
  end
  if daoAndFamousFlag and daoAndFamousFlag == 1 then
    curIdx = 6
  end
  if not isLight and curIdx >= 2 and curIdx <= 5 then
    if curIdx == 2 or curIdx == 4 then
      self:createImgae(x - 51, y + 47, curIdx, layer, isLight)
    else
      self:createImgae(x + 51, y + 47, curIdx, layer, isLight)
    end
  else
    self:createImgae(x, y + 141, curIdx, layer, isLight)
  end
  self:setCharNameLabel(COLOR3.FAMOUS_NAME_COLOR, name, 18, x, y - 15, 4, layer)
  self:setCharNameLabel(COLOR3.NPC_YELLOW, attr, 16, x, y - 9 - 28, 8, layer)
  if isLight then
    self:addLight(x, y, true, layer)
  end
end
function FamousDlg:requestWorShipData(dist, gid)
  gf:CmdToServer("CMD_FAMOUS_CHAR_INFO", {dist = dist, gid = gid})
end
function FamousDlg:createButton(x, y, gid)
  local layer = ccui.Layout:create()
  local buttonLayer = ccui.Layout:create()
  local button = ccui.Button:create(ResMgr.ui.famous_mobai_button, nil, nil, ccui.TextureResType.localType)
  button:setScale9Enabled(true)
  button:setContentSize(84, 36)
  button:setPosition(x, y)
  button:setName(gid)
  buttonLayer:setColor(COLOR3.FAMOUS_BUTTON_COLOR)
  buttonLayer:addChild(button)
  local label = ccui.Text:create()
  label:setFontSize(18)
  label:setString(CHS[7260031])
  label:setColor(COLOR3.FAMOUS_BUTTON_LABEL)
  label:setPosition(x, y)
  label:setName("buttonLabel")
  local mobaiImage = ccui.ImageView:create(ResMgr.ui.famous_mobai_background, ccui.TextureResType.localType)
  mobaiImage:setScale9Enabled(true)
  mobaiImage:setName("mobaiImage")
  local mobaiLabel = ccui.Text:create()
  mobaiLabel:setFontSize(18)
  local mobaiLabelSize = mobaiLabel:getContentSize()
  mobaiImage:setContentSize(mobaiLabelSize.width + 12, 28)
  local mobaiImageSize = mobaiImage:getContentSize()
  mobaiLabel:setPosition(mobaiImageSize.width / 2, mobaiImageSize.height / 2)
  mobaiImage:setPosition(x, y)
  mobaiLabel:setName("mobaiLabel")
  mobaiLabel:setColor(COLOR3.FAMOUS_MOBAI_LABEL)
  mobaiImage:addChild(mobaiLabel)
  mobaiImage:setVisible(false)
  label:setVisible(false)
  button:setVisible(false)
  layer:addChild(label, 4)
  layer:addChild(mobaiImage, 3)
  layer:addChild(buttonLayer, 3)
  self.charLayer:addChild(layer, 2)
end
function FamousDlg:createImgae(x, y, no, layer, isLight)
  local iconImg
  if no <= 6 then
    if isLight then
      iconImg = ccui.ImageView:create(ResMgr.ui["famous_no" .. no])
    else
      iconImg = ccui.ImageView:create(ResMgr.ui["famous_vertical_no" .. no])
    end
  else
    iconImg = ccui.ImageView:create(ResMgr.ui.famous_paibian_no1)
  end
  iconImg:setPosition(x, y)
  layer:addChild(iconImg, 2)
  if not isLight then
    local effectIcon = ResMgr.magic.famouse_rank_effect1
    if no == 6 then
      effectIcon = ResMgr.magic.famouse_rank_effect2
    elseif no == 2 or no == 3 then
      effectIcon = ResMgr.magic.famouse_rank_effect3
    elseif no == 4 or no == 5 then
      effectIcon = ResMgr.magic.famouse_rank_effect4
    end
    local magic = gf:createLoopMagic(effectIcon, nil, {blendMode = "add"})
    magic:setPosition(x, y)
    layer:addChild(magic, 2)
  end
end
function FamousDlg:onMoBaiButton(gid)
  if Me:getLevel() < 75 then
    gf:ShowSmallTips(CHS[7260027])
    return
  end
  if self.worship_size == 3 then
    gf:ShowSmallTips(CHS[7260029])
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  if Me:isInCombat() then
    gf:ShowSmallTips(CHS[3003433])
    return
  end
  for k, v in pairs(self.worshipPersons) do
    if gid == v then
      gf:ShowSmallTips(CHS[7260044])
      return
    end
  end
  self:sendFanousWorshipCmd(gid)
  return true
end
function FamousDlg:sendFanousWorshipCmd(charGid)
  gf:CmdToServer("CMD_FAMOUS_WORSHIP", {
    famous_type = self.famousType,
    level_index = self.level_index,
    char_gid = charGid
  })
end
function FamousDlg:setImgFullScreen()
  if not DeviceMgr:getUIScale() then
    local winsize = {
      width = Const.WINSIZE.width / Const.UI_SCALE,
      height = Const.WINSIZE.height / Const.UI_SCALE
    }
  end
  local topyPanel = self:getControl("TopyPanel")
  topyPanel:setContentSize(topyPanel:getContentSize().width + winsize.width - winsize.height * 1.5, topyPanel:getContentSize().height)
  local parameter = ccui.RelativeLayoutParameter:create()
  parameter:setAlign(ccui.RelativeAlign.centerInParent)
  local bgImg = ccui.ImageView:create(ResMgr.ui.famous_background)
  self:setCtrlFullClient(bgImg, nil, true)
  local layer = ccui.Layout:create()
  layer:setLayoutParameter(parameter)
  layer:addChild(bgImg, 1)
  self.paibianImg = ccui.ImageView:create(ResMgr.ui.famous_paibian_no1)
  self.paibianImg:setPosition(self.paibian.x, self.paibian.y)
  bgImg:addChild(self.paibianImg, 1)
  self.root:addChild(layer, 1)
  self:changeUserPosition()
end
function FamousDlg:changeUserPosition()
  if not DeviceMgr:getUIScale() then
    local winsize = {
      width = Const.WINSIZE.width / Const.UI_SCALE,
      height = Const.WINSIZE.height / Const.UI_SCALE
    }
  end
  local centerX = 960
  local centerY = 384
  for k, v in pairs(self.usersPosition) do
    v.x = v.x - (centerX - winsize.width / 2)
    v.y = v.y - (centerY - winsize.height / 2)
  end
  SHARE_POS.x = SHARE_POS.x - (centerX - winsize.width / 2)
  SHARE_POS.y = SHARE_POS.y - (centerY - winsize.height / 2)
end
function FamousDlg:getAttributionByFamousType(famousType)
  for k, v in pairs(ATTRIBUTION) do
    if v[3] == famousType then
      return v[1]
    end
  end
end
function FamousDlg:needShowWorShipButton()
  return self.famousType ~= FAMOUS_TYPE.FAMOUS_RANK_WORSHIP
end
function FamousDlg:getWorShipTimesByGid(gid)
  if self.charWorShipData and self.charWorShipData[gid] then
    return self.charWorShipData[gid].mon_worship
  end
  return ""
end
function FamousDlg:MSG_FAMOUS_YESTODAY_DATA(data)
  if data.score ~= 0 then
    local dlg = DlgMgr:getDlgByName("FamousAccountDlg")
    if not dlg then
      DlgMgr:openDlgEx("FamousAccountDlg", data)
    end
  end
end
function FamousDlg:MSG_FAMOUS_WORSHIP(data)
  self.worshipPersons = data.worship_persons
  self:setLabelText("NowLabel", 3 - data.worship_size, "TimePanel")
  local score, _ = gf:getArtFontMoneyDesc(data.score)
  self:setLabelText("ValueLabel", score, "PointsPanel")
  local button = self:getControl(data.char_gid, self.charLayer)
  if not button then
    return
  end
  local rootPanel = button:getParent():getParent()
  for k, v in pairs(rootPanel:getChildren()) do
    if v:getName() ~= "mobaiImage" then
      v:setVisible(false)
    else
      v:setVisible(true)
      performWithDelay(self.charLayer, function()
        v:getChildByName("mobaiLabel"):setString(string.format(CHS[7260030], data.old_mon_worship))
        local size = v:getChildByName("mobaiLabel"):getContentSize()
        v:setContentSize(size.width + 12, 28)
        v:getChildByName("mobaiLabel"):setPosition(v:getContentSize().width / 2, v:getContentSize().height / 2)
      end, 0)
      performWithDelay(self.charLayer, function()
        v:getChildByName("mobaiLabel"):setString(string.format(CHS[7260030], data.mon_worship))
        local size = v:getChildByName("mobaiLabel"):getContentSize()
        v:setContentSize(size.width + 12, 28)
        v:getChildByName("mobaiLabel"):setPosition(v:getContentSize().width / 2, v:getContentSize().height / 2)
      end, 0.4)
    end
  end
  performWithDelay(self.charLayer, function()
    for _, info in pairs(self.famousInfo) do
      local gid = info.gid
      local button = self:getControl(gid, self.charLayer)
      if not button then
        return
      end
      local rootPanel = button:getParent():getParent()
      local isMoBai = false
      for i, mbGid in pairs(self.worshipPersons) do
        if mbGid == gid then
          isMoBai = true
        end
      end
      if isMoBai then
        for k, v in pairs(rootPanel:getChildren()) do
          if v:getName() == "mobaiImage" then
            v:setVisible(false)
          else
            v:setVisible(true)
          end
        end
      end
      if isMoBai then
        button:getParent():getParent():getChildByName("buttonLabel"):setVisible(false)
        button:setVisible(false)
      end
    end
  end, 1)
end
function FamousDlg:MSG_FAMOUS_OPEN_UI(data)
  if not data then
    return
  end
  self:setCtrlVisible("TimePanel", true, "LikePanel")
  self:setCtrlVisible("ValuePanel", true, "RankingPanel")
  self:setCtrlVisible("ValuePanel", true, "PointsPanel")
  self.worshipPersons = data.worship_persons
  self.famousType = data.famous_type
  self.level_index = data.level_index
  self.worship_size = data.worship_size
  local score, _ = gf:getArtFontMoneyDesc(data.score)
  self:setLabelText("ValueLabel", score, "PointsPanel")
  self:setLabelText("TextLabel", CHS[7120368], "RankingPanel")
  if data.rank ~= 0 then
    self:setLabelText("NumLabel", data.rank, "RankingPanel")
  else
    self:setLabelText("NumLabel", ">100", "RankingPanel")
  end
  self:setLabelText("NowLabel", 3 - data.worship_size, "TimePanel")
  self.famousInfo = data.famous_info
  if data.famous_type == FAMOUS_TYPE.FAMOUS_RANK_TAO_WIN then
    self:setLabelText("NumLabel", "", "RankingPanel")
    self:setLabelText("TextLabel", CHS[4200895], "RankingPanel")
    for i = 1, data.famous_size do
      if type(self.famousInfo[i].val) == "number" then
        self.famousInfo[i].val = gf:getTaoStr(self.famousInfo[i].val)
      end
    end
  end
  if #data.famous_info == 0 then
    gf:ShowSmallTips(CHS[7260045])
    self:initUserPanel()
    self:addPaiBian(self.curSelectedItem1, self.paibianName)
    return
  end
  if data.famous_type == FAMOUS_TYPE.FAMOUS_RANK_TAO_WIN then
    self:initUser(1)
  elseif data.famous_type == FAMOUS_TYPE.FAMOUS_RANK_WORSHIP then
    self:initUser(2)
  else
    self:initUser(0)
  end
end
function FamousDlg:MSG_OFFLINE_CHAR_INFO(data)
  data.isOnline = 2
  self:MSG_CHAR_INFO(data)
end
function FamousDlg:MSG_CHAR_INFO_EX(data)
  self:MSG_CHAR_INFO(data)
end
function FamousDlg:MSG_OPEN_MRT_EXCHANGE_SHOP(data)
  self:changeTopyPanelStatus(false)
  if not DlgMgr:getDlgByName("FamousStoreDlg") then
    DlgMgr:openDlgEx("FamousStoreDlg", data)
  else
    local score, _ = gf:getArtFontMoneyDesc(data.score)
    self:setLabelText("ValueLabel", score, "PointsPanel")
    return
  end
end
function FamousDlg:MSG_CROSS_SERVER_CHAR_INFO(data)
  data.isOnline = data.online
  self:MSG_CHAR_INFO_EX(data)
end
function FamousDlg:onClickBlank()
  return true
end
function FamousDlg:MSG_CHAR_INFO(data)
  local dlg = DlgMgr:openDlg("CharMenuContentDlg")
  local distName = FriendMgr:getKuafObjDist(data.gid)
  if FriendMgr:isKuafDist(distName) then
    dlg:setMuneType(CHAR_MUNE_TYPE.FAMOUS_KUAFU)
  else
    dlg:setMuneType(CHAR_MUNE_TYPE.FAMOUS_NORMAL)
  end
  dlg:setInfo(data)
  local rect = {
    x = GameMgr.curTouchPos.x,
    y = GameMgr.curTouchPos.y,
    width = 5,
    height = 5
  }
  dlg:setFloatingFramePos(rect)
end
function FamousDlg:MSG_FAMOUS_CHAR_INFO(data)
  if not self.charWorShipData then
    self.charWorShipData = {}
  end
  self.charWorShipData[data.gid] = data
  DlgMgr:sendMsg("CharMenuContentDlg", "refreshCharWorshipTimes", data.gid)
end
return FamousDlg
