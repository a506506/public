local FightCommanderCmdEditDlg = Singleton("FightCommanderCmdEditDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
local RADIO_BUTTON = {
  "EnemyButton",
  "MeButton"
}
local COMMAND_TYPE = FightCommanderCmdMgr:getCommandTypeCfg()
local MAX_COMMAND_COUNT = 10
function FightCommanderCmdEditDlg:init()
  self.listView = self:getControl("ListView")
  self.radioGroup = RadioGroup.new()
  self.radioGroup:setItemsByButton(self, RADIO_BUTTON, self.onRadioButton)
  self.itemPanel = self:retainCtrl("ItemPanel")
  self.selectImage = self:retainCtrl("SelectImage")
  self:bindListener("ConfrimButton", self.onConfrimButton)
  FightCommanderCmdMgr:checkRequestExtraCommand()
  self:setDlgByType(COMMAND_TYPE.ENEMY)
end
function FightCommanderCmdEditDlg:setDlgByType(type)
  self.radioGroup:setSetlctButtonByName(RADIO_BUTTON[type])
  self:onRadioButton(self:getControl(RADIO_BUTTON[type]))
end
function FightCommanderCmdEditDlg:refreshCommandList(type)
  if type and type ~= self.commandType then
    return
  end
  local isOpponent = self.commandType == COMMAND_TYPE.ENEMY
  local commandList = FightCommanderCmdMgr:getDefaultCommand(isOpponent)
  local extraList = FightCommanderCmdMgr:getExtraCommand(isOpponent)
  local defaultCommandCount = #commandList
  for i = 1, #extraList do
    table.insert(commandList, extraList[i])
  end
  if #commandList < MAX_COMMAND_COUNT then
    table.insert(commandList, "")
  end
  self.listView:removeAllItems()
  local commandCount = #commandList
  local itemCount = math.ceil(commandCount / 2)
  for i = 1, itemCount do
    local itemPanel = self.itemPanel:clone()
    local index1 = 2 * i - 1
    local itemPanel1 = itemPanel:getChildByName("ItemPanel1")
    self:setSingleItemInfo(itemPanel1, commandList[index1], defaultCommandCount < index1, index1 - defaultCommandCount)
    local index2 = 2 * i
    local itemPanel2 = itemPanel:getChildByName("ItemPanel2")
    if commandList[index2] then
      self:setSingleItemInfo(itemPanel2, commandList[index2], defaultCommandCount < index2, index2 - defaultCommandCount)
    else
      itemPanel2:setVisible(false)
    end
    self.listView:pushBackCustomItem(itemPanel)
  end
end
function FightCommanderCmdEditDlg:setSingleItemInfo(item, str, showChange, index)
  self:setLabelText("Label", gf:filtTextOnly(str), item)
  if str == "" then
    self:setCtrlVisible("AddButton", true, item)
    self:setCtrlVisible("ChangeButton", false, item)
    self:bindTouchEventListener(self:getControl("AddButton", nil, item), self.onAddButton)
    self:bindTouchEventListener(item, self.onAddButton)
  else
    self:setCtrlVisible("AddButton", false, item)
    self:setCtrlVisible("ChangeButton", showChange, item)
    if showChange then
      local btn = self:getControl("ChangeButton", nil, item)
      btn.index = index
      item.index = index
      self:bindTouchEventListener(btn, self.onChangeButton)
      self:bindTouchEventListener(item, self.onChangeButton)
    end
  end
end
function FightCommanderCmdEditDlg:onChangeButton(sender, eventType)
-- fail 15
unluac.decompile.expression.FunctionCall@6d311334
-1
  if eventType == ccui.TouchEventType.ended then
  end
end
function FightCommanderCmdEditDlg:onAddButton(sender, eventType)
  if eventType == ccui.TouchEventType.ended then
    local dlg = DlgMgr:openDlg("FightCommanderCmdInputDlg")
    dlg:setData(nil, function(para)
      if not string.isNilOrEmpty(para) then
        FightCommanderCmdMgr:requestEditExtraCommand(self.commandType == COMMAND_TYPE.ENEMY, nil, para, "add")
      end
    end)
  end
end
function FightCommanderCmdEditDlg:onRadioButton(sender, eventType)
  local type
  if sender:getName() == "EnemyButton" then
    type = COMMAND_TYPE.ENEMY
    self:setCtrlVisible("EnemySelectImage", true)
    self:setCtrlVisible("MeImage", false)
  else
    type = COMMAND_TYPE.FRIENDS
    self:setCtrlVisible("EnemySelectImage", false)
    self:setCtrlVisible("MeImage", true)
  end
  if not self.commandType or self.commandType ~= type then
    self.commandType = type
    self:refreshCommandList()
  end
end
function FightCommanderCmdEditDlg:onConfrimButton(sender, eventType)
  FightCommanderCmdMgr:requestEditExtraCommand(self.commandType == COMMAND_TYPE.ENEMY, nil, nil, "reset")
end
function FightCommanderCmdEditDlg:cleanup()
  self.commandType = nil
end
return FightCommanderCmdEditDlg
