local FixedTeamEffortDlg = Singleton("FixedTeamEffortDlg", Dialog)
local REWARDS = {
  {
    name = CHS[5410420],
    bind = 0,
    amount = 1
  },
  {
    name = CHS[3001103],
    bind = 1,
    amount = 1
  },
  {
    name = CHS[3001102],
    bind = 1,
    amount = 1
  },
  {
    name = CHS[3001099],
    bind = 1,
    amount = 1
  },
  {
    name = CHS[7190126],
    bind = 1,
    amount = 1
  },
  {
    name = CHS[3001106],
    bind = 1,
    amount = 1
  },
  {
    name = CHS[3001108],
    bind = 1,
    amount = 1
  },
  {
    name = CHS[3001100],
    bind = 1,
    amount = 1
  },
  {
    name = CHS[3001147],
    bind = 1,
    amount = 1
  },
  {
    name = CHS[3001110],
    bind = 1,
    amount = 1
  }
}
function FixedTeamEffortDlg:init()
  self:bindListener("Button", self.onRuleButton, "NoteButtonPanel")
  self:bindListener("Button", self.onSearchButton, "SearchButtonPanel")
  self:bindListener("GetButton", self.onGetButton)
  self:bindListener("GotButton", self.onGotButton)
  self:bindListener("TreasureBagImage", self.onTreasureBagImage)
  self:bindListener("MemberButton", self.onMemberButton)
  self:bindFloatPanelListener("TeamMainPanel")
  cc.SpriteFrameCache:getInstance():addSpriteFrames("ui/TreasureBag.plist")
  DlgMgr:registPlistEx(self.name, "TreasureBag.plist")
  gf:CmdToServer("CMD_FT_COOPERATE_REQ_DATA")
  self:setImagePlist("TreasureBagBKImage", ResMgr.ui.fixed_team_effort_bk)
  self:setImagePlist("TreasureBagImage", ResMgr.ui.fixed_team_effort_bag)
  self.memberBtn = self:retainCtrl("MemberButton")
  self:setCtrlEnabled("GotButton", false)
  self:hookMsg("MSG_FT_COOPERATE_DATA")
end
function FixedTeamEffortDlg:checkActivityClose()
  local activityTime = ActivityMgr:getActivityStartTimeByMainType("fixed_team_cooperate")
  local curTime = gf:getServerTime()
  if activityTime and activityTime.endTime and curTime >= activityTime.endTime then
    gf:ShowSmallTips(CHS[5420500])
    ChatMgr:sendMiscMsg(CHS[5420500])
    self:onCloseButton()
    return true
  end
end
function FixedTeamEffortDlg:cleanup()
  self.memberBtn = nil
  self.hasFixed = nil
  DlgMgr:unregistPlistEx(self.name, "TreasureBag.plist")
end
function FixedTeamEffortDlg:onRuleButton(sender, eventType)
  DlgMgr:openDlg("FixedTeamEffortRuleDlg")
end
function FixedTeamEffortDlg:onSearchButton(sender, eventType)
  if self:checkActivityClose() then
    return
  end
  if self.hasFixed == nil then
    return
  end
  if not self.hasFixed then
    gf:ShowSmallTips(CHS[5420497])
    return
  end
  self:setCtrlVisible("TeamMainPanel", true)
end
function FixedTeamEffortDlg:onGetButton(sender, eventType)
  if self:checkActivityClose() then
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  gf:CmdToServer("CMD_FT_COOPERATE_FETCH_BONUS")
end
function FixedTeamEffortDlg:onGotButton(sender, eventType)
end
function FixedTeamEffortDlg:onTreasureBagImage(sender, eventType)
  if self:checkActivityClose() then
    return
  end
  local dlg = DlgMgr:openDlg("TreasureBagTipsDlg")
  dlg:setData({
    bonus_index = 1000,
    count = #REWARDS,
    list = REWARDS
  })
end
function FixedTeamEffortDlg:onMemberButton(sender, eventType)
  if sender.member then
    sender.member.isOnline = 2
    local rect = self:getBoundingBoxInWorldSpace(sender)
    FriendMgr:openCharMenu(sender.member, nil, rect)
  end
end
function FixedTeamEffortDlg:initTeamView(data)
  self.memberCells = {}
  self.hasFixed = false
  local comCount, myComCount = 0, 0
  if data and 0 < #data.members then
    local panel = self:getControl("TeamPanel")
    panel:removeAllChildren()
    local size = self.memberBtn:getContentSize()
    local count = #data.members
    local sz = panel:getContentSize()
    local height = size.height * count + 10
    panel:setContentSize(sz.width, height)
    local y = height - 6 - size.height
    for i = 1, count do
      local btn = self.memberBtn:clone()
      self:setImage("GuardImage", ResMgr:getSmallPortrait(data.members[i].icon), btn)
      self:setCtrlVisible("Image_1", data.members[i].state == 1, btn)
      self:setCtrlVisible("Image_2", data.members[i].state == 0, btn)
      self:setNumImgForPanel("ShapePanel", ART_FONT_COLOR.NORMAL_TEXT, data.members[i].level, false, LOCATE_POSITION.LEFT_TOP, 19, btn)
      btn:setPositionY(y)
      btn.member = data.members[i]
      panel:addChild(btn)
      y = y - size.height
      self.memberCells[data.members[i].gid] = btn
      if data.members[i].state == 1 then
        if data.members[i].gid == Me:queryBasic("gid") then
          myComCount = 1
        else
          comCount = math.min(2, comCount + 1)
        end
      end
    end
    local teamMainPanel = self:getControl("TeamMainPanel")
    local sz = teamMainPanel:getContentSize()
    panel:setPositionY((sz.height - height) * 2 / 3)
    self.hasFixed = true
    return comCount + myComCount
  end
  return comCount + myComCount
end
function FixedTeamEffortDlg:MSG_FT_COOPERATE_DATA(data)
  local leftPanel = self:getControl("LeftPanel")
  local rightPanel = self:getControl("RightPanel")
  local comCount = self:initTeamView(data)
  if #data.members == 0 then
    self:setCtrlVisible("GetButton", false)
    self:setCtrlVisible("GotButton", false)
    self:setCtrlVisible("NoticeLabel", true)
    self:setLabelText("DescLabel", CHS[5420499], leftPanel)
    self:setLabelText("NumLabel", "0", leftPanel)
    local bar = self:getControl("ProgressBar", nil, leftPanel)
    bar:setPercent(0)
    self:setLabelText("DescLabel", CHS[5420499], rightPanel)
    self:setLabelText("NumLabel", "0", rightPanel)
    local bar = self:getControl("ProgressBar", nil, rightPanel)
    bar:setPercent(0)
  else
    self:setCtrlVisible("GetButton", data.state ~= 2)
    self:setCtrlEnabled("GetButton", data.state == 1)
    self:setCtrlVisible("GotButton", data.state == 2)
    self:setCtrlVisible("NoticeLabel", false)
    self:setLabelText("DescLabel", data.desc1, leftPanel)
    self:setLabelText("NumLabel", string.format("%d/3", comCount), leftPanel)
    local bar = self:getControl("ProgressBar", nil, leftPanel)
    bar:setPercent(comCount / 3 * 100)
    self:setLabelText("DescLabel", data.desc2, rightPanel)
    self:setLabelText("NumLabel", string.format("%d/%d", data.com_count, data.total_count), rightPanel)
    local bar = self:getControl("ProgressBar", nil, rightPanel)
    bar:setPercent(math.min(100, data.com_count / data.total_count * 100))
  end
end
return FixedTeamEffortDlg
