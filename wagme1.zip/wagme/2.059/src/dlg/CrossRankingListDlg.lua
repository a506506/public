local RankingListDlg = require("dlg/RankingListDlg")
local CrossRankingListDlg = Singleton("CrossRankingListDlg", RankingListDlg)
local RANK_TYPE_TITLE_INFO = {
  [RANK_TYPE.CHAR_TAO] = {
    "",
    CHS[3000045],
    CHS[3000047],
    CHS[3000049],
    CHS[5420363]
  },
  [RANK_TYPE.CHAR_MONTH_TAO] = {
    "",
    CHS[3000045],
    CHS[3000047],
    CHS[3000049],
    CHS[5420363]
  },
  [RANK_TYPE.CHAR_PHY_POWER] = {
    CHS[3000044],
    CHS[3000045],
    CHS[3000047],
    CHS[3000051],
    CHS[5420363]
  },
  [RANK_TYPE.CHAR_MAG_POWER] = {
    CHS[3000044],
    CHS[3000045],
    CHS[3000047],
    CHS[3000052],
    CHS[5420363]
  },
  [RANK_TYPE.CHAR_SPEED] = {
    CHS[3000044],
    CHS[3000045],
    CHS[3000047],
    CHS[3000053],
    CHS[5420363]
  },
  [RANK_TYPE.CHAR_DEF] = {
    CHS[3000044],
    CHS[3000045],
    CHS[3000047],
    CHS[3000054],
    CHS[5420363]
  },
  [RANK_TYPE.PET_MARTIAL] = {
    CHS[3000044],
    CHS[3000045],
    CHS[3000048],
    CHS[3000050],
    CHS[5420363]
  },
  [RANK_TYPE.PET_MONTH_MARTIAL] = {
    CHS[3000044],
    CHS[3000045],
    CHS[3000048],
    CHS[4101252],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_WEAPON] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_HELMET] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_ARMOR] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_BOOT] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_LEVEL_ONE] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_LEVEL_TWO] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_LEVEL_THREE] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_LEVEL_FOUR] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_LEVEL_FIVE] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_LEVEL_SIX] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.EQUIP_LEVEL_SEVEN] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003528],
    CHS[3003529],
    CHS[3003530],
    CHS[5420363]
  },
  [RANK_TYPE.GET_TAO_CHUBAO] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003539],
    CHS[3003540],
    CHS[5420363]
  },
  [RANK_TYPE.GET_TAO_XIANGYAO] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003539],
    CHS[3003540],
    CHS[5420363]
  },
  [RANK_TYPE.GET_TAO_FUMO] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003539],
    CHS[3003540],
    CHS[5420363]
  },
  [RANK_TYPE.GET_TAO_FXDX] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003539],
    CHS[3003540],
    CHS[5420363]
  },
  [RANK_TYPE.GET_TAO_SECOND_XIANGYAO] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003539],
    CHS[3003540],
    CHS[5420363]
  },
  [RANK_TYPE.GET_TAO_SECOND_FUMO] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003539],
    CHS[3003540],
    CHS[5420363]
  },
  [RANK_TYPE.GET_TAO_SECOND_FXDX] = {
    CHS[3003526],
    CHS[3003527],
    CHS[3003539],
    CHS[3003540],
    CHS[5420363]
  },
  [RANK_TYPE.SYNTH_ACHIEVE] = {
    CHS[2200055],
    CHS[3000045],
    CHS[3003539],
    CHS[4100848],
    CHS[5420363]
  },
  [RANK_TYPE.SYNTH_BLOG_POPULAR] = {
    CHS[2200055],
    CHS[3000045],
    CHS[5400289],
    CHS[5400290],
    CHS[5420363]
  }
}
local RANK_TYPE_FIELD_INFO = {
  [RANK_TYPE.CHAR_TAO] = {
    "",
    "name",
    "polar",
    "tao",
    "dist_name"
  },
  [RANK_TYPE.CHAR_MONTH_TAO] = {
    "",
    "name",
    "polar",
    "mon_tao",
    "dist_name"
  },
  [RANK_TYPE.CHAR_PHY_POWER] = {
    "",
    "name",
    "polar",
    "phy_power",
    "dist_name"
  },
  [RANK_TYPE.CHAR_MAG_POWER] = {
    "",
    "name",
    "polar",
    "mag_power",
    "dist_name"
  },
  [RANK_TYPE.CHAR_SPEED] = {
    "",
    "name",
    "polar",
    "speed",
    "dist_name"
  },
  [RANK_TYPE.CHAR_DEF] = {
    "",
    "name",
    "polar",
    "def",
    "dist_name"
  },
  [RANK_TYPE.PET_MARTIAL] = {
    "",
    "name",
    "owner_name",
    "martial",
    "dist_name"
  },
  [RANK_TYPE.PET_MONTH_MARTIAL] = {
    "",
    "name",
    "owner_name",
    "mon_martial",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_WEAPON] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_HELMET] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_ARMOR] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_BOOT] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_LEVEL_ONE] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_LEVEL_TWO] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_LEVEL_THREE] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_LEVEL_FOUR] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_LEVEL_FIVE] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_LEVEL_SIX] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.EQUIP_LEVEL_SEVEN] = {
    "",
    "name",
    "rebuild_level",
    "owner_name",
    "equip_perfect_percent",
    "dist_name"
  },
  [RANK_TYPE.GET_TAO_CHUBAO] = {
    "",
    "name",
    "polar",
    "higest_chub",
    "dist_name"
  },
  [RANK_TYPE.GET_TAO_XIANGYAO] = {
    "",
    "name",
    "polar",
    "higest_xiangy",
    "dist_name"
  },
  [RANK_TYPE.GET_TAO_FUMO] = {
    "",
    "name",
    "polar",
    "higest_fum",
    "dist_name"
  },
  [RANK_TYPE.GET_TAO_FXDX] = {
    "",
    "name",
    "polar",
    "higest_feixdx",
    "dist_name"
  },
  [RANK_TYPE.GET_TAO_SECOND_XIANGYAO] = {
    "",
    "name",
    "polar",
    "higest_xiangy2",
    "dist_name"
  },
  [RANK_TYPE.GET_TAO_SECOND_FUMO] = {
    "",
    "name",
    "polar",
    "higest_fum2",
    "dist_name"
  },
  [RANK_TYPE.GET_TAO_SECOND_FXDX] = {
    "",
    "name",
    "polar",
    "higest_feixdx2",
    "dist_name"
  },
  [RANK_TYPE.SYNTH_ACHIEVE] = {
    "",
    "name",
    "polar",
    "achieve",
    "dist_name"
  },
  [RANK_TYPE.SYNTH_BLOG_POPULAR] = {
    "",
    "name",
    "gender",
    "popular",
    "dist_name"
  }
}
local ONE_MENU = {
  CHS[4010083],
  CHS[4010084],
  CHS[4010085],
  CHS[4010087],
  CHS[4010090]
}
local SECOND_MENU = {
  [CHS[4010083]] = {
    CHS[4010093],
    CHS[5450335],
    CHS[4010094],
    CHS[4010095],
    CHS[4010096],
    CHS[4010097]
  },
  [CHS[4010084]] = {
    "70~79",
    "80~89",
    "90~99",
    "100~109",
    "110~119",
    "120~129",
    "130~139"
  },
  [CHS[4010085]] = {
    CHS[4010099],
    CHS[5420362]
  },
  [CHS[4010087]] = {
    CHS[7100815],
    CHS[7100818],
    CHS[7100816],
    CHS[7100819],
    CHS[7100817],
    CHS[7100820]
  },
  [CHS[4010090]] = {
    CHS[4100848],
    CHS[5400288]
  }
}
local MENU_TAG_TO_RANK_NO = {
  [101] = RANK_TYPE.CHAR_TAO,
  [102] = RANK_TYPE.CHAR_MONTH_TAO,
  [103] = RANK_TYPE.CHAR_PHY_POWER,
  [104] = RANK_TYPE.CHAR_MAG_POWER,
  [105] = RANK_TYPE.CHAR_SPEED,
  [106] = RANK_TYPE.CHAR_DEF,
  [201] = RANK_TYPE.EQUIP_LEVEL_ONE,
  [202] = RANK_TYPE.EQUIP_LEVEL_TWO,
  [203] = RANK_TYPE.EQUIP_LEVEL_THREE,
  [204] = RANK_TYPE.EQUIP_LEVEL_FOUR,
  [205] = RANK_TYPE.EQUIP_LEVEL_FIVE,
  [206] = RANK_TYPE.EQUIP_LEVEL_SIX,
  [207] = RANK_TYPE.EQUIP_LEVEL_SEVEN,
  [301] = RANK_TYPE.PET_MARTIAL,
  [302] = RANK_TYPE.PET_MONTH_MARTIAL,
  [401] = RANK_TYPE.GET_TAO_XIANGYAO,
  [402] = RANK_TYPE.GET_TAO_SECOND_XIANGYAO,
  [403] = RANK_TYPE.GET_TAO_FUMO,
  [404] = RANK_TYPE.GET_TAO_SECOND_FUMO,
  [405] = RANK_TYPE.GET_TAO_FXDX,
  [406] = RANK_TYPE.GET_TAO_SECOND_FXDX,
  [501] = RANK_TYPE.SYNTH_ACHIEVE,
  [502] = RANK_TYPE.SYNTH_BLOG_POPULAR
}
function CrossRankingListDlg:initCfgData()
  self.RankTypeFieldInfo = RANK_TYPE_FIELD_INFO
  self.RankTypeTitleInfo = RANK_TYPE_TITLE_INFO
  self.OneMenu = ONE_MENU
  self.SecondMenu = SECOND_MENU
  self.MenuTagToRankNo = MENU_TAG_TO_RANK_NO
end
function CrossRankingListDlg:init()
  RankingListDlg.init(self)
end
function CrossRankingListDlg:initData()
  self:setRankTypeList()
  self:hookMsg("MSG_RANK_CLIENT_INFO")
  self:hookMsg("MSG_CHAR_INFO")
  self:hookMsg("MSG_MY_RANK_INFO")
  self:hookMsg("MSG_CROSS_RANK_VIEW")
  self:hookMsg("MSG_FIND_CHAR_MENU_FAIL")
end
function CrossRankingListDlg:getTaoStr(tao, taoPoint)
  return gf:getTaoStr(tao, 0)
end
function CrossRankingListDlg:getRankListByType(subType, minLevel, maxLevel, start, limit)
  return RankMgr:getRankListByType(subType, minLevel, maxLevel, start, limit, true)
end
function CrossRankingListDlg:fetchRankInfo(rankType, minLevel, maxLevel, index, equipType)
  self.haveList = false
  self.curType = rankType
  self.myRank = 0
  if equipType then
    RankMgr:fetchCrossRankInfo(equipType, minLevel, maxLevel)
  else
    RankMgr:fetchCrossRankInfo(rankType, minLevel, maxLevel)
  end
end
function CrossRankingListDlg:setMyFight(myRank, inRankItemInfo)
  local meInfo = self:getMeInfo()
  if not meInfo then
    return
  end
  self.myRank = myRank
  local panel = self:getControl("RankingPanel")
  if self:getMainType() == RANK_TYPE.EQUIP then
    panel = self:getControl("LevelEquipmentRankingPanel")
  elseif self:getMainType() == RANK_TYPE.PARTY then
    panel = self:getControl("PartyRankingPanel")
  elseif self.curType == RANK_TYPE.CHAR_TAO or self.curType == RANK_TYPE.CHAR_MONTH_TAO or self.curType == RANK_TYPE.CHALLENGE_TOWER then
    panel = self:getControl("LevelRankingPanel")
  elseif self:getMainType() == RANK_TYPE.PET then
    panel = self:getControl("PetRankingPanel")
  elseif self:getMainType() == RANK_TYPE.HOUSE then
    panel = self:getControl("HouseRankingPanel")
  end
  local myRankPanel = self:getControl("MyRankingPanel", Const.UIPanel, panel)
  myRankPanel.info = inRankItemInfo
  local function setMyRanking(str1, str2, str3, str4, str5, str6)
    local rankStr = str1
    if str1 == 0 then
      rankStr = CHS[3003553]
    end
    if self.curType == RANK_TYPE.CHAR_TAO then
      local myLevel = Me:queryInt("level")
      if self.minLevel and myLevel < self.minLevel and self.maxLevel and myLevel > self.maxLevel then
        rankStr = CHS[3003553]
      end
    elseif self.curType == RANK_TYPE.CHAR_MONTH_TAO then
      local myLevel = Me:queryInt("level")
      if self.minLevel and myLevel < self.minLevel and self.maxLevel and myLevel > self.maxLevel then
        rankStr = CHS[3003553]
      end
    elseif self.curType == RANK_TYPE.GET_TAO_XIANGYAO then
      local myLevel = Me:queryInt("level")
      if str1 == 0 and myLevel >= 80 then
        rankStr = CHS[3003552]
      end
    elseif self.curType == RANK_TYPE.GET_TAO_FUMO then
      local myLevel = Me:queryInt("level")
      if str1 == 0 and myLevel >= 120 then
        rankStr = CHS[3003552]
      end
    end
    self:setLabelText("AttributeLabel1", rankStr, myRankPanel)
    self:setLabelText("AttributeLabel2", str2, myRankPanel)
    self:setLabelText("AttributeLabel3", str3, myRankPanel)
    self:setLabelText("AttributeLabel4", str4, myRankPanel)
    self:setLabelText("AttributeLabel5", str5, myRankPanel)
    self:setLabelText("AttributeLabel6", str6, myRankPanel)
  end
  local fieldInfo = self.RankTypeFieldInfo[self.curType]
  if self:getMainType() == RANK_TYPE.CHAR then
    local part = Me:getPartyName()
    if part == "" then
      part = CHS[3003552]
    end
    local family = Me:queryBasic("polar")
    family = gf:getPolar(tonumber(family))
    if family == "" or nil == family then
      family = CHS[3003552]
    end
    local str4 = ""
    local level = Me:queryBasicInt("level")
    if self.curType == RANK_TYPE.CHAR_LEVEL then
      str4 = part
    elseif self.curType == RANK_TYPE.CHAR_TAO then
      str4 = self:getTaoStr(Me:queryBasicInt("tao"), Me:queryBasicInt("tao_ex"))
    elseif self.curType == RANK_TYPE.CHAR_MONTH_TAO then
      str4 = self:getTaoStr(Me:queryBasicInt("mon_tao"), Me:queryBasicInt("mon_tao_ex"))
    elseif self.curType == RANK_TYPE.CHAR_PHY_POWER then
      if myRank > 0 then
        str4 = inRankItemInfo.phy_power
      end
    elseif self.curType == RANK_TYPE.CHAR_MAG_POWER then
      if myRank > 0 then
        str4 = inRankItemInfo.mag_power
      end
    elseif self.curType == RANK_TYPE.CHAR_SPEED then
      if myRank > 0 then
        str4 = inRankItemInfo.speed
      end
    elseif self.curType == RANK_TYPE.CHAR_DEF then
      if myRank > 0 then
        str4 = inRankItemInfo.def
      end
    elseif self.curType == RANK_TYPE.CHAR_UPGRADE_LEVEL then
      level = Me:queryBasicInt("upgrade/level")
      str4 = part
    end
    setMyRanking(myRank, Me:getShowName(), family, str4, GameMgr:getDistName())
  elseif self:getMainType() == RANK_TYPE.GET_TAO then
    local family = Me:queryBasic("polar")
    family = gf:getPolar(tonumber(family))
    if family == "" or nil == family then
      family = CHS[3003552]
    end
    local time = meInfo.info[fieldInfo[4]]
    local timeStr = ""
    if time <= 0 then
      timeStr = CHS[3003552]
    else
      timeStr = self:getTAOtime(time) .. CHS[3003550]
    end
    setMyRanking(myRank, Me:getShowName(), family, timeStr, GameMgr:getDistName())
  elseif self:getMainType() == RANK_TYPE.PET then
    if inRankItemInfo then
      setMyRanking(myRank, inRankItemInfo.name, Me:getShowName(), inRankItemInfo[fieldInfo[4]], GameMgr:getDistName())
    elseif PetMgr:getPetCount() == 0 then
      setMyRanking(myRank, CHS[3003552], Me:getShowName(), "0", GameMgr:getDistName())
    end
  elseif self:getMainType() == RANK_TYPE.EQUIP then
    if myRank ~= 0 and inRankItemInfo then
      setMyRanking(myRank, inRankItemInfo.name, string.format(CHS[3003551], inRankItemInfo.rebuild_level), Me:getShowName(), inRankItemInfo.equip_perfect_percent / 100 .. "%", GameMgr:getDistName())
    else
      local equip
      if RankMgr:getLastSearchEquip() == RANK_TYPE.EQUIP_WEAPON then
        equip = InventoryMgr:getPerfectEquip(EQUIP.WEAPON)
      elseif RankMgr:getLastSearchEquip() == RANK_TYPE.EQUIP_HELMET then
        equip = InventoryMgr:getPerfectEquip(EQUIP.HELMET)
      elseif RankMgr:getLastSearchEquip() == RANK_TYPE.EQUIP_ARMOR then
        equip = InventoryMgr:getPerfectEquip(EQUIP.ARMOR)
      elseif RankMgr:getLastSearchEquip() == RANK_TYPE.EQUIP_BOOT then
        equip = InventoryMgr:getPerfectEquip(EQUIP.BOOT)
      end
      if not equip then
        setMyRanking(CHS[3003553], CHS[3003552], 0, Me:getShowName(), 0, GameMgr:getDistName())
      else
        setMyRanking(myRank, equip.name, string.format(CHS[3003551], equip.rebuild_level), Me:getShowName(), equip.equip_perfect_percent / 100 .. "%", GameMgr:getDistName())
      end
    end
  elseif self:getMainType() == RANK_TYPE.SYNTH then
    local family
    if self.curType == RANK_TYPE.SYNTH_BLOG_POPULAR then
      family = gf:getGenderChs(Me:queryBasicInt("gender"))
    else
      family = gf:getPolar(Me:queryBasicInt("polar"))
      if family == "" or nil == family then
        family = CHS[3003552]
      end
    end
    if inRankItemInfo then
      setMyRanking(myRank, Me:getShowName(), family, inRankItemInfo[fieldInfo[4]], GameMgr:getDistName())
    end
  end
  myRankPanel:setTag(self.curType)
  self:bindTouchEndEventListener(myRankPanel, self.myRankPanelButton)
end
function CrossRankingListDlg:MSG_MY_RANK_INFO(data)
  local panel = self:getControl("RankingPanel")
  if self:getMainType() == RANK_TYPE.CHAR or self:getMainType() == RANK_TYPE.SYNTH then
    panel = self:getControl("RankingPanel")
  elseif self:getMainType() == RANK_TYPE.PET then
    panel = self:getControl("PetRankingPanel")
  else
    return
  end
  local function setRankInfoForMy(par1, par2, par3, par4, par5, panel)
    self:setLabelText("AttributeLabel1", par1, panel)
    self:setLabelText("AttributeLabel2", par2, panel)
    self:setLabelText("AttributeLabel3", par3, panel)
    self:setLabelText("AttributeLabel4", par4, panel)
    self:setLabelText("AttributeLabel5", par5, panel)
  end
  local myRankPanel = self:getControl("MyRankingPanel", Const.UIPanel, panel)
  if self.curType == data.rankNo then
    if self:getMainType() == RANK_TYPE.CHAR then
      if self.myRank == 0 then
        self:setLabelText("AttributeLabel4", data.value, myRankPanel)
      end
    elseif self:getMainType() == RANK_TYPE.PET then
      if self.myRank == 0 then
        local pet = PetMgr:getPetById(data.id)
        if pet then
          local rankStr = CHS[3003553]
          setRankInfoForMy(rankStr, pet:queryBasic("raw_name"), Me:getShowName(), data.value, GameMgr:getDistName(), myRankPanel)
          self.myRankPetId = data.id
        end
      end
    elseif self:getMainType() == RANK_TYPE.SYNTH and self.myRank == 0 then
      local rankStr = CHS[3003553]
      local family
      if self.curType == RANK_TYPE.SYNTH_BLOG_POPULAR then
        family = gf:getGenderChs(Me:queryBasicInt("gender"))
      else
        family = gf:getPolar(Me:queryBasicInt("polar"))
        if family == "" or nil == family then
          family = CHS[3003552]
        end
      end
      setRankInfoForMy(rankStr, Me:queryBasic("name"), family, data.value, GameMgr:getDistName(), myRankPanel)
    end
  end
end
function CrossRankingListDlg:MSG_CROSS_RANK_VIEW(data)
  if data.type ~= self.curType and (not RankMgr:isEquipLevelType(self.curType) or not RankMgr:isEquipType(data.type)) then
    return
  end
  self.haveList = true
  local minLevel, maxLevel
  self.minLevel = nil
  self.maxLevel = nil
  if not string.isNilOrEmpty(data.level_limit) then
    minLevel, maxLevel = string.match(data.level_limit, "(%d+)-(%d+)")
    self.minLevel = tonumber(minLevel)
    self.maxLevel = tonumber(maxLevel)
  end
  self.startIndex = 1
  self.info = {}
  self.infoType = self:getMainType()
  self:showRankInfo(self.minLevel, self.maxLevel)
end
return CrossRankingListDlg
