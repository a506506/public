local CommunityDlg = Singleton("CommunityDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
local WaitPanel = require("ctrl/WaitPanel")
local DLG_DELAY_CLOSE_TIME = 90
local LOAD_MAX_TIME = 10
local DEFAULT_RAW_URL = CommunityMgr:getCommunityURL()
local WEBPAGE_TAG = 999
local schemeMethods = {
  showArticle = "onShowArticle",
  shareUrlToWX = "onShareUrlToWX",
  shareImageToWX = "onShareImageToWX",
  saveImage = "onSaveImage",
  shareToSpace = "onShareToSpace",
  shareImageToSpace = "onShareImageToSpace",
  shareToFriend = "onShareToFriend",
  getFriendList = "onGetFriendList",
  redirect = "onRedirect",
  isNeedUnlock = "onCheckIsNeedUnlock",
  checkSafeLock = "onCheckSafeLock",
  getGoldSilverCoin = "onGetGoldSilverCoin",
  costGoldSilverCoin = "onCostGoldSilverCoin",
  shrinkVideo = "onShrinkVideo",
  selectCheckBox = "onSelectCheckBox",
  releaseLimitCheckBox = "onReleaseLimitCheckBox",
  openUrl = "onOpenUrl"
}
local WAIT_PANEL_STR = {
  CHS[7150142],
  CHS[7150142] .. ".",
  CHS[7150142] .. "..",
  CHS[7150142] .. "..."
}
local CHECKBOX_LIST = {
  "CommunityHomePageDlgCheckBox",
  "CommunityGuideDlgCheckBox",
  "CommunityDiscoverDlgCheckBox",
  "CommunityDribuneDlgCheckBox",
  "CommunityMyselfDlgCheckBox"
}
function CommunityDlg:init(data)
  local checkBoxList = gf:deepCopy(CHECKBOX_LIST)
  if not GameMgr.initDataDone then
    self:getControl("CommunityDribuneDlg"):removeFromParent()
    self:getControl("CommunityMyselfDlg"):removeFromParent()
    self:getControl("SwitchPanel"):requestDoLayout()
    table.remove(checkBoxList, 4)
    table.remove(checkBoxList, 4)
  elseif not ShareMgr:isOffice() then
    self:getControl("CommunityDribuneDlg"):removeFromParent()
    self:getControl("SwitchPanel"):requestDoLayout()
    table.remove(checkBoxList, 4)
  end
  CommunityMgr:setLastAcesssCheckBox("CommunityHomePageDlgCheckBox")
  self:setCtrlVisible("TitlePanel", false)
  self:bindListener("RefreshButton", self.onRefreshButton, "NoticePanel")
  self.radioGroup = RadioGroup.new()
  self.radioGroup:setItems(self, checkBoxList, self.onCheckBoxClick)
  self.radioGroup:setSetlctByName(CommunityMgr:getLastAcesssCheckBox())
  self.blank:setLocalZOrder(Const.LOADING_DLG_ZORDER - 2)
  SmallTipsMgr:setLocalZOrder(Const.ZORDER_LORDLAOZI_TIP, self.name)
  self:hookMsg("MSG_ENTER_ROOM")
  self:hookMsg("MSG_COMMUNITY_COST_COIN")
  if gf:isWindows() and ATM_IS_DEBUG_VER then
    return
  end
  self:setMusicOnBeforeInfo(SoundMgr:isMusicOn(), SoundMgr:isSoundOn(), SoundMgr:isDubbingOn())
  CommunityMgr:pushOpenCommunityProcessLog(OPEN_COMMUNITY_PROCESS_LOG.SHOW_NOTICE_DLG)
  self.curUrl = CommunityMgr:getCommunityLoadUrl(data)
  self:beginLoadUrl()
  self.inPreLoad = nil
  self:MSG_ENTER_ROOM()
  if string.match(self.curUrl, CommunityMgr:getCommunityUrlGuideSuffix()) then
    self.radioGroup:setSetlctByName("CommunityGuideDlgCheckBox", true)
    CommunityMgr:setLastAcesssCheckBox("CommunityGuideDlgCheckBox")
    gf:CmdToServer("CMD_SET_OPEN_COMMUNITY_FLAG", {})
  end
end
function CommunityDlg:onCheckAddRedDot(ctrlName)
  local curChannel = self.radioGroup:getSelectedRadioName()
  if curChannel == ctrlName then
    return false
  end
  return true
end
function CommunityDlg:setMusicOnBeforeInfo(isMousicOn, isSoundOn, isDubbingOn)
  self.isMusicOnBeforeOpen = isMousicOn
  self.isSoundOnBeforeOpen = isSoundOn
  self.isDubbingOnBeforeOpen = isDubbingOn
end
function CommunityDlg:beginLoadUrl(url)
  if url then
    self.curUrl = url
  end
  if not self:createWebView() then
    return
  end
  self:createWaitPanel()
  self:setCtrlVisible("NoticePanel", false)
  self:checkRecordToken()
  self.webView:loadURL(self.curUrl)
  local startTime = LOAD_MAX_TIME
  self.waitPanel:setVisible(true)
  if not self.schedulId then
    self.schedulId = self:startSchedule(function()
      if startTime > 0 then
        startTime = startTime - 1
      elseif self.radioGroup:getSelectedRadioName() ~= "CommunityHomePageDlgCheckBox" then
        self.curUrl = CommunityMgr:getCommunityLoadUrl(data, true)
        self.webView:loadURL(self.curUrl)
        startTime = LOAD_MAX_TIME
      else
        self:clearSchedule()
        self:removeWebView()
        self.waitPanel:setVisible(false)
        self:setCtrlVisible("NoticePanel", true)
      end
    end, 1)
  end
  self:setVisible(true)
  self:setWebViewVisible(false)
end
function CommunityDlg:createWaitPanel()
  self.waitPanel = self:getControl("WaitPanel")
  self.waitPanelScheduleId = self:startSchedule(function()
    self:refreshWaitPanel()
  end, 0.3)
end
function CommunityDlg:refreshWaitPanel()
  local curStr = self:getLabelText("InfoLabel2", self.waitPanel)
  if curStr == WAIT_PANEL_STR[1] then
    self:setLabelText("InfoLabel2", WAIT_PANEL_STR[2], self.waitPanel)
  elseif curStr == WAIT_PANEL_STR[2] then
    self:setLabelText("InfoLabel2", WAIT_PANEL_STR[3], self.waitPanel)
  elseif curStr == WAIT_PANEL_STR[3] then
    self:setLabelText("InfoLabel2", WAIT_PANEL_STR[4], self.waitPanel)
  else
    self:setLabelText("InfoLabel2", WAIT_PANEL_STR[1], self.waitPanel)
  end
end
function CommunityDlg:removeUrlSuffix(str)
  if self.curUrl then
    local left, right = string.find(self.curUrl, str)
    if left and right then
      self.curUrl = string.sub(self.curUrl, 1, left - 1) .. string.sub(self.curUrl, right + 1, -1)
    end
  end
end
function CommunityDlg:refreshCurUrl()
  if not self.curUrl then
    return
  end
  self:setCtrlVisible("NoticePanel", false)
  self:clearSchedule()
  self:createWaitPanel()
  if not self:createWebView() then
    return
  end
  self.webView:loadURL(self.curUrl)
  local startTime = LOAD_MAX_TIME
  self.waitPanel:setVisible(true)
  if not self.schedulId then
    self.schedulId = self:startSchedule(function()
      if startTime > 0 then
        startTime = startTime - 1
      else
        self:clearSchedule()
        self:removeWebView()
        self.waitPanel:setVisible(false)
        self:setCtrlVisible("NoticePanel", true)
      end
    end, 1)
  end
end
function CommunityDlg:checkRecordToken()
  local lastSelectCheckBox = CommunityMgr:getLastAcesssCheckBox()
  if lastSelectCheckBox ~= "CommunityHomePageDlgCheckBox" and lastSelectCheckBox ~= "CommunityDribuneDlgCheckBox" then
    return
  end
  local userDefault = cc.UserDefault:getInstance()
  local lastToken = userDefault:getStringForKey("last_lommunity_loken", "")
  local curToken = CommunityMgr:getToken()
  if string.isNilOrEmpty(curToken) then
    return
  end
  if not string.isNilOrEmpty(lastToken) and lastToken ~= curToken then
    self.limiteCheckBox = true
  end
  userDefault:setStringForKey("last_lommunity_loken", curToken)
end
function CommunityDlg:setMusicPauseOrOn(flag)
  if self.isMusicOnBeforeOpen then
    if flag then
      SoundMgr:resumeMusic()
    else
      SoundMgr:pauseMusic()
    end
  end
  if self.isSoundOnBeforeOpen then
    if flag then
      SoundMgr:resumeSound()
    else
      SoundMgr:pauseSound()
    end
  end
  if self.isDubbingOnBeforeOpen then
    if flag then
      SoundMgr:resumeDubbing()
    else
      SoundMgr:stopDubbing()
    end
  end
end
function CommunityDlg:tryToResumeMusic()
  if self.isPlayVideo then
    if self.isMusicOnBeforeOpen then
      SoundMgr:resumeMusic()
    end
    if self.isSoundOnBeforeOpen then
      SoundMgr:resumeSound()
    end
    if self.isDubbingOnBeforeOpen then
      SoundMgr:resumeDubbing()
    end
    self.isPlayVideo = false
  end
end
function CommunityDlg:onShowArticle(args)
  local type = args.type
  if type == "video" then
    self.isPlayVideo = true
    if self.isMusicOnBeforeOpen then
      SoundMgr:pauseMusic()
    end
    if self.isSoundOnBeforeOpen then
      SoundMgr:pauseSound()
    end
    if self.isDubbingOnBeforeOpen then
      SoundMgr:stopDubbing()
    end
  else
    self:tryToResumeMusic()
  end
end
function CommunityDlg:onShareUrlToWX(args)
  local type = SHARE_TYPE.WECHAT
  if args.type == "circle" then
    type = SHARE_TYPE.WECHATMOMENTS
  end
  ShareMgr:shareUrlToPlat(type, args.url, args.title, args.desc, self:getThumbPath(), function(result)
    if not self.webView then
      return
    end
    local r = tostring(result)
    local jsCode = "if (typeof(atmShareCallback) == 'function'){ atmShareCallback('" .. r .. "', ''); }else{ alert('" .. r .. "');}"
    self.webView:evaluateJS(jsCode)
  end)
end
function CommunityDlg:onSaveImage(args)
  local url = args.url
  if not gf:gfIsFuncEnabled(FUNCTION_ID.SAVE_TO_GALLERY) then
    local jsCode = string.format("atmDownloadFinish(\"%s\", \"%s\", \"%s\");", "unsupport", url, "")
    self.webView:evaluateJS(jsCode)
    return
  end
  local httpFile = HttpFile:create()
  self:regHttpReq(httpFile)
  local filePath = string.format("saves/atm%d%d.jpg", os.time(), gfGetTickCount())
  gfSaveFile("", filePath)
  filePath = cc.FileUtils:getInstance():getWritablePath() .. filePath
  local function _callback(state, value)
    if not self.reqs then
      return
    end
    if 1 == state then
      local jsCode = string.format("atmDownloadProgress(\"%s\", %d);", url, value)
      self.webView:evaluateJS(jsCode)
    elseif 0 == state then
      if gf:isAndroid() then
        local luaj = require("luaj")
        local className = "org/cocos2dx/lua/AppActivity"
        local sig = "(Ljava/lang/String;I)Ljava/lang/String;"
        local args = {filePath, 80}
        local fun = "saveImageToGallery"
        local ok, ret = luaj.callStaticMethod(className, fun, args, sig)
        if ok then
          filePath = ret
        end
      elseif gf:isIos() then
        local luaoc = require("luaoc")
        local args = {arg1 = filePath}
        local ok, ret = luaoc.callStaticMethod("AppController", "saveImageToGallery", args)
        if ok then
          filePath = ret
        end
      end
      local jsCode = string.format("atmDownloadFinish(\"%s\", \"%s\", \"%s\");", "success", url, filePath)
      self.webView:evaluateJS(jsCode)
      self:unregHttpReq(httpFile)
    elseif 2 == state then
      local jsCode = string.format("atmDownloadFinish(\"%s\", \"%s\", \"%s\");", "fail", url, "")
      self.webView:evaluateJS(jsCode)
      os.remove(filePath)
      self:unregHttpReq(httpFile)
    end
  end
  httpFile:setDelegate(_callback)
  httpFile:downloadFile(url, filePath)
end
function CommunityDlg:onFinishUploadIcon(files, uploads)
  if #files ~= #uploads then
    local sendTip = CHS[5420453]
    local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
    self.webView:evaluateJS(jsCode)
    Client:pushDebugInfo("[shareImageToSpace]:upload fail!")
    return
  end
  BlogMgr:publishStatus("", uploads[1], 0)
  local sendTip = CHS[2200082]
  local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHARESUCCESS", sendTip, sendTip)
  self.webView:evaluateJS(jsCode)
end
function CommunityDlg:downloadCommunityFile(url, callback)
  local httpFile = HttpFile:create()
  self:regHttpReq(httpFile)
  local fileExt = gf:getFileExt(url)
  local filePath = "saves/atmCommunityShare." .. fileExt
  gfSaveFile("", filePath)
  filePath = cc.FileUtils:getInstance():getWritablePath() .. filePath
  local function _callback(state, value)
    if not self.reqs then
      return
    end
    if 1 == state then
      callback(filePath, state)
    elseif 0 == state then
      callback(filePath, state)
      Client:pushDebugInfo("[downloadCommunityFile]:download succ!")
    elseif 2 == state then
      callback(filePath, state)
      Client:pushDebugInfo("[downloadCommunityFile]:download fail!")
      self:unregHttpReq(httpFile)
    end
  end
  httpFile:setDelegate(_callback)
  httpFile:downloadFile(url, filePath)
end
function CommunityDlg:onShareImageToWX(args)
  local type = SHARE_TYPE.WECHAT
  if args.type == "circle" then
    type = SHARE_TYPE.WECHATMOMENTS
  end
  local url = args.url
  self:downloadCommunityFile(url, function(filePath, result)
    if result == 0 then
      ShareMgr:shareToPlat(type, {
        fileName = filePath,
        needNotifyServer = function(result)
          if not self.webView then
            return
          end
          local r = tostring(result)
          local jsCode = "if (typeof(atmShareCallback) == 'function'){ atmShareCallback('" .. r .. "', ''); }else{ alert('" .. r .. "');}"
          self.webView:evaluateJS(jsCode)
        end
      })
    elseif result == 2 then
      local sendTip = CHS[5420453]
      local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
      self.webView:evaluateJS(jsCode)
    end
  end)
end
function CommunityDlg:onShareImageToSpace(args)
  if not Me or Me:queryBasic("gid") == "" or GameMgr:getGameState() ~= GAME_RUNTIME_STATE.MAIN_GAME then
    local sendTip = CHS[5420454]
    local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
    self.webView:evaluateJS(jsCode)
    return
  end
  if Me:getLevel() < 40 then
    local sendTip = CHS[2200092]
    local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
    self.webView:evaluateJS(jsCode)
    return
  end
  local url = args.url
  local userDefault = cc.UserDefault:getInstance()
  local isNeedAG = userDefault:getIntegerForKey("BlogAgreementDlg", 0)
  if isNeedAG == 0 then
    userDefault:setIntegerForKey("BlogAgreementDlg", 1)
    BlogMgr:agreement()
  end
  self:downloadCommunityFile(url, function(filePath, result)
    if result == 0 then
      BlogMgr:cmdUpload(BLOG_OP_TYPE.BLOG_OP_UPLOAD_CIRCLE, "CommunityDlg", "onFinishUploadIcon", filePath)
    elseif result == 2 then
      local sendTip = CHS[5420453]
      local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
      self.webView:evaluateJS(jsCode)
    end
  end)
end
function CommunityDlg:onShareToSpace(args)
  if not Me or Me:queryBasic("gid") == "" or GameMgr:getGameState() ~= GAME_RUNTIME_STATE.MAIN_GAME then
    local sendTip = CHS[5420454]
    local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
    self.webView:evaluateJS(jsCode)
    return
  end
  if Me:getLevel() < 40 then
    local sendTip = CHS[2200092]
    local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
    self.webView:evaluateJS(jsCode)
    return
  end
  local title = args.title
  local articleId = args.articleId
  local comment = args.comment
  local filtTextStr = gfFiltrate(comment or "", false)
  if not string.isNilOrEmpty(filtTextStr) then
    sendTip = CHS[2200093]
    local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
    self.webView:evaluateJS(jsCode)
    return
  end
  local userDefault = cc.UserDefault:getInstance()
  local isNeedAG = userDefault:getIntegerForKey("BlogAgreementDlg", 0)
  if isNeedAG == 0 then
    userDefault:setIntegerForKey("BlogAgreementDlg", 1)
    BlogMgr:agreement()
  end
  local content = string.format("{\t%s\027%s\027%s\t}", title, articleId, comment)
  local viewType = 0
  BlogMgr:publishStatus(content, "", viewType)
  local sendTip = CHS[2200082]
  local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHARESUCCESS", sendTip, sendTip)
  self.webView:evaluateJS(jsCode)
end
function CommunityDlg:onShareToFriend(args)
  local title = args.title
  local articleId = args.articleId
  local comment = args.comment
  local gid = args.id
  local friend = FriendMgr:getFriendByGid(gid)
  local content = string.format("{\t%s\027%s\027%s\t}", title, articleId, "")
  local sendTip
  if friend then
    local filtTextStr = gfFiltrate(comment or "", false)
    if not string.isNilOrEmpty(filtTextStr) then
      sendTip = CHS[2200093]
      local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
      self.webView:evaluateJS(jsCode)
      return
    end
    FriendMgr:sendMsgToFriend(friend:queryBasic("char"), content, gid)
    if not string.isNilOrEmpty(comment) then
      FriendMgr:sendMsgToFriend(friend:queryBasic("char"), comment, gid)
    end
    sendTip = string.format(CHS[2200083], friend:queryBasic("char"))
  else
    local group = FriendMgr:getChatGroupInfoById(gid)
    if not group then
      return
    end
    local filtTextStr = gfFiltrate(comment or "", false)
    if not string.isNilOrEmpty(filtTextStr) then
      sendTip = CHS[2200093]
      local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
      self.webView:evaluateJS(jsCode)
      return
    end
    FriendMgr:sendMsgToChatGroup(group:queryBasic("group_name"), content, gid)
    if not string.isNilOrEmpty(comment) then
      FriendMgr:sendMsgToChatGroup(group:queryBasic("group_name"), comment, gid)
    end
    sendTip = string.format(CHS[2200084], group:queryBasic("group_name"))
  end
  if sendTip then
    local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHARESUCCESS", sendTip, sendTip)
    self.webView:evaluateJS(jsCode)
  end
end
function CommunityDlg:onGetFriendList(args)
  local list = {}
  local friends = {}
  local recents = {}
  local groups = {}
  local friendList = FriendMgr:getObjsByGroup()
  if friendList then
    for k, v in pairs(friendList) do
      local f = {}
      f.icon = v:queryInt("icon")
      f.level = v:queryInt("level")
      f.name = v:queryBasic("char")
      f.party = v:queryBasic("party/name")
      f.id = v:queryBasic("gid")
      f.is_online = v:queryInt("online")
      table.insert(friends, f)
    end
  end
  local recentList = FriendMgr:getRecentFriends()
  if recentList then
    for k, _ in pairs(recentList) do
      local f = {}
      local v = FriendMgr:getFriendByGid(k)
      if v then
        f.icon = v:queryInt("icon")
        f.level = v:queryInt("level")
        f.name = v:queryBasic("char")
        f.party = v:queryBasic("party/name")
        f.id = v:queryBasic("gid")
        f.is_online = v:queryInt("online")
        table.insert(recents, f)
      end
    end
  end
  local groupList = FriendMgr:getChatGroupsData()
  for i = 1, #groupList do
    local g = {}
    local v = groupList[i]
    local list = FriendMgr:getGroupByGroupId(v.group_id)
    local online, total = FriendMgr:getOnlinAndTotaleCounts(list)
    g.online_num = online
    g.total = total
    g.name = v.group_name
    g.id = v.group_id
    local info = FriendMgr:getChatGroupInfoById(v.group_id)
    if info then
      g.icon = info:queryInt("icon")
    end
    table.insert(groups, g)
  end
  list.friends = friends
  list.recent = recents
  list.groups = groups
  local str = require("json").encode(list)
  local jsCode = string.format("var o = JSON.parse(\"%s\"); atmFriendList(o);", str.gsub(str, "\"", "\\\""))
  self.webView:evaluateJS(jsCode)
end
function CommunityDlg:onRedirect(args)
  if not args then
    return
  end
  local url = args.url
  url = DEFAULT_RAW_URL .. url
  self.curUrl = url
end
function CommunityDlg:onGetGoldSilverCoin(args)
  local jsCode = string.format("atmGetGoldSilverCoin(%d,%d,%d);", Me:getGoldCoin(), Me:getSilverCoin(), Me:isInTradingShowState() and 1 or 0)
  self.webView:evaluateJS(jsCode)
end
function CommunityDlg:onCostGoldSilverCoin(args)
  local no = args.no
  local para = args.text
  Log:I("community request cost no: " .. tostring(no) .. " para : " .. tostring(para))
  gf:CmdToServer("CMD_COMMUNITY_COST_COIN", {no = no, para = para})
end
function CommunityDlg:MSG_COMMUNITY_COST_COIN(data)
  local no = data.no
  local result = data.result
  local message = data.message
  local jsCode = string.format("atmCostGoldSilverCoin(\"%s\",%d,\"%s\");", no, result, message)
  self.webView:evaluateJS(jsCode)
  Log:I("community reply cost no: " .. tostring(jsCode))
end
function CommunityDlg:onShrinkVideo(args)
  local uri = args.uri
  print("WDSY-41899 community onShrinkVideo " .. tostring(uri))
  DlgMgr:closeDlg("CommunitySmallVideoDlg")
  local dlg = DlgMgr:openDlgEx("CommunitySmallVideoDlg", uri)
  if dlg then
    dlg:setMusicOnBeforeInfo(self.isMusicOnBeforeOpen, self.isSoundOnBeforeOpen, self.isDubbingOnBeforeOpen)
  end
  self:setVisible(false)
end
function CommunityDlg:doSmallDlgExpandVideo(jsCode)
  self.webView:evaluateJS(jsCode)
end
function CommunityDlg:onOpenUrl(args)
  local url = args.url
  if string.isNilOrEmpty(url) then
    return
  end
  DeviceMgr:openUrl(url)
end
function CommunityDlg:onReleaseLimitCheckBox()
  self.limiteCheckBox = nil
end
function CommunityDlg:onSelectCheckBox(args)
  local index = args.index
  local checkBoxName = CHECKBOX_LIST[tonumber(index)]
  if not checkBoxName then
    print("community onSelectCheckBox warning checkbox index " .. tostring(index))
    return
  end
  self.radioGroup:setSetlctByName(checkBoxName, true)
  CommunityMgr:setLastAcesssCheckBox(checkBoxName)
end
function CommunityDlg:onStopVideoToJs()
  self.webView:evaluateJS("atmMinWebview();")
end
function CommunityDlg:onCheckIsNeedUnlock(args)
  local isNeedUnlock = SafeLockMgr:isNeedUnLock()
  local jsCode = string.format("atmNeedUnlock(%s);", tostring(isNeedUnlock))
  self.webView:evaluateJS(jsCode)
end
function CommunityDlg:onCheckSafeLock(args)
  if not args then
    return
  end
  self.unlockPwd = args.pwd
  self:checkSafeLockRelease("onUnlock")
end
function CommunityDlg:onOpenUnlock()
  if not self.unlockPwd then
    self:onUnlock(CHS[3004464])
    return
  end
  local r, errorTips = SafeLockMgr:isMeetCondition(self.unlockPwd)
  if not r then
    self:onUnlock(errorTips)
    return
  end
  SafeLockMgr:cmdUnLockSafeLock(SafeLockMgr.releaseLockInfo.key, self.unlockPwd)
  self.unlockPwd = nil
end
function CommunityDlg:onUnlock(result)
  if nil == result then
    result = "success"
  end
  local jsCode = string.format("atmUnlockResult('%s');", tostring(result))
  Client:pushDebugInfo(jsCode)
  self.webView:evaluateJS(jsCode)
end
function CommunityDlg:regHttpReq(req)
  if not self.reqs then
    self.reqs = {}
  end
  self.reqs[tostring(req)] = req
  req:retain()
end
function CommunityDlg:unregHttpReq(req)
  if not self.reqs then
    return
  end
  if req then
    self.reqs[tostring(req)] = nil
    req:release()
  else
    for _, v in pairs(self.reqs) do
      if v then
        v:release()
      end
    end
    self.reqs = nil
  end
end
function CommunityDlg:getThumbPath()
  return cc.FileUtils:getInstance():fullPathForFilename(ResMgr.ui.atm_share_url_logo)
end
function CommunityDlg:parseAtmScheme(schemeUrl)
  local url = require("url")
  local info = {}
  info.scheme, info.host = string.match(schemeUrl, "([^:]+)://(.*)")
  local pos = gf:findStrByByte(info.host, "?")
  if not pos then
    info.method = info.host
    return info
  end
  info.method = string.sub(info.host, 1, pos - 1)
  info.args = {}
  local list = gf:split(string.sub(info.host, pos + 1) or "", "&")
  for i = 1, #list do
    local kv = list[i]
    pos = gf:findStrByByte(kv, "=")
    if pos and pos > 1 then
      info.args[string.sub(kv, 1, pos - 1)] = url.unescape(string.sub(kv, pos + 1))
    end
  end
  return info
end
function CommunityDlg:isVisible()
  if self.setVisibleAction then
    return false
  end
  return Dialog.isVisible(self)
end
function CommunityDlg:setVisible(flag, ignoreLoading, ignorePreLoad, stopCloseDelayAction)
  if self.setVisibleAction then
    self.root:stopAction(self.setVisibleAction)
    self.setVisibleAction = nil
  end
  if flag and self.delayCloseAction then
    if stopCloseDelayAction then
      self.root:stopAction(self.delayCloseAction)
      self.delayCloseAction = nil
    else
      return
    end
  end
  if flag and (not DlgMgr:canShowWebDlg(ignoreLoading, self.name) or DlgMgr:sendMsg("CommunitySmallVideoDlg", "isVisible")) then
    flag = false
  end
  if flag then
    if not ignorePreLoad and self.inPreLoad then
      return
    end
    Dialog.setVisible(self, flag)
    if self.isPlayVideo then
      self:setMusicPauseOrOn(false)
    end
  else
    self.setVisibleAction = performWithDelay(self.root, function()
      Dialog.setVisible(self, flag)
      if self.isPlayVideo then
        self:setMusicPauseOrOn(true)
      end
    end, 0)
  end
  if self.webView then
    local noticePanel = self:getControl("NoticePanel")
    if flag and not noticePanel:isVisible() then
      self:setWebViewVisible(true)
    else
      self:setWebViewVisible(false)
    end
  end
end
function CommunityDlg:setWebViewVisible(flag)
  if flag then
    self.webView:setPositionX(0)
  else
    self.webView:setPositionX(10000)
  end
end
function CommunityDlg:onRefreshButton(sender, eventType)
  self:refreshCurUrl()
end
function CommunityDlg:onCheckBoxClick(sender, eventType)
  local checkBoxName = sender:getName()
  if CommunityMgr:getLastAcesssCheckBox() == checkBoxName then
    return
  end
  if not CommunityMgr:getToken() then
    gf:CmdToServer("CMD_REQUEST_COMMUNITY_TOKEN", {})
    self.radioGroup:setSetlctByName(CommunityMgr:getLastAcesssCheckBox(), true)
    return
  end
  if not CommunityMgr:getCommunityURL() then
    self.radioGroup:setSetlctByName(CommunityMgr:getLastAcesssCheckBox(), true)
    return
  end
  if self.limiteCheckBox then
    gf:ShowSmallTips(CHS[7180021])
    self.radioGroup:setSetlctByName(CommunityMgr:getLastAcesssCheckBox(), true)
    return
  end
  CommunityMgr:setLastAcesssCheckBox(checkBoxName)
  local newUrl
  if not GameMgr.initDataDone and CommunityMgr:getLastAcesssCheckBox() == "CommunityHomePageDlgCheckBox" then
    newUrl = CommunityMgr:getCommunityLoadUrl({
      "visitor=yes"
    })
  else
    newUrl = CommunityMgr:getCommunityLoadUrl()
  end
  if not newUrl then
    return
  end
  self:beginLoadUrl(newUrl)
  self:tryToResumeMusic()
end
function CommunityDlg:createWebView()
  if self.webView then
    return true
  end
  self.webView = ccexp.WebView:create()
  if not self.webView then
    self:setCtrlVisible("RefreshPanel", false, "NoticePanel")
    self:setCtrlVisible("UpgradePanel", true)
    return
  end
  self:setCtrlVisible("UpgradePanel", false)
  local webPanel = self:getControl("WebPanel")
  local panelSize = webPanel:getContentSize()
  self.webView = ccexp.WebView:create()
  if gf:isIos() and DeviceMgr:getOSVer() >= "8" and "function" == type(self.webView.useWKWebViewInIos) then
    self.webView:useWKWebViewInIos(true)
  end
  self.webView:setScalesPageToFit(true)
  self.webView:setContentSize(panelSize)
  self.webView:setAnchorPoint(0, 0)
  self.webView:setTag(WEBPAGE_TAG)
  webPanel:addChild(self.webView)
  self:setWebViewVisible(false)
  self.webView:setOnDidFailLoading(function(sender, url)
    if CommunityMgr:getPreLoadRedDotData() then
      local preLoadType = CommunityMgr:getPreLoadCommunityType()
      local preLoadData = CommunityMgr:getPreLoadRedDotData()
      if preLoadType == PRELOAD_COMMUNITY_TYPE.RED_POINT then
        RedDotMgr:updateMailRedDot(preLoadData)
        CommunityMgr:setPreLoadRedDotData()
      elseif preLoadType == PRELOAD_COMMUNITY_TYPE.MAIL_ARTICAL then
        MessageMgr:pushMsg({
          ["MSG"] = 40961,
          ["count"] = 1,
          [1] = preLoadData
        })
        CommunityMgr:setPreLoadRedDotData()
      end
    end
    CommunityMgr:setPreLoadCommunityType(PRELOAD_COMMUNITY_TYPE.NONE)
    self.loadOver = true
    if not DlgMgr:isDlgOpened(self.name) then
      return
    end
    self:clearSchedule()
    self.waitPanel:setVisible(false)
    self:setCtrlVisible("NoticePanel", true)
    self:removeWebView()
    CommunityMgr:clearOpenCommunityProcessLog()
  end)
  self.webView:setOnDidFinishLoading(function(sender, url)
    if CommunityMgr:getPreLoadRedDotData() then
      local preLoadType = CommunityMgr:getPreLoadCommunityType()
      local preLoadData = CommunityMgr:getPreLoadRedDotData()
      if preLoadType == PRELOAD_COMMUNITY_TYPE.RED_POINT then
        RedDotMgr:updateMailRedDot(preLoadData)
        CommunityMgr:setPreLoadRedDotData()
      elseif preLoadType == PRELOAD_COMMUNITY_TYPE.MAIL_ARTICAL then
        MessageMgr:pushMsg({
          ["MSG"] = 40961,
          ["count"] = 1,
          [1] = preLoadData
        })
        CommunityMgr:setPreLoadRedDotData()
      end
    end
    CommunityMgr:setPreLoadCommunityType(PRELOAD_COMMUNITY_TYPE.NONE)
    self.loadOver = true
    if not DlgMgr:isDlgOpened(self.name) then
      return
    end
    self:clearSchedule()
    self.waitPanel:setVisible(false)
    self:setCtrlVisible("NoticePanel", false)
    if self.webView then
      self:setWebViewVisible(self:isVisible())
    end
    self.curUrl = url
    if #CommunityMgr.openCommunityProcessLog > 0 then
      CommunityMgr:pushOpenCommunityProcessLog(OPEN_COMMUNITY_PROCESS_LOG.SHOW_WEB_DLG)
      CommunityMgr:updateCommunityOpenTime()
      CommunityMgr:saveOpenCommunityProcessLog()
    end
  end)
  if "function" == type(self.webView.setOnJSCallback) then
    self.webView:setOnJSCallback(function(sender, url)
      Client:pushDebugInfo("OnJSCallback:" .. tostring(url))
      local info = self:parseAtmScheme(url)
      if info.scheme ~= "atm" then
        return
      end
      local methodName = info.method
      if string.isNilOrEmpty(methodName) then
        return
      end
      local method = schemeMethods[methodName]
      if not method or "function" ~= type(self[method]) then
        return
      end
      self[method](self, info.args)
    end)
    self.webView:setJavascriptInterfaceScheme("atm")
  end
  return true
end
function CommunityDlg:removeWebView()
  if self.webView then
    self.webView:removeFromParent()
    self.webView = nil
  end
end
function CommunityDlg:clearSchedule()
  if self.schedulId then
    self:stopSchedule(self.schedulId)
    self.schedulId = nil
  end
  if self.waitPanelScheduleId then
    self:stopSchedule(self.waitPanelScheduleId)
    self.waitPanelScheduleId = nil
  end
end
function CommunityDlg:cleanup()
  self:clearSchedule()
  self:removeWebView()
  if not DlgMgr:getDlgByName("CommunitySmallVideoDlg") then
    self:tryToResumeMusic()
  end
  self:unregHttpReq()
  self.setVisibleAction = nil
  self.inPreLoad = nil
  self.loadOver = nil
  self.unlockPwd = nil
  self.limiteCheckBox = nil
  self.delayCloseAction = nil
  SmallTipsMgr:setLocalZOrder(nil, self.name)
end
function CommunityDlg:onCloseButton()
  if self.isPlayVideo then
    self:onStopVideoToJs()
  end
  if self.delayCloseAction then
    self.root:stopAction(self.delayCloseAction)
  end
  self:setVisible(false)
  self.delayCloseAction = performWithDelay(self.root, function()
    DlgMgr:closeDlg(self.name)
  end, DLG_DELAY_CLOSE_TIME)
end
function CommunityDlg:MSG_ENTER_ROOM()
  local loadingDlg = DlgMgr:getDlgByName("LoadingDlg")
  if loadingDlg and loadingDlg:isVisible() then
    self:setVisible(false)
    local dlg = DlgMgr:getDlgByName("LoadingDlg")
    dlg:registerExitCallBack(function()
      if not DlgMgr:getDlgByName("CommunityDlg") then
        return
      end
      self:setVisible(true, true)
    end)
    return
  end
end
function CommunityDlg:showLineupInfo()
  local img = self:getControl("ImageView", nil, self:getControl("ItemPanel", nil, "WaitTimePanel"))
  local size = img:getContentSize()
  local magic = gf:createLoopMagic(ResMgr.magic.sundial_magic)
  magic:setPosition(size.width / 2, size.height / 2)
  img:addChild(magic)
  self:setCtrlVisible("TitlePanel", true)
end
function CommunityDlg:setChannel(str, magicLevel)
  if str == CHS[5430038] then
    str = CHS[5410686]
  end
  local info = gf:split(str, CHS[7000078])
  if info and #info > 1 then
    self:setLabelText("WaitTimeLabel", info[2], "ChanelPanel")
  else
    self:setLabelText("WaitTimeLabel", str, "ChanelPanel")
  end
  DlgMgr:sendMsg("LineUpDlg", "showMagic", self:getControl("MagicPanel", nil, "ChanelPanel"), magicLevel)
end
function CommunityDlg:setWaitTime(str)
  local info = gf:split(str, CHS[3004440])
  if info and #info > 1 then
    self:setLabelText("WaitTimeLabel", info[2], "WaitTimePanel")
  else
    self:setLabelText("WaitTimeLabel", str, "WaitTimePanel")
  end
end
return CommunityDlg
