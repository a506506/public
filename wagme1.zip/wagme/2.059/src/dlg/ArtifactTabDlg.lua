local TabDlg = require("dlg/TabDlg")
local ArtifactTabDlg = Singleton("ArtifactTabDlg", TabDlg)
ArtifactTabDlg.defDlg = "ArtifactRefineDlg"
ArtifactTabDlg.dlgs = {
  ArtifactRefineTabDlgCheckBox = "ArtifactRefineDlg",
  ArtifactSkillUpTabDlgCheckBox = "ArtifactSkillUpDlg"
}
ArtifactTabDlg.orderList = {ArtifactRefineTabDlgCheckBox = 1, ArtifactSkillUpTabDlgCheckBox = 2}
ArtifactTabDlg.tabMargin = 5
ArtifactTabDlg.lastSelectItemId = nil
function ArtifactTabDlg:init()
  TabDlg.init(self)
end
function ArtifactTabDlg:setLastSelectItemId(id)
  self.lastSelectItemId = id
end
function ArtifactTabDlg:cleanup()
end
function ArtifactTabDlg:getOpenDefaultDlg()
  return TabDlg.getOpenDefaultDlg(self) or "ArtifactRefineDlg"
end
return ArtifactTabDlg
