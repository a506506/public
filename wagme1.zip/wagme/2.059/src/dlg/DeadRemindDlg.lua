local DeadRemindDlg = Singleton("DeadRemindDlg", Dialog)
function DeadRemindDlg:init()
  self:setCtrlFullClientEx("BKPanel")
  self:bindListener("SkillButton", self.onSkillButton, "RemindPanel_1")
  self:bindListener("PetButton", self.onPetButton, "RemindPanel_1")
  self:bindListener("TaoButton", self.onTaoButton, "RemindPanel_1")
  self:bindListener("EquipButton", self.onEquipButton, "RemindPanel_1")
  self:bindListener("SkillButton", self.onSkillButton, "RemindPanel_2")
  self:bindListener("PetButton", self.onPetButton, "RemindPanel_2")
  self:bindListener("TaoButton", self.onTaoButton, "RemindPanel_2")
  self:bindListener("EquipButton", self.onEquipButton, "RemindPanel_2")
  self:bindListener("CommunityButton", self.onCommunityButton, "RemindPanel_2")
  self:setCtrlVisible("RemindPanel_1", true)
  self:setCtrlVisible("RemindPanel_2", false)
  self:bindListener("ConfrimButton", self.onConfrimButton)
  self:bindListener("ConfrimPanel", self.onConfrimButton)
  self:bindListener("MainPanel", self.onCloseButton)
  self:setCtrlEnabled("Image_164", false)
  self:setCtrlEnabled("Image_162", false)
  self:setCtrlEnabled("Image_163", false)
  self:getControl("MainPanel"):setContentSize(Const.WINSIZE.width / Const.UI_SCALE, Const.WINSIZE.height / Const.UI_SCALE)
  self:getControl("BlackImage"):setContentSize(Const.WINSIZE.width / Const.UI_SCALE, Const.WINSIZE.height / Const.UI_SCALE)
  local dlg = DlgMgr:getDlgByName("CombatResultDlg")
  if dlg then
    dlg:setVisible(false)
  end
end
function DeadRemindDlg:onDlgOpened(param)
  if param and param[1] then
    if param[1] == "8" then
      self.communityType = OPEN_COMMUNITY_PARA.FUBEN
      self:setCtrlVisible("RemindPanel_1", false)
      self:setCtrlVisible("RemindPanel_2", true)
    elseif param[1] == "21" then
      self.communityType = OPEN_COMMUNITY_PARA.BAXIAN
      self:setCtrlVisible("RemindPanel_1", false)
      self:setCtrlVisible("RemindPanel_2", true)
    else
      self:setCtrlVisible("RemindPanel_1", true)
      self:setCtrlVisible("RemindPanel_2", false)
    end
  end
end
function DeadRemindDlg:cleanup()
  local dlg = DlgMgr:getDlgByName("CombatResultDlg")
  if dlg then
    dlg:setVisible(true)
  end
  self.communityType = nil
end
function DeadRemindDlg:onSkillButton(sender, eventType)
  if Me:queryBasic("family") == "" or not GuideMgr:hasThisTab("SkillDlgCheckBox") then
    gf:ShowSmallTips(CHS[3002379])
    return
  end
  DlgMgr:openDlg("SkillDlg")
end
function DeadRemindDlg:onPetButton(sender, eventType)
  DlgMgr:openDlg("PetAttribDlg")
end
function DeadRemindDlg:onTaoButton(sender, eventType)
  local limitLevel = 45
  if limitLevel > Me:queryBasicInt("level") then
    gf:ShowSmallTips(string.format(CHS[3002380], limitLevel))
    return
  end
  local last = DlgMgr:getLastDlgByTabDlg("GetTaoTabDlg") or "GetTaoDlg"
  DlgMgr:openDlg(last)
end
function DeadRemindDlg:onEquipButton(sender, eventType)
  local limitLevel = 35
  if limitLevel > Me:queryBasicInt("level") then
    gf:ShowSmallTips(string.format(CHS[3002380], limitLevel))
    return
  end
  DlgMgr:openTabDlg("EquipmentTabDlg")
end
function DeadRemindDlg:onConfrimButton(sender, eventType)
  self:onCloseButton()
end
function DeadRemindDlg:onCommunityButton(sender, eventType)
  if not self.communityType then
    return
  end
  CommunityMgr:openCommunityDlgByUrlPara(self.communityType)
end
return DeadRemindDlg
