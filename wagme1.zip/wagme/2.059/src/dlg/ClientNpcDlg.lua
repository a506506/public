local ClientNpcDlg = Singleton("ClientNpcDlg", Dialog)
local List = require("core/List")
local MARGIN = 6
local MARGIN_ITEM = 7
local ARROW_DISPLAY_COUNT = 4
function ClientNpcDlg:getCfgFileName()
  return ResMgr:getDlgCfg("NewNpcDlg")
end
function ClientNpcDlg:init()
  self:setFullScreen()
  self:setCtrlFullClient("TouchPanel")
  self.itemButton = self:retainCtrl("MenuButton1")
  self.textColor = self.itemButton:getTitleColor()
  local listViewCtrl = self:getControl("MenuListView")
  listViewCtrl:removeAllItems()
  listViewCtrl:addScrollViewEventListener(function(sender, eventType)
    self:updateSlider(sender, eventType)
  end)
  self.itemPos = nil
  self:setCtrlVisible("TouchPanel", true)
  self:setCtrlVisible("NameBKImage", true)
end
function ClientNpcDlg:adjustNpcDir()
  local npc = CharMgr:getChar(self.npcId)
  if not npc then
    return
  end
  local npcDir = gf:defineDirForPet(cc.p(npc.curX, npc.curY), cc.p(Me.curX, Me.curY))
  npc:setDir(npcDir)
  local dir = gf:defineDir(cc.p(Me.curX, Me.curY), cc.p(npc.curX, npc.curY), Me:getDlgIcon())
  Me:setDir(dir)
end
function ClientNpcDlg:updateSlider(sender, eventType)
  if ccui.ScrollviewEventType.scrolling == eventType then
    local listViewCtrl = sender
    local menuItemCount = listViewCtrl:getChildrenCount()
    local listInnerContent = listViewCtrl:getInnerContainer()
    local innerSize = listInnerContent:getContentSize()
    local listViewSize = listViewCtrl:getContentSize()
    local totalHeight = innerSize.height - listViewSize.height
    local innerPosY = listInnerContent:getPositionY()
    local persent = 1 - -innerPosY / totalHeight
    persent = math.floor(persent * 100)
    if menuItemCount > 0 and totalHeight > MARGIN_ITEM then
      if innerPosY <= -totalHeight + MARGIN_ITEM then
        self:addMagic("MagicPanel", ResMgr:getMagicDownIcon())
      else
        if not self.first then
          self:removeMagic("MagicPanel", ResMgr:getMagicDownIcon())
        end
        self.first = false
      end
    end
    local fadeOut = cc.FadeOut:create(1)
    local func = cc.CallFunc:create(function()
      sliderCtrl:setVisible(false)
    end)
    local action = cc.Sequence:create(fadeOut, func)
  end
end
function ClientNpcDlg:setData(id, name, content, callBack, defaultSelectIndex, icon)
  self.npcId = id
  self.callBack = callBack
  self.defaultSelectIndex = defaultSelectIndex
  self.npc = CharMgr:getChar(self.npcId)
  if self.npc then
    self:setPortrait(self.npc:queryBasicInt("icon"))
  else
    self:setPortrait(icon)
  end
  self:setLabelText("NameLabel", name)
  self:adjustNpcDir()
  self:setMenu(content, name)
end
function ClientNpcDlg:onCloseButton()
  if self.callBack and type(self.callBack) == "function" and self.defaultSelectIndex then
    self.callBack(self.defaultSelectIndex)
  end
  DlgMgr:closeDlg(self.name)
end
function ClientNpcDlg:cleanup()
  self.npcName = nil
end
function ClientNpcDlg:setPortrait(icon)
  self:setCtrlVisible("PortraitBonesPanel", false)
  self:setCtrlVisible("PortraitNormalPanel", true)
  local npcPortrait = self:getControl("PortraitImage", Const.UIImage, "PortraitNormalPanel")
  npcPortrait:loadTexture(ResMgr:getBigPortrait(icon))
end
function ClientNpcDlg:setMenu(content, npcName)
  self:removeMagic("MagicPanel", ResMgr:getMagicDownIcon())
  self.first = true
  self:setTip(content.instruction)
  local list, _ = self:resetListView("MenuListView", MARGIN_ITEM)
  local count = content.count
  for i = 1, count do
    local cell = self.itemButton:clone()
    list:pushBackCustomItem(cell)
    self:setButtonText(cell, content[i])
    self:setCtrlVisible("TipImage", false, cell)
    self:bindTouchEventListener(cell, self.onSelectItem)
    cell.index = i
  end
  if count >= ARROW_DISPLAY_COUNT then
    self:addMagic("MagicPanel", ResMgr:getMagicDownIcon())
  end
end
function ClientNpcDlg:setButtonText(btn, text)
  btn:setTitleText("")
  local textPanel = self:getControl("TextPanel", nil, btn)
  local showText, param = string.match(text, "(.*){(.*)}")
  if string.isNilOrEmpty(showText) then
    self:setColorText(text, textPanel, nil, nil, nil, nil, 23, LOCATE_POSITION.MID_BOTTOM)
    return
  end
  local timeTick = string.match(param, "TickTime=(.+)")
  if string.isNilOrEmpty(timeTick) then
    return
  end
  timeTick = tonumber(timeTick)
  self:setColorText(string.format(showText, timeTick), textPanel, nil, nil, nil, nil, 23, LOCATE_POSITION.MID_BOTTOM)
  if timeTick > 0 then
    schedule(btn, function()
      if timeTick <= 0 then
        btn:stopAllActions()
        self:onCloseButton()
      end
      timeTick = timeTick - 1
      self:setColorText(string.format(showText, timeTick), textPanel, nil, nil, nil, nil, 23, LOCATE_POSITION.MID_BOTTOM)
    end, 1)
  end
end
function ClientNpcDlg:onSelectItem(sender, eventType)
  if eventType ~= ccui.TouchEventType.ended then
    return
  end
  if self.callBack and type(self.callBack) == "function" then
    self.callBack(sender.index)
  end
  DlgMgr:closeDlg(self.name)
end
function ClientNpcDlg:setTip(strTip)
  local panel = self:getControl("TipBackPanel")
  panel:removeAllChildren()
  local box = panel:getBoundingBox()
  local container = ccui.Layout:create()
  container:setPosition(0, 0)
  local scrollview = ccui.ScrollView:create()
  scrollview:setContentSize(panel:getContentSize())
  scrollview:setDirection(ccui.ScrollViewDir.vertical)
  scrollview:addChild(container)
  panel:addChild(scrollview)
  local tip = CGAColorTextList:create()
  if tip.setPunctTypesetting then
    tip:setPunctTypesetting(true)
  end
  tip:setFontSize(21)
  tip:setContentSize(box.width - MARGIN * 4, 0)
  tip:setString(strTip)
  tip:setDefaultColor(self.textColor.r, self.textColor.g, self.textColor.b)
  tip:updateNow()
  local labelW, labelH = tip:getRealSize()
  tip:setPosition(MARGIN, labelH)
  container:addChild(tolua.cast(tip, "cc.LayerColor"))
  container:setContentSize(labelW, labelH)
  scrollview:setInnerContainerSize(container:getContentSize())
  if labelH < panel:getContentSize().height then
    container:setPositionY(panel:getContentSize().height - labelH)
  end
end
return ClientNpcDlg
