local ElitePetShopDlg = Singleton("ElitePetShopDlg", Dialog)
local VariationPetList = require(ResMgr:getCfgPath("VariationPetList.lua"))
local EpicPetList = require(ResMgr:getCfgPath("EpicPetList.lua"))
local LIST_MAX_COUNT = 3
function ElitePetShopDlg:init(type)
  self:bindListener("BuyButton", self.onBuyButton, "OperatePanel")
  self:bindListener("BuyButton", self.onSubmitButton, "SubmissionPanel")
  self.serverPrice = nil
  self.petUnitPanel = self:getControl("ZodiacPanel", Const.UIPanel)
  self.petUnitPanel:retain()
  self.petUnitPanel:removeFromParent()
  self.petSelectEff = self:getControl("BChosenEffectImage", Const.UIPanel, self.petUnitPanel)
  self.petSelectEff:retain()
  self.petSelectEff:removeFromParent()
  self.petSelectEff:setVisible(true)
  self:setCtrlTouchEnabled("ShapeButton", false)
  self.petsPanel = self:retainCtrl("PetsPanel", "ChoseMenuPanel_0")
  self:setCtrlVisible("TriangleImage", false)
  self:bindFloatPanelListener("ChoseMenuPanel_0", "ShapeButton", nil, function()
    local img = self:getControl("TriangleImage")
    img:setFlippedY(false)
  end)
  self.showPets = {}
  self.dlgType = type
  local petList
  if self.dlgType == 2 then
    petList = EpicPetList
    self.cashName = CHS[7190029]
    self:setLabelText("Label", CHS[7190035], "ShapeButton")
    self:setLabelText("TitleLabel1", CHS[7190081], "TitlePanel")
    self:setLabelText("TitleLabel2", CHS[7190081], "TitlePanel")
  elseif self.dlgType == 3 then
    petList = EpicPetList
    self:setLabelText("Label", CHS[7190035], "ShapeButton")
    self:setLabelText("TitleLabel1", CHS[7190081], "TitlePanel")
    self:setLabelText("TitleLabel2", CHS[7190081], "TitlePanel")
  else
    petList = VariationPetList
    self.cashName = CHS[4000268]
    self:setLabelText("Label", CHS[7190034], "ShapeButton")
    self:setLabelText("TitleLabel1", CHS[7190082], "TitlePanel")
    self:setLabelText("TitleLabel2", CHS[7190082], "TitlePanel")
    self:setCtrlTouchEnabled("ShapeButton", true)
    self:bindListener("ShapeButton", self.onShapeButton)
    self:setChoseMenuPanel({
      CHS[5420249],
      CHS[5410411]
    })
    self.petType = CHS[5420249]
  end
  self.petListorder = {}
  for i, pet in pairs(petList) do
    table.insert(self.petListorder, pet)
  end
  table.sort(self.petListorder, function(l, r)
    return l.order < r.order
  end)
  if self.cashName then
    local cashText, fontColor = gf:getArtFontMoneyDesc(InventoryMgr:getAmountByName(self.cashName))
    self:setNumImgForPanel("OwnAmountPanel", fontColor, cashText, false, LOCATE_POSITION.CENTER, 25)
  end
  self:setCtrlVisible("SubmissionPanel", 3 == self.dlgType)
  self:setCtrlVisible("OperatePanel", 3 ~= self.dlgType)
  self:hookMsg("MSG_OPEN_ELITE_PET_SHOP", ElitePetShopDlg)
  self:hookMsg("MSG_EXCHANGE_EPIC_PET_SHOP")
end
function ElitePetShopDlg:cleanup()
  if self.petSelectEff then
    self.petSelectEff:release()
    self.petSelectEff = nil
  end
  if self.petUnitPanel then
    self.petUnitPanel:release()
    self.petUnitPanel = nil
  end
  self.openSelectParam = nil
  self.showPets = nil
  self.elitePetData = nil
  self.cashName = nil
  if 3 == self.dlgType then
    gf:CmdToServer("CMD_EXCHANGE_EPIC_PET_EXIT")
  end
end
function ElitePetShopDlg:setChoseMenuPanel(list)
  local panel = self:getControl("ChoseMenuPanel_0")
  panel:removeAllChildren()
  local count = #list
  local startY = 8
  local cellH = self.petsPanel:getContentSize().height
  for i = 1, count do
    local cell = self.petsPanel:clone()
    cell:setName(list[i])
    cell:setPositionY(startY + (cellH + 2) * (count - i))
    self:setLabelText("NameLabel", list[i], cell)
    panel:addChild(cell)
    self:bindTouchEndEventListener(cell, self.onPetTypePanel)
  end
  panel:setContentSize(panel:getContentSize().width, startY * 2 + cellH * count + 2 * (count - 1))
  self:setCtrlVisible("TriangleImage", true)
end
function ElitePetShopDlg:getPetSelectImage()
  self.petSelectEff:removeFromParent()
  return self.petSelectEff
end
function ElitePetShopDlg:initLeftPetList()
  local petListView = self:resetListView("PetTypeListView", 4)
  local selectName
  if self.openSelectParam then
    selectName = self.openSelectParam[1]
    self.openSelectParam = nil
  end
  local function canShow(i)
    if self.dlgType == 1 then
      if self.petType == CHS[5420249] and self.petListorder[i].variation_type ~= nil and self.petListorder[i].variation_type ~= VARIATION_TYPE.ANIMAL then
        return false
      elseif self.petType == CHS[5410411] and self.petListorder[i].variation_type ~= VARIATION_TYPE.MLZJ then
        return false
      end
    end
    if self.showPets[self.petListorder[i].name] then
      return true
    end
    return false
  end
  local imgPath
  if self.cashName == CHS[7190029] then
    imgPath = ResMgr.ui.zhaohuanling_shenshou
  elseif self.cashName == CHS[4000268] then
    imgPath = ResMgr.ui.zhaohuanling_bianyi
  elseif self.cashName == CHS[5410420] then
    imgPath = ResMgr.ui.zhaohuanling_mlzj
  end
  if imgPath then
    self:setImage("HaveCashImage_1", imgPath, "OperatePanel")
  end
  local index = 1
  for i = 1, #self.petListorder do
    if canShow(i) then
      local panel = self.petUnitPanel:clone()
      panel.petName = self.petListorder[i].name
      panel:setTag(i)
      self:setImage("PetImage", ResMgr:getSmallPortrait(self.petListorder[i].icon), panel)
      self:setItemImageSize("PetImage", panel)
      self:setLabelText("PetNameLabel", self.petListorder[i].name, panel)
      self:setCtrlVisible("PriceLabel", self.dlgType ~= 3, panel)
      self:setCtrlVisible("PriceImage", self.dlgType ~= 3, panel)
      self:setLabelText("PriceLabel", self.petListorder[i].price, panel)
      if imgPath then
        self:setImage("PriceImage", imgPath, panel)
      end
      petListView:pushBackCustomItem(panel)
      self:bindTouchEndEventListener(panel, self.onSetPetAttrib)
      if not selectName and index == 1 or selectName == self.petListorder[i].name then
        self:onSetPetAttrib(panel)
      end
      index = index + 1
    end
  end
end
function ElitePetShopDlg:setPetListFromSer(data)
  self.serverPrice = data.info
  self:setPriceBySer(data.info)
end
function ElitePetShopDlg:setPriceBySer(info)
  local petListView = self:getControl("PetTypeListView")
  local items = petListView:getItems()
  for i, panel in pairs(items) do
    self:setLabelText("PriceLabel", info[i].price, panel)
  end
end
function ElitePetShopDlg:selectTypePanel(name)
  if name == CHS[5410411] then
    self.cashName = CHS[5410420]
  else
    self.cashName = CHS[5420043]
  end
  local cashText, fontColor = gf:getArtFontMoneyDesc(InventoryMgr:getAmountByName(self.cashName))
  self:setNumImgForPanel("OwnAmountPanel", fontColor, cashText, false, LOCATE_POSITION.CENTER, 25)
  self.petType = name
  self:setLabelText("Label", name, "ShapeButton")
end
function ElitePetShopDlg:onPetTypePanel(sender, eventType)
  local name = sender:getName()
  self:selectTypePanel(name)
  self:initLeftPetList()
  self:onShapeButton()
end
function ElitePetShopDlg:onSetPetAttrib(sender, eventType)
  if not sender then
    local listView = self:getControl("PageListView")
    local panel = listView:getItem(0)
    sender = self:getControl("Panel1")
  end
  local tag = sender:getTag()
  local petInfo = self.petListorder[tag]
  self.selectPet = petInfo
  self:setPetAttribInfo(petInfo, tag)
  sender:addChild(self:getPetSelectImage())
  sender:requestDoLayout()
end
function ElitePetShopDlg:setPetAttribInfo(petInfo, tag)
  local add = 40
  local panel = self:getControl("PetShapePanel")
  self:setPortrait("PetIconPanel", petInfo.icon, 0, panel, true, nil, nil, cc.p(-5, -36))
  self:setLabelText("PetNameLabel", petInfo.name, "PetNamePanel_0")
  self:setLabelText("PetPolarLabel", petInfo.polar, panel)
  local life = petInfo.life + add + Formula:getElitePetBasicAddByValue(petInfo.life)
  self:setLabelText("LifeValueLabel", life)
  local mana = petInfo.mana + add + Formula:getElitePetBasicAddByValue(petInfo.mana)
  self:setLabelText("ManaValueLabel", mana)
  local speed = petInfo.speed + add + Formula:getElitePetBasicAddByValue(petInfo.speed)
  self:setLabelText("SpeedValueLabel", speed)
  local phy_attack = petInfo.phy_attack + add + Formula:getElitePetBasicAddByValue(petInfo.phy_attack)
  self:setLabelText("PhyPowerValueLabel", phy_attack)
  local mag_attack = petInfo.mag_attack + add + Formula:getElitePetBasicAddByValue(petInfo.mag_attack)
  self:setLabelText("MagPowerValueLabel", mag_attack)
  self:setLabelText("TotalEffectValueLabel", life + mana + speed + phy_attack + mag_attack)
  self:setNumImgForPanel("PricePanel", ART_FONT_COLOR.DEFAULT, petInfo.price, false, LOCATE_POSITION.CENTER, 23, self:getControl("OwnPanel"))
  self:setLabelText("LevelLabel", CHS[3002398] .. petInfo.level_req)
  for i = 1, 3 do
    self:setImage("SkillImage_" .. i, SkillMgr:getSkillIconFilebyName(petInfo.skills[i]))
    local panel = self:getControl("SkillPanel_" .. i)
    self:setCtrlVisible("ChosenEffectImage", false, panel)
    panel:setTag(i)
    self:bindTouchEndEventListener(panel, self.skillFloatDlg)
  end
end
function ElitePetShopDlg:skillFloatDlg(sender, eventType)
  for i = 1, 3 do
    local panel = self:getControl("SkillPanel_" .. i)
    self:setCtrlVisible("ChosenEffectImage", false, panel)
  end
  self:setCtrlVisible("ChosenEffectImage", true, sender)
  local skillIndex = sender:getTag()
  local rect = self:getBoundingBoxInWorldSpace(sender)
  SkillMgr:showSkillDescDlg(self.selectPet.skills[skillIndex], 0, true, rect)
end
function ElitePetShopDlg:doSubmit()
  if not self.selectPet then
    gf:ShowSmallTips(CHS[2100228])
    return
  end
  gf:CmdToServer("CMD_EXCHANGE_EPIC_PET_SUBMIT_DLG", {
    target_name = self.selectPet.name
  })
end
function ElitePetShopDlg:onBuyButton(sender, eventType)
  if Me:isInTradingShowState() then
    gf:ShowSmallTips(CHS[4300227])
    return
  end
  local pet = {
    type = self.dlgType,
    name = self.selectPet.name
  }
  gf:CmdToServer("CMD_BUY_FROM_ELITE_PET_SHOP", pet)
end
function ElitePetShopDlg:onSubmitButton()
  if not self:checkSafeLockRelease(doSubmit) then
    self:doSubmit()
  end
end
function ElitePetShopDlg:onShapeButton(sender, eventType)
  local ctrl = self:getControl("ChoseMenuPanel_0", nil, sender)
  ctrl:setVisible(not ctrl:isVisible())
  local img = self:getControl("TriangleImage")
  img:setFlippedY(ctrl:isVisible())
end
function ElitePetShopDlg:onSelectPetListView(sender, eventType)
end
function ElitePetShopDlg:onDlgOpened(param)
  self.openSelectParam = param
  if param and param[1] and VariationPetList[param[1]] then
    local type = CHS[5420249]
    if VariationPetList[param[1]].variation_type == VARIATION_TYPE.MLZJ then
      type = CHS[5410411]
    end
    self:selectTypePanel(type)
  end
end
function ElitePetShopDlg:MSG_OPEN_ELITE_PET_SHOP(data)
  self.showPets = {}
  for i = 1, #data.info do
    self.showPets[data.info[i].name] = true
  end
  self:initLeftPetList()
end
function ElitePetShopDlg:MSG_EXCHANGE_EPIC_PET_SHOP(data)
  self.showPets = {}
  for i = 1, #data.pet_names do
    self.showPets[data.pet_names[i]] = true
  end
  self:initLeftPetList()
end
return ElitePetShopDlg
