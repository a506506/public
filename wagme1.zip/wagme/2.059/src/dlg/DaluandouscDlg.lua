local DaluandouscDlg = Singleton("DaluandouscDlg", Dialog)
local COMBAT_POS = {
  1,
  2,
  4,
  5
}
local STORAGE_EXP_MAP = {
  2,
  5,
  5
}
local RETINUE_CARD_MAX_DIS = 5
local UPGRADE_COLOR = cc.c3b(255, 242, 102)
local DEFAULT_SELECT_COLOR = cc.c3b(102, 255, 255)
function DaluandouscDlg:init()
  self:setFullScreen()
  self:bindListener("ZhaomuButton", self.onRecruitButton)
  self:bindListener("ShouqiButton", self.onShouqiButton)
  self:bindListener("TuJianButton", self.onTuJianButton)
  self:bindListener("RecordButton", self.onRecordButton)
  self:bindListener("PromoteButton", self.onPromoteButton)
  self:bindListener("ExpButton", self.onUpStorageButton, "ExpButtonPanel")
  self:bindListener("RuleButton", self.onRuleButton)
  self:bindListener("ReadyButton", self.onReadyButton)
  self:bindFloatPanelListener("TipsPanel3", nil, nil, function()
    self:tryPlayGuide({3})
  end)
  for i = 1, 4 do
    self:setCtrlVisible("TipsPanel" .. i, false)
  end
  local tipPanel = self:getControl("TipsPanel2")
  tipPanel.orgX = tipPanel:getPosition()
  local effectPanel = self:getControl("UpperPanel")
  self.raceEffectPanel = self:getControl("RacePanel", nil, effectPanel)
  for i = 1, 3 do
    local panel = self:getControl("IconPanel" .. i, nil, self.raceEffectPanel)
    self:bindListener("IconPanel" .. i, self.onTypeEffectPanel, self.raceEffectPanel)
    self:setImage("IconImage", ResMgr:getRetinueTypeIcon(i), panel)
  end
  self.polarEffectPanel = self:getControl("PolarPanel", nil, effectPanel)
  for i = 1, 5 do
    local panel = self:getControl("IconPanel" .. i, nil, self.polarEffectPanel)
    self:bindListener("IconPanel" .. i, self.onPolarEffectPanel, self.polarEffectPanel)
    self:setImage("IconImage", ResMgr:getRetinuePolarIcon(i), panel)
  end
  self:refreshPetPanel()
  local userPanel = self:getControl("UserPanel")
  self:setImage("HeadImage", ResMgr:getSmallPortrait(Me:queryBasicInt("org_icon")), userPanel)
  self.retinueSelectPanel = self:getControl("RetinueSelectPanel")
  self.retinueSelectPanel:setVisible(true)
  self.bigRetinuePanel = self:retainCtrl("BigRetinuePanel", self.retinueSelectPanel)
  self.bigRetinuePanel:setVisible(true)
  self.smallRetinuePanel = self:retainCtrl("SmallRetinuePanel", self.retinueSelectPanel)
  self.smallRetinuePanel:setVisible(true)
  self:bindRetinueSelectEvent()
  self.trashPanel = self:getControl("HuishouPanel")
  self:updateTrashPanelStatus()
  self:updateRecruitStatus()
  self:setMainDlgVisible(false)
  self.guideIndex = nil
  self:hookMsg("MSG_FFA_RECRUIT_LIST")
  self:hookMsg("MSG_FFA_FIGHT_RECORD")
  self:hookMsg("MSG_FFA_UPGRADE_RETINUE_RANK")
  self:hookMsg("MSG_ENTER_ROOM")
end
function DaluandouscDlg:setMainDlgVisible(flag)
  local zjmDlg = DlgMgr:getDlgByName("DaluandouzjmDlg")
  if zjmDlg then
    if flag and Me:isInCombat() then
      zjmDlg:setVisible(false)
    else
      zjmDlg:setVisible(flag)
    end
  end
  local chatDlg = DlgMgr:getDlgByName("ChatDlg")
  if chatDlg then
    chatDlg:setVisible(flag)
  end
end
function DaluandouscDlg:setData(data)
  self.retinueList = data.list
  self:refreshTimePanel()
  self:refreshRetinuePanel()
  self:refreshStorageInfo()
end
function DaluandouscDlg:refreshPetPanel()
  local petPanel = self:getControl("PetPanel")
  self:setCtrlVisible("HeadImage", false, petPanel)
  local fightPet = PetMgr:getFightPet(PET_LOCATE.DIFU)
  if fightPet then
    self:setCtrlVisible("HeadImage", true, petPanel)
    self:setImage("HeadImage", ResMgr:getSmallPortrait(fightPet:queryBasicInt("portrait")), petPanel)
  end
end
function DaluandouscDlg:bindRetinueSelectEvent()
  local function createMovePanel(panel)
    local newPanel
    if panel.info.combat_pos < 10 then
      newPanel = self.bigRetinuePanel:clone()
    else
      newPanel = self.smallRetinuePanel:clone()
    end
    local offsetPos = panel:convertToNodeSpace(GameMgr.curTouchPos)
    local nodePos = self.retinueSelectPanel:convertToNodeSpace(GameMgr.curTouchPos)
    newPanel:setPosition(nodePos.x - offsetPos.x, nodePos.y - offsetPos.y)
    self.retinueSelectPanel:addChild(newPanel)
    self:setRetinuePanel(newPanel, panel.info)
    self:setCtrlVisible("EffectImage", true, newPanel)
    self:setCtrlVisible("UpgradeButton", false, newPanel)
    local effectImage = self:getControl("EffectImage", nil, newPanel)
    if effectImage then
      effectImage:setColor(DEFAULT_SELECT_COLOR)
    end
    return newPanel
  end
  local function getFocusedPanel(pos, checkTrashPanel)
    if checkTrashPanel then
      local touchPos = self.trashPanel:getParent():convertToNodeSpace(pos)
      local box = self.trashPanel:getBoundingBox()
      if box and cc.rectContainsPoint(box, touchPos) then
        return self.trashPanel
      end
    end
    for i = 1, #COMBAT_POS do
      local panel = self:getControl("FightRetinuePanel" .. COMBAT_POS[i])
      local touchPos = panel:getParent():convertToNodeSpace(pos)
      local box = panel:getBoundingBox()
      if box and cc.rectContainsPoint(box, touchPos) then
        return panel
      end
    end
    for i = 1, 8 do
      local panel = self:getControl("RetinueSinglePanel" .. i)
      local touchPos = panel:getParent():convertToNodeSpace(pos)
      local box = panel:getBoundingBox()
      if box and cc.rectContainsPoint(box, touchPos) then
        return panel
      end
    end
  end
  local function updateInRetinuePanelEffect(pos)
    self:setCtrlVisible("EffectImage", false, self.trashPanel)
    self:resetSelectEffect()
    self.moveInPanel = getFocusedPanel(pos, true)
    if self.moveInPanel then
      self:setCtrlVisible("EffectImage", true, self.moveInPanel)
    end
  end
  local touchPanel = self:getControl("RetinueSelectPanel")
  local function onTouchBegan(touch, event)
    local touchPos = touch:getLocation()
    touchPos = touchPanel:getParent():convertToNodeSpace(touchPos)
    local box = touchPanel:getBoundingBox()
    if nil == box then
      return false
    end
    if cc.rectContainsPoint(box, touchPos) then
      self.retinueSelectPanel:removeAllChildren()
      self.moveInPanel = nil
      self.selectMovePanel = nil
      self.beginTouchPos = nil
      self.needOpenCard = nil
      local focusPanel = getFocusedPanel(touch:getLocation(), true)
      if focusPanel == self.trashPanel then
        if self.selectPanel then
          self:onHuishouPanel()
        end
        return
      end
      if not self.selectPanel or getFocusedPanel(touch:getLocation()) and getFocusedPanel(touch:getLocation()).info then
        local newSelectPanel = getFocusedPanel(touch:getLocation())
        if self.selectPanel then
          self:resetSelectPanelEffect(self.selectPanel)
        end
        self.selectPanel = newSelectPanel
        if not self.selectPanel or not self.selectPanel.info then
          self:updateTrashPanelStatus()
          return
        end
        self:updateTrashPanelStatus(self.selectPanel.info)
        self:resetSelectEffect()
        self:setCtrlVisible("RetinuePanel", false, self.selectPanel)
        self.selectMovePanel = createMovePanel(self.selectPanel)
        self.lastTouchPos = touch:getLocation()
        self.beginTouchPos = touch:getLocation()
        self.needOpenCard = true
        return true
      else
        self:resetSelectPanelEffect(self.selectPanel)
        self:updateTrashPanelStatus()
      end
    end
    return false
  end
  local function onTouchMove(touch, event)
    if not self.selectMovePanel then
      return
    end
    local touchPos = touch:getLocation()
    local offsetX, offsetY = touchPos.x - self.lastTouchPos.x, touchPos.y - self.lastTouchPos.y
    if gf:distance(self.beginTouchPos.x, self.beginTouchPos.y, touchPos.x, touchPos.y) > RETINUE_CARD_MAX_DIS then
      self.needOpenCard = false
    end
    local posX, posY = self.selectMovePanel:getPosition()
    self.selectMovePanel:setPosition(cc.p(posX + offsetX, posY + offsetY))
    self.lastTouchPos = touchPos
    updateInRetinuePanelEffect(GameMgr.curTouchPos)
  end
  local function onTouchEnd(touch, event)
    if not self.selectMovePanel then
      return
    end
    local touchPos = touch:getLocation()
    local function clearFunc()
      self:setEffectImageStatus(self.moveInPanel, false)
      self.moveInPanel = nil
      self.selectMovePanel = nil
      self.beginTouchPos = nil
      self.needOpenCard = nil
      if self.retinueSelectPanel then
        self.retinueSelectPanel:removeAllChildren()
      end
    end
    if not self.selectPanel then
      clearFunc()
      return
    end
    if self.moveInPanel and self.moveInPanel == self.trashPanel then
      local tips = string.format(CHS[7100745], self:getRetinueNameColorStr(self.selectMovePanel.info.name), self.selectMovePanel.info.rank, self:getSellCost(self.selectMovePanel.info))
      self.selectMovePanel:setVisible(false)
      gf:confirm(tips, function()
        gf:CmdToServer("CMD_FFA_SELL_RETINUE", {
          id = self.selectMovePanel.info.id
        })
        self:setCtrlVisible("EffectImage", false, self.trashPanel)
        clearFunc()
      end, function()
        self:setCtrlVisible("RetinuePanel", true, self.selectPanel)
        self:setCtrlVisible("EffectImage", false, self.trashPanel)
        clearFunc()
      end)
    else
      self:setCtrlVisible("RetinuePanel", true, self.selectPanel)
      if self.moveInPanel then
        if not self.moveInPanel.info and self.moveInPanel.pos < 10 and 10 < self.selectMovePanel.info.combat_pos then
          local fightCount = self:getCombatRetinueCount()
          local allCount = DlgMgr:sendMsg("DaluandouzjmDlg", "getMyData").retinue_bag_lv
          if fightCount >= allCount then
            gf:ShowSmallTips(string.format(CHS[7100760], fightCount))
            clearFunc()
            return true
          end
        end
        gf:CmdToServer("CMD_FFA_SET_RETINUE_COMBAT_POS", {
          id = self.selectMovePanel.info.id,
          pos = self.moveInPanel.pos
        })
      else
        if self.needOpenCard and self.selectPanel and gf:distance(self.beginTouchPos.x, self.beginTouchPos.y, touchPos.x, touchPos.y) <= RETINUE_CARD_MAX_DIS then
          UndergroundMgr:requestRetinueInfo(tostring(self.selectPanel.info.id))
          local effectImage = self:getControl("EffectImage", nil, self.selectPanel)
          if effectImage then
            effectImage:setColor(DEFAULT_SELECT_COLOR)
            effectImage:setVisible(true)
          end
        end
        if self.selectPanel then
          self:setCtrlVisible("EffectImage", true, self.selectPanel)
        end
      end
      clearFunc()
    end
    return true
  end
  local listener = cc.EventListenerTouchOneByOne:create()
  listener:setSwallowTouches(true)
  listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
  listener:registerScriptHandler(onTouchMove, cc.Handler.EVENT_TOUCH_MOVED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_ENDED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_CANCELLED)
  local dispatcher = touchPanel:getEventDispatcher()
  dispatcher:addEventListenerWithSceneGraphPriority(listener, touchPanel)
end
function DaluandouscDlg:resetSelectPanelEffect(panel)
  local effectImage = self:getControl("EffectImage", nil, panel)
  if effectImage then
    if panel and panel.info and #self:getUpRankMaterialList(panel.info) > 0 then
      effectImage:setColor(UPGRADE_COLOR)
      effectImage:setVisible(true)
    else
      effectImage:setColor(DEFAULT_SELECT_COLOR)
      effectImage:setVisible(false)
    end
  end
end
function DaluandouscDlg:resetSelectEffect()
  for i = 1, #COMBAT_POS do
    local panel = self:getControl("FightRetinuePanel" .. COMBAT_POS[i])
    self:setEffectImageStatus(panel, false)
  end
  for i = 1, 8 do
    local panel = self:getControl("RetinueSinglePanel" .. i)
    self:setEffectImageStatus(panel, false)
  end
end
function DaluandouscDlg:updateTrashPanelStatus(info)
  if info then
    self.trashPanel:setVisible(true)
    self:setLabelText("NumLabel", string.format("+%d", self:getSellCost(info)))
  else
    self.trashPanel:setVisible(false)
  end
end
function DaluandouscDlg:setEffectImageStatus(panel, flag)
  if not panel then
    return
  end
  local effectImage = self:getControl("EffectImage", nil, panel)
  local retinuePanel = self:getControl("RetinuePanel", nil, panel)
  if not effectImage then
    return
  end
  if not retinuePanel then
    return
  end
  if flag then
    effectImage:setVisible(true)
  else
    local effectColor = effectImage:getColor()
    if not panel.info or not retinuePanel:isVisible() or effectColor.r ~= UPGRADE_COLOR.r or effectColor.g ~= UPGRADE_COLOR.g or effectColor.b ~= UPGRADE_COLOR.b then
      effectImage:setVisible(false)
      if not panel.info or not retinuePanel:isVisible() then
        effectImage:setColor(DEFAULT_SELECT_COLOR)
      end
    end
  end
end
function DaluandouscDlg:getRetinueNameColorStr(name)
  local cfg = UndergroundMgr:getRetinueCfg(name)
  if cfg then
    if cfg.color == 1 then
      return string.format("#B%s#n", name)
    elseif cfg.color == 2 then
      return string.format("#O%s#n", name)
    elseif cfg.color == 3 then
      return string.format("#Y%s#n", name)
    end
  end
  return ""
end
function DaluandouscDlg:getCombatRetinueCount()
  local count = 0
  for i = 1, #self.retinueList do
    if self.retinueList[i].combat_pos < 10 then
      count = count + 1
    end
  end
  return count
end
function DaluandouscDlg:setRetinuePanel(panel, info)
  self:setCtrlVisible("RetinuePanel", false, panel)
  self:setCtrlVisible("EffectImage", false, panel)
  local effectImage = self:getControl("EffectImage", nil, panel)
  if effectImage then
    effectImage:setColor(DEFAULT_SELECT_COLOR)
  end
  panel.info = info
  if not info then
    return
  end
  local cfg = UndergroundMgr:getRetinueCfg(info.name)
  if not cfg then
    return
  end
  self:setCtrlVisible("RetinuePanel", true, panel)
  self:setImage("HeadImage", ResMgr:getSmallPortrait(cfg.icon), panel)
  if cfg.color == 1 then
    self:setImagePlist("QualityImage", ResMgr.ui.guard_rank1, panel)
  elseif cfg.color == 2 then
    self:setImagePlist("QualityImage", ResMgr.ui.guard_rank2, panel)
  elseif cfg.color == 3 then
    self:setImagePlist("QualityImage", ResMgr.ui.guard_rank3, panel)
  end
  self:setCtrlVisible("StarPanel_1", false, panel)
  self:setCtrlVisible("StarPanel_2", false, panel)
  self:setCtrlVisible("StarPanel_3", false, panel)
  self:setCtrlVisible("StarPanel_" .. info.rank, true, panel)
  self:setImage("RaceImage", ResMgr:getRetinueTypeTag(cfg.type), panel)
  self:setImage("ZhongzuImage", ResMgr:getRetinueTypeTag(cfg.type), panel)
  self:setImage("PolarImage", ResMgr:getRetinuePolarTag(cfg.polar), panel)
  self:setImage("MenpaiImage", ResMgr:getRetinuePolarTag(cfg.polar), panel)
  self:setImage("TypeImage", ResMgr:getRetinueAttackTag(cfg.fightType), panel)
  self:setImage("LeixingImage", ResMgr:getRetinueAttackTag(cfg.fightType), panel)
  local showUpgrade = #self:getUpRankMaterialList(info) > 0
  self:setCtrlVisible("UpgradeButton", showUpgrade, panel)
  local effectImage = self:getControl("EffectImage", nil, panel)
  if effectImage and showUpgrade then
    effectImage:setColor(UPGRADE_COLOR)
    effectImage:setVisible(true)
  end
  local upgradeButton = self:getControl("UpgradeButton", nil, panel)
  if upgradeButton then
    self:getControl("UpgradeButton", nil, panel).info = info
    self:bindListener("UpgradeButton", self.onUpgradeButton, panel)
  end
end
function DaluandouscDlg:hasRetinueInStore()
  if not self.retinueList then
    return
  end
  for i = 1, #self.retinueList do
    if self.retinueList[i].combat_pos > 10 then
      return true
    end
  end
end
function DaluandouscDlg:refreshRetinuePanel()
  local selectRetinueId
  if self.selectPanel then
    DlgMgr:closeDlg("ConfirmDlg")
    if self.selectPanel.info then
      selectRetinueId = self.selectPanel.info.id
    end
    self.selectPanel = nil
  end
  local findSelectRetinue = false
  for i = 1, #COMBAT_POS do
    local panel = self:getControl("FightRetinuePanel" .. COMBAT_POS[i])
    panel.info = nil
    panel.pos = COMBAT_POS[i]
    self:setEffectImageStatus(panel, false)
    self:setCtrlVisible("RetinuePanel", false, panel)
  end
  for i = 1, #self.retinueList do
    if self.retinueList[i].combat_pos < 10 then
      local panel = self:getControl("FightRetinuePanel" .. self.retinueList[i].combat_pos)
      self:setRetinuePanel(panel, self.retinueList[i])
      if self.retinueList[i].id == selectRetinueId then
        findSelectRetinue = true
        self.selectPanel = panel
      end
    end
  end
  for i = 1, 8 do
    local panel = self:getControl("RetinueSinglePanel" .. i)
    panel.info = nil
    panel.pos = 10 + i
    self:setEffectImageStatus(panel, false)
    self:setCtrlVisible("RetinuePanel", false, panel)
  end
  local hasSetPos = 99
  for i = 1, #self.retinueList do
    if self.retinueList[i].combat_pos > 10 then
      local panel = self:getControl("RetinueSinglePanel" .. self.retinueList[i].combat_pos - 10)
      self:setRetinuePanel(panel, self.retinueList[i])
      if self.retinueList[i].id == selectRetinueId then
        findSelectRetinue = true
        self.selectPanel = panel
      end
      if hasSetPos > self.retinueList[i].combat_pos - 10 then
        hasSetPos = self.retinueList[i].combat_pos - 10
      end
    end
  end
  if hasSetPos ~= 99 then
    local tipPanel = self:getControl("TipsPanel2")
    tipPanel:setPositionX(tipPanel.orgX + (hasSetPos - 1) * (self:getControl("RetinueSinglePanel1"):getContentSize().width + 4))
  end
  if not findSelectRetinue then
    self:updateTrashPanelStatus()
  else
    self:updateTrashPanelStatus(self.selectPanel.info)
    self:setCtrlVisible("EffectImage", true, self.selectPanel)
    local effectImage = self:getControl("EffectImage", nil, self.selectPanel)
    if effectImage then
      effectImage:setColor(DEFAULT_SELECT_COLOR)
    end
  end
  self:refreshEffectPanel()
  DlgMgr:sendMsg("DaluandouzmscDlg", "refreshRetinueHasNum")
end
function DaluandouscDlg:getSellCost(info)
  if not info then
    return 0
  end
  local cfg = UndergroundMgr:getRetinueCfg(info.name)
  if not cfg then
    return 0
  end
  if cfg.color == 1 then
    if info.rank == 1 then
      return 1
    elseif info.rank == 2 then
      return 2
    else
      return 6
    end
  elseif cfg.color == 2 then
    if info.rank == 1 then
      return 2
    elseif info.rank == 2 then
      return 4
    else
      return 8
    end
  elseif info.rank == 1 then
    return 3
  elseif info.rank == 2 then
    return 6
  else
    return 12
  end
end
function DaluandouscDlg:getUpRankMaterialList(info)
  local rankList1, rankList2, _ = self:getRetinueMaterialList(info.name, nil, {
    info.combat_pos
  })
  return UndergroundMgr:getUpRankMaterialList(info, rankList1, rankList2)
end
function DaluandouscDlg:refreshTimePanel()
  local data = DlgMgr:sendMsg("DaluandouzjmDlg", "getDlgData")
  if not data then
    return
  end
  local list = data.list
  self:setCtrlVisible("ReadyButton", false)
  if data.round > 1 and data.has_combat == 1 then
    for i = 1, #list do
      if list[i].gid == Me:queryBasic("gid") then
        self:setCtrlVisible("ReadyButton", list[i].is_ready ~= 1)
      end
    end
  end
  local titlePanel = self:getControl("TitlePanel")
  self:setLabelText("RankLabel", string.format(CHS[7100739], data.round), titlePanel)
  if data.has_combat == 1 then
    self:setLabelText("StageLabel", CHS[7100740], titlePanel)
    do
      local leftTime = math.max(0, data.protect_time - gf:getServerTime())
      local timeLabel = self:getControl("TimeLabel", Const.UIAtlasLabel, titlePanel)
      if leftTime <= 10 then
        self:setLabelText("TimeLabel", leftTime, titlePanel, COLOR3.RED)
      else
        self:setLabelText("TimeLabel", leftTime, titlePanel, COLOR3.WHITE)
      end
      self:addCountDownEffect(true)
      timeLabel:stopAllActions()
      schedule(timeLabel, function()
        leftTime = math.max(0, data.protect_time - gf:getServerTime())
        timeLabel:setString(leftTime)
        if leftTime <= 10 then
          self:addCountDownEffect()
          timeLabel:setColor(COLOR3.RED)
        else
          timeLabel:setColor(COLOR3.WHITE)
        end
        if 0 > data.protect_time - gf:getServerTime() then
          timeLabel:stopAllActions()
          self:addCountDownEffect(true)
        end
      end, 1)
    end
  else
    self:setLabelText("StageLabel", CHS[7100741], titlePanel)
    self:getControl("TimeLabel", Const.UIAtlasLabel, titlePanel):stopAllActions()
    self:setLabelText("TimeLabel", 60, titlePanel, COLOR3.WHITE)
  end
end
function DaluandouscDlg:addCountDownEffect(remove)
  local panel = self:getControl("TitlePanel")
  if remove then
    if panel:getChildByName("DaluandouCountDown") then
      panel:removeChildByName("DaluandouCountDown")
    end
    return
  end
  if panel:getChildByName("DaluandouCountDown") then
    return
  end
  local magic = gf:createSelfRemoveMagic(ResMgr.magic.daluandou_count_down, {blendMode = "add"})
  local sz = panel:getContentSize()
  magic:setPosition(sz.width / 2, sz.height)
  magic:setName("DaluandouCountDown")
  panel:addChild(magic)
end
function DaluandouscDlg:refreshEffectPanel()
  local function refreshSinglePanel(panel, type, isPolar)
    local count = self:getRetinueInCombatCount(type, isPolar)
    panel.num = count
    panel.type = type
    if count > 0 then
      self:setNumImgForPanel(panel, ART_FONT_COLOR.NORMAL_TEXT, count, nil, LOCATE_POSITION.LEFT_TOP, 12.5)
    else
      self:removeNumImgForPanel(panel, LOCATE_POSITION.LEFT_TOP)
    end
    if isPolar and count < 2 or not isPolar and count <= 0 then
      gf:grayImageView(self:getControl("IconImage", nil, panel))
      gf:grayImageView(self:getControl("TypeIconImage", nil, panel))
    else
      gf:resetImageView(self:getControl("IconImage", nil, panel))
      gf:resetImageView(self:getControl("TypeIconImage", nil, panel))
    end
  end
  for i = 1, 3 do
    local panel = self:getControl("IconPanel" .. i, nil, self.raceEffectPanel)
    refreshSinglePanel(panel, i)
  end
  for i = 1, 5 do
    local panel = self:getControl("IconPanel" .. i, nil, self.polarEffectPanel)
    refreshSinglePanel(panel, i, true)
  end
end
function DaluandouscDlg:tryPlayGuide(removeGuides)
  local myData = DlgMgr:sendMsg("DaluandouzjmDlg", "getMyData")
  if not myData then
    return
  end
  if removeGuides then
    for i = 1, #removeGuides do
      local key = removeGuides[i]
      if myData["play_instruction" .. key] == 1 then
        gf:CmdToServer("CMD_FFA_OVER_INSTRUCTION", {index = key})
        myData["play_instruction" .. key] = 0
      end
    end
  end
  local hasRetinue = self:hasRetinueInStore()
  if myData.play_instruction1 == 1 and self.fightRetinueCount == 0 and not hasRetinue then
    self:setCtrlVisible("TipsPanel1", true)
  else
    self:setCtrlVisible("TipsPanel1", false)
  end
  if myData.play_instruction1 == 0 and myData.play_instruction2 == 1 and self.fightRetinueCount == 0 and hasRetinue then
    self:setCtrlVisible("TipsPanel2", true)
  else
    self:setCtrlVisible("TipsPanel2", false)
  end
  if myData.play_instruction2 == 0 and myData.play_instruction3 == 1 and self.fightRetinueCount == 1 then
    self:setCtrlVisible("TipsPanel3", true)
    self:setCtrlVisible("TipsPanel4", true)
  else
    self:setCtrlVisible("TipsPanel3", false)
    self:setCtrlVisible("TipsPanel4", false)
  end
end
function DaluandouscDlg:refreshStorageInfo()
  local myData = DlgMgr:sendMsg("DaluandouzjmDlg", "getMyData")
  local numPanel = self:getControl("NumPanel", nil, "MainPanel")
  local fightRetinueCount = 0
  for i = 1, #self.retinueList do
    if self.retinueList[i].combat_pos < 10 then
      fightRetinueCount = fightRetinueCount + 1
    end
  end
  self.fightRetinueCount = fightRetinueCount
  self:tryPlayGuide(fightRetinueCount > 0 and {1, 2} or nil)
  self:setLabelText("FightAtlasLabel", fightRetinueCount, numPanel)
  self:setLabelText("StoreAtlasLabel", myData.retinue_bag_lv, numPanel)
  local expPanel = self:getControl("ExpPanel")
  self:setLabelText("StoreLevel", myData.retinue_bag_lv, expPanel)
  self:setLabelText("ScoreLabel", myData.point, expPanel)
  self:setLabelText("LevelUpLabel_1", string.format("%d/%d", myData.retinue_bag_exp, myData.retinue_bag_upgrade_exp), expPanel)
  self:setLabelText("LevelUpLabel_2", string.format("%d/%d", myData.retinue_bag_exp, myData.retinue_bag_upgrade_exp), expPanel)
  if myData.retinue_bag_lv >= 4 then
    self:setLabelText("LevelUpLabel_1", "", expPanel)
    self:setLabelText("LevelUpLabel_2", "", expPanel)
    self:setLabelText("AddExpAtlasLabel", string.format(CHS[7100746], "5"), expPanel)
    self:setLabelText("CostLabel", string.format(CHS[7100747], STORAGE_EXP_MAP[myData.retinue_bag_lv - 1]), expPanel)
  else
    self:setLabelText("AddExpAtlasLabel", string.format(CHS[7100746], myData.buy_add_exp), expPanel)
    self:setLabelText("CostLabel", string.format(CHS[7100747], STORAGE_EXP_MAP[myData.retinue_bag_lv]), expPanel)
  end
end
function DaluandouscDlg:getRetinueInCombatCount(type, isPolar)
  return UndergroundMgr:getRetinueInCombatCount(self.retinueList, type, isPolar)
end
function DaluandouscDlg:getRetinueMaterialList(name, rank, ignorePos)
  return UndergroundMgr:getRetinueMaterialList(self.retinueList, name, rank, ignorePos)
end
function DaluandouscDlg:updateRecruitStatus()
  local zhaoMuPanel = self:getControl("ZhaomuPanel")
  if DlgMgr:getDlgByName("DaluandouzmscDlg") then
    self:setCtrlVisible("ZhaomuButton", false, zhaoMuPanel)
    self:setCtrlVisible("ShouqiButton", true, zhaoMuPanel)
  else
    self:setCtrlVisible("ZhaomuButton", true, zhaoMuPanel)
    self:setCtrlVisible("ShouqiButton", false, zhaoMuPanel)
  end
end
function DaluandouscDlg:cleanup()
  if self.selectPanel then
    DlgMgr:closeDlg("ConfirmDlg")
  end
  self.retinueList = nil
  self.selectPanel = nil
  self.moveInPanel = nil
  self.selectMovePanel = nil
  self.lastTouchPos = nil
  self.beginTouchPos = nil
  self.needOpenCard = nil
  self.fightRetinueCount = nil
  DlgMgr:closeDlg("DaluandouzmscDlg")
  self:setMainDlgVisible(true)
end
function DaluandouscDlg:onHuishouPanel(sender, eventType)
  if not self.selectPanel or not self.selectPanel.info then
    return
  end
  local tips = string.format(CHS[7100745], self:getRetinueNameColorStr(self.selectPanel.info.name), self.selectPanel.info.rank, self:getSellCost(self.selectPanel.info))
  gf:confirm(tips, function()
    gf:CmdToServer("CMD_FFA_SELL_RETINUE", {
      id = self.selectPanel.info.id
    })
  end)
end
function DaluandouscDlg:onUpStorageButton(sender, eventType)
  local myData = DlgMgr:sendMsg("DaluandouzjmDlg", "getMyData")
  local costPoint = STORAGE_EXP_MAP[myData.retinue_bag_lv]
  if not costPoint then
    gf:ShowSmallTips(CHS[7100757])
    return
  end
  if costPoint > myData.point then
    gf:ShowSmallTips(CHS[7100749])
    return
  end
  gf:CmdToServer("CMD_FFA_BUY_BAG_LEVEL_EXP", {exp_num = costPoint})
end
function DaluandouscDlg:onUpgradeButton(sender, eventType)
  local info = sender.info
  if not info then
    return
  end
  local materialList = self:getUpRankMaterialList(info)
  if #materialList > 0 then
    gf:CmdToServer("CMD_FFA_UPGRADE_RETINUE_RANK", {
      id = info.id,
      list = materialList,
      count = #materialList
    })
  end
end
function DaluandouscDlg:onTypeEffectPanel(sender, eventType)
  if not sender.type or not sender.num then
    return
  end
  local rect = self:getBoundingBoxInWorldSpace(sender)
  local dlg = DlgMgr:getDlgByName("UndergroundBuffDlg")
  dlg = dlg or DlgMgr:openDlg("UndergroundBuffDlg")
  dlg:setData({
    isPolar = false,
    type = sender.type,
    num = sender.num
  })
  dlg:setFloatingFramePos(rect)
end
function DaluandouscDlg:onPolarEffectPanel(sender, eventType)
  if not sender.type or not sender.num then
    return
  end
  local rect = self:getBoundingBoxInWorldSpace(sender)
  local dlg = DlgMgr:getDlgByName("UndergroundBuffDlg")
  dlg = dlg or DlgMgr:openDlg("UndergroundBuffDlg")
  dlg:setData({
    isPolar = true,
    type = sender.type,
    num = sender.num
  })
  dlg:setFloatingFramePos(rect)
end
function DaluandouscDlg:onRecruitButton(sender, eventType)
  gf:CmdToServer("CMD_FFA_REQUEST_RETINUE_DATA", {type = 2})
  self:setCtrlVisible("TipsPanel1", false)
end
function DaluandouscDlg:onShouqiButton(sender, eventType)
  DlgMgr:closeDlg("DaluandouzmscDlg")
  self:updateRecruitStatus()
end
function DaluandouscDlg:onTuJianButton(sender, eventType)
  DlgMgr:openDlg("DaluandoutjDlg")
end
function DaluandouscDlg:onRecordButton(sender, eventType)
  gf:CmdToServer("CMD_FFA_REQUEST_FIGHT_RECORD", {})
end
function DaluandouscDlg:onPromoteButton(sender, eventType)
  DlgMgr:openDlg("DaluandousxqhDlg")
end
function DaluandouscDlg:onReadyButton(sender, eventType)
  DlgMgr:sendMsg("DaluandouzjmDlg", "onReadyButton")
end
function DaluandouscDlg:onRuleButton(sender, eventType)
  DlgMgr:openDlg("DaluandouScRuleDlg")
end
function DaluandouscDlg:MSG_FFA_RECRUIT_LIST(data)
  local dlg = DlgMgr:getDlgByName("DaluandouzmscDlg")
  dlg = dlg or DlgMgr:openDlg("DaluandouzmscDlg")
  dlg:setData(data)
  self:tryPlayGuide({1})
end
function DaluandouscDlg:MSG_FFA_FIGHT_RECORD(data)
  local dlg = DlgMgr:getDlgByName("DaluandoudzlsDlg")
  dlg = dlg or DlgMgr:openDlg("DaluandoudzlsDlg")
  dlg:setData(data)
end
function DaluandouscDlg:MSG_FFA_UPGRADE_RETINUE_RANK(data)
end
function DaluandouscDlg:MSG_ENTER_ROOM(data)
  if not MapMgr:isInDifuDaluandou() then
    DlgMgr:closeDlg(self.name)
  end
end
return DaluandouscDlg
