local CockFightingRuleDlg = Singleton("CockFightingRuleDlg", Dialog)
function CockFightingRuleDlg:init()
  self:bindListViewListener("ListView", self.onSelectListView)
end
function CockFightingRuleDlg:onUpdate()
  local percent = self:getCurScrollPercent("ListView", true)
  self:setCtrlVisible("DownArrowPanel", percent < 97)
  self:setCtrlVisible("UpArrowPanel", percent > 3)
end
function CockFightingRuleDlg:onSelectListView(sender, eventType)
end
return CockFightingRuleDlg
