local DaluandoutjDlg = Singleton("DaluandoutjDlg", Dialog)
local TYPE_CFG = {
  "Color",
  "Type",
  "Polar",
  "Fight",
  Color = {
    0,
    1,
    2,
    3
  },
  Type = {
    0,
    1,
    2,
    3
  },
  Polar = {
    0,
    1,
    2,
    3,
    4,
    5
  },
  Fight = {
    0,
    1,
    2,
    3,
    4
  },
  ColorDes = {
    CHS[7100725],
    CHS[7100729],
    CHS[7100730],
    CHS[7100731]
  },
  TypeDes = {
    CHS[7100726],
    CHS[7100575],
    CHS[7100576],
    CHS[7100577]
  },
  PolarDes = {
    CHS[7100727],
    CHS[7100578],
    CHS[7100579],
    CHS[7100580],
    CHS[7100581],
    CHS[7100582]
  },
  FightDes = {
    CHS[7100728],
    CHS[7100583],
    CHS[7100584],
    CHS[7100585],
    CHS[7100586]
  }
}
local OPTION_MARGIN = 5
local RETINUE = UndergroundMgr:getRetinueTypeCfg("Retinue")
function DaluandoutjDlg:init()
  self:getControl("ColorButton").type = TYPE_CFG[1]
  self:getControl("TypeButton").type = TYPE_CFG[2]
  self:getControl("PolarButton").type = TYPE_CFG[3]
  self:getControl("FightButton").type = TYPE_CFG[4]
  self:bindListener("ColorButton", self.onTypeButton)
  self:bindListener("TypeButton", self.onTypeButton)
  self:bindListener("PolarButton", self.onTypeButton)
  self:bindListener("FightButton", self.onTypeButton)
  self.scrollView = self:getControl("ScrollView")
  self.singleItemPanel = self:retainCtrl("SinglePanel")
  self:bindListener("Button", self.onTypeSelectButton, "OptionPanel")
  self.typeItemPanel = self:retainCtrl("Button", "OptionPanel")
  self.optionPanel = self:getControl("OptionPanel")
  self:bindFloatPanelListener("OptionPanel", nil, nil, function()
    self:resetTypeButton()
  end)
  self.optionPanel:setVisible(false)
  self.typeSelect = {}
  for i = 1, 4 do
    self:setCtrlVisible("Image_1", false, TYPE_CFG[i] .. "Button")
    self:setCtrlVisible("Image_2", true, TYPE_CFG[i] .. "Button")
  end
  self:selectType("Color", 0, true)
  self:selectType("Type", 0, true)
  self:selectType("Polar", 0, true)
  self:selectType("Fight", 0)
end
function DaluandoutjDlg:resetTypeButton()
  for i = 1, 4 do
    self:setCtrlVisible("Image_1", false, TYPE_CFG[i] .. "Button")
    self:setCtrlVisible("Image_2", true, TYPE_CFG[i] .. "Button")
  end
end
function DaluandoutjDlg:onTypeButton(sender, eventType)
  local typeList = TYPE_CFG[sender.type]
  local typeDesList = TYPE_CFG[sender.type .. "Des"]
  if not typeList then
    return
  end
  self:resetTypeButton()
  self:setCtrlVisible("Image_1", true, sender.type .. "Button")
  self:setCtrlVisible("Image_2", false, sender.type .. "Button")
  local count = #typeList
  self.optionPanel:removeAllChildren()
  local sz = self.optionPanel:getContentSize()
  local itemHeight = self.typeItemPanel:getContentSize().height
  sz.height = count * itemHeight + 2 * OPTION_MARGIN
  self.optionPanel:setContentSize(sz)
  for i = 1, count do
    local item = self.typeItemPanel:clone()
    item:setTitleText(typeDesList[i])
    item.type = typeList[i]
    item:setPositionY(sz.height - (i - 1) * itemHeight - itemHeight / 2 - OPTION_MARGIN)
    self.optionPanel:addChild(item)
  end
  self.optionPanel.type = sender.type
  self.optionPanel:setVisible(true)
  self.optionPanel:setPositionX(sender:getPositionX() - sender:getContentSize().width / 2)
  self.optionPanel:setPositionY(sender:getPositionY() - sender:getContentSize().height / 2 - sz.height)
end
function DaluandoutjDlg:onTypeSelectButton(sender, eventType)
  self:selectType(self.optionPanel.type, sender.type)
  self.optionPanel:setVisible(false)
  self:resetTypeButton()
end
function DaluandoutjDlg:selectType(itemType, type, notRefresh)
  self:setLabelText("Label1", TYPE_CFG[itemType .. "Des"][type + 1], itemType .. "Button")
  self:setLabelText("Label2", TYPE_CFG[itemType .. "Des"][type + 1], itemType .. "Button")
  self.typeSelect[itemType] = type
  if not notRefresh then
    self:refreshItemList()
  end
end
function DaluandoutjDlg:getCardList()
  local list = {}
  for _, v in pairs(RETINUE) do
    if (self.typeSelect.Color <= 0 or self.typeSelect.Color == v.color) and (0 >= self.typeSelect.Type or self.typeSelect.Type == v.type) and (0 >= self.typeSelect.Polar or self.typeSelect.Polar == v.polar) and (0 >= self.typeSelect.Fight or self.typeSelect.Fight == v.fightType) then
      table.insert(list, v)
    end
  end
  table.sort(list, function(l, r)
    if l.color < r.color then
      return true
    end
    if l.color > r.color then
      return false
    end
    if l.type < r.type then
      return true
    end
    if l.type > r.type then
      return false
    end
    if l.polar < r.polar then
      return true
    end
    if l.polar > r.polar then
      return false
    end
    if l.fightType < r.fightType then
      return true
    end
    if l.fightType > r.fightType then
      return false
    end
  end)
  return list
end
function DaluandoutjDlg:refreshItemList()
  self.scrollView:removeAllChildren()
  self.cardList = self:getCardList()
  local count = #self.cardList
  if count <= 0 then
    gf:ShowSmallTips(CHS[7100733])
    return
  end
  local itemSize = self.singleItemPanel:getContentSize()
  local row = math.ceil(count / 4)
  local innerHeight = row * itemSize.height
  local scrollSize = self.scrollView:getContentSize()
  if innerHeight < scrollSize.height then
    innerHeight = scrollSize.height
  end
  self.scrollView:getInnerContainer():setContentSize(scrollSize.width, innerHeight)
  self.scrollView:getInnerContainer():setPositionY(scrollSize.height - innerHeight)
  for i = 1, count do
    local panel = self.singleItemPanel:clone()
    self:setSingleItemInfo(panel, self.cardList[i])
    local xIndex = i % 4 == 0 and 4 or i % 4
    local yIndex = math.ceil(i / 4)
    panel:setPosition((xIndex - 1) * itemSize.width, innerHeight - itemSize.height * yIndex)
    self.scrollView:addChild(panel)
  end
end
function DaluandoutjDlg:getRetinueByName(name)
  for i = 1, #self.cardList do
    if self.cardList[i].name == name then
      local lastName = self.cardList[i - 1] and self.cardList[i - 1].name or nil
      local nextName = self.cardList[i + 1] and self.cardList[i + 1].name or nil
      return lastName, name, nextName
    end
  end
end
function DaluandoutjDlg:setSingleItemInfo(panel, info)
  self:setPortrait("ShapePanel", info.icon, nil, panel)
  local infoPanel = self:getControl("NamePanel", nil, panel)
  if info.color == 1 then
    self:setLabelText("NameLabel", info.name, infoPanel, COLOR3.BLUE)
  elseif info.color == 2 then
    self:setLabelText("NameLabel", info.name, infoPanel, COLOR3.PURPLE)
  elseif info.color == 3 then
    self:setLabelText("NameLabel", info.name, infoPanel, COLOR3.YELLOW)
  end
  local typeDes, polarDes, fightDes = UndergroundMgr:getRetinueDesChs(info.type, info.polar, info.fightType)
  self:setImage("RaceImage", ResMgr:getRetinueTypeTag(info.type), panel)
  self:setLabelText("RaceLabel", typeDes, panel)
  self:setImage("PolarImage", ResMgr:getRetinuePolarTag(info.polar), panel)
  self:setLabelText("PolarLabel", polarDes, panel)
  self:setImage("TypeImage", ResMgr:getRetinueAttackTag(info.fightType), panel)
  self:setLabelText("TypeLabel", fightDes, panel)
  self:getControl("TouchPanel", nil, panel).name = info.name
  self:bindListener("TouchPanel", self.onShapePanel, panel)
end
function DaluandoutjDlg:onShapePanel(sender, eventType)
  UndergroundMgr:requestRetinueInfo(sender.name)
end
return DaluandoutjDlg
