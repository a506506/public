local NumImg = require("ctrl/NumImg")
local FightRoundDlg = Singleton("FightRoundDlg", Dialog)
function FightRoundDlg:init()
  self:setFullScreen()
  self:bindListener("RecordButton", self.onFightRecordButton)
  if FightCmdRecordMgr:getRecordGuideFlag() then
    gf:createArmatureMagic(ResMgr.ArmatureMagic.fight_record_guide, self:getControl("RecordButton"), Const.ARMATURE_MAGIC_TAG)
  end
  self:setCtrlVisible("RecordButton", not Me:isLookOn() and FightCmdRecordMgr:isRecordMagicOpen())
  if MapMgr:isInDifuDaluandou() then
    self:setCtrlVisible("RecordButton", false)
  end
  BatteryAndWifiMgr:bindBatteryAndWifi(self)
  self:setCtrlVisible("TimeLabel_3", false)
  self:setCtrlVisible("TimeLabel_4", false)
end
function FightRoundDlg:isPlayFight()
  if not self.numImg:isVisible() and not self.waitImg:isVisible() then
    return true
  end
  return false
end
function FightRoundDlg:updateBattery(rawlevel, scale, status, health)
  BatteryAndWifiMgr:updateBattery(self, rawlevel, scale, status, health)
end
function FightRoundDlg:updateNetwork(networkState)
  BatteryAndWifiMgr:updateNetwork(self, networkState)
end
function FightRoundDlg:updateWifiStatus(wifiState, level)
  BatteryAndWifiMgr:updateWifiStatus(self, wifiState, level)
end
function FightRoundDlg:setCurRound(round)
  local roundPanel = self:getControl("NumPanel", Const.UIPanel)
  roundPanel:removeAllChildren()
  local numImg = NumImg.new("sfight_num", round, false, -2)
  numImg:setScale(1)
  numImg:setAnchorPoint(0.5, 0.5)
  numImg:setPosition(roundPanel:getContentSize().width / 2, roundPanel:getContentSize().height / 2)
  roundPanel:addChild(numImg)
end
function FightRoundDlg:onFightRecordButton(sender, eventType)
  if sender:getChildByTag(Const.ARMATURE_MAGIC_TAG) then
    sender:removeChildByTag(Const.ARMATURE_MAGIC_TAG)
    FightCmdRecordMgr:setRecordGuideFlag(false)
  end
  DlgMgr:openDlg("FightRecordDlg")
end
return FightRoundDlg
