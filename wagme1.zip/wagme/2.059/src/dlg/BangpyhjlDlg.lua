local BangpyhjlDlg = Singleton("BangpyhjlDlg", Dialog)
function BangpyhjlDlg:init(data)
  self:bindListener("CloseImage", self.onCloseButton)
  self:setLabelText("NameLabel", data.dishName)
  self:setquality(data)
  self:setImage("IconImage", PartyMgr:getBpyhDishIcon(data.dishName))
  performWithDelay(self.root, function()
    self:onCloseButton()
  end, 6)
end
function BangpyhjlDlg:setquality(data)
  local startNum = math.floor(data.quality / 2)
  local halfNUm = data.quality % 2
  for i = 1, 5 do
    if i <= startNum then
      local x, y = self:getControl("StarImage", nil, "StarPanel" .. i):getPosition()
      local img = self:setCtrlVisible("StarAllImage", true, "StarPanel" .. i)
      img:setPosition(x, y)
    else
      self:setCtrlVisible("StarAllImage", false, "StarPanel" .. i)
    end
  end
  if halfNUm > 0 then
    local image = self:setCtrlVisible("StarAllImage", true, "StarPanel" .. startNum + 1)
    local x, y = self:getControl("StarImage", nil, "StarPanel" .. halfNUm):getPosition()
    local size = image:getContentSize()
    local ret = {
      x = 0,
      y = 0,
      width = size.width * 0.5,
      height = size.height
    }
    image:setTextureRect(ret)
    image:setPositionX(x - size.width * 0.25)
  end
end
return BangpyhjlDlg
