local ArenaTopTenDlg = Singleton("ArenaTopTenDlg", Dialog)
local YEAR_MAGIN = 5
local SEASON_MAGIN = 5
function ArenaTopTenDlg:init()
  self:bindListener("ChoseButton", self.onChoseButton)
  self.unitYearPanel = self:retainCtrl("YearCellPanel")
  self:bindTouchEndEventListener(self.unitYearPanel, self.onChoseYearPanel)
  self.unitBigPanel = self:retainCtrl("BigPanel")
  self.unitBigSelectImage = self:retainCtrl("BChosenEffectImage", self.unitBigPanel)
  self:bindTouchEndEventListener(self.unitBigPanel, self.onChoseSeasonPanel)
  self.unitRankPanel = self:retainCtrl("OneRowRankingListPanel")
  self.unitRankSelectImage = self:retainCtrl("ChosenEffectImage", self.unitRankPanel)
  self:bindTouchEndEventListener(self.unitRankPanel, self.onChoseWinnerPanel)
  self.yearPanel = self:getControl("YearListPanel")
  self.yearPanelSize = self.yearPanel:getContentSize()
  self.selectSeason = nil
  self:hookMsg("MSG_COMPETE_TOURNAMENT_TOP_USER_INFO")
  self:setData()
end
function ArenaTopTenDlg:setData()
  local data = RingMgr:getSeasonTitleData()
  self:setYearList(data)
end
function ArenaTopTenDlg:setYearList(data)
  local yearList = self:resetListView("YearListView", YEAR_MAGIN, ccui.ListViewGravity.centerHorizontal)
  local yearPanel = self:getControl("YearListPanel")
  local count = data.startYear - data.endYear + 1
  local size = {
    width = self.yearPanelSize.width,
    height = 0
  }
  local maxDisplayCount = 5
  if count > maxDisplayCount then
    size.height = self.yearPanelSize.height + (self.unitYearPanel:getContentSize().height + YEAR_MAGIN) * (maxDisplayCount - 1)
  else
    size.height = self.yearPanelSize.height + (self.unitYearPanel:getContentSize().height + YEAR_MAGIN) * (count - 1)
  end
  yearPanel:setContentSize(size)
  yearList:setContentSize(size.width, size.height - 20)
  for i = data.startYear, data.endYear, -1 do
    local panel = self.unitYearPanel:clone()
    self:setLabelText("NameLabel", i .. "年度", panel)
    panel.year = i .. "年度"
    panel.data = data[i]
    yearList:pushBackCustomItem(panel)
  end
  local item = yearList:getItem(0)
  if item then
    self:onChoseYearPanel(item)
  end
  yearPanel:requestDoLayout()
  yearList:requestDoLayout()
end
function ArenaTopTenDlg:onChoseButton(sender, eventType)
  local panel = self:getControl("YearListPanel")
  panel:setVisible(not panel:isVisible())
end
function ArenaTopTenDlg:onChoseYearPanel(sender, eventType)
  self:setLabelText("TitleNameLabel", sender.year, "ChoseButton")
  self:setSeasonList(sender.data)
  self:setCtrlVisible("YearListPanel", false)
end
function ArenaTopTenDlg:setSeasonList(data)
  local seasonList = self:resetListView("SeasonListView", SEASON_MAGIN, ccui.ListViewGravity.centerHorizontal)
  for i = 1, #data do
    local panel = self.unitBigPanel:clone()
    self:setLabelText("TimeLabel", string.format("%s月%s日赛季", data[i].month, data[i].day), panel)
    panel.data = data[i].seasonData
    seasonList:pushBackCustomItem(panel)
  end
  local item = seasonList:getItem(0)
  if item then
    self:onChoseSeasonPanel(item)
  end
end
function ArenaTopTenDlg:addSeasonSelectImage(sender)
  self.unitBigSelectImage:removeFromParent()
  sender:addChild(self.unitBigSelectImage)
end
function ArenaTopTenDlg:onChoseSeasonPanel(sender, eventType)
  self:addSeasonSelectImage(sender)
  local data = RingMgr:getTenWinnerData()
  self.selectSeason = sender.data
  if data and data[self.selectSeason] then
    self:setTenWinnerList(data[self.selectSeason])
  else
    RingMgr:questTenWinner(self.selectSeason)
  end
end
function ArenaTopTenDlg:setTenWinnerList(data)
  local tenWinnerList = self:resetListView("TenListView", 0, ccui.ListViewGravity.centerHorizontal)
  for i = 1, #data do
    local panel = self.unitRankPanel:clone()
    self:setWinnerData(data[i], panel, i)
    panel.data = data[i]
    tenWinnerList:pushBackCustomItem(panel)
  end
  local item = tenWinnerList:getItem(0)
  if item then
    self:onChoseWinnerPanel(item)
  end
end
function ArenaTopTenDlg:setWinnerData(data, panel, index)
  if index == 1 then
    self:setCtrlVisible("OneImage", true, panel)
  elseif index == 2 then
    self:setCtrlVisible("TwoImage", true, panel)
  elseif index == 3 then
    self:setCtrlVisible("ThreeImage", true, panel)
  else
    self:setLabelText("BonusLabel", index, panel)
  end
  self:setCtrlVisible("BackImage_2", index % 2 == 0, panel)
  self:setLabelText("NameLabel", gf:getRealName(data.name), panel)
  self:setNumImgForPanel("PortraitPanel", ART_FONT_COLOR.NORMAL_TEXT, data.level, false, LOCATE_POSITION.LEFT_TOP, 21, panel)
  self:setImage("PortraitImage", ResMgr:getSmallPortrait(data.icon), panel)
  self:setItemImageSize("PortraitImage", panel)
  self:setLabelText("LeaderboardLabel", data.score, panel)
  local stage, level = RingMgr:getStepAndLevelByScore(data.score)
  self:setImage("SeasonImage", RingMgr:getResIcon(stage), panel)
  self:setStar(level, panel)
end
function ArenaTopTenDlg:addWinnerSelectImage(sender)
  self.unitRankSelectImage:removeFromParent()
  sender:addChild(self.unitRankSelectImage)
end
function ArenaTopTenDlg:onChoseWinnerPanel(sender, eventType)
  self:addWinnerSelectImage(sender)
  self:setWinnerInfo(sender.data)
end
function ArenaTopTenDlg:setWinnerInfo(data)
  self:setPortrait("PlayerBodyPanel", data.icon, data.weaponIcon)
  if data["upgrade/type"] then
    self:addUpgradeMagicToCtrl("PlayerBodyPanel", data["upgrade/type"], nil, true)
  end
  local stage, level = RingMgr:getStepAndLevelByScore(data.score)
  self:setImage("ShapeSeasonImage", RingMgr:getResIcon(stage))
  self:setStar(level, self:getControl("ShapeStarPanel"))
  self:setLabelText("RankLabel1", RingMgr:getJobChs(stage, level), "StagePanel", RingMgr:getColor(data.curStage))
  self:updateLayout("StagePanel")
end
function ArenaTopTenDlg:setStar(level, panel)
  for i = 1, 3 do
    self:setCtrlVisible("StarImage_" .. i, i <= level, panel)
    self:setCtrlVisible("NoneStarImage_" .. i, level < i, panel)
  end
end
function ArenaTopTenDlg:MSG_COMPETE_TOURNAMENT_TOP_USER_INFO(data)
  if self.selectSeason == data.season then
    local data = RingMgr:getTenWinnerData()
    self:setTenWinnerList(data[self.selectSeason])
  end
end
return ArenaTopTenDlg
