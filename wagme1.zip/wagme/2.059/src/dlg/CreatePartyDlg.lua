local CreatePartyDlg = Singleton("CreatePartyDlg", Dialog)
local nameLenLimit = 6
local nameMin = 2
local announceLimit = 200
local CREATE_PARTY_NEED_MONEY = 10000000
function CreatePartyDlg:init()
  self:bindListener("CreateButton", self.onCreateButton)
  self:bindListener("CleanName", self.CleanName)
  self:bindListener("CleanAnnounce", self.CleanAnnounce)
  self:bindEditFieldForSafe("NamePanel", nameLenLimit, "CleanName", nil, nil, true)
  local textCtrl = self:getControl("TextField", nil, "NamePanel")
  textCtrl:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
  textCtrl:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
  local moneyStr, fontColor = gf:getArtFontMoneyDesc(CREATE_PARTY_NEED_MONEY)
  local numImg = self:setNumImgForPanel("MoneyPanel", fontColor, moneyStr, false, LOCATE_POSITION.CENTER, 25)
end
function CreatePartyDlg:CleanName(sender, eventType)
  local namePanel = self:getControl("NamePanel")
  self:setInputText("TextField", "", namePanel)
  self:setCtrlVisible("DefaultLabel", true, namePanel)
  self:setCtrlVisible("CleanName", false)
end
function CreatePartyDlg:CleanAnnounce(sender, eventType)
  local tenetPanel = self:getControl("TenetPanel")
  self:setInputText("TextField", "", tenetPanel)
  self:setCtrlVisible("DefaultLabel", true, tenetPanel)
  self:setCtrlVisible("CleanAnnounce", false)
end
function CreatePartyDlg:onCreateButton(sender, eventType)
  local limitJoinPartyLevel = PartyMgr:getJoinPartyLevelMin()
  if limitJoinPartyLevel > Me:queryBasicInt("level") then
    gf:ShowSmallTips(string.format(CHS[3002371], limitJoinPartyLevel))
    return
  end
  if Me:queryBasic("party/name") ~= "" then
    gf:ShowSmallTips(CHS[3002373])
    return
  end
  local namePanel = self:getControl("NamePanel")
  local partyName = self:getInputText("TextField", namePanel)
  if partyName == nil or partyName == "" then
    gf:ShowSmallTips(CHS[4000192])
    return
  end
  local len = string.len(partyName)
  if len < nameMin * 2 then
    gf:ShowSmallTips(CHS[3002374])
    return
  end
  if gf:isMeetSearchByGid(partyName) then
    gf:ShowSmallTips(CHS[3002375])
    return
  end
  if not gf:checkHasEnoughMoney(CREATE_PARTY_NEED_MONEY) then
    return
  end
  local announcePanel = self:getControl("TenetPanel")
  local nameText, haveBadName = gf:filtTextEx(partyName, nil, nil, true)
  if haveBadName then
    ChatMgr:shieldLog("wenzpb", 9, partyName)
    return
  end
  if not PartyMgr:checkChengWeiLegal(partyName) then
    ChatMgr:shieldLog("wenzpb", 9, partyName)
    gf:ShowSmallTips(CHS[6000033])
    return
  end
  PartyMgr:createParty(partyName, "")
  self:onCloseButton()
end
return CreatePartyDlg
