local CaseSMFJWomanPictureDlg = Singleton("CaseSMFJWomanPictureDlg", Dialog)
local ORDER = {
  ResMgr.ui.case_smfj_zuoyi,
  ResMgr.ui.case_smfj_tiaowu,
  ResMgr.ui.case_smfj_zhuanxiang,
  ResMgr.ui.case_smfj_shengqi
}
local MAP = {
  [CHS[5400977]] = 1,
  [CHS[5400978]] = 2,
  [CHS[5400979]] = 3,
  [CHS[5400980]] = 4
}
function CaseSMFJWomanPictureDlg:init()
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel")
  self:bindListener("ClosePanel", self.onCloseButton)
end
function CaseSMFJWomanPictureDlg:setData(para)
  if not string.isNilOrEmpty(para) then
    local indexs = gf:split(para, ",")
    for i = 1, #indexs do
      self:setImagePlist(string.format("KeyWordsImage%02d", i), ORDER[MAP[indexs[i]]], "KeyWordsPanel")
    end
    if not TanAnSMFJMgr:checkHasTips("new_woman") then
      ChatMgr:sendMiscMsg(CHS[5400976])
      gf:ShowSmallTips(CHS[5400976])
      TanAnSMFJMgr:setFlagTips("new_woman", 1)
    end
  else
    local image1 = self:getControl("ImageView", nil, "FireMaskPanel")
    local image2 = self:getControl("ImageView1", nil, "FireMaskPanel")
    local sprite = image1:getVirtualRenderer()
    sprite:setBlendFunc(gl.ONE, gl.ZERO)
    local sprite = image2:getVirtualRenderer()
    sprite:setBlendFunc(gl.ONE, gl.ZERO)
    if not TanAnSMFJMgr:checkHasTips("old_woman") then
      ChatMgr:sendMiscMsg(CHS[5400968])
      gf:ShowSmallTips(CHS[5400968])
      TanAnSMFJMgr:setFlagTips("old_woman", 1)
    end
  end
  local panel = self:getControl("PicturePanel")
  local panel2 = self:getControl("FireMaskPanel")
  local renderPanel = self:getControl("RenderPanel")
  local rText = cc.RenderTexture:create(panel:getContentSize().width + 16, panel:getContentSize().height - 24)
  rText:setPosition(renderPanel:getContentSize().width / 2, renderPanel:getContentSize().height / 2 - 14)
  renderPanel:addChild(rText)
  panel:setPosition(8, 0)
  panel2:setPosition(24, 16)
  rText:beginWithClear(0, 0, 0, 0)
  panel:visit()
  if string.isNilOrEmpty(para) then
    panel2:visit()
  end
  rText:endToLua()
  panel:setVisible(false)
  panel2:setVisible(false)
end
return CaseSMFJWomanPictureDlg
