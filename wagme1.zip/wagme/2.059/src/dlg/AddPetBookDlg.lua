local AddPetBookDlg = Singleton("AddPetBookDlg", Dialog)
function AddPetBookDlg:init()
  self:bindListener("BuyButton", self.onBuyButton)
  self:bindCheckBoxListener("GoldCheckBox", self.onCheckBox)
  self.pet = nil
  self:onCheckBox(self:getControl("GoldCheckBox"))
end
function AddPetBookDlg:onCheckBox(sender, eventType)
  self:setCtrlVisible("SilverImage", not sender:getSelectedState(), "BuyButton")
  self:setCtrlVisible("GoldImage", sender:getSelectedState(), "BuyButton")
end
function AddPetBookDlg:setData(pet)
  self.pet = pet
end
function AddPetBookDlg:onBuyButton(sender, eventType)
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  local pet = self.pet
  if self.pet:queryInt("rank") == Const.PET_RANK_WILD then
    gf:ShowSmallTips(string.format(CHS[4200215], self.pet:getName()))
    return
  end
  local godBookCount = pet:queryBasicInt("god_book_skill_count")
  local dlg = DlgMgr:getDlgByName("PetSkillDlg")
  if not dlg then
    return
  end
  local skillNo = dlg.curSkillNo
  local skillName = SkillMgr:getSkillName(skillNo)
  local power = 0
  for i = 1, godBookCount do
    local nameKey = "god_book_skill_name_" .. i
    local name = pet:queryBasic(nameKey)
    local skillAttr = SkillMgr:getskillAttribByName(name)
    if skillNo == skillAttr.skill_no then
      local levelKey = "god_book_skill_level_" .. i
      local powerKey = "god_book_skill_power_" .. i
      local level = pet:queryBasic(levelKey)
      local bookPower = pet:queryBasicInt(powerKey)
      power = bookPower
    end
  end
  if power + 3500 > 30000 then
    gf:ShowSmallTips(CHS[4200216])
    return
  end
  if self:checkSafeLockRelease("onBuyButton") then
    return
  end
  if Me:getTotalCoin() < 100 then
    gf:askUserWhetherBuyCoin()
    return
  end
  local limitStr, day = gf:converToLimitedTimeDay(pet:query("gift"))
  local isGold = self:isCheck("GoldCheckBox")
  local coin_type = isGold and "gold_coin" or ""
  local costSilver = 0
  if isGold then
    if 100 > Me:getGoldCoin() then
      gf:askUserWhetherBuyCoin()
      return
    end
  elseif 100 <= Me:getSilverCoin() then
    costSilver = 100
  else
    costSilver = Me:getSilverCoin()
  end
  if costSilver ~= 0 and day < 60 then
    local willLimitDay = 10
    gf:confirm(string.format(CHS[4200214], costSilver, willLimitDay), function()
      PetMgr:buyGodBooknimbusByCoin(pet:queryBasicInt("no"), skillName, coin_type)
    end)
    return
  end
  PetMgr:buyGodBooknimbusByCoin(pet:queryBasicInt("no"), skillName, coin_type)
end
return AddPetBookDlg
