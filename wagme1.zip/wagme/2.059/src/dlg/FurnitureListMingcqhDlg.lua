local FurnitureListDlg = require("dlg/FurnitureListDlg")
local FurnitureListMingcqhDlg = Singleton("FurnitureListMingcqhDlg", FurnitureListDlg)
function FurnitureListMingcqhDlg:init()
  FurnitureListDlg.init(self)
  self:hookMsg("MSG_ENTER_ROOM")
  self:hookMsg("MSG_YUANDJ_MCQH_BONUS")
end
function FurnitureListMingcqhDlg:getCfgFileName()
  return ResMgr:getDlgCfg("FurnitureListDlg")
end
function FurnitureListMingcqhDlg:initShowText(char, menus)
  local furnitureType = char:queryBasic("furniture_type")
  local button = self:getControl("FurnitureButton")
  local name = char:queryBasic("name")
  button:setTitleText(CHS[2000720])
end
function FurnitureListMingcqhDlg:onFurnitureButton(sender)
  if not self.char then
    return
  end
  local char = self.char
  local id = char:getId()
  local furn = HomeMgr:getFurnitureById(id)
  if not furn then
    gf:ShowSmallTips(CHS[4200431])
    ChatMgr:sendMiscMsg(CHS[4200431])
    self:onCloseButton()
    return
  elseif furn.curX ~= char.curX or furn.curY ~= char.curY then
    gf:ShowSmallTips(CHS[4200418])
    ChatMgr:sendMiscMsg(CHS[4200418])
    self:onCloseButton()
    return
  end
  gf:confirm(CHS[2000721], function()
    local magic
    magic = gf:createCallbackMagic(ResMgr.magic.xiulmz_grey_fog, function()
      if magic then
        magic:removeFromParent()
        MingcqhMgr:checkFurniture(furn)
      end
    end)
    magic:setAnchorPoint(cc.p(0.5, 0.5))
    magic:setPosition(furn.curX, furn.curY)
    gf:getCharTopLayer():addChild(magic)
    gf:CmdToServer("CMD_YUANDJ_MCQH_SELECT_FURNITURE", {
      index = furn:getId()
    })
  end, nil, nil, nil, nil, nil, nil, "mcqh")
  self:close()
end
function FurnitureListMingcqhDlg:MSG_ENTER_ROOM(data)
  self:onCloseButton()
end
function FurnitureListMingcqhDlg:MSG_YUANDJ_MCQH_BONUS(data)
  self:onCloseButton()
end
return FurnitureListMingcqhDlg
