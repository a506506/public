local CombatResultDlg = Singleton("CombatResultDlg", Dialog)
local SUDU = 1
local SHANGHAI = 2
local ZHANGAI = 3
local ZHILIAO = 4
local TIPS = {
  [1] = CHS[4101592],
  [2] = CHS[4101593],
  [3] = CHS[4101594],
  [4] = CHS[4101595]
}
function CombatResultDlg:init(data)
  self:setCtrlFullClient("BlackImage")
  self:setCtrlFullClient(self.root)
  self:bindListener("CloseImage", self.onCloseButton)
  self:bindListener("ContinueButton", self.onCloseButton)
  self:createShareButton(self:getControl("ShareButton"), SHARE_FLAG.FIGHTRESULT)
  self.data = data
  self:setPlayerData(data)
  local dlg = DlgMgr:getDlgByName("DeadRemindDlg")
  if dlg then
    self:setVisible(false)
  end
  if data and data.dlgType == "qmpk" then
    self:setCtrlVisible("QuanmPKImage", true)
  end
end
function CombatResultDlg:setPlayerData(data)
  local leftData, rightData
  local resulrPanel = self:getControl("BKPanel", nil, "MainPanel")
  local isQmpkInfo = false
  if self.data and self.data.dlgType and self.data.dlgType == "qmpk" then
    isQmpkInfo = true
  end
  self:setCtrlVisible("DistPanel", GameMgr:IsCrossDist(), "LeftResultPanel")
  self:setCtrlVisible("DistPanel", GameMgr:IsCrossDist(), "RightResultPanel")
  if isQmpkInfo then
    self:setCtrlVisible("DistPanel", false, "LeftResultPanel")
    self:setCtrlVisible("DistPanel", false, "RightResultPanel")
    self:setCtrlVisible("QuanmPKDistPanel", true, "LeftResultPanel")
    self:setCtrlVisible("QuanmPKDistPanel", true, "RightResultPanel")
  end
  if data.corps == 1 then
    leftData = data.atk_players
    rightData = data.def_players
    self:setCtrlVisible("VictoryPanel", data.result == 1, "LeftResultPanel")
    self:setCtrlVisible("FailPanel", data.result == 2, "LeftResultPanel")
    self:setCtrlVisible("VictoryPanel", data.result == 2, "RightResultPanel")
    self:setCtrlVisible("FailPanel", data.result == 1, "RightResultPanel")
  elseif data.corps == 2 then
    rightData = data.atk_players
    leftData = data.def_players
    self:setCtrlVisible("VictoryPanel", data.result == 2, "LeftResultPanel")
    self:setCtrlVisible("FailPanel", data.result == 1, "LeftResultPanel")
    self:setCtrlVisible("VictoryPanel", data.result == 1, "RightResultPanel")
    self:setCtrlVisible("FailPanel", data.result == 2, "RightResultPanel")
  else
    leftData = data.atk_players
    rightData = data.def_players
  end
  if data.result == 3 then
    self:setCtrlVisible("VictoryPanel", false, "RightResultPanel")
    self:setCtrlVisible("FailPanel", false, "RightResultPanel")
  end
  local teamPanel = self:getControl("LeftPanel")
  local distPanel = self:getControl("DistPanel", nil, "LeftResultPanel")
  if isQmpkInfo then
    distPanel = self:getControl("QuanmPKDistPanel", nil, "LeftResultPanel")
  end
  self:setLabelText("DistLabel", leftData[1].dist_name, distPanel)
  for i = 1, 5 do
    local uPanel = self:getControl("SingleMemberPanel_" .. i, nil, teamPanel)
    self:setUnitPlayerData(leftData[i], uPanel, data.corps == 1)
  end
  local teamPanel = self:getControl("RightPanel")
  local distPanel = self:getControl("DistPanel", nil, "RightResultPanel")
  if isQmpkInfo then
    distPanel = self:getControl("QuanmPKDistPanel", nil, "RightResultPanel")
  end
  self:setLabelText("DistLabel", rightData[1].dist_name, distPanel)
  for i = 1, 5 do
    local uPanel = self:getControl("SingleMemberPanel_" .. i, nil, teamPanel)
    self:setUnitPlayerData(rightData[i], uPanel, data.corps == 2)
  end
end
function CombatResultDlg:onImage(sender, eventType)
  gf:showTipInfo(sender.tips, sender)
end
function CombatResultDlg:setUnitPlayerData(data, panel, isAtk)
  panel.data = data
  if not data then
    panel:setVisible(false)
    return
  end
  panel:setVisible(true)
  self:setLabelText("MemberNameLabel", gf:getRealName(data.name), panel)
  self:setImage("ShapeImage", ResMgr:getSmallPortrait(data.icon), panel)
  local powPanel = self:getControl("PowerInfoPanel", nil, panel)
  self:setLabelText("ValueLabel", data.total_damage, powPanel)
  local obPanel = self:getControl("ObstructInfoPanel", nil, panel)
  self:setLabelText("ValueLabel", data.abnormal_tims, obPanel)
  local healPanel = self:getControl("HealInfoPanel", nil, panel)
  self:setLabelText("ValueLabel", data.total_heal, healPanel)
  local diePanel = self:getControl("DieInfoPanel", nil, panel)
  self:setLabelText("ValueLabel", data.dead_times, diePanel)
  for i = 1, 4 do
    self:setImagePlist("Image_" .. i, ResMgr.ui.touming, panel)
    self:setCtrlVisible("Image_" .. i, false, panel)
    self:bindListener("Image_" .. i, self.onImage, panel)
  end
  if isAtk then
    self:setProgressBarForSelf("ProgressBar", data.total_damage, self.data.atk_total_damage, powPanel)
    self:setProgressBarForSelf("ProgressBar", data.abnormal_tims, self.data.atk_abnormal_tims, obPanel)
    self:setProgressBarForSelf("ProgressBar", data.total_heal, self.data.atk_total_heal, healPanel)
    self:setProgressBarForSelf("ProgressBar", data.dead_times, self.data.atk_dead_times, diePanel)
    local idx = 1
    if data.id == self.data.shengshou.id and self.data.shengshou.value ~= 0 then
      local img = self:setImage("Image_" .. idx, ResMgr.ui.shengshou, panel)
      img.tips = TIPS[ZHILIAO]
      self:setCtrlVisible("Image_" .. idx, true, panel)
      idx = idx + 1
    end
    if data.id == self.data.fengshen.id and self.data.fengshen.value ~= 0 then
      local img = self:setImage("Image_" .. idx, ResMgr.ui.fengshen, panel)
      img.tips = TIPS[ZHANGAI]
      self:setCtrlVisible("Image_" .. idx, true, panel)
      idx = idx + 1
    end
    if data.id == self.data.zhanshen.id and self.data.zhanshen.value ~= 0 then
      local img = self:setImage("Image_" .. idx, ResMgr.ui.zhanshen, panel)
      img.tips = TIPS[SHANGHAI]
      self:setCtrlVisible("Image_" .. idx, true, panel)
      idx = idx + 1
    end
    if data.id == self.data.first_order_player_id then
      local img = self:setImage("Image_" .. idx, ResMgr.ui.xianshou, panel)
      img.tips = TIPS[SUDU]
      self:setCtrlVisible("Image_" .. idx, true, panel)
    end
  else
    self:setProgressBarForSelf("ProgressBar", data.total_damage, self.data.def_total_damage, powPanel)
    self:setProgressBarForSelf("ProgressBar", data.abnormal_tims, self.data.def_abnormal_tims, obPanel)
    self:setProgressBarForSelf("ProgressBar", data.total_heal, self.data.def_total_heal, healPanel)
    self:setProgressBarForSelf("ProgressBar", data.dead_times, self.data.def_dead_times, diePanel)
    local idx = 1
    if data.id == self.data.shengshou.id and self.data.shengshou.value ~= 0 then
      local img = self:setImage("Image_" .. idx, ResMgr.ui.shengshou, panel)
      img.tips = TIPS[ZHILIAO]
      self:setCtrlVisible("Image_" .. idx, true, panel)
      idx = idx + 1
    end
    if data.id == self.data.fengshen.id and self.data.fengshen.value ~= 0 then
      local img = self:setImage("Image_" .. idx, ResMgr.ui.fengshen, panel)
      img.tips = TIPS[ZHANGAI]
      self:setCtrlVisible("Image_" .. idx, true, panel)
      idx = idx + 1
    end
    if data.id == self.data.zhanshen.id and self.data.zhanshen.value ~= 0 then
      local img = self:setImage("Image_" .. idx, ResMgr.ui.zhanshen, panel)
      self:setCtrlVisible("Image_" .. idx, true, panel)
      img.tips = TIPS[SHANGHAI]
      idx = idx + 1
    end
    if data.id == self.data.first_order_player_id then
      local img = self:setImage("Image_" .. idx, ResMgr.ui.xianshou, panel)
      self:setCtrlVisible("Image_" .. idx, true, panel)
      img.tips = TIPS[SUDU]
    end
  end
end
function CombatResultDlg:setProgressBarForSelf(name, val, max, root)
  self:setProgressBar(name, val, max, root)
  if max ~= 0 then
    self:setLabelText("PercentageLabel_1", string.format("%0.2f%%", val / max * 100), root)
    self:setLabelText("PercentageLabel_2", string.format("%0.2f%%", val / max * 100), root)
  end
end
function CombatResultDlg:setCtrlFullClient(ctrlName, root, isKeepSize, dontDoLayout)
  if not DeviceMgr:getUIScale() then
    local winsize = {
      width = Const.WINSIZE.width / Const.UI_SCALE,
      height = Const.WINSIZE.height / Const.UI_SCALE,
      x = 0,
      y = 0,
      ox = 0,
      oy = 0
    }
  end
  local panel
  if "string" == type(ctrlName) then
    panel = self:getControl(ctrlName, nil, root)
  else
    panel = ctrlName
  end
  if not panel then
    return
  end
  if not isKeepSize then
    local curSize = panel:getContentSize()
    panel:setContentSize(winsize.width + winsize.ox * 2, winsize.height + winsize.oy * 4)
    local newSize = panel:getContentSize()
    local cx, cy = panel:getPosition()
    panel:setPosition(cx + (newSize.width - curSize.width) * (panel:getAnchorPoint().x - 0.5), cy + (newSize.height - curSize.height) * (panel:getAnchorPoint().y - 0.5))
  end
  local ox, oy = winsize.y or winsize.x or 0, 0
  ox, oy = ox / Const.UI_SCALE, oy / Const.UI_SCALE
  local x, y = panel:getPosition()
  panel:setPosition(x - ox, y - oy)
  if panel.requestDoLayout and not dontDoLayout then
    panel:requestDoLayout()
  end
end
return CombatResultDlg
