local CommunitySmallVideoDlg = Singleton("CommunitySmallVideoDlg", Dialog)
local LOAD_MAX_TIME = 10
local schemeMethods = {
  expandVideo = "onExpandVideo",
  showArticle = "onShowArticle"
}
local lastTouchPos, moveSprite
function CommunitySmallVideoDlg:init(uri)
  self.blank:setLocalZOrder(Const.LOADING_DLG_ZORDER - 2)
  self:bindListener("MovePanel", self.onMovePanel, nil, true)
  self.curUrl = CommunityMgr:getCommunityURL() .. "/" .. uri
  self.moveSprite = self:retainCtrl("FramePanel")
  self.moveSprite:setAnchorPoint(0.5, 0.5)
  self:beginLoadUrl()
  self:hookMsg("MSG_ENTER_ROOM")
  local rootSize = self.moveSprite:getContentSize()
  local blankSize = self.blank:getContentSize()
  self.minX = rootSize.width / 2
  self.maxX = blankSize.width - rootSize.width / 2
  self.minY = rootSize.height / 2
  self.maxY = blankSize.height - rootSize.height / 2
end
function CommunitySmallVideoDlg:setMusicOnBeforeInfo(isMousicOn, isSoundOn, isDubbingOn)
  self.isMusicOnBeforeOpen = isMousicOn
  self.isSoundOnBeforeOpen = isSoundOn
  self.isDubbingOnBeforeOpen = isDubbingOn
end
function CommunitySmallVideoDlg:onMovePanel(sender, eventType)
  if eventType == ccui.TouchEventType.began then
    if moveSprite then
      local movePosX, movePosY = moveSprite:getPosition()
      self:setPosition(cc.p(movePosX, movePosY))
      moveSprite:removeFromParent()
      moveSprite = nil
    end
    lastTouchPos = gf:deepCopy(GameMgr.curTouchPos)
    moveSprite = self.moveSprite:clone()
    local rootPosX, rootPosY = self.root:getPosition()
    moveSprite:setPosition(rootPosX, rootPosY)
    moveSprite:setLocalZOrder(-1)
    self.blank:addChild(moveSprite)
  elseif eventType == ccui.TouchEventType.moved then
    if not moveSprite then
      return
    end
    local curTouchPos = gf:deepCopy(GameMgr.curTouchPos)
    local offsetX, offsetY = curTouchPos.x - lastTouchPos.x, curTouchPos.y - lastTouchPos.y
    local curX, curY = moveSprite:getPosition()
    local setX, setY = curX + offsetX, curY + offsetY
    setX = math.max(math.min(setX, self.maxX), self.minX)
    setY = math.max(math.min(setY, self.maxY), self.minY)
    moveSprite:setPosition(cc.p(setX, setY))
    lastTouchPos = curTouchPos
  elseif eventType == ccui.TouchEventType.ended or eventType == ccui.TouchEventType.canceled then
    if not moveSprite then
      return
    end
    local movePosX, movePosY = moveSprite:getPosition()
    self:setPosition(cc.p(movePosX, movePosY))
    moveSprite:removeFromParent()
    moveSprite = nil
  end
end
function CommunitySmallVideoDlg:beginLoadUrl()
  self:createWebView()
  self.webView:loadURL(self.curUrl)
  local startTime = LOAD_MAX_TIME
  if not self.schedulId then
    self.schedulId = self:startSchedule(function()
      if startTime > 0 then
        startTime = startTime - 1
      else
        self:clearSchedule()
        self:removeWebView()
      end
    end, 1)
  end
  self:setVisible(true)
  self.webView:setVisible(false)
end
function CommunitySmallVideoDlg:onCloseButton(sender, eventType)
  local dlg = DlgMgr:getDlgByName("CommunityDlg")
  if dlg then
    dlg:onCloseButton()
  end
  DlgMgr:closeDlg(self.name)
end
function CommunitySmallVideoDlg:cleanup()
  self:clearSchedule()
  self:removeWebView()
  if not self.isCloseDlgByExpandBtn then
    self:tryToResumeMusic()
  end
  local dlg = DlgMgr:getDlgByName("CommunityDlg")
  if dlg then
    dlg:setMusicOnBeforeInfo(self.isMusicOnBeforeOpen, self.isSoundOnBeforeOpen, self.isDubbingOnBeforeOpen)
  end
  self.isCloseDlgByExpandBtn = nil
  self.curUrl = nil
  self.isMusicOnBeforeOpen = nil
  self.isSoundOnBeforeOpen = nil
  self.isDubbingOnBeforeOpen = nil
end
function CommunitySmallVideoDlg:clearSchedule()
  if self.schedulId then
    self:stopSchedule(self.schedulId)
    self.schedulId = nil
  end
end
function CommunitySmallVideoDlg:tryToResumeMusic()
  if self.isPlayVideo then
    if self.isMusicOnBeforeOpen then
      SoundMgr:resumeMusic()
    end
    if self.isSoundOnBeforeOpen then
      SoundMgr:resumeSound()
    end
    if self.isDubbingOnBeforeOpen then
      SoundMgr:resumeDubbing()
    end
    self.isPlayVideo = false
  end
end
function CommunitySmallVideoDlg:onShowArticle(args)
  local type = args.type
  if type == "video" then
    self.isPlayVideo = true
    if self.isMusicOnBeforeOpen then
      SoundMgr:pauseMusic()
    end
    if self.isSoundOnBeforeOpen then
      SoundMgr:pauseSound()
    end
    if self.isDubbingOnBeforeOpen then
      SoundMgr:stopDubbing()
    end
  else
    self:tryToResumeMusic()
  end
end
function CommunitySmallVideoDlg:onExpandVideo(args)
  Log:I("WDSY-41899 community onExpandVideo ")
  CommunityMgr:setLastAcesss(CommunityMgr.lastAccessUrl, gf:getServerTime())
  CommunityMgr:askForOpenCommunityDlg()
  if not string.isNilOrEmpty(args) and not string.isNilOrEmpty(args.playtime) then
    local jsCode = string.format("atmMaxWebview(%d);", tonumber(args.playtime))
    DlgMgr:sendMsg("CommunityDlg", "doSmallDlgExpandVideo", jsCode)
  end
  self.isCloseDlgByExpandBtn = true
  DlgMgr:closeDlg(self.name)
end
function CommunitySmallVideoDlg:createWebView()
  if self.webView then
    return
  end
  self.webView = ccexp.WebView:create()
  local webPanel = self:getControl("WebPanel")
  local panelSize = webPanel:getContentSize()
  self.webView = ccexp.WebView:create()
  if gf:isIos() and DeviceMgr:getOSVer() >= "8" and "function" == type(self.webView.useWKWebViewInIos) then
    self.webView:useWKWebViewInIos(true)
  end
  self.webView:setScalesPageToFit(true)
  self.webView:setContentSize(panelSize)
  self.webView:setAnchorPoint(0, 0)
  webPanel:addChild(self.webView)
  self.webView:setVisible(false)
  self.webView:setOnDidFailLoading(function(sender, url)
    if not DlgMgr:isDlgOpened(self.name) then
      return
    end
    self:clearSchedule()
    self:removeWebView()
  end)
  self.webView:setOnDidFinishLoading(function(sender, url)
    if not DlgMgr:isDlgOpened(self.name) then
      return
    end
    self:clearSchedule()
    if self.webView then
      self.webView:setVisible(true)
    end
    self.curUrl = url
  end)
  if "function" == type(self.webView.setOnJSCallback) then
    self.webView:setOnJSCallback(function(sender, url)
      Client:pushDebugInfo("OnJSCallback:" .. tostring(url))
      local info = self:parseAtmScheme(url)
      if info.scheme ~= "atm" then
        return
      end
      local methodName = info.method
      if string.isNilOrEmpty(methodName) then
        return
      end
      local method = schemeMethods[methodName]
      if not method or "function" ~= type(self[method]) then
        return
      end
      self[method](self, info.args)
    end)
    self.webView:setJavascriptInterfaceScheme("atm")
  end
end
function CommunitySmallVideoDlg:parseAtmScheme(schemeUrl)
  local url = require("url")
  local info = {}
  info.scheme, info.host = string.match(schemeUrl, "([^:]+)://(.*)")
  local pos = gf:findStrByByte(info.host, "?")
  if not pos then
    info.method = info.host
    return info
  end
  info.method = string.sub(info.host, 1, pos - 1)
  info.args = {}
  local list = gf:split(string.sub(info.host, pos + 1) or "", "&")
  for i = 1, #list do
    local kv = list[i]
    pos = gf:findStrByByte(kv, "=")
    if pos and pos > 1 then
      info.args[string.sub(kv, 1, pos - 1)] = url.unescape(string.sub(kv, pos + 1))
    end
  end
  return info
end
function CommunitySmallVideoDlg:removeWebView()
  if self.webView then
    self.webView:removeFromParent()
    self.webView = nil
  end
end
function CommunitySmallVideoDlg:MSG_ENTER_ROOM()
  local loadingDlg = DlgMgr:getDlgByName("LoadingDlg")
  if loadingDlg and loadingDlg:isVisible() then
    if self.webView then
      self.webView:setVisible(false)
    end
    local dlg = DlgMgr:getDlgByName("LoadingDlg")
    dlg:registerExitCallBack(function()
      if self.webView then
        self.webView:setVisible(true)
      end
    end)
    return
  end
end
return CommunitySmallVideoDlg
