local ConvenientCallGuardDlg = Singleton("ConvenientCallGuardDlg", Dialog)
function ConvenientCallGuardDlg:init()
  self:bindListener("UseButton", self.onUseButton)
  self.itemImage = self:getControl("ItemImage", Const.UIImage)
  self.nameLabel = self:getControl("NameLabel", Const.UILabel)
  self.blank:setLocalZOrder(Const.FAST_CALL_GUARD_DLG_ZORDER)
  self.root:setAnchorPoint(0, 0)
  local dlgSize = self.root:getContentSize()
  self.root:setPosition(Const.WINSIZE.width, 0)
  local move = cc.MoveTo:create(0.5, cc.p(Const.WINSIZE.width / Const.UI_SCALE - dlgSize.width - (Const.WINSIZE.width - self:getWinSize().width) / 2, 0))
  local moveAct = cc.EaseBounceOut:create(move)
  self.root:runAction(moveAct)
  self.curGuardName = ""
end
function ConvenientCallGuardDlg:MSG_CARD_INFO(data)
end
function ConvenientCallGuardDlg:setInfo(guardData)
  local imgPath = ResMgr:getSmallPortrait(guardData[2])
  self.itemImage:loadTexture(imgPath)
  gf:setItemImageSize(self.itemImage)
  self.nameLabel:setText(guardData[4])
  self.curGuardName = guardData[4]
  local rank = guardData[8]
  local color = CharMgr:getNameColorByType(OBJECT_TYPE.GUARD, false, rank)
  self.nameLabel:setColor(color)
end
function ConvenientCallGuardDlg:onUseButton(sender, eventType)
  if eventType == ccui.TouchEventType.ended then
    local callGuardDlg = DlgMgr:openDlg("GuardAttribDlg")
    if callGuardDlg then
      performWithDelay(callGuardDlg.root, function()
        DlgMgr:sendMsg("GuardListChildDlg", "selectGuardByName", self.curGuardName)
      end, 0.3)
    end
    DlgMgr:closeDlg(self.name)
  end
end
return ConvenientCallGuardDlg
