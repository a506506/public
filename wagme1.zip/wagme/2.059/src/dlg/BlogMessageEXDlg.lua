local BlogMessageDlg = require("dlg/BlogMessageDlg")
local BlogMessageEXDlg = Singleton("BlogMessageEXDlg", BlogMessageDlg)
BlogMessageEXDlg.relationLeftDlgName = "BlogInfoEXDlg"
function BlogMessageEXDlg:getCfgFileName()
  return ResMgr:getDlgCfg("BlogMessageDlg")
end
function BlogMessageEXDlg:onExpressionButton(sender, eventType)
  local dlg = DlgMgr:getDlgByName("LinkAndExpressionDlg")
  if dlg then
    DlgMgr:closeDlg("LinkAndExpressionDlg")
    return
  end
  dlg = DlgMgr:openDlg("LinkAndExpressionDlg")
  dlg:setCallObj(self, "blog")
  local height = dlg:getMainBodyHeight()
  DlgMgr:upDlg("BlogMessageEXDlg", height)
end
function BlogMessageEXDlg:LinkAndExpressionDlgcleanup()
  DlgMgr:resetUpDlg("BlogMessageEXDlg")
end
return BlogMessageEXDlg
