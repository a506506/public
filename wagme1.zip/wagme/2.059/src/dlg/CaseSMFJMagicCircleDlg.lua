local CaseSMFJMagicCircleDlg = Singleton("CaseSMFJMagicCircleDlg", Dialog)
local ITEMS_ORDER = {
  CHS[5400933],
  CHS[5400931],
  CHS[5400932],
  CHS[5400934]
}
function CaseSMFJMagicCircleDlg:init()
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel")
  self:bindListener("AddButton01", self.onAddButton)
  self:bindListener("AddButton02", self.onAddButton)
  self:bindListener("AddButton03", self.onAddButton)
  self:bindListener("AddButton04", self.onAddButton)
  self:bindListener("ClosePanel", self.onCloseButton)
  for i = 1, 4 do
    self:setCtrlVisible(string.format("ItemImage%02d", i), false)
  end
  self.selectTag = 1
  self.selectItems = {}
end
function CaseSMFJMagicCircleDlg:cleanup()
  self.selectTag = nil
  self.selectItems = nil
  self.hasPlayAction = nil
end
function CaseSMFJMagicCircleDlg:setData(itemList, npcName, para)
  self.itemList = itemList
  self.npcName = npcName
  self.orderItems = gf:split(para, ",")
end
function CaseSMFJMagicCircleDlg:onAddButton(sender, eventType)
  if not self.itemList then
    return
  end
  if self.hasPlayAction then
    return
  end
  local tag = tonumber(string.match(sender:getName(), ".+(%d+)"))
  if tag then
    self.selectTag = tag
    local flag = {}
    for _, v in pairs(self.selectItems) do
      flag[v.name] = 1
    end
    local itemList = {}
    for _, v in pairs(self.itemList) do
      if not flag[v.name] then
        table.insert(itemList, v)
      end
    end
    if #itemList == 0 then
      gf:ShowSmallTips(CHS[5400928])
      return
    end
    local dlg = DlgMgr:openDlg("SubmitMultiItemDlg")
    dlg:setData(itemList, 1, "smfj_sj")
  end
end
function CaseSMFJMagicCircleDlg:getItemById(itemId)
  if not self.itemList then
    return
  end
  for i = 1, #self.itemList do
    local item = self.itemList[i]
    if item ~= nil and itemId == item.item_unique then
      return item
    end
  end
end
function CaseSMFJMagicCircleDlg:setSelectItem(itemId)
  if not self.selectTag then
    return
  end
  local item = self:getItemById(itemId)
  if item then
    if not string.match(item.name, CHS[7190438]) then
      gf:ShowSmallTips(CHS[5400930])
      return
    end
    self.selectItems[self.selectTag] = item
    local imgName = string.format("ItemImage%02d", self.selectTag)
    self:setCtrlVisible(imgName, true)
    self:setImage(imgName, ResMgr:getIconPathByName(item.name))
    local img = self:getControl(string.format("AddButton%02d", self.selectTag))
    img:setOpacity(0)
    local count = 0
    for _, v in pairs(self.selectItems) do
      count = count + 1
    end
    if count == 4 then
      self:checkResult()
    end
  end
end
function CaseSMFJMagicCircleDlg:checkResult()
  local isSucc = true
  for i = 1, #self.selectItems do
    if not string.match(self.selectItems[i].name, self.orderItems[i]) then
      isSucc = false
    end
  end
  self.hasPlayAction = true
  if isSucc then
    for i = 1, 4 do
      local magic = gf:createLoopMagic(ResMgr.magic.smfj_shuijing_around, nil, {blendMode = "add"})
      local panel = self:getControl(string.format("ItemImage%02d", i))
      local size = panel:getContentSize()
      magic:setPosition(size.width / 2, size.height / 2)
      panel:addChild(magic)
      if i == 1 then
        performWithDelay(panel, function()
          local data = {
            npc_name = self.npcName,
            count = 4,
            items = {}
          }
          for i = 1, #self.selectItems do
            table.insert(data.items, self.selectItems[i].name)
          end
          gf:CmdToServer("CMD_TANAN_SMFJ_SUBMIT_ITEM", data)
        end, 2)
      end
    end
  else
    for i = 1, 4 do
      do
        local img = self:getControl(string.format("ItemImage%02d", i))
        local action = cc.Sequence:create(cc.MoveBy:create(0.03, cc.p(0, 4)), cc.MoveBy:create(0.06, cc.p(0, -8)), cc.MoveBy:create(0.03, cc.p(0, 4)))
        local action2 = cc.Sequence:create(cc.MoveBy:create(0.02, cc.p(4, 0)), cc.MoveBy:create(0.04, cc.p(-8, 0)), cc.MoveBy:create(0.02, cc.p(4, 0)), cc.CallFunc:create(function()
          if not img:isVisible() then
            img:stopAllActions()
          end
        end))
        img:runAction(cc.RepeatForever:create(cc.Sequence:create(action2)))
        if i == 1 then
          performWithDelay(img, function()
            for i = 1, 4 do
              local img = self:getControl(string.format("ItemImage%02d", i))
              img:setVisible(false)
              local img = self:getControl(string.format("AddButton%02d", i))
              img:setOpacity(255)
            end
            gf:ShowSmallTips(CHS[5400935])
            self.selectItems = {}
            self.hasPlayAction = nil
          end, 0.8)
        end
      end
    end
  end
end
return CaseSMFJMagicCircleDlg
