local DiYuShenYuanDlg = Singleton("DiYuShenYuanDlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
local ICON_CFG = 6510
local OffPos = cc.p(10, -10)
function DiYuShenYuanDlg:init(data)
  self:bindListener("AddButton", self.onAddButton)
  self:bindListener("MinusButton", self.onMinusButton)
  self:bindListener("InfoButton", self.onInfoButton)
  self:bindListener("StartButton", self.onStartButton)
  self:bindListener("RewardButton", self.onRewardButton)
  self:bindFloatingEvent("RulePanel")
  self:setPortrait("BossIconPanel", ICON_CFG, 0, nil, true, nil, nil, OffPos)
  self.data = data
  self:setRound(data.cengshu)
  self.chatContent = {}
  self.curCengshu = math.max(data.heightestLevel, 1)
  self.bar = self:setProgressBar("ExpProgressBar", self.curCengshu, 9)
  self.isShowAct = 0
  self:updateBySetCengShu(true)
end
function DiYuShenYuanDlg:setRound(round)
  if round == 0 then
    self:setCtrlVisible("TextImage2", false, "TextPanel")
    self:setCtrlVisible("TextImage1", true, "TextPanel")
    self:setCtrlVisible("TextImage4", true, "TextPanel")
    self:setCtrlVisible("TextImage3", false, "TextPanel")
    return
  end
  self:setCtrlVisible("TextImage1", true, "TextPanel")
  self:setCtrlVisible("TextImage3", true, "TextPanel")
  self:setCtrlVisible("TextImage4", false, "TextPanel")
  if round == 10 then
    round = 13
  end
  self:setCtrlVisible("TextImage2", true, "TextPanel")
  self:setImagePlist("TextImage2", string.format("lingyzmword%04d.png", round), "TextPanel")
end
function DiYuShenYuanDlg:onAddButton(sender, eventType)
  self.curCengshu = self.curCengshu + 1
  if self.curCengshu > 9 then
    self.curCengshu = 9
  end
  self.bar = self:setProgressBar("ExpProgressBar", self.curCengshu, 9)
  self:updateBySetCengShu(true)
end
function DiYuShenYuanDlg:onMinusButton(sender, eventType)
  self.curCengshu = self.curCengshu - 1
  if self.curCengshu <= 0 then
    self.curCengshu = 1
  end
  self.bar = self:setProgressBar("ExpProgressBar", self.curCengshu, 9)
  self:updateBySetCengShu(true)
end
function DiYuShenYuanDlg:updateBySetCengShu(isShowAct)
  local showReson = 0
  local str = ""
  if self.curCengshu <= 3 then
    self:setLabelText("TitleLabel", string.format(CHS[4101657], gf:changeNumToChinese(self.curCengshu)), "NuYiPanel")
    str = CHS[4101660]
    showReson = 1
  elseif self.curCengshu <= 6 then
    self:setLabelText("TitleLabel", string.format(CHS[4101658], gf:changeNumToChinese(self.curCengshu)), "NuYiPanel")
    showReson = 2
    str = CHS[4101661]
  else
    self:setLabelText("TitleLabel", string.format(CHS[4101659], gf:changeNumToChinese(self.curCengshu)), "NuYiPanel")
    showReson = 3
    str = CHS[4101662]
  end
  if isShowAct and showReson ~= self.isShowAct then
    do
      local panel = self:getControl("BossIconPanel")
      local char = panel:getChildByTag(100)
      self:setChat(char, str)
      local act = gf:getServerTime() % 2 == 1 and Const.SA_ATTACK or Const.SA_CAST
      char:playActionOnce(function()
        local contentSize = panel:getContentSize()
        local basicX = contentSize.width / 2 + OffPos.x
        local basicY = contentSize.height / 2 + OffPos.y
        char:setPosition(basicX, basicY)
      end, act)
    end
  end
  self.isShowAct = showReson
  self:updateBtn()
  local reward = self.data.rewardInfo[self.curCengshu]
  local rewardPanel = self:getControl("ItemListPanel")
  rewardPanel:removeAllChildren(true)
  local rewardContainer = RewardContainer.new(reward, rewardPanel:getContentSize(), nil, nil, true, 13)
  rewardContainer:setAnchorPoint(0, 0.5)
  rewardContainer:setPosition(0, rewardPanel:getContentSize().height / 2)
  rewardPanel:addChild(rewardContainer)
end
function DiYuShenYuanDlg:setChat(char, msg)
  local headX, headY = char:getHeadOffset()
  local dlg = DlgMgr:openDlg("PopUpDlg")
  local bg = dlg:addTip(msg, nil, false)
  bg:setPosition(char:getPositionX() + headX, char:getPositionY() + headY)
  local function cb()
    for k, v in pairs(self.chatContent) do
      if v == bg then
        table.remove(self.chatContent, k)
      end
    end
  end
  local action = cc.Sequence:create(cc.DelayTime:create(3), cc.CallFunc:create(cb), cc.RemoveSelf:create())
  char:getParent():addChild(bg)
  if not self.chatContent then
    self.chatContent = {}
  end
  if #self.chatContent ~= 0 then
    local node = table.remove(self.chatContent, 1)
    node:stopAllActions()
    node:removeFromParent()
  end
  bg:runAction(action)
  table.insert(self.chatContent, bg)
end
function DiYuShenYuanDlg:updateBtn()
  if self.curCengshu == 1 then
    self:setCtrlEnabled("MinusButton", false)
    self:setCtrlEnabled("AddButton", true)
  elseif self.curCengshu == 9 then
    self:setCtrlEnabled("MinusButton", true)
    self:setCtrlEnabled("AddButton", false)
  else
    self:setCtrlEnabled("MinusButton", true)
    self:setCtrlEnabled("AddButton", true)
  end
end
function DiYuShenYuanDlg:onInfoButton(sender, eventType)
  self:setCtrlVisible("RulePanel", true)
end
function DiYuShenYuanDlg:onRewardButton(sender, eventType)
  local task = TaskMgr:getTaskByName(CHS[4200824])
  if self.data.bonus_flag == 0 and not task then
    gf:ShowSmallTips(CHS[4200825])
    return
  end
  if self.data.bonus_flag == 1 then
    gf:ShowSmallTips(CHS[4200826])
    return
  end
  local tips = string.format(CHS[4200827], gf:changeNumToChinese(tonumber(task.task_extra_para)))
  gf:confirm(tips, function()
    AutoWalkMgr:beginAutoWalk(gf:findDest(CHS[4200828]))
    self:onCloseButton()
  end)
end
function DiYuShenYuanDlg:onStartButton(sender, eventType)
  gf:CmdToServer("CMD_GHOSTDOM_CHALLENGE", {
    cengshu = self.curCengshu
  })
end
return DiYuShenYuanDlg
