local FireworksCountdownDlg = Singleton("FireworksCountdownDlg", Dialog)
function FireworksCountdownDlg:init(data)
  self:bindListener("Button1", self.onButton1)
  self:bindListener("ShowButton", self.onShowButton)
  self.blank:setLocalZOrder(Const.LOADING_DLG_ZORDER)
  if data then
    local leftTime = math.min(10, data.leftTime)
    local numImg = self:createCountDown(leftTime, "NumPanel", "MainPanel")
    numImg:setScale(0.7, 0.7)
    local numImg = self:createCountDown(leftTime, "NumPanel", "SmallPanel")
    numImg:setScale(0.6, 0.6)
    if leftTime > 1 then
      self:startCountDown("MainPanel", leftTime)
      self:startCountDown("SmallPanel", leftTime)
    end
  end
  performWithDelay(self.root, function()
    self:onCloseButton()
  end, 20)
  self:onShowButton()
end
function FireworksCountdownDlg:onButton1(sender, eventType)
  self:setCtrlVisible("MainPanel", false)
  self:setCtrlVisible("SmallPanel", true)
end
function FireworksCountdownDlg:onShowButton(sender, eventType)
  self:setCtrlVisible("MainPanel", true)
  self:setCtrlVisible("SmallPanel", false)
end
function FireworksCountdownDlg:startCountDown(root, time)
  Dialog.startCountDown(self, time, "NumPanel", root, function(numImg)
  end, function(numImg)
    if numImg.num == 1 then
      self:stopCountDown("NumPanel", root)
    end
  end)
end
return FireworksCountdownDlg
