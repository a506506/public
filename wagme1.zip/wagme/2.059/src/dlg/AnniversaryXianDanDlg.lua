local AnniversaryXianDanDlg = Singleton("AnniversaryXianDanDlg", Dialog)
local NIMBUS_MAGIC = {
  ResMgr.ArmatureMagic.danlu_nimbus_gold,
  ResMgr.ArmatureMagic.danlu_nimbus_wood,
  ResMgr.ArmatureMagic.danlu_nimbus_water,
  ResMgr.ArmatureMagic.danlu_nimbus_fire,
  ResMgr.ArmatureMagic.danlu_nimbus_earth
}
local GUIDE_CONFIG = {
  {
    action = "showNimbusFinger",
    cond = "checkNimbusGuide",
    finish = "finishNimbusfinger"
  },
  {
    action = "showFireFinger",
    cond = "checkFireGuide",
    finish = "finishFirefinger"
  },
  {
    action = "showHelp",
    cond = "checkHelpGuide"
  }
}
function AnniversaryXianDanDlg:init(param)
  self:bindListener("HelpButton", self.onHelpButton)
  self:bindListener("SupplyButton", self.onSupplyButton)
  self:bindListener("NimbusButton", self.onNimbusButton)
  self:bindListener("BagButton", self.onBagButton)
  self:bindListener("NoteButton", self.onNoteButton)
  self:bindListener("ApplyButton", self.onApplyButton, "BagUsePanel")
  self:bindListener("MetalButton", self.onClickMetalButton, "NimbusSelectPanel")
  self:bindListener("WoodButton", self.onClickWoodButton, "NimbusSelectPanel")
  self:bindListener("WaterButton", self.onClickWaterButton, "NimbusSelectPanel")
  self:bindListener("FireButton", self.onClickFireButton, "NimbusSelectPanel")
  self:bindListener("EarthButton", self.onClickEarthButton, "NimbusSelectPanel")
  self.chosenCtrl = self:retainCtrl("ChosenImage", "BagUsePanel")
  self:bindFloatPanelListener("NimbusSelectPanel")
  self.guideState = cc.UserDefault:getInstance():getIntegerForKey(string.format("xd_state_%s", Me:queryBasic("gid")), 1)
  for i = 1, 4 do
    self:bindListener("XianDPanel_" .. i, self.onClickXianD, "BagUsePanel")
    self:setCtrlTouchEnabled("XianDPanel_" .. i, true, "BagUsePanel")
    self:setCtrlVisible("ChosenImage", false, self:getControl("XianDPanel_" .. i, nil, "BagUsePanel"))
  end
  self:bindFloatPanelListener("BagUsePanel")
  self:refreshData()
  if not param then
    gf:CmdToServer("CMD_ZNQ_2020_XDHX_DATA", {})
  end
  schedule(self.root, function()
    gf:CmdToServer("CMD_ZNQ_2020_XDHX_DATA", {})
  end, 60)
  self:hookMsg("MSG_ZNQ_2020_XDHX_DATA")
  self:hookMsg("MSG_ZNQ_2020_XDHX_CLOSE_DLG")
  EventDispatcher:addEventListener("ENTER_FOREGROUND", self.onResume, self)
end
function AnniversaryXianDanDlg:cleanup()
  self.chosenCtrl = nil
  self.changingNimbus = nil
  self.guideState = nil
  DlgMgr:closeDlg("AnniversaryXianDanRuleDlg")
  EventDispatcher:removeEventListener("ENTER_FOREGROUND", self.onResume, self)
end
function AnniversaryXianDanDlg:tryPlayGuide(...)
  if not self.guideState then
    return
  end
  local item = GUIDE_CONFIG[self.guideState]
  if not item then
    return
  end
  if item.cond and self[item.cond] and self[item.cond](self, ...) then
    self[item.action](self, ...)
  end
end
function AnniversaryXianDanDlg:playNextGuide(state, ...)
  if not self.guideState or state ~= self.guideState then
    return
  end
  local item = GUIDE_CONFIG[self.guideState]
  if not item then
    return
  end
  if item.finish and self[item.finish] then
    self[item.finish](self)
  end
  self.guideState = self.guideState + 1
  self:tryPlayGuide(...)
  cc.UserDefault:getInstance():setIntegerForKey(string.format("xd_state_%s", Me:queryBasic("gid")), self.guideState)
end
function AnniversaryXianDanDlg:refreshData()
  local data = AnniversaryMgr:getXdhxData()
  if not data then
    self:setCtrlVisible("StatePanel", false)
    self:setCtrlVisible("OperatePanel", false)
    self:setDanLuState()
    return
  end
  self:setCtrlVisible("StatePanel", true)
  self:setCtrlVisible("OperatePanel", true)
  self:showDanLuFloating(data.is_closed or not self:isOpen())
  self:setLevel(data.level, data.exp, data.next_level_need_exp)
  self:setNote(data)
  self:setFire(data.fire_point)
  self:setRemainTime(data.remain_bonus_time, data.is_closed)
  local panel = self:getControl("DanLunWindowMagicPanel", nil, "DanLuPanel")
  if self.changingNimbus == 1 then
    local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
    if magic then
      magic:removeFromParent()
    end
    local info = data.level >= 4 and ResMgr.ArmatureMagic.danlu_close_4_6 or ResMgr.ArmatureMagic.danlu_close_1_3
    magic = gf:createArmatureLoopMagic(info.name, info.action, panel, 314, panel:getContentSize().height - 261, 1)
    magic:setTag(Const.ARMATURE_MAGIC_TAG)
    self:playCollectNimbus(function()
      self:setNimbusState()
      self:playDanLuOpen(function()
        function onFinish()
          gf:ShowSmallTips(string.format(CHS[2100369], gf:getPolar(data.nimbus_type)))
          self.changingNimbus = nil
        end
        if data.is_closed then
          performWithDelay(panel, function()
            self:playDanLuClose(function()
              onFinish()
              self:setDanLuState()
            end)
          end, 0.3)
        else
          onFinish()
        end
      end)
    end)
  elseif self.changingNimbus == 2 then
    self:playDanLuClose(function()
      local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
      if magic then
        magic:removeFromParent()
      end
      local info = data.level >= 4 and ResMgr.ArmatureMagic.danlu_close_4_6 or ResMgr.ArmatureMagic.danlu_close_1_3
      magic = gf:createArmatureLoopMagic(info.name, info.action, panel, 314, panel:getContentSize().height - 261, 1)
      magic:setTag(Const.ARMATURE_MAGIC_TAG)
      self:playCollectNimbus(function()
        self:setNimbusState()
        self:playDanLuOpen(function()
          gf:ShowSmallTips(string.format(CHS[2100369], gf:getPolar(data.nimbus_type)))
          self.changingNimbus = nil
        end)
      end)
    end)
  else
    self:setNimbusState()
    self.changingNimbus = nil
  end
  self:setButtonState(data)
  self:tryPlayGuide(data)
end
function AnniversaryXianDanDlg:showDanLuFloating(isClosed)
  local danLuPanel = self:getControl("OnlyDanLuPanel", nil, "DanLuPanel")
  if not danLuPanel.initPos then
    local x, y = danLuPanel:getPosition()
    danLuPanel.initPos = cc.p(x, y)
  end
  if isClosed then
    if danLuPanel.floatingAction then
      danLuPanel:stopAllActions()
    end
    danLuPanel.floatingAction = nil
    danLuPanel:setPosition(danLuPanel.initPos)
    return
  end
  if not danLuPanel.floatingAction then
    local act1 = cc.EaseSineInOut:create(cc.MoveBy:create(1, cc.p(0, 10)))
    local act2 = cc.EaseSineInOut:create(cc.MoveBy:create(1, cc.p(0, -10)))
    danLuPanel.floatingAction = danLuPanel:runAction(cc.RepeatForever:create(cc.Sequence:create(act1, act2)))
  end
end
function AnniversaryXianDanDlg:isStart()
  local data = AnniversaryMgr:getXdhxData()
  if not data then
    return
  end
  return 0 ~= data.nimbus_type
end
function AnniversaryXianDanDlg:isOpen()
  local data = AnniversaryMgr:getXdhxData()
  if not data then
    return
  end
  return 0 ~= data.nimbus_type and not data.is_closed
end
function AnniversaryXianDanDlg:setLevel(level, curExp, nextNeedExp)
  local levelPanel = self:getControl("LevelPanel", nil, "StatePanel")
  self:setLabelText("Label1", level, levelPanel)
  self:setLabelText("Label2", level, levelPanel)
  local expDesc = level < 6 and string.format("%d/%d", curExp, nextNeedExp) or CHS[2100355]
  self:setLabelText("Label3", expDesc, levelPanel)
  self:setLabelText("Label4", expDesc, levelPanel)
  self:setLabelText("Label5", expDesc, levelPanel)
  self:setProgressBar("ProgressBar", curExp, nextNeedExp, levelPanel, COLOR3.GREEN)
  self:setDanLuState()
end
function AnniversaryXianDanDlg:setDanLuState()
  local isOpen = self:isOpen()
  local data = AnniversaryMgr:getXdhxData()
  if not data then
    return
  end
  local level = data and data.level
  local panel = self:getControl("DanLunWindowMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
  if not isOpen then
    local info = level >= 4 and ResMgr.ArmatureMagic.danlu_close_4_6 or ResMgr.ArmatureMagic.danlu_close_1_3
    local magic = gf:createArmatureLoopMagic(info.name, info.action, panel, 314, panel:getContentSize().height - 261, 1)
    magic:setTag(Const.ARMATURE_MAGIC_TAG)
  end
  self:setCtrlVisible("DanLunLevelImage_1", level <= 3, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_2", level == 2, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_3", level == 3, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_4", level >= 4, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_5", level >= 5, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_6", level == 6, "DanLuPanel")
end
function AnniversaryXianDanDlg:playDanLuOpen(callback)
  local panel = self:getControl("DanLunWindowMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
  local data = AnniversaryMgr:getXdhxData()
  local level = data and data.level
  if not level then
    return
  end
  local info = level >= 4 and ResMgr.ArmatureMagic.danlu_opening_4_6 or ResMgr.ArmatureMagic.danlu_opening_1_3
  local magic = gf:createArmatureOnceMagic(info.name, info.action, panel, callback, self, nil, 314, panel:getContentSize().height - 261, 1)
  magic:setTag(Const.ARMATURE_MAGIC_TAG)
end
function AnniversaryXianDanDlg:playDanLuClose(callback)
  local panel = self:getControl("DanLunWindowMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
  local data = AnniversaryMgr:getXdhxData()
  local level = data and data.level
  if not level then
    return
  end
  local info = level >= 4 and ResMgr.ArmatureMagic.danlu_closeing_4_6 or ResMgr.ArmatureMagic.danlu_closeing_1_3
  local magic = gf:createArmatureOnceMagic(info.name, info.action, panel, callback, self, nil, 314, panel:getContentSize().height - 261, 1)
  magic:setTag(Const.ARMATURE_MAGIC_TAG)
end
function AnniversaryXianDanDlg:playCollectNimbus(callback)
  local panel = self:getControl("DanLunnimbusMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
  panel = self:getControl("DanLunnimbusCollectMagicPanel", nil, "DanLuPanel")
  magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
  local info = ResMgr.ArmatureMagic.danlu_collect
  local magic = gf:createArmatureOnceMagic(info.name, info.action, panel, callback, self, nil, 314, panel:getContentSize().height - 262, 1)
  magic:setTag(Const.ARMATURE_MAGIC_TAG)
end
function AnniversaryXianDanDlg:setNimbusState()
  local panel = self:getControl("DanLunnimbusMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
  if not self:isStart() then
    return
  end
  local data = AnniversaryMgr:getXdhxData()
  local nimbus_type = data and data.nimbus_type
  if not nimbus_type then
    return
  end
  local info = NIMBUS_MAGIC[nimbus_type]
  local magic = gf:createArmatureLoopMagic(info.name, info.action, panel, 314, panel:getContentSize().height - 262, 1)
  magic:setTag(Const.ARMATURE_MAGIC_TAG)
end
function AnniversaryXianDanDlg:setFire(value)
  local firePanel = self:getControl("FirePanel", nil, "StatePanel")
  local fireState = CHS[2100338]
  local icon = ResMgr.magic.danlu_fire_state_1
  local image = ResMgr.ui.danlu_fire_state_1
  if value >= 75 then
    fireState = CHS[2100339]
    icon = ResMgr.magic.danlu_fire_state_5
    image = ResMgr.ui.danlu_fire_state_5
  elseif value >= 50 then
    fireState = CHS[2100340]
    icon = ResMgr.magic.danlu_fire_state_4
    image = ResMgr.ui.danlu_fire_state_4
  elseif value >= 25 then
    fireState = CHS[2100341]
    icon = ResMgr.magic.danlu_fire_state_3
    image = ResMgr.ui.danlu_fire_state_3
  elseif value > 0 then
    fireState = CHS[2100342]
    icon = ResMgr.magic.danlu_fire_state_2
    image = ResMgr.ui.danlu_fire_state_2
  else
    fireState = CHS[2100338]
    icon = ResMgr.magic.danlu_fire_state_1
    image = ResMgr.ui.danlu_fire_state_1
  end
  self:setLabelText("Label1", fireState, firePanel)
  self:setLabelText("Label2", fireState, firePanel)
  self:setImage("Image", image, firePanel)
  local fireDesc = string.format("%d/%d", value, 100)
  self:setLabelText("Label3", fireDesc, firePanel)
  self:setLabelText("Label4", fireDesc, firePanel)
  self:setLabelText("Label5", fireDesc, firePanel)
  self:setProgressBar("ProgressBar", value, 100, firePanel, COLOR3.GREEN)
  self:setFireMagic(icon)
end
function AnniversaryXianDanDlg:setFireMagic(icon)
  local panel = self:getControl("FireMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByName("FireMagic")
  if magic then
    magic:removeFromParent()
  end
  if not self:isStart() then
    return
  end
  magic = gf:createLoopMagic(icon, nil, {blendMode = "add"})
  magic:setAnchorPoint(0.5, 0.5)
  magic:setPosition(315, panel:getContentSize().height - 316)
  magic:setName("FireMagic")
  panel:addChild(magic, 1)
end
function AnniversaryXianDanDlg:setRemainTime(hourglass, isClosed)
  local panel = self:getControl("MoodPanel", nil, "StatePanel")
  local showText = string.format(CHS[2100343], math.ceil(hourglass / 60))
  if isClosed then
    showText = showText .. CHS[2200201]
  end
  self:setLabelText("Label3", showText, panel)
  self:setLabelText("Label4", showText, panel)
  self:setLabelText("Label5", showText, panel)
  self:setProgressBar("ProgressBar", hourglass / 60, 30, panel, COLOR3.GREEN)
end
function AnniversaryXianDanDlg:setNote(data)
  if data and not data.is_closed then
    self:setLabelText("Label1", CHS[2100344], "NotePanel")
    self:setLabelText("Label1", CHS[2100344], "NotePanel")
  else
    self:setLabelText("Label1", CHS[2100345], "NotePanel")
    self:setLabelText("Label1", CHS[2100345], "NotePanel")
  end
end
function AnniversaryXianDanDlg:setButtonState(data)
  local operatePanel = self:getControl("OperatePanel")
  local helpPanel = self:getControl("HelpPanel", nil, operatePanel)
  local helpTimesDesc = data.remain_help_times <= 0 and CHS[2100346] or string.format("%d/%d", data.remain_help_times, 3)
  self:setCtrlVisible("BKImage", data.remain_help_times > 0, helpPanel)
  self:setLabelText("Label1", helpTimesDesc, helpPanel)
  self:setLabelText("Label2", helpTimesDesc, helpPanel)
  self:setLabelText("Label3", helpTimesDesc, helpPanel)
  local supplyPanel = self:getControl("SupplyPanel", nil, operatePanel)
  local supplyTimesDesc = string.format("%d/%d", data.usable_liveness, 20)
  self:setLabelText("Label1", supplyTimesDesc, supplyPanel)
  self:setLabelText("Label2", supplyTimesDesc, supplyPanel)
  self:setLabelText("Label3", supplyTimesDesc, supplyPanel)
  local nimbusPanel = self:getControl("NimbusPanel", nil, operatePanel)
  local nimbusDesc = data.nimbus_type ~= 0 and CHS[2100347] or CHS[2100348]
  self:setLabelText("Label1", nimbusDesc, nimbusPanel)
  self:setLabelText("Label2", nimbusDesc, nimbusPanel)
  self:setLabelText("Label3", nimbusDesc, nimbusPanel)
  local bagPanel = self:getControl("BagPanel", nil, operatePanel)
  local bagDesc = self:getXdItemAmount(data)
  self:setLabelText("Label1", bagDesc, bagPanel)
  self:setLabelText("Label2", bagDesc, bagPanel)
  self:setLabelText("Label3", bagDesc, bagPanel)
end
function AnniversaryXianDanDlg:showNimbusFinger(...)
  local nimbusPanel = self:getControl("NimbusPanel", nil, "OperatePanel")
  local magic = nimbusPanel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    return
  end
  local info = ResMgr.ArmatureMagic.demoShowFinger
  magic = gf:createArmatureLoopMagic(info.name, info.action, nimbusPanel)
  magic:setTag(Const.ARMATURE_MAGIC_TAG)
end
function AnniversaryXianDanDlg:finishNimbusfinger()
  local nimbusPanel = self:getControl("NimbusPanel", nil, "OperatePanel")
  local magic = nimbusPanel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
end
function AnniversaryXianDanDlg:checkNimbusGuide(...)
  local data = (...)
  return self.guideState == 1 and data.nimbus_type == 0
end
function AnniversaryXianDanDlg:showFireFinger(...)
  local firePanel = self:getControl("SupplyPanel", nil, "OperatePanel")
  local magic = firePanel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    return
  end
  local info = ResMgr.ArmatureMagic.demoShowFinger
  magic = gf:createArmatureLoopMagic(info.name, info.action, firePanel)
  magic:setTag(Const.ARMATURE_MAGIC_TAG)
end
function AnniversaryXianDanDlg:finishFirefinger()
  local firePanel = self:getControl("SupplyPanel", nil, "OperatePanel")
  local magic = firePanel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
end
function AnniversaryXianDanDlg:checkFireGuide(...)
  local data = (...)
  return self.guideState == 2 and data.nimbus_type ~= 0
end
function AnniversaryXianDanDlg:showHelp(...)
  self:onNoteButton()
  self:playNextGuide(3, ...)
end
function AnniversaryXianDanDlg:checkHelpGuide(...)
  local data = (...)
  return self.guideState == 3 and data.nimbus_type ~= 0
end
function AnniversaryXianDanDlg:getXdItemAmount(data)
  if not data or not data.items then
    return 0
  end
  local amount = 0
  for i = 1, #data.items do
    amount = amount + data.items[i].num
  end
  return amount
end
function AnniversaryXianDanDlg:getXdName(xdType)
  if xdType == 1 then
    return CHS[2100349]
  elseif xdType == 2 then
    return CHS[2100350]
  elseif xdType == 3 then
    return CHS[2100351]
  elseif xdType == 4 then
    return CHS[2100352]
  end
end
function AnniversaryXianDanDlg:isOpenActivity()
  local data = AnniversaryMgr:getXdhxData()
  local curTime = gf:getServerTime()
  return curTime >= data.begin_time and curTime <= data.end_time
end
function AnniversaryXianDanDlg:showBagPanel()
  if not self:isOpenActivity() then
    gf:ShowSmallTips(CHS[2100368])
    return
  end
  local data = AnniversaryMgr:getXdhxData()
  self:setCtrlVisible("BagUsePanel", true)
  local items = {
    {item_type = 1, num = 0},
    {item_type = 2, num = 0},
    {item_type = 3, num = 0},
    {item_type = 4, num = 0}
  }
  if data and data.items then
    for i = 1, #data.items do
      items[data.items[i].item_type].num = data.items[i].num
    end
  end
  for i = 1, 4 do
    local panel = self:getControl("XianDPanel_" .. i, nil, "BagUsePanel")
    local item = items[i]
    if item then
      panel.item_type = item.item_type
      panel.item_num = item.num
      self:setCtrlVisible("ItemImage", true, panel)
      self:setCtrlVisible("shdowImage", true, panel)
      self:setImage("ItemImage", ResMgr:getIconPathByName(self:getXdName(item.item_type)), panel)
      self:setNumImgForPanel("NumPanel", ART_FONT_COLOR.NORMAL_TEXT, item.num, false, LOCATE_POSITION.RIGHT_BOTTOM, 21, panel)
      self:setImagePlist(panel, ResMgr.ui.bag_item_bg_img)
    else
      self:setCtrlVisible("ItemImage", false, panel)
      self:setCtrlVisible("shdowImage", false, panel)
      self:setNumImgForPanel("NumPanel", ART_FONT_COLOR.NORMAL_TEXT, "", false, LOCATE_POSITION.RIGHT_BOTTOM, 21, panel)
      self:setImagePlist(panel, ResMgr.ui.bag_no_item_bg_img)
    end
    if i == 1 and not self.chosenCtrl:getParent() then
      self:onClickXianD(panel)
    end
  end
end
function AnniversaryXianDanDlg:doChangeNimbus(nimbusType)
  local data = AnniversaryMgr:getXdhxData()
  if not data then
    return
  end
  if not self:isOpenActivity() then
    gf:ShowSmallTips(CHS[2200225])
    self:onCloseButton()
    return
  end
  if self.changingNimbus then
    gf:ShowSmallTips(CHS[2200204])
    return
  end
  self:playNextGuide(1, data)
  local nimbus_type = data.nimbus_type
  if nimbus_type == nimbusType then
    gf:ShowSmallTips(string.format(CHS[2200226], gf:getPolar(nimbusType)))
    return
  end
  gf:CmdToServer("CMD_ZNQ_2020_XDHX_SET_NIMBUS_TYPE", {nimbus_type = nimbusType})
  self:setCtrlVisible("NimbusSelectPanel")
  self.changingNimbus = self:isOpen() and 2 or 1
end
function AnniversaryXianDanDlg:onHelpButton(sender, eventType)
  local data = AnniversaryMgr:getXdhxData()
  if not data then
    return
  end
  if data.remain_help_times <= 0 then
    gf:ShowSmallTips(CHS[2200205])
    return
  end
  gf:CmdToServer("CMD_ZNQ_2020_XDHX_HELP_DATA_LIST")
end
function AnniversaryXianDanDlg:onSupplyButton(sender, eventType)
  local data = AnniversaryMgr:getXdhxData()
  if not data or not data.usable_liveness then
    return
  end
  if self.changingNimbus then
    gf:ShowSmallTips(CHS[2200213])
    return
  end
  gf:CmdToServer("CMD_ZNQ_2020_XDHX_ADD_FIRE_POINT")
  self:playNextGuide(2, data)
end
function AnniversaryXianDanDlg:onNimbusButton(sender, eventType)
  self:setCtrlVisible("NimbusSelectPanel", true)
end
function AnniversaryXianDanDlg:onBagButton(sender, eventType)
  self:showBagPanel()
end
function AnniversaryXianDanDlg:onNoteButton(sender, eventType)
  DlgMgr:openDlg("AnniversaryXianDanRuleDlg")
end
function AnniversaryXianDanDlg:onApplyButton(sender, eventType)
  local parent = self.chosenCtrl:getParent()
  if not parent then
    gf:ShowSmallTips(CHS[2100370])
    return
  end
  local itemType = parent.item_type
  if not parent.item_num or parent.item_num <= 0 then
    gf:ShowSmallTips(CHS[2200202])
    return
  end
  if Me:isInCombat() then
    gf:ShowSmallTips(CHS[2200212])
    return
  end
  gf:CmdToServer("CMD_ZNQ_2020_XDHX_APPLY_ITEM", {item_type = itemType})
end
function AnniversaryXianDanDlg:onClickMetalButton()
  self:doChangeNimbus(1)
end
function AnniversaryXianDanDlg:onClickWoodButton()
  self:doChangeNimbus(2)
end
function AnniversaryXianDanDlg:onClickWaterButton()
  self:doChangeNimbus(3)
end
function AnniversaryXianDanDlg:onClickFireButton()
  self:doChangeNimbus(4)
end
function AnniversaryXianDanDlg:onClickEarthButton()
  self:doChangeNimbus(5)
end
function AnniversaryXianDanDlg:MSG_ZNQ_2020_XDHX_DATA(data)
  self:refreshData()
  if self:getCtrlVisible("BagUsePanel") then
    self:showBagPanel()
  end
end
function AnniversaryXianDanDlg:onClickXianD(sender)
  local data = AnniversaryMgr:getXdhxData()
  local ctlName = sender:getName()
  local item_type = tonumber(string.match(ctlName, "XianDPanel_(%d+)"))
  self.chosenCtrl:removeFromParent()
  sender:addChild(self.chosenCtrl)
  local itemName = self:getXdName(item_type)
  local desc = InventoryMgr:getDescript(itemName)
  self:setLabelText("NameLabel", itemName, "BagUsePanel")
  self:setLabelText("DescLabel", desc, "BagUsePanel")
end
function AnniversaryXianDanDlg:onResume()
  gf:CmdToServer("CMD_ZNQ_2020_XDHX_DATA")
end
function AnniversaryXianDanDlg:MSG_ZNQ_2020_XDHX_CLOSE_DLG(data)
  self:onCloseButton()
end
return AnniversaryXianDanDlg
