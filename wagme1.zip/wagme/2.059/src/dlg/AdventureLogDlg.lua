local AdventureLogDlg = Singleton("AdventureLogDlg", Dialog)
local MAX_COUNT = 100
function AdventureLogDlg:init(para)
  self.unitLogPanel = self:retainCtrl("UnitLogPanel")
  self.layerCountPanel = self:retainCtrl("TitlePanel", "InfoPanel")
  local data = para == 2 and ActivityHelperMgr:getMyActMJSLLogData() or ActivityMgr:getMyAct2019kwdzLogData()
  self:setData(data)
end
function AdventureLogDlg:setData(data)
  if not data or not next(data) then
    self:setCtrlVisible("ListView", false)
    self:setCtrlVisible("NoticePanel", true)
    return
  else
    self:setCtrlVisible("ListView", true)
    self:setCtrlVisible("NoticePanel", false)
  end
  local list = self:resetListView("ListView")
  local count = 0
  for i = #data, 1, -1 do
    if count >= MAX_COUNT then
      return
    end
    count = count + 1
    local panel = self.unitLogPanel:clone()
    local str = gf:getServerDate("%H:%M", data[i].ti) .. "  " .. data[i].log
    self:setColorText(str, panel)
    list:pushBackCustomItem(panel)
    if data[i].isAddLayrt or i == 1 then
      local panel = self.layerCountPanel:clone()
      self:setLabelText("NumberLabel", string.format(CHS[4200633], data[i].layer), panel)
      list:pushBackCustomItem(panel)
    end
  end
end
return AdventureLogDlg
