local BlogMakeUpDlg = require("dlg/BlogMakeUpDlg")
local BlogMakeUpEXDlg = Singleton("BlogMakeUpEXDlg", BlogMakeUpDlg)
function BlogMakeUpEXDlg:getCfgFileName()
  return ResMgr:getDlgCfg("BlogMakeUpDlg")
end
function BlogMakeUpEXDlg:onCloseButton()
  local tabDlg = DlgMgr:getDlgByName("BlogEXTabDlg")
  if tabDlg then
    tabDlg:onCloseButton()
  end
  Dialog.onCloseButton(self)
end
return BlogMakeUpEXDlg
