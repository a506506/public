local TabDlg = require("dlg/TabDlg")
local AchievementTabDlg = Singleton("AchievementTabDlg", TabDlg)
AchievementTabDlg.dlgs = {
  AchievementDlgCheckBox = "AchievementListDlg",
  ServiceAchievementDlgCheckBox = "ServiceAchievementDlg"
}
return AchievementTabDlg
