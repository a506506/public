local ArenaRewardDlg = Singleton("ArenaRewardDlg", Dialog)
local CONST_DATA = {ListCellNumber = 20}
function ArenaRewardDlg:init()
  self:bindListViewListener("ContentListView", self.onSelectContentListView)
  self:bindListener("ConfirmButton", self.onConfirmButton)
  self.rewardPanel = self:getControl("RewardPanel1", Const.UIPanel)
  self.rewardPanel:retain()
  self.listView = self:getControl("ContentListView", Const.UIListView)
  self.listView:removeAllChildren()
  self.listView:setDirection(ccui.ListViewDirection.vertical)
  self:hookMsg("MSG_ARENA_TOP_BONUS_LIST")
  self:MSG_ARENA_TOP_BONUS_LIST()
end
function ArenaRewardDlg:cleanup()
  self:releaseCloneCtrl("rewardPanel")
end
function ArenaRewardDlg:MSG_ARENA_TOP_BONUS_LIST()
  self:initList()
end
function ArenaRewardDlg:initList()
  self.rewardList = ArenaMgr:getHighestRewardList()
  local highestRankLabel = self:getControl("HighestRankingAtlasLabel", Const.UIAtlasLabel)
  highestRankLabel:setString(self.rewardList.highestRank)
  self.listView:removeAllChildren()
  for i = 1, #self.rewardList do
    local cell = self.rewardPanel:clone()
    self:setcellInfo(cell, i)
    ccui.ListView.pushBackCustomItem(self.listView, cell)
  end
  local scrollNumber = self:getScrollToNumber(self.rewardList)
  performWithDelay(self.listView, function()
    local prencent = scrollNumber * self.rewardPanel:getContentSize().height / (self.listView:getInnerContainer():getContentSize().height - self.listView:getContentSize().height)
    if prencent > 1 then
      prencent = 1
    end
    self.listView:scrollToPercentVertical(100 * prencent, 0.5, true)
  end, 0.01)
end
function ArenaRewardDlg:getScrollToNumber(rewardList)
  local scrollToNumber = 1
  for i = 1, #rewardList do
    if rewardList[i].status ~= 2 then
      scrollToNumber = i
      break
    end
  end
  if scrollToNumber - 2 < 0 then
    return 0
  else
    return scrollToNumber - 2
  end
end
function ArenaRewardDlg:setcellInfo(cell, tag)
  local rankLabel = self:getControl("LimitLabel", Const.UILabel, cell)
  rankLabel:setString(string.format(CHS[6000131], self.rewardList[tag].rank))
  local rewardLabel = self:getControl("GoldLabel", Const.UILabel, cell)
  rewardLabel:setString(self.rewardList[tag].bonus)
  local getBtn = self:getControl("GetButton", Const.UIButton, cell)
  getBtn:setTag(tag)
  local gotBtn = self:getControl("GotButton", Const.UIButton, cell)
  local noBtn = self:getControl("NoButton", Const.UIButton, cell)
  self:bindListener("GetButton", self.onGetButton, cell)
  if self.rewardList[tag].status == 0 then
    getBtn:setVisible(false)
    noBtn:setVisible(true)
    gf:grayImageView(noBtn)
  elseif self.rewardList[tag].status == 1 then
    getBtn:setVisible(true)
    noBtn:setVisible(false)
  elseif self.rewardList[tag].status == 2 then
    getBtn:setVisible(false)
    gotBtn:setVisible(true)
    gf:grayImageView(gotBtn)
  end
end
function ArenaRewardDlg:onGetButton(sender, eventType)
  local tag = sender:getTag()
  ArenaMgr:getReward(self.rewardList[tag].rank)
end
function ArenaRewardDlg:onConfirmButton()
  DlgMgr:closeDlg(self.name)
end
function ArenaRewardDlg:onSelectContentListView(sender, eventType)
end
return ArenaRewardDlg
