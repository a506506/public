local DaluandousxqhDlg = Singleton("DaluandousxqhDlg", Dialog)
local PROP_LEVEL = {
  {prop = "+100%", cost = 3},
  {prop = "+120%", cost = 4},
  {prop = "+150%", cost = 5},
  {prop = "+200%", cost = 6},
  {prop = "+250%", cost = 7},
  {prop = "+300%", cost = 8},
  {prop = "+350%", cost = 9},
  {prop = "+400%", cost = 0}
}
function DaluandousxqhDlg:init()
  self:bindListener("BuyButton", self.onBuyButton)
  self:setData()
end
function DaluandousxqhDlg:setData()
  local myData = DlgMgr:sendMsg("DaluandouzjmDlg", "getMyData")
  local phyPowerPanel = self:getControl("PhyPowerPanel")
  local magPowerPanel = self:getControl("MagPowerPanel")
  self.upgradeLevel = myData.upgrade_prop_lv
  self.point = myData.point
  if myData.upgrade_prop_lv >= #PROP_LEVEL - 1 then
    self:setCtrlVisible("DoneImage", true)
    self:setCtrlVisible("BuyButton", false)
    self:setCtrlVisible("CostPanel", false)
    self:setCtrlVisible("NumLabel_1", false, phyPowerPanel)
    self:setCtrlVisible("Image", false, phyPowerPanel)
    self:setLabelText("NumLabel_2", string.format(CHS[7100759], myData.upgrade_prop_lv), phyPowerPanel)
    self:setCtrlVisible("NumLabel_1", false, magPowerPanel)
    self:setCtrlVisible("Image", false, magPowerPanel)
    if PROP_LEVEL[myData.upgrade_prop_lv + 1] then
      self:setLabelText("NumLabel_2", PROP_LEVEL[myData.upgrade_prop_lv + 1].prop, magPowerPanel)
    else
      self:setLabelText("NumLabel_2", "+400%", magPowerPanel)
    end
  else
    self:setCtrlVisible("DoneImage", false)
    self:setCtrlVisible("BuyButton", true)
    self:setCtrlVisible("CostPanel", true)
    if PROP_LEVEL[myData.upgrade_prop_lv + 1] then
      self:setLabelText("ScoreLabel", string.format("%d/%d", myData.point, PROP_LEVEL[myData.upgrade_prop_lv + 1].cost))
    else
      self:setLabelText("ScoreLabel", string.format("%d/%d", myData.point, 0))
    end
    self:setCtrlVisible("NumLabel_1", true, phyPowerPanel)
    self:setCtrlVisible("Image", true, phyPowerPanel)
    self:setLabelText("NumLabel_1", string.format(CHS[7100759], myData.upgrade_prop_lv), phyPowerPanel)
    self:setLabelText("NumLabel_2", string.format(CHS[7100759], myData.upgrade_prop_lv + 1), phyPowerPanel)
    self:setCtrlVisible("NumLabel_1", true, magPowerPanel)
    self:setCtrlVisible("Image", true, magPowerPanel)
    if PROP_LEVEL[myData.upgrade_prop_lv + 1] then
      self:setLabelText("NumLabel_1", PROP_LEVEL[myData.upgrade_prop_lv + 1].prop, magPowerPanel)
    else
      self:setLabelText("NumLabel_1", "+400%", magPowerPanel)
    end
    if PROP_LEVEL[myData.upgrade_prop_lv + 2] then
      self:setLabelText("NumLabel_2", PROP_LEVEL[myData.upgrade_prop_lv + 2].prop, magPowerPanel)
    else
      self:setLabelText("NumLabel_2", "+400%", magPowerPanel)
    end
  end
end
function DaluandousxqhDlg:onBuyButton(sender, eventType)
  if Me:isInCombat() then
    gf:ShowSmallTips(CHS[7100478])
    return
  end
  if self.upgradeLevel >= #PROP_LEVEL - 1 then
    gf:ShowSmallTips(CHS[7100748])
    return
  end
  if self.point < PROP_LEVEL[self.upgradeLevel + 1].cost then
    gf:ShowSmallTips(CHS[7100749])
    return
  end
  gf:CmdToServer("CMD_FFA_UPGRADE_PROP_LEVEL", {
    level = self.upgradeLevel
  })
end
return DaluandousxqhDlg
