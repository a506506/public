local Bitset = require("core/Bitset")
local FloatingMenuDlg = Singleton("FloatingMenuDlg", Dialog)
local RIGHT_CTRL = {
  [1] = "",
  [2] = "",
  [4] = ""
}
local Margin = 3
local btnStrTable = {
  [1] = {
    title = CHS[3002632],
    key = "chat"
  },
  [2] = {
    title = CHS[3002633],
    key = "addFriend"
  },
  [3] = {
    title = CHS[3002634],
    key = "seeEquip"
  },
  [4] = {
    title = CHS[5400270],
    key = "openBlog"
  },
  [5] = {
    title = CHS[4100069],
    key = "changeCard"
  },
  [6] = {
    title = CHS[4200378],
    key = "jiuqu"
  },
  [7] = {
    title = CHS[3002635],
    key = "leadTeam"
  },
  [8] = {
    title = CHS[3002636],
    key = "callTeam"
  },
  [9] = {
    title = CHS[3002637],
    key = "changeLeader"
  },
  [10] = {
    title = CHS[3002638],
    key = "leaveTeam"
  },
  [11] = {
    title = CHS[6400093],
    key = "sendNotify"
  },
  [12] = {
    title = CHS[7003021],
    key = "callAll"
  },
  [13] = {
    title = CHS[7190423],
    key = "commander"
  },
  [14] = {
    title = CHS[4101809],
    key = "assess"
  }
}
local BUTTON_STR_COUNT = #btnStrTable
local MEMBER_ORDER = {
  chat = 6,
  addFriend = 8,
  seeEquip = 5,
  openBlog = 9,
  changeCard = 4,
  jiuqu = 7,
  leadTeam = 100,
  callTeam = 100,
  changeLeader = 1,
  leaveTeam = 2,
  sendNotify = 3,
  callAll = 100,
  cancelCommander = 100,
  setCommander = 100,
  assess = 10
}
local MEMBEREX_ORDER = {
  chat = 4,
  addFriend = 6,
  seeEquip = 5,
  openBlog = 7,
  changeCard = 100,
  jiuqu = 100,
  leadTeam = 100,
  callTeam = 1,
  changeLeader = 100,
  leaveTeam = 2,
  sendNotify = 3,
  callAll = 100,
  cancelCommander = 100,
  setCommander = 100
}
local LEADER_ORDER = {
  chat = 3,
  addFriend = 7,
  seeEquip = 4,
  openBlog = 8,
  changeCard = 5,
  jiuqu = 6,
  leadTeam = 1,
  callTeam = 100,
  changeLeader = 100,
  leaveTeam = 100,
  sendNotify = 2,
  callAll = 100,
  cancelCommander = 100,
  setCommander = 100,
  assess = 9
}
local max_button_num = 10
local firendTag = 998
local MAX_SHOW_NUM = 5
local MAX_SHOW_HEIGHT = 360
FloatingMenuDlg.dlgSize = nil
FloatingMenuDlg.mainPanelSize = nil
function FloatingMenuDlg:init()
  self.dlgSize = self.dlgSize or self.root:getContentSize()
  local mainPanel = self:getControl("MainPanel")
  self.mainPanelSize = self.mainPanelSize or mainPanel:getContentSize()
  self.curChar = nil
  self.listView = self:getControl("ListView")
  self.menuButton = self:retainCtrl("MenuButton1")
  self:bindTouchEndEventListener(self.menuButton, self.onMenuButton)
  for i = 2, max_button_num do
    local btn = self:getControl("MenuButton" .. i)
    if btn then
      btn:removeFromParent()
    end
  end
  self:hookMsg("MSG_LOOK_PLAYER_EQUIP")
  self:hookMsg("MSG_CHAR_INFO")
end
function FloatingMenuDlg:setData(member)
  if nil == member then
    return
  end
  self.member = member
  local btnList = self:getBtnListStr(member)
  local btnCount = #btnList
  local btnContentSize = self.menuButton:getContentSize()
  local btnStr = "MenuButton"
  for i = 1, btnCount do
    local btn = self.menuButton:clone()
    btn:setTitleText(btnList[i].title)
    btn:setName(btnList[i].key)
    self.listView:pushBackCustomItem(btn)
  end
  local height = (btnContentSize.height + Margin) * (max_button_num - btnCount)
  local width = self.root:getContentSize().width
  local panel = self:getControl("MainPanel")
  panel:setContentSize({
    width = panel:getContentSize().width,
    height = math.min(self.mainPanelSize.height - height, MAX_SHOW_HEIGHT)
  })
  self.root:setContentSize({
    width = width,
    height = math.min(self.dlgSize.height - height, MAX_SHOW_HEIGHT)
  })
  if btnCount <= MAX_SHOW_NUM then
    self.listView:setBounceEnabled(false)
  end
  FriendMgr:requestCharMenuInfo(member.gid)
  if FriendMgr:hasFriend(member.gid) then
    self:setButtonText("addFriend", CHS[5000062])
  else
    self:setButtonText("addFriend", CHS[5000064])
  end
end
function FloatingMenuDlg:getBtnListStr(member)
  local isLeader = TeamMgr:getLeaderId() == Me:queryBasicInt("id")
  local btnList = {}
  if isLeader and self.member.id == Me:getId() then
    table.insert(btnList, btnStrTable[12])
    return btnList
  end
  for i = 1, BUTTON_STR_COUNT do
    if not isLeader then
      if i < 5 then
        table.insert(btnList, btnStrTable[i])
      elseif btnStrTable[i].title == CHS[4200378] or btnStrTable[i].title == CHS[4100069] then
        if not TeamMgr:isLeaveTemp(self.member.id) and not TeamMgr:isOverlineLeaveTemp(self.member.id) and not TeamMgr:isLeaveTemp(Me:getId()) and not TeamMgr:isOverlineLeaveTemp(Me:getId()) then
          table.insert(btnList, btnStrTable[i])
        end
      elseif btnStrTable[i].title == CHS[3002635] and self.member.id == TeamMgr:getLeaderId() then
        table.insert(btnList, btnStrTable[i])
      elseif btnStrTable[i].title == CHS[6400093] and gf:gfIsFuncEnabled(FUNCTION_ID.VIBRATE) then
        table.insert(btnList, btnStrTable[i])
      elseif btnStrTable[i].title == CHS[4101809] then
        table.insert(btnList, btnStrTable[i])
      end
    elseif btnStrTable[i].title == CHS[3002635] then
    elseif btnStrTable[i].title == CHS[6400093] then
      if gf:gfIsFuncEnabled(FUNCTION_ID.VIBRATE) then
        table.insert(btnList, btnStrTable[i])
      end
    elseif TeamMgr:isLeaveTemp(self.member.id) or TeamMgr:isOverlineLeaveTemp(self.member.id) then
      if btnStrTable[i].title ~= CHS[3002637] and btnStrTable[i].title ~= CHS[4200378] and btnStrTable[i].title ~= CHS[4100069] and btnStrTable[i].title ~= CHS[7190423] and btnStrTable[i].title ~= CHS[7003021] then
        table.insert(btnList, btnStrTable[i])
      end
    elseif btnStrTable[i].title == CHS[7190423] then
      if FightCommanderCmdMgr:isCommanderFuncOpen() then
        if FightCommanderCmdMgr:isCommander(self.member.gid) then
          table.insert(btnList, {
            title = CHS[7190419],
            key = "cancelCommander"
          })
        else
          table.insert(btnList, {
            title = CHS[7190422],
            key = "setCommander"
          })
        end
      end
    elseif btnStrTable[i].title == CHS[4101809] then
      table.insert(btnList, btnStrTable[i])
    elseif i ~= 12 and btnStrTable[i].title ~= CHS[3002636] then
      table.insert(btnList, btnStrTable[i])
    end
  end
  local zorder
  if Me:isTeamLeader() then
    if TeamMgr:isLeaveTemp(self.member.id) or TeamMgr:isOverlineLeaveTemp(self.member.id) then
      zorder = MEMBEREX_ORDER
    else
      zorder = MEMBER_ORDER
    end
  else
    zorder = LEADER_ORDER
  end
  if zorder then
    table.sort(btnList, function(l, r)
      if not zorder[l.key] then
        return false
      end
      if not zorder[r.key] then
        return true
      end
      if zorder[l.key] < zorder[r.key] then
        return true
      end
    end)
  end
  return btnList
end
function FloatingMenuDlg:setIndex(idx, boundingBox)
  self:setCtrlVisible("PointImage_0", false)
  local worldPos
  if idx < 3 then
    self.root:setAnchorPoint(0, 1)
    worldPos = cc.p(boundingBox.x + boundingBox.width, boundingBox.y + boundingBox.height / 2)
  else
    self.root:setAnchorPoint(1, 1)
    worldPos = cc.p(boundingBox.x, boundingBox.y + boundingBox.height / 2)
  end
  self.root:setPosition(self.root:getParent():convertToNodeSpace(worldPos))
  local mainPanelBoundingBox = self:getBoundingBoxInWorldSpace(self:getControl("MainPanel"))
  local curPos = self.root:convertToWorldSpace(cc.p(0, 0))
  if curPos.y < mainPanelBoundingBox.height then
    local pos
    if mainPanelBoundingBox.height + 20 <= self:getWinSize().height then
      pos = self.root:getParent():convertToNodeSpace(cc.p(self.root:getPositionX(), mainPanelBoundingBox.height + 20))
    else
      pos = self.root:getParent():convertToNodeSpace(cc.p(self.root:getPositionX(), self:getWinSize().height))
    end
    self.root:setPositionY(pos.y)
  end
end
function FloatingMenuDlg:adjustPos(touchRect, starRect)
  self:setCtrlVisible("PointImage_0", true)
  local pointImage = self:getControl("PointImage_0")
  local rootBoundingBox = self:getBoundingBoxInWorldSpace(self.root)
  local pointImgBoundingBox = self:getBoundingBoxInWorldSpace(pointImage)
  self.root:setAnchorPoint(0.5, 0.5)
  local ccp = {
    x = starRect.x - rootBoundingBox.width * 0.5 - pointImgBoundingBox.width,
    y = starRect.y - rootBoundingBox.height * 0.5 + starRect.height
  }
  if ccp.y < rootBoundingBox.height * 0.5 + self:getWinSize().oy then
    local targetY = rootBoundingBox.height / 2 + 25 + self:getWinSize().oy
    if rootBoundingBox.height + 25 + self:getWinSize().oy > self:getWinSize().height then
      ccp.y = self:getWinSize().height - rootBoundingBox.height / 2
    else
      ccp.y = targetY
    end
  end
  ccp = self.root:getParent():convertToNodeSpace(ccp)
  self.root:setPosition(ccp)
  local pt = self.root:convertToNodeSpace(cc.p(touchRect.x, touchRect.y + touchRect.height / 2))
  pointImage:setPositionY(pt.y)
end
function FloatingMenuDlg:onMenuButton1(sender, eventType)
  FriendMgr:communicat(self.member.name, self.member.gid, self.member.icon, self.member.level)
  DlgMgr:closeDlg(self.name)
end
function FloatingMenuDlg:onMenuButton2(sender, eventType)
  if not self.curChar or not self.curChar.name then
    return
  end
  local name = self.curChar.name
  if FriendMgr:hasFriend(self.curChar.gid) then
    local str = string.format(CHS[5000060], gf:getRealName(name))
    gf:confirm(str, function()
      FriendMgr:deleteFriend(name, self.curChar.gid)
    end)
  else
    FriendMgr:addFriend(name)
  end
  DlgMgr:closeDlg(self.name)
end
function FloatingMenuDlg:onMenuButton3(sender, eventType)
  gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_LOOK_PLAYER_EQUIP, self.member.gid)
end
function FloatingMenuDlg:onMenuButton4(sender, eventType)
  if not Me:isTeamLeader() or not TeamMgr.selectMember then
    return
  end
  local member = TeamMgr.selectMember
  gf:CmdToServer("CMD_OPER_TELEPORT_ITEM", {
    oper = Const.TRY_RECRUIT,
    id = member.id,
    para2 = member.gid
  })
  DlgMgr:closeDlg(self.name)
end
function FloatingMenuDlg:onMenuButton5(sender, eventType)
  if Me:isPassiveMode() or not Me:isTeamLeader() or self.member == nil then
    return
  end
  local member = self.member
  if member == nil then
    return
  end
  local name = member.name
  if name == Me:getName() then
    return
  end
  if Me:isLookOn() then
    gf:ShowSmallTips(CHS[3002640])
    return
  end
  if TaskMgr:isInTaskBKTX(6) then
    gf:ShowSmallTips(CHS[4010228])
    return
  end
  local function onConfirm()
    gf:CmdToServer("CMD_CHANGE_TEAM_LEADER", {
      new_leader_id = member.id
    })
  end
  local tip = string.format(CHS[1003780], gf:getRealName(name))
  gf:confirm(tip, onConfirm)
  DlgMgr:closeDlg(self.name)
end
function FloatingMenuDlg:onMenuButton6(sender, eventType)
  if Me:isPassiveMode() or not Me:isTeamLeader() or self.member == nil then
    return
  end
  local member = self.member
  if member == nil then
    return
  end
  local name = member.name
  if name == Me:getName() then
    return
  end
  gf:confirm(string.format(CHS[6800001], gf:getRealName(name)), function()
    gf:CmdToServer("CMD_KICKOUT", {peer_name = name})
  end)
  DlgMgr:closeDlg(self.name)
end
function FloatingMenuDlg:requireTobeLeader(sender, eventType)
  local myId = Me:getId()
  if TeamMgr:inTeamEx(myId) and not TeamMgr:inTeam(myId) then
    gf:ShowSmallTips(CHS[3002641])
    return
  elseif Me:isLookOn() then
    gf:ShowSmallTips(CHS[3002640])
    return
  end
  gf:CmdToServer("CMD_REQUEST_JOIN", {
    peer_name = self.member.name,
    ask_type = Const.REQUEST_TEAM_LEADER
  })
  DlgMgr:closeDlg(self.name)
end
function FloatingMenuDlg:onMenuButton(sender, eventType)
  local name = sender:getName()
  if name == "chat" then
    self:onMenuButton1(sender, eventType)
  elseif name == "addFriend" then
    self:onMenuButton2(sender, eventType)
  elseif name == "seeEquip" then
    self:onMenuButton3(sender, eventType)
  elseif name == "leadTeam" then
    self:requireTobeLeader(sender, eventType)
  elseif name == "callTeam" then
    self:onMenuButton4(sender, eventType)
  elseif name == "changeLeader" then
    self:onMenuButton5(sender, eventType)
  elseif name == "leaveTeam" then
    self:onMenuButton6(sender, eventType)
  elseif name == "changeCard" then
    self:onChangeCard(sender, eventType)
  elseif name == "sendNotify" then
    self:onSendNotify(sender, eventType)
  elseif name == "callAll" then
    self:onCallAll(sender, eventType)
  elseif name == "jiuqu" then
    self:onJiuqu(sender, eventType)
  elseif name == "openBlog" then
    self:onOpenBlog()
  elseif name == "cancelCommander" then
    FightCommanderCmdMgr:requestSetCommander(self.member.gid, 0)
    self:onCloseButton()
  elseif name == "setCommander" then
    FightCommanderCmdMgr:requestSetCommander(self.member.gid, 1)
    self:onCloseButton()
  elseif name == "assess" then
    self:onAssessTeam(self.member.gid)
  end
end
function FloatingMenuDlg:onAssessTeam(gid)
  gf:CmdToServer("CMD_TEAM_ASSESS_INFO", {gid = gid})
end
function FloatingMenuDlg:onJiuqu(sender, eventType)
  if Me:isInCombat() then
    gf:ShowSmallTips(CHS[3003759])
    self:onCloseButton()
    return
  end
  if TeamMgr:isLeaveTemp(Me:getId()) then
    gf:ShowSmallTips(CHS[4000398])
    return
  end
  if TeamMgr:isLeaveTemp(self.member.id) then
    gf:ShowSmallTips(CHS[4000399])
    return
  end
  if TeamMgr:isOverlineLeaveTemp(Me:getId()) then
    gf:ShowSmallTips(CHS[4000398])
    return
  end
  if TeamMgr:isOverlineLeaveTemp(self.member.id) then
    gf:ShowSmallTips(CHS[4000399])
    return
  end
  local amount = InventoryMgr:getAmountByName(CHS[4200378])
  local amount2 = InventoryMgr:getAmountByName(CHS[4300795])
  if amount + amount2 <= 0 then
    gf:ShowSmallTips(CHS[4200379])
    return
  end
  local dlg = DlgMgr:openDlg("ShapePenDlg")
  dlg:setListData(self.member)
  local rect = self:getBoundingBoxInWorldSpace(self.root)
  dlg:setPositionByRect(rect)
end
function FloatingMenuDlg:onCallAll(sender, eventType)
  TeamMgr:callAll()
  self:close()
end
function FloatingMenuDlg:onChangeCard(sender, eventType)
  if TeamMgr:isLeaveTemp(Me:getId()) then
    gf:ShowSmallTips(CHS[4000398])
    return
  end
  if TeamMgr:isLeaveTemp(self.member.id) then
    gf:ShowSmallTips(CHS[4000399])
    return
  end
  if TeamMgr:isOverlineLeaveTemp(Me:getId()) then
    gf:ShowSmallTips(CHS[4000398])
    return
  end
  if TeamMgr:isOverlineLeaveTemp(self.member.id) then
    gf:ShowSmallTips(CHS[4000399])
    return
  end
  local cardTao = StoreMgr:getChangeCard()
  local cardBag = InventoryMgr:getChangeCard()
  if #cardTao + #cardBag == 0 then
    gf:ShowSmallTips(CHS[4200380])
    return
  end
  local dlg = DlgMgr:openDlg("TeamChangeCardMenuDlg")
  dlg:setPlayer(self.member)
  local rect = self:getBoundingBoxInWorldSpace(self.root)
  dlg:setPositionByRect(rect)
end
function FloatingMenuDlg:onOpenBlog()
  BlogMgr:openBlog(self.member.gid)
  self:onCloseButton()
end
function FloatingMenuDlg:MSG_LOOK_PLAYER_EQUIP(data)
  self:onCloseButton()
end
function FloatingMenuDlg:onSendNotify()
  VibrateMgr:sendVibrate("team", self.member.gid)
end
function FloatingMenuDlg:MSG_CHAR_INFO(data)
  self.curChar = data
  self.curChar.settingFlag = Bitset.new(data.setting_flag)
  self.curChar.charStatus = Bitset.new(data.char_status)
end
return FloatingMenuDlg
