local ActivitiesWeekCalendarDlg = Singleton("ActivitiesWeekCalendarDlg", Dialog)
local DAY_LIST = {
  [1] = "Day7ListPanel",
  [2] = "Day1ListPanel",
  [3] = "Day2ListPanel",
  [4] = "Day3ListPanel",
  [5] = "Day4ListPanel",
  [6] = "Day5ListPanel",
  [7] = "Day6ListPanel"
}
function ActivitiesWeekCalendarDlg:init()
  for i = 1, 5 do
    local dayPanelName = string.format("Everyday%dListPanel", i)
    self:bindListener(dayPanelName, self.onClickEveryDayListPanel)
  end
  self.cell = self:getControl("ListUnitMidPanel", nil, "Day1ListPanel"):clone()
  self.cell:retain()
  self:setSelectEffect()
  self:setEveryDayList()
  self:setWeekDayList()
end
function ActivitiesWeekCalendarDlg:setSelectEffect()
  local time = gf:getServerTime()
  local day = gf:getServerDate("*t", time).wday
  self:setCtrlVisible("FrameImage1", false, DAY_LIST[day])
  self:setCtrlVisible("FrameImage2", true, DAY_LIST[day])
  self:setCtrlVisible("SelectedImage", true, "Day" .. day - 1 .. "Panel")
end
function ActivitiesWeekCalendarDlg:sortData(data)
  table.sort(data, function(l, r)
    local lHour, lMin, lHour2, lMin2 = string.match(l.activityTime[1][1], "(%d+):(%d+)-(%d+):(%d+)")
    local rHour, rMin, rHour2, rMin2 = string.match(r.activityTime[1][1], "(%d+):(%d+)-(%d+):(%d+)")
    if lHour < rHour then
      return false
    end
    if lHour > rHour then
      return true
    end
    if lMin < rMin then
      return false
    end
    if lMin > rMin then
      return true
    end
    if lHour2 < rHour2 then
      return false
    end
    if lHour2 > rHour2 then
      return true
    end
    if lMin2 < rMin2 then
      return false
    end
    if lMin2 > rMin2 then
      return true
    end
  end)
end
function ActivitiesWeekCalendarDlg:setEveryDayList()
  local everyDayLimitActivity = {}
  local limitActivity = ActivityMgr:getLimitActivity(true)
  for k, v in pairs(limitActivity) do
    if v.actitiveDate == "0" then
      local activityTime = v.activityTime
      for i = 1, #activityTime do
        table.insert(everyDayLimitActivity, {
          name = v.name,
          show_name = v.short_name or v.name,
          activityTime = {
            v.activityTime[i]
          },
          order = v.index
        })
      end
    end
  end
  self:sortData(everyDayLimitActivity)
  for i = 1, 5 do
    local dayPanelName = string.format("Everyday%dListPanel", i)
    local index = #everyDayLimitActivity - i + 1
    self:setLabelText("NameLabel", everyDayLimitActivity[index] and everyDayLimitActivity[index].show_name or "", dayPanelName)
    self:getControl(dayPanelName).cellData = everyDayLimitActivity[index]
  end
end
function ActivitiesWeekCalendarDlg:setWeekDayList()
  for i = 1, 7 do
    local wdayData = {}
    local limitActivity = ActivityMgr:getLimitActivity(true)
    for k, v in pairs(limitActivity) do
      if self:isWdayActivity(i, v) then
        local activityTime = v.activityTime
        for j = 1, #activityTime do
          table.insert(wdayData, {
            name = v.name,
            show_name = v.short_name or v.name,
            activityTime = {
              v.activityTime[j]
            },
            order = v.index
          })
        end
      end
    end
    self:sortData(wdayData)
    self:setListView(wdayData, DAY_LIST[i])
  end
end
function ActivitiesWeekCalendarDlg:setListView(data, panel)
  local listPanel = self:getControl("ListScrollView", nil, panel)
  listPanel:removeAllChildren()
  local contentLayer = ccui.Layout:create()
  for i = 1, #data do
    do
      local cell = self.cell:clone()
      local cellData = data[i]
      self:setLabelText("NameLabel", cellData.show_name, cell)
      local num = #cellData.activityTime
      local timePanelName = num .. "TimesPanel"
      self:setCtrlVisible(timePanelName, true, cell)
      for j = 1, num do
        local timeStr = string.match(cellData.activityTime[j][1], "(%d+:%d+-%d+:%d+)")
        self:setLabelText("TimeLabel" .. j, timeStr, self:getControl(timePanelName, nil, cell))
      end
      cell:setPosition(0, (i - 1) * cell:getContentSize().height)
      cell:setTag(i)
      local touchPanel = self:getControl("BackImage", nil, cell)
      touchPanel:setTouchEnabled(true)
      local function touch(sender, eventType)
        if ccui.TouchEventType.ended == eventType then
          local dlg = DlgMgr:openDlg("ActivitiesInfoFFDlg")
          local info = ActivityMgr:getLimitActivityDataByName(cellData.name)
          dlg:setData(info, false)
        end
      end
      touchPanel:addTouchEventListener(touch)
      contentLayer:addChild(cell)
    end
  end
  local totalHeight = #data * self.cell:getContentSize().height
  contentLayer:setContentSize(listPanel:getContentSize().width, totalHeight)
  listPanel:setTouchEnabled(true)
  listPanel:setClippingEnabled(true)
  listPanel:setBounceEnabled(true)
  listPanel:addChild(contentLayer)
  listPanel:setInnerContainerSize(contentLayer:getContentSize())
end
function ActivitiesWeekCalendarDlg:isWdayActivity(wday, data)
  local isWdayActivity = false
  local dayStr = string.match(data.actitiveDate, ":(.+)") or data.actitiveDate
  local weekDayList = gf:split(dayStr, ",")
  for i = 1, #weekDayList do
    if wday == tonumber(weekDayList[i]) then
      isWdayActivity = true
      break
    end
  end
  return isWdayActivity
end
function ActivitiesWeekCalendarDlg:cleanup()
  self:releaseCloneCtrl("cell")
end
function ActivitiesWeekCalendarDlg:onClickEveryDayListPanel(sender)
  local cellData = sender.cellData
  if not cellData then
    return
  end
  local dlg = DlgMgr:openDlg("ActivitiesInfoFFDlg")
  local info = ActivityMgr:getLimitActivityDataByName(cellData.name)
  dlg:setData(info, false)
end
return ActivitiesWeekCalendarDlg
