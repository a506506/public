local ActivitiesInfoFFDlg = Singleton("ActivitiesInfoFFDlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
local json = require("json")
local SPACE = 10
local WordWidth = 200
function ActivitiesInfoFFDlg:init()
  self:bindListener("ActivitiesInfoFFPanel", self.onCloseButton)
end
function ActivitiesInfoFFDlg:getStartTimeByMainType(mainType)
  local activityTime = ActivityMgr:getActivityStartTimeByMainType(mainType)
  return activityTime.startTime
end
function ActivitiesInfoFFDlg:setData(data, isReward)
  local name = data.name
  if data.showName then
    name = data.showName
  end
  if string.match(name, "Month") then
    local activityStartTime = self:getStartTimeByMainType(data.mainType)
    local m = tonumber(gf:getServerDate("%m", activityStartTime - Const.FIVE_HOURS))
    local newActName = string.gsub(name, "Month", gf:changeNumber(m))
    self:setLabelText("NameLabel", newActName)
  else
    self:setLabelText("NameLabel", name)
  end
  local timeStr = ""
  for i = 1, #data.activityTime do
    if timeStr == "" then
      timeStr = data.activityTime[i][1]
    else
      timeStr = timeStr .. CHS[3002231] .. data.activityTime[i][1]
    end
  end
  if name == CHS[4200511] then
    self:setLabelText("TimeLabel2", CHS[4300370])
  elseif name == CHS[7100750] then
    self:setLabelText("TimeLabel2", CHS[7100751])
  else
    self:setLabelText("TimeLabel2", timeStr)
  end
  self:setLabelText("TeamLabel2", data.team)
  local descStr = data.desc
  if data.newDesc then
    if data.effectTime and not DistMgr:curIsTestDist() and gf:getServerTime() >= data.effectTime then
      descStr = data.newDesc
    elseif data.effectTimeTest and DistMgr:curIsTestDist() and gf:getServerTime() >= data.effectTimeTest then
      descStr = data.newDesc
    end
  elseif DistMgr:curIsTestDist() and data.testDistDesc then
    descStr = data.testDistDesc
  elseif data.name == CHS[6400081] then
    descStr = string.format(data.desc, ActivityMgr:get_level_add_exp_precent())
  elseif data.name == CHS[6200075] then
    local lineNumStr = ActivityMgr:getActivityExtraInfo("quanfu_hongbao")
    if GameMgr:getTotalLieNum() and GameMgr:getTotalLieNum() > 6 and not string.isNilOrEmpty(lineNumStr) then
      descStr = string.format(CHS[7150129], tonumber(lineNumStr))
    else
      descStr = CHS[6200093]
    end
  elseif data.name == CHS[4100285] then
    local taskName = ""
    local acts = ActivityMgr.doubleActvies[data.name]
    if not next(acts) then
      taskName = CHS[3004424]
    else
      taskName = CHS[4200180]
      local i = 1
      for name, _ in pairs(acts) do
        if i == 1 then
          taskName = taskName .. name
        else
          taskName = taskName .. "、" .. name
        end
        i = i + 1
      end
    end
    descStr = string.format(data.desc, taskName)
  elseif data.name == CHS[4100704] then
    local info = json.decode(ActivityMgr.activityInfoEx.activityList.cs_league_100.para)
    descStr = string.format(descStr, math.floor(info.tao_rate / 100))
  end
  if data.name == CHS[7002150] then
    local endTime = string.match(data.activityTime[1][1], ".*-(.*)")
    descStr = string.format(data.desc, GameMgr:getDistName(), endTime)
  end
  if data.name == CHS[4300236] then
    local activityStartTime = self:getStartTimeByMainType(data.mainType)
    local m = tonumber(gf:getServerDate("%m", activityStartTime - Const.FIVE_HOURS))
    descStr = string.gsub(descStr, "Month", gf:changeNumber(m))
  elseif data.name == CHS[4300244] then
    local endTime = string.match(data.activityTime[1][1], ".*-(.*)")
    descStr = string.format(descStr, endTime)
  end
  local reward = data.reward
  local level = data.level
  if DistMgr:curIsTestDist() and data.testLevel then
    level = data.testLevel
  end
  if data.name == CHS[5420168] then
    if ActivityMgr.activityInfoEx and ActivityMgr.activityInfoEx.activityList and ActivityMgr.activityInfoEx.activityList.welcome_draw and ActivityMgr.activityInfoEx.activityList.welcome_draw.para ~= "" then
      local info = json.decode(ActivityMgr.activityInfoEx.activityList.welcome_draw.para)
      reward = info.reward
      descStr = string.format(descStr, info.condition)
      if info.condition == CHS[5420198] then
        level = 50
      end
    end
  elseif data.name == CHS[3000713] or data.name == CHS[7100750] then
    descStr = string.format(descStr, math.min(ActivityMgr:getActivityCurDayTimes(data.name), ActivityMgr:getActivityWeekCanRewardDays(data.name)))
  end
  self:setColorText(descStr, "InfoPanel2", nil, 0, 0, COLOR3.WHITE)
  self:setLabelText("LevelLabel2", string.format(CHS[7004001], level))
  if DistMgr:isTestDist(GameMgr:getDistName()) and data.testDistReward then
    reward = data.testDistReward
  end
  local rewardPanel = self:getControl("RewardItemsPanel")
  rewardPanel:removeAllChildren(true)
  local rewardContainer = RewardContainer.new(reward, rewardPanel:getContentSize(), nil, nil, true)
  rewardContainer:setAnchorPoint(0, 0.5)
  rewardContainer:setPosition(0, rewardPanel:getContentSize().height / 2)
  rewardPanel:addChild(rewardContainer)
end
function ActivitiesInfoFFDlg:setFullData(data, isReward)
  self:setLabelText("NameLabel", data.name)
  self:setLabelText("TimeLabel2", data.time)
  self:setLabelText("LevelLabel2", data.level)
  self:setLabelText("TeamLabel2", data.team)
  self:setColorText(data.desc, "InfoPanel2", nil, 0, 0, COLOR3.WHITE)
  local rewardPanel = self:getControl("RewardItemsPanel")
  rewardPanel:removeAllChildren(true)
  local reward
  if DistMgr:isTestDist(GameMgr:getDistName()) and data.testDistReward then
    reward = data.testDistReward
  else
    reward = data.reward
  end
  local rewardContainer = RewardContainer.new(reward, rewardPanel:getContentSize(), nil, nil, true)
  rewardContainer:setAnchorPoint(0, 0.5)
  rewardContainer:setPosition(0, rewardPanel:getContentSize().height / 2)
  rewardPanel:addChild(rewardContainer)
end
return ActivitiesInfoFFDlg
