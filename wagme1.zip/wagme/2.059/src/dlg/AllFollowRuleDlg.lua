local AllFollowRuleDlg = Singleton("AllFollowRuleDlg", Dialog)
local RULE_PANEL = {
  "PetChangeRulePanel",
  "PetFollowRulePanel",
  "ChildFollowRulePanel"
}
local RULE_PANEL_SIZE = {
  PetChangeRulePanel = {BackImage2 = 160},
  PetFollowRulePanel = {BackImage2 = 235, PetChangeRulePanel = 185},
  ChildFollowRulePanel = {BackImage2 = 235, PetChangeRulePanel = 185}
}
function AllFollowRuleDlg:init(data)
  self:bindListener("CheckButton", self.onPetFollowCheckButton, "PetFollowRulePanel")
  self:bindListener("CheckButton", self.onCheckButton, "ChildFollowRulePanel")
  for _, pName in pairs(RULE_PANEL) do
    self:setCtrlVisible(pName, data.para == pName)
  end
  self:setCtrlVisible("CutoffImage", false, "AllBKPanel")
  if data.para == "PetChangeRulePanel" then
    self:setCtrlContentSize("BackImage2", nil, RULE_PANEL_SIZE[data.para].BackImage2)
  else
    local isShowGongtong = SystemSettingMgr:getSettingStatus("award_supply_pet", 0) >= 1 and not MapMgr:curIsInDifu()
    if isShowGongtong then
      self:setCtrlVisible("CutoffImage", true, "AllBKPanel")
      self:setCtrlVisible("PetChangeRulePanel", true)
    else
      self:setCtrlContentSize("BackImage2", nil, RULE_PANEL_SIZE[data.para].BackImage2)
    end
    local panel = self:getControl("PetChangeRulePanel")
    panel:setPositionY(RULE_PANEL_SIZE[data.para].PetChangeRulePanel)
    if data.para == "PetFollowRulePanel" then
      self:setPetFollowRulePanel(data)
    else
      self:setChildFollowRulePanel()
    end
  end
end
function AllFollowRuleDlg:setChildFollowRulePanel(data)
  self.kid = HomeChildMgr:getFightKid() or HomeChildMgr:getFollowKid()
  local panel = self:getControl("ChildFollowRulePanel")
  if self.kid then
    if HomeChildMgr:getFightKid() then
      self:setLabelText("TitleLabel", CHS[7120251])
    else
      self:setLabelText("TitleLabel", CHS[4200902])
    end
    self:getControl("ShapePanel"):setBackGroundImage(ResMgr.ui.bag_item_bg_img, ccui.TextureResType.plistType)
    local kidCfg = HomeChildMgr:getFamilyCfg(self.kid:queryBasicInt("gender"), self.kid:queryBasicInt("polar"))
    self:setImage("GuardImage", ResMgr:getSmallPortrait(kidCfg.icon), panel)
    self:setImageSize("GuardImage", {width = 64, height = 64}, panel)
    self:setNumImgForPanel("LevelPanel", ART_FONT_COLOR.NORMAL_TEXT, self.kid:getLevel(), false, LOCATE_POSITION.LEFT_TOP, 21, panel)
    self:setLabelText("NameLabel", self.kid:getShowName(), panel, COLOR3.GREEN)
    self:setLabelText("StrengtLabel", string.format(CHS[7100443], self.kid:queryBasicInt("energy")), panel)
  else
    self:setLabelText("TitleLabel", CHS[7120252])
    self:getControl("ShapePanel"):setBackGroundImage(ResMgr.ui.bag_item_bg_img, ccui.TextureResType.plistType)
    self:setImage("GuardImage", ResMgr.ui.kid_logo_image, panel)
    self:setImageSize("GuardImage", {width = 64, height = 64}, panel)
    self:setLabelText("NameLabel", CHS[7120253], panel, COLOR3.EQUIP_NORMAL)
    self:setLabelText("StrengtLabel", CHS[7120255], panel)
  end
end
function AllFollowRuleDlg:setPetFollowRulePanel(data)
  local pet = PetMgr:getPetById(data.id)
  pet = pet or PetMgr:getFightPet()
  local panel = self:getControl("PetFollowRulePanel")
  self.pet = pet
  if pet then
    self:setLabelText("TitleLabel", CHS[4200801], panel)
    self:setLabelText("NameLabel", pet:queryBasic("name"), panel)
    self:setLabelText("LifetLabel", string.format(CHS[4200802], pet:queryInt("longevity")), panel)
    self:setImage("GuardImage", ResMgr:getSmallPortrait(pet:queryBasicInt("portrait")), self:getControl("ShapePanel", nil, panel))
    self:setNumImgForPanel("LevelPanel", ART_FONT_COLOR.NORMAL_TEXT, pet:queryBasicInt("level"), false, LOCATE_POSITION.LEFT_TOP, 21, panel)
  else
    self:setLabelText("TitleLabel", CHS[4200803], panel)
    self:setLabelText("NameLabel", CHS[5000059], panel, COLOR3.EQUIP_NORMAL)
    self:setLabelText("LifetLabel", string.format(CHS[4200802], 0), panel)
    self:setImage("GuardImage", ResMgr.ui.button_pet, self:getControl("ShapePanel", nil, panel))
    self:removeNumImgForPanel("LevelPanel", LOCATE_POSITION.LEFT_TOP, panel)
  end
end
function AllFollowRuleDlg:onPetFollowCheckButton(sender, eventType)
  local dlg = DlgMgr:openDlg("PetAttribDlg")
  if self.pet then
    DlgMgr:sendMsg("PetListChildDlg", "selectPetId", self.pet:getId())
  end
  self:onCloseButton()
end
function AllFollowRuleDlg:onCheckButton(sender, eventType)
  if self.kid then
    DlgMgr:openDlgEx("KidInfoDlg", {
      selectId = self.kid:queryBasic("cid")
    })
    DlgMgr:closeDlg(self.name)
  else
    local kids = HomeChildMgr:getChildByOrder()
    for i = 1, #kids do
      if kids[i].stage == HomeChildMgr.CHILD_TYPE.KID then
        DlgMgr:openDlgEx("KidInfoDlg", {
          selectId = kids[i].id
        })
      end
    end
    DlgMgr:closeDlg(self.name)
  end
end
function AllFollowRuleDlg:cleanup()
  self.kid = nil
end
return AllFollowRuleDlg
