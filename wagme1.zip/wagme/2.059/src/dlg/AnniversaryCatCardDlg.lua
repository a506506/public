local AnniversaryCatCardDlg = Singleton("AnniversaryCatCardDlg", Dialog)
local GAME_STATE = {
  NOT_START = 0,
  GAMING = 1,
  OVER = 2
}
local GAME_OPER_TYPE = {
  ACTION_DATA = 0,
  ACTION_START = 1,
  ACTION_FINISH = 2,
  ACTION_RESET = 3,
  ACTION_TURN = 4
}
local MAGIC_AB = ResMgr.magic.anniversary_card_ab
local MAGIC_BC = ResMgr.magic.anniversary_card_bc
local MAGIC_CA = ResMgr.magic.anniversary_card_ca
local MAGIC_RULE = {
  AB = {isDouble = false, first = MAGIC_AB},
  AC = {
    isDouble = true,
    first = MAGIC_AB,
    second = MAGIC_BC,
    waitShow = "B"
  },
  BA = {
    isDouble = true,
    first = MAGIC_BC,
    second = MAGIC_CA,
    waitShow = "C"
  },
  BC = {isDouble = false, first = MAGIC_BC},
  CA = {isDouble = false, first = MAGIC_CA},
  CB = {
    isDouble = true,
    first = MAGIC_CA,
    second = MAGIC_AB,
    waitShow = "A"
  }
}
local MAGIC_TAG = 999
local LEVEL_LIMIT = 30
local CARD_NUM = 9
function AnniversaryCatCardDlg:init()
  self:bindListener("StartButton", self.onStartButton)
  self:bindListener("ResetButton", self.onResetButton)
  self:bindListener("CommitButton", self.onCommitButton)
  local function onCardPanel(sender, eventType)
    if eventType == ccui.TouchEventType.began then
      self:setCtrlVisible("TouchEffectImage", true, sender)
    else
      self:setCtrlVisible("TouchEffectImage", false, sender)
      if eventType == ccui.TouchEventType.ended then
        if not ActivityMgr:isFestivalActivityBegin(CHS[7190158]) then
          gf:ShowSmallTips(CHS[7100175])
          return
        end
        if not self:checkIsValidTime() then
          self:sendToServer(GAME_OPER_TYPE.ACTION_DATA)
          self.openDlgTime = gf:getServerTime()
          return
        end
        local tag = sender:getTag()
        if self.dlgBtnEnabled then
          self:sendToServer(GAME_OPER_TYPE.ACTION_TURN, tag)
          self:setDlgBtnEnabled(false)
        end
      end
    end
  end
  for i = 1, CARD_NUM do
    local card = self:getControl("UnitPanel" .. i, nil, "OperatePanel")
    card:addTouchEventListener(onCardPanel)
    card:setTag(i)
  end
  self.statusList = {}
  self.firstNeedPlayMagic = false
  self:sendToServer(GAME_OPER_TYPE.ACTION_DATA)
  self:setDlgByStatus(GAME_STATE.NOT_START)
  self.openDlgTime = gf:getServerTime()
  self.dlgBtnEnabled = true
  self.needStartGame = nil
  self:hookMsg("MSG_LINGMAO_FANPAI_DATA")
end
function AnniversaryCatCardDlg:sendToServer(oper, para)
  gf:CmdToServer("CMD_LINGMAO_FANPAI_OPER", {
    oper = oper,
    para = para or 0
  })
end
function AnniversaryCatCardDlg:setDlgByStatus(state, notRefreshIcon)
  self.gameState = state
  self:setCtrlVisible("FinishedPanel", false)
  self:setCtrlVisible("UnstartedPanel", false)
  gf:grayImageView(self:getControl("ResetButton"))
  gf:grayImageView(self:getControl("CommitButton"))
  if state == GAME_STATE.NOT_START then
    self:setCtrlVisible("UnstartedPanel", true)
    self.statusList = {}
    for i = 1, CARD_NUM do
      table.insert(self.statusList, "C")
    end
  elseif state == GAME_STATE.GAMING then
    gf:resetImageView(self:getControl("ResetButton"))
    gf:resetImageView(self:getControl("CommitButton"))
  else
    self:setCtrlVisible("FinishedPanel", true)
  end
  if not notRefreshIcon then
    self:refreshIcon()
  end
end
function AnniversaryCatCardDlg:refreshIcon(list)
  if not list or #list == 0 then
    list = {}
    for i = 1, CARD_NUM do
      list[i] = i
    end
  end
  for i = 1, #list do
    local unitPanel = self:getControl("UnitPanel" .. list[i], nil, "OperatePanel")
    self:setCtrlVisible("CardTypeAPanel", false, unitPanel)
    self:setCtrlVisible("CardTypeBPanel", false, unitPanel)
    self:setCtrlVisible("CardTypeCPanel", false, unitPanel)
    self:setCtrlVisible("CardType" .. self.statusList[list[i]] .. "Panel", true, unitPanel)
  end
end
function AnniversaryCatCardDlg:getRightCount()
  local count = 0
  for i = 1, #self.statusList do
    if self.statusList[i] == "C" then
      count = count + 1
    end
  end
  return count
end
function AnniversaryCatCardDlg:checkIsValidTime(notShowTips)
  if self.openDlgTime and gf:isSameDay5(gf:getServerTime(), self.openDlgTime) then
    return true
  end
  if not notShowTips then
    gf:ShowSmallTips(CHS[7190167])
  end
  return false
end
function AnniversaryCatCardDlg:setDlgBtnEnabled(flag)
  for i = 1, CARD_NUM do
    self:setCtrlOnlyEnabled("UnitPanel" .. i, flag, "OperatePanel")
  end
  self:setCtrlOnlyEnabled("ResetButton", flag)
  self:setCtrlOnlyEnabled("CommitButton", flag)
  self.dlgBtnEnabled = flag
end
function AnniversaryCatCardDlg:playCardChangeMagic(list)
  if not list or #list == 0 then
    return
  end
  for i = 1, #list do
    do
      local panel = self:getControl("UnitPanel" .. i)
      self:setCtrlVisible("CardTypeAPanel", false, panel)
      self:setCtrlVisible("CardTypeBPanel", false, panel)
      self:setCtrlVisible("CardTypeCPanel", false, panel)
      local key = self.statusList[i] .. list[i]
      local magicConfig = MAGIC_RULE[key]
      if panel.delayToPlay then
        self.root:stopAction(panel.delayToPlay)
        panel.delayToPlay = nil
      end
      local magic = panel:getChildByTag(MAGIC_TAG)
      if magic then
        magic:stopAllActions()
        magic:removeFromParent()
      end
      if magicConfig then
        local function func()
          panel:removeChildByTag(MAGIC_TAG)
          if magicConfig.isDouble then
            self:setCtrlVisible("CardType" .. magicConfig.waitShow .. "Panel", true, panel)
            panel.delayToPlay = performWithDelay(self.root, function()
              self:setCtrlVisible("CardTypeAPanel", false, panel)
              self:setCtrlVisible("CardTypeBPanel", false, panel)
              self:setCtrlVisible("CardTypeCPanel", false, panel)
              panel.delayToPlay = nil
              self:addMagicToCardPanel(panel, magicConfig.second, function()
                panel:removeChildByTag(MAGIC_TAG)
                self:setCtrlVisible("CardType" .. list[i] .. "Panel", true, panel)
                self:setDlgBtnEnabled(true)
              end)
            end, 0.3)
          else
            self:setCtrlVisible("CardType" .. list[i] .. "Panel", true, panel)
            self:setDlgBtnEnabled(true)
          end
        end
        self:addMagicToCardPanel(panel, magicConfig.first, func)
      else
        self:setCtrlVisible("CardType" .. list[i] .. "Panel", true, panel)
      end
    end
  end
end
function AnniversaryCatCardDlg:addMagicToCardPanel(panel, icon, callBack)
  local magic = panel:getChildByTag(MAGIC_TAG)
  if not magic then
    magic = gf:createCallbackMagic(icon, callBack)
    magic:setPosition(50, 50)
    panel:addChild(magic)
    magic:setTag(MAGIC_TAG)
  end
end
function AnniversaryCatCardDlg:cleanup()
  self.statusList = {}
  self.openDlgTime = nil
  self.dlgBtnEnabled = nil
end
function AnniversaryCatCardDlg:onStartButton(sender, eventType)
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  if Me:getLevel() < LEVEL_LIMIT then
    gf:ShowSmallTips(string.format(CHS[7190165], LEVEL_LIMIT))
    return
  end
  if not ActivityMgr:isFestivalActivityBegin(CHS[7190158]) then
    gf:ShowSmallTips(CHS[7100175])
    return
  end
  if not self:checkIsValidTime(true) then
    self:sendToServer(GAME_OPER_TYPE.ACTION_DATA)
    self.openDlgTime = gf:getServerTime()
    self.needStartGame = true
    return
  end
  self:sendToServer(GAME_OPER_TYPE.ACTION_START)
  self.firstNeedPlayMagic = true
end
function AnniversaryCatCardDlg:onResetButton(sender, eventType)
  if self.gameState == GAME_STATE.NOT_START then
    gf:ShowSmallTips(CHS[7190162])
  elseif self.gameState == GAME_STATE.GAMING then
    if not ActivityMgr:isFestivalActivityBegin(CHS[7190158]) then
      gf:ShowSmallTips(CHS[7100175])
      return
    end
    if not self:checkIsValidTime() then
      self:sendToServer(GAME_OPER_TYPE.ACTION_DATA)
      self.openDlgTime = gf:getServerTime()
      return
    end
    self:sendToServer(GAME_OPER_TYPE.ACTION_RESET)
  elseif self.gameState == GAME_STATE.OVER then
    gf:ShowSmallTips(CHS[7190164])
  end
end
function AnniversaryCatCardDlg:onCommitButton(sender, eventType)
  if self.gameState == GAME_STATE.NOT_START then
    gf:ShowSmallTips(CHS[7190162])
  elseif self.gameState == GAME_STATE.GAMING then
    local count = self:getRightCount()
    if count <= 3 then
      gf:ShowSmallTips(CHS[7190168])
      return
    end
    if Me:isInJail() then
      gf:ShowSmallTips(CHS[6000214])
      return
    end
    if Me:getLevel() < LEVEL_LIMIT then
      gf:ShowSmallTips(string.format(CHS[7190165], LEVEL_LIMIT))
      return
    end
    if GameMgr.inCombat then
      gf:ShowSmallTips(CHS[7190166])
      return
    end
    if not ActivityMgr:isFestivalActivityBegin(CHS[7190158]) then
      gf:ShowSmallTips(CHS[7100175])
      return
    end
    if not self:checkIsValidTime() then
      self:sendToServer(GAME_OPER_TYPE.ACTION_DATA)
      self.openDlgTime = gf:getServerTime()
      return
    end
    gf:confirm(string.format(CHS[7190163], count), function()
      if Me:isInJail() then
        gf:ShowSmallTips(CHS[6000214])
        return
      end
      if Me:getLevel() < LEVEL_LIMIT then
        gf:ShowSmallTips(string.format(CHS[7190165], LEVEL_LIMIT))
        return
      end
      if GameMgr.inCombat then
        gf:ShowSmallTips(CHS[7190166])
        return
      end
      if not ActivityMgr:isFestivalActivityBegin(CHS[7190158]) then
        gf:ShowSmallTips(CHS[7100175])
        return
      end
      if not self:checkIsValidTime() then
        self:sendToServer(GAME_OPER_TYPE.ACTION_DATA)
        self.openDlgTime = gf:getServerTime()
        return
      end
      self:sendToServer(GAME_OPER_TYPE.ACTION_FINISH, self.gameDay)
    end)
  elseif self.gameState == GAME_STATE.OVER then
    gf:ShowSmallTips(CHS[7190164])
  end
end
function AnniversaryCatCardDlg:MSG_LINGMAO_FANPAI_DATA(data)
  if not data then
    return
  end
  local notRefreshIcon = false
  if (self.firstNeedPlayMagic or self.gameState == GAME_STATE.GAMING) and data.status == GAME_STATE.GAMING then
    self:playCardChangeMagic(data.list)
    notRefreshIcon = true
  end
  self.gameDay = data.gameDay
  self.statusList = data.list
  self:setDlgByStatus(data.status, notRefreshIcon)
  if self.needStartGame then
    self:onStartButton()
    self.needStartGame = false
  end
end
return AnniversaryCatCardDlg
