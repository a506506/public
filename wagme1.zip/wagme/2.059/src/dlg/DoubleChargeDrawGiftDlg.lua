local DoubleChargeDrawGiftDlg = Singleton("DoubleChargeDrawGiftDlg", Dialog)
function DoubleChargeDrawGiftDlg:init()
  self:bindListener("GoButton", self.onGoButton)
  self:bindListener("RechargeButton", self.onRechargeButton)
  gf:CmdToServer("CMD_REQUEST_DOUBLE_LOTTERY_INFO")
  self:MSG_REQUEST_DOUBLE_LOTTERY_INFO()
  self:hookMsg("MSG_REQUEST_DOUBLE_LOTTERY_INFO")
end
function DoubleChargeDrawGiftDlg:onGoButton(sender, eventType)
  local dlg = DlgMgr:getDlgByName("WelfareDlg")
  dlg:onButtonClick(dlg:getControl("WelfareButton5"))
end
function DoubleChargeDrawGiftDlg:onRechargeButton(sender, eventType)
  DlgMgr:openDlg("OnlineRechargeDlg")
  self:onCloseButton()
end
function DoubleChargeDrawGiftDlg:MSG_REQUEST_DOUBLE_LOTTERY_INFO(data)
  data = data or GiftMgr.doubleLottertData
  if not data then
    return
  end
  self:setLabelText("Label2", string.format("%d/150", data.double_lottery_time), "LabelPanel1")
  local startTimeStr = gf:getServerDate(CHS[7150112], data.start_time)
  local endTimeStr = gf:getServerDate(CHS[7150112], data.end_time)
  local timeStr = string.format(CHS[4300628], startTimeStr, endTimeStr)
  self:setLabelText("TitleLabel", timeStr, panel)
  self:setLabelText("TimesLabel", string.format(CHS[4300632], Me:queryBasicInt("lottery_times")))
end
return DoubleChargeDrawGiftDlg
