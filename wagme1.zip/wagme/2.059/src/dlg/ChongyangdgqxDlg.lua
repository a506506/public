local ChongyangdgqxDlg = Singleton("ChongyangdgqxDlg", Dialog)
local ITEM_TYPE = {TIGER = 1000, CAT = 2000}
local ITEM_CFG = {
  {
    name = CHS[7190609],
    tag = ITEM_TYPE.CAT
  },
  {
    name = CHS[7190608],
    tag = ITEM_TYPE.TIGER
  }
}
local MONSTER_CFG = {
  [CHS[7190614]] = true,
  [CHS[7190615]] = true,
  [CHS[7190616]] = true
}
local MONSTER_MOVE_DIS = 5
local MONSTER_MOVE_DIS_DX_DY = 3
local MONSTER_TO_ME_DIS = 4
local COUNT_DOWN_FONT_SIZE = 23
function ChongyangdgqxDlg:init()
  self:setFullScreen()
  self:bindListener("ShowButton", self.onShowButton)
  self:bindCtrlTouchListener()
  self:doInit()
  self:setBasicInfo()
  self:hookMsg("MSG_INVENTORY")
  self:hookMsg("MSG_CHONGYANG_2019_DGQX_ITEM")
  self:hookMsg("MSG_CHONGYANG_2019_DGQX_TUFU")
  EventDispatcher:addEventListener(EVENT.EVENT_END_COMBAT, self.onEventEndCombat, self)
  if Me:isInCombat() then
    self:setVisible(false)
  end
end
function ChongyangdgqxDlg:bindCtrlTouchListener()
  for i = 1, #ITEM_CFG do
    local itemPanel = self:getControl("ItemPanel", nil, "JewelPanel_" .. i)
    itemPanel:setTag(i)
    self:blindLongPress("ItemPanel", self.onOneSecondLater, self.onClick, "JewelPanel_" .. i)
  end
end
function ChongyangdgqxDlg:doInit()
  for i = 1, #ITEM_CFG do
    self:setCtrlVisible("ChosenImage_1", false, "JewelPanel_" .. i)
    self:setCtrlVisible("ChosenImage_2", false, "JewelPanel_" .. i)
  end
end
function ChongyangdgqxDlg:onOneSecondLater(sender, eventType)
  local tag = sender:getTag()
  local itemName = ITEM_CFG[tag].name
  local rect = self:getBoundingBoxInWorldSpace(sender)
  InventoryMgr:showBasicMessageDlg(itemName, rect)
end
function ChongyangdgqxDlg:onClick(sender, eventType)
  if sender.inCountDown then
    return
  end
  local tag = sender:getTag()
  local itemName = ITEM_CFG[tag].name
  local amount = InventoryMgr:getAmountByName(itemName)
  if amount == 0 then
    gf:ShowSmallTips(CHS[7190721])
    return
  end
  if Me:isInCombat() then
    gf:ShowSmallTips(CHS[8000005])
    return
  end
  self:useItem(itemName)
end
function ChongyangdgqxDlg:useItem(itemName)
  local monsterList = self:getMonsterList()
  local meX, meY = gf:convertToMapSpace(Me.curX, Me.curY)
  local sceneH = GameMgr:getSceneHeight()
  for i = 1, #monsterList do
    local monster = monsterList[i]
    local monsterX, monsterY = gf:convertToMapSpace(monster.curX, monster.curY)
    monster.startX = monsterX
    monster.startY = monsterY
    local tarX, tarY = self:getMonsterTargetPos(meX, meY, monsterX, monsterY)
    monster.endX = tarX
    monster.endY = tarY
  end
  local sendData = {}
  sendData.item_name = itemName
  sendData.count = #monsterList
  for i = 1, sendData.count do
    sendData[i] = {}
    sendData[i].npc_id = monsterList[i]:getId()
    sendData[i].start_x = monsterList[i].startX
    sendData[i].start_y = monsterList[i].startY
    sendData[i].end_x = monsterList[i].endX
    sendData[i].end_y = monsterList[i].endY
  end
  gf:CmdToServer("CMD_CHONGYANG_2019_DGQX_ITEM", sendData)
  if itemName == CHS[7190609] then
    self:playCountDown(ITEM_TYPE.CAT, 2)
  elseif itemName == CHS[7190608] then
    self:playCountDown(ITEM_TYPE.TIGER, 2)
  end
end
function ChongyangdgqxDlg:getMonsterList()
  local monsterList = {}
  local meX, meY = gf:convertToMapSpace(Me.curX, Me.curY)
  for _, char in pairs(CharMgr.chars) do
    if OBJECT_NPC_TYPE.CANNOT_TOUCH == char:queryBasicInt("sub_type") and MONSTER_CFG[char:getName()] then
      local charX, charY = gf:convertToMapSpace(char.curX, char.curY)
      if gf:distance(meX, meY, charX, charY) <= 8 then
        table.insert(monsterList, char)
      end
    end
  end
  return monsterList
end
function ChongyangdgqxDlg:getTuFuTurnDir(tufuId, monsterId)
  local tufu = CharMgr:getCharById(tufuId)
  local monster = CharMgr:getCharById(monsterId)
  if not tufu or not monster then
    return
  end
  local tufuX, tufuY = gf:convertToMapSpace(tufu.curX, tufu.curY)
  local monsterX, monsterY = gf:convertToMapSpace(monster.curX, monster.curY)
  if tufuX < monsterX then
    if tufuY < monsterY then
      return 5
    elseif tufuY > monsterY then
      return 3
    else
      return 4
    end
  elseif tufuX > monsterX then
    if tufuY < monsterY then
      return 7
    elseif tufuY > monsterY then
      return 1
    else
      return 0
    end
  elseif tufuY < monsterY then
    return 6
  elseif tufuY > monsterY then
    return 2
  end
end
function ChongyangdgqxDlg:getMonsterTargetPos(meX, meY, monsterX, monsterY)
  local meX, meY = gf:convertToMapSpace(Me.curX, Me.curY)
  local tarX, tarY
  if monsterX == meX then
    tarX = meX
    tarY = monsterY > meY and monsterY + MONSTER_MOVE_DIS or monsterY - MONSTER_MOVE_DIS
  else
    local k = (monsterY - meY) / (monsterX - meX)
    if monsterX > meX then
      tarX = monsterX + math.sqrt(MONSTER_MOVE_DIS * MONSTER_MOVE_DIS / (1 + k * k))
    else
      tarX = monsterX - math.sqrt(MONSTER_MOVE_DIS * MONSTER_MOVE_DIS / (1 + k * k))
    end
    tarY = monsterY + k * (tarX - monsterX)
  end
  if monsterX > meX then
    tarX = math.ceil(tarX)
  else
    tarX = math.floor(tarX)
  end
  if monsterY > meY then
    tarY = math.ceil(tarY)
  else
    tarY = math.floor(tarY)
  end
  local notObstaclePos = GObstacle:Instance():GetNearestPos(tarX, tarY)
  return math.floor(notObstaclePos / 1000), notObstaclePos % 1000
end
function ChongyangdgqxDlg:setBasicInfo()
  for i = 1, #ITEM_CFG do
    local itemName = ITEM_CFG[i].name
    local itemImage = self:getControl("ItemImage", nil, "JewelPanel_" .. i)
    self:setImage("ItemImage", InventoryMgr:getIconFileByName(itemName), "JewelPanel_" .. i)
    self:setLabelText("NameLabel", itemName, "JewelPanel_" .. i)
    if amount == 0 then
      gf:grayImageView(itemImage)
    else
      gf:resetImageView(itemImage)
    end
  end
end
function ChongyangdgqxDlg:playCountDown(type, time)
  local panel
  if type == ITEM_TYPE.CAT then
    panel = self:getControl("ItemPanel", nil, "JewelPanel_1")
  elseif type == ITEM_TYPE.TIGER then
    panel = self:getControl("ItemPanel", nil, "JewelPanel_2")
  end
  panel.inCountDown = true
  panel:removeChildByTag(type)
  panel:stopAllActions()
  self:setCtrlVisible("ChosenImage_1", true, panel)
  local progressTimer = cc.ProgressTimer:create(cc.Sprite:create(ResMgr.ui.ore_progress_timer))
  progressTimer:setReverseDirection(true)
  progressTimer:setTag(type)
  panel:addChild(progressTimer)
  local contentSize = panel:getContentSize()
  progressTimer:setPosition(contentSize.width / 2, contentSize.height / 2)
  progressTimer:setPercentage(100)
  local progressTo = cc.ProgressTo:create(time, 0)
  local endAction = cc.CallFunc:create(function()
    progressTimer:removeFromParent()
    self:setCtrlVisible("ChosenImage_1", false, panel)
    panel.inCountDown = nil
  end)
  progressTimer:runAction(cc.Sequence:create(progressTo, endAction))
  local sec = time
  self:setCtrlVisible("TimePanel", true, panel)
  self:setNumImgForPanel("TimePanel", ART_FONT_COLOR.NORMAL_TEXT, sec, false, LOCATE_POSITION.MID, COUNT_DOWN_FONT_SIZE, panel)
  schedule(panel, function()
    sec = sec - 1
    if sec > 0 then
      self:setNumImgForPanel("TimePanel", ART_FONT_COLOR.NORMAL_TEXT, sec, false, LOCATE_POSITION.MID, COUNT_DOWN_FONT_SIZE, panel)
    else
      self:setCtrlVisible("TimePanel", false, panel)
      panel:stopAllActions()
    end
  end, 1)
end
function ChongyangdgqxDlg:onShowButton()
  local dlg = DlgMgr:openDlg("GameFunctionDlg")
  dlg:onHideButton()
  self:setCtrlVisible("ShowButton", false)
  self:setCtrlVisible("FunctionPanel", true)
end
function ChongyangdgqxDlg:onCloseButton()
  self:setCtrlVisible("ShowButton", true)
  self:setCtrlVisible("FunctionPanel", false)
end
function ChongyangdgqxDlg:doTuFuAction(id, dir)
  local char = CharMgr:getCharById(id)
  if dir then
    char:setDir(dir)
  end
  if char and char.charAction then
    char.charAction:playAction(nil, Const.SA_CAST, 1)
  end
end
function ChongyangdgqxDlg:doMonsterEffect(id)
  local monster = CharMgr:getCharById(id)
  if monster then
    local headX, headY = monster.charAction:getHeadOffset()
    local magic = gf:createSelfRemoveMagic(ResMgr.magic.tanan_jhll_too_close, nil, {blendMode = "add"})
    magic:setAnchorPoint(0.5, 0.5)
    magic:setLocalZOrder(Const.CHARACTION_ZORDER)
    magic:setPosition(0, headY + 20)
    magic:setTag(icon)
    monster:addToMiddleLayer(magic)
  end
end
function ChongyangdgqxDlg:doMonsterAction(id)
  local char = CharMgr:getCharById(id)
  if char and char.charAction then
    char:setAct(Const.FA_STAND)
    char.charAction:playAction(function()
      local monster = CharMgr:getCharById(id)
      if monster and monster.charAction then
        monster:setActAndCB(Const.FA_DIE_NOW, function()
          local npc = CharMgr:getCharById(id)
          if npc then
            npc:setActAndCB(Const.FA_DIED, function()
              CharMgr:deleteChar(id)
            end)
          end
        end)
      end
    end, Const.SA_DEFENSE, 1)
    local magics = SkillEffectMgr:getMagicInfo(14, 1)
    if magics and magics[1] then
      local callback = function(node, data)
        node:removeFromParent()
      end
      local magic = gf:createCallbackMagic(magics[1].icon, callback)
      magic:setPosition(0, 0)
      char:addToMiddleLayer(magic)
      SoundMgr:playSkillEffect(magics[1].icon)
    end
  end
end
function ChongyangdgqxDlg:onEventEndCombat()
  self:setVisible(true)
  self:onShowButton()
end
function ChongyangdgqxDlg:MSG_INVENTORY(data)
  self:setBasicInfo()
end
function ChongyangdgqxDlg:MSG_CHONGYANG_2019_DGQX_ITEM(data)
  if data.char_id == Me:getId() then
    for i = 1, data.count do
      self:doMonsterEffect(data.npc_list[i])
    end
  end
end
function ChongyangdgqxDlg:MSG_CHONGYANG_2019_DGQX_TUFU(data)
  self:doTuFuAction(data.tufu_id, self:getTuFuTurnDir(data.tufu_id, data.npc_id))
  self:doMonsterAction(data.npc_id)
end
return ChongyangdgqxDlg
