local ChangyjjDlg = Singleton("ChangyjjDlg", Dialog)
local GAME_STATUS = {
  WAIT = 1,
  PLAYING = 2,
  STOP = 3
}
local ROUND = {PLAYER = 0, OTHER = 1}
local NPC_CONFIG = {
  [CHS[7190778]] = {
    succ = 100,
    min_succ = 0,
    reduce_succ = 10,
    speed = 225,
    add_speed = {min = 29, max = 34},
    width = 120,
    reduce_width = {min = 5, max = 10},
    gender = 1
  }
}
local TALK = {
  CHS[5450299],
  CHS[5450300],
  CHS[5450301],
  CHS[5450302],
  CHS[5450303]
}
local ROUND_SPACE = 3
local MIN_WIDTH = 45
local curNpcConfig
local DOWN_TIME = 30
function ChangyjjDlg:init()
  self:setFullScreen()
  CharMgr:setVisible(false)
  self:bindListener("StartButton", self.onStartButton)
  self:bindListener("LeaveButton", self.onLeaveButton)
  self:bindListener("CloseButton", self.onCloseButton)
  self:bindListener("TouchPanel", self.onTouchPanel, nil, true)
  self.gameStatus = GAME_STATUS.WAIT
  self.greenImg = self:getControl("GreenImage")
  self.canMoveSize = self:getControl("CanMovePanel"):getContentSize()
  self.npcName = CHS[7190778]
  self.npcIcon = 6148
  curNpcConfig = NPC_CONFIG[self.npcName]
  self:setStartData()
  self:createCountDown(DOWN_TIME)
  DlgMgr:closeDlg("DramaDlg")
  self.allInvisbleDlgs = DlgMgr:getAllInVisbleDlgs()
  DlgMgr:showAllOpenedDlg(false, {
    [self.name] = 1
  })
end
function ChangyjjDlg:setStartData()
  self.curRound = 0
  self.npcDrinkNum = 0
  self.playerDrinkNum = 0
  self.showResultTime = 0
  self.roundData = {}
  self.result = ""
  self.gameStatus = GAME_STATUS.WAIT
  self:initView()
end
function ChangyjjDlg:cmdResult(result)
  if self.result == "succ" then
    DlgMgr:sendMsg("YinhrdDlg", "doSmallGameResult", 10, 1)
  elseif self.result == "onCloseBtn" then
    DlgMgr:sendMsg("YinhrdDlg", "doSmallGameResult", 10, 2)
  else
    DlgMgr:sendMsg("YinhrdDlg", "doSmallGameResult", 10, 0)
  end
end
function ChangyjjDlg:createCountDown(time)
  self:setCtrlVisible("CountDownPanel", false)
  local numImg = Dialog.createCountDown(self, time, "CountDownPanel")
  numImg:setScale(0.5, 0.5)
end
function ChangyjjDlg:startCountDown(time)
  self:setCtrlVisible("CountDownPanel", true)
  Dialog.startCountDown(self, time, "CountDownPanel", nil, function(numImg)
    self:setCtrlVisible("CountDownPanel", false)
    self:setResult(0)
  end)
end
function ChangyjjDlg:stopCountDown()
  Dialog.stopCountDown(self, "CountDownPanel")
  self:setCtrlVisible("CountDownPanel", false)
end
function ChangyjjDlg:initView()
  self:creatCharPanel(self.npcIcon, "NpcBonesPanel", false)
  self:setLabelText("NameLabel", self.npcName, "NpcNamePanel")
  self:creatCharPanel(Me:queryBasicInt("icon"), "PlayerBonesPanel", true)
  self:setLabelText("NameLabel", Me:getShowName(), "PlayerNamePanel")
  self:setCtrlVisible("MovePanel", false)
  self:setCtrlVisible("StartButton", true)
  self:setCtrlVisible("LeaveButton", false)
  self:setCtrlVisible("ResultPanel", false)
  self:setCtrlVisible("SayPanel", false, "PlayerBonesPanel")
  self:setCtrlVisible("SayPanel", false, "NpcBonesPanel")
  self:setCtrlVisible("TitlePanel", false)
  self:setCtrlVisible("ChoseNpcImage", false)
  self:setCtrlVisible("ChosePlayerImage", false)
  self:showSuccJiuNum()
end
function ChangyjjDlg:adjustDifficulty()
  if self.roundData and self.roundData.curRound == self.curRound then
    return
  end
  local lastData = self.roundData
  self.roundData = {}
  if not lastData or self.curRound == 1 then
    self.roundData.curRound = self.curRound
    self.roundData.speed = curNpcConfig.speed
    self.roundData.width = curNpcConfig.width
    self.roundData.succ = curNpcConfig.succ
  else
    self.roundData.curRound = self.curRound
    self.roundData.succ = math.max(curNpcConfig.min_succ, curNpcConfig.succ - self.curRound * curNpcConfig.reduce_succ)
    self.roundData.speed = lastData.speed + math.random(curNpcConfig.add_speed.min, curNpcConfig.add_speed.max)
    self.roundData.width = math.max(MIN_WIDTH, lastData.width - math.random(curNpcConfig.reduce_width.min, curNpcConfig.reduce_width.max))
  end
  local min = self.roundData.width / 2 + 50
  local max = self.canMoveSize.width - self.roundData.width / 2
  self.roundData.yellowX = math.random(min, max)
end
function ChangyjjDlg:setGameStopResult()
  if self.gameStatus == GAME_STATUS.STOP then
    self:setCtrlVisible("ResultPanel", true)
    self:setCtrlVisible("LeaveButton", true)
    self:setCtrlVisible("WinImage", false, "ResultPanel")
    self:setCtrlVisible("WinBKImage", false, "ResultPanel")
    self:setCtrlVisible("LoseImage", false, "ResultPanel")
    self:setCtrlVisible("LoseBKImage", false, "ResultPanel")
    self:setCtrlVisible("DrawImage", false, "ResultPanel")
    if self.playerDrinkNum > self.npcDrinkNum then
      self:setCtrlVisible("WinImage", true, "ResultPanel")
      self:setCtrlVisible("WinBKImage", true, "ResultPanel")
      self.result = "succ"
    elseif self.playerDrinkNum < self.npcDrinkNum then
      self:setCtrlVisible("LoseImage", true, "ResultPanel")
      self:setCtrlVisible("LoseBKImage", true, "ResultPanel")
      self.result = "fail"
    else
      self:setCtrlVisible("DrawImage", true, "ResultPanel")
      self:setCtrlVisible("WinBKImage", true, "ResultPanel")
      self.result = "draw"
    end
  end
end
function ChangyjjDlg:setNextRoundView()
  self:setCtrlVisible("MovePanel", false)
  self:setCtrlVisible("StartButton", false)
  self:setCtrlVisible("LeaveButton", false)
  self:setCtrlVisible("ResultPanel", false)
  self:setCtrlVisible("TitlePanel", false)
  self:setCtrlVisible("ChoseNpcImage", false)
  self:setCtrlVisible("ChosePlayerImage", false)
  if self.gameStatus == GAME_STATUS.STOP then
    self:setGameStopResult()
  elseif self.gameStatus == GAME_STATUS.PLAYING then
    self:setCtrlVisible("MovePanel", true)
    self:startCountDown(DOWN_TIME)
    self.whoRound = (self.whoRound + 1) % 2
    local yImg = self:getControl("YellowImage")
    if self.whoRound == ROUND.PLAYER then
      self.curRound = self.curRound + 1
      self:adjustDifficulty()
      local size = yImg:getContentSize()
      yImg:setContentSize(self.roundData.width, size.height)
      yImg:setPositionX(self.roundData.yellowX)
      self:setChat(TALK[1], "PlayerBonesPanel")
      gf:ShowSmallTips(CHS[5450308])
      self:setCtrlVisible("TitlePanel", true)
      self:setCtrlVisible("ChosePlayerImage", true)
      self.greenImg:loadTexture(ResMgr.ui.changyjj_green_circle)
      yImg:loadTexture(ResMgr.ui.changyjj_yellow_block)
    else
      self.npcIsSucc = self.roundData.succ >= math.random(1, 100)
      self.showResultTime = math.random(1, 5)
      self:setChat(TALK[1], "NpcBonesPanel")
      gf:ShowSmallTips(string.format(CHS[5450307], self.npcName))
      self:setCtrlVisible("ChoseNpcImage", true)
      self.greenImg:loadTexture(ResMgr.ui.changyjj_gray_circle)
      yImg:loadTexture(ResMgr.ui.changyjj_red_block)
    end
    self.greenImgDir = 1
    self.greenImg:setPositionX(0)
  end
end
function ChangyjjDlg:showResult()
  self:setCtrlVisible("CountDownPanel", false)
end
function ChangyjjDlg:creatCharPanel(icon, panelName)
  self:setCtrlVisible("ShapeImage", true, panelName)
  self:setImage("ShapeImage", ResMgr:getBigPortrait(icon), panelName)
end
function ChangyjjDlg:showSuccJiuNum()
  local panel = self:getControl("NpcCountPanel")
  for i = 1, 8 do
    self:setCtrlVisible("GlassImage" .. i, i <= self.npcDrinkNum, panel)
  end
  local numImg = self:setNumImgForPanel("NumPanel", ART_FONT_COLOR.B_FIGHT, self.npcDrinkNum, false, LOCATE_POSITION.CENTER, 25, "NpcCountPanel")
  numImg:setScale(0.35, 0.35)
  panel:setVisible(self.npcDrinkNum ~= 0)
  local panel = self:getControl("PlayerCountPanel")
  for i = 1, 8 do
    self:setCtrlVisible("GlassImage" .. i, i <= self.playerDrinkNum, panel)
  end
  local numImg = self:setNumImgForPanel("NumPanel", ART_FONT_COLOR.B_FIGHT, self.playerDrinkNum, false, LOCATE_POSITION.CENTER, 23, "PlayerCountPanel")
  numImg:setScale(0.35, 0.35)
  panel:setVisible(self.playerDrinkNum ~= 0)
end
function ChangyjjDlg:onStartButton(sender, eventType)
  self.gameStatus = GAME_STATUS.PLAYING
  self.whoRound = ROUND.OTHER
  self.curRound = 0
  self.npcDrinkNum = 0
  self.playerDrinkNum = 0
  self.roundData = {}
  self:showSuccJiuNum()
  self:setNextRoundView()
end
function ChangyjjDlg:onLeaveButton(sender, eventType)
  DlgMgr:closeDlg(self.name)
end
function ChangyjjDlg:onCloseButton(sender, eventType)
  if self.gameStatus == GAME_STATUS.STOP then
    self:setGameStopResult()
    DlgMgr:closeDlg(self.name)
  else
    gf:confirm(CHS[7190777], function()
      self.result = "onCloseBtn"
      DlgMgr:closeDlg(self.name)
    end)
  end
end
function ChangyjjDlg:onTouchPanel(sender, eventType)
  if self.gameStatus ~= GAME_STATUS.PLAYING or self.whoRound ~= ROUND.PLAYER then
    return
  end
  if eventType == ccui.TouchEventType.began then
    self:setResult()
  end
end
function ChangyjjDlg:setResult(result)
  self.gameStatus = GAME_STATUS.WAIT
  self:stopCountDown()
  local curX = self.greenImg:getPositionX()
  if result ~= 0 and (result == 1 or self:isInYellowPanel(curX)) then
    if self.whoRound == ROUND.PLAYER then
      self:setChat(TALK[2], "PlayerBonesPanel")
      self.playerDrinkNum = self.playerDrinkNum + 1
    else
      self:setChat(TALK[2], "NpcBonesPanel")
      self.npcDrinkNum = self.npcDrinkNum + 1
      if self.npcDrinkNum > self.playerDrinkNum then
        self:setChat(TALK[4] .. "#15" .. BrowMgr:getGenderSign(), "PlayerBonesPanel")
        self.gameStatus = GAME_STATUS.STOP
      end
    end
    self:showSuccJiuNum()
  elseif self.whoRound == ROUND.PLAYER then
    self:setChat(TALK[3], "PlayerBonesPanel")
  elseif self.npcDrinkNum == self.playerDrinkNum then
    self:setChat(TALK[5], "NpcBonesPanel")
    self:setChat(TALK[5], "PlayerBonesPanel")
    self.gameStatus = GAME_STATUS.STOP
  elseif self.npcDrinkNum < self.playerDrinkNum then
    self:setChat(TALK[4] .. "#15" .. BrowMgr:getGenderSign(curNpcConfig.gender), "NpcBonesPanel")
    self.gameStatus = GAME_STATUS.STOP
  end
  if self.gameStatus == GAME_STATUS.STOP then
    self:setCtrlVisible("ChoseNpcImage", false)
    self:setCtrlVisible("ChosePlayerImage", false)
  end
  performWithDelay(self.root, function()
    if self.gameStatus ~= GAME_STATUS.STOP then
      self.gameStatus = GAME_STATUS.PLAYING
    end
    self:setNextRoundView()
  end, ROUND_SPACE)
end
function ChangyjjDlg:setChat(str, ctrlName)
  local panel = self:getControl(ctrlName)
  local labelPanel = self:getControl("LabelPanel", nil, panel)
  local locate = ctrlName == "PlayerBonesPanel" and LOCATE_POSITION.RIGHT_BOTTOM or nil
  self:setColorText(str, labelPanel, nil, 0, 0, nil, 21, locate, nil, nil)
  local textNode = labelPanel:getChildByTag(Dialog.TAG_COLORTEXT_CTRL)
  local textCtrl = tolua.cast(textNode, "CGAColorTextList")
  local textW, textH = textCtrl:getRealSize()
  local backImage = self:getControl("InfoBackImage1", nil, panel)
  backImage:setContentSize(textW + 18, textH + 34)
  local sayPanel = self:getControl("SayPanel", nil, panel)
  sayPanel:requestDoLayout()
  sayPanel:setVisible(true)
  sayPanel:stopAllActions()
  performWithDelay(sayPanel, function()
    sayPanel:setVisible(false)
  end, 3)
end
function ChangyjjDlg:onUpdate(delayTime)
  if self.gameStatus ~= GAME_STATUS.PLAYING then
    return
  end
  self:moveGreenImg(delayTime)
end
function ChangyjjDlg:moveGreenImg(delayTime)
  local curX = self.greenImg:getPositionX()
  if self.greenImgDir == 1 then
    curX = math.floor(curX + self.roundData.speed * delayTime)
    if curX >= self.canMoveSize.width then
      curX = self.canMoveSize.width
      self.greenImgDir = 0
    end
  else
    curX = math.floor(curX - self.roundData.speed * delayTime)
    if curX <= 0 then
      curX = 0
      self.greenImgDir = 1
    end
  end
  self.greenImg:setPositionX(curX)
  self.showResultTime = self.showResultTime - delayTime
  if self.whoRound == ROUND.OTHER and 0 >= self.showResultTime then
    if self.npcIsSucc then
      if self:isInYellowPanel(curX) then
        self:setResult(1)
      end
    elseif not self:isInYellowPanel(curX, 20) and self:isInYellowPanel(curX, 60) then
      self:setResult(0)
    end
  end
end
function ChangyjjDlg:isInYellowPanel(curX, offset)
  offset = offset or 0
  if math.abs(curX - self.roundData.yellowX) <= self.roundData.width / 2 - 15 + offset then
    return true
  end
end
function ChangyjjDlg:cleanup()
  self:cmdResult(self.result)
  local t = {}
  if self.allInvisbleDlgs then
    for i = 1, #self.allInvisbleDlgs do
      t[self.allInvisbleDlgs[i]] = 1
    end
  end
  DlgMgr:showAllOpenedDlg(true, t)
  self.allInvisbleDlgs = nil
  if not Me:isInCombat() and not Me:isLookOn() and not DlgMgr:isDlgOpened("YinhrdDlg") then
    CharMgr:setVisible(true)
  end
end
return ChangyjjDlg
