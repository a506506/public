local AngpaoAddDlg = Singleton("AngpaoAddDlg", Dialog)
local ARPanel = require("ctrl/AddReducePanel")
local MIN_NUM = 1
local MAX_NUM = 6
local MIN_MONEY = 10000
local MAX_MONEY = 20000000
local TOTAL_MONEY = 2000000000
function AngpaoAddDlg:init()
  self:bindListener("ConfrimButton", self.onConfrimButton)
  self:bindListener("StopButton", self.onStopButton)
  self.arPanel1 = ARPanel.new(self, "TimeAddButton", "TimeReduceButton", nil, true, 1)
  self.arPanel1:setClickLimitPara(MIN_NUM, MAX_NUM)
  local strMoney = gf:getMoneyDesc(MAX_MONEY)
  self.arPanel2 = ARPanel.new(self, "MoneyAddButton", "MoneyReduceButton", nil, true, 2, 10000, 10000)
  self.arPanel2:setClickLimitPara(MIN_MONEY, MAX_MONEY, nil, string.format(CHS[5410388], strMoney))
  self.arPanel2:bindNumInput("ConValueLabel", "MoneyPanel", function()
    if self.status == 1 then
      return true
    end
  end)
  local strMoney, color = gf:getMoneyDesc(MIN_MONEY, true)
  self:setLabelText("NoteLabel_6", strMoney, nil, color)
  strMoney, color = gf:getMoneyDesc(Me:queryBasicInt("cash"), true)
  self:setLabelText("NoteLabel_8", strMoney, nil, color)
  strMoney, color = gf:getMoneyDesc(TOTAL_MONEY, true)
  self:setLabelText("NoteLabel_10", strMoney, nil, color)
  self.num = 0
  self.cash = 0
  self.castNum = 0
  if MarryMgr.weddingRedbagInfo then
    self:setData(MarryMgr.weddingRedbagInfo)
  end
  self:hookMsg("MSG_WEDDING_RUNNING_REDBAG_SETTING")
end
function AngpaoAddDlg:cleanup()
  self.num = nil
  self.cash = nil
  self.castNum = nil
end
function AngpaoAddDlg:setData(data)
  self.castNum = data.total
  local strMoney, color = gf:getMoneyDesc(self.castNum, true)
  self:setLabelText("TotalMoneyLabel", strMoney, nil, color)
  self:setCtrlVisible("ConfrimButton", data.status ~= 1)
  self:setCtrlVisible("StopButton", data.status == 1)
  if data.status == 1 then
    self:setCtrlVisible("StopButton", true)
    self:setCtrlVisible("ConfrimButton", false)
  else
    self:setCtrlVisible("StopButton", false)
    self:setCtrlVisible("ConfrimButton", true)
  end
  self.status = data.status
  self.arPanel1:setNum(data.num == 0 and 1 or data.num)
  self.arPanel2:setNum(data.cash == 0 and MIN_MONEY or data.cash)
end
function AngpaoAddDlg:onConfrimButton(sender, eventType)
  if self.castNum + self.num * self.cash > TOTAL_MONEY then
    local strMoney = gf:getMoneyDesc(TOTAL_MONEY)
    gf:ShowSmallTips(string.format(CHS[5410389], strMoney))
    return
  end
  if self:checkSafeLockRelease("onConfrimButton", sender) then
    return
  end
  if gf:checkEnough("cash", self.cash * self.num) then
    gf:confirm(CHS[5410390], function()
      gf:CmdToServer("CMD_WEDDING_RUNNING_REDBAG_SETTING", {
        num = self.num,
        cash = self.cash,
        status = 1
      })
    end)
  end
end
function AngpaoAddDlg:onStopButton(sender, eventType)
  gf:CmdToServer("CMD_WEDDING_RUNNING_REDBAG_SETTING", {
    num = self.num,
    cash = self.cash,
    status = 0
  })
end
function AngpaoAddDlg:updateNum(num, key)
  if key == 1 then
    self:setLabelText("ConValueLabel", num, "GrantPanel")
    self:setCtrlEnabled("TimeAddButton", num < MAX_NUM and self.status == 0)
    self:setCtrlEnabled("TimeReduceButton", num > MIN_NUM and self.status == 0)
    self.num = num
  else
    local strMoney, color = gf:getMoneyDesc(num, true)
    self:setLabelText("ConValueLabel", strMoney, "MoneyPanel", color)
    self:setCtrlEnabled("MoneyAddButton", num < MAX_MONEY and self.status == 0)
    self:setCtrlEnabled("MoneyReduceButton", num > MIN_MONEY and self.status == 0)
    self.cash = num
  end
end
function AngpaoAddDlg:MSG_WEDDING_RUNNING_REDBAG_SETTING(data)
  self:setData(data)
end
return AngpaoAddDlg
