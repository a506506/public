local FireworksCeremonyDlg = require("dlg/FireworksCeremonyDlg")
local FireworksMainDlg = Singleton("FireworksMainDlg", FireworksCeremonyDlg)
function FireworksMainDlg:init()
  self:setFullScreen()
  self:bindListener("OpenButton", self.onOpenButton)
  self:bindListener("CloseButton", self.onCloseButton2)
  self:bindListener("UpPanel", self.onUpPanel)
  schedule(self.root, function()
    if not DlgMgr:isDlgOpened("FireworksCeremonyDlg") then
      gf:CmdToServer("CMD_FIREWORKS_PARTY_INFO", {})
    end
  end, 1)
  self:setItemsDescript()
  self:onOpenButton()
  self:initShoot()
  self:setLabelText("ValueLabel", 0, "FireValuePanel")
  local bar = self:getControl("FireLoadingBar")
  bar:setPercent(0)
  self:hookMsg("MSG_FIREWORKS_PARTY_INFO")
end
function FireworksMainDlg:onOpenButton(sender, eventType)
  self:setCtrlVisible("UpPanel", true)
  self:setCtrlVisible("OpenButton", false)
  self:setCtrlVisible("CloseButton", true)
end
function FireworksMainDlg:onCloseButton2(sender, eventType)
  self:setCtrlVisible("UpPanel", false)
  self:setCtrlVisible("OpenButton", true)
  self:setCtrlVisible("CloseButton", false)
end
function FireworksMainDlg:onUpPanel(sender, eventType)
  DlgMgr:sendMsg("SystemFunctionDlg", "onFireWorksButton")
end
function FireworksMainDlg:MSG_FIREWORKS_PARTY_INFO(data)
  self:updateShoot(data)
end
return FireworksMainDlg
