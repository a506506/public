local FurnitureInfoDlg = Singleton("FurnitureInfoDlg", Dialog)
local FurnitureInfo = require("cfg/FurnitureInfo")
local BTN_FUNC = {
  [CHS[3002410]] = {normalClick = "onSell"},
  [CHS[7000295]] = {normalClick = "onBaitan"},
  [CHS[3002816]] = {normalClick = "onResource"}
}
local menuMore = {}
local FONT_SIZE = 19
local ITEM_MARGIN = 5
local ART_FONT_SIZE = 19
local MONEY_IMAGE = {
  ResMgr.ui.small_reward_cash,
  ResMgr.ui.small_reward_glod
}
local VOUCHER_IMAGE = ResMgr.ui.small_reward_voucher
local CASH_IMAGE = ResMgr.ui.small_reward_cash
function FurnitureInfoDlg:init()
  self:bindListener("MoreButton", self.onMoreButton)
  self:bindListener("ApplyButton", self.onApplyButton)
  self:bindListener("FurnitureInfoDlg", self.onCloseButton)
  self:bindListener("DepositButton", self.onDepositButton)
  self:bindListener("SourceButton", self.onResource)
  self:bindListener("ResourceButton", self.onResource)
  self:bindListener("LeftButton", self.onLeftButton)
  self:bindListener("RightButton", self.onRightButton)
  self:bindListener("PuttingButton", self.onPuttingButton)
  self:bindListener("SellButton", self.onSell)
  self:bindListener("PreviewButton", self.onPreviewButton)
  self:bindListener("BuyButton", self.onBuyButton)
  self:getControl("MoreButton"):setLocalZOrder(10)
  self.btn = self:getControl("MoreButton"):clone()
  self.btn:retain()
  self.btnLayer = cc.Layer:create()
  self.btnLayer:setAnchorPoint(0, 0)
  self.btnLayer:retain()
  self.furniture = nil
  self.isMore = nil
  self:hookMsg("MSG_INVENTORY")
end
function FurnitureInfoDlg:resetCtrlShowState()
  self:setCtrlVisible("SourceButton", false)
  self:setCtrlVisible("MoreButton", false)
  self:setCtrlVisible("ApplyButton", false)
  self:setCtrlVisible("StorePanel", false)
  self:setCtrlVisible("PuttingButtonPanel", false)
  self:setCtrlVisible("HasFurniturePanel", false)
  self:setCtrlVisible("NoFurniturePanel", false)
  self:setCtrlVisible("LeftButton", false)
  self:setCtrlVisible("RightButton", false)
  self:setCtrlVisible("PriceLabelPanel", false)
  self:setCtrlVisible("LimitLabel", false)
  self:setCtrlVisible("PuttingPanel", false)
  self:setCtrlVisible("BindLabel", false)
end
function FurnitureInfoDlg:setBasicInfo(furniture, isCard, isFromPutting, isNeedHidePrice)
  self.furniture = furniture
  self.isCard = isCard
  self.isFromPutting = isFromPutting
  self:resetCtrlShowState()
  local name = furniture.name
  local type = HomeMgr:getFurnitureType(name)
  local purchaseType = HomeMgr:getPurchaseType(name)
  local purchaseCost = HomeMgr:getPurchaseCost(name)
  local level = HomeMgr:getFurnitureLevel(name)
  local maxDur = HomeMgr:getMaxDur(name)
  local dur = furniture.durability or maxDur
  local comfort = HomeMgr:getFurnitureComfort(name)
  local price = HomeMgr:getFurnitureSellPrice(name)
  local capacity = HomeMgr:getFurnitureCapacity(name)
  self:setImage("ItemImage", ResMgr:getItemIconPath(HomeMgr:getFurnitureIcon(name)))
  self:setItemImageSize("ItemImage")
  if furniture and InventoryMgr:isLimitedItem(furniture) then
    InventoryMgr:addLogoBinding(self:getControl("ItemImage"))
  else
    InventoryMgr:removeLogoBinding(self:getControl("ItemImage"))
  end
  self:setLabelText("NameLabel1", name)
  local levelStr = string.format(CHS[7002359], gf:getChineseNum(level))
  self:setLabelText("NameLabel2", levelStr)
  local typeStr = string.format(CHS[7002361], string.gsub(type, "-", CHS[7002362]))
  self:setLabelText("NameLabel3", typeStr)
  local comfortLabel = string.format(CHS[7002363], comfort)
  self:setLabelText("ComfortLabel", comfortLabel)
  if maxDur then
    local durStr = string.format(CHS[7002360], dur, maxDur)
    self:setLabelText("ComfortLabel_0", durStr)
  else
    self:setLabelText("ComfortLabel_0", CHS[7002367])
  end
  if capacity then
    if not furniture.food_num then
      local durStr = string.format(CHS[4200411], capacity, capacity)
      self:setLabelText("ComfortLabel_0", durStr)
    else
      local durStr = string.format(CHS[4200411], furniture.food_num, furniture.max_food_num)
      self:setLabelText("ComfortLabel_0", durStr)
    end
  end
  local descPanel1 = self:getControl("DescPanel")
  local descPanel2 = self:getControl("SpecialPanel")
  local descPanel1Height = descPanel1:getContentSize().height
  local descPanel2Height = descPanel2:getContentSize().height
  local desc1 = HomeMgr:getFurnitureDesc(name)
  local height1 = self:setDescript(desc1, descPanel1, COLOR3.LIGHT_WHITE)
  descPanel1:setContentSize(descPanel1:getContentSize().width, height1)
  local specialFunc = HomeMgr:getFurnitureSpecialDesc(name)
  local height2 = -2 * ITEM_MARGIN
  if specialFunc then
    local desc2 = string.format(CHS[7002365], specialFunc)
    height2 = self:setDescript(desc2, descPanel2, COLOR3.LIGHT_WHITE)
    self:setCtrlVisible("SeparateImage_2", true)
  else
    self:setCtrlVisible("SeparateImage_2", false)
  end
  descPanel2:setContentSize(descPanel2:getContentSize().width, height2)
  local limitLabelOffset = 0
  if isFromPutting then
    self:setCtrlVisible("PuttingPanel", true)
    local buyImage = self:getControl("BuyImage", nil, "BuyPanel")
    self:setImagePlist("BuyImage", MONEY_IMAGE[purchaseType], "BuyPanel")
    local cost = purchaseCost
    if purchaseType == 1 then
      cost = cost * 10000
    end
    self:setCtrlVisible("NotPanel", false, "BuyPanel")
    self:setCtrlVisible("Panel_58", false, "BuyPanel")
    if cost == 0 then
      self:setColorText(CHS[7003094], "NotPanel", "BuyPanel", nil, nil, nil, ART_FONT_SIZE, true)
      self:setCtrlVisible("NotPanel", true, "BuyPanel")
      buyImage:setVisible(false)
      self:setButtonText("BuyButton", CHS[7002358], "NoFurniturePanel")
    else
      buyImage:setVisible(true)
      self:setCtrlVisible("Panel_58", true, "BuyPanel")
      local costStr, costColor = gf:getArtFontMoneyDesc(cost)
      self:setNumImgForPanel("Panel_58", costColor, costStr, false, LOCATE_POSITION.MID, ART_FONT_SIZE, "BuyPanel")
    end
    local buyImage = self:getControl("BuyImage", nil, "SalePanel")
    if HomeMgr:isFunitureCanGetCashBySell(furniture) then
      self:setImagePlist("BuyImage", CASH_IMAGE, "SalePanel")
    else
      self:setImagePlist("BuyImage", VOUCHER_IMAGE, "SalePanel")
    end
    self:setCtrlVisible("NotPanel", false, "SalePanel")
    self:setCtrlVisible("Panel_58", false, "SalePanel")
    if price == 0 then
      self:setColorText(CHS[7003095], "NotPanel", "SalePanel", nil, nil, nil, ART_FONT_SIZE, true)
      buyImage:setVisible(false)
      self:setCtrlVisible("NotPanel", true, "SalePanel")
    else
      buyImage:setVisible(true)
      self:setCtrlVisible("Panel_58", true, "SalePanel")
      local sellStr, sellColor = gf:getArtFontMoneyDesc(price)
      self:setNumImgForPanel("Panel_58", sellColor, sellStr, false, LOCATE_POSITION.MID, ART_FONT_SIZE, "SalePanel")
    end
  elseif isNeedHidePrice == true then
    self:setCtrlVisible("PriceLabelPanel", false)
    self:setCtrlVisible("LimitLabel", false)
    self:setCtrlVisible("BindLabel", false)
    local hideHeight = self:getControl("PriceLabelPanel"):getContentSize().height + self:getControl("LimitLabel"):getContentSize().height + 3 * ITEM_MARGIN
    limitLabelOffset = -hideHeight
  else
    self:setCtrlVisible("PriceLabelPanel", true)
    self:setCtrlVisible("LimitLabel", true)
    self:setCtrlVisible("BindLabel", true)
    local priceStr
    if price > 0 then
      priceStr = string.format(CHS[7002364], gf:getMoneyDesc(price))
    else
      priceStr = CHS[7002366]
    end
    self:setDescript(priceStr, self:getControl("PriceLabelPanel"), COLOR3.BLUE, true)
    if InventoryMgr:isTimeLimitedItem(furniture) then
      local str, day = gf:converToLimitedTimeDay(furniture.gift)
      self:setLabelText("BindLabel", str)
      local timeLimitStr = string.format(CHS[7000184], gf:getServerDate(CHS[4200022], furniture.deadline))
      self:setLabelText("LimitLabel", timeLimitStr)
      limitLabelOffset = 0 + FONT_SIZE + 10
    elseif InventoryMgr:isLimitedItem(furniture) then
      local str, day = gf:converToLimitedTimeDay(furniture.gift)
      self:setLabelText("BindLabel", str)
      limitLabelOffset = 0
    else
      limitLabelOffset = -FONT_SIZE
    end
  end
  local offset = height1 - descPanel1Height + height2 - descPanel2Height + limitLabelOffset
  local mainPanel = self:getControl("FurnitureInfoDlg")
  mainPanel:setContentSize(mainPanel:getContentSize().width, mainPanel:getContentSize().height + offset)
  self:updateLayout("FurnitureInfoDlg")
  if isCard then
    self:setCtrlVisible("SourceButton", true)
  elseif isFromPutting then
    self:setCtrlVisible("PuttingButtonPanel", true)
  else
    self:setCtrlVisible("MoreButton", true)
    self:setCtrlVisible("ApplyButton", true)
  end
  if isFromPutting then
    local furnitures = self.isFromPutting.furnitures
    local index = self.isFromPutting.index
    if furnitures and #furnitures > 0 then
      self:setCtrlVisible("HasFurniturePanel", true)
      self:setCtrlVisible("LeftButton", index > 1)
      self:setCtrlVisible("RightButton", index < #furnitures)
    else
      self:setCtrlVisible("NoFurniturePanel", true)
    end
  end
  menuMore = self:setMenuMore(isCard)
end
function FurnitureInfoDlg:onMoreButton(sender, eventType)
  if not self.isMore then
    self.isMore = true
    local btnSize = self.btn:getContentSize()
    for i, v in pairs(menuMore) do
      local btn = self.btn:clone()
      btn:setTitleText(tostring(v))
      btn:setPosition(0 + btnSize.width / 2, btnSize.height * i + btnSize.height / 2)
      btn:setVisible(true)
      self.btnLayer:addChild(btn)
      self:bindTouchEndEventListener(btn, function(self, sender, eventType)
        local title = sender:getTitleText()
        if BTN_FUNC[title].normalClick and "function" == type(self[BTN_FUNC[title].normalClick]) then
          self[BTN_FUNC[title].normalClick](self, sender, eventType)
        end
      end)
    end
    self.btnLayer:setPosition(0, 0)
    self.btnLayer:removeFromParent()
    sender:addChild(self.btnLayer)
  else
    self.isMore = false
    self.btnLayer:removeFromParent()
  end
end
function FurnitureInfoDlg:onApplyButton(sender, eventType)
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  if Me:isInCombat() then
    gf:ShowSmallTips(CHS[3002430])
    return
  end
  if HomeMgr:getHouseId() ~= Me:queryBasic("house/id") then
    gf:ShowSmallTips(CHS[7003093])
    return
  end
  if not self.furniture or not self.furniture.name then
    return
  end
  local mainType = HomeMgr:getFurnitureMainTypeByName(self.furniture.name)
  local mapName = MapMgr:getCurrentMapName()
  if not string.match(mapName, mainType) then
    gf:ShowSmallTips(string.format(CHS[7002381], mainType))
    return
  end
  gf:CmdToServer("CMD_HOUSE_TRY_MANAGE", {
    dlg_para = HomeMgr:getFurnitureType(self.furniture.name) .. ":" .. self.furniture.name
  })
  self:onCloseButton()
end
function FurnitureInfoDlg:onDepositButton(sender, eventType)
  local str = self:getLabelText("Label_16", sender)
  if str == CHS[4300070] then
    StoreMgr:cmdBagToStore(self.furniture.pos)
  else
    StoreMgr:cmdStoreToBag(self.furniture.pos)
  end
  self:onCloseButton()
end
function FurnitureInfoDlg:onResource(sender, eventType)
  if not self.furniture then
    gf:ShowSmallTips(CHS[4000321])
    return
  end
  if #InventoryMgr:getRescourse(self.furniture.name) == 0 then
    gf:ShowSmallTips(CHS[4000321])
    return
  end
  local rect = self:getBoundingBoxInWorldSpace(self:getControl("FurnitureInfoDlg"))
  InventoryMgr:openItemRescourse(self.furniture.name, rect)
end
function FurnitureInfoDlg:onSell(sender, eventType)
  if Me:isInTradingShowState() then
    gf:ShowSmallTips(CHS[4300227])
    return
  end
  if self:checkSafeLockRelease("onSell") then
    return
  end
  local name = self.furniture.name
  local pos = self.furniture.pos
  local price = HomeMgr:getFurnitureSellPrice(name)
  local priceStr = gf:getMoneyDesc(price)
  local isForeverLimit = InventoryMgr:isLimitedItemForever(self.furniture)
  local isBagFurniture = InventoryMgr:isBagItemByPos(pos)
  local tip
  if isForeverLimit or not isBagFurniture then
    tip = string.format(CHS[7003092], priceStr, name)
  else
    tip = string.format(CHS[7003091], priceStr, name)
  end
  if price <= 0 then
    gf:ShowSmallTips(CHS[7002382])
    return
  end
  gf:confirm(tip, function()
    gf:sendGeneralNotifyCmd(NOTIFY.SELL_ITEM, pos, 1)
    self:onCloseButton()
  end)
end
function FurnitureInfoDlg:onBaitan(sender, eventType)
  if not DistMgr:checkCrossDist() then
    return
  end
  if InventoryMgr:isLimitedItem(self.furniture) then
    gf:ShowSmallTips(CHS[5000215])
    return
  end
  local meLevel = Me:getLevel()
  if meLevel < MarketMgr:getOnSellLevel() then
    gf:ShowSmallTips(string.format(CHS[3002435], MarketMgr:getOnSellLevel()))
    return
  end
  local furniture = {
    name = self.furniture.name,
    bagPos = self.furniture.pos,
    icon = self.furniture.icon,
    amount = self.furniture.amount,
    level = self.furniture.level,
    detail = self.furniture
  }
  local dlg = DlgMgr:openDlg("MarketSellDlg")
  dlg:setSelectItem(furniture.detail.pos)
  MarketMgr:openSellItemDlg(furniture.detail, 3)
  self:onCloseButton()
end
function FurnitureInfoDlg:setStoreDisplayType()
  if not self.furniture then
    return
  end
  if self.furniture.pos < 200 then
    self:setLabelText("Label_16", CHS[4300070], "DepositButton")
  else
    self:setLabelText("Label_16", CHS[4300071], "DepositButton")
  end
  self:setCtrlVisible("StorePanel", true)
  self:setCtrlVisible("ApplyButton", false)
  self:setCtrlVisible("MoreButton", false)
  self:setCtrlVisible("SourceButton", false)
  self:setCtrlVisible("PuttingButtonPanel", false)
end
function FurnitureInfoDlg:setMenuMore(isCard)
  local menuTab = {}
  if not isCard then
    table.insert(menuTab, CHS[3002410])
    if not InventoryMgr:isLimitedItem(self.furniture) and MarketMgr:isItemCanSell(self.furniture) then
      table.insert(menuTab, CHS[7000295])
    end
    table.insert(menuTab, CHS[3002816])
  end
  return menuTab
end
function FurnitureInfoDlg:setDescript(descript, panel, defaultColor, horInMid)
  panel:removeAllChildren()
  local textCtrl = CGAColorTextList:create()
  if defaultColor then
    textCtrl:setDefaultColor(defaultColor.r, defaultColor.g, defaultColor.b)
  end
  textCtrl:setFontSize(FONT_SIZE)
  textCtrl:setString(descript)
  textCtrl:setContentSize(panel:getContentSize().width, 0)
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  if horInMid then
    textCtrl:setPosition((panel:getContentSize().width - textW) * 0.5, textH)
  else
    textCtrl:setPosition(0, textH)
  end
  panel:addChild(tolua.cast(textCtrl, "cc.LayerColor"))
  return textH
end
function FurnitureInfoDlg:cleanup()
  self.furniture = nil
  if self.btnLayer then
    self.btnLayer:release()
    self.btnLayer = nil
  end
  if self.btn then
    self.btn:release()
    self.btn = nil
  end
end
function FurnitureInfoDlg:onLeftButton()
  if not self.furniture then
    return
  end
  if not self.isFromPutting then
    return
  end
  local furnitures = self.isFromPutting.furnitures
  local index = self.isFromPutting.index
  local targetIndex = index - 1
  self:setBasicInfo(furnitures[targetIndex], false, {furnitures = furnitures, index = targetIndex})
end
function FurnitureInfoDlg:onRightButton()
  if not self.furniture then
    return
  end
  if not self.isFromPutting then
    return
  end
  local furnitures = self.isFromPutting.furnitures
  local index = self.isFromPutting.index
  local targetIndex = index + 1
  self:setBasicInfo(furnitures[targetIndex], false, {furnitures = furnitures, index = targetIndex})
end
function FurnitureInfoDlg:onPuttingButton()
  if not self.furniture or not self.furniture.pos then
    return
  end
  DlgMgr:sendMsg("HomePuttingDlg", "doPutting", self.furniture.pos)
  self:onCloseButton()
end
function FurnitureInfoDlg:onBuyButton()
  if not self.furniture or not self.furniture.name then
    return
  end
  local LuBanFur = HomeMgr:getLuBanFur()
  local name = self.furniture.name
  local cost = HomeMgr:getPurchaseCost(name)
  if cost <= 0 then
    self:onResource()
    return
  end
  local info = FurnitureInfo[name]
  local limit = HomeMgr:getLimitByType(info.furniture_type)
  local amount = 0
  for k, v in pairs(FurnitureInfo) do
    if v.furniture_type == info.furniture_type then
      local items = StoreMgr:getFurnitureByName(k, true)
      for i = 1, #items do
        amount = amount + items[i].amount
      end
    end
  end
  if limit > 0 and limit <= amount then
    gf:ShowSmallTips(CHS[2000334])
    return
  end
  DlgMgr:sendMsg("HomePuttingDlg", "doBuy", self.furniture.name)
  self:onCloseButton()
end
function FurnitureInfoDlg:onPreviewButton()
  if not self.furniture or not self.furniture.name then
    return
  end
  DlgMgr:sendMsg("HomePuttingDlg", "doPreview", self.furniture.name)
  self:onCloseButton()
end
function FurnitureInfoDlg:MSG_INVENTORY(data)
  for i = 1, data.count do
    if not self.furniture or data[i].pos == self.furniture.pos then
      self:onCloseButton()
      return
    end
  end
end
return FurnitureInfoDlg
