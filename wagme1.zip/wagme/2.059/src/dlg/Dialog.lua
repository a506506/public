Dialog = Singleton("Dialog")
local CharAction = require("animate/CharAction")
local CharActionEnd = require("animate/CharActionEnd")
local CharActionEx = require("animate/CharActionEx")
local NumImg = require("ctrl/NumImg")
Dialog.TAG_PORTRAIT = 100
Dialog.TAG_PORTRAIT1 = 101
Dialog.TAG_ACTION_CLOSE = 9999
Dialog.TAG_COLORTEXT_CTRL = 102
Dialog.TAG_NUM_IMG = 111
local ARTS_NUM_FONT_DEFAULT = 25
local BLANK_COLOR = cc.c4b(0, 0, 0, 153)
local CTR_BLANK_TAG = 4000766
local MOVE_DISTANCE = 20
local CHECK_DLG_JSON = gf:gfIsFuncEnabled(FUNCTION_ID.CHECK_DLG_JSON_EXIST)
local DEVICE_NAME = DeviceMgr:getDeviceString()
local LIGHT_EFFECT = require(ResMgr:getCfgPath("LightEffect"))
local IconColorScheme = require(ResMgr:getCfgPath("IconColorScheme.lua"))
local NEED_SHOW_ON_FLOOR = {
  GameFunctionDlg = -1,
  HeadDlg = -1,
  ChatDlg = -1,
  SystemFunctionDlg = -1,
  MissionDlg = -1,
  FightInfDlg = -1,
  FightPetMenuDlg = -1,
  FightPetSkillDlg = -1,
  FightPlayerMenuDlg = -1,
  FightPlayerSkillDlg = -1,
  FightRoundDlg = -1,
  JiuTianBuffDlg = -1,
  FightTargetChoseDlg = -1,
  FightUseResDlg = -1,
  AutoFightSettingDlg = -1,
  CombatViewDlg = -1,
  SkillStatusDlg = -1,
  ScreenRecordingDlg = -1,
  FightLookOnDlg = -1,
  HomeFishingDlg = -1,
  ZhiDuoXingDlg = -1,
  SouxlpSmallDlg = -1,
  KuafjjgnDlg = -1,
  WorldBossLifeDlg = -1,
  VacationTempDlg = -1,
  QuanmPK2InfoDlg = -1,
  QuanmPK2InfoExDlg = -1,
  WenquanDlg = -1,
  FightChildSkillDlg = -1,
  UndergroundMainDlg = -1,
  DaluandouzjmDlg = -1,
  XiulmzDlg = -1,
  YinhrdDlg = -1,
  WatchCentreBattleInterfaceDlg = -1,
  WeddingBarrageDlg = -1,
  CaseSMFJItemDlg = -1,
  HUDBulletScreenDlg = -1,
  FireworksMainDlg = -1,
  FireworksFunctionDlg = -1,
  FireworksCountdownDlg = -1
}
local NO_NEED_TO_DELAY_RED_DOT = {
  ActivitiesDlg = true,
  ZaixqyDlg = true,
  CallBackDlg = true,
  WelfareDlg = true,
  TradingSpotTabDlg = true
}
function Dialog:getCfgFileName()
  local jsonName = ResMgr:getDlgCfg(self.name)
  jsonName = LeitingSdkMgr:get2020whiteJson(jsonName)
  return jsonName
end
function Dialog:hideBlankLayer()
  self.isBlankLayerHide = true
end
function Dialog:setDialogType(isSwallow, isClose)
  if type(isSwallow) == "table" then
    self.isSwallow = isSwallow[1]
    self.isClose = isSwallow[2]
    return
  end
  self.isSwallow = isSwallow
  self.isClose = isClose
end
function Dialog:setDlgZOrder(zorder)
  if self.blank then
    self.blank:setLocalZOrder(zorder)
  end
end
function Dialog:getDlgZOrder()
  if self.blank then
    return self.blank:getLocalZOrder()
  end
end
function Dialog:openForGm()
  if nil == self.isSwallow and nil == self.isClose then
    self:setDialogType(false, true)
  end
  local isSwallow = self.isSwallow
  local isClose = self.isClose
  self.blank = ccui.Layout:create()
  self.blank:setContentSize(Const.WINSIZE.width / Const.UI_SCALE, Const.WINSIZE.height / Const.UI_SCALE)
  if NEED_SHOW_ON_FLOOR[self.name] then
    self.blank:setLocalZOrder(NEED_SHOW_ON_FLOOR[self.name])
  end
  if not isSwallow and not self.isBlankLayerHide then
    local colorLayer = cc.LayerColor:create(BLANK_COLOR)
    colorLayer:setContentSize(self.blank:getContentSize())
    self.blank:addChild(colorLayer)
    self.blank.colorLayer = colorLayer
  end
  local function onDealTouch(sender, event)
    if self:isVisible() then
      if isClose then
        if self.clickOutCallFunc then
          self.clickOutCallFunc(self)
          if self.callFuncOnce then
            self.clickOutCallFunc = nil
            self.callFuncOnce = nil
          end
        end
        if "NpcDlg" == self.name then
          gf:CmdToServer("CMD_CLOSE_MENU", {
            id = self.npc_id
          })
        end
        self:onCloseButtonForGm()
      end
    else
      return false
    end
    return true
  end
  if not gf:getUILayer() then
    local logMsg = {}
    table.insert(logMsg, "error:uiLayer is nil")
    if GameMgr and GameMgr.scene then
      table.insert(logMsg, "curScene:" .. tostring(GameMgr.scene:getType()))
    end
    table.insert(logMsg, tostring(__last_cleanup_top_layer))
    gf:ftpUploadEx(table.concat(logMsg, "\n"))
  end
  if self.blank then
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(not isSwallow)
    listener:registerScriptHandler(onDealTouch, cc.Handler.EVENT_TOUCH_BEGAN)
    local dispatcher = self.blank:getEventDispatcher()
    dispatcher:addEventListenerWithSceneGraphPriority(listener, self.blank)
    gf:getUILayer():addChild(self.blank)
  end
  local cfgFile = self:getCfgFileName()
  if CHECK_DLG_JSON or cc.FileUtils:getInstance():isFileExist(cfgFile) then
    self.root = ccs.GUIReader:getInstance():widgetFromJsonFile(cfgFile)
  end
  if not self.root then
    pcall(function()
      self:close()
    end)
    return
  end
  self:registOnUpdate()
  self.blank:addChild(self.root)
  if DeviceMgr:getUIScale() then
    self:align(ccui.RelativeAlign.centerInParent, DeviceMgr:getUIScale())
  else
    self:align(ccui.RelativeAlign.centerInParent)
  end
  self:bindListener("CloseButton", self.onCloseButtonForGm)
  self:sortAllChildren(self.blank)
end
function Dialog:registOnUpdate()
  if self.onUpdate and "function" == type(self.onUpdate) then
    self.root:scheduleUpdateWithPriorityLua(function(delayTime)
      self:onUpdate(delayTime)
    end, 0)
  end
end
function Dialog:sortAllChildren(ctrl)
  if ctrl and "function" == type(ctrl.sortAllChildren) then
    ctrl:sortAllChildren()
    local childs = ctrl:getChildren()
    for i = 1, #childs do
      self:sortAllChildren(childs[i])
    end
  end
end
function Dialog:open(param)
  if nil == self.isSwallow and nil == self.isClose then
    self:setDialogType(false, true)
  end
  local isSwallow = self.isSwallow
  local isClose = self.isClose
  self.blank = ccui.Layout:create()
  self.blank:setContentSize(Const.WINSIZE.width / Const.UI_SCALE, Const.WINSIZE.height / Const.UI_SCALE)
  if NEED_SHOW_ON_FLOOR[self.name] then
    self.blank:setLocalZOrder(NEED_SHOW_ON_FLOOR[self.name])
  end
  if not isSwallow and not self.isBlankLayerHide then
    local colorLayer = cc.LayerColor:create(BLANK_COLOR)
    colorLayer:setContentSize(self.blank:getContentSize())
    self.blank:addChild(colorLayer)
    self.blank.colorLayer = colorLayer
  end
  local function onDealTouch(sender, event)
    if self:isVisible() then
      if isClose then
        if self.clickOutCallFunc then
          self.clickOutCallFunc(self)
          if self.callFuncOnce then
            self.clickOutCallFunc = nil
            self.callFuncOnce = nil
          end
        end
        if "NpcDlg" == self.name then
          gf:CmdToServer("CMD_CLOSE_MENU", {
            id = self.npc_id
          })
        end
        if DlgMgr:getMutexLevel(self.name) == DlgMgr.DLG_TYPE.NORMAL_NO_EFFECT_FOR_CLICK_BLANK then
        elseif self.onClickBlank and self:onClickBlank() then
        else
          self:onCloseButton(sender)
        end
        if not DlgMgr:isFloatingDlg(self.name) then
          RecordLogMgr:isMeetPlugOrder(self.name .. "_blank")
        end
      end
      if "function" == type(self.onClickOuter) then
        return self.onClickOuter(self)
      end
    else
      return false
    end
    return true
  end
  if not gf:getUILayer() then
    local logMsg = {}
    table.insert(logMsg, "error:uiLayer is nil")
    if GameMgr and GameMgr.scene then
      table.insert(logMsg, "curScene:" .. tostring(GameMgr.scene:getType()))
    end
    table.insert(logMsg, tostring(__last_cleanup_top_layer))
    gf:ftpUploadEx(table.concat(logMsg, "\n"))
  end
  if self.blank then
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(not isSwallow)
    listener:registerScriptHandler(onDealTouch, cc.Handler.EVENT_TOUCH_BEGAN)
    local dispatcher = self.blank:getEventDispatcher()
    dispatcher:addEventListenerWithSceneGraphPriority(listener, self.blank)
    gf:getUILayer():addChild(self.blank)
  end
  local cfgFile = self:getCfgFileName()
  if CHECK_DLG_JSON or cc.FileUtils:getInstance():isFileExist(cfgFile) then
    self.root = ccs.GUIReader:getInstance():widgetFromJsonFile(cfgFile)
  end
  if not self.root then
    pcall(function()
      self:close()
    end)
    return
  end
  if self.onUpdate and "function" == type(self.onUpdate) then
    self.root:scheduleUpdateWithPriorityLua(function(delayTime)
      self:onUpdate(delayTime)
    end, 0)
  end
  self.blank:addChild(self.root)
  if ATM_IS_DEBUG_VER then
    self:refreshDlgNamePanel(true)
    EventDispatcher:addEventListener("CONST.SHOW_DLG_NAME", self.refreshDlgNamePanel, self)
  end
  if DeviceMgr:getUIScale() then
    self:align(ccui.RelativeAlign.centerInParent, DeviceMgr:getUIScale())
  else
    self:align(ccui.RelativeAlign.centerInParent)
  end
  self:bindListener("CloseButton", self.onCloseButton)
  if self.init and "function" == type(self.init) then
    if ATM_IS_DEBUG_VER then
      xpcall(function()
        self:init(param)
      end, __G__TRACKBACK__)
    else
      self:init(param)
    end
  end
  self:sortAllChildren(self.blank)
  self.originPos = {}
  self.originPos.x, self.originPos.y = self.root:getPosition()
  local function loadRedDot()
    local redDotList = RedDotMgr:getRedDotList(self.name)
    local blinkList = RedDotMgr:getBlinkRedDotList(self.name) or {}
    if nil ~= redDotList then
      for v, k in pairs(redDotList) do
        if not self:isTabDlg() or self:getCurSelectCtrlName() ~= k then
          self:addRedDot(k, nil, blinkList[k])
        else
          RedDotMgr:removeOneRedDot(self.name, k, self.root)
        end
      end
    end
  end
  if NO_NEED_TO_DELAY_RED_DOT[self.name] then
    loadRedDot()
  else
    performWithDelay(self.blank, loadRedDot, 0)
  end
  local dlgName, param = AutoWalkMgr:getOpenDlgParam()
  if dlgName and param and dlgName == self.name then
    self:onDlgOpened(param)
    AutoWalkMgr:clearOpenDlgParam()
  end
end
function Dialog:refreshDlgNamePanel(showMiscMsg)
  if not ATM_IS_DEBUG_VER then
    return
  end
  if not self.nameLabel then
    self.nameLabel = ccui.Text:create()
    self.nameLabel:setFontSize(21)
    self.nameLabel:setColor(cc.c3b(255, 0, 0))
    self.nameLabel:setString(self.name)
    self.nameLabel:setAnchorPoint(0, 0)
    self.root:addChild(self.nameLabel)
  end
  if Const.showDlgName then
    self.nameLabel:setVisible(true)
    if showMiscMsg then
      ChatMgr:sendMiscMsg(string.format(CHS[7100161], self.name))
    end
  else
    self.nameLabel:setVisible(false)
  end
end
function Dialog:setClickOutCallBack(func, once)
  self.clickOutCallFunc = func
  self.callFuncOnce = once
end
function Dialog:reopen()
  if self.blank == nil then
    self:open()
  else
    self.blank:stopActionByTag(Dialog.TAG_ACTION_CLOSE)
    local zOrder = self:getDlgZOrder()
    self:setDlgZOrder(zOrder + 1)
    gf:getUILayer():reorderChild(self.blank, zOrder)
    gf:getUILayer():sortAllChildren()
  end
end
function Dialog:isTabDlg()
  return false
end
function Dialog:hookMsg(msg)
  MessageMgr:hook(msg, self, self.name)
end
function Dialog:unhookMsg()
  MessageMgr:unhookByHooker(self.name)
end
function Dialog:removeAllEventListener()
  self:setCloseDlgWhenRefreshUserData(false)
  self:setCloseDlgWhenEnterCombat(false)
end
function Dialog:setVisible(show)
  if self.blank then
    self.blank:setVisible(show)
  end
end
function Dialog:isVisible()
  if nil == self.blank then
    return true
  end
  return self.blank:isVisible()
end
function Dialog:setCtrlVisible(ctrlName, visible, root)
  local ctrl = self:getControl(ctrlName, nil, root)
  if ctrl then
    ctrl:setVisible(visible)
  end
  return ctrl
end
function Dialog:setCtrlFlip(ctrlName, flipX, flipY, root)
  local ctrl = self:getControl(ctrlName, nil, root)
  if flipX ~= nil then
    ctrl:setFlippedX(flipX)
  end
  if flipY ~= nil then
    ctrl:setFlippedY(flipY)
  end
end
function Dialog:getCtrlVisible(ctrlName, root)
  local ctrl = self:getControl(ctrlName, nil, root)
  if ctrl then
    return ctrl:isVisible()
  end
end
function Dialog:setCtrlOnlyEnabled(ctrlName, enabled, root)
  local ctrl = self:getControl(ctrlName, nil, root)
  if ctrl then
    ctrl:setEnabled(enabled)
  end
end
function Dialog:setCtrlEnabled(ctrlName, enabled, root, allowClick, useBright)
  local ctrl = self:getControl(ctrlName, nil, root)
  if ctrl then
    ctrl:setEnabled(enabled or allowClick)
    ctrl.isGray = false
    if not useBright then
      if enabled then
        gf:resetImageView(ctrl)
      else
        gf:grayImageView(ctrl)
        ctrl.isGray = true
      end
    else
      ctrl:setBright(enabled)
    end
  end
  return ctrl
end
function Dialog:getWinSize()
  if not DeviceMgr:getUIScale() then
    local winSize = {
      width = Const.WINSIZE.width,
      height = Const.WINSIZE.height,
      x = 0,
      y = 0,
      ox = 0,
      oy = 0
    }
  end
  return winSize
end
function Dialog:setFullScreen()
  if not DeviceMgr:getUIScale() then
    local winsize = {
      width = Const.WINSIZE.width / Const.UI_SCALE,
      height = Const.WINSIZE.height / Const.UI_SCALE
    }
  end
  self.root:setContentSize(winsize.width, winsize.height)
  self.root:requestDoLayout()
end
function Dialog:setCtrlFullScreen(ctrlName, root)
  if not DeviceMgr:getUIScale() then
    local winsize = {
      width = Const.WINSIZE.width / Const.UI_SCALE,
      height = Const.WINSIZE.height / Const.UI_SCALE
    }
  end
  local panel
  if "string" == type(ctrlName) then
    panel = self:getControl(ctrlName, nil, root)
  else
    panel = ctrlName
  end
  if not panel then
    return
  end
  panel:setContentSize(winsize.width, winsize.height)
  if panel.requestDoLayout then
    panel:requestDoLayout()
  end
end
function Dialog:setCtrlFullClient(ctrlName, root, isKeepSize, dontDoLayout)
  if not DeviceMgr:getUIScale() then
    local winsize = {
      width = Const.WINSIZE.width / Const.UI_SCALE,
      height = Const.WINSIZE.height / Const.UI_SCALE,
      x = 0,
      y = 0,
      ox = 0,
      oy = 0
    }
  end
  local panel
  if "string" == type(ctrlName) then
    panel = self:getControl(ctrlName, nil, root)
  else
    panel = ctrlName
  end
  if not panel then
    return
  end
  if not isKeepSize then
    local curSize = panel:getContentSize()
    panel:setContentSize(winsize.width + winsize.ox * 4, winsize.height + winsize.oy * 4)
    local newSize = panel:getContentSize()
    local cx, cy = panel:getPosition()
    panel:setPosition(cx + (newSize.width - curSize.width) * (panel:getAnchorPoint().x - 0.5), cy + (newSize.height - curSize.height) * (panel:getAnchorPoint().y - 0.5))
  end
  local ox, oy = winsize.y or winsize.x or 0, 0
  ox, oy = ox / Const.UI_SCALE, oy / Const.UI_SCALE
  local x, y = panel:getPosition()
  panel:setPosition(x - ox, y - oy)
  if panel.requestDoLayout and not dontDoLayout then
    panel:requestDoLayout()
  end
end
function Dialog:setCtrlFullClientEx(ctrlName, root, isKeepSize)
  local panel
  if "string" == type(ctrlName) then
    panel = self:getControl(ctrlName, nil, root)
  else
    panel = ctrlName
  end
  if not panel then
    return
  end
  panel:setLayoutType(0)
  local children = panel:getChildren()
  for i = 1, #children do
    if children[i] then
      self:setCtrlFullClient(children[i], nil, isKeepSize, true)
    end
  end
  if panel.requestDoLayout then
    panel:requestDoLayout()
  end
end
function Dialog:align(relativeAlign, offset)
  gf:align(self.root, Const.WINSIZE, relativeAlign)
  local ox, oy = 0, 0
  if offset then
    ox, oy = offset.x or 0, offset.y or 0
  end
  if not DeviceMgr:getUIScale() then
    local winsize = {
      designWidth = Const.WINSIZE.width / Const.UI_SCALE,
      designHeight = Const.WINSIZE.height / Const.UI_SCALE
    }
  end
  if ox < 0 then
    ox = ox - (Const.WINSIZE.width - winsize.designWidth) / 2
  elseif ox > 0 then
    ox = ox + (Const.WINSIZE.width - winsize.designWidth) / 2
  end
  if oy < 0 then
    oy = oy - (Const.WINSIZE.height - winsize.designHeight) / 2
  elseif oy > 0 then
    oy = oy + (Const.WINSIZE.height - winsize.designHeight) / 2
  end
  local pos = cc.p(self.root:getPositionX() + ox, self.root:getPositionY() + oy)
  self:setPosition(pos)
end
function Dialog:setPosition(pos)
  if not self.root then
    return
  end
  self.root:setPosition(pos.x / Const.UI_SCALE, pos.y / Const.UI_SCALE)
end
function Dialog:bindTouchEventListener(ctrl, func, data)
  if not ctrl then
    Log:W("Dialog:bindTouchEventListener no control ")
    return
  end
  local ctrlName = ctrl:getName()
  local function listener(sender, eventType)
    local str = self.name .. ":" .. tostring(ctrlName) .. " receive event:" .. tostring(eventType)
    Log:I(str)
    if eventType == ccui.TouchEventType.began then
      self.beganWaitDlgIsNotOpen = not DlgMgr:isDlgOpened("WaitDlg")
      func(self, sender, eventType)
    elseif eventType == ccui.TouchEventType.ended then
      if self.beganWaitDlgIsNotOpen and DlgMgr:isDlgOpened("WaitDlg") then
        func(self, sender, ccui.TouchEventType.canceled)
        return
      end
      if not self:isVisible() or not sender:isVisible() then
        func(self, sender, ccui.TouchEventType.canceled)
        return
      end
      self:touchEndEventFunc(sender, eventType, ctrl, func, data)
    else
      func(self, sender, eventType)
    end
  end
  ctrl:addTouchEventListener(listener)
end
function Dialog:bindTouchEndEventListener(ctrl, func, data)
  if not ctrl then
    Log:W("Dialog:bindTouchEndEventListener no control ")
    return
  end
  local ctrlName = ctrl:getName()
  local function listener(sender, eventType)
    local str = self.name .. ":" .. tostring(ctrlName) .. " receive event:" .. tostring(eventType)
    Log:I(str)
    if eventType == ccui.TouchEventType.began then
      self.beganWaitDlgIsNotOpen = not DlgMgr:isDlgOpened("WaitDlg")
    elseif eventType == ccui.TouchEventType.ended then
      if self.beganWaitDlgIsNotOpen and DlgMgr:isDlgOpened("WaitDlg") then
        return
      end
      if not self:isVisible() or not sender:isVisible() then
        return
      end
      if sender.isGray then
        gf:grayImageView(sender)
      end
      self:touchEndEventFunc(sender, eventType, ctrl, func, data)
    elseif eventType == ccui.TouchEventType.canceled and sender.isGray then
      gf:grayImageView(sender)
    end
  end
  ctrl:addTouchEventListener(listener)
end
function Dialog:touchEndEventFunc(sender, eventType, ctrl, func, data)
  local ctrlName = ctrl:getName()
  local str = self.name .. ":" .. tostring(ctrlName) .. " receive event:" .. tostring(eventType)
  RecordLogMgr:setOneTouchRecordMemo("clickmouse", str)
  RecordLogMgr:addPosForPosRecordCtrlName(str)
  local isRedDotRemoved = self:removeRedDot(sender)
  if not self:playExtraSound(sender) then
    SoundMgr:playEffect("button")
  end
  if RecordLogMgr.isContinuing then
    local stepInfo = RecordLogMgr:getTiggerStepByDlgName(RecordLogMgr.completeStep)
    if stepInfo and stepInfo.dlgName == self.name and stepInfo.clickCtrlName == ctrlName then
      RecordLogMgr:nextStep()
    end
  end
  local tiggerInfo = RecordLogMgr:getTiggerDataByDlgName(self.name)
  if tiggerInfo and tiggerInfo[ctrlName] and not RecordLogMgr.isContinuing then
    RecordLogMgr:tiggerStart(self.name, ctrlName)
  end
  local marketCheaterCtrl = RecordLogMgr:getMarketCheaterCtrlInfo(self.name)
  if marketCheaterCtrl and marketCheaterCtrl[ctrlName] then
    RecordLogMgr:setMarketCheaterClickTimesData(ctrlName, self.name)
  end
  if sender.doubleClickTips then
    local lastClickTime = sender.lastClickTime or 0
    if gfGetTickCount() - lastClickTime < sender.doubleClickTime then
      if sender.doubleClickTips ~= "" then
        gf:ShowSmallTips(sender.doubleClickTips)
      end
      return
    end
    sender.lastClickTime = gfGetTickCount()
  end
  func(self, sender, eventType, data, isRedDotRemoved)
  self:isMeetPlugOrder(sender)
end
function Dialog:isMeetPlugOrder(sender)
  if not sender.isRecordPlugOrder then
    if sender.switchKey then
      RecordLogMgr:isMeetPlugOrder(sender.switchKey .. "_" .. tostring(sender.isOn))
    elseif self.name then
      RecordLogMgr:isMeetPlugOrder(self.name .. "_" .. sender:getName())
    end
  else
    sender.isRecordPlugOrder = nil
  end
end
function Dialog:setValidClickTime(panelName, timeInterval, tips, root)
  local ctl = self:getControl(panelName, nil, root)
  ctl.doubleClickTips = tips
  ctl.doubleClickTime = timeInterval
end
function Dialog:bindFloatPanelListener(panelName, switchPanelName, switchRoot, cb, isNotSwallow)
  local panel = "string" == type(panelName) and self:getControl(panelName) or panelName
  if not panel then
    return
  end
  panel:setVisible(false)
  local bkPanel = self:getControl("BKPanel") or self.root
  local layout = ccui.Layout:create()
  layout:setContentSize(bkPanel:getContentSize())
  layout:setPosition(bkPanel:getPosition())
  layout:setAnchorPoint(bkPanel:getAnchorPoint())
  local switchPanel = self:getControl(switchPanelName, nil, switchRoot)
  local function touch(touch, event)
    local rect = self:getBoundingBoxInWorldSpace(panel)
    local rect2 = self:getBoundingBoxInWorldSpace(switchPanel)
    local toPos = touch:getLocation()
    local isInRect2 = false
    if switchPanelName and cc.rectContainsPoint(rect2, toPos) then
      isInRect2 = true
    end
    if not cc.rectContainsPoint(rect, toPos) and not isInRect2 and panel:isVisible() then
      panel:setVisible(false)
      if cb then
        cb(self)
      end
      return true
    end
  end
  self.blank:addChild(layout, 10, 100)
  if panel.requestDoLayout then
    panel:requestDoLayout()
  end
  gf:bindTouchListener(layout, touch, nil, isNotSwallow)
end
function Dialog:bindListener(name, func, root, notOnlyEnd)
  if nil == func then
    Log:W("Dialog:bindListener no function.")
    return
  end
  local widget = self:getControl(name, nil, root)
  if nil == widget then
    if name ~= "CloseButton" then
      Log:W("Dialog:bindListener no control " .. name)
    end
    return
  end
  if notOnlyEnd then
    self:bindTouchEventListener(widget, func)
  else
    self:bindTouchEndEventListener(widget, func)
  end
  return widget
end
function Dialog:bindListViewListener(name, func, longTouchCallback, root)
  local listView = self:getControl(name, "ccui.ListView", root)
  if not listView then
    Log:W("Dialog:bindListViewListener no control " .. name)
    return
  end
  local function listener(sender, eventType)
    if eventType == ccui.ListViewEventType.ONSELECTEDITEM_START then
      listView.noCallClickCB = nil
      if longTouchCallback then
        listView.delayAction = performWithDelay(listView, function()
          if GuideMgr:isRunning() then
            return
          end
          listView.delayAction = nil
          listView.noCallClickCB = true
          longTouchCallback(self, sender, eventType)
        end, GameMgr:getLongPressTime())
      end
    elseif eventType == ccui.ListViewEventType.ONSELECTEDITEM_END then
      if listView.delayAction then
        listView:stopAction(listView.delayAction)
        listView.delayAction = nil
      end
      if not listView.noCallClickCB then
        func(self, sender, eventType)
        GuideMgr:touchLongCtrl(self.name, name)
      end
      listView.noCallClickCB = nil
      self:removeRedDot(name, root)
    end
  end
  listView:addEventListener(listener)
end
function Dialog:blindLongPress(name, OneSecondLaterFunc, func, root, isCallTouchEnd, cancelFun)
  local widget
  if type(name) == "string" then
    widget = self:getControl(name, nil, root)
  else
    widget = name
  end
  self:blindLongPressWithCtrl(widget, OneSecondLaterFunc, func, true, isCallTouchEnd, cancelFun)
end
function Dialog:blindLongPressWithCtrl(widget, OneSecondLaterFunc, func, needJudgeCancled, isCallTouchEnd, cancelFun)
  if type(widget) ~= "userdata" then
    return
  end
  if not widget then
    Log:W("Dialog:bindListViewListener no control " .. self.name)
    return
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.began then
      local callFunc = cc.CallFunc:create(function()
        if GuideMgr:isRunning() then
          return
        end
        sender:stopAction(self.longPress)
        self.longPress = nil
        if type(OneSecondLaterFunc) == "function" then
          if needJudgeCancled and not sender:isHighlighted() then
            return
          end
          OneSecondLaterFunc(self, sender, eventType)
        end
      end)
      self.longPress = cc.Sequence:create(cc.DelayTime:create(GameMgr:getLongPressTime()), callFunc)
      sender:runAction(self.longPress)
    elseif eventType == ccui.TouchEventType.ended then
      if self.longPress ~= nil then
        sender:stopAction(self.longPress)
        self.longPress = nil
        if type(func) == "function" then
          GuideMgr:touchLongCtrl(self.name, widget:getName())
          func(self, sender, eventType)
          self:isMeetPlugOrder(sender)
          return
        end
      end
      if isCallTouchEnd and type(func) == "function" then
        func(self, sender, eventType)
        GuideMgr:touchLongCtrl(self.name, widget:getName())
        self:isMeetPlugOrder(sender)
      end
    elseif eventType == ccui.TouchEventType.canceled then
      if self.longPress ~= nil then
        sender:stopAction(self.longPress)
        self.longPress = nil
      end
      if cancelFun and type(cancelFun) == "function" then
        cancelFun(self, sender, eventType)
      end
    end
  end
  widget:addTouchEventListener(listener)
end
function Dialog:bindListViewListenerOneSecond(name, OneSecondLaterFunc, func)
  local listView = self:getControl(name, "ccui.ListView")
  if not listView then
    Log:W("Dialog:bindListViewListener no control " .. name)
    return
  end
  local function listener(sender, eventType)
    if eventType == ccui.ListViewEventType.ONSELECTEDITEM_START then
      local callFunc = cc.CallFunc:create(function()
        if GuideMgr:isRunning() then
          return
        end
        if type(OneSecondLaterFunc) == "function" then
          OneSecondLaterFunc(self, sender, eventType)
        end
        self.root:stopAction(self.longPress)
        self.longPress = nil
      end)
      self.longPress = cc.Sequence:create(cc.DelayTime:create(GameMgr:getLongPressTime()), callFunc)
      self.root:runAction(self.longPress)
    elseif eventType == ccui.ListViewEventType.ONSELECTEDITEM_END and self.longPress ~= nil then
      self.root:stopAction(self.longPress)
      self.longPress = nil
      if type(func) == "function" then
        func(self, sender, eventType)
        GuideMgr:touchLongCtrl(self.name, name)
      end
    end
  end
  listView:addEventListener(listener)
end
function Dialog:bindPressForIntervalCallback(name, t, cb, counterName, root, tag)
  local widget = self:getControl(name, nil, root)
  if not widget then
    Log:W("PartyShopDlg:bindPress no control " .. name)
    return
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.began then
      self[counterName] = 1
      schedule(widget, function()
        cb(self, sender:getName(), self[counterName], widget, eventType, tag)
        self[counterName] = self[counterName] + 1
      end, t)
    elseif eventType == ccui.TouchEventType.moved then
    else
      cb(self, sender:getName(), self[counterName], widget, eventType, tag)
      widget:stopAllActions()
      if widget.isGray then
        gf:grayImageView(widget)
      end
    end
  end
  widget:addTouchEventListener(listener)
end
function Dialog:getControl(name, widgetType, root)
  local widget
  if not name then
    return
  end
  if type(root) == "string" then
    root = self:getControl(root, "ccui.Widget")
    widget = ccui.Helper:seekWidgetByName(root, name)
  else
    root = root or self.root
    widget = ccui.Helper:seekWidgetByName(root, name)
  end
  return widget
end
function Dialog:getInputText(name, root)
  local textField = self:getControl(name, Const.UITextField, root)
  if textField == nil then
    return ""
  else
    return textField:getStringValue()
  end
end
function Dialog:setInputText(name, text, root, color3)
  local ctl = self:getControl(name, Const.UITextField, root)
  if nil ~= ctl and text ~= nil then
    ctl:setText(tostring(text))
    if color3 then
      ctl:setColor(color3)
    end
  end
end
function Dialog:setButtonText(name, text, root)
  local ctl = self:getControl(name, Const.UIButton, root)
  if nil ~= ctl and text ~= nil then
    ctl:setTitleText(tostring(text))
  end
end
function Dialog:getButtonText(name, root)
  local ctl = self:getControl(name, Const.UIButton, root)
  if nil ~= ctl then
    return ctl:getTitleText()
  end
end
function Dialog:getCtrlContentSize(name, root)
  local ctl = self:getControl(name, nil, root)
  if nil ~= ctl then
    return ctl:getContentSize()
  end
end
function Dialog:setCtrlOpacity(name, opacity, root)
  local ctl = self:getControl(name, nil, root)
  if nil ~= ctl then
    ctl:setOpacity(opacity)
  end
  return ctl
end
function Dialog:setCtrlContentSize(name, w, h, root, addX, addY)
  local ctl = self:getControl(name, nil, root)
  if nil ~= ctl then
    w = w or ctl:getContentSize().width
    h = h or ctl:getContentSize().height
    addX = addX or 0
    addY = addY or 0
    ctl:setContentSize(w + addX, h + addY)
    local parentPanel = ctl:getParent()
    if parentPanel and parentPanel.requestDoLayout and type(parentPanel.requestDoLayout) == "function" then
      parentPanel:requestDoLayout()
    end
  end
  return ctl
end
function Dialog:setLabelText(name, text, root, color3)
  local ctl = self:getControl(name, Const.UILabel, root)
  if nil ~= ctl and text ~= nil then
    ctl:setString(tostring(text))
    if color3 then
      ctl:setColor(color3)
    end
  end
  if ctl then
    local parentPanel = ctl:getParent()
    if parentPanel and parentPanel.requestDoLayout and type(parentPanel.requestDoLayout) == "function" then
      parentPanel:requestDoLayout()
    end
    return ctl
  end
end
function Dialog:setCtrlColor(name, color3, root)
  local ctrl = self:getControl(name, Const.UILabel, root)
  if ctrl and color3 then
    ctrl:setColor(color3)
  end
end
function Dialog:getLabelText(name, root)
  local ctl = self:getControl(name, Const.UILabel, root)
  if nil ~= ctl then
    local text = ctl:getString()
    return text
  end
end
function Dialog:setProgressBarByHourglass(name, hourglass, startValue, fun, root, isOpposite)
  local bar = self:getControl(name, Const.UIProgressBar, root)
  if not bar then
    return
  end
  if startValue then
    bar:setPercent(startValue)
  else
    startValue = bar:getPercent()
  end
  if hourglass <= 0 then
    return
  end
  local startTime = gfGetTickCount()
  local elapseTime = hourglass - hourglass * startValue / 100
  schedule(bar, function()
    local curTime = gfGetTickCount() - startTime
    local value = curTime / hourglass * 100
    if isOpposite then
      value = (hourglass - curTime - elapseTime) / hourglass * 100
    end
    if value > 100 then
      value = 100
    elseif value < 0 then
      value = 0
    end
    bar:setPercent(value)
    if curTime >= hourglass then
      bar:stopAllActions()
      if fun then
        fun()
      end
    end
  end, 0)
end
function Dialog:setProgressBarByHourglassToEnd(name, hourglass, startValue, endValue, fun, root, updateFunc)
  local bar = self:getControl(name, Const.UIProgressBar, root)
  if not bar then
    return
  end
  bar:setPercent(startValue)
  if hourglass <= 0 then
    return
  end
  local startTime = gfGetTickCount()
  local elapseTime = hourglass
  schedule(bar, function()
    local curTime = gfGetTickCount() - startTime
    local value = curTime / hourglass * (endValue - startValue) + startValue
    if startValue < endValue then
      if value > endValue then
        value = endValue
      elseif value < 0 then
        value = 0
      end
    elseif value < endValue then
      value = endValue
    elseif value < 0 then
      value = 0
    end
    bar:setPercent(value)
    if "function" == type(updateFunc) then
      updateFunc(value)
    end
    if curTime >= hourglass then
      bar:stopAllActions()
      if fun then
        fun()
      end
    end
  end, 0)
  return bar
end
function Dialog:setProgressBar(name, val, max, root, color, isGrow, func)
  local bar = self:getControl(name, Const.UIProgressBar, root)
  if not bar then
    return
  end
  local function grow(desValue)
    local curValue = bar:getPercent() + 1.5
    if curValue > math.min(100, desValue * 100 / max) then
      bar:stopAllActions()
      bar:setPercent(math.min(100, desValue * 100 / max))
      if func then
        performWithDelay(bar, function()
          func()
        end, 0.05)
      end
    else
      bar:setPercent(curValue)
    end
  end
  if max == nil or val == nil or max == 0 or val < 0 then
    bar:setPercent(0)
    if func then
      func()
    end
  elseif isGrow then
    if val == 0 then
      val = max
    end
    schedule(bar, function()
      grow(val)
    end, 0.001)
  else
    bar:stopAllActions()
    bar:setPercent(math.min(100, val * 100 / max))
    if func then
      func()
    end
  end
  if color ~= nil then
    bar:setColor(color)
  end
  return bar
end
function Dialog:setProgressBarColor(name, color, root)
  local bar = self:getControl(name, Const.UIProgressBar, root)
  if bar == nil then
    return
  end
  bar:setColor(color)
end
function Dialog:setImage(name, path, root, noAuto)
  if path == nil or string.len(path) == 0 then
    return
  end
  local img = self:getControl(name, Const.UIImage, root)
  if img then
    img:loadTexture(path)
  end
  if not noAuto and img then
    local parentPanel = img:getParent()
    if parentPanel and parentPanel.requestDoLayout and type(parentPanel.requestDoLayout) == "function" then
      parentPanel:requestDoLayout()
    end
  end
  return img
end
function Dialog:setImagePlist(name, path, root)
  if path == nil or string.len(path) == 0 then
    return
  end
  local sp = cc.SpriteFrameCache:getInstance():getSpriteFrame(path)
  if not sp then
    Log:D("!!!!!!not spriteFrameCache !!!!!! path: " .. path)
    return
  end
  local img = self:getControl(name, Const.UIImage, root)
  if img then
    img:loadTexture(path, ccui.TextureResType.plistType)
  end
  if img then
    local parentPanel = img:getParent()
    if parentPanel and parentPanel.requestDoLayout and type(parentPanel.requestDoLayout) == "function" then
      parentPanel:requestDoLayout()
    end
    return img
  end
end
function Dialog:setImageSize(name, size, root)
  local img = self:getControl(name, Const.UIImage, root)
  if img then
    img:ignoreContentAdaptWithSize(false)
    img:setContentSize(size)
  end
end
function Dialog:setPanelPlist(name, path, root)
  if path == nil or string.len(path) == 0 then
    return
  end
  local sp = cc.SpriteFrameCache:getInstance():getSpriteFrame(path)
  if not sp then
    Log:D("!!!!!!not spriteFrameCache !!!!!! path: " .. path)
    return
  end
  local img = self:getControl(name, Const.UIImage, root)
  if img then
    img:setBackGroundImage(path, ccui.TextureResType.plistType)
  end
  if img then
    local parentPanel = img:getParent()
    if parentPanel and parentPanel.requestDoLayout and type(parentPanel.requestDoLayout) == "function" then
      parentPanel:requestDoLayout()
    end
    return img
  end
end
function Dialog:bindPageViewAndPageTag(pageView, pageTag, pageChangeCallBack)
  if nil == pageView or nil == pageTag then
    return
  end
  local idx = pageView:getCurPageIndex()
  pageTag:setPage(idx + 1)
  pageView:addEventListener(function(sender, eventType)
    idx = pageView:getCurPageIndex()
    if pageTag:getPage() == idx + 1 then
      return
    end
    pageTag:setPage(idx + 1)
    if pageChangeCallBack then
      pageChangeCallBack(self, idx + 1)
    end
  end)
end
function Dialog:bindCheckBoxListener(ctrlName, func, root)
  local ctrl = self:getControl(ctrlName, Const.UICheckBox, root)
  if not ctrl then
    Log:W("Dialog:ctrl no control " .. ctrlName)
    return
  end
  self:bindCheckBoxWidgetListener(ctrl, func)
end
function Dialog:bindCheckBoxWidgetListener(widget, func)
  if not widget then
    Log:W("Dialog:bindCheckBoxWidgetListener no control ")
    return
  end
  local function listener(sender, eventType)
    SoundMgr:playEffect("button")
    func(self, sender, eventType)
    if self.name then
      RecordLogMgr:isMeetPlugOrder(self.name .. "_" .. sender:getName() .. "_" .. eventType)
    end
  end
  widget:addEventListener(listener)
end
function Dialog:bindSliderListener(ctrlName, func, root)
  local ctrl = self:getControl(ctrlName, Const.UISlider, root)
  if not ctrl then
    Log:W("Dialog:ctrl no control " .. ctrlName)
    return
  end
  local function listener(sender, eventType)
    func(self, sender, eventType)
  end
  ctrl:addEventListener(listener)
end
function Dialog:doSomeDlgClose()
  local numDlgs = DlgMgr:getNumDlgsCgf()
  for dName, _ in pairs(numDlgs) do
    local dlg = DlgMgr:getDlgByName(dName)
    if dlg and dlg.obj and DlgMgr:getDlgByName(dlg.obj.name) then
    else
      DlgMgr:closeDlg(dName)
    end
  end
end
function Dialog:closeForGm(now, notCloseInputNumDlg)
  if nil ~= self.root then
    self.root:removeFromParent()
    self.root = nil
  end
  if nil ~= self.blank then
    self.blank:removeFromParent()
    self.blank = nil
  end
  if not notCloseInputNumDlg then
    self:doSomeDlgClose()
  end
  DlgMgr:clearDlg(self.name)
end
function Dialog:close(now, notCloseInputNumDlg)
  local function closeNow()
    GuideMgr:removeCurGuidListCtrl(self.name)
    RedDotMgr:removeRelativeDlg(self.name)
    SafeLockMgr:removeContinueCbByModule(self.name)
    if self.cleanup and "function" == type(self.cleanup) then
      self:cleanup()
    end
    self:unhookMsg()
    self:removeAllEventListener()
    if ATM_IS_DEBUG_VER then
      self.nameLabel = nil
      EventDispatcher:removeEventListener("CONST.SHOW_DLG_NAME", self.refreshDlgNamePanel, self)
    end
    assert(self.name, "nil == self.name")
    assert(self.name == self.__cls_type__, string.format("self.name(%s) != self.__cls_type__(%s)", tostring(self.name), tostring(self.__cls_type__)))
    DlgMgr:clearDlg(self.name)
    self:showDlgsWhenOpenHide()
    if nil ~= self.root then
      self.root:removeFromParent()
      self.root = nil
    end
    if nil ~= self.blank then
      self.blank:removeFromParent()
      self.blank = nil
    end
    self:releaseCtrls()
    if not notCloseInputNumDlg then
      self:doSomeDlgClose()
    end
  end
  BlogMgr:cleanAutoLoad(self.name)
  closeNow()
end
function Dialog:getIconKey(icon, weaponIcon)
  return gf:getIconKey(icon, weaponIcon)
end
function Dialog:setPortrait(panelName, icon, weapon, root, showAttackByClick, action, func, offPos, orgIcon, syncLoad, dir, pTag, extend, partIndex, partColorIndex, petIcon, gatherIcons, gatherPartIndex, gatherPartColorIndex)
  local argList = {
    panelName = panelName,
    icon = icon,
    weapon = weapon,
    root = root,
    action = action,
    clickCb = func,
    offPos = offPos,
    orgIcon = orgIcon,
    syncLoad = syncLoad,
    dir = dir,
    pTag = pTag,
    extend = extend,
    partIndex = partIndex,
    partColorIndex = partColorIndex,
    petIcon = petIcon,
    gatherIcons = gatherIcons,
    gatherPartIndex = gatherPartIndex,
    gatherPartColorIndex = gatherPartColorIndex
  }
  if showAttackByClick then
    if type(showAttackByClick) == "string" then
      argList.showActionByClick = showAttackByClick
    else
      argList.showActionByClick = "attack"
    end
  end
  return self:setPortraitByArgList(argList)
end
function Dialog:setPortraitByArgList(argList)
  local panelName = argList.panelName
  local icon = argList.icon or 0
  local weapon = argList.weapon or 0
  local root = argList.root
  local showActionByClick = argList.showActionByClick
  local action = argList.action or Const.SA_STAND
  local clickCb = argList.clickCb
  local offPos = argList.offPos or cc.p(0, -36)
  local orgIcon = argList.orgIcon
  local syncLoad = argList.syncLoad
  local dir = argList.dir or 5
  local petIcon = argList.petIcon or 0
  local pTag = argList.pTag
  local extend = argList.extend
  local partIndex = argList.partIndex
  local partColorIndex = argList.partColorIndex
  local gatherIcons = argList.gatherIcons
  local scheme = gf:getIconScheme(icon, weapon)
  local gatherPartIndex = argList.gatherPartIndex
  local gatherPartColorIndex = argList.gatherPartColorIndex
  if scheme and string.isNilOrEmpty(partIndex) and string.isNilOrEmpty(partColorIndex) then
    partIndex = gf:getPartIndexByIcon(icon, weapon)
    partColorIndex = gf:getPartColorIndexByIcon(icon, weapon)
    icon = scheme.org_icon or icon
    weapon = 0
  elseif petIcon > 0 then
    weapon = 0
  end
  if gf:isCharExist(icon) == false and not pTag then
    icon = 6005
    weapon = 0
    partIndex = gf:getPartIndexByIcon(icon, weapon)
    partColorIndex = gf:getPartColorIndexByIcon(icon, weapon)
  end
  local panel = panelName
  if type(panelName) == "string" then
    panel = self:getControl(panelName, nil, root)
  end
  if panel == nil then
    return
  end
  local size = panel:getContentSize()
  local char = panel:getChildByTag(pTag or Dialog.TAG_PORTRAIT)
  if icon == nil or icon == 0 then
    if nil ~= char then
      char:removeFromParent()
    end
    return
  end
  if nil == char then
    if extend then
      char = CharActionEx.new(syncLoad)
    elseif action and action == Const.SA_DIE then
      char = CharActionEnd.new()
    else
      char = CharAction.new(syncLoad)
    end
    panel:addChild(char, 0, pTag or Dialog.TAG_PORTRAIT)
  end
  if orgIcon then
    char.orgIcon = orgIcon
  end
  if action and action == Const.SA_DIE then
    char:set(icon, weapon, action, dir, partIndex)
  else
    char:set(icon, weapon, action, dir, petIcon, gatherIcons, nil, partIndex, partColorIndex, gatherPartIndex, gatherPartColorIndex)
  end
  local function setPos()
    if nil ~= offPos then
      local contentSize = panel:getContentSize()
      local basicX = contentSize.width / 2 + offPos.x
      local basicY = contentSize.height / 2 + offPos.y
      char:setPosition(basicX, basicY)
    else
      gf:align(char, size, ccui.RelativeAlign.centerInParent)
    end
  end
  if showActionByClick then
    self:bindTouchEndEventListener(panel, function(...)
      if showActionByClick == "attack" then
        char:playActionOnce(function()
          setPos()
        end)
      elseif showActionByClick == "attackOrCast" then
        char:playActionOnce(function()
          setPos()
        end, math.random(1, 2) == 1 and Const.SA_ATTACK or Const.SA_CAST)
      elseif showActionByClick == "walk" then
        if char.action == Const.SA_WALK then
          return
        end
        char:playWalkThreeTimes(function()
          setPos()
        end)
      end
      setPos()
      if clickCb then
        clickCb(...)
      end
    end)
  end
  setPos()
  return char
end
function Dialog:removePortrait(panelName, root, tag)
  local panel = self:getControl(panelName, nil, root)
  if panel == nil then
    return
  end
  if not tag then
    panel:removeChildByTag(Dialog.TAG_PORTRAIT)
    panel:removeChildByTag(Dialog.TAG_PORTRAIT1)
  else
    panel:removeChildByTag(tag)
  end
end
function Dialog:setListViewTop(ctrlName, root, margin, isNotDelay)
  local list = self:getControl(ctrlName, Const.UIListView, root)
  local items = list:getItems()
  local height = 0
  margin = margin or 0
  for k, panel in pairs(items) do
    height = height + panel:getContentSize().height
  end
  height = height + (#items - 1) * margin
  if height <= list:getContentSize().height then
    return
  end
  if isNotDelay then
    list:getInnerContainer():setPositionY(list:getContentSize().height - height)
    list:requestDoLayout()
  else
    performWithDelay(self.root, function()
      list:getInnerContainer():setPositionY(list:getContentSize().height - height)
      list:requestDoLayout()
    end, 0)
  end
end
function Dialog:setCtrlTouchEnabled(ctrlName, enable, root)
  local ctrl = self:getControl(ctrlName, nil, root)
  if ctrl then
    ctrl:setTouchEnabled(enable)
  end
end
function Dialog:resetListView(name, margin, gravity, root, notBounce)
  margin = margin or 0
  gravity = gravity or ccui.ListViewGravity.left
  local list = self:getControl(name, Const.UIListView, root)
  if nil == list then
    return
  end
  list:removeAllItems()
  list:setGravity(gravity)
  list:setTouchEnabled(true)
  list:setItemsMargin(margin)
  list:setClippingEnabled(true)
  list:setBounceEnabled(not notBounce)
  list:setInnerContainerSize(cc.size(0, 0))
  if GuideMgr:isRunning() then
    if nil == list.direct then
      list.direct = list:getDirection()
    end
    GuideMgr:addCurGuidListCtrl(self.name, list)
  elseif list.direct then
    list:setDirection(list.direct)
    list.direct = nil
  end
  local size = list:getContentSize()
  return list, size
end
function Dialog:getListViewSelectedItem(listView)
  if not listView then
    return
  end
  local index = listView:getCurSelectedIndex()
  local item = listView:getItem(index)
  return item
end
function Dialog:getListViewSelectedItemTag(listView)
  local item = self:getListViewSelectedItem(listView)
  if not item then
    return 0
  end
  return item:getTag()
end
function Dialog:popupMenus(menuList, rect)
  local menuDlg = DlgMgr:openDlg("MenuDlg")
  menuDlg:setMenus(menuList, self.name)
  rect = rect or {
    x = GameMgr.curTouchPos.x,
    y = GameMgr.curTouchPos.y,
    width = 5,
    height = 5
  }
  menuDlg:setFloatingFramePos(rect)
end
function Dialog:closeMenuDlg()
  DlgMgr:closeDlg("MenuDlg")
end
function Dialog:updateLayout(name, root)
  local panel = self:getControl(name, Const.UIPanel, root)
  if nil ~= panel then
    panel:requestDoLayout()
  end
end
function Dialog:setCheck(checkBox, isCheck, root)
  local ctl = self:getControl(checkBox, Const.UICheckBox, root)
  if ctl == nil then
    return
  end
  if type(isCheck) == "number" then
    isCheck = isCheck ~= 0
  end
  ctl:setSelectedState(isCheck)
end
function Dialog:isCheck(checkBox, root)
  local ctl = self:getControl(checkBox, Const.UICheckBox, root)
  if ctl == nil then
    return
  end
  return ctl:getSelectedState()
end
function Dialog:getBoundingBoxInWorldSpace(node)
  if not node then
    return
  end
  local rect = node:getBoundingBox()
  local pt = node:convertToWorldSpace(cc.p(0, 0))
  rect.x = pt.x
  rect.y = pt.y
  rect.width = rect.width * Const.UI_SCALE
  rect.height = rect.height * Const.UI_SCALE
  return rect
end
function Dialog:setFloatingFramePos(rect)
  if not self.root then
    return
  end
  if not rect then
    self:align(ccui.RelativeAlign.centerInParent)
    return
  end
  local x = rect.x + rect.width * 0.5
  local y = rect.y + rect.height * 0.5
  local dlgSize = self.root:getContentSize()
  dlgSize.width = dlgSize.width * Const.UI_SCALE
  dlgSize.height = dlgSize.height * Const.UI_SCALE
  local ap = self.root:getAnchorPoint()
  self.root:setAnchorPoint(0, 0)
  local posX, posY, isUp
  if x < Const.WINSIZE.width * 0.5 then
    if y > Const.WINSIZE.height * 0.5 then
      posX = rect.x + rect.width
      posY = rect.y - dlgSize.height
      isUp = false
    else
      posX = rect.x + rect.width
      posY = rect.y + rect.height
      isUp = true
    end
  elseif y > Const.WINSIZE.height * 0.5 then
    posX = rect.x - dlgSize.width
    posY = rect.y - dlgSize.height
    isUp = false
  else
    posX = rect.x - dlgSize.width
    posY = rect.y + rect.height
    isUp = true
  end
  local winSize = self:getWinSize()
  if isUp then
    if posY + dlgSize.height > winSize.oy + winSize.height then
      posY = Const.WINSIZE.height - dlgSize.height - 20 * Const.UI_SCALE
    end
  elseif posY < winSize.oy then
    posY = 20 * Const.UI_SCALE + winSize.oy
  end
  if posX < winSize.ox then
    posX = winSize.ox + 20 * Const.UI_SCALE
  elseif posX + dlgSize.width > winSize.width + winSize.ox then
    posX = winSize.width + winSize.ox - 20 * Const.UI_SCALE - dlgSize.width
  end
  self:setPosition(cc.p(posX, posY))
end
function Dialog:setCtrGrayAndTouchEnbel(name, isTouch)
  local ctr = self:getControl(name)
  if ctr == nil then
    return
  end
  local grayLayer = ctr:getChildByTag(CTR_BLANK_TAG)
  if nil == grayLayer then
    grayLayer = cc.LayerColor:create(BLANK_COLOR)
    grayLayer:setContentSize(ctr:getContentSize())
    grayLayer:setTag(CTR_BLANK_TAG)
    ctr:addChild(grayLayer)
  end
  if isTouch ~= nil then
    ctr:setEnabled(isTouch)
  else
    ctr:setEnabled(false)
  end
end
function Dialog:setCtrGrayAndTouchEnbelByCtrl(ctrl, isTouch)
  if ctrl == nil then
    return
  end
  local grayLayer = ctrl:getChildByTag(CTR_BLANK_TAG)
  if nil == grayLayer then
    grayLayer = cc.LayerColor:create(BLANK_COLOR)
    grayLayer:setContentSize(ctrl:getContentSize())
    grayLayer:setTag(CTR_BLANK_TAG)
    ctrl:addChild(grayLayer)
  end
  if isTouch ~= nil then
    ctrl:setEnabled(isTouch)
  else
    ctrl:setEnabled(false)
  end
end
function Dialog:removeCtrGrayAndTouchEnbel(name, isTouch)
  local ctr = self:getControl(name)
  if ctr == nil then
    return
  end
  local grayLayer = ctr:getChildByTag(CTR_BLANK_TAG)
  if grayLayer ~= nil then
    grayLayer:removeFromParent()
  end
  if isTouch ~= nil then
    ctr:setEnabled(isTouch)
  else
    ctr:setEnabled(true)
  end
end
function Dialog:removeCtrGrayAndTouchEnbelByCtrl(ctrl, isTouch)
  if ctrl == nil then
    return
  end
  local grayLayer = ctrl:getChildByTag(CTR_BLANK_TAG)
  if grayLayer ~= nil then
    grayLayer:removeFromParent()
  end
  if isTouch ~= nil then
    ctrl:setEnabled(isTouch)
  else
    ctrl:setEnabled(true)
  end
end
function Dialog:addSliderMoveFun(name, func, panel)
  local slider = self:getControl(name, Const.UISlider, panel)
  if slider == nil then
    return
  end
  local function listener(sender, eventType)
    func(self, sender, eventType)
  end
  slider:addEventListener(listener)
end
function Dialog:getSliderPercent(name, panel)
  local slider = self:getControl(name, Const.UISlider, panel)
  if slider == nil then
    return
  end
  return slider:getPercent()
end
function Dialog:setSliderPercent(name, percent, panel)
  local slider = self:getControl(name, Const.UISlider, panel)
  if slider == nil then
    return
  end
  return slider:setPercent(percent)
end
function Dialog:addMagic(name, icon, param)
  local ctrl
  if type(name) == "string" then
    ctrl = self:getControl(name)
  elseif type(name) == "userdata" then
    ctrl = name
  end
  if nil == ctrl then
    return
  end
  local magic
  if ctrl:getChildByTag(icon) then
    return
  end
  if param and param.callBack then
    magic = gf:createCallbackMagic(icon, param.callback, param.extraPara)
  elseif param and param.isOnce then
    magic = gf:createSelfRemoveMagic(icon, param.extraPara)
  else
    magic = gf:createLoopMagic(icon, nil, param and param.extraPara)
  end
  ctrl:addChild(magic)
  magic:setTag(icon)
  gf:align(magic, ctrl:getContentSize(), ccui.RelativeAlign.centerInParent)
  return magic
end
function Dialog:resetRootPos()
  if self.originPos then
    self.root:stopAllActions()
    self.root:setPosition(self.originPos)
  end
end
function Dialog:removeMagic(name, icon)
  local ctrl
  if type(name) == "string" then
    ctrl = self:getControl(name)
  elseif type(name) == "userdata" then
    ctrl = name
  end
  if nil == ctrl then
    return
  end
  if ctrl:getChildByTag(icon) then
    ctrl:removeChildByTag(icon)
  end
end
function Dialog:getSelectItemBox(type)
  return nil
end
function Dialog:addRedDot(name, root, isBlink)
  local ctrl
  local realName = ""
  if "string" == type(name) then
    ctrl = self:getControl(name, nil, root)
    if nil == ctrl then
      return
    end
    realName = name
  elseif "userdata" == type(name) then
    ctrl = name
    realName = ctrl:getName()
  end
  if nil == self.redDotList then
    self.redDotList = {}
  end
  if self.onCheckAddRedDot and type(self.onCheckAddRedDot) == "function" and not self:onCheckAddRedDot(realName) then
    RedDotMgr:removeOneRedDot(self.name, realName, self.root)
    return
  end
  gf:setCtrlRedDot(ctrl)
  if isBlink then
    gf:setRedDotBlink(ctrl)
  end
  if self.RED_DOT_SCALE then
    gf:setRedDotScale(ctrl, self.RED_DOT_SCALE)
  end
  ctrl.hasRedDot = true
  self.redDotList[realName] = name
end
function Dialog:removeRedDot(name, root)
  local ctrl
  local realName = ""
  if "string" == type(name) then
    ctrl = self:getControl(name, nil, root)
    if nil == ctrl then
      return
    end
    realName = name
  elseif "userdata" == type(name) then
    ctrl = name
    realName = ctrl:getName()
  end
  if not ctrl.hasRedDot then
    return
  end
  if nil == self.redDotList then
    self.redDotList = {}
  end
  gf:removeCtrlRedDot(ctrl, true)
  self.redDotList[realName] = nil
  if not self.name then
    return
  end
  RedDotMgr:removeOneRedDot(self.name, realName, root)
  ctrl.hasRedDot = false
  return true
end
function Dialog:getCurScrollPercent(name, isVertical, root)
  local listView = self:getControl(name, Const.UIListView, root)
  local listViewSize = listView:getContentSize()
  if not listView then
    return 0
  end
  if isVertical then
    local minY = listViewSize.height - listView:getInnerContainer():getContentSize().height
    local h = -1 * minY
    local curPosY = listView:getInnerContainer():getPositionY()
    if h == 0 then
      return 0
    end
    return (curPosY - minY) / h * 100
  else
    local minX = listViewSize.width - listView:getInnerContainer():getContentSize().width
    local h = -1 * minX
    local curPosX = listView:getInnerContainer():getPositionX()
    if h == 0 then
      return 0
    end
    return (curPosX - minX) / h * 100
  end
end
function Dialog:setListJumpItem(listView, index, sender)
  local items = listView:getItems()
  if not index then
    for _, panel in pairs(items) do
      if panel == sender then
        index = _
      end
    end
  end
  if index > #items then
    return
  end
  local sz = listView:getContentSize()
  local innerContainer = listView:getInnerContainer()
  local innerSz = innerContainer:getContentSize()
  if innerSz.height <= sz.height then
    return
  end
  local positionY = -(#items - index) * items[1]:getContentSize().height
  innerContainer:setPositionY(positionY)
end
function Dialog:removeAllRedDot()
  if nil == self.redDotList then
    self.redDotList = {}
  end
  for k, v in pairs(self.redDotList) do
    self:removeRedDot(v)
  end
  self.redDotList = {}
  RedDotMgr:removeDlgRedDot(self.name)
end
function Dialog:onDlgOpened(param)
end
function Dialog:playExtraSound(sender)
  return false
end
function Dialog:createEditBox(name, root, returnType, func)
  local function editBoxListner(event, sender)
    if func ~= nil then
      func(self, event, sender)
    end
    if "ended" == event then
      SoundMgr:postEditing()
    end
  end
  local backSprite = cc.Scale9Sprite:create(ResMgr.ui.editBox_back)
  backSprite:setOpacity(0)
  local panel = self:getControl(name, nil, root)
  local editBox = cc.EditBox:create(panel:getContentSize(), backSprite)
  editBox:registerScriptEditBoxHandler(editBoxListner)
  editBox:setReturnType(returnType or cc.KEYBOARD_RETURNTYPE_DEFAULT)
  editBox:setAnchorPoint(0, 0.5)
  editBox:setPosition(5, panel:getContentSize().height / 2)
  editBox:setName("EditBox")
  local cfg = DeviceMgr:getUIScale()
  if cfg and "function" == type(editBox.setMargin) then
    editBox:setMargin(cfg.ebLeftMargin, cfg.ebRightMargin)
  end
  panel:addChild(editBox)
  editBox:needsLayout()
  return editBox
end
function Dialog:createColorTextByLabel(panelName, root, labelName, align)
  labelName = labelName or "Label"
  local panel = self:getControl(panelName, nil, root)
  local label = self:getControl(labelName, nil, panel)
  self:setColorTextEx(label:getString(), panel, label:getColor(), label:getFontSize(), align)
end
function Dialog:setColorTextEx(str, panel, color, fontSize, locate, width)
  fontSize = fontSize or 19
  color = color or COLOR3.TEXT_DEFAULT
  panel:removeAllChildren()
  local size = panel:getContentSize()
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(fontSize)
  if width then
    textCtrl:setContentSize(width, 0)
  end
  textCtrl:setString(str)
  textCtrl:setDefaultColor(color.r, color.g, color.b)
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  if locate == LOCATE_POSITION.LEFT_TOP then
    textCtrl:setPosition(0, size.height)
  elseif locate == LOCATE_POSITION.CENTER then
    textCtrl:setPosition(0, size.height * 0.5 + textH * 0.5)
  else
    textCtrl:setPosition((size.width - textW) * 0.5, size.height - (size.height - 19) * 0.5)
  end
  panel:addChild(tolua.cast(textCtrl, "cc.LayerColor"))
  return textCtrl
end
function Dialog:setColorText(str, panelName, root, marginX, marginY, defColor, fontSize, locate, isPunct, isVip)
  marginX = marginX or 0
  marginY = marginY or 0
  root = root or self.root
  fontSize = fontSize or 20
  defColor = defColor or COLOR3.TEXT_DEFAULT
  local panel
  if type(panelName) == "string" then
    panel = self:getControl(panelName, Const.UIPanel, root)
  else
    panel = panelName
  end
  if not panel then
    return
  end
  panel:removeAllChildren()
  local size = panel:getContentSize()
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(fontSize)
  textCtrl:setString(str, isVip)
  textCtrl:setContentSize(size.width - 2 * marginX, 0)
  textCtrl:setDefaultColor(defColor.r, defColor.g, defColor.b)
  if textCtrl.setPunctTypesetting then
    textCtrl:setPunctTypesetting(true == isPunct)
  end
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  if locate == true or locate == LOCATE_POSITION.MID_BOTTOM then
    textCtrl:setPosition((size.width - textW) / 2, textH + marginY)
  elseif locate == LOCATE_POSITION.RIGHT_BOTTOM then
    textCtrl:setPosition(size.width - textW, textH + marginY)
  else
    textCtrl:setPosition(marginX, textH + marginY)
  end
  local textNode = tolua.cast(textCtrl, "cc.LayerColor")
  panel:addChild(textNode, textNode:getLocalZOrder(), Dialog.TAG_COLORTEXT_CTRL)
  local panelHeight = textH + 2 * marginY
  panel:setContentSize(size.width, panelHeight)
  return panelHeight, size.height
end
function Dialog:getColorText(panelName, root)
  local panel
  if type(panelName) == "string" then
    panel = self:getControl(panelName, Const.UIPanel, root)
  else
    panel = panelName
  end
  local child = panel:getChildByTag(Dialog.TAG_COLORTEXT_CTRL)
  if child then
    local textCtrl = tolua.cast(child, "CGAColorTextList")
    if textCtrl then
      return textCtrl:getString()
    end
  end
end
function Dialog:youMustGiveMeOneNotifyEx(param, detail)
  local function func()
    if DlgMgr:getDlgByName(gf:getUILayer().callBackDlgName) then
      self:youMustGiveMeOneNotify(param, detail)
    end
    gf:getUILayer().callBackDlgName = nil
  end
  gf:getUILayer().callBackDlgName = self.name
  if detail and detail.notDelay then
    func()
  else
    local delay = cc.DelayTime:create(0.09)
    local action = cc.CallFunc:create(func)
    gf:getUILayer():runAction(cc.Sequence:create(delay, action))
  end
end
function Dialog:youMustGiveMeOneNotify(param, detail)
  GuideMgr:youCanDoIt(self.name, param)
end
function Dialog:createSwichButton(statePanel, isOn, func, key, limitConditionFuc)
  statePanel.isOn = isOn
  local actionTime = 0.2
  local bkImage1 = self:getControl("BKImage1", nil, statePanel)
  local bkImage2 = self:getControl("BKImage2", nil, statePanel)
  local image = self:getControl("Image", nil, statePanel)
  local onPositionX = image:getPositionX()
  statePanel.onPositionX = onPositionX
  statePanel.switchKey = key
  local isAtionEnd = true
  local function swichButtonAction(self, sender, eventType, data, noCallBack)
    if not noCallBack and limitConditionFuc and limitConditionFuc(self, statePanel.isOn, key) then
      return
    end
    local action
    if isAtionEnd then
      if statePanel.isOn then
        local moveto = cc.MoveTo:create(actionTime, cc.p(0, image:getPositionY()))
        isAtionEnd = false
        local fuc = cc.CallFunc:create(function()
          if bkImage1 then
            local fadeIn = cc.FadeIn:create(actionTime)
            bkImage1:setOpacity(0)
            bkImage1:runAction(fadeIn)
          end
          if bkImage2 then
            local fadeout = cc.FadeOut:create(actionTime)
            local delayFunc = cc.CallFunc:create(function()
              isAtionEnd = true
              if not noCallBack then
                func(self, statePanel.isOn, key)
              end
            end)
            local sq = cc.Sequence:create(fadeout, delayFunc)
            bkImage2:runAction(sq)
          else
            isAtionEnd = true
            if not noCallBack then
              func(self, statePanel.isOn, key)
            end
          end
        end)
        local deily = cc.DelayTime:create(actionTime)
        action = cc.Spawn:create(moveto, fuc)
        image:runAction(action)
        statePanel.isOn = not statePanel.isOn
      else
        local moveto = cc.MoveTo:create(actionTime, cc.p(onPositionX, image:getPositionY()))
        isAtionEnd = false
        local fuc = cc.CallFunc:create(function()
          if bkImage2 then
            local fadeIn = cc.FadeIn:create(actionTime)
            bkImage2:setOpacity(0)
            bkImage2:runAction(fadeIn)
          end
          if bkImage1 then
            local fadeout = cc.FadeOut:create(actionTime)
            local delayFunc = cc.CallFunc:create(function()
              isAtionEnd = true
              if not noCallBack then
                func(self, statePanel.isOn, key)
              end
            end)
            local sq = cc.Sequence:create(fadeout, delayFunc)
            bkImage1:runAction(sq)
          else
            isAtionEnd = true
            if not noCallBack then
              func(self, statePanel.isOn, key)
            end
          end
        end)
        action = cc.Spawn:create(moveto, fuc)
        image:runAction(action)
        statePanel.isOn = not statePanel.isOn
      end
    end
  end
  self:bindTouchEndEventListener(statePanel, swichButtonAction)
  local function onNodeEvent(event)
    if "cleanup" == event and not isAtionEnd and func then
      func(self, statePanel.isOn, key)
    end
  end
  statePanel:registerScriptHandler(onNodeEvent)
  statePanel.touchAction = swichButtonAction
  function image.resetActionEndFlag()
    isAtionEnd = true
  end
  if statePanel.isOn then
    if bkImage1 then
      bkImage1:setOpacity(0)
    end
    image:setPositionX(onPositionX)
  else
    if bkImage2 then
      bkImage2:setOpacity(0)
    end
    image:setPositionX(0)
  end
end
function Dialog:switchButtonStatusWithAction(ctrl, status)
  if "function" ~= type(ctrl.touchAction) then
    return
  end
  if ctrl.isOn ~= status then
    ctrl.touchAction(self, ctrl)
  end
end
function Dialog:switchButtonStatus(ctrl, status)
  if "function" ~= type(ctrl.touchAction) then
    return
  end
  if ctrl.isOn ~= status then
    local bkImage1 = self:getControl("BKImage1", nil, ctrl)
    local bkImage2 = self:getControl("BKImage2", nil, ctrl)
    local image = self:getControl("Image", nil, ctrl)
    bkImage1:stopAllActions()
    bkImage2:stopAllActions()
    image:stopAllActions()
    if image.resetActionEndFlag then
      image.resetActionEndFlag()
    end
    local onPositionX = ctrl.onPositionX
    ctrl.isOn = status
    if status then
      bkImage1:setOpacity(0)
      bkImage2:setOpacity(1000)
      image:setPositionX(onPositionX)
    else
      bkImage1:setOpacity(1000)
      bkImage2:setOpacity(0)
      image:setPositionX(0)
    end
  end
end
function Dialog:getButtonStatus(ctrl)
  return ctrl.isOn
end
function Dialog:bindListViewByPageLoad(listViewName, touchPaneName, cb, root)
  local listView = self:getControl(listViewName, Const.UIListView, root)
  if not listView then
    return
  end
  local panel = self:getControl(touchPaneName, Const.UIPanel, root)
  if not panel then
    return
  end
  local function onTouchBegan(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
    touchPos = panel:getParent():convertToNodeSpace(touchPos)
    if not panel:isVisible() then
      return false
    end
    local box = panel:getBoundingBox()
    if nil == box then
      return false
    end
    if cc.rectContainsPoint(box, touchPos) then
      return true
    end
    return false
  end
  local onTouchMove = function(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
  end
  local function onTouchEnd(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
    local box = panel:getBoundingBox()
    if nil == box then
      return false
    end
    local percent = self:getCurScrollPercent(listViewName, true, root)
    Log:D("The percent is %d%%", percent)
    if type(cb) == "function" then
      cb(self, percent, listView)
    end
    return true
  end
  local listener = cc.EventListenerTouchOneByOne:create()
  listener:setSwallowTouches(false)
  listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
  listener:registerScriptHandler(onTouchMove, cc.Handler.EVENT_TOUCH_MOVED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_ENDED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_CANCELLED)
  local dispatcher = panel:getEventDispatcher()
  dispatcher:addEventListenerWithSceneGraphPriority(listener, panel)
end
function Dialog:setNumImgForPanel(panelNameOrPanel, imgName, amount, showSign, locate, fontSize, root, gap, offsetX, offsetY)
  local panel = panelNameOrPanel
  if type(panelNameOrPanel) == "string" then
    root = root or self.root
    panel = self:getControl(panelNameOrPanel, nil, root)
  end
  if nil == panel then
    return
  end
  local tag = locate * 999
  local numImg = panel:getChildByTag(tag)
  if numImg then
    numImg:removeFromParent()
  end
  gap = gap or -1
  numImg = NumImg.new(imgName, amount, showSign, gap)
  numImg:setTag(tag)
  numImg:setLocalZOrder(100)
  panel:addChild(numImg)
  offsetX = offsetX or 0
  offsetY = offsetY or 0
  local panelSize = panel:getContentSize()
  if locate == LOCATE_POSITION.RIGHT_BOTTOM then
    numImg:setAnchorPoint(1, 0)
    numImg:setPosition(panelSize.width - 5 + offsetX, 5 + offsetY)
  elseif locate == LOCATE_POSITION.LEFT_BOTTOM then
    numImg:setAnchorPoint(0, 0)
    numImg:setPosition(5 + offsetX, 5 + offsetY)
  elseif locate == LOCATE_POSITION.RIGHT_TOP then
    numImg:setAnchorPoint(1, 1)
    numImg:setPosition(panelSize.width - 5 + offsetX, panelSize.height - 5 + offsetY)
  elseif locate == LOCATE_POSITION.LEFT_TOP then
    numImg:setAnchorPoint(0, 1)
    numImg:setPosition(5 + offsetX, panelSize.height - 5 + offsetY)
  elseif locate == LOCATE_POSITION.CENTER then
    numImg:setAnchorPoint(0, 0.5)
    numImg:setPosition(0 + offsetX, panelSize.height / 2 + offsetY)
  elseif locate == LOCATE_POSITION.MID then
    numImg:setAnchorPoint(0.5, 0.5)
    numImg:setPosition(panelSize.width / 2 + offsetX, panelSize.height / 2 + offsetY)
  elseif locate == LOCATE_POSITION.MID_TOP then
    numImg:setAnchorPoint(0.5, 0.5)
    numImg:setPosition(panelSize.width / 2 + offsetX, panelSize.height - 5 + offsetY)
  elseif locate == LOCATE_POSITION.MID_BOTTOM then
    numImg:setAnchorPoint(0.5, 0.5)
    numImg:setPosition(panelSize.width / 2 + offsetX, 5 + offsetY)
  else
    Log:W("Location not expected!")
    return
  end
  if fontSize == 25 then
    numImg:setScale(1, 1)
  elseif fontSize == 30 then
    numImg:setScale(1.1333333333333333, 1.1818181818181819)
  elseif fontSize == 23 then
    numImg:setScale(0.9333333333333333, 0.9090909090909091)
  elseif fontSize == 21 then
    numImg:setScale(0.8666666666666667, 0.8181818181818182)
  elseif fontSize == 19 then
    numImg:setScale(0.8, 0.7272727272727273)
  elseif fontSize == 17 then
    numImg:setScale(0.7333333333333333, 0.6363636363636364)
  elseif fontSize == 15 then
    numImg:setScale(0.6666666666666666, 0.5454545454545454)
  elseif fontSize == 12.5 then
    numImg:setScale(0.5, 0.5)
  else
    Log:W("Font Size not expected!")
    return
  end
  return numImg
end
function Dialog:removeNumImgForPanel(panelNameOrPanel, locate, root)
  local panel = panelNameOrPanel
  if type(panelNameOrPanel) == "string" then
    root = root or self.root
    panel = self:getControl(panelNameOrPanel, Const.UIPanel, root)
  end
  if nil == panel then
    return
  end
  local tag = locate * 999
  panel:removeChildByTag(tag, true)
end
function Dialog:setCloseDlgWhenRefreshUserData(enabled)
  if enabled then
    EventDispatcher:addEventListener("REFRESH_USER_DATA", self.onRefreshUserData, self)
  else
    EventDispatcher:removeEventListener("REFRESH_USER_DATA", self.onRefreshUserData, self)
  end
end
function Dialog:setCloseDlgWhenEnterCombat(enabled)
  if enabled then
    EventDispatcher:addEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  else
    EventDispatcher:removeEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  end
end
function Dialog:stopAllAction(ctrlName)
  local ctrl
  if type(ctrlName) == "string" then
    ctrl = self:getControl("BKPanel")
  elseif type(ctrlName) == "userdata" then
    ctrl = ctrlName
  else
    return
  end
  if nil == ctrl then
    return
  end
  ctrl:stopAllActions()
end
function Dialog:releaseCloneCtrl(ctrlStr)
  if self[ctrlStr] then
    self[ctrlStr]:release()
    self[ctrlStr] = nil
  end
end
function Dialog:toCloneCtrl(ctrlStr, root)
  local ctrl = self:getControl(ctrlStr, nil, root)
  ctrl:setVisible(true)
  ctrl:retain()
  ctrl:removeFromParentAndCleanup()
  return ctrl
end
function Dialog:bindFloatingEvent(crtlName, root, onUnvisible)
  local panel = self:getControl(crtlName, nil, root)
  if not panel then
    return
  end
  panel:setVisible(false)
  local function onTouchBegan(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
    touchPos = panel:getParent():convertToNodeSpace(touchPos)
    if not panel:isVisible() then
      return false
    end
    return true
  end
  local onTouchMove = function(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
  end
  local function onTouchEnd(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
    local box = panel:getBoundingBox()
    if panel:isVisible() then
      performWithDelay(self.root, function()
        panel:setVisible(false)
        if onUnvisible then
          onUnvisible()
        end
      end, 0)
    end
    return true
  end
  local listener = cc.EventListenerTouchOneByOne:create()
  listener:setSwallowTouches(false)
  listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
  listener:registerScriptHandler(onTouchMove, cc.Handler.EVENT_TOUCH_MOVED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_ENDED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_CANCELLED)
  local dispatcher = panel:getEventDispatcher()
  dispatcher:addEventListenerWithSceneGraphPriority(listener, panel)
end
function Dialog:bindEditFieldForSafe(parentPanelName, lenLimit, clenButtonName, verAlign, eventCallBack, needUpDlgHeight, placeHolderColor)
  local namePanel = parentPanelName
  if type(parentPanelName) == "string" then
    namePanel = self:getControl(parentPanelName)
  end
  local textCtrl = self:getControl("TextField", nil, namePanel)
  textCtrl:setPlaceHolder(placeHolder or "")
  if placeHolderColor and textCtrl.setColorSpaceHolder then
    textCtrl:setColorSpaceHolder(placeHolderColor)
  end
  textCtrl:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
  textCtrl:setTextVerticalAlignment(verAlign or cc.TEXT_ALIGNMENT_CENTER)
  self:setCtrlVisible(clenButtonName, false, namePanel)
  self:setCtrlVisible("DefaultLabel", true, namePanel)
  if not self.checkImeStatus then
    self.checkImeStatus = {}
  end
  self.upDlgAction = nil
  if needUpDlgHeight and type(needUpDlgHeight) == "boolean" then
    needUpDlgHeight = self:getTextFieldNeedUpHeight(textCtrl)
  end
  textCtrl:addEventListener(function(sender, eventType)
    if ccui.TextFiledEventType.attach_with_ime == eventType and not self:isContainTouchPos(parentPanelName) then
      return
    end
    if ccui.TextFiledEventType.insert_text == eventType then
      local str = textCtrl:getStringValue()
      self:setCtrlVisible(clenButtonName, true, namePanel)
      self:setCtrlVisible("DefaultLabel", false, namePanel)
      if gf:getTextLength(str) > lenLimit * 2 then
        gf:ShowSmallTips(CHS[4000224])
      end
      textCtrl:setText(tostring(gf:subString(str, lenLimit * 2)))
    elseif ccui.TextFiledEventType.delete_backward == eventType then
      local str = sender:getStringValue()
      if "" == str then
        self:setCtrlVisible(clenButtonName, false, namePanel)
        self:setCtrlVisible("DefaultLabel", true, namePanel)
      end
    elseif ccui.TextFiledEventType.attach_with_ime == eventType then
      self.checkImeStatus[parentPanelName] = self:getTextFieldNeedUpHeight(sender)
    elseif ccui.TextFiledEventType.detach_with_ime == eventType then
      self.checkImeStatus[parentPanelName] = false
      SoundMgr:postEditing()
    end
    if eventCallBack then
      eventCallBack(self, sender, eventType)
    end
    if needUpDlgHeight and type(needUpDlgHeight) == "number" and (ccui.TextFiledEventType.attach_with_ime == eventType or ccui.TextFiledEventType.detach_with_ime == eventType) then
      if self.upDlgAction then
        return
      end
      self.upDlgAction = performWithDelay(self.root, function()
        local upHeight = self:getDlgUpStatus()
        if upHeight then
          DlgMgr:upDlg(self.name, upHeight)
        else
          DlgMgr:resetUpDlg(self.name)
        end
        self.upDlgAction = nil
      end, 0.1)
    end
  end)
  return textCtrl
end
function Dialog:getDlgUpStatus()
  if gf:isIos() then
    for k, v in pairs(self.checkImeStatus) do
      if v then
        return v
      end
    end
  end
  return false
end
function Dialog:isContainTouchPos(nodeOrName)
  local pos = GameMgr.curTouchPos
  local panel
  if type(nodeOrName) == "string" then
    panel = self:getControl(nodeOrName)
  else
    panel = nodeOrName
  end
  local rect = self:getBoundingBoxInWorldSpace(panel)
  if cc.rectContainsPoint(rect, pos) then
    return true
  end
end
function Dialog:getTextFieldNeedUpHeight(textCtrl)
  local rect = self:getBoundingBoxInWorldSpace(textCtrl)
  local iosImeHeight = Const.WINSIZE.height / 3 * 2
  if textCtrl.getImeHeight then
    local realImeHeight = textCtrl:getImeHeight()
    if realImeHeight ~= 0 then
      iosImeHeight = realImeHeight
    end
  end
  local needUpDlgHeight = 0
  if iosImeHeight > rect.y then
    needUpDlgHeight = iosImeHeight - rect.y
  end
  return needUpDlgHeight
end
function Dialog:bindNumInput(ctrlName, root, limitCallBack, key, isString, useBig, displayPosition)
  local panel = self:getControl(ctrlName, nil, root)
  local function openNumIuputDlg()
    if limitCallBack and "function" == type(limitCallBack) and limitCallBack(self) then
      return
    end
    local rect = self:getBoundingBoxInWorldSpace(panel)
    local dlg
    if useBig then
      dlg = DlgMgr:openDlg("NumInputExDlg")
    else
      dlg = DlgMgr:openDlg("SmallNumInputDlg")
    end
    if DlgMgr:isDlgOpened(self.name) then
      dlg:setObj(self, self.name)
    else
      dlg:setObj(self)
    end
    dlg:setKey(key)
    dlg:setIsString(true == isString and true or false)
    dlg:updatePosition(rect, displayPosition)
    if self.doWhenOpenNumInput then
      self:doWhenOpenNumInput(ctrlName, root)
    end
  end
  self:bindListener(ctrlName, openNumIuputDlg, root)
  return openNumIuputDlg
end
function Dialog:addMagicToCtrl(ctrlName, icon, root, pos, dir, extraPara)
  local ctrl = self:getControl(ctrlName, nil, root)
  if not ctrl then
    return
  end
  local effect = LIGHT_EFFECT[icon]
  if not effect then
    return
  end
  local armatureType = LIGHT_EFFECT[icon].armatureType
  extraPara = extraPara or LIGHT_EFFECT[icon].extraPara
  local behind = LIGHT_EFFECT[icon].behind
  local magic, dbMagic
  if not armatureType or armatureType == 0 then
    magic = gf:createLoopMagic(icon, nil, extraPara)
    magic:setContentSize(ctrl:getContentSize())
  elseif armatureType == 3 then
    if type(icon) == "table" then
      dbMagic = DragonBonesMgr:createCharDragonBones(icon.icon, icon.armatureName)
      if dbMagic then
        magic = tolua.cast(dbMagic, "cc.Node")
      end
    end
  else
    local actionName
    if LIGHT_EFFECT[icon] and LIGHT_EFFECT[icon].show_action and dir then
      actionName = LIGHT_EFFECT[icon].show_action[dir]
    end
    if not actionName then
      actionName = "Top"
      if behind then
        actionName = "Bottom"
      end
    end
    magic = ArmatureMgr:createArmatureByType(armatureType, icon, actionName)
    magic:getAnimation():play(actionName, -1, 1)
  end
  if "number" == type(pos) then
    local charAction = ctrl:getChildByTag(Dialog.TAG_PORTRAIT)
    if charAction then
      local x, y
      local cx, cy = charAction:getPosition()
      if 3 == pos then
        x, y = charAction:getHeadOffset()
      elseif 2 == pos then
        x, y = charAction:getWaistOffset()
      elseif 1 == pos then
        x, y = 0, 0
      end
      pos = cc.p(x + cx, y + cy)
    end
  end
  pos = pos or cc.p(ctrl:getContentSize().width / 2, ctrl:getContentSize().height / 2)
  magic:setPosition(pos)
  ctrl:addChild(magic, behind and -1 or 1, icon)
  return magic
end
function Dialog:removeMagicFromCtrl(ctrlName, icon, root)
  local sender = self:getControl(ctrlName, nil, root)
  local magic = sender:getChildByTag(icon)
  if magic then
    magic:removeFromParent()
  end
end
function Dialog:addLoopMagicToCtrl(ctrlName, icon, root, pos, extraPara)
  local ctrl = self:getControl(ctrlName, nil, root)
  if not ctrl then
    return
  end
  local effect = gf:createLoopMagic(icon, nil, extraPara)
  effect:setAnchorPoint(0.5, 0.5)
  pos = pos or cc.p(ctrl:getContentSize().width / 2, ctrl:getContentSize().height / 2)
  effect:setPosition(pos)
  effect:setContentSize(ctrl:getContentSize())
  ctrl:addChild(effect, 1, icon)
end
function Dialog:removeLoopMagicFromCtrl(ctrlName, icon, root)
  self:removeMagicFromCtrl(ctrlName, icon, root)
end
function Dialog:removeArmatureMagicFromCtrl(ctrlName, tag, root)
  self:removeMagicFromCtrl(ctrlName, tag, root)
end
function Dialog:getLoopMagicFromCtrl(ctrlName, icon, root)
  local sender = self:getControl(ctrlName, nil, root)
  local magic = sender:getChildByTag(icon)
  return magic
end
function Dialog:addUpgradeMagicToCtrl(ctrlName, type, root, state)
  local ctrl = self:getControl(ctrlName, nil, root)
  if not ctrl then
    return
  end
  ctrl:removeChildByTag(Const.UPGRADE_MAGIC_TAG)
  local scale = 1
  local downH = 0
  if not state then
    scale = Const.UPGRADE_CHILD_MAGIC_SCALE
    downH = 15
  end
  local magicIcon = ResMgr:getUpgradeIconByType(type)
  if not magicIcon then
    return
  end
  local effect = gf:createLoopMagic(magicIcon, nil, {
    loopInterval = 5000,
    scaleX = scale,
    scaleY = scale
  })
  local pos = cc.p(ctrl:getContentSize().width / 2, ctrl:getContentSize().height / 2 - downH)
  effect:setPosition(pos)
  effect:setAnchorPoint(0.5, 0.5)
  effect:setContentSize(ctrl:getContentSize())
  ctrl:addChild(effect)
  effect:setTag(Const.UPGRADE_MAGIC_TAG)
end
function Dialog:removeUpgradeMagicToCtrl(ctrlName, root)
  local ctrl = self:getControl(ctrlName, nil, root)
  if not ctrl then
    return
  end
  ctrl:removeChildByTag(Const.UPGRADE_MAGIC_TAG)
end
function Dialog:addUpgradeImage(imageCtrlName, type, root)
  self:setCtrlVisible(imageCtrlName, false, root)
  local imagePath = ResMgr:getUpgradeIconByType(type, true)
  if imagePath then
    self:setCtrlVisible(imageCtrlName, true, root)
    self:setImage(imageCtrlName, ResMgr:getUpgradeIconByType(type, true))
  end
end
function Dialog:createShareButton(btnCtrl, typeStr, fun, preFun, backFun)
  if nil == btnCtrl then
    return
  end
  if ShareMgr:isShowShareBtn() then
    btnCtrl:setVisible(true)
  else
    btnCtrl:setVisible(false)
    return
  end
  self:bindTouchEndEventListener(btnCtrl, function()
    if "function" == type(fun) then
      fun(self)
    else
      ShareMgr:share(typeStr, preFun, backFun)
    end
  end)
end
function Dialog:initScrollViewPanel(data, cellColne, func, scrollView, column, lineSpace, columnSpace, startX, startY, scrollDir)
  if not scrollView then
    return
  end
  startX = startX or 0
  startY = startY or 0
  lineSpace = lineSpace or 0
  columnSpace = columnSpace or 0
  scrollView:removeAllChildren()
  local contentLayer = ccui.Layout:create()
  local line = math.floor(#data / column)
  local left = #data % column
  if left ~= 0 then
    line = line + 1
  end
  local curColunm = 0
  local totalHeight = line * (cellColne:getContentSize().height + lineSpace) + startY
  local totalWidth = column * (cellColne:getContentSize().width + columnSpace) + startX
  if scrollDir == ccui.ScrollViewDir.horizontal then
    totalHeight = scrollView:getContentSize().height
  end
  for i = 1, line do
    if i == line and left ~= 0 then
      curColunm = left
    else
      curColunm = column
    end
    for j = 1, curColunm do
      local tag = j + (i - 1) * column
      local cell = cellColne:clone()
      cell:setAnchorPoint(0, 1)
      local x = (j - 1) * (cellColne:getContentSize().width + columnSpace) + startX
      local y = totalHeight - (i - 1) * (cellColne:getContentSize().height + lineSpace) - startY
      cell:setPosition(x, y)
      cell:setTag(tag)
      func(self, cell, data[tag])
      contentLayer:addChild(cell)
    end
  end
  if scrollDir == ccui.ScrollViewDir.horizontal then
    contentLayer:setContentSize(totalWidth, scrollView:getContentSize().height)
    scrollView:setInnerContainerSize(contentLayer:getContentSize())
  else
    contentLayer:setContentSize(scrollView:getContentSize().width, totalHeight)
    scrollView:setInnerContainerSize(contentLayer:getContentSize())
  end
  if totalHeight < scrollView:getContentSize().height then
    contentLayer:setPositionY(scrollView:getContentSize().height - totalHeight)
  end
  scrollView:addChild(contentLayer, 0, #data * 99)
end
function Dialog:startCoroutine(func, ...)
  return startCoroutine(func, ...)
end
function Dialog:yield(time)
  yield(time, self.blank)
end
function Dialog:stopCoroutine(co)
  stopCoroutine(co)
end
function Dialog:onCloseButtonForGm()
  DlgMgr:closeDlgForGm(self.name)
end
function Dialog:onCloseButton()
  if "NpcDlg" == self.name then
    gf:CmdToServer("CMD_CLOSE_MENU", {
      id = self.npc_id
    })
    DlgMgr:closeDlg(self.name)
  else
    DlgMgr:closeDlg(self.name)
  end
end
function Dialog:onRefreshUserData()
  if GameMgr.canRefreshUserData then
    self:onCloseButton()
  end
end
function Dialog:onEnterCombat()
  self:onCloseButton()
end
function Dialog:createScratch(ctrlName, scImagePath, erasers, desRate, cb, effectAareRate, canTouchFlag, root, para)
  local panel = self:getControl(ctrlName, nil, root)
  local rText = cc.RenderTexture:create(panel:getContentSize().width, panel:getContentSize().height)
  rText:setPosition(panel:getContentSize().width / 2, panel:getContentSize().height / 2)
  panel:addChild(rText)
  local image = cc.Sprite:create(scImagePath)
  image:setAnchorPoint(0, 0)
  image:setPosition(0, 0)
  if para then
    if para.rotate then
      image:setRotation(para.rotate)
    end
    if para.scaleX then
      image:setScaleX(para.scaleX)
    end
    if para.scaleY then
      image:setScaleY(para.scaleY)
    end
    if para.FlipX then
      image:setFlipX(para.FlipX)
    end
    if para.FlipY then
      image:setFlipY(para.FlipY)
    end
    if para.anchorPos then
      image:setAnchorPoint(para.anchorPos)
    end
  end
  rText:beginWithClear(0, 0, 0, 0)
  image:visit()
  rText:endToLua()
  local panelW = math.floor(panel:getContentSize().width * effectAareRate)
  local panelH = math.floor(panel:getContentSize().height * effectAareRate)
  local map = {}
  map.all = (panelW + 1) * (panelH + 1)
  map.part = 0
  for i = 1, panelW + 1 do
    map[i] = {}
    for j = 1, panelH + 1 do
      map[i][j] = 1
    end
  end
  local box = panel:getBoundingBox()
  box.x = 0
  box.y = 0
  local lastPos = {}
  local i = 1
  local eCount = #erasers
  local lastMoveTime = 0
  local function onErase(touch, event)
    local eventCode = event:getEventCode()
    local touchPos = touch:getLocation()
    local curPos = {}
    curPos.x = touchPos.x
    curPos.y = touchPos.y
    touchPos = rText:convertToNodeSpace(touchPos)
    touchPos.x = touchPos.x + box.width / 2
    touchPos.y = touchPos.y + box.height / 2
    if nil == box then
      return curPos
    end
    if not lastPos.x then
      lastPos.x = curPos.x
      lastPos.y = curPos.y
    end
    lastPos = rText:convertToNodeSpace(lastPos)
    lastPos.x = lastPos.x + box.width / 2
    lastPos.y = lastPos.y + box.height / 2
    local c = 0
    rText:begin()
    local pos = {}
    pos.x = lastPos.x - touchPos.x
    pos.y = lastPos.y - touchPos.y
    local nurmal = cc.pNormalize(pos)
    local lastDistance = cc.pGetDistance(touchPos, lastPos)
    while lastDistance >= 2 do
      touchPos.x = touchPos.x + nurmal.x * 2
      touchPos.y = touchPos.y + nurmal.y * 2
      if lastDistance <= cc.pGetDistance(touchPos, lastPos) then
        break
      end
      lastDistance = cc.pGetDistance(touchPos, lastPos)
      if cc.rectContainsPoint(box, touchPos) then
        local eraser = erasers[i]
        i = i % eCount + 1
        if not eraser then
          return curPos
        end
        eraser:setPosition(touchPos)
        eraser:visit()
        local effectPos = {}
        effectPos.x = touchPos.x - (box.width - box.width * effectAareRate) / 2
        effectPos.y = touchPos.y - (box.height - box.height * effectAareRate) / 2
        local box2 = {}
        box2.width = box.width * effectAareRate
        box2.height = box.height * effectAareRate
        box2.x = 0
        box2.y = 0
        if cc.rectContainsPoint(box2, effectPos) then
          local x1 = math.floor(effectPos.x) - eraser.radius + 1
          local y1 = math.floor(effectPos.y) + eraser.radius - 1
          local x2 = x1 + eraser.radius + eraser.radius - 1
          local y2 = y1 - (eraser.radius + eraser.radius - 1)
          if x1 < 1 then
            x1 = 1
          end
          if y1 > panelH then
            y1 = panelH
          end
          if x2 > panelW then
            x2 = panelW
          end
          if y2 < 1 then
            y2 = 1
          end
          for i = x1, x2 do
            for j = y2, y1 do
              if map[i][j] == 1 then
                map[i][j] = 0
                map.part = map.part + 1
              end
            end
          end
          if map.part / map.all >= desRate then
            cb(self, ctrlName)
          end
        end
      end
    end
    rText:endToLua()
    return curPos
  end
  self[canTouchFlag] = true
  local function onTouchBegan(touch, event)
    if not self[canTouchFlag] then
      return false
    end
    i = 1
    self[canTouchFlag] = false
    local touchPos = touch:getLocation()
    lastPos = {}
    lastPos.x = touchPos.x
    lastPos.y = touchPos.y
    return true
  end
  local function onTouchMove(touch, event)
    if lastMoveTime + 20 > gfGetTickCount() then
      return true
    end
    lastMoveTime = gfGetTickCount()
    lastPos = onErase(touch, event)
    return true
  end
  local function onTouchEnd(touch, event)
    onErase(touch, event)
    lastPos = {}
    self[canTouchFlag] = true
  end
  local listener = cc.EventListenerTouchOneByOne:create()
  listener:setSwallowTouches(false)
  listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
  listener:registerScriptHandler(onTouchMove, cc.Handler.EVENT_TOUCH_MOVED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_ENDED)
  listener:registerScriptHandler(onTouchEnd, cc.Handler.EVENT_TOUCH_CANCELLED)
  local dispatcher = panel:getEventDispatcher()
  dispatcher:addEventListenerWithSceneGraphPriority(listener, rText)
  return rText
end
function Dialog:createEraser(radius)
  local eraser = cc.DrawNode:create()
  eraser:drawDot(cc.p(0, 0), radius, cc.c4b(0, 0, 0, 0))
  eraser:setAnchorPoint(0.5, 0.5)
  eraser:setBlendFunc(gl.ONE, gl.ZERO)
  eraser.radius = radius
  return eraser
end
function Dialog:setItemImageSize(str, root, isNotImg)
  local img = self:getControl(str, nil, root)
  gf:setItemImageSize(img, isNotImg)
end
function Dialog:setSmallRewardImageSize(str, root, isNotImg)
  local img = self:getControl(str, nil, root)
  gf:setSmallRewardImageSize(img, isNotImg)
end
function Dialog:setSkillFlagImageSize(str, root, isNotImg)
  local img = self:getControl(str, nil, root)
  gf:setSkillFlagImageSize(img, isNotImg)
end
function Dialog:checkSafeLockRelease(funName, ...)
  if SafeLockMgr:isToBeRelease() then
    SafeLockMgr:addContinueCb(self.name, funName, ...)
    return true
  end
  return false
end
function Dialog:retainCtrl(ctrlName, root)
  local ctrl
  if type(ctrlName) == "string" then
    ctrl = self:getControl(ctrlName, nil, root)
  elseif type(ctrlName) == "userdata" then
    ctrl = ctrlName
  end
  if ctrl == nil then
    return
  end
  ctrl:setVisible(true)
  ctrl:retain()
  ctrl:removeFromParent()
  if not self.var.retainCtrls then
    self.var.retainCtrls = {}
  end
  table.insert(self.var.retainCtrls, ctrl)
  return ctrl
end
function Dialog:releaseCtrls()
  if not self.var.retainCtrls then
    return
  end
  for _, v in ipairs(self.var.retainCtrls) do
    if v then
      v:cleanup()
      v:release()
    end
  end
  self.var.retainCtrls = nil
end
function Dialog:startSchedule(func, time)
  return schedule(self.root, func, time)
end
function Dialog:stopSchedule(schedule)
  if schedule then
    self.root:stopAction(schedule)
  end
end
function Dialog:bindTipPanelTouchEvent(name)
  local tipPanel = self:getControl(name)
  local layout = ccui.Layout:create()
  layout:setContentSize(tipPanel:getContentSize())
  layout:setPosition(tipPanel:getPosition())
  layout:setAnchorPoint(tipPanel:getAnchorPoint())
  local function touch(touch, event)
    local rect = self:getBoundingBoxInWorldSpace(tipPanel)
    local toPos = touch:getLocation()
    if not cc.rectContainsPoint(rect, toPos) and tipPanel:isVisible() then
      tipPanel:setVisible(false)
      return true
    end
  end
  self.root:addChild(layout, 10, 1)
  gf:bindTouchListener(layout, touch)
end
function Dialog:setListInnerPosByIndex(listName, index, root)
  local list
  if type(listName) == "string" then
    list = self:getControl(listName, nil, root)
  else
    list = listName
  end
  if not #list:getItems() == 0 then
    return
  end
  if list:getInnerContainer():getContentSize().height <= list:getContentSize().height then
    return
  end
  local inner = list:getInnerContainer()
  local margin = list:getItemsMargin()
  local panel = list:getChildren()[1]
  local height = (panel:getContentSize().height + margin) * index - margin
  if height >= list:getContentSize().height then
    inner:setPositionY(height - inner:getContentSize().height)
  end
end
function Dialog:setMenuList(listInfo, oneMenus, onePanel, secondMenus, secondPanel, onOneMenuCallBack, onSecondMenuCallBack, cfgPara)
  cfgPara = cfgPara or {}
  local listView, margin, gravity, root
  if type(listInfo) == "string" then
    margin = 0
    gravity = ccui.ListViewGravity.centerVertical
    listView = self:getControl(listInfo, nil, root)
  elseif type(listInfo) == "table" then
    margin = listInfo.margin or 0
    gravity = listInfo.gravity or ccui.ListViewGravity.centerVertical
    root = listInfo.root
    listView = self:getControl(listInfo.name, nil, root)
  end
  if not listView then
    return
  end
  listView:removeAllItems()
  listView:setGravity(gravity)
  listView:setTouchEnabled(true)
  listView:setItemsMargin(margin)
  listView:setClippingEnabled(true)
  listView:setInnerContainerSize(cc.size(0, 0))
  local defSelectIndex = 0
  local function onSmallMenu(dlg, sender, isDef)
    if type(self.isCanClickSmallMenu) == "function" and not self:isCanClickSmallMenu(sender) then
      return
    end
    local items = listView:getItems()
    local removeBigTag
    for _, panel in pairs(items) do
      local tag = panel:getTag()
      if tag % 100 ~= 0 and math.floor(tag / 100) * 100 ~= sender:getTag() then
        self:setCtrlVisible("SChosenEffectImage", false, panel)
      else
      end
    end
    self:setCtrlVisible("SChosenEffectImage", true, sender)
    if onSecondMenuCallBack then
      onSecondMenuCallBack(dlg, sender, isDef)
    end
  end
  local function setSmallMenuListByBigMenu(sender)
    local menus = secondMenus[sender:getName()]
    local defaultFlag
    for i = 1, #menus do
      local panel = secondPanel:clone()
      panel:setTag(sender:getTag() + i)
      panel:setName(menus[i])
      self:setLabelText("Label", menus[i], panel)
      listView:insertCustomItem(panel, math.floor(sender:getTag() / 100) + i - 1)
      if not defaultFlag and not cfgPara.two and (type(self.isCanClickSmallMenu) ~= "function" or not not self:isCanClickSmallMenu(panel, true)) then
        defaultFlag = true
        onSmallMenu(self, panel, cfgPara)
      end
      if cfgPara and cfgPara.two and (cfgPara.two == menus[i] or cfgPara.two == panel:getTag()) then
        onSmallMenu(self, panel)
        defSelectIndex = sender:getTag() / 100 + i
        defaultFlag = true
        cfgPara.two = nil
      end
    end
    listView:refreshView()
  end
  local function setArrow(state, panel)
    panel.menuState = state
    self:setCtrlVisible("DownArrowImage", false, panel)
    self:setCtrlVisible("UpArrowImage", false, panel)
    if state == MENU_BUTTON_STATE.NORMAL then
      self:setCtrlVisible("DownArrowImage", true, panel)
      self:setCtrlVisible("BChosenEffectImage", false, panel)
      self:setCtrlVisible("SChosenEffectImage", false, panel)
    else
      if state == MENU_BUTTON_STATE.EXPAND then
        self:setCtrlVisible("UpArrowImage", true, panel)
        self:setCtrlVisible("BChosenEffectImage", true, panel)
        self:setCtrlVisible("SChosenEffectImage", true, panel)
      else
      end
    end
  end
  local function removeSmallMenu(sender)
    local items = listView:getItems()
    local removeBigTag
    for _, panel in pairs(items) do
      local tag = panel:getTag()
      if tag % 100 ~= 0 then
        listView:removeChild(panel)
        removeBigTag = math.floor(tag / 100) * 100
      else
        self:setCtrlVisible("BChosenEffectImage", false, panel)
      end
    end
    if removeBigTag then
      setArrow(MENU_BUTTON_STATE.NORMAL, listView:getChildByTag(removeBigTag))
      sender.isSelect = false
    end
    listView:requestRefreshView()
  end
  local function onBigMenu(dlg, sender)
    if type(self.isCanClickBigMenu) == "function" and not self:isCanClickBigMenu(sender) then
      return
    end
    defSelectIndex = sender:getTag() / 100
    if onOneMenuCallBack then
      onOneMenuCallBack(dlg, sender)
    end
    if secondMenus then
      local isNeedNormal = false
      if sender.isSelect == true and sender.menuState == MENU_BUTTON_STATE.EXPAND then
        isNeedNormal = true
      end
      if cfgPara and cfgPara.againClickNeedNotHideTwoMenu then
        isNeedNormal = false
      end
      removeSmallMenu(sender)
      if sender.menuState == MENU_BUTTON_STATE.NORMAL and not isNeedNormal then
        if secondMenus[sender:getName()] then
          setSmallMenuListByBigMenu(sender)
        end
        setArrow(MENU_BUTTON_STATE.EXPAND, sender)
      elseif sender.menuState == MENU_BUTTON_STATE.EXPAND then
        setArrow(MENU_BUTTON_STATE.EXPAND, sender)
      elseif sender.menuState == MENU_BUTTON_STATE.NO_CHILD then
        setArrow(MENU_BUTTON_STATE.NO_CHILD, sender)
        self:setCtrlVisible("BChosenEffectImage", true, sender)
        self:setCtrlVisible("SChosenEffectImage", true, sender)
      end
      if isNeedNormal then
        self:setCtrlVisible("BChosenEffectImage", true, sender)
        self:setCtrlVisible("SChosenEffectImage", true, sender)
      end
      sender.isSelect = true
    else
      local items = listView:getItems()
      for _, panel in pairs(items) do
        self:setCtrlVisible("BChosenEffectImage", false, panel)
        self:setCtrlVisible("SChosenEffectImage", false, panel)
      end
      self:setCtrlVisible("BChosenEffectImage", true, sender)
      self:setCtrlVisible("SChosenEffectImage", true, sender)
      listView:requestRefreshView()
    end
  end
  if oneMenus then
    self:bindTouchEndEventListener(onePanel, onBigMenu)
  end
  if secondMenus then
    self:bindTouchEndEventListener(secondPanel, onSmallMenu)
  end
  local defaultFlag = false
  for i, menuStr in pairs(oneMenus) do
    local panel = onePanel:clone()
    panel:setTag(i * 100)
    panel:setName(menuStr)
    self:setCtrlVisible("BChosenEffectImage", false, panel)
    self:setLabelText("Label", menuStr, panel)
    listView:pushBackCustomItem(panel)
    if secondMenus and secondMenus[menuStr] then
      setArrow(MENU_BUTTON_STATE.NORMAL, panel)
    else
      setArrow(MENU_BUTTON_STATE.NO_CHILD, panel)
    end
    if not defaultFlag and not cfgPara.one and (type(self.isCanClickBigMenu) ~= "function" or not not self:isCanClickBigMenu(panel, true)) then
      defaultFlag = true
      onBigMenu(self, panel)
    end
    if cfgPara and cfgPara.one and (cfgPara.one == menuStr or cfgPara.one == panel:getTag()) then
      onBigMenu(self, panel)
      defaultFlag = true
      cfgPara.one = nil
    end
  end
  if cfgPara and cfgPara.isScrollToDef then
    performWithDelay(self.root, function()
      self:setListInnerPosByIndex(listView, defSelectIndex)
    end, 0)
  end
  listView:refreshView()
end
function Dialog:displayPlayActions(panelName, root, offset, tag, actions, callback)
  local offPos
  if "number" == type(offset) then
    offPos = cc.p(0, offset)
  elseif "table" == type(offset) then
    offPos = offset
  end
  tag = tag or Dialog.TAG_PORTRAIT
  actions = actions or {
    Const.SA_ATTACK,
    Const.SA_CAST
  }
  local actKey = "act" .. tostring(tag)
  tag = tag or Dialog.TAG_PORTRAIT
  local function delayPlayAttack(panel, no)
    local size = panel:getContentSize()
    local function setPos()
      local charNow = panel:getChildByTag(tag)
      if not charNow then
        return
      end
      if nil ~= offPos then
        local contentSize = panel:getContentSize()
        local basicX = contentSize.width / 2 + offPos.x
        local basicY = contentSize.height / 2 + offPos.y
        charNow:setPosition(basicX, basicY)
      end
    end
    if panel[actKey] then
      panel:stopAction(panel[actKey])
      panel[actKey] = nil
      local charNow = panel:getChildByTag(tag)
      if charNow then
        charNow:resetAction()
      end
      setPos()
    end
    local showAction = actions[no % #actions + 1]
    panel[actKey] = performWithDelay(panel, function()
      local charNow = panel:getChildByTag(tag)
      if not charNow then
        return
      end
      if "function" == type(callback) then
        callback(showAction)
      end
      if Const.SA_WALK == showAction then
        charNow:playWalkThreeTimes(function()
          if "function" == type(callback) then
            callback(Const.SA_STAND)
          end
          setPos()
          delayPlayAttack(panel, no + 1)
        end)
      else
        charNow:playActionOnce(function()
          if "function" == type(callback) then
            callback(Const.SA_STAND)
          end
          setPos()
          delayPlayAttack(panel, no + 1)
        end, showAction)
      end
    end, 3)
  end
  local shapePanel = self:getControl(panelName, nil, root)
  delayPlayAttack(shapePanel, 0)
end
function Dialog:frozeButton(name, time, root)
  local ctrl = self:getControl(name, nil, root)
  if not ctrl then
    return
  end
  time = time or 0.3
  self:setCtrlEnabled(name, false, root)
  local delay = cc.DelayTime:create(time)
  local func = cc.CallFunc:create(function()
    self:setCtrlEnabled(name, true, root)
  end)
  local action = cc.Sequence:create(delay, func)
  return ctrl:runAction(action)
end
function Dialog:setLastOperTime(key, time)
  DlgMgr:setLastTime(self.name .. key, time)
end
function Dialog:getLastOperTime(key)
  return DlgMgr:getLastTime(self.name .. key)
end
function Dialog:isOutLimitTime(key, spaceTime)
  local lastTime = DlgMgr:getLastTime(self.name .. key)
  if not lastTime or spaceTime <= gfGetTickCount() - lastTime then
    return true
  end
end
function Dialog:createCountDown(time, ctrlName, root)
  local timePanel = self:getControl(ctrlName, nil, root)
  if not timePanel then
    return
  end
  local sz = timePanel:getContentSize()
  local numImg = NumImg.new(ART_FONT_COLOR.B_FIGHT, time, false, -5)
  numImg:setPosition(sz.width / 2, sz.height / 2)
  numImg:setName("countDown")
  timePanel:addChild(numImg)
  return numImg
end
function Dialog:startCountDown(time, ctrlName, root, callBack, midCallBack)
  local timePanel = self:getControl(ctrlName, nil, root)
  if not timePanel then
    return
  end
  local numImg = timePanel:getChildByName("countDown")
  if not numImg then
    return
  end
  numImg:setNum(time, false)
  numImg:startCountDown(callBack, midCallBack)
  return numImg
end
function Dialog:stopCountDown(ctrlName, root)
  local timePanel = self:getControl(ctrlName, nil, root)
  if not timePanel then
    return
  end
  local numImg = timePanel:getChildByName("countDown")
  if not numImg then
    return
  end
  numImg:stopCountDown()
  return numImg
end
function Dialog:moveToOtherParent(panel, newParent)
  local oldParent = panel:getParent()
  if oldParent == newParent then
    return
  end
  local x, y = panel:getPosition()
  local pos = oldParent:convertToWorldSpace(cc.p(x, y))
  pos = newParent:convertToNodeSpace(pos)
  panel:setPosition(pos.x, pos.y)
  panel:retain()
  panel:removeFromParent(false)
  newParent:addChild(panel)
  panel:release()
end
function Dialog:runProgressAction(ctlName, tip, root)
  self:setLabelText(ctlName, tip, root)
  local panel = self:getControl(ctlName, nil, root)
  panel:stopAllActions()
  local i = 1
  schedule(panel, function()
    if not panel:isVisible() then
      panel:stopAllActions()
      return
    end
    self:setLabelText(ctlName, tip .. string.rep(".", i), root)
    i = i + 1
    if i > 3 then
      i = 0
    end
  end, 0.3)
end
function Dialog:hideAllDlgs(excepts)
  self.allInvisbleDlgs = DlgMgr:getAllInVisbleDlgs()
  local mainDlgs = DlgMgr:getMainDlgList()
  for i = #self.allInvisbleDlgs, 1, -1 do
    if mainDlgs[self.allInvisbleDlgs[i]] then
      table.remove(self.allInvisbleDlgs, i)
    end
  end
  DlgMgr:setNotCheckMainDlg(self.name, true)
  excepts = excepts or {}
  excepts[self.name] = 1
  DlgMgr:showAllOpenedDlg(false, excepts)
end
function Dialog:showDlgsWhenOpenHide()
  if not self.allInvisbleDlgs then
    return
  end
  local t = {}
  if self.allInvisbleDlgs then
    for i = 1, #self.allInvisbleDlgs do
      t[self.allInvisbleDlgs[i]] = 1
    end
  end
  DlgMgr:setNotCheckMainDlg(self.name)
  DlgMgr:showAllOpenedDlg(true, t)
  self.allInvisbleDlgs = nil
end
function Dialog:showParentName(ctrl, idx)
  if not ctrl then
    gf:ShowSmallTips("没有控件！！！！")
    return
  end
  if not idx then
    idx = idx or ""
    Log:D(ctrl:getName() .. " 的父控件相关信息")
  end
  if ctrl ~= self.root and ctrl:getParent() ~= self.root then
    idx = idx .. "  "
    Log:D(idx .. ctrl:getParent():getName())
    self:showParentName(ctrl:getParent(), idx)
  end
end
function Dialog:showChildrenName(ctrl)
  if not ctrl then
    Log:D("没有该控件！")
    return
  end
  local items = ctrl:getChildren()
  Log:D(ctrl:getName() .. "子控件为")
  for _, panel in pairs(items) do
    Log:D("     " .. panel:getName())
  end
end
function Dialog:addLine(dlg, label, data, func)
  local size = label:getContentSize()
  local node = gf:drawLine(0.5, cc.c4f(0.08235294117647059, 0.6705882352941176, 0.00392156862745098, 1), cc.p(0, 1), cc.p(size.width, 1))
  label:removeChildByTag(999)
  label:setTouchEnabled(true)
  node:setTag(999)
  label:addChild(node)
  dlg:bindTouchEndEventListener(label, function()
    if func then
      func(data)
    end
  end)
end
function Dialog:showChildrenName(ctrl)
  if not ctrl then
    Log:D("没有该控件！")
    return
  end
  local items = ctrl:getChildren()
  Log:D(ctrl:getName() .. "子控件为")
  for _, panel in pairs(items) do
    Log:D("     " .. panel:getName())
  end
end
