local FightCommanderSetDlg = Singleton("FightCommanderSetDlg", Dialog)
local COMMAND_TYPE = FightCommanderCmdMgr:getCommandTypeCfg()
local OPER_TYPE = {ALL = 1, TARGET = 0}
function FightCommanderSetDlg:init()
  self:bindListener("DeleteAllButton", self.onDeleteAllButton)
  self:bindListener("DeleteButton", self.onDeleteButton)
  self:bindListener("AddButton", self.onAddButton)
  self:bindListener("CommandButton", self.onCommandButton)
  self:setCtrlVisible("CommandButton", false)
  self.listView = self:getControl("ListView")
  self.itemPanel = self:retainCtrl("ItemPanel")
  FightCommanderCmdMgr:checkRequestExtraCommand()
end
function FightCommanderSetDlg:setData(data)
  self.objId = data.objId
  self.commandType = data.type
  self:refreshCommandList()
  local showCommandBtn = true
  if self.objId == Me:getId() or string.isNilOrEmpty(data.gid) then
    showCommandBtn = false
  end
  if showCommandBtn and Me:isTeamLeader() and TeamMgr:inTeam(self.objId) then
    self:setCtrlVisible("CommandButton", true)
    local obj = TeamMgr:getMemberById(self.objId)
    if obj and obj.gid == FightCommanderCmdMgr.commanderGid then
      self:getControl("CommandButton"):setTitleText(CHS[7190419])
    else
      self:getControl("CommandButton"):setTitleText(CHS[7190418])
    end
  end
end
function FightCommanderSetDlg:refreshCommandList(type)
  if type and type ~= self.commandType then
    return
  end
  local isOpponent = self.commandType == COMMAND_TYPE.ENEMY
  local commandList = FightCommanderCmdMgr:getDefaultCommand(isOpponent)
  local extraList = FightCommanderCmdMgr:getExtraCommand(isOpponent)
  for i = 1, #extraList do
    table.insert(commandList, extraList[i])
  end
  self.listView:removeAllItems()
  local commandCount = #commandList
  local itemCount = math.ceil(commandCount / 2)
  for i = 1, itemCount do
    local itemPanel = self.itemPanel:clone()
    local index1 = 2 * i - 1
    local itemButton1 = itemPanel:getChildByName("ItemButton1")
    itemButton1.cmdText = commandList[index1]
    itemButton1:setTitleText(gf:filtTextOnly(commandList[index1]))
    self:bindTouchEventListener(itemButton1, self.onSelectCommandButton)
    local index2 = 2 * i
    local itemButton2 = itemPanel:getChildByName("ItemButton2")
    if commandList[index2] then
      itemButton2.cmdText = commandList[index2]
      itemButton2:setTitleText(gf:filtTextOnly(commandList[index2]))
      self:bindTouchEventListener(itemButton2, self.onSelectCommandButton)
    else
      itemButton2:setVisible(false)
    end
    self.listView:pushBackCustomItem(itemPanel)
  end
end
function FightCommanderSetDlg:onSelectCommandButton(sender, eventType)
  if eventType == ccui.TouchEventType.ended then
    if not self.objId then
      return
    end
    FightCommanderCmdMgr:requestSetObjectCommand(OPER_TYPE.TARGET, self.objId, sender.cmdText)
    self:onCloseButton()
  end
end
function FightCommanderSetDlg:onDeleteAllButton(sender, eventType)
  FightCommanderCmdMgr:requestSetObjectCommand(OPER_TYPE.ALL, self.commandType, "")
  self:onCloseButton()
end
function FightCommanderSetDlg:onDeleteButton(sender, eventType)
  if not self.objId then
    return
  end
  FightCommanderCmdMgr:requestSetObjectCommand(OPER_TYPE.TARGET, self.objId, "")
  self:onCloseButton()
end
function FightCommanderSetDlg:onAddButton(sender, eventType)
  local dlg = DlgMgr:openDlg("FightCommanderCmdEditDlg")
  dlg:setDlgByType(self.commandType)
end
function FightCommanderSetDlg:onCommandButton(sender, eventType)
  local obj = TeamMgr:getMemberById(self.objId)
  if not obj then
    self:onCloseButton()
    return
  end
  if obj.gid == FightCommanderCmdMgr.commanderGid then
    FightCommanderCmdMgr:requestSetCommander(obj.gid, 0)
  else
    FightCommanderCmdMgr:requestSetCommander(obj.gid, 1)
  end
  self:onCloseButton()
end
function FightCommanderSetDlg:onCloseButton(sender, eventType)
  DlgMgr:closeDlg("CombatStatusDlg")
  DlgMgr:closeDlg(self.name)
end
function FightCommanderSetDlg:cleanup()
  self.objId = nil
  self.commandType = nil
end
return FightCommanderSetDlg
