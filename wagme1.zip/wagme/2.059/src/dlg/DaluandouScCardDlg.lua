local DaluandouScCardDlg = Singleton("DaluandouScCardDlg", Dialog)
function DaluandouScCardDlg:init()
end
function DaluandouScCardDlg:setData(data)
  local cfg = UndergroundMgr:getRetinueCfg(data.name)
  if not cfg then
    return
  end
  local iconPanel = self:getControl("IconPanel")
  self:setImage("HeadImage", ResMgr:getSmallPortrait(cfg.icon), iconPanel)
  if cfg.color == 1 then
    self:setLabelText("NameLabel", data.name, iconPanel, COLOR3.BLUE)
    self:setImagePlist("QualityImage", ResMgr.ui.guard_rank1, iconPanel)
  elseif cfg.color == 2 then
    self:setLabelText("NameLabel", data.name, iconPanel, COLOR3.PURPLE)
    self:setImagePlist("QualityImage", ResMgr.ui.guard_rank2, iconPanel)
  elseif cfg.color == 3 then
    self:setLabelText("NameLabel", data.name, iconPanel, COLOR3.YELLOW)
    self:setImagePlist("QualityImage", ResMgr.ui.guard_rank3, iconPanel)
  end
  self:setCtrlVisible("StarPanel_1", false, iconPanel)
  self:setCtrlVisible("StarPanel_2", false, iconPanel)
  self:setCtrlVisible("StarPanel_3", false, iconPanel)
  self:setCtrlVisible("StarPanel_" .. data.rank, true, iconPanel)
  self:setImage("RaceImage", ResMgr:getRetinueTypeTag(cfg.type), iconPanel)
  self:setImage("PolarImage", ResMgr:getRetinuePolarTag(cfg.polar), iconPanel)
  self:setImage("TypeImage", ResMgr:getRetinueAttackTag(cfg.fightType), iconPanel)
  local attributePanel = self:getControl("AttributePanel")
  self:setLabelText("Label_1", data.life, attributePanel)
  self:setLabelText("Label_2", data.mana, attributePanel)
  self:setLabelText("Label_3", data.phy, attributePanel)
  self:setLabelText("Label_4", data.mag, attributePanel)
  self:setLabelText("Label_5", data.defence, attributePanel)
  self:setLabelText("Label_6", data.speed, attributePanel)
  local skillName, skillEffect = string.match(cfg.effect1, "(.*)：(.*)")
  self:setLabelText("SkillNameLabel1", skillName)
  self:setColorText(skillEffect, "SkillDesPanel1", nil, nil, nil, COLOR3.FLOAT_TEXT_BROWN, 17)
  if not string.isNilOrEmpty(cfg.effect2) then
    local skillName, skillEffect = string.match(cfg.effect2, "(.*)：(.*)")
    self:setLabelText("SkillNameLabel2", skillName)
    self:setColorText(skillEffect, "SkillDesPanel2", nil, nil, nil, COLOR3.FLOAT_TEXT_BROWN, 17)
  else
    self:setLabelText("SkillNameLabel2", "")
    self:getControl("SkillNameLabel2"):setContentSize(self:getControl("SkillNameLabel2"):getContentSize().width, 0)
    self:getControl("SkillDesPanel2"):setContentSize(self:getControl("SkillDesPanel2"):getContentSize().width, 0)
  end
  UndergroundMgr:setRetinueSkillInfo(self, "SkillPanel1")
  UndergroundMgr:setRetinueSkillInfo(self, "SkillPanel2", nil, cfg.skillList[1], cfg.polar)
  if not UndergroundMgr:setRetinueSkillInfo(self, "SkillPanel3", nil, cfg.skillList[2], cfg.polar) then
    self:getControl("SkillPanel3"):setContentSize(0, 0)
  end
  local iconHeight = iconPanel:getContentSize().height
  local attributeHeight = attributePanel:getContentSize().height
  local lineImageHeight1 = self:getControl("LineImage1"):getContentSize().height + 5
  local skillNameHeight1 = self:getControl("SkillNameLabel1"):getContentSize().height
  local skillDesHeight1 = self:getControl("SkillDesPanel1"):getContentSize().height
  local skillNameHeight2 = self:getControl("SkillNameLabel2"):getContentSize().height
  local skillDesHeight2 = self:getControl("SkillDesPanel2"):getContentSize().height
  local lineImageHeight2 = self:getControl("LineImage2"):getContentSize().height + 5
  local skillPanelHeight1 = self:getControl("SkillPanel1"):getContentSize().height
  local skillPanelHeight3 = self:getControl("SkillPanel3"):getContentSize().height
  local bkImage2 = self:getControl("BKImage2")
  local bkImage2Sz = bkImage2:getContentSize()
  bkImage2Sz.height = attributeHeight + lineImageHeight1 + skillNameHeight1 + skillDesHeight1 + skillNameHeight2 + skillDesHeight2 + lineImageHeight2 + skillPanelHeight1 + skillPanelHeight3 + 5
  bkImage2:setContentSize(bkImage2Sz)
  local bkImage1 = self:getControl("BKImage1")
  local bkImage1Sz = bkImage1:getContentSize()
  bkImage1Sz.height = bkImage2Sz.height + iconHeight + 15
  bkImage1:setContentSize(bkImage1Sz)
  self.root:setContentSize(bkImage1Sz)
end
return DaluandouScCardDlg
