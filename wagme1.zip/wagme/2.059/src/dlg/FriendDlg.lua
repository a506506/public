local RadioGroup = require("ctrl/RadioGroup")
local SingleFriend = require("dlg/SingleFriendDlg")
local SystemMessageListDlg = require("dlg/SystemMessageListDlg")
local FriendVerifyOperateDlg = require("dlg/FriendVerifyOperateDlg")
local FlockTags = require("dlg/FlockTagsDlg")
local SingleGroup = require("dlg/SingleGroupDlg")
local FriendInstallDlg = require("dlg/FriendInstallDlg")
local GroupMessageDlg = require("dlg/GroupMessageDlg")
local SingleCreatGroup = require("dlg/SingleCreatGroupDlg")
local FriendDlg = Singleton("FriendDlg", Dialog)
local CHECKBOXS = {
  "FriendCheckBox",
  "TempCheckBox",
  "GroupCheckBox",
  "BlacklistCheckBox",
  "MailCheckBox",
  "InstallCheckBox"
}
local CHECK_BOX_PANEL_LIST = {
  "FriendListPanel",
  "TempPanel",
  "GroupListPanel",
  "BlackListPanel",
  "SystemMessageListDlg",
  "FriendInstallDlg",
  "SearchPanel",
  "SuggestPanel",
  "ChatBoxPanel",
  "FriendVerifyOperateDlg",
  "GroupMessageDlg"
}
local PANEL_TO_INDEX = {
  FriendListPanel = 1,
  TempPanel = 2,
  GroupListPanel = 3,
  BlackListPanel = 4,
  SystemMessageListDlg = 5,
  FriendInstallDlg = 6,
  SearchPanel = 7,
  SuggestPanel = 8,
  ChatBoxPanel = 9,
  FriendVerifyOperateDlg = 10,
  GroupMessageDlg = 11
}
local CHECK_BOX_PANEL_LIST_INDEX = {
  FriendListView = 1,
  TempListView = 2,
  BlackListView = 3,
  SearchListView = 5,
  SuggestListView = 6
}
local SEARCH_CHECKBOX = {
  "SearchWithIdCheckBox",
  "SearchWithNameCheckBox"
}
local GROUP_LIST_MAPPING = {
  [1] = "1listView",
  [2] = "2listView",
  [3] = "3listView",
  [4] = "4listView",
  [6] = "TempListView",
  [5] = "BlackListView",
  [7] = "7listView",
  [8] = "8listView"
}
local ChatPanelTag = 9999
local START_POS = cc.p(5, 64)
local listOrderList = {}
function FriendDlg:init()
  local size = self.root:getContentSize()
  self.rawHeight = size.height
  self:setFullScreen()
  self:bindListener("SuggestButton", self.onSuggestButton)
  self:bindListener("RefreshButton", self.onSuggestButton)
  self:bindListener("BlackReturnButton", self.returnBtn)
  self:bindListener("SearchReturnButton", self.returnBtn)
  self:bindListener("TempReturnButton", self.returnBtn)
  self:bindListener("SuggestReturnButton", self.returnBtn)
  self:bindListener("SearchButton", self.onSearch, "SearchAndSupPanel")
  self:bindListener("SearchButton", self.onSearchOffline, "SearchPanel")
  self:bindListener("NoteButton", self.onSearchNoteButton, "SearchPanel")
  self:bindListener("DelButton", self.onDelButton, "SearchAndSupPanel")
  self:bindListener("CloseButton", self.onCloseButton_1)
  self:bindListener("SearchLabel", self.onSearchLabel)
  self:bindListener("BlogDlgButton", self.onBlogDlgButton)
  self:bindListener("CityDlgButton", self.onCityDlgButton)
  self:bindListener("ChannelDlgButton", self.onChannelButton)
  self:bindListener("FriendReturnButton", self.onChatBoxReturnButton)
  self:bindListener("TempReturnButton", self.onChatBoxReturnButton)
  self:bindListener("NewFriendButton", self.onNewFriendButton)
  self:bindListener("GroupNewsButton", self.onGroupNewsButton)
  self:bindListener("GroupReturnButton", self.onGroupReturnButton)
  self:bindListener("EmptyFriendButton", self.onEmptyFriendButton)
  self:bindFloatPanelListener(self:getControl("SearchTipsPanel", nil, "SearchPanel"), nil, nil, nil, true)
  self:bindFriendSearchEditField("FriendSearchPanel", 6, "DelButton")
  local friendListView = self:getControl("FriendListView")
  local delayRefreshFriendListView
  local function onScrollFrineView(sender, eventType)
    if ccui.ScrollviewEventType.scrolling == eventType or ccui.ScrollviewEventType.scrollToTop == eventType or ccui.ScrollviewEventType.scrollToBottom == eventType then
      do
        local function _onScrolling()
          local listViewCtrl = sender
          local listInnerContent = listViewCtrl:getInnerContainer()
          local innerSize = listInnerContent:getContentSize()
          local listViewSize = listViewCtrl:getContentSize()
          local totalHeight = innerSize.height - listViewSize.height
          local innerPosY = math.floor(listInnerContent:getPositionY() + 0.5)
          local y = listViewSize.height - innerPosY
          local items = listViewCtrl:getItems()
          local item
          for i = 1, #items do
            item = items[i]
            local itemX, itemY = item:getPosition()
            local itemSize = item:getContentSize()
            if y >= itemY and y <= itemY + itemSize.height then
              if item and item.owner and item.owner and item.owner.isOpen then
                self:createFlockTags(item, math.min(y - itemY, 67))
              elseif self.flockTags then
                self.flockTags:setVisible(false)
              end
              item = nil
              break
            end
          end
        end
        performWithDelay(sender, function()
          _onScrolling()
        end, 0)
      end
    end
  end
  friendListView:addScrollViewEventListener(onScrollFrineView)
  self.chatGroupCtrList = {}
  self.friendGroupList = {}
  self:updateView()
  self:updateData()
  self:blinkMove()
  self:doBlogEffect()
  self:doCityView()
  self.tempReturnBtn = self:getControl("TempReturnButton")
  self.friendReturnBtn = self:getControl("FriendReturnButton")
  self.groupReturnBtn = self:getControl("GroupReturnButton")
  self:hookMsg("MSG_MY_APPENTICE_INFO")
  self:hookMsg("MSG_FRIEND_UPDATE_LISTS")
  self:hookMsg("MSG_FRIEND_ADD_CHAR")
  self:hookMsg("MSG_FRIEND_REMOVE_CHAR")
  self:hookMsg("MSG_FRIEND_NOTIFICATION")
  self:hookMsg("MSG_FRIEND_UPDATE_PARTIAL")
  self:hookMsg("MSG_RECOMMEND_FRIEND")
  self:hookMsg("MSG_MESSAGE_EX")
  self:hookMsg("MSG_MESSAGE")
  self:hookMsg("MSG_FINGER")
  self:hookMsg("MSG_FRIEND_ADD_GROUP")
  self:hookMsg("MSG_FRIEND_MOVE_CHAR")
  self:hookMsg("MSG_FRINED_REMOVE_GROUP")
  self:hookMsg("MSG_FRIEND_REFRESH_GROUP")
  self:hookMsg("MSG_DELETE_CHAT_GROUP")
  self:hookMsg("MSG_CHAT_GROUP")
  self:hookMsg("MSG_CHAT_GROUP_PARTIAL")
  self:hookMsg("MSG_CHAT_GROUP_MEMBERS")
  self:hookMsg("MSG_LOGIN_DONE")
  self:hookMsg("MSG_LBS_REMOVE_FRIEND")
  self:hookMsg("MSG_LBS_ADD_FRIEND_OPER")
  self:hookMsg("MSG_LBS_ENABLE")
  self:hookMsg("MSG_UPDATE")
  self:hookMsg("MSG_SET_SETTING")
  self:hookMsg("MSG_FIND_CHAR_MENU_FAIL")
  self:hookMsg("MSG_CHAR_INFO")
end
function FriendDlg:createFlockTags(item, y)
  if not self.flockTags then
    self.flockTags = ccs.GUIReader:getInstance():widgetFromJsonFile("ui/FlockTagsDlg.json")
    self:getControl("ClipPanel", nil, "FriendListPanel"):addChild(self.flockTags)
  else
    self.flockTags:setVisible(true)
  end
  self.flockTags:setPosition(cc.p(START_POS.x, START_POS.y - y))
  local function updateLable()
    self:setLabelText("NameLabel", self:getLabelText("NameLabel", item), self.flockTags)
    self:setLabelText("Numlabel", self:getLabelText("Numlabel", item), self.flockTags)
  end
  updateLable()
  self:setCtrlVisible("NoteButton", self:getControl("NoteButton", nil, item):isVisible(), self.flockTags)
  self:setCtrlVisible("ArrowImage1", self:getControl("ArrowImage1", nil, item):isVisible(), self.flockTags)
  self:setCtrlVisible("ArrowImage2", self:getControl("ArrowImage2", nil, item):isVisible(), self.flockTags)
  if item and item.owner then
    if self.flockTags and self.flockTags.refOb then
      self.flockTags.refOb.dirCb = nil
    end
    item.owner.dirCb = updateLable
    self.flockTags.refOb = item.owner
  end
  self:bindListener("NoteButton", function()
    if item and item.owner and item.owner.onNoteButton then
      item.owner.onNoteButton(item.owner, self:getControl("NoteButton", nil, item))
    end
  end, self.flockTags)
  self:bindListener("ClickPanel", function()
    if item and item.owner and item.owner.onClickPanel then
      item.owner.onClickPanel(item.owner, self:getControl("ClickPanel", nil, item))
    end
  end, self.flockTags)
end
function FriendDlg:doBlogEffect()
  local btn = self:getControl("BlogDlgButton")
  if not btn then
    return
  end
  local hasShowYSGT = cc.UserDefault:getInstance():getIntegerForKey("blogBtnMagic" .. gf:getShowId(Me:queryBasic("gid"))) or 0
  if hasShowYSGT ~= 1 and Me:getLevel() >= 40 and Me:getLevel() <= 75 then
    local effect = btn:getChildByTag(ResMgr.magic.blog_btn)
    if not effect then
      local magic = gf:createLoopMagic(ResMgr.magic.blog_btn)
      magic:setTag(ResMgr.magic.blog_btn)
      magic:setPosition(btn:getContentSize().width * 0.5, btn:getContentSize().height * 0.5)
      btn:addChild(magic)
    end
    cc.UserDefault:getInstance():setIntegerForKey("blogBtnMagic" .. gf:getShowId(Me:queryBasic("gid")), 1)
    self:setCtrlVisible("BlogTipsPanel", true)
  end
end
function FriendDlg:addMagicForCity()
  local btn = self:getControl("CityDlgButton")
  local effect = btn:getChildByTag(ResMgr.magic.blog_btn)
  if not effect then
    local magic = gf:createLoopMagic(ResMgr.magic.blog_btn)
    magic:setTag(ResMgr.magic.blog_btn)
    magic:setPosition(btn:getContentSize().width * 0.5, btn:getContentSize().height * 0.5)
    btn:addChild(magic)
  end
end
function FriendDlg:doCityView()
  local btn = self:getControl("CityDlgButton")
  if not btn then
    return
  end
  if CitySocialMgr:checkCanShowCity() then
    btn:setVisible(true)
  else
    btn:setVisible(false)
    return
  end
  local level, levelTest = CitySocialMgr:getLevelLimit()
  if not DistMgr:curIsTestDist() and level > Me:getLevel() then
    return
  end
  if DistMgr:curIsTestDist() and levelTest > Me:getLevel() then
    return
  end
  local key = "hasCityBtnMagic" .. gf:getShowId(Me:queryBasic("gid"))
  local hasShow = cc.UserDefault:getInstance():getIntegerForKey(key, 0)
  if hasShow ~= 1 then
    local effect = btn:getChildByTag(ResMgr.magic.blog_btn)
    if not effect then
      self:addMagic(btn, ResMgr.magic.blog_btn)
    end
    cc.UserDefault:getInstance():setIntegerForKey(key, 1)
    self:setCtrlVisible("CityTipsPanel", true)
  end
end
function FriendDlg:bindFriendSearchEditField(parentPanelName, lenLimit, clenButtonName)
  local namePanel = self:getControl(parentPanelName)
  local textCtrl = self:getControl("SearchTextField", nil, namePanel)
  self:setCtrlVisible(clenButtonName, false, namePanel)
  self:setCtrlVisible("NoteLabel", true, parentPanelName)
  textCtrl:addEventListener(function(sender, eventType)
    if ccui.TextFiledEventType.insert_text == eventType then
      self:setCtrlVisible(clenButtonName, true, namePanel)
      self:setCtrlVisible("NoteLabel", false, parentPanelName)
      local str = textCtrl:getStringValue()
      if gf:getTextLength(str) > lenLimit * 2 then
        gf:ShowSmallTips(CHS[4000224])
      end
      textCtrl:setText(tostring(gf:subString(str, lenLimit * 2)))
    elseif ccui.TextFiledEventType.delete_backward == eventType then
      local str = sender:getStringValue()
      if "" == str then
        self:setCtrlVisible(clenButtonName, false, namePanel)
        self:setCtrlVisible("NoteLabel", true, parentPanelName)
        self:setFriendGroupPanelList()
      end
    elseif ccui.TextFiledEventType.detach_with_ime == eventType then
      SoundMgr:postEditing()
    end
  end)
  local function onSearchFriend(ctrl, sender, eventType)
    local idOrName = self:getInputText("SearchTextField", "FriendSearchPanel")
    if string.isNilOrEmpty(idOrName) then
      gf:ShowSmallTips(CHS[2100089])
      self:setFriendGroupPanelList()
    else
      local friends = FriendMgr:localSearchFriend(idOrName)
      table.sort(friends, function(l, r)
        return FriendMgr:sortFunc(l, r)
      end)
      if not friends or #friends <= 0 then
        gf:ShowSmallTips(CHS[2100090])
      end
      if self.flockTags then
        self.flockTags:setVisible(false)
      end
      self:setPanelList(friends, "FriendListView", "FriendSlider")
    end
  end
  self:bindListener("SearchButton", onSearchFriend, namePanel)
  self:bindListener(clenButtonName, self.onCleanSearchName, namePanel)
end
function FriendDlg:onCleanSearchName(sender, eventType)
  local namePanel = self:getControl("FriendSearchPanel")
  local textCtrl = self:getControl("SearchTextField", nil, namePanel)
  local str = textCtrl:getStringValue()
  if not string.isNilOrEmpty(str) then
    textCtrl:didNotSelectSelf()
    textCtrl:setText("")
    textCtrl:setDeleteBackward(true)
    self:setCtrlVisible("DelButton", true, namePanel)
    self:setCtrlVisible("NoteLabel", true, namePanel)
    self:setFriendGroupPanelList()
  end
end
function FriendDlg:blinkMove()
  local sartPos, rect, posx
  local movePanel = self:getControl("MovePanel")
  local winSize = self:getWinSize()
  gf:bindTouchListener(movePanel, function(touch, event)
    local toPos = touch:getLocation()
    local eventCode = event:getEventCode()
    if eventCode == cc.EventCode.BEGAN then
      local panelCtrl = self:getControl("FriendPanel")
      rect = self:getBoundingBoxInWorldSpace(movePanel)
      posx = self.root:getPositionX()
      local dlg = DlgMgr.dlgs.SystemMessageShowDlg
      if cc.rectContainsPoint(rect, toPos) and not dlg and self:isVisible() then
        sartPos = toPos
        return true
      end
    elseif eventCode == cc.EventCode.MOVED then
      if toPos.x < sartPos.x then
        local dif = toPos.x - sartPos.x
        self.root:setPositionX(posx + dif)
      end
    elseif eventCode == cc.EventCode.ENDED then
      if toPos.x < rect.x then
        self:moveToWinOut(0.5)
      else
        self:moveToWinIn(0.2)
      end
    end
  end, {
    cc.Handler.EVENT_TOUCH_BEGAN,
    cc.Handler.EVENT_TOUCH_MOVED,
    cc.Handler.EVENT_TOUCH_ENDED
  }, false)
end
function FriendDlg:removeVerifyRedDot()
  if self.friendCheckPanel then
    Dialog.removeRedDot(self.friendCheckPanel, "PortraitImage")
  end
end
function FriendDlg:cleanup()
  if self.friendCheckPanel then
    self.friendCheckPanel.root:release()
    self.friendCheckPanel = nil
  end
  if self.systemMessageDlg then
    self.systemMessageDlg:close()
    self.systemMessageDlg = nil
  end
  if self.friendVerifyOperateDlg then
    self.friendVerifyOperateDlg:close()
    self.friendVerifyOperateDlg = nil
  end
  if self.groupMessageDlg then
    self.groupMessageDlg:close()
    self.groupMessageDlg = nil
  end
  listOrderList = {}
  self.chatName = nil
  self.chatGroupName = nil
  self.chatGid = nil
  self.chatLastUpdateStateTime = nil
  self.flockTags = nil
  local curChatPanel = self:getCurChatPanel()
  if curChatPanel then
    curChatPanel:clear()
  end
  FriendMgr.curVisibleDlg = 1
  self.idx = 1
  DlgMgr:closeDlg("SystemMessageShowDlg")
  RedDotMgr:removeCtrRedDotData("FriendDlg", "FriendVerifyReturnButton")
  RedDotMgr:removeCtrRedDotData("FriendDlg", "FriendReturnButton")
  RedDotMgr:removeCtrRedDotData("FriendDlg", "TempReturnButton")
  RedDotMgr:removeCtrRedDotData("FriendDlg", "GroupReturnButton")
end
function FriendDlg:clearData()
  self.chatGroupCtrList = {}
  self.friendGroupList = {}
  self:updateData(true)
end
function FriendDlg:sortFunc(l, r)
  l.lastChatTime = l.lastChatTime or 0
  r.lastChatTime = r.lastChatTime or 0
  l.hasRedDot = l.hasRedDot or 0
  r.hasRedDot = r.hasRedDot or 0
  l.index = l.index or 0
  r.index = r.index or 0
  if l.hasRedDot > r.hasRedDot then
    return true
  elseif l.hasRedDot < r.hasRedDot then
    return false
  end
  if l.lastChatTime > r.lastChatTime then
    return true
  elseif l.lastChatTime < r.lastChatTime then
    return false
  end
  if l.isOnline < r.isOnline then
    return true
  elseif l.isOnline > r.isOnline then
    return false
  end
  if l.isOnline ~= 2 then
    if 0 < l.isVip and 0 >= r.isVip then
      return true
    elseif 0 >= l.isVip and 0 < r.isVip then
      return false
    end
  end
  if l.friendShip > r.friendShip then
    return true
  elseif l.friendShip < r.friendShip then
    return false
  end
  if l.index < r.index then
    return true
  elseif l.index > r.index then
    return false
  end
  return false
end
function FriendDlg:setPanelList(arr, listView, slider)
  local friends = arr
  table.sort(friends, function(l, r)
    return self:sortFunc(l, r)
  end)
  local list = self:resetData(listView)
  local i = 1
  for i = 1, #friends do
    do
      local func = cc.CallFunc:create(function()
        local friend
        if listView == "TempListView" then
          friend = FriendMgr:convertToUserData(FriendMgr:getTemFriendByGid(friends[i].gid))
        elseif listView == "FriendListView" then
          friend = FriendMgr:convertToUserData(FriendMgr:getFriendByGid(friends[i].gid))
        end
        if friend then
          self:insertOneItem(list, listView, friend, true)
        else
          self:insertOneItem(list, listView, friends[i], true)
        end
      end)
      list:runAction(cc.Sequence:create(cc.DelayTime:create(0.03 * (i - 1)), func))
    end
  end
end
function FriendDlg:resetData(listView, notBounce)
  self[listView] = {}
  listOrderList[listView] = {}
  local list, _ = self:resetListView(listView, 5, nil, nil, notBounce)
  if list then
    list:stopAllActions()
  end
  if listView == "FriendListView" then
    for i = 1, 8 do
      if GROUP_LIST_MAPPING[i] and i ~= 5 and i ~= 6 then
        self[GROUP_LIST_MAPPING[i]] = {}
        listOrderList[GROUP_LIST_MAPPING[i]] = {}
      end
    end
  end
  return list
end
function FriendDlg:insertOneItem(list, listView, friendInfo, isRefresh, notFreshGroupSize)
  if not list then
    return
  end
  if not self[listView] then
    self[listView] = {}
  end
  if self[listView][friendInfo.gid] then
    self:updateOneItem(list, listView, friendInfo)
    return self[listView][friendInfo.gid]
  end
  local singleFriend = SingleFriend.new()
  singleFriend:setData(friendInfo)
  singleFriend.parentListViewIndex = CHECK_BOX_PANEL_LIST_INDEX[listView]
  list:pushBackCustomItem(singleFriend.root)
  list:refreshView()
  if not notFreshGroupSize then
    self:refreshFriendGroupSize(list)
  end
  self[listView][friendInfo.gid] = singleFriend
  if not listOrderList[listView] then
    listOrderList[listView] = {}
  end
  if not self.maxIndex then
    self.maxIndex = {}
  end
  if not self.maxIndex[listView] or #listOrderList[listView] == 0 then
    self.maxIndex[listView] = 0
  end
  friendInfo.index = self.maxIndex[listView] + 1
  self.maxIndex[listView] = friendInfo.index
  table.insert(listOrderList[listView], friendInfo)
  if isRefresh then
    self:refreshList(list, listView, friendInfo)
  end
  return singleFriend
end
function FriendDlg:refreshFriendGroupSize(list)
  local tag = list:getTag()
  local group = self.friendGroupList[tostring(tag)]
  if group then
    group:refreshListViewContentSize()
  end
end
function FriendDlg:refreshList(list, listView, friendInfo)
  if not list then
    return
  end
  local friendCtrl = self[listView][friendInfo.gid]
  if not friendCtrl then
    return
  end
  local arr = listOrderList[listView]
  local index = 0
  if nil == arr then
    arr = {}
  end
  for i = 1, #arr do
    if arr[i].gid == friendInfo.gid then
      friendInfo.index = arr[i].index or 0
      table.remove(arr, i)
      break
    end
  end
  for i = 1, #arr do
    if not self:sortFunc(arr[i], friendInfo) then
      index = i
      table.insert(arr, index, friendInfo)
      break
    end
  end
  if 0 == #arr then
    index = 1
    table.insert(arr, index, friendInfo)
  end
  if 0 == index then
    table.insert(arr, friendInfo)
    index = #arr
  end
  local no = list:getIndex(friendCtrl.root)
  friendCtrl.root:retain()
  list:removeItem(no)
  if 0 > index - 1 or index > #list:getItems() + 1 then
    list:pushBackCustomItem(friendCtrl.root)
  else
    list:insertCustomItem(friendCtrl.root, index - 1)
  end
  list:refreshView()
  friendCtrl.root:release()
  return index
end
function FriendDlg:removeOneItem(list, listView, friendInfo)
  local friendCtrl = self[listView][friendInfo.gid]
  if friendCtrl then
    local dataIndex = self:getFriendInfo(listView, friendInfo.gid)
    local index = list:getIndex(friendCtrl.root)
    list:removeItem(index)
    self[listView][friendInfo.gid] = nil
    table.remove(listOrderList[listView], dataIndex)
    self:refreshFriendGroupSize(list)
  end
end
function FriendDlg:updateOneItem(list, listView, friendInfo)
  if not self[listView] then
    return
  end
  local singleFriend = self[listView][friendInfo.gid]
  local newFriendInfo
  if listView == "TempListView" then
    newFriendInfo = FriendMgr:convertToUserData(FriendMgr:getTemFriendByGid(friendInfo.gid))
  else
    newFriendInfo = FriendMgr:convertToUserData(FriendMgr:getFriendByGid(friendInfo.gid))
  end
  if newFriendInfo then
    friendInfo = newFriendInfo
  end
  if singleFriend then
    self:refreshList(list, listView, friendInfo)
    singleFriend:setData(friendInfo)
  else
    if not self:isLoadfriendsEnd() then
      local groupCtrl = self.friendGroupList[tostring(friendInfo.group)]
      if groupCtrl and friendInfo.hasRedDot == 1 then
        groupCtrl:sortOneFriend(friendInfo.gid)
      end
      return
    end
    self:insertOneItem(list, listView, friendInfo, true)
  end
end
function FriendDlg:updateData(onlyClearData)
  if self.friendCheckPanel then
    self.friendCheckPanel.root:removeFromParentAndCleanup(true)
    self.friendCheckPanel.root:release()
    self.friendCheckPanel = nil
  end
  if onlyClearData then
    self.friendGroupList = {}
    self:resetData("FriendListView", true)
  else
    FriendMgr:setFriendsRedDot()
    self:setFriendGroupPanelList()
  end
  local friends = FriendMgr:getBlackList()
  self:setPanelList(friends, "BlackListView", "BlackSlider")
  local friends = FriendMgr:getTempFriend()
  self:setPanelList(friends, "TempListView", "TempSlider")
  self:setGroupPanelList()
end
function FriendDlg:setFriendGroupPanelList()
  local data = FriendMgr:getFriendGroupData()
  local friendListView = self:getControl("FriendListView")
  self.friendGroupList = {}
  self:resetData("FriendListView", true)
  for i = 1, #data do
    local flockTages = FlockTags.new()
    flockTages:setData(data[i], i)
    friendListView:pushBackCustomItem(flockTages.root)
    self.friendGroupList[data[i].groupId] = flockTages
  end
  local singleCreateGroup = SingleCreatGroup.new()
  local data = {}
  data.type = "friendGroup"
  singleCreateGroup:setData(data)
  friendListView:pushBackCustomItem(singleCreateGroup.root)
end
function FriendDlg:setGroupPanelList()
  local groups = FriendMgr:getChatGroupsData()
  local count = #groups
  local lsitView = self:getControl("GroupListView")
  lsitView:removeAllItems()
  self.chatGroupCtrList = {}
  for i = 1, count do
    local singleGroup = SingleGroup.new()
    singleGroup:setData(groups[i])
    lsitView:pushBackCustomItem(singleGroup)
    self.chatGroupCtrList[groups[i].group_id] = singleGroup
  end
  local singleCreateGroup = SingleCreatGroup.new()
  local data = {}
  data.type = "chatGroup"
  singleCreateGroup:setData(data)
  lsitView:pushBackCustomItem(singleCreateGroup.root)
end
function FriendDlg:updateView()
  self:moveToWinOutAtOnce()
  local winSize = self:getWinSize()
  self.heightScale = winSize.height / Const.UI_SCALE / self.rawHeight
  local panelCtrl = self:getControl("FriendPanel")
  local panelSize = panelCtrl:getContentSize()
  local panelHeght = self.rawHeight * self.heightScale
  panelCtrl:setContentSize(panelSize.width, panelHeght)
  self:updatePage("TempPanel", "TempListView")
  self:updatePage("FriendListPanel", "FriendListView")
  self:updatePage("SearchPanel", "SearchListView")
  self:updatePage("BlackListPanel", "BlackListView")
  self:updatePage("SuggestPanel", "SuggestListView")
  self:updatePage("GroupListPanel", "GroupListView")
  self.systemMessageDlg = SystemMessageListDlg.new()
  self.systemMessageDlg.root:setContentSize(panelSize.width, panelHeght)
  panelCtrl:addChild(self.systemMessageDlg.root)
  self.systemMessageDlg.root:setVisible(false)
  self:updatePage("SystemMessagePanel", "SystemMessageListView", "SystemMessageSlider")
  self.groupMessageDlg = GroupMessageDlg.new()
  self.groupMessageDlg.root:setContentSize(panelSize.width, panelHeght)
  self.groupMessageDlg:adjustDlgSize(self.rawHeight, self.heightScale)
  panelCtrl:addChild(self.groupMessageDlg.root)
  self.groupMessageDlg.root:setVisible(false)
  self:updatePage("GroupMessagePanel")
  self.friendInstallDlg = FriendInstallDlg.new()
  self.friendInstallDlg.root:setContentSize(panelSize.width, panelHeght)
  panelCtrl:addChild(self.friendInstallDlg.root)
  self.friendInstallDlg.root:setVisible(false)
  self:updatePage("FriendInstallOperatePanel", "ListView")
  self.friendVerifyOperateDlg = FriendVerifyOperateDlg.new()
  self.friendVerifyOperateDlg.root:setContentSize(panelSize.width, panelHeght)
  self.friendVerifyOperateDlg:adjustDlgSize(self.rawHeight, self.heightScale)
  panelCtrl:addChild(self.friendVerifyOperateDlg.root)
  self.friendVerifyOperateDlg.root:setVisible(false)
  self.radioGroup = RadioGroup.new()
  self.radioGroup:setItems(self, CHECKBOXS, self.onCheckBoxClick)
  local panelCtrl = self:getControl("ChatBoxPanel", Const.UIPanel)
  local PanelSize = panelCtrl:getContentSize()
  local tmpH = self.rawHeight - PanelSize.height
  panelCtrl:setContentSize(PanelSize.width, self.rawHeight * self.heightScale - tmpH)
  local searchCtrl = self:getControl("SearchTextField", nil, "SearchAndSupPanel")
  searchCtrl:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
  searchCtrl:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
  searchCtrl:addEventListener(function(sender, eventType)
    if ccui.TextFiledEventType.insert_text == eventType then
      self:setCtrlVisible("DelButton", true, "SearchAndSupPanel")
      self:setCtrlVisible("NoteLabel", false, "SearchAndSupPanel")
      local str = sender:getStringValue()
      if gf:getTextLength(str) > 12 then
        str = gf:subString(str, 12)
        searchCtrl:setText(str)
        gf:ShowSmallTips(CHS[3002642])
      end
    elseif ccui.TextFiledEventType.delete_backward == eventType then
      local str = sender:getStringValue()
      if "" == str then
        self:setCtrlVisible("DelButton", false, "SearchAndSupPanel")
        self:setCtrlVisible("NoteLabel", true, "SearchAndSupPanel")
      end
    elseif ccui.TextFiledEventType.detach_with_ime == eventType then
      SoundMgr:postEditing()
    end
  end)
  self:setCtrlVisible("DelButton", false, "SearchAndSupPanel")
  self:setCtrlVisible("NoteLabel", true, "SearchAndSupPanel")
  local closeBtn = self:getControl("CloseButton")
  local centerY = winSize.height / 2 / Const.UI_SCALE
  closeBtn:setPositionY(centerY)
end
function FriendDlg:exchangeWinVisible(idx)
  local i = 0
  for i = 1, #CHECK_BOX_PANEL_LIST do
    local ctrl = self:getControl(CHECK_BOX_PANEL_LIST[i])
    if ctrl then
      ctrl:setVisible(false)
    end
  end
  local ctrlName = CHECKBOXS[idx]
  if ctrlName then
    self:removeRedDot(ctrlName)
  end
  if idx <= 6 and idx >= 1 then
    self.radioGroup:selectRadio(idx, true)
  elseif idx ~= PANEL_TO_INDEX.GroupMessageDlg and idx ~= PANEL_TO_INDEX.FriendVerifyOperateDlg then
    self.radioGroup:unSelectedRadio()
  end
  if CHECK_BOX_PANEL_LIST[idx] ~= "ChatBoxPanel" then
    local ctrl = self:getCurChatPanel()
    if ctrl then
      ctrl:removeFromParent(false)
    end
  end
  local ctrl = self:getControl(CHECK_BOX_PANEL_LIST[idx])
  ctrl:setVisible(true)
  if CHECK_BOX_PANEL_LIST[idx] == "SystemMessageListDlg" then
    self.systemMessageDlg:updateListViewHeight()
  end
  local hasChange = self.idx ~= idx
  self.idx = idx
  if idx ~= PANEL_TO_INDEX.SearchPanel and idx ~= PANEL_TO_INDEX.SuggestPanel and idx ~= PANEL_TO_INDEX.FriendVerifyOperateDlg then
    self:setCtrlVisible("SearchAndSupPanel", false)
  end
  if idx == PANEL_TO_INDEX.FriendListPanel then
    self:setCtrlVisible("NewFriendButton", true)
    self:setCtrlVisible("GroupNewsButton", false)
  elseif idx == PANEL_TO_INDEX.GroupListPanel or idx == PANEL_TO_INDEX.GroupMessageDlg then
    self:setCtrlVisible("NewFriendButton", false)
    self:setCtrlVisible("GroupNewsButton", true)
  elseif idx == PANEL_TO_INDEX.SystemMessageListDlg then
    local widget = ccui.Helper:seekWidgetByName(ctrl, "InfoPanel")
    if widget then
      widget:setVisible(true)
    end
    self:setCtrlVisible("NewFriendButton", false)
    self:setCtrlVisible("GroupNewsButton", false)
  else
    self:setCtrlVisible("NewFriendButton", false)
    self:setCtrlVisible("GroupNewsButton", false)
  end
  if hasChange then
    RedDotMgr:removeOneRedDot("FriendDlg", "GroupReturnButton")
    RedDotMgr:removeOneRedDot("FriendDlg", "TempReturnButton")
    RedDotMgr:removeOneRedDot("FriendDlg", "FriendReturnButton")
  end
end
function FriendDlg:getCurDlgIndex()
  return self.idx
end
function FriendDlg:onCheckBoxClick(sender, curIdx)
  FriendMgr:exchangeFriendDlg(curIdx)
  self:removeRedDot(sender)
  DlgMgr:closeDlg("SystemMessageShowDlg")
  self.chatName = nil
  self.chatGroupName = nil
  self.chatGid = nil
  self.chatLastUpdateStateTime = nil
  self:setCtrlVisible("GroupReturnButton", false)
  if sender:getName() ~= "FriendCheckBox" then
    self:onCleanSearchName()
  end
end
function FriendDlg:dolayoutFriendListView()
  local listView = self:getControl("FriendListView")
  listView:refreshView()
end
function FriendDlg:updatePage(panelName, listViewName)
  local panelCtrl = self:getControl(panelName, Const.UIPanel)
  if not panelCtrl then
    return
  end
  local PanelSize = panelCtrl:getContentSize()
  local tmpH = self.rawHeight - PanelSize.height
  panelCtrl:setContentSize(PanelSize.width, self.rawHeight * self.heightScale - tmpH - 3)
  if listViewName then
    local listViewCtrl = self:getControl(listViewName)
    local listViewSize = listViewCtrl:getContentSize()
    tmpH = self.rawHeight - listViewSize.height
    listViewCtrl:setContentSize(listViewSize.width, self.rawHeight * self.heightScale - tmpH - 3)
  end
  local bkImageCtrl = self:getControl("MessageBKImage", nil, panelCtrl)
  if bkImageCtrl then
    local bkImageSize = bkImageCtrl:getContentSize()
    tmpH = self.rawHeight - bkImageSize.height
    bkImageCtrl:setContentSize(bkImageSize.width, self.rawHeight * self.heightScale - tmpH - 3)
  end
end
function FriendDlg:refreshChatGroupInfo(name, groupId)
  FriendDlg:setGroupChatTips(name, groupId)
end
function FriendDlg:setGroupChatTips(name, groupId)
  if self.chatGid ~= groupId then
    return
  end
  self:setCtrlVisible("GoupInfoPanel", true)
  self:setCtrlVisible("InfoPanel", false)
  local panelCtrl = self:getControl("GoupInfoPanel")
  self:setLabelText("NameLabel", gf:getShowName(name), panelCtrl)
  local online, total = FriendMgr:getOnlinAndTotaleCountsByGroup(groupId)
  if FriendMgr:isQmpkTeamGroup({group_id = groupId}) then
    self:setLabelText("PlayerNumLabel1", total)
    self:setLabelText("PlayerNumLabel2", "/" .. total)
  else
    self:setLabelText("PlayerNumLabel1", online)
    self:setLabelText("PlayerNumLabel2", "/" .. total)
  end
  local groupInfo = FriendMgr:convertGroupInfo(FriendMgr:getChatGroupInfoById(groupId))
  local button = self:getControl("GroupInformationButton")
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
      if groupInfo and Me:queryBasic("gid") == groupInfo.leader_gid then
        local dlg = DlgMgr:openDlg("GroupInformationDlg")
        dlg:setGroupData(groupInfo)
      else
        local dlg = DlgMgr:openDlg("GroupInformationMemberDlg")
        dlg:setGroupData(groupInfo)
      end
    end
  end
  button:addTouchEventListener(listener)
  self:updateLayout("GoupInfoPanel")
end
function FriendDlg:setFriendTips(online)
  if not self.chatGid or not self.chatName then
    return
  end
  local panelCtrl = self:getControl("InfoPanel", nil, "ChatBoxPanel")
  local warningImg = self:getControl("WarningImage", nil, panelCtrl)
  self:setCtrlVisible("GoupInfoPanel", false)
  self:setCtrlVisible("InfoPanel", true)
  local gid = self.chatGid
  local name = self.chatName
  local friendType = CHS[5000070]
  if FriendMgr:isNpcByGid(gid) then
    friendType = ""
    warningImg:setVisible(false)
  elseif FriendMgr:hasFriend(gid) then
    friendType = CHS[5000069]
    warningImg:setVisible(false)
  elseif CitySocialMgr:hasCityFriendByGid(gid) then
    friendType = CHS[5400513]
    warningImg:setVisible(false)
  else
    warningImg:setVisible(true)
  end
  local onlineStr = ""
  local friend = FriendMgr:getFriendByGid(gid) or FriendMgr:getTemFriendByGid(gid)
  if (friend and friend:queryBasicInt("online") == 2 or online == 2) and not FriendMgr:isNpcByGid(gid) then
    onlineStr = CHS[5420217]
  end
  local titleStr = string.format(CHS[5000068], friendType, gf:getRealName(name), onlineStr)
  local namePanel = self:getControl("NamePanel", Const.UIPanel, panelCtrl)
  namePanel:removeAllChildren()
  local size = panelCtrl:getContentSize()
  local titleCtrl = CGAColorTextList:create()
  titleCtrl:setFontSize(20)
  titleCtrl:setString(titleStr)
  titleCtrl:setDefaultColor(COLOR3.TEXT_DEFAULT.r, COLOR3.TEXT_DEFAULT.g, COLOR3.TEXT_DEFAULT.b)
  titleCtrl:updateNow()
  local textW, textH = titleCtrl:getRealSize()
  local layer = tolua.cast(titleCtrl, "cc.LayerColor")
  layer:setPosition(0, textH)
  namePanel:addChild(layer)
  namePanel:setContentSize(textW, textH)
  self:updateLayout("InfoPanel", "ChatBoxPanel")
end
function FriendDlg:setGroupChatInfo(group)
  self.chatGroupName = group.group_name
  local chatBoxPanel = self:getControl("ChatBoxPanel")
  local griupId = group.group_id
  self.chatGid = griupId
  local chatCtrl = FriendMgr:getChatByGid(griupId, chatBoxPanel:getContentSize(), CHAT_CHANNEL.CHAT_GROUP)
  self:setGroupChatTips(group.group_name, group.group_id)
  self:setCtrlVisible("GroupReturnButton", true)
  self:setCtrlVisible("FriendReturnButton", false)
  self:setCtrlVisible("TempReturnButton", false)
  RedDotMgr:removeOneRedDot("FriendDlg", "GroupReturnButton")
  chatCtrl:removeFromParent(false)
  chatBoxPanel:removeChildByTag(ChatPanelTag, false)
  chatBoxPanel:addChild(chatCtrl, 0, ChatPanelTag)
  chatCtrl:refreshChatPanel()
  chatCtrl:setCallBack(self, "sendGroupMsg", CHAT_CHANNEL.CHAT_GROUP)
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.ChatBoxPanel)
  self.root:requestDoLayout()
end
function FriendDlg:setChatInfo(info, isFromFriendpanel)
  local name
  local gid = info.gid
  local friendInfo = FriendMgr:getFriendByGid(gid) or FriendMgr:getTemFriendByGid(gid)
  if friendInfo then
    name = friendInfo:queryBasic("char")
    self.chatIcon = friendInfo:queryBasicInt("icon")
    self.chatLevel = friendInfo:queryBasicInt("level")
  else
    name = info.name
    self.chatIcon = info.icon
    self.chatLevel = info.level or 0
  end
  self.chatName = name
  self.chatGid = gid
  self.chatLastUpdateStateTime = gf:getServerTime()
  self:setFriendTips()
  local chatBoxPanel = self:getControl("ChatBoxPanel")
  local chatCtrl = FriendMgr:getChatByGid(gid, chatBoxPanel:getContentSize(), CHAT_CHANNEL.FRIEND)
  local seleclRadioName = self.radioGroup:getSelectedRadioName()
  self:setCtrlVisible("FriendCheckBox", true)
  self:setCtrlVisible("TempCheckBox", true)
  local showFriendBox = isFromFriendpanel and seleclRadioName == "FriendCheckBox" or not isFromFriendpanel and not FriendMgr:isTempByGid(gid) and FriendMgr:hasFriend(gid)
  if showFriendBox then
    self:setCtrlVisible("FriendReturnButton", true)
    self:setCtrlVisible("TempReturnButton", false)
  else
    self:setCtrlVisible("FriendReturnButton", false)
    self:setCtrlVisible("TempReturnButton", true)
  end
  self:setCtrlVisible("GroupReturnButton", false)
  if not FriendMgr:isNpcByGid(gid) then
    local dist = FriendMgr:getKuafObjDist(gid)
    FriendMgr:requestFriendOnlineState(gid, dist)
  end
  chatCtrl:removeFromParent(false)
  chatBoxPanel:removeChildByTag(ChatPanelTag, false)
  chatBoxPanel:addChild(chatCtrl, 0, ChatPanelTag)
  chatCtrl:refreshChatPanel()
  chatCtrl:setCallBack(self, "sendMsg", CHAT_CHANNEL.FRIEND)
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.ChatBoxPanel)
  if not showFriendBox then
    local friends = FriendMgr.tempList
    for gid, v in pairs(friends) do
      if RedDotMgr:tempFriendHasRedDot(gid) and gid ~= self.chatGid then
        RedDotMgr:insertOneRedDot("FriendDlg", "TempReturnButton")
        break
      end
    end
  end
  self.root:requestDoLayout()
end
function FriendDlg:setSystemMsgInfo(info)
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.SystemMessageListDlg)
end
function FriendDlg:setFriendVerfyInfo(info)
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.FriendVerifyOperateDlg)
  self:setCtrlVisible("SearchAndSupPanel", true)
  RedDotMgr:removeOneRedDot("FriendDlg", "FriendReturnButton")
end
function FriendDlg:sendGroupMsg(text, voiceTime, token)
  if nil == self.chatGroupName then
    return
  end
  local name = self.chatGroupName
  if FriendMgr:sendMsgToChatGroup(name, text, self.chatGid, voiceTime, token) then
    return true
  end
end
function FriendDlg:sendMsg(text, voiceTime, token)
  if nil == self.chatName then
    return
  end
  local name = self.chatName
  FriendMgr:sendMsgToFriend(name, text, self.chatGid, voiceTime, token, self.chatLevel)
  self:MSG_FRIEND_UPDATE_PARTIAL({
    char = name,
    gid = self.chatGid
  })
  return true
end
function FriendDlg:onSuggestButton(sender, eventType)
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.SuggestPanel)
  local leftTime = 60 - (gf:getServerTime() - (self.clickTime or 0))
  if leftTime <= 0 then
    FriendMgr:requetSuggestFriend()
    self.clickTime = gf:getServerTime()
  else
    gf:ShowSmallTips(string.format(CHS[3002643], leftTime))
  end
end
function FriendDlg:returnBtn(sender, eventType)
  self.radioGroup:selectRadio(1)
end
function FriendDlg:onChatBoxReturnButton(sender, eventType)
  if sender:getName() == "FriendReturnButton" then
    self.radioGroup:selectRadio(1)
  elseif not FriendMgr:isTempByGid(self.chatGid) then
    FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.FriendListPanel)
  else
    self.radioGroup:selectRadio(2)
  end
  self:setCtrlVisible("FriendCheckBox", true)
  self:setCtrlVisible("TempCheckBox", true)
  RedDotMgr:removeChatRedDot(self.chatGid)
  self.chatName = nil
  self.chatGid = nil
  self.chatLastUpdateStateTime = nil
end
function FriendDlg:isOutsideWin()
  local winSize = self:getWinSize()
  if self.root:getPositionX() <= -self.root:getContentSize().width / 2 + winSize.x then
    return true
  else
    return false
  end
end
function FriendDlg:isShow()
  return self:isVisible() and not self:isOutsideWin()
end
function FriendDlg:show(noOpenAction)
  local channelDlg = DlgMgr:getDlgByName("ChannelDlg")
  if channelDlg then
    if not channelDlg:isOutsideWin() then
      noOpenAction = true
    end
    channelDlg:moveToWinOutAtOnce()
  end
  if not self:isOutsideWin() then
    noOpenAction = true
  end
  if noOpenAction then
    self:moveToWinInAtOnce()
  else
    self:moveToWinOutAtOnce()
    self:moveToWinIn()
  end
  local gid = self.chatGid
  performWithDelay(self.root, function()
    if self.chatGid and gid == self.chatGid then
      RedDotMgr:removeChatRedDot(self.chatGid)
    end
  end, 0)
end
function FriendDlg:moveToWinOutAtOnce()
  self.root:stopAllActions()
  local winSize = self:getWinSize()
  self.root:setPosition(-self.root:getContentSize().width / 2 + winSize.x, Const.WINSIZE.height / Const.UI_SCALE / 2 + winSize.y)
end
function FriendDlg:moveToWinOut(time)
  DlgMgr:closeDlg("SystemMessageShowDlg")
  local callBack = cc.CallFunc:create(function()
    DlgMgr:closeDlg("SystemMessageShowDlg")
  end)
  local winSize = self:getWinSize()
  local action = cc.MoveTo:create(time or 0.25, cc.p(-self.root:getContentSize().width / 2 + winSize.x, Const.WINSIZE.height / Const.UI_SCALE / 2 + winSize.y))
  self.root:stopAllActions()
  self.root:runAction(cc.Sequence:create(action, callBack))
  RedDotMgr:removeOneRedDot("ChatDlg", "FriendButton")
  RedDotMgr:removeOneRedDot("ChannelDlg", "FriendDlgButton")
  RedDotMgr:removeOneRedDot("HomeFishingDlg", "FriendButton")
  DlgMgr:closeDlg("CharMenuContentDlg")
end
function FriendDlg:moveToWinInAtOnce()
  self.root:stopAllActions()
  local winSize = self:getWinSize()
  self.root:setPosition(Const.WINSIZE.width / Const.UI_SCALE / 2 + winSize.x, Const.WINSIZE.height / Const.UI_SCALE / 2 + winSize.y)
  FriendMgr:checkNeedDoNpcMsgRead(self.chatGid)
end
function FriendDlg:moveToWinIn(time)
  self.root:stopAllActions()
  local winSize = self:getWinSize()
  local moveto = cc.MoveTo:create(time or 0.25, cc.p(Const.WINSIZE.width / Const.UI_SCALE / 2 + winSize.x, Const.WINSIZE.height / Const.UI_SCALE / 2 + winSize.y))
  local callBack = cc.CallFunc:create(function()
    if self.gid then
      DlgMgr:sendMsg("ChatDlg", "hideDoFriendPopup", self.gid)
    end
    FriendMgr:checkNeedDoNpcMsgRead(self.chatGid)
  end)
  self.root:runAction(cc.Sequence:create(moveto, callBack))
end
function FriendDlg:onCloseButton_2(sender, eventType)
  self:moveToWinOut()
end
function FriendDlg:onCloseButton_1(sender, eventType)
  self:moveToWinOut()
end
function FriendDlg:onCommonSearch(sender, from)
  local text = self:getInputText("SearchTextField", "SearchAndSupPanel")
  local curTime = gf:getServerTime()
  if from == "offline_friend" then
    local showId = gf:getShowId(Me:queryBasic("gid")) or ""
    local key = string.format("offlineSearchFalg%s", showId)
    local flag = cc.UserDefault:getInstance():getBoolForKey(key, false)
    if not flag then
      gf:ShowSmallTips(CHS[5420476])
      cc.UserDefault:getInstance():setBoolForKey(key, true)
      self:setCtrlVisible("SearchTipsPanel", true, "SearchPanel")
      return
    end
    if sender.lastTime and curTime - sender.lastTime <= 10 then
      gf:ShowSmallTips(CHS[5420474])
      return
    end
  end
  if "" == text then
    return gf:ShowSmallTips(CHS[3002644])
  end
  if gf:getTextLength(text) < 3 then
    gf:ShowSmallTips(CHS[5420475])
    return
  end
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.SearchPanel)
  self:resetData("SearchListView")
  if not gf:checkRename(text) then
    if gf:getShowId(Me:queryBasic("gid")) == text then
      gf:ShowSmallTips(CHS[3002645])
      return
    end
    local data = {}
    data.char = text
    data.type = 2
    data.from = from
    gf:CmdToServer("CMD_FINGER", data)
  else
    if Me:queryBasic("name") == text then
      gf:ShowSmallTips(CHS[3002645])
      return
    end
    local data = {}
    data.char = text
    data.type = 1
    data.from = from
    gf:CmdToServer("CMD_FINGER", data)
  end
  sender.lastTime = curTime
end
function FriendDlg:onSearchNoteButton(sender, eventType)
  self:setCtrlVisible("SearchTipsPanel", true, "SearchPanel")
end
function FriendDlg:onSearchOffline(sender, eventType)
  self:onCommonSearch(sender, "offline_friend")
end
function FriendDlg:onSearch(sender, eventType)
  self:onCommonSearch(sender, "friend")
end
function FriendDlg:onSearchLabel(sender, eventType)
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.SearchPanel)
end
function FriendDlg:onDelButton(sender, eventType)
  local searchCtrl = self:getControl("SearchTextField", nil, "SearchAndSupPanel")
  searchCtrl:didNotSelectSelf()
  searchCtrl:setText("")
  searchCtrl:setDeleteBackward(true)
  self:setCtrlVisible("NoteLabel", false, "SearchAndSupPanel")
end
function FriendDlg:setSysMsgSelect(info)
  self.systemMessageDlg:setSelectMsgId(info)
end
function FriendDlg:getFriendInfo(listView, gid)
  local curList = listOrderList[listView]
  if nil == curList then
    return
  end
  for k, value in pairs(curList) do
    if value.gid == gid then
      return k, value
    end
  end
  return nil
end
function FriendDlg:MSG_MY_APPENTICE_INFO(data)
  local lastData = MasterMgr:getLastMyMasterInfo()
  if lastData then
    for i = 1, lastData.count do
      local user = lastData.userInfo[i]
      self:MSG_FRIEND_UPDATE_PARTIAL({
        char = user.name,
        gid = user.gid
      })
    end
  end
  for i = 1, data.count do
    local user = data.userInfo[i]
    self:MSG_FRIEND_UPDATE_PARTIAL({
      char = user.name,
      gid = user.gid
    })
  end
end
function FriendDlg:MSG_FRIEND_UPDATE_LISTS(data)
  self:updateData()
end
function FriendDlg:MSG_FRIEND_ADD_CHAR(data)
  for i = 1, data.count do
    local group = tonumber(data[i].group)
    local list = self:getControl(GROUP_LIST_MAPPING[group])
    if list then
      local friendInfo = FriendMgr:convertToUserData(FriendMgr:getFriendByGroupAndGid(group, data[i].gid))
      if not friendInfo then
        if "N/A" == data[i]["party/name"] then
          data[i]["party/name"] = ""
        end
        if group == 6 and data[i].gid == Me:queryBasic("gid") then
          gf:sendErrInfo(ERR_OCCUR.ERROR_TYPE_SELF_ADD_TEMP_FRIEND, "MSG_FRIEND_ADD_CHAR,data=" .. tostringex(data) .. ",stack:" .. gfTraceback())
          friendInfo = nil
        else
          friendInfo = {
            gid = data[i].gid,
            name = data[i].char,
            icon = data[i].icon,
            faction = data[i]["party/name"],
            lev = data[i].level,
            isVip = 0,
            isOnline = data[i].online or 2,
            friendShip = data[i].friend
          }
        end
      end
      if friendInfo then
        self:insertOneItem(list, GROUP_LIST_MAPPING[group], friendInfo, true)
        if group ~= 6 and group ~= 5 then
          self:refreshTempFriend({
            group = 6,
            gid = friendInfo.gid
          })
        end
      end
      if self.chatGid == data[i].gid then
        self.chatName = data[i].char
        self:setFriendTips()
      end
      self:updateListData(data[i], friendInfo)
    end
  end
end
function FriendDlg:updateListData(data, friendInfo)
  if not friendInfo then
    return
  end
  local list = listOrderList[GROUP_LIST_MAPPING[data.group]]
  if nil == list then
    return
  end
  for k, value in pairs(list) do
    if value.gid == friendInfo.gid then
      value.name = data.char
      break
    end
  end
end
function FriendDlg:MSG_FRIEND_REMOVE_CHAR(data)
  local group = tonumber(data.group)
  local list = self:getControl(GROUP_LIST_MAPPING[group])
  local _, friendInfo = self:getFriendInfo(GROUP_LIST_MAPPING[group], data.gid)
  if list and friendInfo then
    self:removeOneItem(list, GROUP_LIST_MAPPING[group], {
      group = data.group,
      name = data.char,
      gid = data.gid
    })
  end
end
function FriendDlg:MSG_FRIEND_NOTIFICATION(data)
  local name = data.char
  local friendInfo = FriendMgr:convertToUserData(FriendMgr:getFriendByName(name))
  if not friendInfo then
    return
  end
  local group = tonumber(friendInfo.group)
  local list = self:getControl(GROUP_LIST_MAPPING[group])
  self:updateOneItem(list, GROUP_LIST_MAPPING[group], friendInfo)
  if self.chatGid == friendInfo.gid then
    self.chatName = friendInfo.name
    self:setFriendTips()
  end
  self:refreshTempFriend({
    group = 6,
    gid = friendInfo.gid
  })
end
function FriendDlg:MSG_FRIEND_UPDATE_PARTIAL(data)
  local name = data.char
  local gid = data.gid
  local charInfo
  local group = tonumber(data.group)
  if FriendMgr:isBlackByGId(gid) then
    charInfo = FriendMgr:getBlackByGid(gid)
  elseif FriendMgr:isTemFriendGroup(group) then
    charInfo = FriendMgr:getTemFriendByGid(gid)
  else
    charInfo = FriendMgr:getFriendByGid(gid)
  end
  local friendInfo = FriendMgr:convertToUserData(charInfo)
  if not friendInfo then
    return
  end
  local group = tonumber(friendInfo.group)
  local list = self:getControl(GROUP_LIST_MAPPING[group])
  self:updateOneItem(list, GROUP_LIST_MAPPING[group], friendInfo)
  if self.chatGid == gid then
    self.chatName = friendInfo.name
    self:setFriendTips()
  end
  if FriendMgr:isFriendGroup(group) then
    self:refreshTempFriend({
      group = 6,
      gid = friendInfo.gid
    })
  end
end
function FriendDlg:refreshTempFriendForNpc(data)
  local group = tonumber(data.group)
  local list = self:getControl(GROUP_LIST_MAPPING[group])
  self:updateOneTempItem(list, GROUP_LIST_MAPPING[group], data)
end
function FriendDlg:refreshTempFriend(data)
  local group = tonumber(data.group)
  if group ~= 6 then
    return
  end
  local friendInfo = FriendMgr:convertToUserData(FriendMgr:getTemFriendByGid(data.gid))
  if not friendInfo then
    return
  end
  local group = tonumber(friendInfo.group)
  local list = self:getControl(GROUP_LIST_MAPPING[group])
  self:updateOneTempItem(list, GROUP_LIST_MAPPING[group], friendInfo)
end
function FriendDlg:updateOneTempItem(list, listView, friendInfo)
  local singleFriend = self[listView][friendInfo.gid]
  local newFriendInfo = FriendMgr:convertToUserData(FriendMgr:getTemFriendByGid(friendInfo.gid))
  if newFriendInfo then
    friendInfo = newFriendInfo
  end
  if singleFriend then
    self:refreshList(list, listView, friendInfo)
    singleFriend:setData(friendInfo)
  else
    self:insertOneItem(list, listView, friendInfo, true)
  end
end
function FriendDlg:updateSingleFriendData(group, gid, needRefresh)
  local list = self:getControl(GROUP_LIST_MAPPING[group])
  local listView = GROUP_LIST_MAPPING[group]
  local singleFriend = self[listView][gid]
  local friendInfo = FriendMgr:convertToUserData(FriendMgr:getFriendByGroupAndGid(group, gid))
  if singleFriend then
    singleFriend:setData(friendInfo)
  end
  if needRefresh then
    self:refreshList(list, listView, friendInfo)
  end
  if self.chatGid == friendInfo.gid then
    self.chatName = friendInfo.name
    self:setFriendTips()
  end
end
function FriendDlg:MSG_FINGER(data)
  local count = data.count
  local search = {}
  if count <= 0 then
    self:resetData("SearchListView")
    return
  end
  for i = 1, count do
    local info = {}
    info.name = data[i].name
    info.icon = data[i].icon
    info.lev = data[i].level
    info.gid = data[i].gid
    info.comeback_flag = data[i].comeback_flag
    info.faction = data[i]["party/name"] or ""
    info.isVip = data[i].insider_level
    info.isOnline = string.isNilOrEmpty(data[i].server_name) and 2 or 1
    info.friendShip = 0
    info.isFromSearch = true
    search[i] = info
  end
  self:setPanelList(search, "SearchListView", "SearchSlider")
end
function FriendDlg:MSG_RECOMMEND_FRIEND(data)
  local count = data.count
  if count <= 0 then
    gf:ShowSmallTips(CHS[5000099])
    self:setCtrlVisible("EmptyPanel", true)
    self:resetData("SuggestListView")
    return
  else
    self:setCtrlVisible("EmptyPanel", false)
  end
  local search = {}
  for i = 1, count do
    local info = {}
    info.name = data[i].name
    info.icon = data[i].icon
    info.lev = data[i].level
    info.gid = data[i].gid
    info.faction = data[i]["party/name"] or ""
    info.isVip = data[i].insider_level
    info.isOnline = 1
    info.friendShip = 0
    search[i] = info
  end
  self:setPanelList(search, "SuggestListView", "SuggestSlider")
end
function FriendDlg:addSingleFriendRedDot(listView, gid)
  if self[listView] and self[listView][gid] then
    local ctrl = Dialog.getControl(self[listView][gid], "PortraitImage")
    self:addRedDot(ctrl, nil, true)
  end
end
function FriendDlg:MSG_MESSAGE(data)
  if CHAT_CHANNEL.FRIEND ~= data.channel then
    return
  end
  local friend = FriendMgr:getFriendByGid(data.gid)
  if friend then
    if self.chatGid ~= data.gid then
      local listView = (friend:queryBasic("group") or "") .. "listView"
      self:addSingleFriendRedDot(listView, data.gid)
      self:addSingleFriendRedDot("FriendListView", data.gid)
    end
  elseif FriendMgr:isTempByGid(data.gid) then
    if nil ~= self.TempListView and nil ~= self.TempListView[data.gid] and self.chatGid ~= data.gid then
      self:addSingleFriendRedDot("TempListView", data.gid)
    end
    local lastUpdateTime = self.chatLastUpdateStateTime or 0
    if data.gid == self.chatGid and gf:getServerTime() - lastUpdateTime > 60 then
      self.chatLastUpdateStateTime = gf:getServerTime()
      local dist = FriendMgr:getKuafObjDist(data.gid)
      FriendMgr:requestFriendOnlineState(data.gid, dist)
    end
  end
  if data.gid == self.chatGid and data.name ~= self.chatName then
    self.chatName = data.name
    self:setFriendTips()
  end
end
function FriendDlg:MSG_MESSAGE_EX(data)
  self:MSG_MESSAGE(data)
end
function FriendDlg:isCanSpeak()
  if self:getControl("ChatBoxPanel"):isVisible() then
    return true
  else
    return false
  end
end
function FriendDlg:onBlogDlgButton(sender)
  BlogMgr:openBlog()
  local effect = sender:getChildByTag(ResMgr.magic.blog_btn)
  if effect then
    effect:removeFromParent()
  end
  self:setCtrlVisible("BlogTipsPanel", false)
end
function FriendDlg:onCityDlgButton(sender)
  if CitySocialMgr:checkOpenCityDlg() then
    CitySocialMgr:requestOpenCity()
  end
  local effect = sender:getChildByTag(ResMgr.magic.blog_btn)
  if effect then
    effect:removeFromParent()
  end
  self:setCtrlVisible("CityTipsPanel", false)
end
function FriendDlg:onChannelButton()
  self:moveToWinOutAtOnce()
  local dlg = DlgMgr:openDlg("ChannelDlg")
  dlg:moveToWinInAtOnce()
  DlgMgr:reorderDlgByName("ChannelDlg")
  RedDotMgr:removeOneRedDot("ChatDlg", "FriendButton")
  RedDotMgr:removeOneRedDot("ChannelDlg", "FriendDlgButton")
  RedDotMgr:removeOneRedDot("HomeFishingDlg", "FriendButton")
  DlgMgr:closeDlg("SystemMessageShowDlg")
  self:onCleanSearchName()
end
function FriendDlg:onCheckAddRedDot(ctrlName)
  local isTemChat = self.chatGid and self.tempReturnBtn:isVisible()
  local isFriendChat = self.chatGid and self.friendReturnBtn:isVisible()
  local isGroupChat = self.chatGid and self.groupReturnBtn:isVisible()
  if "TempCheckBox" == ctrlName and (isTemChat or self.radioGroup:getSelectedRadioName() == "TempCheckBox") then
    return false
  elseif "FriendCheckBox" == ctrlName and (isFriendChat or self.radioGroup:getSelectedRadioName() == "FriendCheckBox") then
    return false
  elseif "GroupCheckBox" == ctrlName and (isGroupChat or self.radioGroup:getSelectedRadioName() == "GroupCheckBox") then
    return false
  elseif PANEL_TO_INDEX.GroupMessageDlg == self.idx and ctrlName == "GroupNewsButton" then
    return false
  elseif PANEL_TO_INDEX.FriendVerifyOperateDlg == self.idx and ctrlName == "NewFriendButton" then
    return false
  elseif "MailCheckBox" == ctrlName then
    return not self:isCheck("MailCheckBox")
  elseif ctrlName == "FriendReturnButton" and not isFriendChat then
    return false
  elseif ctrlName == "TempReturnButton" and not isTemChat then
    return false
  elseif ctrlName == "GroupReturnButton" and not isGroupChat and PANEL_TO_INDEX.GroupMessageDlg ~= self.idx then
    return false
  else
    return true
  end
end
function FriendDlg:getCurChatName()
  return self.chatName
end
function FriendDlg:getCurChatGroupName()
  return self.chatGroupName
end
function FriendDlg:getCurChatGid()
  return self.chatGid
end
function FriendDlg:getCurChatLevel()
  local friendInfo = FriendMgr:getFriendByGid(self.chatGid) or FriendMgr:getTemFriendByGid(self.chatGid)
  if friendInfo then
    self.chatLevel = friendInfo:queryBasicInt("level")
  end
  return self.chatLevel
end
function FriendDlg:getCurChatPanel()
  local chatBoxPanel = self:getControl("ChatBoxPanel")
  if not chatBoxPanel or not self.chatGid then
    return
  end
  local chatPanel = chatBoxPanel:getChildByTag(ChatPanelTag)
  return chatPanel
end
function FriendDlg:sortGroupList()
  local lsitView = self:getControl("GroupListView")
  local groups = FriendMgr:getChatGroupsData()
  local count = #lsitView:getItems()
  for i = 1, count - 1 do
    local item = lsitView:getItem(i - 1)
    if item then
      item:setData(groups[i])
      self.chatGroupCtrList[groups[i].group_id] = item
    end
  end
end
function FriendDlg:isLoadfriendsEnd()
  local load = true
  if self.friendGroupList then
    for k, v in pairs(self.friendGroupList) do
      if v and not v:getLoadIsEnd() then
        load = false
        break
      end
    end
  end
  return load
end
function FriendDlg:onNewFriendButton(sender, eventType)
  self:setFriendVerfyInfo({})
  self:onCleanSearchName()
end
function FriendDlg:onGroupNewsButton(sender, eventType)
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.GroupMessageDlg)
  self:setCtrlVisible("GroupReturnButton", true)
  SystemMessageMgr:redAllGgroupMsg()
  RedDotMgr:removeOneRedDot("FriendDlg", "GroupReturnButton")
end
function FriendDlg:onGroupReturnButton(sender, eventType)
  FriendMgr:exchangeFriendDlg(PANEL_TO_INDEX.GroupListPanel)
  self:setCtrlVisible("GroupReturnButton", false)
  self.chatGroupName = nil
  self.chatGid = nil
  self.chatLastUpdateStateTime = nil
end
function FriendDlg:onEmptyFriendButton(sender, eventType)
  local tempList = FriendMgr.tempList
  if tempList and next(tempList) then
    local str = CHS[5400040]
    if RedDotMgr:hasRedDotInfoByOnlyDlgName("tempFriendChat") then
      str = CHS[5400436]
    end
    gf:confirm(str, function()
      self:resetData("TempListView")
      FriendMgr:delAllTempFriend()
    end)
  else
    gf:ShowSmallTips(CHS[5410030])
  end
end
function FriendDlg:MSG_FRIEND_ADD_GROUP(data)
  local friendListView = self:getControl("FriendListView")
  local friendsGroup = FriendMgr:getFriendsGroupsInfoById(data.groupId)
  local flockTages = FlockTags.new()
  flockTages:setData(friendsGroup)
  local index = #friendListView:getItems() - 1
  if index < 0 then
    friendListView:pushBackCustomItem(flockTages.root)
  else
    friendListView:insertCustomItem(flockTages.root, #friendListView:getItems() - 1)
  end
  self.friendGroupList[data.groupId] = flockTages
end
function FriendDlg:MSG_FRINED_REMOVE_GROUP(data)
  local groupId = data.groupId
  local friendListView = self:getControl("FriendListView")
  local index = friendListView:getIndex(self.friendGroupList[data.groupId].root)
  friendListView:removeItem(index)
  self[GROUP_LIST_MAPPING[tonumber(groupId)]] = nil
  listOrderList[GROUP_LIST_MAPPING[tonumber(groupId)]] = nil
end
function FriendDlg:MSG_FRIEND_MOVE_CHAR(data)
  local count = 0
  for i = 1, #data.gidList do
    do
      local moveFriends = cc.CallFunc:create(function()
        local gid = data.gidList[i]
        local friend = FriendMgr:getFriendByGid(gid)
        if friend then
          local friendData = {}
          friendData.group = data.toId
          friendData.char = friend:queryBasic("char")
          friendData.gid = friend:queryBasic("gid")
          local freindsList = {}
          freindsList.count = 1
          freindsList[1] = friendData
          self:MSG_FRIEND_ADD_CHAR(freindsList)
          local friendData = {}
          friendData.group = data.fromId
          friendData.char = friend:queryBasic("char")
          friendData.gid = friend:queryBasic("gid")
          self:MSG_FRIEND_REMOVE_CHAR(friendData)
        end
        count = count - 1
      end)
      self.root:runAction(cc.Sequence:create(cc.DelayTime:create(0.02 * count), moveFriends))
      count = count + 1
    end
  end
end
function FriendDlg:MSG_FRIEND_REFRESH_GROUP(data)
  if not self.friendGroupList then
    return
  end
  local flockTags = self.friendGroupList[data.groupId]
  local friendsGroup = FriendMgr:getFriendsGroupsInfoById(data.groupId)
  if flockTags then
    flockTags:refreshGroupInfo(friendsGroup)
  end
end
function FriendDlg:MSG_DELETE_CHAT_GROUP(data)
  local lsitView = self:getControl("GroupListView")
  local ctrl = self.chatGroupCtrList[data.groupId]
  local index = lsitView:getIndex(ctrl)
  lsitView:removeItem(index)
  self.chatGroupCtrList[data.groupId] = nil
end
function FriendDlg:MSG_CHAT_GROUP(data)
  local lsitView = self:getControl("GroupListView")
  local group = FriendMgr:getChatGroupInfoById(data.groupId)
  local singleGroup = SingleGroup.new()
  singleGroup:setData(FriendMgr:convertGroupInfo(group))
  if self.chatGroupCtrList and not self.chatGroupCtrList[data.groupId] then
    self.chatGroupCtrList[data.groupId] = singleGroup
    local index = #lsitView:getItems() - 1
    if index < 0 then
      lsitView:pushBackCustomItem(singleGroup)
    else
      lsitView:insertCustomItem(singleGroup, index)
    end
    self:sortGroupList()
  end
end
function FriendDlg:MSG_CHAT_GROUP_PARTIAL(data)
  local singleGroup = self.chatGroupCtrList[data.groupId]
  if singleGroup then
    local groupData = FriendMgr:getChatGroupInfoById(data.groupId)
    if not groupData then
      return
    end
    local groupInfo = FriendMgr:convertGroupInfo(groupData)
    if not groupInfo then
      return
    end
    singleGroup:setData(groupInfo)
    self:refreshChatGroupInfo(groupInfo.group_name, data.groupId)
    if self.chatGid == data.groupId and self.chatGroupName and self.chatGroupName ~= data.group_name then
      self.chatGroupName = groupInfo.group_name
    end
  end
end
function FriendDlg:MSG_CHAT_GROUP_MEMBERS(data)
  local groupData = FriendMgr:getChatGroupInfoById(data.group_id)
  if not groupData then
    return
  end
  local groupInfo = FriendMgr:convertGroupInfo(groupData)
  self:refreshChatGroupInfo(groupInfo.group_name, data.group_id)
end
function FriendDlg:MSG_LOGIN_DONE(data)
  local chatPanel = self:getCurChatPanel()
  if not chatPanel then
    return
  end
  FriendMgr:setChatByGid(self.chatGid, chatPanel)
end
function FriendDlg:MSG_LBS_REMOVE_FRIEND(data)
  if self.chatGid == data.gid then
    self:setFriendTips()
  end
end
function FriendDlg:MSG_LBS_ADD_FRIEND_OPER(data)
  if self.chatGid == data.gid then
    self.chatName = data.char
    self:setFriendTips()
  end
end
function FriendDlg:MSG_LBS_ENABLE(data)
  self:doCityView()
end
function FriendDlg:MSG_UPDATE(data)
  if data["setting/auto_reply_msg"] and self.friendInstallDlg then
    self.friendInstallDlg:setUiInfo()
  end
end
function FriendDlg:MSG_SET_SETTING(data)
  if data.setting.auto_reply_msg and self.friendInstallDlg then
    self.friendInstallDlg:updateAutoReplyButton()
  end
end
function FriendDlg:MSG_FIND_CHAR_MENU_FAIL(data)
  local listView = "SearchListView"
  if not self[listView] or not next(self[listView]) then
    return
  end
  local _, friendInfo = self:getFriendInfo(listView, data.char_id)
  if not friendInfo then
    return
  end
  friendInfo.isOnline = 2
  if friendInfo and self[listView][friendInfo.gid] then
    self[listView][friendInfo.gid]:setData(friendInfo)
  end
end
function FriendDlg:MSG_CHAR_INFO(data)
  local listView = "SearchListView"
  if not self[listView] or not next(self[listView]) then
    return
  end
  local _, friendInfo = self:getFriendInfo(listView, data.gid)
  if not friendInfo then
    return
  end
  friendInfo.name = data.name
  friendInfo.icon = data.icon
  friendInfo.lev = data.level
  friendInfo.comeback_flag = data.comeback_flag
  friendInfo.faction = data.party
  friendInfo.isVip = data.vip
  friendInfo.isOnline = 1
  if friendInfo and self[listView][friendInfo.gid] then
    self[listView][friendInfo.gid]:setData(friendInfo)
  end
end
return FriendDlg
