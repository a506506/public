local BaosjcDlg = Singleton("BaosjcDlg", Dialog)
local CONTENT_POOL = {
  CHS[4101627],
  CHS[4101628],
  CHS[4101629],
  CHS[4101630],
  CHS[4101631],
  CHS[4101632]
}
local GAME_STAGE = {
  PREPARE = "prepare",
  MAI_BAOSHI = "hide",
  XUNZHAO_BAOSHI = "running",
  END = "end"
}
function BaosjcDlg:init(data)
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel", "BKPanel")
  self:setCtrlFullClient("BlackPanel2")
  self:bindListener("ChatButton", self.onChatButton, "OtherPanel")
  self:bindListener("ChatButton", self.onChatButton, "SelfInfoPanel")
  self:setCtrlVisible("CoverPanel", true)
  self:setCtrlVisible("RightTimePanel", false)
  self:setCtrlVisible("TitlePanel", false)
  self:setCtrlVisible("ResultPanel", false)
  local selfContentPanel = self:getControl("SelectContentPanel", nil, "SelfInfoPanel")
  local otherContentPanel = self:getControl("SelectContentPanel", nil, "OtherPanel")
  self:bindFloatPanelListener(selfContentPanel)
  self:bindFloatPanelListener(otherContentPanel)
  for i = 1, 6 do
    self:bindListener("Panel_" .. i, self.onContentPanel, selfContentPanel)
    self:bindListener("Panel_" .. i, self.onContentPanel, otherContentPanel)
  end
  self.selectImage = self:retainCtrl("ChosenImage")
  local otherPanel = self:getControl("OtherPanel")
  local myPanel = self:getControl("SelfInfoPanel")
  for i = 1, 4 do
    local rowPanel = self:getControl("Row_" .. i, nil, otherPanel)
    local rowPanel2 = self:getControl("Row_" .. i, nil, myPanel)
    for j = 1, 4 do
      local unitPanel = self:getControl("RockPanel_" .. j, nil, rowPanel)
      unitPanel.x = j
      unitPanel.y = i
      self:setCtrlOnlyEnabled("ItemImage", false, unitPanel)
      self:bindTouchEndEventListener(unitPanel, self.onOtherRockPanel)
      self:refreashRock(unitPanel)
      local unitPanel = self:getControl("RockPanel_" .. j, nil, rowPanel2)
      unitPanel.x = j
      unitPanel.y = i
      self:setCtrlOnlyEnabled("ItemImage", false, unitPanel)
      self:bindTouchEndEventListener(unitPanel, self.onMyRockPanel)
      self:refreashRock(unitPanel)
    end
  end
  self:bindListener("NoteButton", self.onNoteButton)
  self:bindListener("CancelAutoButton", self.onCancelAutoButton)
  self:bindListener("Button_1", self.onButton_1)
  self:bindListener("Button_2", self.onButton_2)
  self:bindListener("Button_1", self.onButton_1)
  self:bindListener("Button_2", self.onButton_2)
  self:bindListener("ExitButton_1", self.onExitButton)
  self:bindListener("ContinueButton", self.onContinueButton)
  self:bindListener("ExitButton_2", self.onExitButton)
  self:initChatContent()
  self.flyBaoshi = {}
  self.flyId = 0
  self.load = false
  self:hookMsg("MSG_NATIONAL_2019_BSJC_DATA")
  self:hookMsg("MSG_NATIONAL_2019_BSJC_BONUS")
  self:hookMsg("MSG_MESSAGE_EX")
  self:MSG_NATIONAL_2019_BSJC_DATA(data)
end
function BaosjcDlg:refreashRock(panel, type)
  if not type or type == 1 then
    self:setCtrlVisible("ItemImage", true, panel)
    local img = self:setImage("ItemImage", ResMgr:getItemIconPath(21015), panel)
    img:setScale(1)
    local img = self:setCtrlVisible("ShadowImage", true, panel)
    img:setScale(1)
    local img = self:setCtrlVisible("RockImage", true, panel)
    img:setScale(1)
  elseif type == 2 then
    self:setCtrlVisible("ItemImage", true, panel)
    self:setCtrlVisible("ShadowImage", true, panel)
    self:setCtrlVisible("RockImage", false, panel)
  elseif type == 3 then
    self:setCtrlVisible("ItemImage", false, panel)
    self:setCtrlVisible("ShadowImage", false, panel)
    self:setCtrlVisible("RockImage", false, panel)
  end
end
function BaosjcDlg:setTitle(title)
  self:setLabelText("Label", title, "TitlePanel")
end
function BaosjcDlg:setMaiBaoshiStage()
  self:setTitle(CHS[4101633])
  self.timerMaibaoshi = self:startSchedule(function()
    local ti = math.max(self.data.end_time - gf:getServerTime(), 0)
    ti = math.min(30, ti)
    self:setLabelText("Label_1", ti, "RightTimePanel")
    if ti <= 0 then
      self:stopSchedule(self.timerMaibaoshi)
      self.timerMaibaoshi = nil
    end
  end, 0.1)
end
function BaosjcDlg:refreashRockData(data)
  data = data or self.data
  if data.status == GAME_STAGE.PREPARE or data.status == GAME_STAGE.END then
    return
  end
  local otherPanel = self:getControl("OtherPanel")
  local myPanel = self:getControl("SelfInfoPanel")
  for i = 1, 4 do
    local rowPanel = self:getControl("Row_" .. i, nil, otherPanel)
    local rowPanel2 = self:getControl("Row_" .. i, nil, myPanel)
    for j = 1, 4 do
      local unitPanel = self:getControl("RockPanel_" .. j, nil, rowPanel)
      local idx = self:getTheIdxByXY(unitPanel.x, unitPanel.y)
      local state = data.board_info.Other[idx].state
      if state == 1 then
        self:refreashRock(unitPanel, 3)
      end
      local unitPanel = self:getControl("RockPanel_" .. j, nil, rowPanel2)
      local idx = self:getTheIdxByXY(unitPanel.x, unitPanel.y)
      if not data or not data.board_info or not data.board_info.Me or not data.board_info.Me[idx] then
        local ss
      end
      if data.board_info.Me[idx].state == 1 then
        self:refreashRock(unitPanel, 3)
      elseif data.board_info.Me[idx].type == 1 then
        self:refreashRock(unitPanel, 2)
      end
    end
  end
end
function BaosjcDlg:cleanup()
  self:stopScheduleAll()
  for _, image in pairs(self.flyBaoshi) do
    image:removeFromParent()
  end
  self.flyBaoshi = {}
end
function BaosjcDlg:stopScheduleAll()
  if self.timerMaibaoshi then
    self:stopSchedule(self.timerMaibaoshi)
    self.timerMaibaoshi = nil
  end
  if self.timerXunzhaobaoshi then
    self:stopSchedule(self.timerXunzhaobaoshi)
    self.timerXunzhaobaoshi = nil
  end
end
function BaosjcDlg:setXunZhaoBaoshiStage()
  self.timerXunzhaobaoshi = self:startSchedule(function()
    local ti = math.max(self.data.end_time - gf:getServerTime(), 0)
    ti = math.min(30, ti)
    self:setLabelText("Label_1", ti, "RightTimePanel")
    if ti <= 0 then
      self:stopSchedule(self.timerXunzhaobaoshi)
      self.timerXunzhaobaoshi = nil
    end
  end, 0.1)
end
function BaosjcDlg:setGameSatge(data)
  if data.status == GAME_STAGE.PREPARE or data.status == GAME_STAGE.END then
    local maxTime = math.min(data.end_time, gf:getServerTime() + 3)
    gf:startCountDowm(maxTime)
  elseif data.status == GAME_STAGE.MAI_BAOSHI then
    self:setMaiBaoshiStage()
  elseif data.status == GAME_STAGE.XUNZHAO_BAOSHI then
    self:setXunZhaoBaoshiStage()
  end
end
function BaosjcDlg:refreashStoneItem(data)
  data = data or self.data
  local myStonePanel = self:getControl("StonePanel", nil, "SelfInfoPanel")
  local otherStonePanel = self:getControl("StonePanel", nil, "OtherPanel")
  if data.status == GAME_STAGE.MAI_BAOSHI or data.status == GAME_STAGE.PREPARE then
    for i = 1, 3 do
      local n = 3 - data.corp_info.Me.last_baoshi
      self:setCtrlVisible("Image_" .. i, i > n, myStonePanel)
      self:setImage("Image_" .. i, ResMgr:getItemIconPath(21015), myStonePanel)
      local n = 3 - data.corp_info.Other.last_baoshi
      self:setCtrlVisible("Image_" .. i, i > n, otherStonePanel)
      self:setImage("Image_" .. i, ResMgr:getItemIconPath(21015), otherStonePanel)
    end
  elseif data.status == GAME_STAGE.XUNZHAO_BAOSHI then
    for i = 1, 3 do
      local n = 3 - data.board_info.Other.takedNum
      self:setCtrlVisible("Image_" .. i, i > n, myStonePanel)
      local n = 3 - data.board_info.Me.takedNum
      self:setCtrlVisible("Image_" .. i, i > n, otherStonePanel)
      self:setImage("Image_" .. i, ResMgr:getItemIconPath(21015), myStonePanel)
      self:setImage("Image_" .. i, ResMgr:getItemIconPath(21015), otherStonePanel)
    end
  end
end
function BaosjcDlg:initChatContent()
  local selfContentPanel = self:getControl("SelectContentPanel", nil, "SelfInfoPanel")
  local otherContentPanel = self:getControl("SelectContentPanel", nil, "OtherPanel")
  for i = 1, 6 do
    local selfPanel = self:getControl("Panel_" .. i, nil, selfContentPanel)
    local str = BrowMgr:addGenderSign(CONTENT_POOL[i], Me:queryBasicInt("gender"))
    self:setColorText(str, selfPanel, nil, nil, nil, COLOR3.WHITE, nil, LOCATE_POSITION.MID_BOTTOM)
    local otherPanel = self:getControl("Panel_" .. i, nil, otherContentPanel)
    local str = BrowMgr:addGenderSign(CONTENT_POOL[i], Me:queryBasicInt("gender"))
    self:setColorText(str, otherPanel, nil, nil, nil, COLOR3.WHITE, nil, LOCATE_POSITION.MID_BOTTOM)
  end
end
function BaosjcDlg:getTheIdxByXY(x, y)
  return (y - 1) * 4 + x
end
function BaosjcDlg:onMyRockPanel(sender, eventType)
  local x = sender.x
  local y = sender.y
  local data = self.data.corp_info.Me
  if self.data.status == GAME_STAGE.MAI_BAOSHI then
    if data.last_baoshi <= 0 then
      gf:ShowSmallTips(CHS[4101635])
      return
    end
    local boardInfo = self.data.board_info.Me
    local idx = self:getTheIdxByXY(x, y)
    if boardInfo[idx].type == 1 then
      gf:ShowSmallTips(CHS[4101636])
      return
    end
    BlogMgr:showButtonList(self, sender, "BaosjcDlgMairu", self.name)
  elseif self.data.status == GAME_STAGE.XUNZHAO_BAOSHI then
    gf:ShowSmallTips(CHS[4101637])
    return
  elseif self.data.status == GAME_STAGE.PREPARE then
    return
  end
  self.selectImage:removeFromParent()
  sender:addChild(self.selectImage)
end
function BaosjcDlg:onOtherRockPanel(sender, eventType)
  local x = sender.x
  local y = sender.y
  local idx = self:getTheIdxByXY(x, y)
  if self.data.status == GAME_STAGE.MAI_BAOSHI then
    gf:ShowSmallTips(CHS[4101638])
    return
  elseif self.data.status == GAME_STAGE.XUNZHAO_BAOSHI then
    if self.data.gid ~= Me:queryBasic("gid") then
      gf:ShowSmallTips(CHS[4101639])
      return
    end
    if self.data.board_info.Other.takedNum >= 3 then
      gf:ShowSmallTips(CHS[4101640])
      return
    end
    if self.data.board_info.Other[idx].state == 1 then
      gf:ShowSmallTips(CHS[4101641])
      return
    end
    BlogMgr:showButtonList(self, sender, "BaosjcDlgZhakai", self.name)
  elseif self.data.status == GAME_STAGE.PREPARE then
    return
  end
  gf:CmdToServer("CMD_NATIONAL_2019_BSJC_FIND", {
    index = idx - 1,
    para = "select"
  })
  self.selectImage:removeFromParent()
  sender:addChild(self.selectImage)
end
function BaosjcDlg:onBaosjcDlgMairu(sender)
  local x = sender.x
  local y = sender.y
  local data = self.data.corp_info.Me
  gf:PrintMap(data)
  local idx = self:getTheIdxByXY(x, y)
  if data.last_baoshi <= 0 then
    gf:ShowSmallTips(CHS[4101635])
    return
  end
  local boardInfo = self.data.board_info.Me
  local idx = self:getTheIdxByXY(x, y)
  if boardInfo[idx].type == 1 then
    gf:ShowSmallTips(CHS[4101636])
    return
  end
  self.selectImage:removeFromParent()
  gf:CmdToServer("CMD_NATIONAL_2019_BSJC_CANG", {
    index = idx - 1
  })
end
function BaosjcDlg:onBaosjcDlgZhakai(sender)
  local x = sender.x
  local y = sender.y
  local idx = self:getTheIdxByXY(x, y)
  if self.data.gid ~= Me:queryBasic("gid") then
    gf:ShowSmallTips(CHS[4101639])
    return
  end
  if self.data.board_info.Other.takedNum >= 3 then
    gf:ShowSmallTips(CHS[4101640])
    return
  end
  if self.data.board_info.Other[idx].state == 1 then
    gf:ShowSmallTips(CHS[4101641])
    return
  end
  local para = Me:queryBasic("gid") .. ":" .. idx - 1
  gf:CmdToServer("CMD_NATIONAL_2019_BSJC_FIND", {
    index = idx - 1,
    para = para
  })
  self.selectImage:removeFromParent()
end
function BaosjcDlg:onNoteButton(sender, eventType)
  DlgMgr:openDlg("BaosjcRuleDlg")
end
function BaosjcDlg:onButton_1(sender, eventType)
end
function BaosjcDlg:onButton_2(sender, eventType)
end
function BaosjcDlg:onChatButton(sender, eventType)
  local panel = sender:getParent()
  self:setCtrlVisible("SelectContentPanel", true, panel)
end
function BaosjcDlg:onContentPanel(sender, eventType)
  if not sender.text then
    return
  end
  local data = {}
  data.channel = 4
  data.msg = sender.text
  data.orgLength = string.len(data.msg)
  gf:CmdToServer("CMD_CHAT_EX", data)
end
function BaosjcDlg:onCancelAutoButton(sender, eventType)
  gf:CmdToServer("CMD_NATIONAL_2019_BSJC_CANCEL_TRUSTEESHIP")
end
function BaosjcDlg:onButton_1(sender, eventType)
end
function BaosjcDlg:onButton_2(sender, eventType)
end
function BaosjcDlg:onExitButton(sender, eventType)
  gf:CmdToServer("CMD_NATIONAL_2019_BSJC_QUIT")
  DlgMgr:closeDlg(self.name)
end
function BaosjcDlg:onContinueButton(sender, eventType)
  gf:CmdToServer("CMD_NATIONAL_2019_BSJC_CONTINUE")
end
function BaosjcDlg:setColorText(str, panelName, root, marginX, marginY, defColor, fontSize, locate, isPunct, isVip)
  marginX = marginX or 0
  marginY = marginY or 0
  root = root or self.root
  fontSize = fontSize or 20
  defColor = defColor or COLOR3.TEXT_DEFAULT
  local panel
  if type(panelName) == "string" then
    panel = self:getControl(panelName, Const.UIPanel, root)
  else
    panel = panelName
  end
  if not panel then
    return
  end
  panel:removeAllChildren()
  panel.text = str
  local size = panel:getContentSize()
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(fontSize)
  textCtrl:setString(str, isVip)
  textCtrl:setContentSize(size.width - 2 * marginX, 0)
  textCtrl:setDefaultColor(defColor.r, defColor.g, defColor.b)
  if textCtrl.setPunctTypesetting then
    textCtrl:setPunctTypesetting(true == isPunct)
  end
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  if locate == true or locate == LOCATE_POSITION.MID_BOTTOM then
    textCtrl:setPosition((size.width - textW) / 2, textH + marginY)
  elseif locate == LOCATE_POSITION.RIGHT_BOTTOM then
    textCtrl:setPosition(size.width - textW, textH + marginY)
  elseif locate == "leftMid" then
    textCtrl:setPosition(marginX, textH + (size.height - textH) * 0.5)
  else
    textCtrl:setPosition(marginX, textH + marginY)
  end
  local textNode = tolua.cast(textCtrl, "cc.LayerColor")
  panel:addChild(textNode, textNode:getLocalZOrder(), Dialog.TAG_COLORTEXT_CTRL)
  local panelHeight = textH + 2 * marginY
end
function BaosjcDlg:onCloseButton(sender, eventType)
  gf:confirm(CHS[4101642], function()
    gf:CmdToServer("CMD_NATIONAL_2019_BSJC_QUIT")
    if DlgMgr:getDlgByName("BaosjcDlg") then
      DlgMgr:closeDlg(self.name)
    end
  end)
end
function BaosjcDlg:setXunBSTitle(data)
  if data.status ~= GAME_STAGE.XUNZHAO_BAOSHI or data.gid == Me:queryBasic("gid") then
  else
    local otherPanel = self:getControl("SelfInfoPanel")
    local otherData = data.corp_info.Other
    self.selectImage:removeFromParent()
    local idx = otherData.select_index
    if idx >= 0 then
      local x = idx % 4 + 1
      local y = math.floor(idx / 4) + 1
      local panelY = self:getControl("Row_" .. y, nil, otherPanel)
      local destPanel = self:getControl("RockPanel_" .. x, nil, panelY)
      destPanel:addChild(self.selectImage)
    end
  end
end
function BaosjcDlg:setHeadInfo(data)
  local function setHead(data, panel)
    self:setImage("IconImage", ResMgr:getSmallPortrait(data.icon), panel)
    self:setLabelText("NameLabel_2", data.name, panel)
    self:setCtrlEnabled("IconImage", data.is_online == 1, panel)
    self:setCtrlVisible("CancelAutoButton", data.trusteeship_flag == 1, panel)
    self:setCtrlVisible("StateBKImage", data.trusteeship_flag == 1, panel)
    self:setCtrlVisible("SellStateValueLabel_1", data.trusteeship_flag == 1, panel)
    self:setCtrlVisible("SellStateValueLabel_2", data.trusteeship_flag == 1, panel)
    self:setLabelText("SellStateValueLabel_1", CHS[4100399], panel)
    self:setLabelText("SellStateValueLabel_2", CHS[4100399], panel)
    self:setCtrlVisible("OKImage", data.last_baoshi <= 0 and self.data.status == GAME_STAGE.MAI_BAOSHI, panel)
  end
  local myPanel = self:getControl("SelfInfoPanel")
  local myData = data.corp_info.Me
  setHead(myData, myPanel)
  local otherPanel = self:getControl("OtherPanel")
  local otherData = data.corp_info.Other
  setHead(otherData, otherPanel)
  local removeMag = function(panel)
    local magic = panel:getChildByTag(999)
    if magic then
      magic:removeFromParent()
    end
  end
  if data.status == GAME_STAGE.XUNZHAO_BAOSHI then
    local magic = {}
    magic.name = ResMgr.ArmatureMagic.point_head_eff.name
    magic.action = "Bottom01"
    if data.gid == Me:queryBasic("gid") then
      removeMag(self:getControl("HeadPanel", nil, otherPanel))
      local hPanel = self:getControl("HeadPanel", nil, myPanel)
      if not hPanel:getChildByTag(999) then
        gf:createArmatureMagic(magic, hPanel, 999, 0, 0)
      end
      self:setTitle(CHS[4200816])
    else
      removeMag(self:getControl("HeadPanel", nil, myPanel))
      local hPanel = self:getControl("HeadPanel", nil, otherPanel)
      if not hPanel:getChildByTag(999) then
        gf:createArmatureMagic(magic, hPanel, 999, 0, 0)
      end
      self:setTitle(CHS[4200817])
    end
  else
    removeMag(self:getControl("HeadPanel", nil, otherPanel))
    removeMag(self:getControl("HeadPanel", nil, myPanel))
  end
end
function BaosjcDlg:playMagic(cell, icon, cb)
  local size = cell:getContentSize()
  local magic = gf:createCallbackMagic(icon, function(node)
    node:removeFromParent(true)
    if cb then
      cb()
    end
  end)
  local x, y = cell:getPosition()
  local pos = cell:getParent():convertToWorldSpace(cc.p(x, y))
  pos = self.root:convertToNodeSpace(pos)
  magic:setPosition(pos.x + size.width / 2, pos.y + size.height / 2)
  magic:setLocalZOrder(20)
  self.root:addChild(magic)
end
function BaosjcDlg:MSG_NATIONAL_2019_BSJC_DATA(data)
  self.data = data
  self:setCtrlVisible("RightTimePanel", data.status ~= GAME_STAGE.PREPARE and data.status ~= GAME_STAGE.END)
  self:setCtrlVisible("TitlePanel", data.status ~= GAME_STAGE.PREPARE and data.status ~= GAME_STAGE.END)
  if not self.load then
    self.load = true
    self:setHeadInfo(data)
    self:setXunBSTitle(data)
    gf:closeCountDown()
    self:stopScheduleAll()
    self:setGameSatge(data)
    self:refreashRockData()
    self:refreashStoneItem(data)
    return
  end
  if data.from == "enter" then
    self:setCtrlVisible("ResultPanel", false)
    self.resultData = nil
    local otherPanel = self:getControl("OtherPanel")
    local myPanel = self:getControl("SelfInfoPanel")
    for i = 1, 4 do
      local rowPanel = self:getControl("Row_" .. i, nil, otherPanel)
      local rowPanel2 = self:getControl("Row_" .. i, nil, myPanel)
      for j = 1, 4 do
        local unitPanel = self:getControl("RockPanel_" .. j, nil, rowPanel)
        self:setCtrlOnlyEnabled("ItemImage", false, unitPanel)
        self:refreashRock(unitPanel)
        local unitPanel = self:getControl("RockPanel_" .. j, nil, rowPanel2)
        self:setCtrlOnlyEnabled("ItemImage", false, unitPanel)
        self:refreashRock(unitPanel)
      end
    end
    local myStonePanel = self:getControl("StonePanel", nil, "SelfInfoPanel")
    local otherStonePanel = self:getControl("StonePanel", nil, "OtherPanel")
    for i = 1, 3 do
      self:setCtrlVisible("Image_" .. i, true, myStonePanel)
      self:setImage("Image_" .. i, ResMgr:getItemIconPath(21015), myStonePanel)
      self:setCtrlVisible("Image_" .. i, true, otherStonePanel)
      self:setImage("Image_" .. i, ResMgr:getItemIconPath(21015), otherStonePanel)
    end
  end
  self:setHeadInfo(data)
  self:setXunBSTitle(data)
  gf:closeCountDown()
  self:stopScheduleAll()
  if data.status == GAME_STAGE.XUNZHAO_BAOSHI and data.from == "oper_finish" and data.para ~= "" then
    self:setGameSatge(data)
    do
      local tab = gf:split(data.para, ":")
      local whoPanel = tab[1] == Me:queryBasic("gid") and "OtherPanel" or "SelfInfoPanel"
      local idx = tonumber(tab[2]) + 1
      local y = math.floor((idx - 1) / 4) + 1
      local x = idx % 4
      if x == 0 then
        x = 4
      end
      local hangPanel = self:getControl("Row_" .. y, nil, whoPanel)
      local panel = self:getControl("RockPanel_" .. x, nil, hangPanel)
      local hasBaoshi = false
      if tab[1] == Me:queryBasic("gid") then
        hasBaoshi = data.board_info.Other[idx].type == 1
      else
        hasBaoshi = data.board_info.Me[idx].type == 1
      end
      if not hasBaoshi then
        self:playMagic(panel, ResMgr.magic.xunbao_use_shovel, function()
          self:refreashRockData()
          self:refreashStoneItem(data)
          if self.resultData then
            self:MSG_NATIONAL_2019_BSJC_BONUS(self.resultData, true)
          end
        end)
        return
      end
      self:playMagic(panel, ResMgr.magic.xunbao_use_shovel, function()
        self:refreashRockData(data)
        local baoshiImage = ccui.ImageView:create(ResMgr:getItemIconPath(21015))
        self.flyId = self.flyId + 1
        baoshiImage:setTag(self.flyId)
        baoshiImage:setName("BaosjcDlg" .. self.flyId)
        self.flyBaoshi[self.flyId] = baoshiImage
        local rectStart = self:getBoundingBoxInWorldSpace(panel)
        baoshiImage:setPosition(cc.p(rectStart.x + panel:getContentSize().width * 0.5, rectStart.y + panel:getContentSize().height * 0.5))
        local destImage
        local parentPanel = tab[1] == Me:queryBasic("gid") and "SelfInfoPanel" or "OtherPanel"
        local destPanel = self:getControl("StonePanel", nil, parentPanel)
        for i = 3, 1, -1 do
          local isVisible = self:getCtrlVisible("Image_" .. i, destPanel)
          if not isVisible and not destImage then
            destImage = self:getControl("Image_" .. i, nil, destPanel)
          end
        end
        local destRect = self:getBoundingBoxInWorldSpace(destImage)
        local delayAct = cc.DelayTime:create(0.5)
        local moveAct = cc.MoveTo:create(0.4, cc.p(destRect.x / Const.UI_SCALE + destRect.width * 0.5, destRect.y / Const.UI_SCALE + destRect.height * 0.5))
        local disAct = cc.CallFunc:create(function()
          baoshiImage:removeFromParent()
          self.flyBaoshi[baoshiImage:getTag()] = nil
          self:refreashStoneItem(data)
          if self.resultData then
            self:MSG_NATIONAL_2019_BSJC_BONUS(self.resultData, true)
          end
        end)
        baoshiImage:runAction(cc.Sequence:create(delayAct, moveAct, disAct))
        gf:getUILayer():addChild(baoshiImage)
      end)
    end
  else
    self:setGameSatge(data)
    if data.status ~= GAME_STAGE.XUNZHAO_BAOSHI then
      self:refreashRockData()
      self:refreashStoneItem(data)
    elseif data.from == "enter_zhao" then
      self:refreashRockData()
      self:refreashStoneItem(data)
    end
  end
end
function BaosjcDlg:MSG_NATIONAL_2019_BSJC_BONUS(data, isShow)
  self.resultData = data
  if not isShow then
    return
  end
  self:setCtrlVisible("ResultPanel", true)
  if data.tao then
    self:setLabelText("NumLabel", gf:getTaoStr(tonumber(data.tao)) .. CHS[4100702], "TaoPanel")
    self:setCtrlVisible("TaoPanel", true)
  else
    self:setCtrlVisible("TaoPanel", false)
  end
  if data.exp then
    self:setLabelText("NumLabel", data.exp, "ExpPanel")
    self:setCtrlVisible("ExpPanel", true)
  else
    self:setCtrlVisible("ExpPanel", false)
  end
  local bkPanel = self:getControl("BKPanel", nil, "ResultPanel")
  self:setCtrlVisible("Image_3_1", data.result == 1, bkPanel)
  self:setCtrlVisible("Image_4", data.result == 1, bkPanel)
  self:setCtrlVisible("Image_3_2", data.result == 2, bkPanel)
  self:setCtrlVisible("Image_5", data.result == 3, bkPanel)
  self:setCtrlVisible("Image_6", data.result == 3, bkPanel)
  self:setCtrlVisible("ExitButton_1", Me:isTeamLeader())
  self:setCtrlVisible("ExitButton_2", not Me:isTeamLeader())
  self:setCtrlVisible("ContinueButton", Me:isTeamLeader())
  self:setCtrlVisible("FailNoticePanel", data.bonus_type == "ok" or data.isGetBonus == 1)
  if data.isGetBonus == 1 then
    self:setLabelText("Label", CHS[4101643], "FailNoticePanel")
  elseif data.bonus_type == "ok" then
    self:setLabelText("Label", CHS[4200814], "FailNoticePanel")
  end
end
function BaosjcDlg:MSG_MESSAGE_EX(data)
  if data.channel ~= CHAT_CHANNEL.TEAM then
    return
  end
  local panel
  if data.gid == Me:queryBasic("gid") then
    panel = self:getControl("SpeechPanel", nil, "SelfInfoPanel")
  else
    panel = self:getControl("SpeechPanel", nil, "OtherPanel")
  end
  local strPanel = self:getControl("InfoPanel", nil, panel)
  self:setColorText(data.msg, strPanel, nil, 10, nil, COLOR3.TEXT_DEFAULT, nil, "leftMid")
  panel:setVisible(true)
  performWithDelay(self.root, function()
    panel:setVisible(false)
  end, 3)
end
return BaosjcDlg
