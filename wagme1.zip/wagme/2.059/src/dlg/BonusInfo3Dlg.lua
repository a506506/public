local BonusInfo3Dlg = Singleton("BonusInfo3Dlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
function BonusInfo3Dlg:init(data)
  self:bindListViewListener("ListView", self.onSelectListView)
  self.rootSize = self.rootSize or self.root:getContentSize()
  self.unitPanel = self:retainCtrl("RewardPanel1")
  local classList = TaskMgr:getRewardList(data)
  local rewardList = classList[1]
  local list = self:resetListView("ListView")
  for i = 1, #rewardList do
    local reward = rewardList[i]
    local imgPath, textureResType = RewardContainer:getRewardPath(reward)
    local panel = self.unitPanel:clone()
    local image = self:getControl("RewardImage", nil, panel)
    image:loadTexture(imgPath, textureResType)
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
    local name = string.gsub(item.name, "=F", "")
    self:setLabelText("NumLabel", name .. "： " .. item.number, panel)
    list:pushBackCustomItem(panel)
  end
  local items = list:getItems()
  list:setBounceEnabled(#items > 7)
  local addHeight = #items * self.unitPanel:getContentSize().height
  addHeight = math.min(addHeight, 7 * self.unitPanel:getContentSize().height)
  self.root:setContentSize(self.rootSize.width, self.rootSize.height + addHeight + 5)
  self:setCtrlContentSize("TipsPanel", nil, self.rootSize.height + addHeight + 5)
  self:setCtrlContentSize("BKImage", nil, self.rootSize.height + addHeight + 5)
  self:setCtrlContentSize("ListView", nil, addHeight)
end
function BonusInfo3Dlg:onSelectListView(sender, eventType)
end
return BonusInfo3Dlg
