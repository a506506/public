local FunnyDlg = require("dlg/FunnyDlg")
local Funny5Dlg = Singleton("Funny5Dlg", FunnyDlg)
return Funny5Dlg
