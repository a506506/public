local BinghkyExDlg = Singleton("BinghkyExDlg", Dialog)
local Npc = require("obj/Npc")
local LIGHT_EFFECT = require("cfg/LightEffect")
local COUNT_DOWN_TIME = 5
local GAME_AREA = {
  {x = 612, y = 0},
  {x = 450, y = 84},
  {x = 450, y = 335},
  {x = 630, y = 460},
  {x = 1050, y = 460},
  {x = 1250, y = 335},
  {x = 1236, y = 84},
  {x = 1068, y = 0}
}
local GAME_AREA_LENTH = math.ceil(math.sqrt(829396))
local MAP_NPC_CFG = {
  {
    id = 100,
    icon = 6223,
    x = 17,
    y = 31,
    dir = 3,
    effPos = GAME_AREA[2]
  },
  {
    id = 200,
    icon = 6223,
    x = 16,
    y = 19,
    dir = 5,
    effPos = GAME_AREA[3]
  },
  {
    id = 300,
    icon = 6223,
    x = 25,
    y = 13,
    dir = 5,
    effPos = GAME_AREA[4]
  },
  {
    id = 400,
    icon = 6223,
    x = 44,
    y = 13,
    dir = 7,
    effPos = GAME_AREA[5]
  },
  {
    id = 500,
    icon = 6223,
    x = 53,
    y = 19,
    dir = 7,
    effPos = GAME_AREA[6]
  },
  {
    id = 600,
    icon = 6223,
    x = 51,
    y = 31,
    dir = 1,
    effPos = GAME_AREA[7]
  }
}
local TARGET_ATTACK_RADIUS = 192
local ATTACKED_STATUS = {
  NONE = 0,
  FIRE = 1,
  ICE = 2
}
local FIRE_ATTACK_OPACITY = 50
local GAME_SIGHT_POS = cc.p(35, 24)
local ICE_ATTACK_SPEED = -50
function BinghkyExDlg:init(data)
  self:setFullScreen()
  self:setCtrlFullClientEx("BKPanel", nil, true)
  self:bindListener("RestartButton", self.onRestartButton)
  self:bindListener("QuitButton", self.onQuitButton)
  self:bindListener("CloseButton", self.onCloseButton)
  self.infoPanel = self:getControl("InfoPanel")
  self.mapNpc = {}
  self.npcAttackEff = {}
  self.npcAttackEffTime = {}
  self.mapSize = MapMgr.mapSize
  self:createGhostPlaer(data.icon, data.name)
  self:bornMapNpc()
  self:resetGame()
end
function BinghkyExDlg:isNeedHideChar(id)
  if id == self.objId then
    return false
  end
  return true
end
function BinghkyExDlg:createGhostPlaer(icon, name)
  self.objId = 2000
  self.obj = require("obj/activityObj/YinHunRuDianNpc").new()
  self.obj:absorbBasicFields({
    id = self.objId,
    icon = icon,
    name = name,
    opacity = 160
  })
  self.obj:onEnterScene(GAME_SIGHT_POS.x, GAME_SIGHT_POS.y)
  self.obj:setDir(5)
  self.obj:setAct(Const.FA_STAND)
  CharMgr:deleteChar(self.objId)
  CharMgr.chars[self.objId] = self.obj
  GameMgr.scene.map:setCenterChar(self.objId)
end
function BinghkyExDlg:getCfgFileName()
  return ResMgr:getDlgCfg("BinghkyDlg")
end
function BinghkyExDlg:resetGame()
  self.obj:setLastMapPos(GAME_SIGHT_POS.x, GAME_SIGHT_POS.y)
  self.obj:setPos(gf:convertToClientSpace(GAME_SIGHT_POS.x, GAME_SIGHT_POS.y))
  self:setCtrlVisible("BKPanel", false)
  self:setCtrlVisible("ResultPanel", false)
  self.life = 3
  self:setLifePanel()
  self.obj:setSeepPrecentByClient(0)
  self.gameingTime = 60
  self:refreshGamingTime()
  self.infoPanel:setVisible(false)
  gf:startCountDowm(COUNT_DOWN_TIME + gf:getServerTime(), "start", function()
    local dlg = DlgMgr.dlgs.BinghkyExDlg
    if dlg then
      self:startGame()
      self.infoPanel:setVisible(true)
    end
  end)
  self:clearNpcAttackEff()
end
function BinghkyExDlg:startGame()
  self:setMeCheckKnockItem()
  self:stopSchedule(self.timeScheduleId)
  self.timeScheduleId = self:startSchedule(function()
    if self.gameingTime > 0 then
      self.gameingTime = self.gameingTime - 1
      self:refreshGamingTime()
    else
      self:gotoClose()
    end
  end, 1)
  self:playNpcCaseAction()
  self:stopSchedule(self.tickScheduleId)
  self.tickScheduleId = self:startSchedule(function()
    if not self.tickScheduleId then
      return
    end
    self:checkAttackEff()
  end, 0)
end
function BinghkyExDlg:endGame()
  self:stopSchedule(self.timeScheduleId)
  self.timeScheduleId = nil
  self:stopSchedule(self.tickScheduleId)
  self.tickScheduleId = nil
  self:clearNpcAttackEff()
  self:playNpcCaseAction(true)
  self.obj:setSeepPrecentByClient(nil)
  self:gotoClose()
end
function BinghkyExDlg:checkAttackEff()
  for k, v in pairs(self.npcAttackEff) do
    if "boolean" == type(v) then
      local curTick = gfGetTickCount()
      if not self.npcAttackEffTime[k] or curTick - self.npcAttackEffTime[k] > 1000 then
        self.npcAttackEff[k] = self:createAttackEff(k)
        self.npcAttackEffTime[k] = curTick
        self:doNpcCastMagic(k)
      end
    else
      if not v.bottomLayer then
        return
      end
      v:updatePos()
      local attackedMe = self:checkMeAttacked(v)
      local inGameArea = self:isInGameArea(cc.p(v.curX, v.curY))
      if attackedMe then
        if v.type == ATTACKED_STATUS.FIRE then
          self:setMeFireStatus()
        elseif v.type == ATTACKED_STATUS.ICE then
          self:setMeIceStatus()
        end
        if not self.tickScheduleId then
          return
        end
        v:cleanup()
        self.npcAttackEff[k] = true
      elseif inGameArea then
        v.inGameAreaEd = true
      elseif v.inGameAreaEd or not v.inMoveAction or v.curX < 0 or v.curX > self.mapSize.width or v.curY < 0 or v.curY > self.mapSize.height then
        v:cleanup()
        self.npcAttackEff[k] = true
      end
    end
  end
end
function BinghkyExDlg:setMeFireStatus()
  if self.obj.bhkyStatus and self.obj.bhkyStatus == ATTACKED_STATUS.FIRE then
    return
  end
  self.obj.bhkyStatus = ATTACKED_STATUS.FIRE
  self.obj:setOpacity(FIRE_ATTACK_OPACITY)
  performWithDelay(self.obj.middleLayer, function()
    self.obj:setOpacity(255)
  end, 0.2)
  performWithDelay(self.obj.middleLayer, function()
    self.obj:setOpacity(FIRE_ATTACK_OPACITY)
  end, 0.4)
  performWithDelay(self.obj.middleLayer, function()
    self.obj:setOpacity(255)
  end, 0.6)
  performWithDelay(self.obj.middleLayer, function()
    self.obj:setOpacity(FIRE_ATTACK_OPACITY)
  end, 0.8)
  performWithDelay(self.obj.middleLayer, function()
    self.obj:setOpacity(255)
    self.obj.bhkyStatus = ATTACKED_STATUS.NONE
  end, 1)
  self.life = self.life - 1
  self:setLifePanel()
  if self.life <= 0 then
    self:endGame()
  end
end
function BinghkyExDlg:setMeIceStatus()
  self.obj:setSeepPrecentByClient(ICE_ATTACK_SPEED)
  local effectCfg = LIGHT_EFFECT[1357]
  if self.obj.middleLayer.iceAction then
    self.obj.middleLayer:stopAction(self.obj.middleLayer.iceAction)
    self.obj:deleteMagic(effectCfg.icon)
  end
  self.obj:addMagicOnWaist(effectCfg.icon, effectCfg.behind, effectCfg.icon, effectCfg.armatureType)
  self.obj.middleLayer.iceAction = performWithDelay(self.obj.middleLayer, function()
    self.obj:setSeepPrecentByClient(0)
    self.obj.bhkyStatus = ATTACKED_STATUS.NONE
    self.obj:deleteMagic(effectCfg.icon)
  end, 3)
end
function BinghkyExDlg:checkMeAttacked(char)
  if not char then
    return
  end
  if not Me or not self.obj.charAction or not self.obj.charAction.char then
    return
  end
  local meKnockItem = self.obj.topLayer:getChildByName("KnockLayer")
  if not meKnockItem then
    return
  end
  local itemSize = meKnockItem:getContentSize()
  local pos11 = meKnockItem:convertToWorldSpace(cc.p(0, 0))
  local pos21 = char.image:convertToWorldSpace(cc.p(0, 0))
  local pos12 = cc.p(pos11.x + itemSize.width, pos11.y + itemSize.height)
  local pos22 = cc.p(pos21.x + char.width, pos21.y + char.height)
  if 0 < Formula:getRectOvelLapArea(pos11.x, pos11.y, pos12.x, pos12.y, pos21.x, pos21.y, pos22.x, pos22.y) then
    return true
  end
end
function BinghkyExDlg:createAttackEff(id)
  local path, icon, type = self:getRandomEffect()
  local cfg = MAP_NPC_CFG[id / 100]
  local mapX, mapY = gf:convertToMapSpace(cfg.effPos.x, cfg.effPos.y)
  local effectObj = require("obj/EffectItem").new(mapX, mapY)
  local sprite = effectObj:addImage(path)
  if sprite then
    sprite:setVisible(false)
  end
  effectObj:addMagic(icon)
  effectObj.type = type
  effectObj:setSpeedPercent(self:getSpeedPercent())
  local tarX, tarY, angle = self:getAttackTargetPos(cfg.effPos.x, cfg.effPos.y)
  if effectObj.magic then
    effectObj.magic:setRotation(angle)
  end
  effectObj:moveTo(tarX, tarY)
  return effectObj
end
function BinghkyExDlg:getSpeedPercent()
  return 100 + math.max(0, (60 - self.gameingTime) / 120 * 300)
end
function BinghkyExDlg:getAttackTargetPos(startX, startY)
  local x = math.random(self.obj.curX - TARGET_ATTACK_RADIUS, self.obj.curX + TARGET_ATTACK_RADIUS)
  local y = math.random(self.obj.curY - TARGET_ATTACK_RADIUS, self.obj.curY + TARGET_ATTACK_RADIUS)
  if not self:isInGameArea(cc.p(x, y)) then
    x, y = self.obj.curX, self.obj.curY
  end
  local k = (y - startY) / (x - startX)
  local addX = math.sqrt(GAME_AREA_LENTH * GAME_AREA_LENTH / (1 + k * k))
  local addY = math.ceil(math.abs(k * addX))
  addX = math.ceil(addX)
  if x == startX then
    addX = 0
    addY = GAME_AREA_LENTH
  end
  local tarX = startX < x and x + addX or x - addX
  local tarY = startY < y and y + addY or y - addY
  local vecX = tarX - startX
  local vecY = tarY - startY
  local angle = math.atan2(-vecY, vecX) * 180 / math.pi
  return tarX, tarY, angle
end
function BinghkyExDlg:isInGameArea(pos)
  if Formula:ptInPolygon(pos, GAME_AREA) then
    return true
  end
  return false
end
function BinghkyExDlg:getRandomEffect()
  if math.random(0, 1) == 0 then
    return ResMgr.ui.small_right_arrow, ResMgr.magic.bhky_fire_ball, ATTACKED_STATUS.FIRE
  else
    return ResMgr.ui.small_right_arrow, ResMgr.magic.bhky_ice_ball, ATTACKED_STATUS.ICE
  end
end
function BinghkyExDlg:bornMapNpc()
  for i = 1, #MAP_NPC_CFG do
    local cfg = MAP_NPC_CFG[i]
    local npc = Npc.new()
    npc:absorbBasicFields({
      id = cfg.id,
      icon = cfg.icon,
      dir = cfg.dir,
      name = "",
      sub_type = OBJECT_NPC_TYPE.CANNOT_TOUCH
    })
    npc:setAct(Const.FA_STAND)
    npc:onEnterScene(cfg.x, cfg.y)
    self.mapNpc[cfg.id] = npc
  end
end
function BinghkyExDlg:playNpcCaseAction(isRecover)
  for k, v in pairs(self.mapNpc) do
    if isRecover then
      v:setAct(Const.FA_STAND)
    else
      local npcId = v:getId()
      self.npcAttackEff[npcId] = true
      self:doNpcCastMagic(npcId)
    end
  end
end
function BinghkyExDlg:doNpcCastMagic(id)
  local function callback()
    self:doNpcCastMagicEnd(id)
  end
  local npc = self.mapNpc[id]
  if not npc then
    return
  end
  npc:setActAndCB(Const.FA_ACTION_CAST_MAGIC, callback)
end
function BinghkyExDlg:doNpcCastMagicEnd(id)
  local function callback()
    local npc = self.mapNpc[id]
    if not npc or npc.faAct ~= Const.FA_ACTION_CAST_MAGIC_END then
      return
    end
    npc:setAct(Const.FA_STAND)
  end
  local npc = self.mapNpc[id]
  if not npc then
    return
  end
  npc:setActAndCB(Const.FA_ACTION_CAST_MAGIC_END, callback)
end
function BinghkyExDlg:clearNpcAttackEff()
  for k, v in pairs(self.npcAttackEff) do
    if "boolean" ~= type(v) then
      v:cleanup()
    end
  end
  self.npcAttackEff = {}
end
function BinghkyExDlg:clearMapNpc()
  for k, v in pairs(self.mapNpc) do
    v:cleanup()
  end
  self.mapNpc = {}
end
function BinghkyExDlg:setMeCheckKnockItem()
  if self.obj.topLayer:getChildByName("KnockLayer") then
    return
  end
  local rect = self.obj.charAction.char.contentRect
  local colorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 0))
  colorLayer:setContentSize(rect.width - 25, rect.height - 35)
  colorLayer:setPosition(cc.p(-rect.width / 2 + 13, 0))
  self.obj:addToTopLayer(colorLayer)
  colorLayer:setName("KnockLayer")
end
function BinghkyExDlg:removeMeCheckKnockItem()
  local item = self.obj.charAction.char:getChildByName("KnockLayer")
  if item then
    item:removeFromParent()
    item = nil
  end
end
function BinghkyExDlg:setLifePanel()
  for i = 1, 3 do
    local panel = self:getControl("LifePanel_" .. i, nil, self.infoPanel)
    self:setCtrlVisible("Image_1", false, panel)
    self:setCtrlVisible("Image_2", false, panel)
    if i <= self.life then
      self:setCtrlVisible("Image_1", true, panel)
    else
      self:setCtrlVisible("Image_2", true, panel)
    end
  end
end
function BinghkyExDlg:refreshGamingTime()
  self:setLabelText("TimeLabel", self.gameingTime, self.infoPanel)
end
function BinghkyExDlg:onCloseButton()
  gf:confirm(CHS[7190777], function()
    DlgMgr:sendMsg("YinhrdDlg", "doSmallGameResult", 13, 2)
    DlgMgr:closeDlg(self.name)
  end)
end
function BinghkyExDlg:gotoClose()
  if self.gameingTime > 0 then
    DlgMgr:sendMsg("YinhrdDlg", "doSmallGameResult", 13, 0)
  else
    DlgMgr:sendMsg("YinhrdDlg", "doSmallGameResult", 13, 1)
  end
  DlgMgr:closeDlg(self.name)
end
function BinghkyExDlg:cleanup()
  self:stopSchedule(self.timeScheduleId)
  self:stopSchedule(self.tickScheduleId)
  self:clearNpcAttackEff()
  self.npcAttackEffTime = {}
  self:clearMapNpc()
  self.obj = nil
  CharMgr:deleteChar(self.objId)
  GameMgr.scene.map:setCenterChar()
end
return BinghkyExDlg
