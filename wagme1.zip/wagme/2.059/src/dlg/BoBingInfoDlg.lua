local BoBingInfoDlg = Singleton("BoBingInfoDlg", Dialog)
function BoBingInfoDlg:init()
  self:bindListener("ClosePanel", self.onCloseButton)
  self:bindListener("CloseButton", self.onCloseButton)
end
return BoBingInfoDlg
