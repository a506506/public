local FunnyDlg = require("dlg/FunnyDlg")
local Funny2Dlg = Singleton("Funny2Dlg", FunnyDlg)
return Funny2Dlg
