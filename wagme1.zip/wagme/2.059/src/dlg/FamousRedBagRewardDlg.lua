local FamousRedBagRewardDlg = Singleton("FamousRedBagRewardDlg", Dialog)
function FamousRedBagRewardDlg:init()
  self:setCtrlVisible("RedBagReadyPanel", true)
  self:setCtrlVisible("RedBagRewardPanel", false)
  self:bindListener("GoOnImage", self.onCloseButton)
end
function FamousRedBagRewardDlg:setData(data)
  self:playAction(data)
end
function FamousRedBagRewardDlg:playAction(data)
  local function playResult()
    self:playResult(data)
  end
  local fuc = cc.CallFunc:create(playResult)
  local readyImage = self:getControl("PartyRedBagReadyImage")
  readyImage:setScale(0.5)
  local action = cc.ScaleBy:create(0.3, 2)
  readyImage:runAction(cc.Sequence:create(action, cc.DelayTime:create(0.4), fuc))
end
function FamousRedBagRewardDlg:playResult(data)
  self:setCtrlVisible("RedBagReadyPanel", false)
  self:setCtrlVisible("RedBagRewardPanel", true)
  self:setCtrlVisible("MessagePanel", true)
  self:setCtrlVisible("GoOnImage", true)
  local lightEffect = self:getControl("BigLightEffectImage")
  local rotate = cc.RotateBy:create(2, 360)
  local action = cc.RepeatForever:create(rotate)
  lightEffect:runAction(action)
  self:setLabelText("MoneyLabel", data.coin)
  local name = data.name or data.senderName
  self:setColorTextEx(string.format(CHS[7100803], gf:getRealName(name), gf:filtTextOnly(data.text or data.msg)), self:getControl("TextPanel", nil, "MessagePanel"), COLOR3.WHITE, 21)
end
return FamousRedBagRewardDlg
