local FireworksCeremonyDlg = Singleton("FireworksCeremonyDlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
local ITEMS = {
  CHS[5410475],
  CHS[5410476],
  CHS[5410477],
  CHS[5410478]
}
local mUpY, mMidY, mDownY
local REWARDS = {
  {
    80000,
    CHS[5420429],
    10000,
    10,
    500
  },
  {
    120000,
    CHS[5420430],
    300,
    16,
    15
  },
  {
    300000,
    CHS[5420431],
    150,
    16,
    8
  },
  {
    600000,
    CHS[5420432],
    50,
    16,
    3
  },
  {
    1000000,
    CHS[5420433],
    1,
    16,
    1
  },
  {
    1500000,
    CHS[5420434],
    1,
    16,
    1
  }
}
function FireworksCeremonyDlg:init()
  self:bindListener("MixingButton", self.onMixingButton)
  self:bindListener("RuleButton", self.onRuleButton)
  self:bindListener("CumulationPanel", self.onCumulationPanel, nil, true)
  self:setCtrlTouchEnabled("Button", false, "CumulationPanel")
  cc.SpriteFrameCache:getInstance():addSpriteFrames("ui/Artisticfont01.plist")
  DlgMgr:registPlistEx(self.name, "Artisticfont01.plist")
  self:setItemsDescript()
  self.nums = {}
  self:initShoot()
  self:initGather()
  self:initMaterials()
  schedule(self.root, function()
    gf:CmdToServer("CMD_FIREWORKS_PARTY_INFO", {})
  end, 1)
  self:hookMsg("MSG_FIREWORKS_PARTY_INFO")
end
function FireworksCeremonyDlg:cleanup()
  self.data = nil
  self.nums = nil
  DlgMgr:unregistPlistEx(self.name, "Artisticfont01.plist")
end
function FireworksCeremonyDlg:setItemsDescript()
  for i = 1, #ITEMS do
    local info = InventoryMgr:getItemInfoByName(ITEMS[i])
    if info.descript then
      if DistMgr:curIsTestDist() then
        info.descript = string.gsub(info.descript, "N", i == 4 and 10000 or 20)
      else
        info.descript = string.gsub(info.descript, "N", i == 4 and 1000 or 1)
      end
    end
  end
end
function FireworksCeremonyDlg:onUpdate(dt)
end
function FireworksCeremonyDlg:onMixingButton(sender, eventType)
  gf:CmdToServer("CMD_FIREWORKS_PARTY_MERGE")
end
function FireworksCeremonyDlg:onRuleButton(sender, eventType)
  DlgMgr:openDlg("FireworksCeremonyRuleDlg")
end
function FireworksCeremonyDlg:onCumulationPanel(sender, eventType)
  if eventType == ccui.TouchEventType.began then
    sender:setScale(1.2)
  elseif eventType == ccui.TouchEventType.moved then
    if not sender:isHighlighted() then
      sender:setScale(1)
    else
      sender:setScale(1.2)
    end
  else
    sender:setScale(1)
    if eventType == ccui.TouchEventType.ended then
      if not self.data then
        return
      end
      local dlg = DlgMgr:openDlg("FireworksStatisticsDlg")
      dlg:setData(self.data, REWARDS)
    end
  end
end
function FireworksCeremonyDlg:getShowNum(num)
  if num < 1000 then
    return num
  elseif num < 10000 then
    return tostring(num / 1000) .. CHS[5400356]
  else
    return tostring(num / 10000) .. CHS[5400357]
  end
end
function FireworksCeremonyDlg:initShoot()
  local rewards = REWARDS
  local panel, classList, reward, imgPath, textureResType
  for i = 1, #rewards do
    panel = self:getControl(string.format("RewardItemPanel%02d", i))
    classList = TaskMgr:getRewardList(rewards[i][2])
    if not classList[1] or not next(classList[1]) then
      return
    end
    reward = classList[1][1]
    imgPath, textureResType = RewardContainer:getRewardPath(reward)
    if textureResType == ccui.TextureResType.plistType then
      self:setImagePlist("ItemImage", imgPath, panel)
    else
      self:setImage("ItemImage", imgPath, panel)
    end
    self:setLabelText("Label", self:getShowNum(rewards[i][1]), panel)
    local numIndex = DistMgr:curIsTestDist() and 5 or 3
    local num = i == 1 and rewards[i][numIndex] * 300 or rewards[i][numIndex]
    self:setLabelText("ItemValueTextBMFont", self:getShowNum(num), panel)
    panel.reward = reward
    panel.shootNum = rewards[i][1]
    panel.lastShootNum = i == 1 and 0 or rewards[i - 1][1]
    panel.info = rewards[i]
    self:bindTouchEndEventListener(panel, function(dlg, sender, eventType)
      RewardContainer:imagePanelTouch(sender, eventType)
    end)
  end
end
function FireworksCeremonyDlg:updateShoot(data)
  self:setLabelText("ValueLabel", data.shoot_num, "FireValuePanel")
  local bar = self:getControl("FireLoadingBar")
  local percent = 0
  local panel, img, flag
  flag = false
  for i = 1, 6 do
    panel = self:getControl(string.format("RewardItemPanel%02d", i))
    if data.shoot_num >= panel.shootNum then
      percent = percent + panel.info[4]
    else
      panel:removeChildByName("GotImage")
      if not flag then
        flag = true
        percent = percent + (data.shoot_num - panel.lastShootNum) / (panel.shootNum - panel.lastShootNum) * panel.info[4]
      end
    end
  end
  if data.shoot_num > 1500000 then
    percent = percent + (data.shoot_num - 1500000) / 31250
  end
  bar:setPercent(math.min(100, percent))
end
function FireworksCeremonyDlg:initGather()
  local panel
  for i = 1, 4 do
    panel = self:getControl(string.format("FireworksPanel%02d", i))
    do
      local img = self:getControl("ItemImage", nil, panel)
      img:loadTexture(ResMgr:getIconPathByName(ITEMS[i]))
      self:setLabelText("ValueLabel", "", panel)
      self:bindTouchEndEventListener(img, function(dlg, sender)
        local rect = self:getBoundingBoxInWorldSpace(img)
        InventoryMgr:showBasicMessageDlg(ITEMS[i], rect)
      end)
      self:bindListener("FireButton", function(dlg, sender)
        if not self.data then
          return
        end
        if self:getLabelText("Label", sender:getParent()) == CHS[5410480] then
          local time = gf:getServerTime()
          if time < self.data.shoot_start_time or time > self.data.shoot_end_time then
            gf:ShowSmallTips(CHS[5410481])
            return
          end
          local dlg = DlgMgr:openDlg("GetTaoBuyDlg")
          dlg:setInfoByType("fireworks")
        else
          if Me:isInJail() then
            gf:ShowSmallTips(CHS[5000228])
            return
          end
          if Me:isInCombat() then
            gf:ShowSmallTips(CHS[4000223])
            return
          end
          if Me:isLookOn() then
            gf:ShowSmallTips(CHS[5420353])
            return
          end
          if i == 4 and PlayActionsMgr:isPlayLiHua() then
            gf:ShowSmallTips(CHS[5420354])
            return
          end
          gf:CmdToServer("CMD_FIREWORKS_PARTY_USE_ITEM", {index = i, isOpenFast = 1})
        end
      end, panel)
    end
  end
end
function FireworksCeremonyDlg:updateGather(data)
  local panel
  for i = 1, 4 do
    panel = self:getControl(string.format("FireworksPanel%02d", i))
    local img = self:getControl("ItemImage", nil, panel)
    if not data.gathers[i] or data.gathers[i] == 0 then
      gf:grayImageView(img)
      self:setLabelText("ValueLabel", "", panel)
      if i == 4 then
        self:setLabelText("Label", CHS[5410480], panel)
        self:setLabelText("Label1", CHS[5410480], panel)
      end
    else
      gf:resetImageView(img)
      self:setLabelText("ValueLabel", string.format("%d", data.gathers[i]), panel)
      if i == 4 then
        self:setLabelText("Label", CHS[5410479], panel)
        self:setLabelText("Label1", CHS[5410479], panel)
      end
    end
  end
  self:setLightedNum(data.gather_num)
end
function FireworksCeremonyDlg:initMaterials()
  local items = {
    CHS[5410484],
    CHS[5410485],
    CHS[5410486]
  }
  local panel, img
  for i = 1, 3 do
    panel = self:getControl(string.format("ItemPanel%02d", i), nil, "RightPanel")
    img = self:getControl("ItemImage", nil, panel)
    img:loadTexture(ResMgr:getIconPathByName(items[i]))
    self:setLabelText("ItemNumTextBMFont", "", panel)
    self:bindTouchEndEventListener(panel, function(dlg, sender)
      local rect = self:getBoundingBoxInWorldSpace(sender)
      InventoryMgr:showBasicMessageDlg(items[i], rect)
    end)
  end
end
function FireworksCeremonyDlg:updateMaterials(data)
  local canCompound = true
  local panel, img
  for i = 1, 3 do
    panel = self:getControl(string.format("ItemPanel%02d", i))
    img = self:getControl("ItemImage", nil, panel)
    if not data.materials[i] or data.materials[i] == 0 then
      canCompound = false
      gf:grayImageView(img)
      self:setLabelText("ItemNumTextBMFont", "", panel)
    else
      gf:resetImageView(img)
      self:setLabelText("ItemNumTextBMFont", data.materials[i], panel)
    end
  end
  self:setLabelText("TimaLabel01", string.format("%s%s~%s", CHS[5420137], gf:getServerDate(CHS[7100196], data.start_time), gf:getServerDate(CHS[7100196], data.end_time)))
end
function FireworksCeremonyDlg:getNumFrame(num)
  return cc.SpriteFrameCache:getInstance():getSpriteFrame(string.format("Artisticfont01/%d.png", num))
end
function FireworksCeremonyDlg:setLightedNum(num)
  self:setLabelText("Label", num, "GatherNumPanel01")
end
function FireworksCeremonyDlg:MSG_FIREWORKS_PARTY_INFO(data)
  self.data = data
  self:setCtrlVisible("CumulationPanel", data.round == 2)
  self:updateShoot(data)
  self:updateGather(data)
  self:updateMaterials(data)
end
return FireworksCeremonyDlg
