local ChangePolarDoneDlg = Singleton("ChangePolarDoneDlg", Dialog)
function ChangePolarDoneDlg:init(data)
  self:setFullScreen()
  self:setCtrlFullClient("BlackImage")
  self:bindListener("ConfrimButton", self.onConfrimButton)
  self:bindListener("ConfrimPanel", self.onConfrimButton)
  self:setData(data)
end
function ChangePolarDoneDlg:setData(data)
  local panel1 = self:getControl("MagicPanel")
  self:creatCharDragonBones(panel1, gf:getIconByGenderAndPolar(Me:queryBasicInt("gender"), data.old_polar), 0)
  self:setLabelText("NameLabel1", gf:getPolarDesc(data.old_polar))
  local panel2 = self:getControl("MagicPanel", nil, "IconPanel_2")
  self:creatCharDragonBones(panel2, gf:getIconByGenderAndPolar(Me:queryBasicInt("gender"), data.new_polar), 0)
  self:setLabelText("NameLabel1", gf:getPolarDesc(data.new_polar), "IconPanel_2")
end
function ChangePolarDoneDlg:creatCharDragonBones(panel, icon, offsetY)
  local magic = panel:getChildByName("charPortrait")
  if magic and magic:getTag() == icon then
    return
  end
  local dbMagic = DragonBonesMgr:createCharDragonBones(icon, string.format("%05d", icon))
  if not dbMagic then
    return
  end
  local magic = tolua.cast(dbMagic, "cc.Node")
  offsetY = offsetY or 0
  magic:setPosition(panel:getContentSize().width * 0.5, panel:getContentSize().height * 0.5 + offsetY)
  magic:setName("charPortrait")
  magic:setTag(icon)
  panel:addChild(magic)
  DragonBonesMgr:toPlay(dbMagic, "stand", 0)
end
function ChangePolarDoneDlg:onConfrimButton(sender, eventType)
  self:onCloseButton()
end
return ChangePolarDoneDlg
