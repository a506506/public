local DaluandouzmscDlg = Singleton("DaluandouzmscDlg", Dialog)
local COMBAT_POS = {
  1,
  2,
  4,
  5
}
function DaluandouzmscDlg:init()
  self:bindListener("Button", self.onRefreshButton, "ShuaxPanel")
  self:bindListener("ShutButton", self.onLockButton, "SuodPanel")
  self:bindListener("OpenButton", self.onLockButton, "SuodPanel")
  self:bindListener("BKTouchPanel", self.onCloseButton)
  DlgMgr:sendMsg("DaluandouscDlg", "updateRecruitStatus")
  self:refreshLockPanel()
end
function DaluandouzmscDlg:setData(data)
  for i = 1, 4 do
    local panel = self:getControl("ScPanel_" .. i)
    self:refreshSinglePanel(panel, data.list[i], i)
  end
end
function DaluandouzmscDlg:refreshLockPanel()
  self:setCtrlVisible("OpenButton", false, "SuodPanel")
  self:setCtrlVisible("ShutButton", false, "SuodPanel")
  local myData = DlgMgr:sendMsg("DaluandouzjmDlg", "getMyData")
  if myData and myData.is_lock_retinue == 1 then
    self:setCtrlVisible("ShutButton", true, "SuodPanel")
  else
    self:setCtrlVisible("OpenButton", true, "SuodPanel")
  end
end
function DaluandouzmscDlg:refreshSinglePanel(panel, info, index)
  local cfg = UndergroundMgr:getRetinueCfg(info.name)
  if not cfg then
    return
  end
  if info.can_recruit_num <= 0 then
    panel:setVisible(false)
    return
  end
  panel.name = info.name
  panel:setVisible(true)
  if cfg.color == 1 then
    self:setLabelText("NameLabel", info.name, panel, COLOR3.BLUE)
  elseif cfg.color == 2 then
    self:setLabelText("NameLabel", info.name, panel, COLOR3.PURPLE)
  elseif cfg.color == 3 then
    self:setLabelText("NameLabel", info.name, panel, COLOR3.YELLOW)
  end
  local rolePanel = self:getControl("RolePanel", nil, panel)
  rolePanel:removeChildByTag(Dialog.TAG_PORTRAIT)
  self:setPortrait("RolePanel", cfg.icon, nil, panel)
  local numPanel = self:getControl("BKImage_2", nil, panel)
  numPanel:setVisible(false)
  local hasNum = #DlgMgr:sendMsg("DaluandouscDlg", "getRetinueMaterialList", info.name, 1)
  if hasNum > 0 then
    numPanel:setVisible(true)
    self:setLabelText("HaveLabel", string.format(CHS[7250006], hasNum), numPanel)
  end
  local recruitButton = self:getControl("TouchPanel", nil, panel)
  recruitButton.name = info.name
  recruitButton.price = info.price
  recruitButton.index = index
  self:blindLongPress("TouchPanel", self.onRecruitCardPanel, self.onRecruitPanel, panel)
  self:setLabelText("NumLabel", info.price, panel)
  self:setImage("RaceImage", ResMgr:getRetinueTypeTag(cfg.type), panel)
  self:setImage("PolarImage", ResMgr:getRetinuePolarTag(cfg.polar), panel)
  self:setImage("TypeImage", ResMgr:getRetinueAttackTag(cfg.fightType), panel)
end
function DaluandouzmscDlg:refreshRetinueHasNum()
  for i = 1, 4 do
    local panel = self:getControl("ScPanel_" .. i)
    local numPanel = self:getControl("BKImage_2", nil, panel)
    numPanel:setVisible(false)
    local hasNum = #DlgMgr:sendMsg("DaluandouscDlg", "getRetinueMaterialList", panel.name, 1)
    if hasNum > 0 then
      numPanel:setVisible(true)
      self:setLabelText("HaveLabel", string.format(CHS[7250006], hasNum), numPanel)
    end
  end
end
function DaluandouzmscDlg:onCloseButton(sender, eventType)
  DlgMgr:sendMsg("DaluandouscDlg", "onShouqiButton")
end
function DaluandouzmscDlg:onRefreshButton(sender, eventType)
  gf:CmdToServer("CMD_FFA_REFRESH_RETINUE", {})
end
function DaluandouzmscDlg:onLockButton(sender, eventType)
  local myData = DlgMgr:sendMsg("DaluandouzjmDlg", "getMyData")
  if myData and myData.is_lock_retinue == 1 then
    gf:CmdToServer("CMD_FFA_LOCK_RECRUIT_LIST", {is_lock = 0})
  else
    gf:CmdToServer("CMD_FFA_LOCK_RECRUIT_LIST", {is_lock = 1})
  end
end
function DaluandouzmscDlg:onRecruitCardPanel(sender, eventType)
  UndergroundMgr:requestRetinueInfo(sender.name)
end
function DaluandouzmscDlg:onRecruitPanel(sender, eventType)
  local myData = DlgMgr:sendMsg("DaluandouzjmDlg", "getMyData")
  if not myData or myData.point < sender.price then
    gf:ShowSmallTips(CHS[7100743])
    return
  end
  local retinueList1, retinueList2, retinueList3 = DlgMgr:sendMsg("DaluandouscDlg", "getRetinueMaterialList", nil, nil, COMBAT_POS)
  if #retinueList1 + #retinueList2 + #retinueList3 >= 8 then
    gf:ShowSmallTips(CHS[7100744])
    return
  end
  gf:CmdToServer("CMD_FFA_RECRUIT_RETINUE", {
    name = sender.name,
    index = sender.index - 1
  })
end
return DaluandouzmscDlg
