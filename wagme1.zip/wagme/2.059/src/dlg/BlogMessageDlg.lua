local BlogMessageDlg = Singleton("BlogMessageDlg", Dialog)
local LISTVIEW_MARGIN = 2
local WORD_LIMIT = 60
local INIT_LOAD_MESSAGE_NUM = 20
local ONE_LOAD_MESSAGE_NUM = 10
local WRITE_MOVE_WIDTH = 600
BlogMessageDlg.relationLeftDlgName = "BlogInfoDlg"
function BlogMessageDlg:init(data)
  self:bindListener("WriteButton", self.onSwitchWriteButton, "OutPanel1")
  self:bindListener("CloseWriteButton", self.onCloseWriteButton)
  self:bindListener("WriteButton", self.onPublishWriteButton, "OutPanel2")
  self:bindListener("FriendButton", self.onFriendButton)
  self:bindListener("FlowerButton", self.onFlowerButton)
  self:bindListener("ExpressionButton", self.onExpressionButton)
  self:bindListener("InfoButton", self.onPopularityInfoButton, "PopularityPanel")
  self:bindListener("InfoButton", self.onFlowerInfoButton, "FlowerPanel")
  self:bindListener("DelButton", self.onDelButton, "OutPanel2")
  self:bindListener("OneMessagePanel", self.onOneMessagePanel)
  self:bindListener("DeleteButton", self.onDeleteButton, "OneMessagePanel")
  self:bindListener("PortraitPanel", self.onPortraitPanel, "OneMessagePanel")
  self:bindListener("UnReadNotePanel", self.onUnReadNotePanel)
  self:bindListener("BackButton", self.onBackButton, "OutPanel3")
  self:setCtrlVisible("OutPanel3", false)
  self:setCtrlVisible("UnReadNotePanel", false)
  self.oneMessagePanel = self:retainCtrl("OneMessagePanel")
  self.curListViewName = "ListView"
  self.loadingPanel = self:retainCtrl("LoadingPanel")
  self.isLoading = false
  self.selectMsgData = nil
  self.lastRequestMessageIId = nil
  self.lastRequestNum = -1
  self.curLoadIndex = 0
  self.isFinishLoad = false
  self.isFirstOpenDlg = true
  self.notCallListView = false
  self.lastWriteStatus = false
  self.isUnReadView = false
  self.blogMessageList = {}
  self.cacheData = {}
  self.blogHostData = data
  local me = BlogMgr.startRequestMessage or 0
  local gid = data.user_gid
  local distName = BlogMgr:getDistByGid(gid)
  if BlogMgr.startRequestMessage then
    BlogMgr:requestBlogMessageData(BlogMgr.startRequestMessage, INIT_LOAD_MESSAGE_NUM, gid, 2, distName)
    self.lastRequestMessageIId = BlogMgr.startRequestMessage.iid
  else
    BlogMgr:requestBlogMessageData({}, INIT_LOAD_MESSAGE_NUM, gid, 1, distName)
  end
  BlogMgr:setStartRequestMessage(nil)
  self.lastRequestNum = INIT_LOAD_MESSAGE_NUM
  BlogMgr:clearMessageList(gid)
  self:refreshInfo(self.blogHostData)
  self:initWritePanel(self.blogHostData)
  self:initView()
  self:setInfoPanel(BlogMgr.blogFlowerInfo or {})
  if data.user_gid == Me:queryBasic("gid") then
    self:MSG_BLOG_MESSAGE_NUM_ABOUT_ME({
      count = BlogMgr.unReadMessageCount or 0
    })
  end
  self.openTime = gf:getServerTime()
  self:hookMsg("MSG_BLOG_MESSAGE_LIST")
  self:hookMsg("MSG_BLOG_MESSAGE_WRITE")
  self:hookMsg("MSG_BLOG_MESSAGE_DELETE")
  self:hookMsg("MSG_FRIEND_ADD_CHAR")
  self:hookMsg("MSG_BLOG_CHAR_INFO")
  self:hookMsg("MSG_BLOG_FLOWER_UPDATE")
  self:hookMsg("MSG_BLOG_MESSAGE_NUM_ABOUT_ME")
  self:hookMsg("MSG_BLOG_MESSAGE_LIST_ABOUT_ME")
  self:hookMsg("MSG_BLOG_DELETE_ALL_COMMENT_AND_MESSAGE")
end
function BlogMessageDlg:cleanup()
  DlgMgr:closeDlg("BlogRecordDlg")
  DlgMgr:closeDlg("BlogFlowersDlg")
  DlgMgr:closeDlg(self.relationLeftDlgName)
  local circleCtrl = self:getControl("LoadingImage", nil, self.loadingPanel)
  circleCtrl:stopAllActions()
end
function BlogMessageDlg:refreshInfo(data)
  data = data or {}
  if data.user_gid == Me:queryBasic("gid") then
    self:setLabelText("TitleLabel_2", CHS[5400268] .. CHS[5400269], "TitlePanel")
  else
    self:setLabelText("TitleLabel_2", gf:getRealName(data.name or "") .. CHS[5400269], "TitlePanel")
  end
end
function BlogMessageDlg:setInfoPanel(data)
  self:setLabelText("NumLabel", math.min(9999999, data.popular or 0), "PopularityPanel")
  self:setLabelText("NumLabel", data.flower or 0, "FlowerPanel")
end
function BlogMessageDlg:initWritePanel(data)
  data = data or {}
  if data.user_gid == Me:queryBasic("gid") then
    self:setCtrlVisible("WriteButton", true, "OutPanel1")
    self:setCtrlVisible("FriendButton", false, "OutPanel1")
    self:setCtrlVisible("FlowerButton", false, "OutPanel1")
  else
    self:setCtrlVisible("WriteButton", true, "OutPanel1")
    self:setCtrlVisible("FlowerButton", true, "OutPanel1")
    if FriendMgr:hasFriend(data.user_gid) then
      self:setCtrlVisible("FriendButton", false, "OutPanel1")
    else
      self:setCtrlVisible("FriendButton", BlogMgr:isSameDist(data.user_gid), "OutPanel1")
    end
  end
end
function BlogMessageDlg:initView()
  self:resetListData()
  self:setCtrlVisible("NoticePanel", false)
  local function onScrollView(sender, eventType)
    if self.notCallListView then
      return
    end
    if ccui.ScrollviewEventType.scrolling == eventType or ccui.ScrollviewEventType.scrollToTop == eventType or ccui.ScrollviewEventType.scrollToBottom == eventType then
      local listViewCtrl = sender
      local listInnerContent = listViewCtrl:getInnerContainer()
      local innerSize = listInnerContent:getContentSize()
      local scrollViewSize = listViewCtrl:getContentSize()
      local items = listViewCtrl:getItems()
      if #items <= 0 then
        return
      end
      local innerPosY = math.floor(listInnerContent:getPositionY() + 0.5)
      local totalHeight = innerSize.height - scrollViewSize.height
      if innerPosY > 0 and not self.isLoading then
        local moreData = self:getMoreMessage(ONE_LOAD_MESSAGE_NUM)
        if 0 == #moreData and not self.isFinishLoad then
          self:setLoadingVisible(true)
          return
        end
        self:refreshList(moreData)
      end
      if -innerPosY > totalHeight + 10 and not self.isLoading and not self.isUnReadView then
        self.root:stopAction(self.requestDelay)
        self.requestDelay = performWithDelay(self.root, function()
          local gid = BlogMgr:getBlogGidByDlgName(self.name)
          local item = self:getFirstItem()
          local msgData = item.msgData
          BlogMgr:requestBlogMessageData(msgData, 10, gid, 0, BlogMgr:getDistByGid(gid))
          self.lastRequestNum = 10
        end, 0.5)
        self:setLoadingVisible(true, "up")
      end
    end
  end
  self:getControl("ListView"):addScrollViewEventListener(onScrollView)
  self:getControl("UnReadListView"):addScrollViewEventListener(onScrollView)
  local circleCtrl = self:getControl("LoadingImage", nil, self.loadingPanel)
  local rotate = cc.RotateBy:create(1, 360)
  local action = cc.RepeatForever:create(rotate)
  circleCtrl:runAction(action)
  self:setCtrlVisible("DelButton", false, "OutPanel2")
  self.inputCtrl = self:createEditBox("TextPanel", "OutPanel2", nil, function(sender, type)
    if "end" == type then
    elseif "changed" == type then
      if not self.inputCtrl then
        return
      end
      local content = self.inputCtrl:getText()
      local len = gf:getTextLength(content)
      if len > WORD_LIMIT then
        content = gf:subString(content, WORD_LIMIT)
        self.inputCtrl:setText(content)
        gf:ShowSmallTips(CHS[5400041])
      end
      if len == 0 then
        self:setCtrlVisible("DelButton", false, "OutPanel2")
      else
        self:setCtrlVisible("DelButton", true, "OutPanel2")
      end
    end
  end)
  self.inputCtrl:setFontColor(COLOR3.TEXT_DEFAULT)
  self.inputCtrl:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
  self.inputCtrl:setPlaceholderFont(CHS[3003794], 21)
  self.inputCtrl:setFont(CHS[3003794], 21)
  self.inputCtrl:setPlaceHolder(CHS[5400257])
  self.inputCtrl:setPlaceholderFontSize(21)
  self.inputCtrl:setPlaceholderFontColor(cc.c3b(102, 102, 102))
  self.inputCtrl:setFontColor(COLOR3.TEXT_DEFAULT)
  self:setCtrlVisible("OutPanel1", true)
  self:setCtrlVisible("OutPanel2", true)
  local outPanel = self:getControl("OutPanel2")
  local posX = outPanel:getPositionX()
  outPanel:setPositionX(posX - WRITE_MOVE_WIDTH)
end
function BlogMessageDlg:moveOutPanel(moveX, ctrlName, time)
  local outPanel1 = self:getControl(ctrlName)
  local action = cc.MoveBy:create(time or 0.2, {x = moveX, y = 0})
  outPanel1:runAction(action)
end
function BlogMessageDlg:setLoadingVisible(visible, w)
  if self.isLoading == visible then
    return
  end
  local listView = self:getControl(self.curListViewName)
  self.isLoading = visible
  if visible then
    if w == "up" then
      listView:insertCustomItem(self.loadingPanel, 0)
    else
      listView:pushBackCustomItem(self.loadingPanel)
    end
  elseif self.loadingPanel:getParent() then
    listView:removeChild(self.loadingPanel, false)
  end
  self.notCallListView = true
  listView:refreshView()
  self.notCallListView = false
end
function BlogMessageDlg:initMessagePanel(panel, data)
  self:setImage("PortraitImage", ResMgr:getSmallPortrait(data.sender_icon), panel)
  if data.sender_dist ~= GameMgr:getDistName() then
    gf:addKuafLogo(self:getControl("PortraitPanel", nil, panel))
  end
  self:setNumImgForPanel("PortraitPanel", ART_FONT_COLOR.NORMAL_TEXT, data.sender_level, false, LOCATE_POSITION.LEFT_TOP, 21, panel)
  local nameStr = gf:getShowName(data.sender_name or "")
  if data.char_name and data.char_name ~= "" then
    nameStr = string.format(CHS[5420235], data.char_name)
  end
  self:setLabelText("PlayerNameLabel", nameStr, panel)
  local msg = data.message
  if data.target_name ~= "" then
    local str = string.format(CHS[5400286], "#B" .. gf:getShowName(data.target_name) .. "#n")
    if data.char_name and data.char_name ~= "" then
      str = string.format(CHS[5420236], gf:getShowName(data.sender_name))
    end
    msg = str .. data.message
  end
  local flower = string.match(msg, "{\029ICON=(.+)}")
  local msg = string.gsub(msg, "{\029(.+)}", "")
  msg = gf:filtTextByTwo(msg, nil, true)
  local curHeight, oldHeight = self:setColorText(msg, "TextPanel", panel, nil, nil, nil, 19, nil, nil, data.sender_vip ~= 0)
  if oldHeight < curHeight then
    local size = panel:getContentSize()
    panel:setContentSize(size.width, size.height - oldHeight + curHeight)
  end
  local flowerInfo = BlogMgr:getFlowerInfo()
  if flower and flowerInfo[flower] then
    local textPanel = self:getControl("TextPanel", nil, panel)
    local img = ccui.ImageView:create(flowerInfo[flower].icon)
    local colorLayer = textPanel:getChildByTag(Dialog.TAG_COLORTEXT_CTRL)
    local textCtrl = tolua.cast(colorLayer, "CGAColorTextList")
    local textW, textH = textCtrl:getRealSize()
    img:setScale(0.38)
    img:setPosition(textW + img:getContentSize().width / 2 * 0.38, img:getContentSize().height / 2 * 0.38)
    textPanel:addChild(img)
  end
  local str = self:getTimeStr(data.time or 0)
  self:setLabelText("TimeLabel", str, panel)
  if (self.blogHostData.user_gid == Me:queryBasic("gid") or data.sender_gid == Me:queryBasic("gid")) and not data.char_name then
    self:setCtrlVisible("DeleteButton", true, panel)
  else
    self:setCtrlVisible("DeleteButton", false, panel)
  end
  panel.msgData = data
end
function BlogMessageDlg:getTimeStr(time)
  local curTime = gf:getServerTime()
  local timeStr
  local timeC = math.abs(curTime - time)
  if timeC <= 3600 then
    local min = math.floor(timeC / 60) + 1
    timeStr = string.format(CHS[6000088], min)
  elseif timeC < 86400 then
    local hour = math.floor(timeC / 3600)
    timeStr = string.format(CHS[6000087], hour)
  else
    timeStr = gf:getServerDate(CHS[4300233], time)
  end
  return timeStr
end
function BlogMessageDlg:resetListData()
  self:setCtrlVisible("NoticePanel", true)
  self:resetListView(self.curListViewName, LISTVIEW_MARGIN)
end
function BlogMessageDlg:refreshList(data, isReset, upLoad)
  self:setCtrlVisible("NoticePanel", false)
  self:setLoadingVisible(false)
  if #data == 0 then
    return
  end
  local listView
  if isReset then
    listView = self:resetListView(self.curListViewName, LISTVIEW_MARGIN)
  else
    listView = self:getControl(self.curListViewName)
  end
  if not upLoad then
    for i = 1, #data do
      local panel = self.oneMessagePanel:clone()
      self:initMessagePanel(panel, data[i])
      listView:pushBackCustomItem(panel)
    end
  else
    for i = 1, #data do
      local panel = self.oneMessagePanel:clone()
      self:initMessagePanel(panel, data[i])
      listView:insertCustomItem(panel, i - 1)
    end
  end
  self.notCallListView = true
  listView:doLayout()
  listView:refreshView()
  self.notCallListView = false
end
function BlogMessageDlg:removeOneItem(index)
  local listView = self:getControl("ListView")
  local items = listView:getItems()
  if index > #items then
    return
  end
  listView:removeItem(index - 1)
  local moreData = self:getMoreMessage(1)
  if #moreData > 0 then
    self:refreshList(moreData)
  end
  local data = self.blogMessageList or {}
  local cou = #data
  if index == cou and data[index - 1] then
    self.lastRequestMessageIId = data[index - 1].iid
  elseif cou == 1 then
    self:resetListData()
  end
  self.curLoadIndex = self.curLoadIndex - 1
end
function BlogMessageDlg:getMoreMessage(num, notRequest)
  local moreData = {}
  local data = self.blogMessageList or {}
  local cou = #data
  if cou > self.curLoadIndex then
    for i = self.curLoadIndex + 1, self.curLoadIndex + num do
      if data[i] then
        table.insert(moreData, data[i])
        self.curLoadIndex = self.curLoadIndex + 1
      else
        break
      end
    end
  end
  if not notRequest and not self.isFinishLoad and data[cou] and self.lastRequestMessageIId ~= data[cou].iid then
    local message = data[cou]
    if self.isUnReadView then
      BlogMgr:requestBlogUnReadMessageData(message, num)
    else
      local gid = BlogMgr:getBlogGidByDlgName(self.name)
      BlogMgr:requestBlogMessageData(message, num, gid, nil, BlogMgr:getDistByGid(gid))
    end
    self.lastRequestNum = num
    self.lastRequestMessageIId = data[cou].iid
  end
  return moreData
end
function BlogMessageDlg:switchWritePanel(isWrite)
  if self.lastWriteStatus == isWrite then
    return
  end
  self.lastWriteStatus = isWrite
  if isWrite then
    self:moveOutPanel(WRITE_MOVE_WIDTH, "OutPanel2")
    self:moveOutPanel(WRITE_MOVE_WIDTH, "OutPanel1")
  else
    self:moveOutPanel(-WRITE_MOVE_WIDTH, "OutPanel1")
    self:moveOutPanel(-WRITE_MOVE_WIDTH, "OutPanel2")
  end
end
function BlogMessageDlg:initInputCtrl()
  self.inputCtrl:setPlaceHolder(CHS[5400257])
  self.selectMsgData = nil
  self:onDelButton()
end
function BlogMessageDlg:isMeetLevel()
  local gid = BlogMgr:getBlogGidByDlgName(self.name)
  if Me:queryBasicInt("level") < 40 and Me:queryBasic("gid") == gid then
    gf:ShowSmallTips(CHS[5400263])
    return
  end
  if Me:queryBasicInt("level") < 70 and Me:queryBasic("gid") ~= gid then
    gf:ShowSmallTips(CHS[4300291])
    return
  end
  return true
end
function BlogMessageDlg:onSwitchWriteButton(sender, eventType)
  if not self:isMeetLevel() then
    return
  end
  self:switchWritePanel(true)
  self.selectMsgData = nil
end
function BlogMessageDlg:onCloseWriteButton(sender, eventType)
  self:switchWritePanel(false)
  self:initInputCtrl()
end
function BlogMessageDlg:onPublishWriteButton(sender, eventType)
  if gf:isLimitChangeUserInfo() then
    return
  end
  self:sendMessage()
end
function BlogMessageDlg:onFriendButton(sender, eventType)
  if not self.blogHostData then
    return
  end
  FriendMgr:tryToAddFriend(self.blogHostData.name, self.blogHostData.user_gid)
end
function BlogMessageDlg:onFlowerButton(sender, eventType)
  if not self.blogHostData then
    return
  end
  if not BlogMgr:isSameDist(self.blogHostData.user_gid) then
    gf:ShowSmallTips(CHS[4300366])
    return
  end
  if Me:queryBasicInt("level") < BlogMgr:getMessageLimitLevel() then
    gf:ShowSmallTips(CHS[5400267])
    return
  end
  local gid = BlogMgr:getBlogGidByDlgName(self.name)
  DlgMgr:openDlgEx("BlogFlowersDlg", gid)
end
function BlogMessageDlg:onExpressionButton(sender, eventType)
  local dlg = DlgMgr:getDlgByName("LinkAndExpressionDlg")
  if dlg then
    DlgMgr:closeDlg("LinkAndExpressionDlg")
    return
  end
  dlg = DlgMgr:openDlg("LinkAndExpressionDlg")
  dlg:setCallObj(self, "blog")
  local height = dlg:getMainBodyHeight()
  DlgMgr:upDlg("BlogMessageDlg", height)
end
function BlogMessageDlg:addExpression(expression)
  if not self.inputCtrl then
    return
  end
  local content = self.inputCtrl:getText()
  if gf:getTextLength(content .. expression) > WORD_LIMIT then
    gf:ShowSmallTips(CHS[5400041])
    return
  end
  content = content .. expression
  self.inputCtrl:setText(content)
  self:setCtrlVisible("DelButton", true, "OutPanel2")
end
function BlogMessageDlg:addSpace()
  if not self.inputCtrl then
    return
  end
  local content = self.inputCtrl:getText()
  if gf:getTextLength(content .. " ") > WORD_LIMIT then
    gf:ShowSmallTips(CHS[5400041])
    return
  end
  self.inputCtrl:setText(content .. " ")
  self:setCtrlVisible("DelButton", true, "OutPanel2")
end
function BlogMessageDlg:deleteWord()
  if not self.inputCtrl then
    return
  end
  local text = self.inputCtrl:getText()
  local len = string.len(text)
  local deletNum = 0
  if len > 0 then
    if string.byte(text, len) < 128 then
      deletNum = 1
    elseif 128 <= string.byte(text, len - 1) and string.byte(text, len - 2) >= 224 then
      deletNum = 3
    elseif string.byte(text, len - 1) >= 192 then
      deletNum = 2
    end
    local newtext = string.sub(text, 0, len - deletNum)
    self.inputCtrl:setText(newtext)
    if len - deletNum <= 0 then
      self:setCtrlVisible("DelButton", false, "OutPanel2")
    end
  else
    self:setCtrlVisible("DelButton", false, "OutPanel2")
  end
end
function BlogMessageDlg:sendMessage(content)
  if not self:isMeetLevel() then
    return
  end
  local content = self.inputCtrl:getText()
  if content == nil or string.len(content) == 0 then
    gf:ShowSmallTips(CHS[5400265])
    return
  end
  local filtTextStr, haveFilt = gf:filtTextByTwo(content, nil, true)
  if haveFilt then
    ChatMgr:shieldLog("wenzpb", 4, content)
    local dlg = DlgMgr:openDlg("OnlyConfirmDlg")
    dlg:setTip(CHS[5420088])
    dlg:setCallFunc(function()
      gf:ShowSmallTips(CHS[5400266])
      ChatMgr:sendMiscMsg(CHS[5400266])
      DlgMgr:closeDlg("OnlyConfirmDlg")
      self.inputCtrl:setText(filtTextStr)
    end, true)
    return
  end
  local msgData = self.selectMsgData or {}
  content = BrowMgr:addGenderSign(content)
  BrowMgr:updateBrowUseTime(content)
  local gid = BlogMgr:getBlogGidByDlgName(self.name)
  BlogMgr:requestAddBlogMessage(msgData.sender_gid, msgData.iid, content, gid, BlogMgr:getDistByGid(gid), msgData.sender_dist)
end
function BlogMessageDlg:swichWordInput()
  if not self.inputCtrl then
    return
  end
  self.inputCtrl:sendActionsForControlEvents(cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
end
function BlogMessageDlg:LinkAndExpressionDlgcleanup()
  DlgMgr:resetUpDlg("BlogMessageDlg")
end
function BlogMessageDlg:onPopularityInfoButton(sender, eventType)
  gf:showTipInfo(CHS[5400287], sender)
end
function BlogMessageDlg:onFlowerInfoButton(sender, eventType)
  local curGid = BlogMgr:getBlogGidByDlgName(self.name)
  if not BlogMgr:isSameDist(curGid) then
    gf:ShowSmallTips(CHS[4300368])
    return
  end
  DlgMgr:openDlgEx("BlogRecordDlg", {
    type = "flower",
    gid = curGid,
    dist = BlogMgr:getDistByGid(curGid)
  })
end
function BlogMessageDlg:onReportCommentForBlog(sender, eventType)
  if not self.selectMsgData then
    return
  end
  local para = "@spcial@;" .. self.selectMsgData.message .. CHS[4300499] .. BlogMgr:getDistByGid(self.blogHostData.user_gid) .. ":" .. self.selectMsgData.iid .. ";" .. self.blogHostData.user_gid
  ChatMgr:questOpenReportDlg(self.selectMsgData.sender_gid, self.selectMsgData.sender_name, self.selectMsgData.sender_dist, para)
  self.selectMsgData = nil
end
function BlogMessageDlg:onReplyCommentForBlog(sender, eventType)
  if not self.selectMsgData then
    return
  end
  local name = self.selectMsgData.sender_name
  if not self:isMeetLevel() then
    return
  end
  self:switchWritePanel(true)
  self.inputCtrl:setPlaceHolder(string.format(CHS[5400258], gf:getShowName(name)))
end
function BlogMessageDlg:onDelSomeOneAllComment(sender, eventType)
  if not self.selectMsgData then
    return
  end
  local selectMsgData = self.selectMsgData
  gf:confirm(CHS[2200229], function()
    if not DlgMgr:getDlgByName("BlogMessageDlg") then
      return
    end
    BlogMgr:deleteSomeOneAllComment(selectMsgData.sender_gid)
  end)
end
function BlogMessageDlg:onOneMessagePanel(sender, eventType)
  local msgData = sender.msgData
  if not msgData or msgData.sender_gid == Me:queryBasic("gid") then
    return
  end
  if self.isUnReadView then
    if msgData.char_gid == Me:queryBasic("gid") then
      return
    end
    BlogMgr:openBlog(msgData.char_gid, 2, nil, BlogMgr:getDistByGid(msgData.char_gid))
    BlogMgr:setStartRequestMessage(msgData)
  else
    self:onCloseWriteButton()
    self:initInputCtrl()
    if self.blogHostData and self.blogHostData.user_gid == Me:queryBasic("gid") then
      BlogMgr:showButtonList(self, sender, "blogCommentAndReportForMyMessage", self.name)
    else
      BlogMgr:showButtonList(self, sender, "blogCommentAndReportForMessage", self.name)
    end
    self.selectMsgData = msgData
  end
end
function BlogMessageDlg:checkIsExsit(iid)
  if not next(self.blogMessageList) then
    return false
  end
  for key, v in ipairs(self.blogMessageList) do
    if v.iid == iid then
      return true
    end
  end
  return false
end
function BlogMessageDlg:onDeleteButton(sender, eventType)
  local msgData = sender:getParent().msgData
  if msgData then
    do
      local dlgName = self.name
      gf:confirm(CHS[5400259], function()
        local gid = BlogMgr:getBlogGidByDlgName(dlgName)
        if gid then
          if self:checkIsExsit(msgData.iid) then
            local distName = BlogMgr:getDistByGid(gid)
            BlogMgr:requestDeleteBlogMessage(msgData.iid, gid, distName)
          else
            gf:ShowSmallTips(CHS[4300293])
          end
        end
      end)
    end
  end
end
function BlogMessageDlg:onPortraitPanel(sender, eventType)
  local msgData = sender:getParent().msgData
  if msgData and msgData.sender_gid ~= Me:queryBasic("gid") then
    local char = {}
    char.gid = msgData.sender_gid
    char.name = msgData.sender_name
    char.level = msgData.sender_level
    char.icon = msgData.sender_icon
    char.isOnline = 2
    local rect = self:getBoundingBoxInWorldSpace(sender)
    char.dist_name = msgData.sender_dist
    if msgData.sender_dist ~= GameMgr:getDistName() then
      FriendMgr:openCharMenu(char, CHAR_MUNE_TYPE.KUAFU_BLOG, rect)
    else
      FriendMgr:openCharMenu(char, nil, rect)
    end
  end
end
function BlogMessageDlg:onDelButton(sender, eventType)
  self.inputCtrl:setText("")
  self:setCtrlVisible("DelButton", false, "OutPanel2")
end
function BlogMessageDlg:MSG_BLOG_MESSAGE_WRITE(data)
  if data.host_gid == BlogMgr:getUserGid(self.name) then
    self:initInputCtrl()
  end
end
function BlogMessageDlg:MSG_BLOG_MESSAGE_LIST(data, isUnRead)
  if data.host_gid ~= BlogMgr:getUserGid(self.name) then
    return
  end
  if self.isUnReadView and isUnRead ~= true then
    return
  end
  self:addMessage(data)
  if data.count == -1 then
    gf:ShowSmallTips(CHS[4300198])
    ChatMgr:sendMiscMsg(CHS[4300198])
    self.lastRequestMessageIId = nil
    self.lastRequestNum = -1
  end
  if data.request_iid == "" and data.count < 1 then
    self:resetListData()
    if data.count == 0 then
      self.isFirstOpenDlg = false
      if not self.isUnReadView and data.host_gid == Me:queryBasic("gid") then
        BlogMgr:setHasMailRedDotForMessage(nil)
      end
    end
    return
  end
  if data.count < self.lastRequestNum then
    self.isFinishLoad = true
  else
    self.isFinishLoad = false
  end
  self.lastRequestNum = -1
  if data.request_iid == "" or self.isFirstOpenDlg then
    self.curLoadIndex = 0
    self.lastRequestMessageIId = nil
    local moreData = self:getMoreMessage(ONE_LOAD_MESSAGE_NUM, true)
    self:refreshList(moreData, true)
    if not self.isUnReadView and data.host_gid == Me:queryBasic("gid") then
      BlogMgr:setHasMailRedDotForMessage(nil)
    end
    self.isFirstOpenDlg = false
  elseif self.isLoading then
    if not data.isUpLoad then
      local moreData = self:getMoreMessage(ONE_LOAD_MESSAGE_NUM)
      self:refreshList(moreData)
    else
      self:refreshList(data, nil, true)
      self.curLoadIndex = self.curLoadIndex + #data
      if #data > 0 then
        if data[1].time > self.openTime then
          gf:ShowSmallTips(CHS[5420232])
          ChatMgr:sendMiscMsg(CHS[5420232])
        end
      elseif data.host_gid == Me:queryBasic("gid") then
        BlogMgr:setHasMailRedDotForMessage(nil)
      end
    end
  end
end
function BlogMessageDlg:getFirstItem()
  local listView = self:getControl("ListView")
  local items = listView:getItems()
  if items[1]:getName() == "LoadingPanel" then
    return items[2]
  else
    return items[1]
  end
end
function BlogMessageDlg:MSG_BLOG_MESSAGE_LIST_ABOUT_ME(data)
  if not self.isUnReadView then
    return
  end
  self:MSG_BLOG_MESSAGE_LIST(data, true)
end
function BlogMessageDlg:MSG_BLOG_MESSAGE_NUM_ABOUT_ME(data)
  if data.count > 0 and self.blogHostData.user_gid == Me:queryBasic("gid") then
    self:setLabelText("UnReadNoteLabel", string.format(CHS[5420234], data.count))
    self:setCtrlVisible("UnReadNotePanel", true)
    BlogMgr:setHasMailRedDotForMessage(nil, "unread")
  else
    self:setCtrlVisible("UnReadNotePanel", false)
  end
end
function BlogMessageDlg:onUnReadNotePanel()
  self:setLoadingVisible(false)
  self.cacheData = {
    blogMessageList = self.blogMessageList,
    selectMsgData = self.selectMsgData,
    isFinishLoad = self.isFinishLoad,
    lastWriteStatus = self.lastWriteStatus,
    curLoadIndex = self.curLoadIndex
  }
  self:setCtrlVisible("ListView", false)
  self:setCtrlVisible("UnReadListView", true)
  self.curListViewName = "UnReadListView"
  local items = self:getControl("UnReadListView"):getItems()
  self:setCtrlVisible("NoticePanel", #items == 0)
  self.root:stopAction(self.requestDelay)
  BlogMgr:requestBlogUnReadMessageData({}, INIT_LOAD_MESSAGE_NUM)
  self.lastRequestNum = INIT_LOAD_MESSAGE_NUM
  BlogMgr.unReadMessageCount = 0
  self.isUnReadView = true
  self:setCtrlVisible("OutPanel3", true)
  self:setCtrlVisible("OutPanel1", false)
  self:setCtrlVisible("OutPanel2", false)
  self:setCtrlVisible("UnReadNotePanel", false)
end
function BlogMessageDlg:onBackButton()
  self:setLoadingVisible(false)
  self.blogMessageList = self.cacheData.blogMessageList
  self.selectMsgData = self.cacheData.selectMsgData
  self.isFinishLoad = self.cacheData.isFinishLoad
  self.lastWriteStatus = self.cacheData.lastWriteStatus
  self.curLoadIndex = self.cacheData.curLoadIndex
  self.lastRequestMessageIId = nil
  self.lastRequestNum = -1
  self:setCtrlVisible("ListView", true)
  self:setCtrlVisible("UnReadListView", false)
  self.curListViewName = "ListView"
  local items = self:getControl("ListView"):getItems()
  self:setCtrlVisible("NoticePanel", #items == 0)
  self.root:stopAction(self.requestDelay)
  self.isUnReadView = false
  self:setCtrlVisible("OutPanel3", false)
  self:setCtrlVisible("OutPanel1", true)
  self:setCtrlVisible("OutPanel2", true)
end
function BlogMessageDlg:MSG_FRIEND_ADD_CHAR(data)
  local curGid = BlogMgr:getUserGid(self.name)
  if curGid ~= Me:queryBasic("gid") then
    if FriendMgr:hasFriend(curGid) then
      self:setCtrlVisible("FriendButton", false, "OutPanel1")
    else
      self:setCtrlVisible("FriendButton", BlogMgr:isSameDist(curGid), "OutPanel1")
    end
  end
end
function BlogMessageDlg:MSG_BLOG_CHAR_INFO(data)
  self.blogHostData = BlogMgr:getUserDataByDlgName(self.name)
  self:refreshInfo(self.blogHostData)
  self:initWritePanel(self.blogHostData)
end
function BlogMessageDlg:MSG_BLOG_FLOWER_UPDATE(data)
  if data.host_gid ~= BlogMgr:getUserGid(self.name) then
    return
  end
  self:setInfoPanel(data)
end
function BlogMessageDlg:addMessage(data)
  if data.request_iid == "" or not self.blogMessageList then
    self.blogMessageList = {}
  end
  local oldData = self.blogMessageList
  if #data > 0 then
    if not oldData[1] or oldData[1].time > data[1].time or oldData[1].time == data[1].time and oldData[1].iid > data[1].iid then
      for i = 1, #data do
        table.insert(self.blogMessageList, data[i])
      end
      data.isUpLoad = false
    else
      self.blogMessageList = {}
      for i = 1, #data do
        table.insert(self.blogMessageList, data[i])
      end
      for i = 1, #oldData do
        table.insert(self.blogMessageList, oldData[i])
      end
      data.isUpLoad = true
    end
  end
end
function BlogMessageDlg:MSG_BLOG_MESSAGE_DELETE(data)
  if data.host_gid ~= BlogMgr:getUserGid(self.name) then
    return
  end
  if self.isUnReadView then
    return
  end
  if not next(self.blogMessageList) then
    return
  end
  for key, v in ipairs(self.blogMessageList) do
    if v.iid == data.iid then
      self:removeOneItem(key)
      table.remove(self.blogMessageList, key)
      break
    end
  end
end
function BlogMessageDlg:MSG_BLOG_DELETE_ALL_COMMENT_AND_MESSAGE(data)
  local gid = BlogMgr:getBlogGidByDlgName(self.name)
  BlogMgr:requestBlogMessageData({}, INIT_LOAD_MESSAGE_NUM, gid, 1, BlogMgr:getDistByGid(gid))
end
return BlogMessageDlg
