local DossierDlg = Singleton("DossierDlg", Dialog)
local SUB_PANEL_NAME = "JUAN"
local TIPS_COLOR = cc.c3b(168, 133, 94)
local TITLE_IMAGE_RES = {
  [CHS[4101149]] = ResMgr.ui.tanan_bjfy
}
local EVIDENCE_CFG = {
  num = 10,
  emptyPath = ResMgr.ui.bag_no_item_bg_img,
  itemPath = ResMgr.ui.bag_item_bg_img
}
local CLUE_LIST_VIEW_OFFSETY = 38
function DossierDlg:init()
  self:bindListViewListener("ClueListView", self.onSelectClueListView)
  self.orgTipsPos = cc.p(self:getControl("PromptTextPanel", Const.UIPanel, "SingleCluePanel"):getPosition())
  self.itemCtrl = self:retainCtrl("SingleCluePanel")
  self:refreshTitle()
  self:bindFloatPanelListener("MXZRulePanel")
end
function DossierDlg:refreshTitle()
  local image = self:getControl("NameImage", Const.UIImage, "TitlePanel1")
  if TaskMgr:getTaskByName(CHS[7190256]) then
    image:loadTexture(ResMgr.ui.tanan_jhll_dossier_title)
  elseif TaskMgr:getTaskByName(CHS[5400611]) then
    image:loadTexture(ResMgr.ui.tanan_tw_dossier_title)
  elseif TaskMgr:getTaskByName(CHS[7190287]) then
    image:loadTexture(ResMgr.ui.tanan_mxza_dossier_title)
  elseif TaskMgr:getTaskByName(CHS[7100914]) then
    image:loadTexture(ResMgr.ui.tanan_sswd_dossier_title)
  elseif TaskMgr:getTaskByName(CHS[5400946]) then
    image:loadTexture(ResMgr.ui.tanan_smfj_dossier_title)
  elseif TaskMgr:getTaskByName(CHS[7100955]) then
    image:loadTexture(ResMgr.ui.tanan_mshc_dossier_title)
  elseif TaskMgr:getTaskByName(CHS[7120444]) then
    image:loadTexture(ResMgr.ui.tanan_jnsz_dossier_title)
  elseif TaskMgr:getTaskByName(CHS[4200985]) then
    image:loadTexture(ResMgr.ui.tanan_stmz_dossier_title)
  end
end
function DossierDlg:setData(data)
  if not data then
    return
  end
  self.data = data
  self:setCtrlVisible("MainPanel", false)
  self:setCtrlVisible("MXZAMainPanel", false)
  self:setCtrlVisible("NoProgressMainPanel", false)
  local isInClueListTask = TaskMgr:getTaskByName(CHS[7190287]) or TaskMgr:getTaskByName(CHS[7100914]) or TaskMgr:getTaskByName(CHS[5400946])
  local isNoProgressTask = TaskMgr:getTaskByName(CHS[7100955])
  self.mainPanel = nil
  if isInClueListTask then
    self.mainPanel = self:getControl("MXZAMainPanel")
    self:initMxzaItem()
  elseif isNoProgressTask then
    self.mainPanel = self:getControl("NoProgressMainPanel")
  else
    self.mainPanel = self:getControl("MainPanel")
  end
  self.mainPanel:setVisible(true)
  local progressPanel = self:getControl("ProgressPanel", nil, self.mainPanel)
  if isInClueListTask then
    self:setLabelText("TextLabel", string.format(CHS[7190294], data.count), progressPanel)
    self:bindListener("InfoButton", self.onMxInfoButton, progressPanel)
  elseif isNoProgressTask then
  elseif data.percent >= 0 then
    progressPanel:setVisible(true)
    self:setProgressBar("ConsumeProgressBar", data.percent, 100, progressPanel)
    self:setLabelText("NumLabel", data.percent .. "%", progressPanel)
  else
    progressPanel:setVisible(false)
  end
  if isInClueListTask and isInClueListTask.task_type == CHS[5400946] then
    self:setCtrlVisible("ProgressPanel", false, self.mainPanel)
    self:setLabelText("TextLabel", CHS[5400990], "EvidencePanel")
  end
  self:clearSchedule()
  if self.showLeftInfo and self.showLeftPanel and data.list[self.showLeftInfo.index] then
    self.showLeftPanel:setPosition(self.orgTipsPos)
    self:setColorText(string.format(CHS[7190239], data.list[self.showLeftInfo.index].tips), self.showLeftPanel, nil, nil, nil, COLOR3.TIPS_COLOR, 17, false, true)
    self.showLeftInfo = nil
    self.showLeftPanel = nil
    return
  end
  local listView = self:resetListView("ClueListView", 10, nil, self.mainPanel)
  for i = 1, data.count do
    local singleInfo = data.list[i]
    if not singleInfo then
      return
    end
    local item = self:setSingleItem(self.itemCtrl:clone(), singleInfo, i == data.count)
    item:setName(SUB_PANEL_NAME .. i)
    listView:pushBackCustomItem(item)
  end
  if data.hasNext then
    local nextInfo = {}
    nextInfo.index = data.count + 1
    nextInfo.des = CHS[7190240]
    nextInfo.tips = CHS[7190241]
    if isInClueListTask then
      nextInfo.tips = CHS[7100363]
    end
    nextInfo.showLeftTime = 0
    local item = self:setSingleItem(self.itemCtrl:clone(), nextInfo)
    self:setCtrlVisible("RemarksButton", false, item)
    listView:pushBackCustomItem(item)
  end
  listView:refreshView()
  self:setListInnerPosByIndex("ClueListView", data.hasNext and data.count + 1 or data.count, self.mainPanel)
  if isInClueListTask then
    local innerContainer = self:getControl("ClueListView", nil, self.mainPanel):getInnerContainer()
    innerContainer:setPositionY(innerContainer:getPositionY() - CLUE_LIST_VIEW_OFFSETY)
  end
  self:startSchedule()
  if TITLE_IMAGE_RES[data.taskName] then
    self:setImage("NameImage", ResMgr.ui.tanan_bjfy, "TitlePanel1")
  else
  end
end
function DossierDlg:setSingleItem(panel, info, isLast)
  self:setLabelText("TitleLabel", string.format(CHS[7190238], gf:numberToChs(info.index)), panel)
  if info.index > 20 then
    self:getControl("TitlePanel", nil, panel):setContentSize(cc.size(160, 28))
    self:getControl("TitleLabel", nil, panel):setContentSize(cc.size(105, 28))
  end
  self:setColorText(string.format(CHS[7190243], info.des), "ClueTextPanel", panel, nil, nil, COLOR3.ORANGE, 19, false, true)
  if info.showLeftTime and info.showLeftTime > 0 then
    local tips = gf:getServerDate(CHS[7190242], math.min(info.showLeftTime, 300))
    self:setColorText(string.format(CHS[7190239], tips), "PromptTextPanel", panel, nil, nil, COLOR3.TIPS_COLOR, 17, false, true)
  else
    self:setColorText(string.format(CHS[7190239], info.tips), "PromptTextPanel", panel, nil, nil, COLOR3.TIPS_COLOR, 17, false, true)
  end
  local remarkButton = self:getControl("RemarksButton", Const.UIButton, panel)
  remarkButton.info = info
  self:bindTouchEndEventListener(remarkButton, self.onRemarkButton)
  panel.info = info
  return panel
end
function DossierDlg:refreshRemarks(index, text)
  if not self.data or not self.data.list[index] then
    return
  end
  self.data.list[index].remarks = text
  local innarContainer = self:getControl("ClueListView", nil, self.mainPanel):getInnerContainer()
  local remarksButton = self:getControl("RemarksButton", Const.UIButton, innarContainer:getChildByName(SUB_PANEL_NAME .. index))
  if remarksButton then
    remarksButton.info = self.data.list[index]
  end
end
function DossierDlg:onRemarkButton(sender, eventType)
  local info = sender.info
  if not info or not self.data then
    return
  end
  local rect = self:getBoundingBoxInWorldSpace(sender)
  local dlg = DlgMgr:openDlg("DossierTipsDlg")
  info.taskName = self.data.taskName
  dlg:setData(info)
  dlg.root:setAnchorPoint(0, 0)
  dlg:setFloatingFramePos(rect)
end
function DossierDlg:onSelectClueListView(sender, eventType)
end
function DossierDlg:startSchedule()
  if self.scheduleId then
    return
  end
  self.scheduleId = gf:Schedule(function()
    local listView = self:getControl("ClueListView", nil, self.mainPanel)
    local items = listView:getItems()
    for i = 1, #items do
      local item = items[i]
      if item and item.info and item.info.showLeftTime > 0 then
        item.info.showLeftTime = item.info.showLeftTime - 1
        local tips = gf:getServerDate(CHS[7190242], math.min(item.info.showLeftTime, 300))
        local leftPanel = self:getControl("PromptTextPanel", Const.UIPanel, item)
        self:setColorText(string.format(CHS[7190239], tips), leftPanel, nil, nil, nil, COLOR3.TIPS_COLOR, 17, false, true)
        if item.info.showLeftTime <= 0 then
          local task = TaskMgr:getTaskByShowName(CHS[7190224])
          if not task then
            return
          end
          gf:CmdToServer("CMD_DETECTIVE_TASK_CLUE", {
            taskName = task.task_type
          })
          self.showLeftInfo = item.info
          self.showLeftPanel = leftPanel
        end
      end
    end
  end, 1)
end
function DossierDlg:clearSchedule()
  if self.scheduleId then
    gf:Unschedule(self.scheduleId)
    self.scheduleId = nil
  end
end
function DossierDlg:cleanup()
  self:clearSchedule()
  self.showLeftInfo = nil
  self.showLeftPanel = nil
  self.data = nil
end
function DossierDlg:initMxzaItem()
  local root = self:getControl("EvidencePanel", nil, "MXZAMainPanel")
  local items = TanAnMgr:getEvidenceItems()
  local lenth = #items
  self:setCtrlVisible("NextButton", lenth > EVIDENCE_CFG.num, root)
  self:bindListener("NextButton", self.onNextEvidenceItem, root)
  self:setMxzaItemList(1)
  for i = 1, EVIDENCE_CFG.num do
    local panel = self:getControl("ItemShapePanel" .. i, nil, root)
    self:bindListener("ItemImage", self.onMxzaItem, panel)
  end
end
function DossierDlg:setMxzaItemList(startIndex)
  local root = self:getControl("EvidencePanel", nil, "MXZAMainPanel")
  local items = TanAnMgr:getEvidenceItems()
  local lenth = #items
  for i = 1, EVIDENCE_CFG.num do
    local itemRoot = self:getControl("ItemShapePanel" .. i, nil, root)
    local img = self:getControl("ItemImage", nil, itemRoot)
    img:setVisible(false)
    local itemIndex = i + startIndex - 1
    if items[itemIndex] then
      itemRoot:setBackGroundImage(EVIDENCE_CFG.itemPath, ccui.TextureResType.plistType)
      img:setVisible(true)
      img:loadTexture(ResMgr:getIconPathByName(items[itemIndex].name))
      img.item = items[itemIndex]
    else
      itemRoot:setBackGroundImage(EVIDENCE_CFG.emptyPath, ccui.TextureResType.plistType)
      img.item = nil
    end
  end
  self:getControl("NextButton", nil, root).startIndex = startIndex
end
function DossierDlg:onMxzaItem(sender, eventType)
  local item = sender.item
  if not item then
    return
  end
  local dlg = InventoryMgr:showBasicMessageByItem(item, self:getBoundingBoxInWorldSpace(sender))
  if dlg then
    dlg:setShowButtons({use = true, more = false})
    dlg:setCtrlVisible("ResourceButton", false)
    dlg:getControl("ApplyButton"):getLayoutParameter():setAlign(ccui.RelativeAlign.alignParentBottomCenterHorizontal)
  end
end
function DossierDlg:onNextEvidenceItem(sender, eventType)
  local items = TanAnMgr:getEvidenceItems()
  local lenth = #items
  local nextIndex = sender.startIndex + EVIDENCE_CFG.num
  if lenth >= nextIndex then
    self:setMxzaItemList(nextIndex)
  else
    self:setMxzaItemList(1)
  end
end
function DossierDlg:onMxInfoButton(sender, eventType)
  if TaskMgr:getTaskByName(CHS[7100914]) then
    DlgMgr:openDlg("WodiRuleDlg")
  else
    self:setCtrlVisible("MXZRulePanel", true)
  end
end
return DossierDlg
