local BirthDayGiftDlg = Singleton("BirthDayGiftDlg", Dialog)
local FOLLOW_SPRITE_OFFPOS = {
  [1] = cc.p(-30, -60),
  [3] = cc.p(40, -60),
  [5] = cc.p(-40, -60),
  [7] = cc.p(40, -60)
}
function BirthDayGiftDlg:getCfgFileName()
  return ResMgr:getDlgCfg("ServiceGiftDlg")
end
function BirthDayGiftDlg:init(data)
  self:bindListener("GetButton", self.onGetButton)
  self:bindListViewListener("ListView", self.onSelectListView)
  self:bindListener("TurnRightButton", self.onTurnRightButton)
  self:bindListener("TurnLeftButton", self.onTurnLeftButton)
  self.unitPanel = self:retainCtrl("OneRowPartyMemberPanel")
  self:bindListener("CheckBox", self.onCheckBox, self.unitPanel)
  self.notePanel = self:retainCtrl("NotePanel")
  self:setLabelText("TitleLabel", CHS[7150622], "ShapePanel")
  self:setLabelText("TitleLabel_1", CHS[4300890])
  self:setLabelText("TitleLabel_2", CHS[4300890])
  self.orgIcon = Me:queryBasicInt("icon")
  self.fashion = nil
  self.data = data
  self:setData(data)
end
function BirthDayGiftDlg:cleanup()
  self.giftNum = nil
  self.fashion = nil
  self.data = nil
end
function BirthDayGiftDlg:setData(data)
  self:setCtrlVisible("Label_1", false, "TypePanel")
  self:setCtrlVisible("Label_2", false, "TypePanel")
  self:setCtrlVisible("Label_3", true, "TypePanel")
  local list = self:resetListView("ListView")
  for i = 1, data.bonus_count do
    local panel = self.unitPanel:clone()
    self:setGudingUnitPanel(data.bonus_list[i], panel, i)
    list:pushBackCustomItem(panel)
  end
  list:pushBackCustomItem(self.notePanel)
  for i = 1, data.fasion_count do
    local panel = self.unitPanel:clone()
    self:setUnitPanel(data.fashion_list[i], panel, i)
    list:pushBackCustomItem(panel)
  end
end
function BirthDayGiftDlg:setGudingUnitPanel(data, panel, i)
  if data.type == "appellation" then
    local image = self:setImagePlist("Image", ResMgr.ui.small_title, panel)
    InventoryMgr:addLogoTimeLimit(image)
  elseif data.type == "item" then
    local image = self:setImage("Image", ResMgr:getIconPathByName(data.name), panel)
    if string.match(data.name, CHS[4300893]) then
      InventoryMgr:addLogoTimeLimit(image)
    else
      InventoryMgr:addLogoBinding(image)
    end
  end
  self:setImageSize("Image", {width = 64, height = 64}, panel)
  self:setLabelText("NameLabel", data.name, panel)
  self:setCtrlVisible("BackImage_2", i % 2 == 0, panel)
  self:setCtrlVisible("CheckBox", false, panel)
end
function BirthDayGiftDlg:setUnitPanel(data, panel, i)
  local itemName = data.name
  local days = data.days
  self:setImage("Image", ResMgr:getIconPathByName(itemName), panel)
  self:setImageSize("Image", {width = 64, height = 64}, panel)
  self:setLabelText("NameLabel", itemName .. "·" .. string.format(CHS[4200520], days), panel)
  self:setCtrlVisible("BackImage_2", i % 2 == 0, panel)
  panel.fashion = data
end
function BirthDayGiftDlg:refreshPortraitPanel(isTurn)
  local root = self:getControl("ShapePanel")
  local userPanel = self:getControl("UserPanel", nil, root)
  userPanel:removeAllChildren()
  if not self.fashion then
    self:setLabelText("TitleLabel", CHS[7150622], root)
    return
  end
  if not isTurn then
    self.dir = 5
  end
  self:setLabelText("TitleLabel", self.fashion.name .. "·" .. string.format(CHS[4200520], self.fashion.days), root)
  local icon = InventoryMgr:getFashionShapeIcon(self.fashion.name)
  self:setPortrait("UserPanel", icon, nil, root, nil, nil, nil, cc.p(0, -40), nil, nil, self.dir)
  if self.fashion.follow_pet_type and 0 < self.fashion.follow_pet_type then
    self:setPortrait("UserPanel", ResMgr:getFollowSprite(icon, self.fashion.follow_pet_type), 0, root, nil, nil, nil, FOLLOW_SPRITE_OFFPOS[self.dir], 0, nil, self.dir, Dialog.TAG_PORTRAIT1, true)
  end
  self:displayPlayActions("UserPanel", root)
end
function BirthDayGiftDlg:onTurnRightButton()
  if not self.dir then
    return
  end
  self.dir = self.dir - 2
  if self.dir < 0 then
    self.dir = 7
  end
  self:refreshPortraitPanel(true)
end
function BirthDayGiftDlg:onTurnLeftButton()
  if not self.dir then
    return
  end
  self.dir = self.dir + 2
  if self.dir > 7 then
    self.dir = 1
  end
  self:refreshPortraitPanel(true)
end
function BirthDayGiftDlg:onCheckBox(sender)
  local list = self:getControl("ListView")
  local items = list:getItems()
  for _, panel in pairs(items) do
    self:setCheck("CheckBox", false, panel)
  end
  self.fashion = sender:getParent().fashion
  sender:setSelectedState(true)
  self:refreshPortraitPanel()
end
function BirthDayGiftDlg:onGetButton(sender, eventType)
  if not self.fashion then
    gf:ShowSmallTips(CHS[4300358])
    return
  end
  gf:CmdToServer("CMD_BIRTHDAY_GIFT_FASION", {
    fasion_name = self.fashion.name
  })
  self:onCloseButton()
end
function BirthDayGiftDlg:onSelectListView(sender, eventType)
end
return BirthDayGiftDlg
