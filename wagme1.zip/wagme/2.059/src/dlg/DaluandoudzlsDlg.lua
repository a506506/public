local DaluandoudzlsDlg = Singleton("DaluandoudzlsDlg", Dialog)
function DaluandoudzlsDlg:init()
  self.listView = self:getControl("ListView")
  self.itemPanel = self:retainCtrl("SingleItemPanel")
  self.titlePanel = self:retainCtrl("SingleTitlePanel")
end
function DaluandoudzlsDlg:setData(data)
  self.listView:removeAllChildren()
  table.sort(data.list, function(l, r)
    if l.round > r.round then
      return true
    end
    if l.round < r.round then
      return false
    end
  end)
  for i = 1, data.count do
    local titlePanel = self.titlePanel:clone()
    self:setTitleInfo(titlePanel, data.list[i].round)
    self.listView:pushBackCustomItem(titlePanel)
    for j = 1, data.list[i].count do
      local itemPanel = self.itemPanel:clone()
      self:setItemInfo(itemPanel, data.list[i].list[j])
      if j % 2 == 0 then
        self:setCtrlVisible("BKImage1", false, itemPanel)
        self:setCtrlVisible("BKImage2", true, itemPanel)
      else
        self:setCtrlVisible("BKImage1", true, itemPanel)
        self:setCtrlVisible("BKImage2", false, itemPanel)
      end
      self.listView:pushBackCustomItem(itemPanel)
    end
  end
end
function DaluandoudzlsDlg:setTitleInfo(panel, round)
  self:setLabelText("NumLabel", string.format(CHS[7100734], round), panel)
end
function DaluandoudzlsDlg:setItemInfo(panel, info)
  local panel1 = self:getControl("NamePanel1", nil, panel)
  local panel2 = self:getControl("NamePanel2", nil, panel)
  local player1 = DlgMgr:sendMsg("DaluandouzjmDlg", "getPlayerByGid", info.attacker_gid)
  local player2 = DlgMgr:sendMsg("DaluandouzjmDlg", "getPlayerByGid", info.victim_gid)
  if info.result == 1 then
    local polar1, _ = ResMgr:getPolarAndGenerByIcon(player1.icon)
    self:setLabelText("MenpLabel", gf:getPolar(polar1), panel1)
    self:setLabelText("LvLabel", string.format(CHS[7100735], player1.level), panel1)
    self:setLabelText("NameLabel", gf:getShowName(player1.name), panel1)
    if player2 then
      local polar2, _ = ResMgr:getPolarAndGenerByIcon(player2.icon)
      self:setLabelText("MenpLabel", gf:getPolar(polar2), panel2)
      self:setLabelText("LvLabel", string.format(CHS[7100735], player2.level), panel2)
      self:setLabelText("NameLabel", gf:getShowName(player2.name), panel2)
    else
      self:setLabelText("MenpLabel", "", panel2)
      self:setLabelText("LvLabel", "", panel2)
      self:setLabelText("NameLabel", CHS[7100796], panel2)
    end
  else
    local polar2, _ = ResMgr:getPolarAndGenerByIcon(player2.icon)
    self:setLabelText("MenpLabel", gf:getPolar(polar2), panel1)
    self:setLabelText("LvLabel", string.format(CHS[7100735], player2.level), panel1)
    self:setLabelText("NameLabel", gf:getShowName(player2.name), panel1)
    if player1 then
      local polar1, _ = ResMgr:getPolarAndGenerByIcon(player1.icon)
      self:setLabelText("MenpLabel", gf:getPolar(polar1), panel2)
      self:setLabelText("LvLabel", string.format(CHS[7100735], player1.level), panel2)
      self:setLabelText("NameLabel", gf:getShowName(player1.name), panel2)
    else
      self:setLabelText("MenpLabel", "", panel2)
      self:setLabelText("LvLabel", "", panel2)
      self:setLabelText("NameLabel", CHS[7100796], panel2)
    end
  end
end
return DaluandoudzlsDlg
