local CaseSMFJBoxKeyDlg = Singleton("CaseSMFJBoxKeyDlg", Dialog)
local COLORS = {
  cc.c3b(255, 255, 255),
  cc.c3b(156, 54, 54),
  cc.c3b(75, 128, 163),
  cc.c3b(81, 143, 74)
}
function CaseSMFJBoxKeyDlg:init()
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel")
  self:bindListener("ClosePanel", self.onCloseButton)
  self.indexs = {
    3,
    2,
    1,
    4
  }
  if TanAnSMFJMgr.dungeonData then
    local list = TanAnSMFJMgr.dungeonData.box_color_list
    self:setCtrlColor("LeftUpImage", COLORS[list[1]])
    self:setCtrlColor("RightUpImage", COLORS[list[2]])
    self:setCtrlColor("RightDownImage", COLORS[list[3]])
    self:setCtrlColor("LeftDownImage", COLORS[list[4]])
  end
end
return CaseSMFJBoxKeyDlg
