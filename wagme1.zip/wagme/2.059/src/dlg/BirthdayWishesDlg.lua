local BirthdayWishesDlg = Singleton("BirthdayWishesDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
local WISH_TIPS = {
  CheckBox_1 = CHS[4300565],
  CheckBox_2 = CHS[4300566],
  CheckBox_3 = CHS[4300567]
}
local MASTER_CHECKBOS = {
  "CheckBox_1",
  "CheckBox_2",
  "CheckBox_3"
}
local LIMIT = 120
function BirthdayWishesDlg:init()
  self:bindListener("SendButton", self.onSendButton)
  self:bindListener("TemplateButton_1", self.onTemplateButton_1)
  self:bindListener("TemplateButton_2", self.onTemplateButton_2)
  self:bindListener("TemplateButton_3", self.onTemplateButton_3)
  self:bindListener("DeleteButton", self.onDeleteButton)
  self.radioGroup = RadioGroup.new()
  self.radioGroup:setItems(self, MASTER_CHECKBOS, self.onMatserCheckBox)
  self:setCtrlVisible("DeleteButton", false)
  self:setCtrlVisible("ContentrLabel", false)
  self:setColorText(CHS[4300568], self:getControl("ContentPanel"), nil, nil, nil, COLOR3.GRAY)
  self.content = ""
  self.newNameEdit = self:createEditBox("TouchPanel", nil, nil, function(sender, type)
    if type == "end" then
      if not self.newNameEdit then
        return
      end
      local newName = self.newNameEdit:getText()
      self:setColorText(newName, self:getControl("ContentPanel"))
      if newName == "" then
        self.radioGroup:unSelectedRadio()
        self:setColorText(CHS[4300568], self:getControl("ContentPanel"), nil, nil, nil, COLOR3.GRAY)
      else
        self.content = newName
        self:setCtrlVisible("DeleteButton", true)
      end
      self.newNameEdit:setText("")
    elseif type == "changed" then
      if not self.newNameEdit then
        return
      end
      local newName = self.newNameEdit:getText()
      if gf:getTextLength(newName) > LIMIT then
        newName = gf:subString(newName, LIMIT)
        self.newNameEdit:setText(newName)
        gf:ShowSmallTips(CHS[5400041])
      end
      self:setColorText(newName, self:getControl("ContentPanel"))
      if newName == "" then
        self.radioGroup:unSelectedRadio()
        self:setColorText(CHS[4300568], self:getControl("ContentPanel"), nil, nil, nil, COLOR3.GRAY)
      else
        self:setCtrlVisible("DeleteButton", true)
        self.content = newName
      end
      self.newNameEdit:setText("")
    end
  end)
  self.newNameEdit:setPlaceholderFont(CHS[3003794], 23)
  self.newNameEdit:setFont(CHS[3003794], 23)
  self.newNameEdit:setPlaceholderFontColor(cc.c3b(102, 102, 102))
end
function BirthdayWishesDlg:onMatserCheckBox(sender, eventType)
  self:setCtrlVisible("DeleteButton", true)
  self:setColorText(WISH_TIPS[sender:getName()], self:getControl("ContentPanel"))
  self.content = WISH_TIPS[sender:getName()]
end
function BirthdayWishesDlg:onSendButton(sender, eventType)
  if ChatMgr:textIsALlSpace(self.content) then
    gf:ShowSmallTips(CHS[3004013])
    return
  end
  if gf:getTextLength(self.content) < 8 then
    gf:ShowSmallTips(CHS[4300569])
    return
  end
  local nameText, haveBadName = gf:filtTextByTwo(self.content, nil, true)
  if haveBadName then
    gf:ShowSmallTips(CHS[4300876])
    self.content = nameText
    self:setColorText(nameText, self:getControl("ContentPanel"))
    return
  end
  if not gf:isSameDay(gf:getServerTime(), tonumber(self.birthTime)) then
    gf:ShowSmallTips(CHS[4300570])
    self:onCloseButton()
    return
  end
  FriendMgr:sendMsgToFriend(self.toName, self.content, self.toGid)
  gf:showTipAndMisMsg(string.format(CHS[4300571], self.toName))
  self:onCloseButton()
end
function BirthdayWishesDlg:onTemplateButton_1(sender, eventType)
end
function BirthdayWishesDlg:onTemplateButton_2(sender, eventType)
end
function BirthdayWishesDlg:onDlgOpened(list)
  self.toName = list[2]
  self.toGid = list[1]
  self.birthTime = list[3]
  self:setLabelText("InforLabel2", list[2])
end
function BirthdayWishesDlg:onDeleteButton(sender, eventType)
  self:setColorText(CHS[4300568], self:getControl("ContentPanel"), nil, nil, nil, COLOR3.GRAY)
  self:setCtrlVisible("DeleteButton", false)
  self.radioGroup:unSelectedRadio()
end
function BirthdayWishesDlg:setColorText(str, panelName, root, marginX, marginY, defColor, fontSize, locate, isPunct, isVip)
  marginX = marginX or 0
  marginY = marginY or 0
  root = root or self.root
  fontSize = fontSize or 20
  defColor = defColor or COLOR3.TEXT_DEFAULT
  local panel
  if type(panelName) == "string" then
    panel = self:getControl(panelName, Const.UIPanel, root)
  else
    panel = panelName
  end
  if not panel then
    return
  end
  panel:removeAllChildren()
  local size = panel:getContentSize()
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(fontSize)
  textCtrl:setString(str, isVip)
  textCtrl:setContentSize(size.width - 2 * marginX, 0)
  textCtrl:setDefaultColor(defColor.r, defColor.g, defColor.b)
  if textCtrl.setPunctTypesetting then
    textCtrl:setPunctTypesetting(true == isPunct)
  end
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  if locate == true or locate == LOCATE_POSITION.MID_BOTTOM then
    textCtrl:setPosition((size.width - textW) / 2, textH + marginY)
  elseif locate == LOCATE_POSITION.RIGHT_BOTTOM then
    textCtrl:setPosition(size.width - textW, textH + marginY)
  else
    textCtrl:setPosition(marginX, size.height)
  end
  local textNode = tolua.cast(textCtrl, "cc.LayerColor")
  panel:addChild(textNode, textNode:getLocalZOrder(), Dialog.TAG_COLORTEXT_CTRL)
  local panelHeight = textH + 2 * marginY
  return panelHeight, size.height
end
return BirthdayWishesDlg
