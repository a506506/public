local CommonDescDlg = require("dlg/CommonDescDlg")
local CreateCharDescDlg = Singleton("CreateCharDescDlg", CommonDescDlg)
local noLogin = false
local FONTSIZE_TITLE = 21
local FONTSIZE_TEXT2 = 19
function CreateCharDescDlg:getCfgFileName()
  return ResMgr:getDlgCfg("LoginNewDistActiveDlg")
end
function CreateCharDescDlg:init()
  self.listView = self:getControl("UpdateListView")
  DlgMgr:setVisible("UserLoginDlg", false)
  self:setCtrlVisible("ActiveListView", false)
  self:setLabelText("TitleLabel_1", CHS[4400010])
  self:setLabelText("TitleLabel_2", CHS[4400010])
  self:setCtrlVisible("SwitchPanel_0", false)
  if self.blank.colorLayer then
    self.blank:removeChild(self.blank.colorLayer)
  end
end
function CreateCharDescDlg:onCloseButton()
  if not DlgMgr:isDlgOpened("LoginChangeDistDlg") then
    DlgMgr:setVisible("UserLoginDlg", true)
  else
    DlgMgr:setVisible("LoginChangeDistDlg", true)
  end
  DlgMgr:closeDlg("WaitDlg")
  DlgMgr:closeDlg("CreateCharDlg")
  DlgMgr:closeDlg(self.name)
end
function CommonDescDlg:getListView()
  return "UpdateListView"
end
function CreateCharDescDlg:getControl(name, type, root)
  root = root or self.root
  local widget = ccui.Helper:seekWidgetByName(root, name)
  return widget
end
function CreateCharDescDlg:bindListener(name, func, root)
  if nil == func then
    Log:W("Dialog:bindListener no function.")
    return
  end
  local widget = self:getControl(name, nil, root)
  if nil == widget then
    if name ~= "CloseButton" then
      Log:W("Dialog:bindListener no control " .. name)
    end
    return
  end
  self:bindTouchEndEventListener(widget, func)
end
function CreateCharDescDlg:bindTouchEndEventListener(ctrl, func, data)
  if not ctrl then
    Log:W("Dialog:bindTouchEndEventListener no control ")
    return
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
      func(self, sender, eventType, data)
    end
  end
  ctrl:addTouchEventListener(listener)
end
function CreateCharDescDlg:setNoLogin(flag)
  noLogin = flag
end
function CreateCharDescDlg:cleanup()
  noLogin = false
end
return CreateCharDescDlg
