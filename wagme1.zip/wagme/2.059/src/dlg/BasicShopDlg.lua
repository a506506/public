local BasicShopDlg = Singleton("BasicShopDlg", Dialog)
local shopLimit = 100
local mTips = {}
function BasicShopDlg:getCfgFileName()
  return ResMgr:getDlgCfg("PartyShopDlg")
end
function BasicShopDlg:init()
  self:bindListener("BuyButton", self.onBuyButton)
  self:bindPressForIntervalCallback("ReduceButton", 0.1, self.onSubOrAddNum, "times")
  self:bindPressForIntervalCallback("AddButton", 0.1, self.onSubOrAddNum, "times")
  self:bindNumInput("NumberValuePanel", nil, self.onlimitNumInput)
  self.pickGoods = nil
  self.goods = nil
  local goodsPanel = self:getControl("GoodsPanel", Const.UIPanel)
  local goodsPanel1 = self:getControl("GoodsPanel1", Const.UIPanel, goodsPanel)
  local goodsPanel2 = self:getControl("GoodsPanel2", Const.UIPanel, goodsPanel)
  self:setCtrlVisible("ChosenImage", false, goodsPanel1)
  self:setCtrlVisible("ChosenImage", false, goodsPanel2)
  self:setCtrlVisible("SoldoutImage", false, goodsPanel1)
  self:setCtrlVisible("SoldoutImage", false, goodsPanel2)
  self.goodsPanel = goodsPanel:clone()
  self.goodsPanel:retain()
  self:getControl("GoodsPanel"):removeFromParent()
  self:setCtrlVisible("EmptyPanel", true)
  self:setCtrlVisible("ItemInfoPanel", false)
  self:setHavePanel()
  self:setCost()
  self:setTips(mTips)
  self:hookMsgs()
  self.shopLimit = shopLimit
end
function BasicShopDlg:cleanup()
  self:releaseCloneCtrl("goodsPanel")
  self.goodsPanel = nil
  self.pickGoods = nil
  self.goods = nil
end
function BasicShopDlg:hookMsgs()
end
function BasicShopDlg:getOwnNum()
  return 0
end
function BasicShopDlg:setShopLimit(shopLimit)
end
function BasicShopDlg:getShopLimit()
  return InventoryMgr:isCanAddToBag(self.goods[self.pickGoods].name, shopLimit, nil, self.goods[self.pickGoods].bind == 1)
end
function BasicShopDlg:setTips()
  mTips.minNumTip = CHS[4000206]
  mTips.maxNumTip1 = CHS[3003270]
  mTips.maxNumTip2 = CHS[6000150]
  mTips.maxNumTip3 = CHS[6000035]
  mTips.costTip = CHS[4200407]
end
function BasicShopDlg:onReduceButton(sender, eventType)
  if not self.pickGoods then
    gf:ShowSmallTips(CHS[3003269])
    return
  end
  local countPanel = self:getControl("BuyNumberPanel")
  local num = tonumber(self:getLabelText("NumberValueLabel", countPanel))
  if num - 1 < 1 then
    gf:ShowSmallTips(mTips.minNumTip)
    return
  end
  self:setLabelText("NumberValueLabel", num - 1, countPanel)
  self:refreshTotalValuePanel(self.goods[self.pickGoods].cost * (num - 1))
  return true
end
function BasicShopDlg:onAddButton(sender, eventType)
  if not self.pickGoods then
    gf:ShowSmallTips(CHS[3003269])
    return
  end
  local countPanel = self:getControl("BuyNumberPanel")
  local num = tonumber(self:getLabelText("NumberValueLabel", countPanel))
  if num + 1 > self.shopLimit then
    if self.shopLimit == shopLimit then
      gf:ShowSmallTips(mTips.maxNumTip3)
    else
      gf:ShowSmallTips(mTips.maxNumTip2)
    end
    return
  end
  if num + 1 > self.goods[self.pickGoods].num then
    gf:ShowSmallTips(mTips.maxNumTip1)
    return
  end
  if (num + 1) * self.goods[self.pickGoods].cost > self:getOwnNum() then
    gf:ShowSmallTips(mTips.costTip)
    return
  end
  self:setLabelText("NumberValueLabel", num + 1, countPanel)
  self:refreshTotalValuePanel(self.goods[self.pickGoods].cost * (num + 1))
  return true
end
function BasicShopDlg:refreshTotalValuePanel(totalValue)
  local pricePanel = self:getControl("TotalValuePanel")
  local costStr = gf:getMoneyDesc(totalValue, true)
  if totalValue > self:getOwnNum() then
    self:setLabelText("TotalValueLabel_1", costStr, pricePanel, COLOR3.RED)
    self:setLabelText("TotalValueLabel_2", costStr, pricePanel)
  else
    self:setLabelText("TotalValueLabel_1", costStr, pricePanel, COLOR3.WHITE)
    self:setLabelText("TotalValueLabel_2", costStr, pricePanel)
  end
end
function BasicShopDlg:onSubOrAddNum(ctrlName, times)
  if times == 1 then
    self.needShowSubOrAddTips = true
  end
  if self.needShowSubOrAddTips then
    local flag = false
    if ctrlName == "AddButton" then
      flag = self:onAddButton()
    elseif ctrlName == "ReduceButton" then
      flag = self:onReduceButton()
    end
    if not flag then
      self.needShowSubOrAddTips = nil
    end
  end
end
function BasicShopDlg:onBuyButton(sender, eventType)
end
function BasicShopDlg:setStore()
  local storeGoodsPanel = self:resetListView("PharmacyListView")
  storeGoodsPanel:setItemsMargin(8)
  local count = 1
  if self.goods.count % 2 == 0 then
    count = self.goods.count / 2
  else
    count = math.floor(self.goods.count / 2) + 1
  end
  local i = 1
  while i <= self.goods.count do
    local goodsPanel = self.goodsPanel:clone()
    local goodsPanel1 = self:getControl("GoodsPanel1", nil, goodsPanel)
    self:setGoods(i, goodsPanel1)
    goodsPanel1:setTag(i)
    self:bindTouchEndEventListener(goodsPanel1, self.chooseGoods)
    i = i + 1
    local goodsPanel2 = self:getControl("GoodsPanel2", nil, goodsPanel)
    if i <= self.goods.count then
      self:setGoods(i, goodsPanel2)
      goodsPanel2:setTag(i)
      self:bindTouchEndEventListener(goodsPanel2, self.chooseGoods)
      i = i + 1
    else
      goodsPanel2:setVisible(false)
    end
    storeGoodsPanel:pushBackCustomItem(goodsPanel)
  end
  local defaultItems = storeGoodsPanel:getItems(0)
  local defaultGoodsPanel = self:getControl("GoodsPanel1", nil, defaultItems)
  self:chooseGoods(defaultGoodsPanel)
end
function BasicShopDlg:setStoreItemsNum()
  local storeGoodsPanel = self:getControl("PharmacyListView")
  local itemsPanel = storeGoodsPanel:getItems()
  for i, goodsPanel in pairs(itemsPanel) do
    local goodsPanel1 = self:getControl("GoodsPanel1", nil, goodsPanel)
    local goodsPanel2 = self:getControl("GoodsPanel2", nil, goodsPanel)
    self:setGoods(i * 2 - 1, goodsPanel1)
    self:setGoods(i * 2, goodsPanel2)
  end
  self:setCost()
end
function BasicShopDlg:chooseGoods(sender, eventType)
  self:setCtrlVisible("EmptyPanel", false)
  self:setCtrlVisible("ItemInfoPanel", true)
  local chosen = self:getControl("ChosenImage", nil, sender)
  local isChosen = chosen:isVisible()
  if isChosen then
    self:onAddButton()
    return
  end
  local storeGoodsPanel = self:getControl("PharmacyListView")
  local itemsPanel = storeGoodsPanel:getItems()
  for _, goodsPanel in pairs(itemsPanel) do
    local goodsPanel1 = self:getControl("GoodsPanel1", nil, goodsPanel)
    local goodsPanel2 = self:getControl("GoodsPanel2", nil, goodsPanel)
    self:setCtrlVisible("ChosenImage", false, goodsPanel1)
    self:setCtrlVisible("ChosenImage", false, goodsPanel2)
  end
  self:setCtrlVisible("ChosenImage", true, sender)
  self.pickGoods = sender:getTag()
  self:setGoodsInfo()
  self:setCost(true)
  self.shopLimit = self:getShopLimit()
end
function BasicShopDlg:setGoods(index, panel)
  if not self.goods[index] then
    return
  end
  local goodImagePanel = self:getControl("GoodsImagePanel", Const.UIPanel, panel)
  local goodImage = ccui.ImageView:create(ResMgr:getItemIconPath(InventoryMgr:getIconByName(self.goods[index].name)))
  goodImage:setPosition(goodImagePanel:getContentSize().width / 2, goodImagePanel:getContentSize().height / 2)
  goodImage:setAnchorPoint(0.5, 0.5)
  gf:setItemImageSize(goodImage)
  goodImagePanel:removeAllChildren()
  goodImagePanel:addChild(goodImage)
  self:setLabelText("NumLabel", self.goods[index].num, panel)
  self:setLabelText("GoodsNameLabel", self.goods[index].name, panel)
  local str = gf:getMoneyDesc(self.goods[index].cost, true)
  self:setLabelText("GoodsValueLabel", str, panel)
  if self.goods[index].bind == 1 then
    InventoryMgr:addLogoBinding(goodImage)
  else
    InventoryMgr:removeLogoBinding(goodImage)
  end
  if self.goods[index].num == 2147483647 then
    self:setLabelText("LimitNumLabel", "", panel)
    self:setCtrlVisible("SoldoutImage", false, panel)
  elseif self.goods[index].num == 0 then
    self:setLabelText("LimitNumLabel", CHS[3003274] .. self.goods[index].num, panel, COLOR3.RED)
    self:setCtrlVisible("SoldoutImage", true, panel)
    gf:grayImageView(goodImage)
  else
    self:setLabelText("LimitNumLabel", CHS[3003274] .. self.goods[index].num, panel)
    self:setCtrlVisible("SoldoutImage", false, panel)
    gf:resetImageView(goodImage)
  end
end
function BasicShopDlg:setGoodsInfo()
  if not self.pickGoods then
    return
  end
  local introPanel = self:getControl("GoodsAttribInfoPanel")
  self:setLabelText("GoodsNameLabel", self.goods[self.pickGoods].name, introPanel)
  local desc = InventoryMgr:getDescript(self.goods[self.pickGoods].name)
  local scorllView = self:getControl("ScrollView")
  local sz = scorllView:getContentSize()
  local itemUseLevel = InventoryMgr:getItemInfoByNameAndField(self.goods[self.pickGoods].name, "use_level")
  local useLevelStr = CHS[5420013] .. CHS[5420012]
  if itemUseLevel then
    useLevelStr = CHS[5420013] .. string.format(CHS[5420011], itemUseLevel)
  end
  local allDesc = {}
  table.insert(allDesc, desc)
  table.insert(allDesc, useLevelStr)
  self:setColorText(table.concat(allDesc, "\n"), "ItemDescPanel")
  self:updateLayout("ItemInfoPanel")
  local itemDescPanel = self:getControl("ItemDescPanel", nil, "ScrollView")
  local itemDescSz = itemDescPanel:getContentSize()
  scorllView:setInnerContainerSize(cc.size(sz.width, itemDescSz.height))
  itemDescPanel:setPositionY(0)
  scorllView:getInnerContainer():setPositionY(sz.height - itemDescSz.height)
  scorllView:setTouchEnabled(sz.height < itemDescSz.height)
end
function BasicShopDlg:onDlgOpened(itemName)
  local listView = self:getControl("PharmacyListView")
  local items = listView:getItems()
  for i = 1, #items do
    local goodsPanel1 = self:getControl("GoodsPanel1", nil, items[i])
    local goodsPanel2 = self:getControl("GoodsPanel2", nil, items[i])
    if self.goods[goodsPanel1:getTag()] and self.goods[goodsPanel1:getTag()].name == itemName then
      self:chooseGoods(goodsPanel1)
      return
    end
    if self.goods[goodsPanel2:getTag()] and self.goods[goodsPanel2:getTag()].name == itemName then
      self:chooseGoods(goodsPanel2)
      return
    end
  end
end
function BasicShopDlg:setCost(isChosingDifferentGood)
  local countPanel = self:getControl("BuyNumberPanel")
  local pricePanel = self:getControl("TotalValuePanel")
  if not self.pickGoods then
    self:setLabelText("NumberValueLabel", "0", countPanel)
    self:refreshTotalValuePanel(0)
    return
  end
  local num = tonumber(self:getLabelText("NumberValueLabel", countPanel))
  if not num or num < 1 or isChosingDifferentGood then
    num = 1
  end
  if num > self.goods[self.pickGoods].num then
    num = self.goods[self.pickGoods].num
  end
  self:setLabelText("NumberValueLabel", num, countPanel)
  self:refreshTotalValuePanel(self.goods[self.pickGoods].cost * num)
end
function BasicShopDlg:setHavePanel()
  local ownPanel = self:getControl("HavePanel")
  local haveText = gf:getArtFontMoneyDesc(self:getOwnNum())
  self:setNumImgForPanel("HaveTextPanel", ART_FONT_COLOR.DEFAULT, haveText, haveText, LOCATE_POSITION.MID, 23, ownPanel)
end
function BasicShopDlg:onlimitNumInput(ctrlName)
  if not self.pickGoods then
    gf:ShowSmallTips(CHS[3003275])
    return true
  end
end
function BasicShopDlg:insertNumber(num)
  local countPanel = self:getControl("BuyNumberPanel")
  local shopNum = tonumber(self:getLabelText("NumberValueLabel", countPanel))
  shopNum = num
  if shopNum < 0 then
    shopNum = 0
  end
  local limit = math.min(self.shopLimit, self.goods[self.pickGoods].num)
  if num > limit then
    if self.shopLimit > self.goods[self.pickGoods].num then
      gf:ShowSmallTips(mTips.maxNumTip1)
    elseif self.shopLimit == shopLimit then
      gf:ShowSmallTips(mTips.maxNumTip3)
    else
      gf:ShowSmallTips(mTips.maxNumTip2)
    end
    shopNum = math.max(math.min(limit, math.floor(self:getOwnNum() / self.goods[self.pickGoods].cost)), 0)
  elseif num * self.goods[self.pickGoods].cost > self:getOwnNum() then
    gf:ShowSmallTips(mTips.costTip)
    shopNum = math.floor(self:getOwnNum() / self.goods[self.pickGoods].cost)
  end
  self:setLabelText("NumberValueLabel", shopNum, countPanel)
  self:refreshTotalValuePanel(self.goods[self.pickGoods].cost * shopNum)
  DlgMgr:sendMsg("SmallNumInputDlg", "setInputValue", shopNum)
end
return BasicShopDlg
