local BaozqyDlg = Singleton("BaozqyDlg", Dialog)
local PartMap = require("obj/PartMap")
local NumImg = require("ctrl/NumImg")
local BASIC_CFG = require("cfg/BaozqyCfg")
local CharAction = require("animate/CharAction")
local CharActionBegin = require("animate/CharActionBegin")
local CharActionEnd = require("animate/CharActionEnd")
local Progress = require("ctrl/Progress")
local BOOM_START_POS = BASIC_CFG.boomStartPos
local ROUND_TIME_LIMIT = BASIC_CFG.roundTimeLimit
local MONSTER_CFG = BASIC_CFG.monster
local ROUND_CFG = BASIC_CFG.round
local BOOM_START_POS = BASIC_CFG.boomStartPos
local BOOM_DEMAGE_CFG = BASIC_CFG.boomDemage
local ruleEffectFlag
local MAP_SIZE = cc.size(960, 640)
local MAP_CENTER_POS = cc.p(1068, 506)
local LEFT_LINE_MARGIN = 5
local AIM_MOVE_TIME = 2
local MAX_ROUND = 30
local FLY_SPEED = 450
local MAX_BOOM_BUM = 20
local MAX_TICK_BUM = 99
local FIRE_LIMIT_TIME = 500
local RANK_INDEX_IMG = {
  ResMgr.ui.rank_index_img1,
  ResMgr.ui.rank_index_img2,
  ResMgr.ui.rank_index_img3
}
function BaozqyDlg:init()
  self:setFullScreen()
  self:setCtrlFullScreen("MainPanel")
  self:setCtrlFullClient("ReadyPanel")
  self:setCtrlFullClient("BlackPanel", "ReadyPanel")
  self:setCtrlFullClient("StarPanel")
  self:bindListener("Button", self.onStartButton, "PlayPanel")
  self:bindListener("Button", self.onCloseButton, self:getControl("ClosePanel", nil, "TopPanel"))
  self:bindListener("Button", self.onTipsButton, self:getControl("InfoPanel", nil, "TopPanel"))
  self:bindListener("Button", self.onFireButton, "FirePanel", true)
  self.listSelectEffect = self:retainCtrl("ChosenEffectImage", "ReadyPanel")
  self.listPanel1 = self:retainCtrl("RankingPanel01", "ReadyPanel")
  self.listPanel2 = self:retainCtrl("RankingPanel02", "ReadyPanel")
  self.monsterPanel = self:getControl("MonsterPanel", nil, "PlayerPanel")
  self.aimPanel = self:getControl("AimPanel", nil, "MainPanel")
  self.aimPanel:setVisible(false)
  self.aimPanelSz = self.aimPanel:getContentSize()
  self.aimPanelStartX = self:getControl("LinePanel1", nil, "MainPanel"):getPositionX()
  self:setCtrlVisible("ReadyPanel", true)
  self:setCtrlVisible("MainPanel", false)
  self:getControl("ReadyPanel"):getChildByName("PlayPanel"):getChildByName("TextPanel"):setTouchEnabled(false)
  self.monsterList = {}
  if not ruleEffectFlag then
    ruleEffectFlag = true
    DlgMgr:openDlg("BaozqyRuleDlg")
  end
  self:createMap()
  self:initFireButtonStatus()
  self:hookMsg("MSG_CHAR_INFO")
  self:hookMsg("MSG_CHAR_INFO_EX")
  self:hookMsg("MSG_OFFLINE_CHAR_INFO")
  self:hookMsg("MSG_SPRING_2020_BZQY_START")
  self:createShareButton(self:getControl("ShareButton", nil, "MyselfPanel"), SHARE_FLAG.BZQYRANK)
  EventDispatcher:addEventListener("ENTER_BACKGROUND", self.onEnterBackground, self)
end
function BaozqyDlg:setData(data)
  self.dlgData = data
  local root = self:getControl("ReadyPanel")
  local infoPanel = self:getControl("InfoPanel", nil, root)
  if data.left_times > 0 then
    self:setLabelText("NowLabel", data.left_times, infoPanel, COLOR3.WHITE)
  else
    self:setLabelText("NowLabel", data.left_times, infoPanel, COLOR3.RED)
  end
  self:setLabelText("MaxLabel", data.max_times, infoPanel)
  local myRankPanel = self:getControl("MyselfPanel", nil, root)
  local rankText = data.rank
  if 0 >= data.rank then
    rankText = CHS[7120386]
  end
  self:setLabelText("NumLabel", rankText, myRankPanel)
  self:setLabelText("NameLabel", Me:getShowName(), myRankPanel)
  self:setLabelText("ResultLabel", data.score, myRankPanel)
  local partName = Me:queryBasic("party/name")
  if string.isNilOrEmpty(partName) then
    partName = CHS[7100146]
  end
  self:setLabelText("PartyLabel", partName, myRankPanel)
  local listView = self:getControl("ListView", nil, root)
  listView:removeAllItems()
  listView:setLocalZOrder(10)
  for i = 1, data.count do
    local itemPanel
    if i % 2 == 1 then
      itemPanel = self.listPanel1:clone()
    else
      itemPanel = self.listPanel2:clone()
    end
    if RANK_INDEX_IMG[i] then
      itemPanel:getChildByName("NumImagePanel"):setBackGroundImage(RANK_INDEX_IMG[i])
    end
    itemPanel:setTouchEnabled(true)
    self:setSingleItemPanel(itemPanel, data.list[i])
    listView:pushBackCustomItem(itemPanel)
  end
end
function BaozqyDlg:setSingleItemPanel(panel, info)
  self:setLabelText("NumLabel", info.rank, panel)
  self:setLabelText("NameLabel", info.name, panel)
  self:setLabelText("ResultLabel", info.score, panel)
  local partyName = info.party_name
  if string.isNilOrEmpty(info.party_name) then
    partyName = CHS[7100146]
  end
  self:setLabelText("PartyLabel", partyName, panel)
  panel.gid = info.gid
  panel:addTouchEventListener(function(sender, eventType)
    if eventType == ccui.TouchEventType.ended then
      local charMenuDlg = DlgMgr:getDlgByName("CharMenuContentDlg")
      if charMenuDlg and charMenuDlg.gid == sender.gid then
        return
      end
      if self.listSelectEffect:getParent() then
        self.listSelectEffect:removeFromParent()
      end
      sender:addChild(self.listSelectEffect)
    end
  end)
end
function BaozqyDlg:createMap()
  local mapPanel = self:getControl("MapPanel")
  mapPanel:removeAllChildren()
  local partMap = PartMap.new(19002, MAP_CENTER_POS.x, MAP_CENTER_POS.y, MAP_SIZE, true)
  local mapSize = partMap:getContentSize()
  local mapCurX, mapCurY = partMap:getCurPosition()
  mapCurY = mapSize.height - mapCurY - MAP_SIZE.height
  partMap:setAnchorPoint(0, 0)
  partMap:setPosition(-mapCurX, -mapCurY)
  mapPanel:addChild(partMap)
  self.partMap = partMap
end
function BaozqyDlg:onUpdate()
  if self.pauseGame then
    return
  end
  if not self.round or not self.curRoundStartTick then
    return
  end
  local curTick = gfGetTickCount()
  local monsterCount = #self.monsterList
  local roundTimeMin, roundTimeMax = self:getCurRoundTimeLimitInfo()
  if (monsterCount <= 0 and roundTimeMin < curTick - self.curRoundStartTick or roundTimeMax < curTick - self.curRoundStartTick) and self.round < MAX_ROUND then
    self.round = self.round + 1
    self:refreshRoundNum()
    self:startRefreshMonster(self.round)
  end
  if monsterCount <= 0 then
    return
  end
  local filtMonsterList = {}
  for i = 1, monsterCount do
    local positionX = self.monsterList[i]:getPositionX()
    local monsterSz = self.monsterList[i]:getContentSize()
    local monsetrAn = self.monsterList[i]:getAnchorPoint()
    if positionX < 10 then
      self:removeMonster(self.monsterList[i])
    else
      table.insert(filtMonsterList, self.monsterList[i])
    end
  end
  self.monsterList = filtMonsterList
  monsterCount = #self.monsterList
  for i = 1, monsterCount do
    local positionX = self.monsterList[i]:getPositionX()
    positionX = positionX - math.floor(self.monsterList[i].monsterCfg.speed / 33)
    self.monsterList[i]:setPositionX(positionX)
  end
end
function BaozqyDlg:updateMonsterLife(boomX)
  local function doMonsterAttacked(monster, type)
    local minusLife = BOOM_DEMAGE_CFG[type].demage
    if not monster.monsterCfg.minusLife then
      monster.monsterCfg.minusLife = minusLife
    else
      monster.monsterCfg.minusLife = monster.monsterCfg.minusLife + minusLife
    end
    if monster.monsterCfg.minusLife >= monster.monsterCfg.life then
      self:playerMonsterDied(monster, "begin")
    else
      self:playerMonsterDefence(monster, "begin")
    end
  end
  local newMonsterList = {}
  for i = 1, #self.monsterList do
    local monster = self.monsterList[i]
    local positionX = monster:getPositionX()
    local boomDistance = math.abs(boomX - positionX)
    if boomDistance <= BOOM_DEMAGE_CFG[1].radius then
      doMonsterAttacked(monster, 1)
    elseif boomDistance <= BOOM_DEMAGE_CFG[2].radius then
      doMonsterAttacked(monster, 2)
    else
      table.insert(newMonsterList, self.monsterList[i])
    end
  end
  self.monsterList = newMonsterList
end
function BaozqyDlg:playUpdateScore(cfg, x, y, notDie)
  local score = cfg.score1 + cfg.round * cfg.score2
  if notDie then
    score = math.floor(score * 0.1)
  end
  local artFontColor = ART_FONT_COLOR.YELLOW
  if score < 0 then
    artFontColor = ART_FONT_COLOR.RED
  end
  local numImge = NumImg.new(artFontColor, score, true)
  numImge:setScale(1.5)
  numImge:setPosition(x, y)
  self.monsterPanel:addChild(numImge)
  numImge:startMove(1, cc.p(x, y + 50))
  self.score = math.max(0, self.score + score)
  self:refreshScore()
  if 0 < cfg.reward then
    self.boomNum = self.boomNum + cfg.reward
    self.boomNum = math.min(self.boomNum, MAX_BOOM_BUM)
    self:refreshBoomNum()
  end
end
function BaozqyDlg:checkEndGame()
  local function endGame()
    local roundInfo = gfEncrypt(tostring(self.round), self.game_id)
    local scoreInfo = gfEncrypt(tostring(self.score), self.game_id)
    gf:CmdToServer("CMD_SPRING_2020_BZQY_FINISH", {stage = roundInfo, score = scoreInfo})
    self.round = nil
    self:stopGame()
  end
  local playerPanel = self:getControl("PlayerPanel")
  local notBoom = true
  if self.boomNum > 0 or playerPanel:getChildByName("FlyMagic") or playerPanel:getChildByName("BoomMagic") then
    notBoom = false
  end
  if notBoom or 0 >= self.leftTime or self.round >= MAX_ROUND and 0 >= #self.monsterList then
    endGame()
  end
end
function BaozqyDlg:getCurRoundTimeLimitInfo()
  local index = 3
  if self.round <= 10 then
    index = 1
  elseif self.round <= 20 then
    index = 2
  end
  return ROUND_TIME_LIMIT[index].min * 1000, ROUND_TIME_LIMIT[index].max * 1000
end
function BaozqyDlg:startGame()
  self:setLeftTimeTick()
  self.monsterPanel:removeAllChildren()
  self:startRefreshMonster(self.round)
end
function BaozqyDlg:startRefreshMonster(round)
  if round > MAX_ROUND then
    return
  end
  if round < self.round then
    return
  end
  local startIndex = (round - 1) * 5 + 1
  local endIndex = round * 5
  for i = startIndex, endIndex do
    local roundMonsterCfg = ROUND_CFG[i]
    local monsterCfg = gf:deepCopy(MONSTER_CFG[roundMonsterCfg.key])
    self:createMonster(roundMonsterCfg, monsterCfg, round)
  end
  self.curRoundStartTick = gfGetTickCount()
end
function BaozqyDlg:createMonster(roundCfg, monsterCfg, round)
  local sz = self.monsterPanel:getContentSize()
  local monster = CharAction.new()
  monster:set(monsterCfg.icon, nil, Const.SA_WALK, 7)
  monster:setPosition(sz.width + 20, roundCfg.y - 180)
  monster:setVisible(false)
  monster.monsterCfg = monsterCfg
  monster.monsterCfg.round = round
  self.monsterPanel:addChild(monster)
  local monsterSz = monster:getContentSize()
  local monsetrAn = monster:getAnchorPoint()
  self:addMonsterShadow(monster)
  self:addMonsterLifeProgress(monster)
  performWithDelay(self.root, function()
    monster:setVisible(true)
    local magic = gf:createSelfRemoveMagic(ResMgr.magic.xiulmz_grey_fog)
    magic:setPosition(monsterSz.width * monsetrAn.x, monsterSz.height * monsetrAn.y)
    monster:addChild(magic)
    table.insert(self.monsterList, monster)
  end, roundCfg.timeDelay)
end
function BaozqyDlg:addMonsterShadow(monster)
  if monster.shadow then
    return
  end
  local monsterSz = monster:getContentSize()
  local monsetrAn = monster:getAnchorPoint()
  local shadow = cc.Sprite:create(ResMgr.ui.char_shadow_img)
  shadow:setPosition(monsterSz.width * monsetrAn.x, monsterSz.height * monsetrAn.y)
  monster:addChild(shadow, -1)
  monster.shadow = shadow
end
function BaozqyDlg:addMonsterLifeProgress(monster)
  if monster.lifeProgress then
    return
  end
  local monsterSz = monster:getContentSize()
  local monsetrAn = monster:getAnchorPoint()
  local headX, headY = monster:getHeadOffset()
  local lifeProgress = Progress.new(ResMgr.ui.fight_progress_back, ResMgr.ui.fight_progress_life)
  lifeProgress:setPosition(monsterSz.width * monsetrAn.x, monsterSz.height * monsetrAn.y + headY)
  monster:addChild(lifeProgress)
  monster.lifeProgress = lifeProgress
  if not monster.monsterCfg.minusLife then
    monster.monsterCfg.minusLife = 0
  end
  monster.monsterCfg.minusLife = math.min(monster.monsterCfg.minusLife, monster.monsterCfg.life)
  local percent = math.floor((monster.monsterCfg.life - monster.monsterCfg.minusLife) * 100 / monster.monsterCfg.life)
  monster.lifeProgress:setPercent(percent)
  monster.lifeProgress:setVisible(percent > 0 and percent < 100)
end
function BaozqyDlg:playerMonsterDefence(monster, type)
  local parent = monster:getParent()
  local posX, posY = monster:getPosition()
  local monsterCfg = monster.monsterCfg
  local headX, headY = monster:getHeadOffset()
  local newMonster
  if type == "begin" then
    newMonster = CharActionBegin.new()
    newMonster:set(monsterCfg.icon, nil, Const.SA_DEFENSE, 7, nil, function()
      performWithDelay(newMonster, function()
        self:playerMonsterDefence(newMonster, "end")
      end, 0)
    end)
  elseif type == "end" then
    newMonster = CharActionEnd.new()
    newMonster:set(monsterCfg.icon, nil, Const.SA_DEFENSE, 7, nil, function()
      performWithDelay(newMonster, function()
        self:playerMonsterDefence(newMonster)
        self:playUpdateScore(monsterCfg, posX, posY + headY, true)
      end, 0.1)
    end)
  else
    newMonster = CharAction.new()
    newMonster:set(monsterCfg.icon, nil, Const.SA_WALK, 7)
    self:addMonsterShadow(newMonster)
    table.insert(self.monsterList, newMonster)
  end
  monster:removeFromParent()
  newMonster.monsterCfg = monsterCfg
  newMonster:setPosition(posX, posY)
  parent:addChild(newMonster)
  self:addMonsterShadow(newMonster)
  self:addMonsterLifeProgress(newMonster)
end
function BaozqyDlg:playerMonsterDied(monster, type)
  local parent = monster:getParent()
  local posX, posY = monster:getPosition()
  local monsterCfg = monster.monsterCfg
  local headX, headY = monster:getHeadOffset()
  local newMonster
  if type == "begin" then
    newMonster = CharActionBegin.new()
    newMonster:set(monsterCfg.icon, nil, Const.FA_DIE_NOW, 7, nil, function()
      performWithDelay(newMonster, function()
        self:playerMonsterDied(newMonster, "end")
      end, 0)
    end)
  else
    newMonster = CharActionEnd.new()
    newMonster:set(monsterCfg.icon, nil, Const.FA_DIE_NOW, 7, nil, function()
      performWithDelay(newMonster, function()
        newMonster:removeFromParent()
        local headX, headY = newMonster:getHeadOffset()
        self:playUpdateScore(monsterCfg, posX, posY + headY)
      end, 0.1)
    end)
  end
  monster:removeFromParent()
  newMonster.monsterCfg = monsterCfg
  newMonster:setPosition(posX, posY)
  parent:addChild(newMonster)
end
function BaozqyDlg:removeMonster(monster)
  monster:removeFromParent()
end
function BaozqyDlg:startAimEffect()
  self.aimPanel:setVisible(true)
  self.aimPanel:setPositionX(self.aimPanelStartX)
  local targetX = self.aimPanel:getParent():getContentSize().width - self.aimPanelSz.width
  local moveTo = cc.MoveTo:create(AIM_MOVE_TIME, cc.p(targetX, 0))
  local callFunc = cc.CallFunc:create(function()
    self:releaseBoom()
  end)
  self.aimPanel:stopAllActions()
  self.aimPanel:runAction(cc.Sequence:create(moveTo, callFunc))
end
function BaozqyDlg:releaseBoom()
  if not self.canReleaseBoom then
    return
  end
  self.aimPanel:stopAllActions()
  local endX = self.aimPanel:getPositionX() + self.aimPanelSz.width / 2
  local endY = self.aimPanelSz.height / 2
  self:createPlayer("throwEnd", function()
    self:createPlayer()
    self.aimPanel:setVisible(false)
  end)
  self.canReleaseBoom = nil
  self:setBoomFly(endX, endY)
  self.boomNum = self.boomNum - 1
  self:refreshBoomNum()
  self.lastFireTime = gfGetTickCount()
end
function BaozqyDlg:setBoomFly(tarX, tarY)
  local pos = BOOM_START_POS[Me:queryBasicInt("gender")]
  local root = self:getControl("PlayerPanel", nil, "MainPanel")
  local flyMagic = gf:createLoopMagic(ResMgr.magic.fire_cracker_fly)
  flyMagic:setPosition(pos)
  flyMagic:setName("FlyMagic")
  root:addChild(flyMagic)
  local function playEndBoomEffect()
    local boomMagic = gf:createCallbackMagic(ResMgr.magic.fire_cracker_boom, function(magic)
      magic:removeFromParent()
      magic = nil
    end)
    boomMagic:setPosition(cc.p(tarX, tarY))
    boomMagic:setName("BoomMagic")
    root:addChild(boomMagic)
    self:updateMonsterLife(tarX - self.aimPanelStartX)
    self:checkEndGame()
  end
  local jumpHeight = tarX / 3
  local jumpTo = cc.JumpTo:create(tarX / FLY_SPEED, cc.p(tarX, tarY), jumpHeight, 1)
  local callFunc = cc.CallFunc:create(function()
    flyMagic:removeFromParent()
    flyMagic = nil
    playEndBoomEffect()
  end)
  flyMagic:runAction(cc.Sequence:create(jumpTo, callFunc))
end
function BaozqyDlg:setLeftTimeTick()
  if self.titileTickSchedule then
    self:stopSchedule(self.titileTickSchedule)
  end
  local tickAtlas = self:getControl("TimeTextAtlas", nil, "MainPanel")
  self.titileTickSchedule = self:startSchedule(function()
    if self.pauseGame then
      return
    end
    if self.leftTime <= 0 then
      self:addCountDownEffect(true)
      tickAtlas:stopAllActions()
      self:checkEndGame()
      return
    end
    self:checkEndGame()
    self.leftTime = self.leftTime - 1
    tickAtlas:setString(self.leftTime)
    if self.leftTime <= 10 then
      tickAtlas:setColor(COLOR3.RED)
      self:addCountDownEffect()
    end
  end, 1)
end
function BaozqyDlg:addCountDownEffect(remove)
  local titlePanel = self:getControl("TitlePanel", nil, "MainPanel")
  if remove then
    if titlePanel:getChildByName("CountDownEffect") then
      titlePanel:removeChildByName("CountDownEffect")
    end
    return
  end
  if titlePanel:getChildByName("CountDownEffect") then
    return
  end
  local magic = gf:createSelfRemoveMagic(ResMgr.magic.daluandou_count_down, {blendMode = "add"})
  local sz = titlePanel:getContentSize()
  magic:setPosition(sz.width / 2, sz.height)
  magic:setName("CountDownEffect")
  titlePanel:addChild(magic)
end
function BaozqyDlg:createPlayer(type, callBack)
  local root = self:getControl("ShapePanel", nil, "MainPanel")
  local sz = root:getContentSize()
  local icon = 21009
  if Me:queryBasicInt("gender") == 2 then
    icon = 21010
  end
  if self.player then
    self.player:removeFromParent()
    self.player = nil
  end
  if type == "throwBegin" then
    self.player = CharActionBegin.new()
    self.player:setLastFrame(4)
    self.player:set(icon, nil, Const.SA_THROW, 5)
  elseif type == "throwEnd" then
    self.player = CharActionEnd.new()
    self.player:setFirstFrame(5)
    self.player:set(icon, nil, Const.SA_THROW, 5, nil, callBack)
  else
    self.player = CharAction.new()
    self.player:set(icon, nil, Const.SA_STAND, 5)
  end
  self.player:setPosition(sz.width / 2, sz.height / 2)
  root:addChild(self.player)
end
function BaozqyDlg:resetInitInfo()
  self:setCtrlVisible("ReadyPanel", false)
  self:setCtrlVisible("MainPanel", true)
  self:createPlayer()
  self.boomNum = MAX_BOOM_BUM
  self.round = 1
  self.leftTime = MAX_TICK_BUM
  self.score = 0
  self:refreshBoomNum()
  self:refreshRoundNum()
  self:refreshScore()
  local tickAtlas = self:getControl("TimeTextAtlas", nil, "MainPanel")
  tickAtlas:setString(self.leftTime)
  local starPanel = self:getControl("StarPanel", nil, "MainPanel")
  local timePanel = self:getControl("NumPanel", nil, starPanel)
  local starImage = self:getControl("StarImageView", nil, starPanel)
  local sz = timePanel:getContentSize()
  local numImge = NumImg.new("bfight_num", 1, false, -5)
  numImge:setPosition(sz.width / 2, sz.height / 2)
  timePanel:addChild(numImge)
  numImge:setVisible(false)
  self:setCtrlVisible("TipsPanel02", true, "MainPanel")
  local countDown = 3
  schedule(starPanel, function()
    numImge:setVisible(true)
    starImage:setVisible(false)
    numImge:setNum(countDown, false)
    countDown = countDown - 1
    if countDown < 0 then
      starPanel:stopAllActions()
      starPanel:setVisible(false)
      self:setCtrlVisible("TipsPanel02", false, "MainPanel")
      self:startGame()
      self:initFireButtonStatus(true)
    end
  end, 1)
end
function BaozqyDlg:initFireButtonStatus(isRemove)
  local panel = self:getControl("FirePanel")
  if isRemove then
    self:setCtrlOnlyEnabled("Button", true, "FirePanel")
    panel:removeChildByTag(999)
    return
  end
  self:setCtrlOnlyEnabled("Button", false, "FirePanel")
  panel:removeChildByTag(999)
  panel:stopAllActions()
  local sprite = cc.Sprite:create(ResMgr.ui.time_tick_img)
  sprite:setOpacity(204)
  sprite:setColor(COLOR3.BLACK)
  sprite:setTag(999)
  panel:addChild(sprite)
  local contentSize = panel:getContentSize()
  sprite:setPosition(contentSize.width / 2, contentSize.height / 2)
end
function BaozqyDlg:doFireButtonCountDown()
  self:setCtrlOnlyEnabled("Button", false, "FirePanel")
  local panel = self:getControl("FirePanel")
  panel:removeChildByTag(999)
  panel:stopAllActions()
  local sprite = cc.Sprite:create(ResMgr.ui.time_tick_img)
  sprite:setOpacity(204)
  sprite:setColor(COLOR3.BLACK)
  local progressTimer = cc.ProgressTimer:create(sprite)
  progressTimer:setReverseDirection(true)
  progressTimer:setTag(999)
  panel:addChild(progressTimer)
  local contentSize = panel:getContentSize()
  progressTimer:setPosition(contentSize.width / 2, contentSize.height / 2)
  progressTimer:setPercentage(100)
  local progressTo = cc.ProgressTo:create(0.5, 0)
  local endAction = cc.CallFunc:create(function()
    self:setCtrlOnlyEnabled("Button", true, "FirePanel")
    progressTimer:removeFromParent()
  end)
  progressTimer:runAction(cc.Sequence:create(progressTo, endAction))
end
function BaozqyDlg:refreshBoomNum()
  local root = self:getControl("MoneyPanel", nil, "MainPanel")
  self:setLabelText("NowLabel", self.boomNum, root)
end
function BaozqyDlg:refreshRoundNum()
  local root = self:getControl("TitlePanel", nil, "MainPanel")
  self:setLabelText("ValueLabel", self.round, self:getControl("SchedulePanel", nil, root))
end
function BaozqyDlg:refreshScore()
  local root = self:getControl("TitlePanel", nil, "MainPanel")
  self:setLabelText("ValueLabel", string.format(CHS[7120404], self.score), self:getControl("ScorePanel", nil, root))
end
function BaozqyDlg:stopGame()
  if self.titileTickSchedule then
    self:stopSchedule(self.titileTickSchedule)
    self.titileTickSchedule = nil
  end
  self:setCtrlVisible("MainPanel", false)
end
function BaozqyDlg:cleanup()
  self.game_id = nil
  self.curRoundStartTick = nil
  self.round = nil
  self.lastFireTime = nil
  self.player = nil
  self.pauseGame = nil
  EventDispatcher:removeEventListener("ENTER_BACKGROUND", self.onEnterBackground, self)
end
function BaozqyDlg:MSG_CHAR_INFO_EX(data)
  self:MSG_CHAR_INFO(data)
end
function BaozqyDlg:MSG_OFFLINE_CHAR_INFO(data)
  self:MSG_CHAR_INFO(data)
end
function BaozqyDlg:MSG_CHAR_INFO(data)
  local dlg = DlgMgr:openDlg("CharMenuContentDlg")
  dlg:setMuneType(CHAR_MUNE_TYPE.BAOZQY_RANK)
  dlg:setInfo(data)
  local rect = {
    x = GameMgr.curTouchPos.x,
    y = GameMgr.curTouchPos.y,
    width = 5,
    height = 5
  }
  dlg:setFloatingFramePos(rect)
end
function BaozqyDlg:onEnterBackground()
  DlgMgr:closeDlg(self.name)
end
function BaozqyDlg:onCloseButton(sender, eventType)
  if self:getControl("ReadyPanel"):isVisible() then
    gf:CmdToServer("CMD_SPRING_2020_BZQY_QUIT", {type = 2})
    DlgMgr:closeDlg(self.name)
  else
    self.pauseGame = gfGetTickCount()
    gf:confirm(CHS[7120387], function()
      gf:CmdToServer("CMD_SPRING_2020_BZQY_QUIT", {type = 2})
      DlgMgr:closeDlg(self.name)
    end, function()
      if self.curRoundStartTick then
        self.curRoundStartTick = self.curRoundStartTick + gfGetTickCount() - self.pauseGame
      end
      self.pauseGame = nil
    end)
  end
end
function BaozqyDlg:onTipsButton(sender, eventType)
  DlgMgr:openDlg("BaozqyRuleDlg")
end
function BaozqyDlg:onStartButton(sender, eventType)
  gf:CmdToServer("CMD_SPRING_2020_BZQY_START", {})
end
function BaozqyDlg:onFireButton(sender, eventType)
  if self.boomNum <= 0 then
    return
  end
  if self:getControl("StarPanel", nil, "MainPanel"):isVisible() then
    return
  end
  if eventType == ccui.TouchEventType.began then
    local curTick = gfGetTickCount()
    if self.lastFireTime and curTick - self.lastFireTime < FIRE_LIMIT_TIME then
      return
    end
    self:startAimEffect()
    self:createPlayer("throwBegin")
    self.canReleaseBoom = true
  elseif eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
    self:doFireButtonCountDown()
    self:releaseBoom()
  end
end
function BaozqyDlg:MSG_SPRING_2020_BZQY_START(data)
  self.game_id = data.game_id
  self:resetInitInfo()
end
return BaozqyDlg
