local CaseWDTalkDlg = Singleton("CaseWDTalkDlg", Dialog)
local DragonBones = require("animate/DragonBones")
function CaseWDTalkDlg:init()
  self:setFullScreen()
  self:setCtrlVisible("BKPanel", true)
  self:setCtrlFullClient("BlackPanel", "BKPanel")
  self:bindListener("DramaPanel", self.onDramaPanel)
  for i = 1, 4 do
    local talkRoot = self:getControl("Panel" .. i, nil, "ChoosePanel")
    talkRoot.index = i
    self:bindListener("Panel" .. i, self.onSelectionPanel, "ChoosePanel")
  end
  self:hookMsg("MSG_SSWD_SELECT_RESULT")
end
function CaseWDTalkDlg:setData(data)
  self.dlgData = data
  self:setCtrlVisible("ChoosePanel", true)
  for i = 1, 4 do
    local talkRoot = self:getControl("Panel" .. i, nil, "ChoosePanel")
    local talkPanel = self:getControl("TalkPanel", nil, talkRoot)
    talkPanel:setContentSize(cc.size(245, 61))
    self:setColorText(data["selection" .. i], "TalkPanel", talkRoot, nil, nil, cc.c3b(76, 32, 0), 18, LOCATE_POSITION.MID_BOTTOM)
    talkRoot:requestDoLayout()
  end
  self:setLabelText("NameLabel_2", string.format(CHS[7100898], data.charactor), "NpcBonesPanel")
  self:refreshDragonBones(data.icon)
  self:refreshDegree(data.degree)
  self:setColorText(Me:getName() .. ":", "TalkPanel1", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
  self:setColorText(data.question, "TalkPanel2", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
  self:setColorText(CHS[7100897], "TalkPanel3", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
end
function CaseWDTalkDlg:refreshDegree(degree, action)
  self:setLabelText("ProgressLabel_1", string.format("%d%%", degree), "ProgressPanel")
  self:setLabelText("ProgressLabel_2", string.format("%d%%", degree), "ProgressPanel")
  if action then
    local curPercent = self:getControl("ProgressBar", nil, "ProgressPanel"):getPercent()
    self:setProgressBarByHourglassToEnd("ProgressBar", 500, curPercent, degree, nil, "ProgressPanel")
  else
    self:getControl("ProgressBar", nil, "ProgressPanel"):setPercent(degree)
  end
end
function CaseWDTalkDlg:refreshDragonBones(icon)
  local bonesPath, texturePath = ResMgr:getBonesCharFilePath(icon)
  local bExist = cc.FileUtils:getInstance():isFileExist(bonesPath)
  if bExist then
    local shapePanel = self:getControl("ShapePanel", nil, "NpcBonesPanel")
    local magic = shapePanel:getChildByName("charPortrait")
    if magic then
      if magic:getTag() == icon then
        return
      else
        magic:removeFromParent()
      end
    end
    magic = DragonBones.new(icon)
    local size = shapePanel:getContentSize()
    magic:setPosition(size.width * 0.5, 0)
    magic:setName("charPortrait")
    magic:setTag(icon)
    shapePanel:addChild(magic)
    magic:setRTextSizeAndPos(size, cc.p(size.width * 0.5, 0))
    magic:toPlay("stand", 0)
  end
end
function CaseWDTalkDlg:cleanup()
  self.dlgData = nil
  self.resultData = nil
  self.delayDramaAction = nil
  self.nextQuestionAction = nil
end
function CaseWDTalkDlg:onSelectionPanel(sender, eventType)
  gf:CmdToServer("CMD_SSWD_SELECT_ANSWER", {
    index = sender.index
  })
end
function CaseWDTalkDlg:onCloseButton(sender, eventType)
  gf:confirm(CHS[7100896], function()
    gf:CmdToServer("CMD_SSWD_QUIT_GAME", {type = 2})
  end)
end
function CaseWDTalkDlg:onDramaPanel(sender, eventType)
  if self.delayDramaAction then
    self.root:stopAction(self.delayDramaAction)
    self.delayDramaAction = nil
    self:refreshDragonBones(self.dlgData.icon)
    self:setColorText(self.dlgData.name .. ":", "TalkPanel1", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
    self:setColorText(self.resultData.answer, "TalkPanel2", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
    self.nextQuestionAction = performWithDelay(self.root, function()
      self.nextQuestionAction = nil
      gf:CmdToServer("CMD_SSWD_NEXT_QUESTION", {})
    end, 20)
  elseif self.nextQuestionAction then
    self.root:stopAction(self.nextQuestionAction)
    self.nextQuestionAction = nil
    gf:CmdToServer("CMD_SSWD_NEXT_QUESTION", {})
  end
end
function CaseWDTalkDlg:MSG_SSWD_SELECT_RESULT(data)
  self.resultData = data
  self:refreshDegree(data.degree, true)
  self:refreshDragonBones(Me:queryBasicInt("org_icon"))
  self:setColorText(Me:getName() .. ":", "TalkPanel1", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
  self:setColorText(data.content, "TalkPanel2", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
  self:setColorText("", "TalkPanel3", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
  self:setCtrlVisible("ChoosePanel", false)
  if self.delayDramaAction then
    self.root:stopAction(self.delayDramaAction)
  end
  self.delayDramaAction = performWithDelay(self.root, function()
    self:refreshDragonBones(self.dlgData.icon)
    self:setColorText(self.dlgData.name .. ":", "TalkPanel1", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
    self:setColorText(data.answer, "TalkPanel2", "DramaPanel", nil, nil, cc.c3b(255, 223, 177), 25)
    self.delayDramaAction = nil
    self.nextQuestionAction = performWithDelay(self.root, function()
      self.nextQuestionAction = nil
      gf:CmdToServer("CMD_SSWD_NEXT_QUESTION", {})
    end, 20)
  end, 20)
end
return CaseWDTalkDlg
