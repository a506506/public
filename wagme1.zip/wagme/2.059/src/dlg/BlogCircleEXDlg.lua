local BlogCircleDlg = require("dlg/BlogCircleDlg")
local BlogCircleEXDlg = Singleton("BlogCircleEXDlg", BlogCircleDlg)
function BlogCircleEXDlg:getCfgFileName()
  return ResMgr:getDlgCfg("BlogCircleDlg")
end
function BlogCircleEXDlg:cleanup()
  DlgMgr:closeDlg("BlogInfoEXDlg")
end
return BlogCircleEXDlg
