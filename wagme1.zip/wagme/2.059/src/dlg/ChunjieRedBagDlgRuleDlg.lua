local ChunjieRedBagDlgRuleDlg = Singleton("ChunjieRedBagDlgRuleDlg", Dialog)
function ChunjieRedBagDlgRuleDlg:init()
  self:bindListener("ChunjieRedBagDlgRulePanel", self.onCloseButton)
end
return ChunjieRedBagDlgRuleDlg
