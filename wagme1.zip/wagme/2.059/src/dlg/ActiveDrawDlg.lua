local ActiveDrawDlg = Singleton("ActiveDrawDlg", Dialog)
local REWARD_MAX = 8
ActiveDrawDlg.needCount = 0
ActiveDrawDlg.startPos = 1
ActiveDrawDlg.curPos = 1
ActiveDrawDlg.delay = 1
ActiveDrawDlg.updateTime = 1
ActiveDrawDlg.activeValue = nil
local BonusInfo = {
  liveness_lottery = {
    {
      [1] = {
        icon = ResMgr.ui.reward_big_daohang,
        chs = CHS[4100805],
        isPlist = 1
      }
    },
    {
      [1] = {
        itemIcon = 9002,
        chs = CHS[3001147]
      }
    },
    {
      [1] = {
        icon = ResMgr.ui.reward_big_exp,
        chs = CHS[5410084],
        isPlist = 1
      }
    },
    {
      [1] = {
        itemIcon = 9210,
        chs = CHS[5420247]
      }
    },
    {
      [1] = {
        icon = ResMgr.ui.reward_big_jewelry,
        chs = CHS[5400791],
        isPlist = 1
      }
    },
    {
      [1] = {
        itemIcon = 1716,
        chs = CHS[3001105]
      }
    },
    {
      [1] = {
        itemIcon = 1801,
        chs = CHS[5410420]
      }
    },
    {
      [1] = {
        icon = ResMgr.ui.pet_common,
        chs = CHS[7190034],
        isPlist = 1
      }
    }
  }
}
local ChangeTime = {}
function ActiveDrawDlg:getCfgFileName()
  return ResMgr:getDlgCfg("ReentryAsktaoDlg")
end
function ActiveDrawDlg:init()
  self:bindListener("DrawButton", self.onDrawButton)
  GiftMgr.lastIndex = "WelfareButton9"
  self:changeShowRewards("liveness_lottery")
  self.curLottery = "liveness_lottery"
  self:resetRewards()
  self.isRotating = false
  self:hookMsg("MSG_GENERAL_NOTIFY")
  self:hookMsg("MSG_LIVENESS_LOTTERY_RESULT")
  self:hookMsg("MSG_OPEN_WELFARE")
  self:hookMsg("MSG_OPEN_LIVENESS_LOTTERY")
  local data = GiftMgr:getWelfareData() or {}
  if next(data) then
    self:MSG_OPEN_WELFARE(data)
  end
  GiftMgr:requestActiveDrawAct()
  self:updateLayout("WelfarePanel")
end
function ActiveDrawDlg:changeShowRewards(alas)
  local isChange = false
  if not self.bonusInfo then
    self.bonusInfo = {}
  end
  local curTimeStr = gf:getServerDate("%Y%m%d%H%M%S", gf:getServerTime())
  for i = 1, #BonusInfo[alas] do
    local reward = BonusInfo[alas][i][1]
    if ChangeTime[alas] and ChangeTime[alas][i] then
      for _, t in ipairs(ChangeTime[alas][i]) do
        if curTimeStr >= t.startTime and curTimeStr <= t.endTime then
          reward = BonusInfo[alas][i][t.choose]
          break
        end
      end
    end
    if not self.bonusInfo[i] or self.bonusInfo[i].chs ~= reward.chs then
      isChange = true
      self.bonusInfo[i] = reward
    end
  end
  return isChange
end
function ActiveDrawDlg:resetRewards()
  for i = 1, REWARD_MAX do
    local panel = self:getControl("BonusPanel_" .. i)
    self:setCtrlVisible("ChosenImage", false, panel)
    if self.bonusInfo[i].icon then
      if self.bonusInfo[i].isPlist == 1 then
        self:setImagePlist("BonusImage", self.bonusInfo[i].icon, panel)
      else
        self:setImage("BonusImage", self.bonusInfo[i].icon, panel)
      end
      local image = self:getControl("BonusImage", nil, panel)
      if self.bonusInfo[i].icon == ResMgr.ui.no_bachelor_pick then
        local sss = image:getPositionY() - 31
        image:setPositionY(sss)
        panel:requestDoLayout()
      end
    elseif self.bonusInfo[i].petPortrait then
      self:setImage("BonusImage", ResMgr:getSmallPortrait(self.bonusInfo[i].petPortrait), panel)
    elseif self.bonusInfo[i].itemIcon then
      self:setImage("BonusImage", ResMgr:getItemIconPath(self.bonusInfo[i].itemIcon), panel)
    else
      local path = ResMgr:getItemIconPath(InventoryMgr:getIconByName(self.bonusInfo[i].chs))
      self:setImage("BonusImage", path, panel)
    end
    self:setItemImageSize("BonusImage", panel)
    if 1 == self.bonusInfo[i].timeLimit then
      InventoryMgr:addLogoTimeLimit(self:getControl("BonusImage", Const.UIImage, panel))
    else
      InventoryMgr:removeLogoTimeLimit(self:getControl("BonusImage", Const.UIImage, panel))
    end
    self:setLabelText("NameLabel", self.bonusInfo[i].chs, panel)
  end
end
function ActiveDrawDlg:onUpdate()
  if not self.isRotating then
    if ChangeTime[self.curLottery] and self:changeShowRewards(self.curLottery) then
      self:resetRewards()
    end
    return
  end
  if self.updateTime % self.delay ~= 0 then
    self.updateTime = self.updateTime + 1
    return
  end
  if self.curPos < self.needCount then
    self.delay = self:calcSpeed(self.curPos, self.needCount)
    local wuxPos = self.curPos % REWARD_MAX + 1
    local rollCtrl = self:getControl("ChosenImage", nil, "BonusPanel_" .. wuxPos)
    rollCtrl:setVisible(true)
    rollCtrl:setOpacity(255)
    self.curPos = self.curPos + 1
    if self.curPos ~= self.needCount then
      local timeT = self.delay * 0.03
      if timeT > 1 then
        timeT = 1
      end
      rollCtrl:runAction(cc.FadeOut:create(timeT))
    else
      rollCtrl:stopAllActions()
    end
  else
    self.isRotating = false
    GiftMgr:drawActiveReward(1)
  end
end
function ActiveDrawDlg:calcSpeed(curPos, count)
  if count - curPos < 14 then
    local speed = 6 + (14 - (count - curPos)) * (14 - (count - curPos)) * 0.6
    return math.floor(speed)
  end
  return 6
end
function ActiveDrawDlg:onDrawButton(sender, eventType)
  if not DistMgr:checkCrossDist() then
    return
  end
  if not self:isOutLimitTime("lastTime", 10000) then
    gf:ShowSmallTips(CHS[4300098])
    return
  end
  if self.isRotating then
    return
  end
  if Me:queryBasicInt("level") < 35 then
    gf:ShowSmallTips(CHS[4300097])
    return
  end
  self:setLastOperTime("lastTime", gfGetTickCount())
  GiftMgr:drawActiveReward(0)
end
function ActiveDrawDlg:MSG_LIVENESS_LOTTERY_RESULT(data)
  local ret = -1
  if data.reward == CHS[5420109] and self.bonusInfo[5].chs ~= CHS[5420109] then
    self.bonusInfo[5] = BonusInfo[self.curLottery][5][2]
  end
  for i = 1, REWARD_MAX do
    if self.bonusInfo[i].chs == data.reward then
      ret = i + 1
      break
    end
  end
  if ret == -1 then
    return
  end
  self.isRotating = true
  self.needCount = ret - self.startPos + math.random(4, 5) * REWARD_MAX
  self.startPos = 1
  self.curPos = 0
  self.delay = 1
  self.updateTime = 1
  self:resetRewards()
end
function ActiveDrawDlg:MSG_OPEN_WELFARE(data)
  self:setLabelText("NoteLabel_1", CHS[4400002] .. data.activeCount)
  self:updateLayout("SignPanel")
end
function ActiveDrawDlg:MSG_OPEN_LIVENESS_LOTTERY(data)
  if not data.alas or not BonusInfo[data.alas] then
    return
  end
  self:changeShowRewards(data.alas)
  self:resetRewards()
  self.curLottery = data.alas
  self.activeValue = data.activeValue
  if self.activeValue then
    self:setLabelText("NoteLabel_2", string.format(CHS[4400009], self.activeValue))
  end
  self:updateLayout("WelfarePanel")
end
return ActiveDrawDlg
