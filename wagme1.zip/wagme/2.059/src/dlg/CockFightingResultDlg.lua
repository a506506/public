local CockFightingResultDlg = Singleton("CockFightingResultDlg", Dialog)
local PANEL_POS = {
  {
    cc.p(196, 80)
  },
  {
    cc.p(196, 40),
    cc.p(196, 100)
  },
  {
    cc.p(196, 0),
    cc.p(196, 60),
    cc.p(196, 120)
  },
  {
    cc.p(196, -20),
    cc.p(196, 30),
    cc.p(196, 80),
    cc.p(196, 130)
  }
}
function CockFightingResultDlg:init(data)
  self:bindListener("Button", self.onClosePanel, "ExitPanel")
  self:bindListener("Button", self.onContinueButton, "RestartPanel")
  self:bindListener("ClosePanel", self.onClosePanel)
  self:setCtrlVisible("WinPanel", data.result == 1)
  self:setCtrlVisible("FailPanel", data.result == 2)
  self:setCtrlVisible("PingjuPanel1", data.result == 3)
  local panelList = {}
  local expPanel = self:getControl("ExpPanel", nil, "RewardPanel")
  if data.exp then
    self:setLabelText("ValueLabel", data.exp, expPanel)
    table.insert(panelList, expPanel)
  else
    expPanel:setVisible(false)
  end
  local taoPanel = self:getControl("TaoPanel", nil, "RewardPanel")
  if data.tao then
    self:setLabelText("ValueLabel", gf:getTaoStr(tonumber(data.tao)) .. CHS[4100702], taoPanel)
    self:setCtrlVisible("TipsLabel", false, taoPanel)
    table.insert(panelList, taoPanel)
  else
    taoPanel:setVisible(false)
  end
  local titlePanel = self:getControl("TitlePanel", nil, "RewardPanel")
  if data.appellation then
    self:setLabelText("ValueLabel", data.appellation, titlePanel)
    table.insert(panelList, titlePanel)
  else
    titlePanel:setVisible(false)
  end
  local suprisePanel = self:getControl("SurprisePanel", nil, "RewardPanel")
  if data.item then
    table.insert(panelList, suprisePanel)
  else
    suprisePanel:setVisible(false)
  end
  local posCfg = PANEL_POS[#panelList]
  for i = 1, #panelList do
    panelList[i]:setPosition(posCfg[i])
  end
  local limitPanel = self:getControl("LimitPanel", nil, "RewardPanel")
  if #panelList == 0 then
    limitPanel:setVisible(true)
    limitPanel:setPosition(PANEL_POS[1][1])
  else
    limitPanel:setVisible(false)
  end
end
function CockFightingResultDlg:onContinueButton(sender, eventType)
  gf:CmdToServer("CMD_QINGMING2020_QMDJ_RESTART")
  self:onClosePanel()
end
function CockFightingResultDlg:onClosePanel(sender, eventType)
  DlgMgr:closeDlg("CockFightingResultDlg")
  DlgMgr:closeDlg("CockFightingDlg")
end
return CockFightingResultDlg
