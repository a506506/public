local ChildIntimacyInfoDlg = Singleton("ChildIntimacyInfoDlg", Dialog)
function ChildIntimacyInfoDlg:init(intimacy)
  self:bindListener("InfoButton", self.onInfoButton)
  self:bindListener("IntimacyInfoPanel", self.onCloseButton)
  self:setData(intimacy)
end
function ChildIntimacyInfoDlg:setData(intimacy)
  local curIntimacy = intimacy
  self:setLabelText("Label1", string.format(CHS[7100436], curIntimacy), "RulePanel1")
  local nextLv, curInfo = self:getIntimacyInfo(curIntimacy)
  if not nextLv then
    self:setColorText(CHS[4200448], "Panel2", "RulePanel1", nil, nil, COLOR3.WHITE, 19)
  else
    self:setColorText(string.format(CHS[4100866], nextLv), "Panel2", "RulePanel1", nil, nil, COLOR3.WHITE, 19)
  end
  self:refreshDlgHeight()
  local panel = self:getControl("RulePanel2")
  self:setLabelText("PhyLabel2", string.format("+ %d%%", curInfo.pow), panel)
  self:setLabelText("MagLabel2", string.format("+ %d%%", curInfo.pow), panel)
  self:setLabelText("DefLabel2", string.format("+ %d%%", curInfo.def), panel)
  self:setLabelText("ReviveLabel2", string.format("+ %d%%", curInfo.revivification_rate), panel)
  self:setLabelText("ReviveTimesLabel2", string.format("+ %d", curInfo.revivification_time), panel)
  self:setLabelText("CriticalHitLabel2", string.format("+ %d%%", curInfo.stunt_rate), panel)
  self:setLabelText("DoubleHitLabel2", string.format("+ %d%%", curInfo.double_hit_rate), panel)
  self:setLabelText("DoubleHitTimesLabel2", string.format("+ %d", curInfo.double_hit_time), panel)
end
function ChildIntimacyInfoDlg:refreshDlgHeight()
  local rulePanelSz = self:getCtrlContentSize("RulePanel1")
  local intimacyContentHeight = self:getCtrlContentSize("TitleLabel", "RulePanel1").height + self:getCtrlContentSize("Label1", "RulePanel1").height + self:getCtrlContentSize("Panel2", "RulePanel1").height + 10
  self:setCtrlContentSize("RulePanel1", rulePanelSz.width, intimacyContentHeight)
  local dlgSz = self:getCtrlContentSize("IntimacyInfoPanel")
  local dlgContentHeight = self:getCtrlContentSize("RulePanel1").height + self:getCtrlContentSize("RulePanel2").height + self:getCtrlContentSize("RulePanel3").height + self:getCtrlContentSize("InfoButton").height + 15
  self:setCtrlContentSize("IntimacyInfoPanel", dlgSz.width, dlgContentHeight)
  self:setImageSize("BackImage", {
    width = dlgSz.width,
    height = dlgContentHeight
  })
end
function ChildIntimacyInfoDlg:getIntimacyInfo(intimacy)
  local intimacyCfg = HomeChildMgr:getIntimacyCfg()
  local nextLevel
  local curLevel = 0
  for lv, info in pairs(intimacyCfg) do
    if intimacy < lv then
      nextLevel = nextLevel or lv
      nextLevel = math.min(lv, nextLevel)
    end
    if lv <= intimacy and lv > curLevel then
      curLevel = lv
    end
  end
  return nextLevel, intimacyCfg[curLevel]
end
function ChildIntimacyInfoDlg:onInfoButton(sender, eventType)
  DlgMgr:openDlg("ChildIntimacyRuleDlg")
  self:onCloseButton()
end
return ChildIntimacyInfoDlg
