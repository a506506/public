local CombatStatusDlg = Singleton("CombatStatusDlg", Dialog)
local OBJ_ME = 0
local OBJ_FRIEND = 1
local OBJ_ENEMRY = 2
local margin = 6
local STATUS_POISON = 1
local STATUS_SLEEP = 2
local STATUS_FORGOTTEN = 3
local STATUS_FROZEN = 4
local STATUS_CONFUSION = 5
local STATUS_SPEED_UP = 13
local STATUS_PHY_POWER_UP = 14
local STATUS_DODGE_UP = 17
local STATUS_DEF_UP = 18
local STATUS_RECOVER_LIFE = 19
local STATUS_PASSIVE_ATTACK = 27
local STATUS_DEADLY_KISS = 28
local STATUS_LOYALTY = 29
local STATUS_IMMUNE_PHY_DAMAGE = 30
local STATUS_IMMUNE_MAG_DAMAGE = 31
local STATUS_POLAR_CHANGED = 32
local STATUS_FANZHUAN_QIANKUN = 33
local STATUS_MANA_SHIELD = 34
local STATUS_PASSIVE_MAG_ATTACK = 35
local STATUS_ADD_LIFE_BY_MANA = 36
local STATUS_XUWU = 42
local STATUS_HUANBING_ZHIJI = 43
local STATUS_SHUSHOU_JIUQIN = 44
local STATUS_AITONG_YUJUE = 45
local STATUS_WENFENG_SANGDAN = 46
local STATUS_YANGJING_XURUI = 47
local STATUS_DIANDAO_QIANKUN = 48
local STATUS_JINGANGQUAN = 49
local STATUS_WUJI_BIFAN = 50
local STATUS_TIANYAN = 51
local STATUS_CHAOFENG = 52
local STATUS_QINMI_WUJIAN = 53
local STATUS_QISHA_YIN = 54
local STATUS_QISHA_YANG = 55
local STATUS_YANCHUAN_SHENJIAO = 56
local STATUS_WEIYA = 58
local STATUS_DLB_BJ = 60
local STATUS_HUNQI_FENGMANG = 61
local STATUS_HUNQI_HUNDENG = 62
local STATUS_HUNQI_GUIBU = 63
local STATUS_HUNQI_BOMU = 64
local STATUS_HUNQI_FUHU = 65
local STATUS_YINSHEN = 66
local STATUS_YOUYUAN = 67
local STATUS_LIHUN = 69
local STATUS_LIHUN2 = 70
local STATUS_NINGSHA = 71
local STATUS_XIONGSHA = 72
local STATUS_XURUO = 73
local STATUS_LIHUN_ZHIHUO = 75
local STATUS_XUANWUYIN = 76
local STATUS_YISHOU_WEIGONG = 77
local STATUS_YIGONG_WEISHOU = 78
local STATUS_XIELINGZHIYAN = 79
local STATUS_TONGSHENG_XUESHI = 80
local STATUS_GONGSI_ZUZHOU = 81
local STATUS_SHALU_ZHIXIN = 82
local STATUS_SHOW_OPPONENT_LIFE = 100
local STATUS_TAB = {
  [STATUS_POISON] = CHS[3002334],
  [STATUS_SLEEP] = CHS[3002335],
  [STATUS_FORGOTTEN] = CHS[3002336],
  [STATUS_FROZEN] = CHS[3002337],
  [STATUS_CONFUSION] = CHS[3002338],
  [STATUS_SPEED_UP] = CHS[3002339],
  [STATUS_PHY_POWER_UP] = CHS[3002340],
  [STATUS_DODGE_UP] = CHS[3002341],
  [STATUS_DEF_UP] = CHS[3002342],
  [STATUS_RECOVER_LIFE] = CHS[3002343],
  [STATUS_PASSIVE_ATTACK] = CHS[3002344],
  [STATUS_DEADLY_KISS] = CHS[3002345],
  [STATUS_LOYALTY] = CHS[3002346],
  [STATUS_IMMUNE_PHY_DAMAGE] = CHS[3002347],
  [STATUS_IMMUNE_MAG_DAMAGE] = CHS[3002348],
  [STATUS_POLAR_CHANGED] = CHS[3002349],
  [STATUS_FANZHUAN_QIANKUN] = CHS[3002349],
  [STATUS_PASSIVE_MAG_ATTACK] = CHS[3002350],
  [STATUS_MANA_SHIELD] = CHS[3002351],
  [STATUS_ADD_LIFE_BY_MANA] = CHS[3002352],
  [STATUS_XUWU] = CHS[7000251],
  [STATUS_HUANBING_ZHIJI] = CHS[7000241],
  [STATUS_SHUSHOU_JIUQIN] = CHS[7000242],
  [STATUS_AITONG_YUJUE] = CHS[7000244],
  [STATUS_WENFENG_SANGDAN] = CHS[7000243],
  [STATUS_YANGJING_XURUI] = CHS[7000245],
  [STATUS_DIANDAO_QIANKUN] = CHS[7000307],
  [STATUS_JINGANGQUAN] = CHS[7000308],
  [STATUS_CHAOFENG] = CHS[7000309],
  [STATUS_SHOW_OPPONENT_LIFE] = CHS[7002089],
  [STATUS_QISHA_YIN] = CHS[4100964],
  [STATUS_QISHA_YANG] = CHS[4100965],
  [STATUS_YANCHUAN_SHENJIAO] = CHS[4101059],
  [STATUS_WEIYA] = CHS[4010163],
  [STATUS_DLB_BJ] = CHS[4200551],
  [STATUS_HUNQI_FENGMANG] = CHS[7190626],
  [STATUS_HUNQI_HUNDENG] = CHS[7190627],
  [STATUS_HUNQI_GUIBU] = CHS[7190628],
  [STATUS_HUNQI_BOMU] = CHS[7190630],
  [STATUS_HUNQI_FUHU] = CHS[7190632],
  [STATUS_YINSHEN] = CHS[7100622],
  [STATUS_YOUYUAN] = CHS[7100623],
  [STATUS_LIHUN] = CHS[7100624],
  [STATUS_LIHUN2] = CHS[7100624],
  [STATUS_XURUO] = CHS[4101724],
  [STATUS_NINGSHA] = CHS[4101726],
  [STATUS_XIONGSHA] = CHS[4101727],
  [STATUS_LIHUN_ZHIHUO] = CHS[4200993],
  [STATUS_XUANWUYIN] = CHS[4201015],
  [STATUS_YISHOU_WEIGONG] = CHS[4201016],
  [STATUS_YIGONG_WEISHOU] = CHS[4201017],
  [STATUS_XIELINGZHIYAN] = CHS[4010515],
  [STATUS_TONGSHENG_XUESHI] = CHS[4010516],
  [STATUS_GONGSI_ZUZHOU] = CHS[4010517]
}
local DISPLAY_ATTRIB = {
  {
    title = CHS[4300287],
    titleLabel = "LifeLabel",
    valueLabel = "LifeValueLabel"
  },
  {
    title = CHS[4300288],
    titleLabel = "ManaLabel",
    valueLabel = "ManaValueLabel"
  },
  {
    title = CHS[4300289],
    titleLabel = "NuQiLabel",
    valueLabel = "NuQiValueLabel"
  },
  {
    title = CHS[4300290],
    titleLabel = "ZhenfaLabel",
    valueLabel = "ZhenfaValueLabel"
  }
}
local STATUS_SKILL_LEVEL = {
  [STATUS_POLAR_CHANGED] = "sslv_polar_changed",
  [STATUS_FANZHUAN_QIANKUN] = "sslv_polar_changed",
  [STATUS_PASSIVE_ATTACK] = "sslv_passive_attack",
  [STATUS_IMMUNE_PHY_DAMAGE] = "sslv_immune_phy_damage",
  [STATUS_IMMUNE_MAG_DAMAGE] = "sslv_immune_mag_damage",
  [STATUS_MANA_SHIELD] = "sslv_mana_shield",
  [STATUS_ADD_LIFE_BY_MANA] = "sslv_add_life_by_mana",
  [STATUS_PASSIVE_MAG_ATTACK] = "sslv_passive_mag_attack",
  [STATUS_DIANDAO_QIANKUN] = "sslv_diandao_qiankun",
  [STATUS_JINGANGQUAN] = "sslv_jingangquan",
  [STATUS_CHAOFENG] = "sslv_chaofeng",
  [STATUS_DEADLY_KISS] = "sslv_deadly_kiss",
  [STATUS_LOYALTY] = "sslv_loyalty"
}
function CombatStatusDlg:init()
  cc.SpriteFrameCache:getInstance():addSpriteFrames("ui/polaricon.plist")
  DlgMgr:registPlistEx(self.name, "polaricon.plist")
  for i = 1, #DISPLAY_ATTRIB do
    self:setLabelText(DISPLAY_ATTRIB[i].titleLabel, "")
  end
  self:bindListener("SendNotifyButton", self.onSendNotifyButton)
  self.root:setVisible(false)
  local statusPanel = self:getControl("OneStatusPanel_1", Const.UIPanel)
  self.statusPanel = statusPanel:clone()
  self.statusPanel:retain()
  self.valuePanelSize = self.valuePanelSize or self:getControl("ValuePanel"):getContentSize()
  self.lifePanelSize = self:getControl("LifePanel"):getContentSize()
  self.rootSize = self.rootSize or self.root:getContentSize()
  self.listSize = self:getControl("StatueListListView"):getContentSize()
  self:setImagePlist("PhaseImage", ResMgr.ui.touming)
  self:hookMsg("MSG_COMBAT_STATUS_INFO")
end
function CombatStatusDlg:cleanup()
  self:releaseCloneCtrl("statusPanel")
  DlgMgr:unregistPlistEx(self.name, "polaricon.plist")
end
function CombatStatusDlg:queryInfo(obj, rect)
  if obj == nil then
    self:onCloseButton()
    return
  end
  self.obj = obj
  self.clickRect = rect
  gf:CmdToServer("CMD_GENERAL_NOTIFY", {
    type = NOTIFY.NOTICE_COMBAT_STATUS_INFO,
    para1 = tostring(obj:getId()),
    para2 = tostring(0)
  })
end
function CombatStatusDlg:setAttrib(obj)
  self:setLabelText("NameLabel", obj:getShowName())
end
function CombatStatusDlg:setManaHide()
  self:setLabelText("ManaLabel", "")
  self:setLabelText("ManaValueLabel", "")
  local valuePanel = self:getControl("ValuePanel")
  valuePanel:setContentSize(self.valuePanelSize.width, self.valuePanelSize.height * 0.5)
  self.root:setContentSize(self.rootSize.width, self.rootSize.height - self.valuePanelSize.height * 0.5)
end
function CombatStatusDlg:setAngerHide()
  self:setLabelText("NuQiLabel", "")
  self:setLabelText("NuQiValueLabel", "")
  local valuePanel = self:getControl("ValuePanel")
  valuePanel:setContentSize(self.valuePanelSize.width, self.valuePanelSize.height * 0.5)
  self.root:setContentSize(self.rootSize.width, self.rootSize.height - self.valuePanelSize.height * 0.5)
end
function CombatStatusDlg:setAngerShow(anger)
  self:setLabelText("NuQiValueLabel", anger .. "/100")
end
function CombatStatusDlg:setNotifyHide()
  self:setCtrlVisible("SendNotifyPanel", false)
  local rootSize = self.root:getContentSize()
  self.root:setContentSize(self.rootSize.width, rootSize.height - self:getControl("SendNotifyPanel"):getContentSize().height + 10)
end
function CombatStatusDlg:getLifeDesc(life)
  local lifeNum = tonumber(life)
  if lifeNum >= 1000000000 then
    local y = math.floor(lifeNum / 100000000)
    local w = math.floor((lifeNum - y * 100000000) / 10000)
    local lifeStr = ""
    lifeStr = lifeStr .. tostring(y) .. CHS[7000075]
    if w ~= 0 then
      lifeStr = lifeStr .. tostring(w) .. CHS[7000076]
    end
    return lifeStr
  end
  return life
end
function CombatStatusDlg:setBasicAttrib(key, value, titleKey, color)
  self:setLabelText(DISPLAY_ATTRIB[titleKey].titleLabel, DISPLAY_ATTRIB[key].title)
  self:setLabelText(DISPLAY_ATTRIB[titleKey].valueLabel, value, nil, color)
end
function CombatStatusDlg:getPolarImagePath(polar)
  if polar == CHS[3004297] or polar == 1 then
    return ResMgr.ui.combatStatusDlg_polar_metal
  elseif polar == CHS[3004298] or polar == 2 then
    return ResMgr.ui.combatStatusDlg_polar_wood
  elseif polar == CHS[3004299] or polar == 3 then
    return ResMgr.ui.combatStatusDlg_polar_water
  elseif polar == CHS[3004300] or polar == 4 then
    return ResMgr.ui.combatStatusDlg_polar_fire
  elseif polar == CHS[3004301] or polar == 5 then
    return ResMgr.ui.combatStatusDlg_polar_earth
  end
end
function CombatStatusDlg:MSG_COMBAT_STATUS_INFO(data)
  if data.objId ~= self.obj:getId() then
    self:onCloseButton()
    return
  end
  local displayCount = 0
  self.root:setContentSize(self.rootSize)
  self:getControl("ValuePanel"):setContentSize(self.valuePanelSize)
  self:getControl("LifePanel"):setContentSize(self.lifePanelSize)
  Log:D("1. >>>>>> root size width : " .. self.rootSize.width .. ", height : " .. self.rootSize.height)
  local realName = self.obj:getShowName()
  if Me:isLookOn() then
    self:setLabelText("OthorNameLabel", realName)
    self:setLabelText("NameLabel", "")
    displayCount = displayCount + 1
    self:setBasicAttrib(displayCount, CHS[4200191], displayCount)
    self:setNotifyHide()
  elseif self.obj:getType() == "FightPet" or self.obj:getType() == "FightFriend" then
    displayCount = displayCount + 1
    self:setBasicAttrib(1, self.obj:query("life") .. "/" .. self.obj:query("max_life"), displayCount)
    if self.obj:isGuard() or self.obj:isNpc() or self.obj:isMonster() then
    else
      displayCount = displayCount + 1
      self:setBasicAttrib(2, self.obj:query("mana") .. "/" .. self.obj:query("max_mana"), displayCount)
    end
    if self.obj:getType() == "FightPet" and self.obj:queryBasic("pet_anger") ~= "" then
      displayCount = displayCount + 1
      self:setBasicAttrib(3, self.obj:queryInt("pet_anger") .. "/100", displayCount)
    end
    local polar = gf:getPolar(data.polar)
    local polarPath = self:getPolarImagePath(polar)
    self:setImagePlist("PhaseImage", polarPath)
    self:setLabelText("NameLabel", realName)
    if nil ~= data.level then
      self:setLabelText("NameLabel", realName .. "(" .. data.level .. CHS[3002353])
    end
    self:setLabelText("OthorNameLabel", "")
    if not self.obj:isPlayer() or data.objId == Me:getId() then
      self:setNotifyHide()
    end
  elseif self.obj:getType() == "FightOpponent" then
    self:setLabelText("OthorNameLabel", realName)
    self:setLabelText("NameLabel", "")
    displayCount = displayCount + 1
    if not self.obj.showLife then
      if data.isCanUseHYJJ == 0 then
        self:setBasicAttrib(1, CHS[4300078], displayCount)
      else
        self:setBasicAttrib(1, CHS[4300079], displayCount, COLOR3.GREEN)
      end
    else
      self:setBasicAttrib(1, self:getLifeDesc(self.obj:query("life")) .. "/" .. self:getLifeDesc(self.obj:query("max_life")), displayCount)
    end
    self:setNotifyHide()
  end
  if FightMgr.glossObjsInfo[self.obj:getId()] then
    if FightMgr.glossObjsInfo[self.obj:getId()].name then
      self:setLabelText("NameLabel", gf:getRealName(FightMgr.glossObjsInfo[self.obj:getId()].name))
    end
    if nil ~= data.level and FightMgr.glossObjsInfo[self.obj:getId()].name then
      self:setLabelText("NameLabel", gf:getRealName(FightMgr.glossObjsInfo[self.obj:getId()].name) .. "(" .. data.level .. CHS[3002353])
    end
    if FightMgr.glossObjsInfo[self.obj:getId()].life and FightMgr.glossObjsInfo[self.obj:getId()].max_life then
      displayCount = math.max(displayCount, 1)
      self:setBasicAttrib(1, FightMgr.glossObjsInfo[self.obj:getId()].life .. "/" .. FightMgr.glossObjsInfo[self.obj:getId()].max_life, displayCount)
    end
    if FightMgr.glossObjsInfo[self.obj:getId()].mana and FightMgr.glossObjsInfo[self.obj:getId()].max_mana then
      displayCount = math.max(displayCount, 2)
      self:setBasicAttrib(2, FightMgr.glossObjsInfo[self.obj:getId()].mana .. "/" .. FightMgr.glossObjsInfo[self.obj:getId()].max_mana, displayCount)
    end
  end
  local statusTab = {}
  if data.status_show_opponent_life then
    local statusType = STATUS_SHOW_OPPONENT_LIFE
    local keepRoundStr
    local keep = data.status_show_opponent_life
    if keep > 20 then
      keepRoundStr = string.format(CHS[3002357], CHS[3002358])
    else
      keepRoundStr = string.format(CHS[3002359], keep)
    end
    local str
    if Me:isLookOn() then
      str = STATUS_TAB[statusType]
    else
      str = STATUS_TAB[statusType] .. keepRoundStr
    end
    table.insert(statusTab, {statusType = statusType, str = str})
  end
  if data.zhenfaPolar ~= 0 then
    displayCount = displayCount + 1
    local zhenfa = string.format(CHS[4300285], gf:getPolar(data.zhenfaPolar))
    self:setBasicAttrib(4, zhenfa, displayCount)
  end
  local missCount = 4 - displayCount
  self:setCtrlContentSize("ValuePanel", nil, self.valuePanelSize.height - missCount * 35)
  local rootSize = self.root:getContentSize()
  self.root:setContentSize(rootSize.width, rootSize.height - missCount * 35)
  if DlgMgr:sendMsg("FightInfDlg", "isPlayFight") then
    statusTab = self:addStatus(statusTab, STATUS_FORGOTTEN, data)
    statusTab = self:addStatus(statusTab, STATUS_PHY_POWER_UP, data)
    statusTab = self:addStatus(statusTab, STATUS_POISON, data)
    statusTab = self:addStatus(statusTab, STATUS_RECOVER_LIFE, data)
    statusTab = self:addStatus(statusTab, STATUS_FROZEN, data)
    statusTab = self:addStatus(statusTab, STATUS_DEF_UP, data)
    statusTab = self:addStatus(statusTab, STATUS_SLEEP, data)
    statusTab = self:addStatus(statusTab, STATUS_SPEED_UP, data)
    statusTab = self:addStatus(statusTab, STATUS_CONFUSION, data)
    statusTab = self:addStatus(statusTab, STATUS_DODGE_UP, data)
    statusTab = self:addStatus(statusTab, STATUS_POLAR_CHANGED, data)
    statusTab = self:addStatus(statusTab, STATUS_FANZHUAN_QIANKUN, data)
    statusTab = self:addStatus(statusTab, STATUS_DEADLY_KISS, data)
    statusTab = self:addStatus(statusTab, STATUS_LOYALTY, data)
    statusTab = self:addStatus(statusTab, STATUS_PASSIVE_ATTACK, data)
    statusTab = self:addStatus(statusTab, STATUS_IMMUNE_PHY_DAMAGE, data)
    statusTab = self:addStatus(statusTab, STATUS_IMMUNE_MAG_DAMAGE, data)
    statusTab = self:addStatus(statusTab, STATUS_MANA_SHIELD, data)
    statusTab = self:addStatus(statusTab, STATUS_ADD_LIFE_BY_MANA, data)
    statusTab = self:addStatus(statusTab, STATUS_PASSIVE_MAG_ATTACK, data)
    statusTab = self:addStatus(statusTab, STATUS_XUWU, data)
    statusTab = self:addStatus(statusTab, STATUS_HUANBING_ZHIJI, data)
    statusTab = self:addStatus(statusTab, STATUS_SHUSHOU_JIUQIN, data)
    statusTab = self:addStatus(statusTab, STATUS_AITONG_YUJUE, data)
    statusTab = self:addStatus(statusTab, STATUS_WENFENG_SANGDAN, data)
    statusTab = self:addStatus(statusTab, STATUS_YANGJING_XURUI, data)
    statusTab = self:addStatus(statusTab, STATUS_DIANDAO_QIANKUN, data)
    statusTab = self:addStatus(statusTab, STATUS_JINGANGQUAN, data)
    statusTab = self:addStatus(statusTab, STATUS_CHAOFENG, data)
    statusTab = self:addStatus(statusTab, STATUS_QISHA_YIN, data)
    statusTab = self:addStatus(statusTab, STATUS_QISHA_YANG, data)
    statusTab = self:addStatus(statusTab, STATUS_YANCHUAN_SHENJIAO, data)
    statusTab = self:addStatus(statusTab, STATUS_WEIYA, data)
    statusTab = self:addStatus(statusTab, STATUS_DLB_BJ, data)
    statusTab = self:addStatus(statusTab, STATUS_HUNQI_FENGMANG, data)
    statusTab = self:addStatus(statusTab, STATUS_HUNQI_HUNDENG, data)
    statusTab = self:addStatus(statusTab, STATUS_HUNQI_GUIBU, data)
    statusTab = self:addStatus(statusTab, STATUS_HUNQI_BOMU, data)
    statusTab = self:addStatus(statusTab, STATUS_HUNQI_FUHU, data)
    statusTab = self:addStatus(statusTab, STATUS_NINGSHA, data)
    statusTab = self:addStatus(statusTab, STATUS_XIONGSHA, data)
    statusTab = self:addStatus(statusTab, STATUS_XURUO, data)
    statusTab = self:addStatus(statusTab, STATUS_LIHUN_ZHIHUO, data)
    statusTab = self:addStatus(statusTab, STATUS_XUANWUYIN, data)
    statusTab = self:addStatus(statusTab, STATUS_YISHOU_WEIGONG, data)
    statusTab = self:addStatus(statusTab, STATUS_YIGONG_WEISHOU, data)
    statusTab = self:addStatus(statusTab, STATUS_XIELINGZHIYAN, data)
    statusTab = self:addStatus(statusTab, STATUS_TONGSHENG_XUESHI, data)
    statusTab = self:addStatus(statusTab, STATUS_GONGSI_ZUZHOU, data)
  else
    statusTab = self:addStatusBefore(statusTab, STATUS_FORGOTTEN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_PHY_POWER_UP, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_POISON, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_RECOVER_LIFE, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_FROZEN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_DEF_UP, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_SLEEP, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_SPEED_UP, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_CONFUSION, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_DODGE_UP, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_POLAR_CHANGED, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_FANZHUAN_QIANKUN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_DEADLY_KISS, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_LOYALTY, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_PASSIVE_ATTACK, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_IMMUNE_PHY_DAMAGE, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_IMMUNE_MAG_DAMAGE, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_MANA_SHIELD, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_ADD_LIFE_BY_MANA, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_PASSIVE_MAG_ATTACK, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_XUWU, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_HUANBING_ZHIJI, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_SHUSHOU_JIUQIN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_AITONG_YUJUE, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_WENFENG_SANGDAN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_YANGJING_XURUI, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_DIANDAO_QIANKUN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_JINGANGQUAN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_CHAOFENG, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_QISHA_YIN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_QISHA_YANG, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_YANCHUAN_SHENJIAO, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_WEIYA, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_DLB_BJ, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_HUNQI_FENGMANG, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_HUNQI_HUNDENG, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_HUNQI_GUIBU, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_HUNQI_BOMU, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_HUNQI_FUHU, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_NINGSHA, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_XIONGSHA, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_XURUO, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_LIHUN_ZHIHUO, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_XUANWUYIN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_YISHOU_WEIGONG, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_YIGONG_WEISHOU, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_XIELINGZHIYAN, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_TONGSHENG_XUESHI, data)
    statusTab = self:addStatusBefore(statusTab, STATUS_GONGSI_ZUZHOU, data)
  end
  self:displayStatus(statusTab)
end
function CombatStatusDlg:getKeepRound(field)
  local keep = field or 0
  if keep > 20 then
    return string.format(CHS[3002357], CHS[3002358])
  else
    return string.format(CHS[3002359], keep)
  end
end
function CombatStatusDlg:getKeepRoundSpecial(field, value)
  if field == "status_weiya_count" then
    return string.format(CHS[4010162], value)
  end
  return ""
end
function CombatStatusDlg:getKeepRoundAdd(field, add)
  local keep = field or 0
  local add_value = add or 0
  if keep > 20 then
    return string.format(CHS[6000577], add_value, CHS[3002358])
  else
    return string.format(CHS[6000578], add_value, keep)
  end
end
function CombatStatusDlg:getKeepRoundAddForDef(field, add1, add2)
  local keep = field or 0
  local add_value1 = add1 or 0
  local add_value2 = add2 or 0
  if keep > 20 then
    return string.format(CHS[4300342], add_value1, add_value2, CHS[3002358])
  else
    return string.format(CHS[4300343], add_value1, add_value2, keep)
  end
end
function CombatStatusDlg:getKeepRoundAdd2(field, add1, add2)
  local keep = field or 0
  local add_value1 = add1 or 0
  local add_value2 = add2 or 0
  if keep > 20 then
    return string.format(CHS[6000579], add_value1, add_value2, CHS[3002358])
  else
    return string.format(CHS[6000580], add_value1, add_value2, keep)
  end
end
function CombatStatusDlg:getSkillLevelStr(statusType, data)
  if not STATUS_SKILL_LEVEL[statusType] then
    return ""
  end
  local field = STATUS_SKILL_LEVEL[statusType]
  if data[field] then
    if STATUS_ADD_LIFE_BY_MANA == statusType then
      return string.format(CHS[5000108] .. CHS[4300873], data.status_add_life_by_mana_add, data[field])
    else
      return string.format(CHS[4300873], data[field])
    end
  else
    return ""
  end
end
function CombatStatusDlg:checkStatus(statusType, data)
  local keepRoundStr = ""
  local levelStr = self:getSkillLevelStr(statusType, data)
  local curRound = FightMgr:getCurRound()
  if statusType == STATUS_PHY_POWER_UP then
    keepRoundStr = self:getKeepRoundAdd2(data.status_phy_power, data.status_phy_power_add, data.status_mag_power_add)
  elseif statusType == STATUS_RECOVER_LIFE then
    keepRoundStr = self:getKeepRoundAdd(data.status_recover_life, data.status_recover_life_add)
  elseif statusType == STATUS_DEF_UP then
    keepRoundStr = self:getKeepRoundAddForDef(data.status_def, data.status_def_add, data.status_all_resist_except_add)
  elseif statusType == STATUS_SPEED_UP then
    keepRoundStr = self:getKeepRoundAdd(data.status_speed, data.status_speed_add)
  elseif statusType == STATUS_DODGE_UP then
    keepRoundStr = self:getKeepRound(data.status_dodge)
  elseif statusType == STATUS_POLAR_CHANGED then
    keepRoundStr = self:getKeepRound(data.status_polar_changed)
  elseif statusType == STATUS_FANZHUAN_QIANKUN then
    keepRoundStr = self:getKeepRound(data.status_fanzhuan_qiankun)
  elseif statusType == STATUS_PASSIVE_ATTACK then
    keepRoundStr = self:getKeepRound(data.status_passive_attack)
  elseif statusType == STATUS_IMMUNE_PHY_DAMAGE then
    keepRoundStr = self:getKeepRound(data.status_immune_phy_damage)
  elseif statusType == STATUS_IMMUNE_MAG_DAMAGE then
    keepRoundStr = self:getKeepRound(data.status_immune_mag_damage)
  elseif statusType == STATUS_MANA_SHIELD then
    keepRoundStr = self:getKeepRound(data.status_mana_shield)
  elseif statusType == STATUS_ADD_LIFE_BY_MANA then
    keepRoundStr = self:getKeepRound(data.status_add_life_by_mana)
  elseif statusType == STATUS_PASSIVE_MAG_ATTACK then
    keepRoundStr = self:getKeepRound(data.status_passive_mag_attack)
  elseif statusType == STATUS_XUWU then
    keepRoundStr = self:getKeepRound(data.status_xuwu)
  elseif statusType == STATUS_DIANDAO_QIANKUN then
    keepRoundStr = self:getKeepRound(data.status_diandao_qiankun)
  elseif statusType == STATUS_JINGANGQUAN then
    keepRoundStr = self:getKeepRound(data.status_jingangquan)
  elseif statusType == STATUS_CHAOFENG then
    keepRoundStr = self:getKeepRound(data.status_chaofeng)
  elseif statusType == STATUS_QISHA_YIN then
    keepRoundStr = self:getKeepRound(data.status_qisha_yin)
  elseif statusType == STATUS_QISHA_YANG then
    keepRoundStr = self:getKeepRound(data.status_qisha_yang)
  elseif statusType == STATUS_YANCHUAN_SHENJIAO then
    keepRoundStr = self:getKeepRound(data.status_yanchuan_shenjiao)
  elseif statusType == STATUS_WEIYA then
    if not data.status_weiya_count then
      data.status_weiya_count = 0
    end
    keepRoundStr = self:getKeepRoundSpecial("status_weiya_count", data.status_weiya_count)
  elseif statusType == STATUS_HUNQI_FENGMANG then
    keepRoundStr = self:getKeepRoundAddFengMang(data.status_fengmang, data.status_fengmang_add)
  elseif statusType == STATUS_HUNQI_GUIBU then
    keepRoundStr = self:getKeepRoundGuiBu(data.status_guibu, data.status_guibu_add)
  elseif statusType == STATUS_HUNQI_BOMU then
    keepRoundStr = self:getKeepRoundBoMu(data.status_bomu, data.status_bomu_add)
  elseif statusType == STATUS_HUNQI_HUNDENG then
    keepRoundStr = self:getKeepRoundHunDeng(data.status_hundeng)
  elseif statusType == STATUS_HUNQI_FUHU then
    keepRoundStr = self:getKeepRoundFuHu(data.status_fuhu)
  elseif statusType == STATUS_XIONGSHA then
    keepRoundStr = self:getKeepRound(data.status_xiongsha)
  elseif statusType == STATUS_XIELINGZHIYAN then
    keepRoundStr = self:getKeepRound(data.status_xielingzhiyan)
  elseif statusType == STATUS_TONGSHENG_XUESHI then
    keepRoundStr = self:getKeepRound(data.status_tongsheng_xueshi)
  elseif statusType == STATUS_GONGSI_ZUZHOU then
    keepRoundStr = self:getKeepRound(data.status_gongsi_zuzhou)
  end
  return levelStr .. keepRoundStr
end
function CombatStatusDlg:getKeepRoundAddFengMang(field, value)
  value = value or 0
  return string.format(CHS[7190713], value, value)
end
function CombatStatusDlg:getKeepRoundHunDeng(field, value)
  return CHS[7190714]
end
function CombatStatusDlg:getKeepRoundGuiBu(field, value)
  local keep = field or 0
  value = value or 0
  if keep > 20 then
    return string.format(CHS[7190715], value, CHS[3002358])
  else
    return string.format(CHS[7190715], value, keep)
  end
end
function CombatStatusDlg:getKeepRoundBoMu(field, value)
  value = value or 0
  return string.format(CHS[7190716], value)
end
function CombatStatusDlg:getKeepRoundFuHu(field, value)
  return CHS[7190717]
end
function CombatStatusDlg:addStatusBefore(statusTab, statusType, data)
  local meObj = FightMgr:getObjectById(self.obj:getId())
  if meObj.status:isSet(tonumber(statusType) + 1) then
    local desc
    local keepRoundStr = ""
    if not Me:isLookOn() and (self.obj:getType() == "FightFriend" or self.obj:getType() == "FightPet") then
      keepRoundStr = self:checkStatus(statusType, data)
      if statusType == STATUS_PHY_POWER_UP then
        desc = CHS[6000581] .. keepRoundStr
      else
        desc = STATUS_TAB[statusType] .. keepRoundStr
      end
    else
      desc = STATUS_TAB[statusType] .. keepRoundStr
    end
    table.insert(statusTab, {statusType = statusType, str = desc})
  end
  return statusTab
end
function CombatStatusDlg:addStatus(statusTab, statusType, data)
  local meObj = FightMgr:getObjectById(self.obj:getId())
  if meObj:isSetStatus(tonumber(statusType)) then
    local desc
    local keepRoundStr = ""
    if not Me:isLookOn() and (self.obj:getType() == "FightFriend" or self.obj:getType() == "FightPet") then
      keepRoundStr = self:checkStatus(statusType, data)
      if statusType == STATUS_PHY_POWER_UP then
        desc = CHS[6000581] .. keepRoundStr
      else
        desc = STATUS_TAB[statusType] .. keepRoundStr
      end
    elseif statusType == STATUS_DEF_UP then
      desc = STATUS_TAB[statusType] .. CHS[4300344] .. keepRoundStr
    else
      desc = STATUS_TAB[statusType] .. keepRoundStr
    end
    table.insert(statusTab, {statusType = statusType, str = desc})
  end
  return statusTab
end
function CombatStatusDlg:displayStatus(statusTab)
  local file = ResMgr:getBuffIconPath()
  cc.SpriteFrameCache:getInstance():addSpriteFrames(file .. ".plist")
  local list = self:resetListView("StatueListListView", margin)
  local listSize = self.listSize
  local size = self.statusPanel:getContentSize()
  local count = #statusTab
  for i = 1, count do
    local panel = self.statusPanel:clone()
    local statusImage = self:getControl("StatusImage", Const.UIImage, panel)
    statusImage:loadTexture(ResMgr:getFightStatus(statusTab[i].statusType), ccui.TextureResType.plistType)
    self:setLabelText("DesLabel", statusTab[i].str, panel)
    list:pushBackCustomItem(panel)
  end
  if count < 3 then
    list:setContentSize(listSize.width, (size.height + margin) * count)
    local rootSize = self.root:getContentSize()
    local size = self:getCtrlContentSize("ValuePanel")
    self.root:setContentSize(rootSize.width, rootSize.height - (self.listSize.height - list:getContentSize().height))
  end
  self.root:setVisible(true)
  if self.clickRect then
    if (MapMgr:isInDiGong() or MapMgr:isInMapByName(CHS[7100737])) and not Me:isLookOn() and self.obj:getType() == "FightOpponent" then
      local dlg = DlgMgr:getDlgByName("UndergroundCommanderDlg")
      dlg = dlg or DlgMgr:openDlg("UndergroundCommanderDlg")
      dlg:setObjId(self.obj:getId())
    elseif not FightCommanderCmdMgr:checkCanShowCommanderDlg(self.obj) then
      self:setFloatingFramePos(self.clickRect)
    end
  end
end
function CombatStatusDlg:onSendNotifyButton()
  VibrateMgr:sendVibrate("combat", self.obj:getId())
end
function CombatStatusDlg:onCloseButton()
  DlgMgr:closeDlg(self.name)
  DlgMgr:closeDlg("FightCommanderSetDlg")
  DlgMgr:closeDlg("UndergroundCommanderDlg")
end
return CombatStatusDlg
