local ChannelSetDlg = Singleton("ChannelSetDlg", Dialog)
local CHECKBOX_CONFIG = {
  WorldCheckBox = "hide_world_msg",
  PartyCheckBox = "hide_party_msg",
  TeamCheckBox = "hide_team_msg",
  CurrentCheckBox = "hide_current_msg",
  RumorCheckBox = "hide_rumor_msg",
  PartyAudioCheckBox = "autoplay_party_voice",
  TeamAudioCheckBox = "autoplay_team_voice",
  FliterVoiceCheckBox = "forbidden_play_voice"
}
local OPPOSITE_VALUE = {
  WorldCheckBox = "hide_world_msg",
  PartyCheckBox = "hide_party_msg",
  CurrentCheckBox = "hide_current_msg",
  RumorCheckBox = "hide_rumor_msg",
  TeamCheckBox = "hide_team_msg"
}
local SAVA_LOCAL = {
  WorldVoiceCheckBox = 1,
  TeamVoiceCheckBox = 1,
  PartyVoiceCheckBox = 1
}
function ChannelSetDlg:init()
  self:bindCheckBoxListener("WorldCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("PartyCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("TeamCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("CurrentCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("RumorCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("PartyAudioCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("TeamAudioCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("FliterVoiceCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("WorldVoiceCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("TeamVoiceCheckBox", self.checkBoxClick)
  self:bindCheckBoxListener("PartyVoiceCheckBox", self.checkBoxClick)
  self:initCheckBox()
  self:setCtrlVisible("FliterVoiceCheckBox", false)
end
function ChannelSetDlg:checkBoxClick(sender, eventType)
  local key = CHECKBOX_CONFIG[sender:getName()]
  local userDefault = cc.UserDefault:getInstance()
  if SAVA_LOCAL[sender:getName()] then
    if eventType == ccui.CheckBoxEventType.selected then
      userDefault:setIntegerForKey(sender:getName(), 1)
      gf:ShowSmallTips(CHS[3003682])
    elseif eventType == ccui.CheckBoxEventType.unselected then
      userDefault:setIntegerForKey(sender:getName(), 0)
      gf:ShowSmallTips(CHS[3003687])
    end
    DlgMgr:sendMsg("ChatDlg", "checkVoiceBtnPos")
    return
  end
  if eventType == ccui.CheckBoxEventType.selected then
    if OPPOSITE_VALUE[sender:getName()] then
      SystemSettingMgr:sendSeting(key, 0)
      gf:ShowSmallTips(CHS[3003682])
    else
      SystemSettingMgr:sendSeting(key, 1)
      gf:ShowSmallTips(CHS[3003682])
    end
  elseif eventType == ccui.CheckBoxEventType.unselected then
    if sender:getName() == "PartyCheckBox" and DistMgr:isInKFBZServer() then
      gf:ShowSmallTips(CHS[5000267])
      sender:setSelectedState(true)
      return
    end
    if OPPOSITE_VALUE[sender:getName()] then
      SystemSettingMgr:sendSeting(key, 1)
      gf:ShowSmallTips(CHS[3003687])
    else
      SystemSettingMgr:sendSeting(key, 0)
      gf:ShowSmallTips(CHS[3003687])
    end
  end
end
function ChannelSetDlg:initCheckBox()
  local settingTable = SystemSettingMgr:getSettingStatus()
  for k, v in pairs(CHECKBOX_CONFIG) do
    self:setCheckBoxStaus(k, settingTable[v])
  end
  local userDefault = cc.UserDefault:getInstance()
  for k, v in pairs(SAVA_LOCAL) do
    self:setCheckBoxStaus(k, userDefault:getIntegerForKey(k, 1))
  end
end
function ChannelSetDlg:setCheckBoxStaus(name, status)
  local radio = self:getControl(name, Const.UICheckBox)
  if SAVA_LOCAL[name] then
    radio:setSelectedState(status == 1)
    return
  end
  if radio then
    if status == 1 then
      if OPPOSITE_VALUE[name] then
        radio:setSelectedState(false)
      else
        radio:setSelectedState(true)
      end
    elseif status == 0 or status == nil then
      if OPPOSITE_VALUE[name] then
        radio:setSelectedState(true)
      else
        radio:setSelectedState(false)
      end
    end
  end
end
return ChannelSetDlg
