local ChongYangFoodDlg = Singleton("ChongYangFoodDlg", Dialog)
local TASTE_MAP = {
  10,
  10,
  20,
  20,
  30
}
function ChongYangFoodDlg:init()
  self:bindListener("TasteButton", self.onTasteButton, "ChongYangGaoPanel")
  self:getControl("TasteButton", nil, "ChongYangGaoPanel").tag = 1
  self:bindListener("TasteButton", self.onTasteButton, "JuHuaJiuPanel")
  self:getControl("TasteButton", nil, "JuHuaJiuPanel").tag = 2
  self.lastTasteTime = 0
  self:hookMsg("MSG_CHONGYANG_2017_TASTE")
end
function ChongYangFoodDlg:openSpecialFood()
  self:setScheduleStart(self:getRefreshLeftTime())
  self:openSpecialFoodByName("YangRouPanel")
  self:openSpecialFoodByName("DaPanXiePanel")
  self:openSpecialFoodByName("NiuRouBaoPanel")
  self:bindListener("TasteButton", self.onTasteButton, "YangRouPanel")
  self:getControl("TasteButton", nil, "YangRouPanel").tag = 3
  self:bindListener("TasteButton", self.onTasteButton, "DaPanXiePanel")
  self:getControl("TasteButton", nil, "DaPanXiePanel").tag = 4
  self:bindListener("TasteButton", self.onTasteButton, "NiuRouBaoPanel")
  self:getControl("TasteButton", nil, "NiuRouBaoPanel").tag = 5
end
function ChongYangFoodDlg:openSpecialFoodByName(name)
  local panel = self:getControl(name)
  self:setCtrlVisible("HungryLabel", true, panel)
  self:setCtrlVisible("BlackPanel", false, panel)
  self:setCtrlVisible("TasteButton", true, panel)
  self:setCtrlEnabled("TasteButton", true, panel)
  self:setCtrlVisible("SurplusLabel", true, panel)
end
function ChongYangFoodDlg:getRefreshLeftTime()
  local zeroTime = gf:getServerTodayZeroTime()
  local firstNodeTime = zeroTime + 25200
  local secondNodeTime = zeroTime + 46800
  local thirdNodeTime = zeroTime + 61200
  local currentTime = gf:getServerTime()
  local leftTime = 0
  if firstNodeTime >= currentTime then
    leftTime = firstNodeTime - currentTime
  elseif firstNodeTime < currentTime and secondNodeTime >= currentTime then
    leftTime = secondNodeTime - currentTime
  elseif secondNodeTime < currentTime and thirdNodeTime >= currentTime then
    leftTime = thirdNodeTime - currentTime
  elseif thirdNodeTime < currentTime then
    leftTime = thirdNodeTime - currentTime + 50400
  end
  return leftTime
end
function ChongYangFoodDlg:showRefreshTime(time)
  local hour = math.floor(time / 3600) % 24
  local min = math.floor(time / 60) % 60
  local sec = time % 60
  local timeStr = string.format("%02d:%02d:%02d", hour, min, sec)
  self:setLabelText("TimeLabel", timeStr, "YangRouPanel")
  self:setCtrlVisible("TimeLabel", true, "YangRouPanel")
  self:setLabelText("TimeLabel", timeStr, "DaPanXiePanel")
  self:setCtrlVisible("TimeLabel", true, "DaPanXiePanel")
  self:setLabelText("TimeLabel", timeStr, "NiuRouBaoPanel")
  self:setCtrlVisible("TimeLabel", true, "NiuRouBaoPanel")
end
function ChongYangFoodDlg:setScheduleStart(leftTime)
  self:showRefreshTime(leftTime)
  if not self.schedulId then
    self.schedulId = self:startSchedule(function()
      if leftTime > 0 then
        self:showRefreshTime(leftTime)
        leftTime = leftTime - 1
      else
        self:showRefreshTime(0)
        gf:CmdToServer("CMD_CHONGYANG_2017_TASTE", {
          npc_id = self.npcId,
          no = 0
        })
        self:clearSchedule()
      end
    end, 1)
  end
end
function ChongYangFoodDlg:clearSchedule()
  if self.schedulId then
    self:stopSchedule(self.schedulId)
    self.schedulId = nil
  end
end
function ChongYangFoodDlg:cleanup()
  self:clearSchedule()
end
function ChongYangFoodDlg:onUpdate()
  if not CharMgr:getChar(self.npcId) then
    self:onCloseButton()
  end
end
function ChongYangFoodDlg:onTasteButton(sender, eventType)
  if GameMgr.inCombat then
    gf:ShowSmallTips(CHS[7100040])
    return
  end
  if gf:getServerTime() - self.lastTasteTime < 1 then
    gf:ShowSmallTips(CHS[7100041])
    return
  end
  local senderTag = sender.tag
  if self.taste + TASTE_MAP[senderTag] > 100 then
    gf:ShowSmallTips(CHS[7100042])
    return
  end
  if senderTag == 3 and self.amount1 <= 0 or senderTag == 4 and 0 >= self.amount2 or senderTag == 5 and 0 >= self.amount3 then
    gf:ShowSmallTips(CHS[7100043])
    return
  end
  gf:CmdToServer("CMD_CHONGYANG_2017_TASTE", {
    npc_id = self.npcId,
    no = sender.tag
  })
  self.lastTasteTime = gf:getServerTime()
end
function ChongYangFoodDlg:MSG_CHONGYANG_2017_TASTE(data)
  self.npcId = data.npc_id
  self.npcType = data.type
  self.taste = data.taste
  self:setProgressBar("ExpProgressBar", self.taste, 100)
  self:setLabelText("ExpValueLabel", string.format("%d/%d", self.taste, 100))
  self.amount1 = data.amount1
  self.amount2 = data.amount2
  self.amount3 = data.amount3
  if self.npcType == 1 then
    self:openSpecialFood()
    self:setLabelText("SurplusLabel", string.format(CHS[7100044], self.amount1), "YangRouPanel")
    self:setLabelText("SurplusLabel", string.format(CHS[7100044], self.amount2), "DaPanXiePanel")
    self:setLabelText("SurplusLabel", string.format(CHS[7100044], self.amount3), "NiuRouBaoPanel")
  end
end
return ChongYangFoodDlg
