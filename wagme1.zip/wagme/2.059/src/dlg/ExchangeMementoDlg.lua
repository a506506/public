local ExchangeMementoDlg = Singleton("ExchangeMementoDlg", Dialog)
function ExchangeMementoDlg:init()
  self:bindListener("ReduceButton", self.onReduceButton)
  self:bindListener("AddButton", self.onAddButton)
  self:bindListener("ExchangeButton", self.onExchangeButton)
  self:bindNumInput("MoneyValuePanel")
  self:hookMsg("MSG_NEW_DIST_ONLINEMALL_ITEM_LIST")
end
function ExchangeMementoDlg:setData(data)
  self.dlgData = data
  self:setLabelText("NameLabel", data.alias, "ItemPanel")
  self:setImage("IconImage", data.iconPath, "ItemPanel")
  local image = self:getControl("IconImage", nil, "ItemPanel")
  if data.showLimit then
    if data.bind > 0 then
      InventoryMgr:addLogoTimeLimit(image)
    else
      InventoryMgr:addLogoBinding(image)
    end
  end
  local coinText, fontColor = gf:getArtFontMoneyDesc(tonumber(data.price))
  self:setNumImgForPanel("CoinNumPanel", fontColor, coinText, false, LOCATE_POSITION.MID, 23, "ItemPanel")
  local iconPanel = self:getControl("IconPanel")
  iconPanel.info = data
  self:bindListener("IconPanel", self.onItemPanel, "ItemPanel")
  local leftNumText, fontColor = gf:getArtFontMoneyDesc(tonumber(data.amount))
  self:setNumImgForPanel("LastNumPanel", fontColor, leftNumText, false, LOCATE_POSITION.MID, 23, "ExchangeNumPanel")
  self.inputNum = 1
  self:updataInputNum()
end
function ExchangeMementoDlg:updataInputNum()
  local numText, fontColor = gf:getArtFontMoneyDesc(tonumber(self.inputNum))
  self:setNumImgForPanel("MoneyValuePanel", fontColor, numText, false, LOCATE_POSITION.MID, 23, "ExchangeNumPanel")
  local totalPrice = self.dlgData.price * self.inputNum
  local priceText, fontColor = gf:getArtFontMoneyDesc(tonumber(totalPrice))
  if totalPrice > self.dlgData.coin then
    fontColor = ART_FONT_COLOR.RED
  end
  self:setNumImgForPanel("CoinValuePanel", fontColor, priceText, false, LOCATE_POSITION.MID, 23, "TotalPricePanel")
  self.totalPrice = totalPrice
end
function ExchangeMementoDlg:insertNumber(num)
  if num > self.dlgData.amount then
    num = self.dlgData.amount
    gf:ShowSmallTips(string.format(CHS[7150588], num))
  elseif num <= 0 then
    num = 1
    gf:ShowSmallTips(CHS[7150589])
  end
  self.inputNum = num
  self:updataInputNum()
  local dlg = DlgMgr:getDlgByName("SmallNumInputDlg")
  if dlg then
    dlg:setInputValue(num)
  end
end
function ExchangeMementoDlg:onItemPanel(sender, eventType)
  local rect = self:getBoundingBoxInWorldSpace(sender)
  local itemInfo = gf:deepCopy(sender.info)
  if itemInfo.name == CHS[7150580] or itemInfo.name == CHS[7150582] then
    local dlg = DlgMgr:openDlg("BonusInfo2Dlg")
    if itemInfo.name == CHS[7150580] then
      dlg:setRewardInfo({
        basicInfo = {
          itemInfo.name
        },
        imagePath = ResMgr.ui.small_title,
        limted = false,
        resType = 1,
        time_limited = false
      })
    else
      dlg:setRewardInfo({
        basicInfo = {
          CHS[7150598],
          string.format("“%s”", itemInfo.name)
        },
        imagePath = ResMgr.ui.small_title,
        limted = false,
        resType = 1,
        time_limited = true
      })
    end
    dlg.root:setAnchorPoint(0, 0)
    dlg:setFloatingFramePos(rect)
  else
    local dlg = DlgMgr:openDlg("ItemInfoDlg")
    itemInfo.isGuard = false
    itemInfo.gift = 2
    itemInfo.not_sell = 1
    itemInfo.deadline = itemInfo.bind
    if itemInfo.name == CHS[7150578] then
      itemInfo.limit_use_time = 0
    end
    dlg:setInfoFormCard(itemInfo)
    dlg:setFloatingFramePos(rect)
  end
end
function ExchangeMementoDlg:onReduceButton(sender, eventType)
  if self.inputNum <= 1 then
    gf:ShowSmallTips(CHS[7150589])
    return
  end
  self.inputNum = self.inputNum - 1
  self:updataInputNum()
end
function ExchangeMementoDlg:onAddButton(sender, eventType)
  if self.inputNum >= self.dlgData.amount then
    gf:ShowSmallTips(string.format(CHS[7150588], self.inputNum))
    return
  end
  self.inputNum = self.inputNum + 1
  self:updataInputNum()
end
function ExchangeMementoDlg:onExchangeButton(sender, eventType)
  if self.inputNum > self.dlgData.amount then
    gf:ShowSmallTips(string.format(CHS[7150590], self.dlgData.amount))
    return
  end
  if self.totalPrice > self.dlgData.coin then
    gf:ShowSmallTips(CHS[7150591])
    return
  end
  if self:checkSafeLockRelease("onExchangeButton") then
    return
  end
  local tips = string.format(CHS[7150592], self.totalPrice, self.inputNum, InventoryMgr:getUnit(self.dlgData.name), self.dlgData.name)
  local para = string.format("%s_%s_%s", tostring(self.dlgData.index), tostring(self.inputNum), "")
  gf:confirm(tips, function()
    gf:CmdToServer("CMD_NEW_DIST_ONLINEMALL_BUY_ITEM", {para = para})
  end)
end
function ExchangeMementoDlg:MSG_NEW_DIST_ONLINEMALL_ITEM_LIST()
  DlgMgr:closeDlg(self.name)
end
return ExchangeMementoDlg
