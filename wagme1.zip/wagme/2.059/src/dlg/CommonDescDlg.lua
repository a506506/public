local CommonDescDlg = Singleton("CommonDescDlg", Dialog)
local SliderPanel = require("ctrl/SliderPanel")
local FONTSIZE_TITLE = 25
local FONTSIZE_TEXT1 = 21
local FONTSIZE_TEXT2 = 19
local WIDTH_LEFT_MARGIN = 10
function CommonDescDlg:getTitleFontSize()
  return FONTSIZE_TITLE
end
function CommonDescDlg:getText1FontSize()
  return FONTSIZE_TEXT1
end
function CommonDescDlg:getText2FontSize()
  return FONTSIZE_TEXT2
end
function CommonDescDlg:getListView()
end
function CommonDescDlg:initContent(list, listViewName)
  local noticeList = list or {}
  listViewName = listViewName or self:getListView()
  assert(nil ~= listViewName, "ListViewName can't be nil")
  if not listViewName then
    return
  end
  local listView = self:getControl(listViewName)
  if #listView:getItems() ~= 0 then
    return
  end
  local contentLayer = ccui.Layout:create()
  local height = 0
  self:calTextNoAndInterval(noticeList)
  for i = #noticeList, 1, -1 do
    local layout = self:createLabelLayout(noticeList[i], height, i)
    height = height + layout:getContentSize().height
    contentLayer:addChild(layout)
  end
  contentLayer:setContentSize(listView:getContentSize().width, height)
  listView:pushBackCustomItem(contentLayer)
  local slierPanel = self:getControl("SliderPanel")
  local slider = SliderPanel.new(slierPanel:getContentSize(), listView)
  slierPanel:addChild(slider)
  local function listener(sender, eventType)
    if ccui.ScrollviewEventType.scrolling == eventType then
      slider:scrolling()
    end
  end
  listView:addScrollViewEventListener(listener)
end
function CommonDescDlg:calTextNoAndInterval(noticeList)
  local textNo1 = 1
  local textNo2 = 1
  local fatherType = 1
  local flag = 0
  self.textNo = {}
  self.textInterval = {}
  local cou = #noticeList
  for i = 1, cou do
    self.textNo[i] = {}
    if noticeList[i].K == "C" then
      if string.match(noticeList[i].C, "^# ") then
        self.textNo[i].noText = textNo1 .. ". "
        textNo1 = textNo1 + 1
        textNo2 = 1
        fatherType = 1
        self.textInterval[i] = 8
      elseif string.match(noticeList[i].C, "^* ") then
        self.textNo[i].noText = ""
        textNo1 = 1
        textNo2 = 1
        fatherType = 2
        self.textInterval[i] = 8
      elseif string.match(noticeList[i].C, "^## ") then
        self.textNo[i].noText = " " .. string.char(textNo2 + 96) .. ". "
        if fatherType == 1 then
          self.textNo[i].fatherNoText = textNo1 - 1 .. ". "
        else
          self.textNo[i].fatherNoText = "· "
        end
        textNo2 = textNo2 + 1
        self.textInterval[i] = 4
      else
        self.textInterval[i] = 12
        if flag ~= 0 and noticeList[i].isNewC then
          noticeList[i].C = " \n" .. noticeList[i].C
        end
        if noticeList[i].isNewC then
          flag = 1
        end
        self.textNo[i] = {}
        textNo1 = 1
        textNo2 = 1
      end
    else
      self.textInterval[i] = 0
    end
    if noticeList[i].K == "T" then
      flag = 0
    end
  end
  local lableNo = CGAColorTextList:create()
  lableNo:setFontSize(self:getText1FontSize())
  lableNo:setContentSize(self.listView:getContentSize().width - 10, 0)
  lableNo:setString("1. ")
  lableNo:updateNow()
  self.no1Width = lableNo:getRealSize()
end
function CommonDescDlg:createLabelLayout(content, posy, pos)
  local labelLayout = ccui.Layout:create()
  local text1 = string.match(content.C, "^# ")
  text1 = text1 or string.match(content.C, "^* ")
  local text2 = string.match(content.C, "^## ")
  content.C = string.gsub(content.C, "^# ", "")
  content.C = string.gsub(content.C, "^## ", "")
  content.C = string.gsub(content.C, "^* ", "")
  local lableText = CGAColorTextList:create()
  lableText:setFontSize(self:getTitleFontSize())
  local indentW = 0
  local lableNo
  local labelNoW, labelNoH = 0, 0
  if (text1 or text2) and content.K == "C" then
    lableNo = CGAColorTextList:create()
    lableNo:setFontSize(self:getTitleFontSize())
    lableNo:setContentSize(self.listView:getContentSize().width - 10, 0)
    lableNo:setDefaultColor(COLOR3.TEXT_DEFAULT.r, COLOR3.TEXT_DEFAULT.g, COLOR3.TEXT_DEFAULT.b)
    indentW = 20
    if text1 then
      lableNo:setFontSize(self:getText1FontSize())
      lableNo:setString(tostring(self.textNo[pos].noText))
      lableNo:updateNow()
      labelNoW, labelNoH = lableNo:getRealSize()
      if text1 == "# " then
        indentW = indentW - (labelNoW - self.no1Width)
      end
      lableText:setFontSize(self:getText1FontSize())
    else
      if self.textNo[pos].fatherNoText ~= "· " then
        indentW = indentW + self.no1Width
      end
      lableText:setFontSize(self:getText2FontSize())
      lableNo:setFontSize(self:getText2FontSize())
      lableNo:setString(self.textNo[pos].noText)
      lableNo:updateNow()
      labelNoW, labelNoH = lableNo:getRealSize()
    end
  end
  if lableText.setPunctTypesetting then
    lableText:setPunctTypesetting(true)
  end
  lableText:setString(content.C)
  lableText:setContentSize(self.listView:getContentSize().width - 10 - indentW - labelNoW - WIDTH_LEFT_MARGIN, 0)
  lableText:setDefaultColor(COLOR3.TEXT_DEFAULT.r, COLOR3.TEXT_DEFAULT.g, COLOR3.TEXT_DEFAULT.b)
  lableText:updateNow()
  local labelW, labelH = lableText:getRealSize()
  if lableNo then
    lableNo:setPosition(indentW, labelH)
    labelLayout:addChild(tolua.cast(lableNo, "cc.LayerColor"))
  end
  lableText:setPosition(indentW + labelNoW, labelH)
  labelLayout:addChild(tolua.cast(lableText, "cc.LayerColor"))
  local posInfo = NoticeMgr:getContentPosAndAnchor(posy, self.listView:getContentSize().width, content)
  labelLayout:setContentSize(labelW - 10 + indentW + labelNoW - WIDTH_LEFT_MARGIN, labelH + self.textInterval[pos])
  labelLayout:setPosition(posInfo.position.x + WIDTH_LEFT_MARGIN, posy)
  labelLayout:setAnchorPoint(posInfo.anchorPoint)
  local function ctrlTouch(sender, eventType)
    if ccui.TouchEventType.ended == eventType and lableText:getCsType() == CONST_DATA.CS_TYPE_URL then
      gf:onCGAColorText(lableText, sender, nil, self.name)
    end
  end
  labelLayout:setTouchEnabled(true)
  labelLayout:addTouchEventListener(ctrlTouch)
  return labelLayout
end
return CommonDescDlg
