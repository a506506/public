local ChoseDressDlg = Singleton("ChoseDressDlg", Dialog)
function ChoseDressDlg:init()
  self:bindListener("UseButton", self.onUseButton)
  self:bindListener("TurnRightButton", self.onTurnRightButton)
  self:bindListener("TurnLeftButton", self.onTurnLeftButton)
  self:bindListener("DressPanel", self.onCheckBox)
  self.dressPanel = self:retainCtrl("DressPanel")
  self:setCtrlVisible("PriceLabel", false, self.dressPanel)
  self:setCtrlVisible("PriceBKImage", false, self.dressPanel)
  self:setCtrlVisible("PriceImage", false, self.dressPanel)
  self:setCtrlVisible("PricePanel", false, self.dressPanel)
  self.listView = self:getControl("ListView")
  self.data = nil
  self:setCheck("ChoseCheckBox", false, self.dressPanel)
end
function ChoseDressDlg:setData(data)
  table.sort(data, function(l, r)
    return l.index < r.index
  end)
  self.data = data
  self:initList(data)
  self.msgType = data.type
end
function ChoseDressDlg:initList(data)
  self.lastSelectCell = nil
  self.listView:removeAllItems()
  for i = 1, #data do
    if gf:getServerTime() >= data[i].start_time then
      local cell = self.dressPanel:clone()
      self:setItemInfo(data[i], cell)
      self.listView:pushBackCustomItem(cell)
    end
  end
  self:refreshPortrait(true)
  self:setLabelText("ItemLabel", "", "ShapePanel")
end
function ChoseDressDlg:setItemInfo(data, cell)
  self:setImage("ItemImage", ResMgr:getIconPathByName(data.name), cell)
  if self.data.leftTime <= 0 then
    self:setLabelText("ItemLabel", data.name .. CHS[5410268], cell)
  else
    local str = string.format(CHS[7150193], math.floor(self.data.leftTime / 86400))
    self:setLabelText("ItemLabel", data.name .. "·" .. str, cell)
  end
  local goldText = gf:getArtFontMoneyDesc(data.price)
  self:setNumImgForPanel("PricePanel", ART_FONT_COLOR.DEFAULT, goldText, false, LOCATE_POSITION.LEFT_TOP, 17, cell)
  cell.data = data
end
function ChoseDressDlg:onCheckBox(sender, eventType)
  local isCheck = self:isCheck("ChoseCheckBox", sender)
  if self.lastSelectCell then
    self:setCheck("ChoseCheckBox", false, self.lastSelectCell)
  end
  if isCheck then
    self.lastSelectCell = nil
    self:refreshPortrait(true)
    self:setLabelText("ItemLabel", "", "ShapePanel")
  else
    self.lastSelectCell = sender
    self:setCheck("ChoseCheckBox", true, sender)
    self:refreshPortrait(true)
    if self.data.leftTime <= 0 then
      self:setLabelText("ItemLabel", sender.data.name .. CHS[5410268], "ShapePanel")
    else
      local str = string.format(CHS[7150193], math.floor(self.data.leftTime / 86400))
      self:setLabelText("ItemLabel", sender.data.name .. "·" .. str, "ShapePanel")
    end
  end
end
function ChoseDressDlg:refreshPortrait(resetDir)
  local icon, partIndex, partColorIndex
  if not self.lastSelectCell then
    icon = gf:getIconByGenderAndPolar(Me:queryBasicInt("gender"), Me:queryBasicInt("polar"))
  else
    icon = self.lastSelectCell.data.icon
    partIndex, partColorIndex = nil, nil
  end
  if resetDir then
    self.dir = 5
  end
  local panel = self:getControl("PlanPanel", nil, "PlanShapePanel")
  local argList = {
    panelName = "UserPanel",
    icon = icon,
    weapon = 0,
    root = panel,
    action = nil,
    clickCb = nil,
    offPos = nil,
    orgIcon = icon,
    syncLoad = nil,
    dir = self.dir,
    pTag = nil,
    extend = nil,
    partIndex = "",
    partColorIndex = ""
  }
  self:setPortraitByArgList(argList)
  self.icon = icon
  self:displayPlayActions("UserPanel", panel, -36)
end
function ChoseDressDlg:onUseButton(sender, eventType)
  if not self.lastSelectCell then
    gf:ShowSmallTips(CHS[5430028])
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  if Me:isInCombat() then
    gf:ShowSmallTips(CHS[3002430])
    return
  end
  gf:CmdToServer("CMD_CHOOSE_FASION", {
    type = self.msgType,
    index = self.lastSelectCell.data.index
  })
end
function ChoseDressDlg:onTurnRightButton(sender, eventType)
  self.dir = self.dir - 2
  if self.dir < 0 then
    self.dir = 7
  end
  self:refreshPortrait()
end
function ChoseDressDlg:onTurnLeftButton(sender, eventType)
  self.dir = self.dir + 2
  if self.dir > 7 then
    self.dir = 1
  end
  self:refreshPortrait()
end
return ChoseDressDlg
