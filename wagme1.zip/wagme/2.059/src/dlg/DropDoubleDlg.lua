local DropDoubleDlg = Singleton("DropDoubleDlg", Dialog)
local ITEM_MARGIN = 0
local RES_LIST = {
  {
    CHS[2200008],
    CHS[3000283],
    CHS[3001754],
    CHS[7002143],
    CHS[7002144],
    CHS[4010374],
    CHS[7002145],
    CHS[7002146],
    CHS[4100959],
    CHS[4200510],
    CHS[3000693],
    CHS[7002147],
    CHS[7000014]
  },
  {
    CHS[7002143],
    CHS[7002144],
    CHS[4010374],
    CHS[7002145],
    CHS[7002146],
    CHS[4100959],
    CHS[4200510],
    CHS[3000720],
    CHS[7000014]
  },
  {
    CHS[2000073]
  }
}
local PANEL_NAME = {
  "ItemPanel1",
  "ItemPanel2",
  "ItemPanel3"
}
function DropDoubleDlg:init()
  self.cell = self:getControl("FromPanel")
  self.cell:retain()
  self.cell:removeFromParent()
  self:bindResourceButton()
  self:setItemImage()
  self:onItemPanel(self:getControl("ItemPanel1"), 2)
end
function DropDoubleDlg:bindResourceButton()
  for i = 1, #PANEL_NAME do
    self:getControl(PANEL_NAME[i]):setTag(i)
    self:bindListener(PANEL_NAME[i], self.onItemPanel)
  end
end
function DropDoubleDlg:onItemPanel(sender, eventType)
  self:clearSelectEffect()
  self:setCtrlVisible("BChosenEffectImage", true, sender)
  self.type = sender:getTag()
  self:refreshResourcePanel(self.type)
end
function DropDoubleDlg:clearSelectEffect()
  for i = 1, #PANEL_NAME do
    self:setCtrlVisible("BChosenEffectImage", false, PANEL_NAME[i])
  end
end
function DropDoubleDlg:setItemImage()
  self:setImage("ItemImage", InventoryMgr:getIconFileByName(CHS[3000666]), "ItemShapePanel1")
  self:setImagePlist("ItemImage", ResMgr.ui.big_jewelry, "ItemShapePanel2")
  self:setImage("ItemImage", InventoryMgr:getIconFileByName(CHS[7000081]), "ItemShapePanel3")
end
function DropDoubleDlg:refreshResourcePanel()
  local listView = self:getControl("ListView")
  listView:removeAllChildren()
  listView:setItemsMargin(ITEM_MARGIN)
  local type = self.type
  if not type then
    return
  end
  local resList = RES_LIST[type]
  for i = 1, #resList do
    local cell = self.cell:clone()
    self:setLabelText("FromLabel", string.format(CHS[7003029], resList[i]), cell)
    listView:pushBackCustomItem(cell)
  end
end
function DropDoubleDlg:cleanup()
  self:releaseCloneCtrl("cell")
end
return DropDoubleDlg
