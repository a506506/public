local KuafjjsxDlg = require("dlg/KuafjjsxDlg")
local DifujjMatchTeamDlg = Singleton("DifujjMatchTeamDlg", KuafjjsxDlg)
local POLAR_INFO = {
  "Metal",
  "Wood",
  "Water",
  "Fire",
  "Earth"
}
local MIN_LEVEL, MAX_LEVEL, MIN_TAO, MAX_TAO
function DifujjMatchTeamDlg:getCfgFileName()
  return ResMgr:getDlgCfg("KuafjjsxDlg")
end
function DifujjMatchTeamDlg:checkDownLimitNum(num, tag)
  if tag == 1 then
    if num < MIN_LEVEL then
      gf:ShowSmallTips(string.format(CHS[5400375], MIN_LEVEL))
      return MIN_LEVEL
    end
  elseif tag == 2 then
    if num < self.nums[tag - 1] then
      gf:ShowSmallTips(CHS[5000321])
      return self.nums[tag - 1]
    end
  elseif tag == 3 then
    if num < MIN_TAO then
      gf:ShowSmallTips(string.format(CHS[5000322], MIN_TAO))
      return MIN_TAO
    end
  elseif tag == 4 and num < self.nums[tag - 1] then
    gf:ShowSmallTips(CHS[5000321])
    return self.nums[tag - 1]
  end
  return num
end
function DifujjMatchTeamDlg:checkUpLimitNum(num, tag)
  if tag == 1 then
    if num > self.nums[tag + 1] then
      gf:ShowSmallTips(CHS[5000323])
      return self.nums[tag + 1]
    end
  elseif tag == 2 then
    if num > MAX_LEVEL then
      gf:ShowSmallTips(string.format(CHS[5400378], MAX_LEVEL))
      return MAX_LEVEL
    end
  elseif tag == 3 then
    if num > self.nums[tag + 1] then
      gf:ShowSmallTips(CHS[5000323])
      return self.nums[tag + 1]
    end
  elseif tag == 4 and num > MAX_TAO then
    gf:ShowSmallTips(string.format(CHS[5000324], MAX_TAO))
    return MAX_TAO
  end
  return num
end
function DifujjMatchTeamDlg:initLevel()
  self:setCtrlVisible("LevelLabel", false, "TaoPanel")
  self:setCtrlVisible("LevelLabel2", true, "TaoPanel")
  local ctrl = self:getControl("MinPanel", nil, "TaoPanel")
  local x = ctrl:getPositionX()
  ctrl:setPositionX(x + 14)
  ctrl = self:getControl("LinkLabel", nil, "TaoPanel")
  x = ctrl:getPositionX()
  ctrl:setPositionX(x + 14)
  ctrl = self:getControl("MaxPanel", nil, "TaoPanel")
  x = ctrl:getPositionX()
  ctrl:setPositionX(x + 14)
  local data = DlgMgr:sendMsg("FubenMissionForDFJJDlg", "getDifjjData")
  MIN_LEVEL, MAX_LEVEL = data.min_level, data.max_level
  MIN_TAO, MAX_TAO = 0, 50000
end
function DifujjMatchTeamDlg:setDefaultNum()
  local matchInfo = TeamMgr:getCurMatchInfo() or {}
  local minLevel = matchInfo.minLevel or 0
  local maxLevel = matchInfo.maxLevel or 0
  local minTao = matchInfo.minTao or 0
  local maxTao = matchInfo.maxTao or 0
  local polars = matchInfo.polars or {}
  local data = DlgMgr:sendMsg("FubenMissionForDFJJDlg", "getDifjjData")
  if minLevel <= 0 or maxLevel <= 0 then
    minLevel = math.max(MIN_LEVEL, Me:queryInt("level") - 5)
    maxLevel = math.min(MAX_LEVEL, Me:queryInt("level") + 5)
  end
  if maxTao <= 0 or minTao <= 0 then
    minTao = math.min(math.floor(Me:queryInt("last_mon_tao") / Const.ONE_YEAR_TAO), 50000)
    maxTao = math.min(minTao + 10000, 50000)
  end
  local cou = #polars
  if cou == 0 or cou == 5 then
    self:onSelectAllPolar(self:getControl("BKImage", nil, "AllPolarPanel"))
  else
    for i = 1, cou do
      self:onSelectPolar(self:getControl("BKImage", nil, POLAR_INFO[polars[i]] .. "Panel"))
    end
  end
  local minPanel = self:getControl("MinPanel", nil, "LevelPanel")
  local maxPanel = self:getControl("MaxPanel", nil, "LevelPanel")
  self:setLabelText("ConValueLabel", minLevel, minPanel)
  self:setLabelText("ConValueLabel", maxLevel, maxPanel)
  local minPanel = self:getControl("MinPanel", nil, "TaoPanel")
  local maxPanel = self:getControl("MaxPanel", nil, "TaoPanel")
  self:setLabelText("ConValueLabel", minTao, minPanel)
  self:setLabelText("ConValueLabel", maxTao, maxPanel)
  self.nums = {
    minLevel,
    maxLevel,
    minTao,
    maxTao
  }
  self:setLabelText("LeftLabel", CHS[5400415] .. " " .. MIN_LEVEL .. " ~ " .. MAX_LEVEL, "LevelPanel")
  self:setLabelText("LeftLabel", CHS[5400416] .. " " .. MIN_TAO .. " ~ " .. MAX_TAO, "TaoPanel")
end
function DifujjMatchTeamDlg:onAgreeButton(sender, eventType)
  local polars = {}
  for key, v in pairs(self.choosePolars) do
    if v then
      table.insert(polars, key)
    end
  end
  if not next(polars) then
    gf:ShowSmallTips(CHS[5410215])
    return
  end
  if polars[1] == 0 then
    polars = {
      1,
      2,
      3,
      4,
      5
    }
  end
  gf:CmdToServer("CMD_START_MATCH_TEAM_LEADER_DFJJC", {
    minLevel = self.nums[1],
    maxLevel = self.nums[2],
    polars = polars,
    minTao = self.nums[3],
    maxTao = self.nums[4]
  })
  DlgMgr:sendMsg("TeamDlg", "setMatchInfo", CHS[4101745], self.nums[1], self.nums[2], polars, self.nums[3], self.nums[4])
  self:onCloseButton()
end
return DifujjMatchTeamDlg
