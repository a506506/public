local ChongyangfzlrDlg = Singleton("ChongyangfzlrDlg", Dialog)
local NumImg = require("ctrl/NumImg")
local DEFAULT_TIME_MAX = 30
local CAMERA_POS = cc.p(99, 64)
local OLD_MAN_POS = cc.p(81, 68)
local OLD_MAN_ICON = 20009
local PASSERBY_POS = {
  {
    START = cc.p(75, 61),
    END = cc.p(99, 73)
  },
  {
    START = cc.p(79, 59),
    END = cc.p(103, 71)
  },
  {
    START = cc.p(83, 57),
    END = cc.p(107, 69)
  },
  {
    START = cc.p(87, 55),
    END = cc.p(111, 67)
  },
  {
    START = cc.p(91, 53),
    END = cc.p(115, 65)
  }
}
local NPC_INFO = {
  {icon = OLD_MAN_ICON},
  {icon = 51001},
  {icon = 6035},
  {
    icon = {
      6001,
      7002,
      7003,
      6004,
      6005
    }
  },
  {
    icon = {
      7001,
      6002,
      6003,
      7004,
      7005
    }
  }
}
local SPCIAL_DISTANCE = {
  [51001] = 65
}
local ROUND_INFO = {
  {
    ZHENG = 5,
    FAN = 0,
    NPC_IDX = {4, 5},
    SPEED = 0.2,
    TIME_MAGIN = 2
  },
  {
    ZHENG = 4,
    FAN = 1,
    NPC_IDX = {4, 5},
    SPEED = 0.24,
    TIME_MAGIN = 1.6
  },
  {
    ZHENG = 3,
    FAN = 2,
    NPC_IDX = {
      3,
      4,
      5
    },
    SPEED = 0.26,
    TIME_MAGIN = 1.3
  },
  {
    ZHENG = 2,
    FAN = 3,
    NPC_IDX = {
      2,
      3,
      4,
      5
    },
    SPEED = 0.30000000000000004,
    TIME_MAGIN = 1
  }
}
function ChongyangfzlrDlg:init(data)
  self:setFullScreen()
  self:bindListener("StartButton", self.onStartButton)
  self:bindListener("RestartButton", self.onRestartButton)
  self:bindListener("QuitButton2", self.onQuitButton2)
  self:bindListener("DownButton", self.onDownButton)
  self:bindListener("RightButton", self.onRightButton)
  self:bindListener("UpButton", self.onUpButton)
  self:bindListener("LeftButton", self.onLeftButton)
  self:setCtrlVisible("StartButton", true)
  self:setCtrlVisible("ResultPanel", false)
  self:setCtrlVisible("ControlPanel", false)
  self:initTimePanel()
  DlgMgr:showAllOpenedDlg(false, {
    [self.name] = 1,
    ["LoadingDlg"] = 1
  })
  DlgMgr:setAllDlgVisible(false, {
    [self.name] = 1,
    ["LoadingDlg"] = 1
  })
  CharMgr:doCharHideStatus(Me)
  data.stage = data.stage + 1
  self.data = data
  self:initPosResult()
  self:resetGame(data)
  self:hookMsg("MSG_CHONGYANG_2019_FZLR_QUIT")
  self:hookMsg("MSG_CHONGYANG_2019_FZLR_START")
  self:hookMsg("MSG_CHONGYANG_2019_FZLR_BONUS")
end
function ChongyangfzlrDlg:setRoundInfo(data)
  if not data then
    return
  end
  self:setLabelText("Label_45", string.format(CHS[4010439], data.stage, data.stage_max))
end
function ChongyangfzlrDlg:initPosResult()
  self.posResult = {}
  for i = 1, #PASSERBY_POS do
    local roadInfo = PASSERBY_POS[i]
    local idx = 0
    for j = roadInfo.START.x, roadInfo.END.x, 2 do
      idx = idx + 1
      local key = string.format("%d@%d", roadInfo.START.x + (idx - 1) * 2, roadInfo.START.y + idx - 1)
      self.posResult[key] = 0
    end
  end
  self.posResult["81@68"] = 0
  self.posResult["107@57"] = 1
  self.posResult["109@58"] = 1
  self.posResult["111@59"] = 1
  self.posResult["113@60"] = 1
  self.posResult["115@61"] = 1
  self.posResult["117@62"] = 1
  self.posResult["119@63"] = 1
end
function ChongyangfzlrDlg:onUpdate()
  if self.oldMan then
    self.oldMan:update()
  end
  if self.passerbyMan then
    for _, char in pairs(self.passerbyMan) do
      if self.stopRoad == char.road then
      else
        char:update()
        local dis = SPCIAL_DISTANCE[char:queryBasicInt("icon")] or 40
        if dis >= cc.pGetDistance(cc.p(char.curX, char.curY), cc.p(self.oldMan.curX, self.oldMan.curY)) then
          self.gameSatge = "lose"
          self.stopRoad = char.road
          self.oldMan:setCanMove(false)
          self:gameFail(CHS[4010440])
        end
      end
    end
  end
end
function ChongyangfzlrDlg:resetGame(data)
  data = data or self.data
  self.gameSatge = "ready"
  self.stopRoad = nil
  self.isLock = true
  self:setRoundInfo(data)
  self:cleanupObj()
  self:initOldMan()
  self.passerbyId = 0
  self.passerbyMan = {}
end
function ChongyangfzlrDlg:initRoad(round)
  local poor = {
    1,
    2,
    3,
    4,
    5
  }
  self.zhengRoad = {}
  self.fanRoad = {}
  local zhengNum = ROUND_INFO[round].ZHENG
  local idx = 0
  for i = 1, zhengNum do
    idx = idx + 1
    local r = math.random(1, #poor)
    table.insert(self.zhengRoad, poor[r])
    table.remove(poor, r)
  end
  self.fanRoad = poor
end
function ChongyangfzlrDlg:bornPasserby(startPos, endPos, round, road)
  if self.stopRoad == road then
    return
  end
  local r = math.random(1, #ROUND_INFO[round].NPC_IDX)
  local iconPoor = NPC_INFO[ROUND_INFO[round].NPC_IDX[r]]
  local icon, mount_icon, pet_icon, special_icon
  if type(iconPoor.icon) == "table" then
    icon = iconPoor.icon[math.random(1, #iconPoor.icon)]
  else
    icon = iconPoor.icon
  end
  self.passerbyId = self.passerbyId + 1
  local char = require("obj/activityObj/FzlrNpc").new()
  char:absorbBasicFields({
    icon = icon,
    dir = 5,
    passerbyId = self.passerbyId
  })
  char.road = road
  char:setSpeed(ROUND_INFO[round].SPEED)
  char:setAct(Const.FA_STAND)
  char:onEnterScene(startPos.x, startPos.y)
  local function callBack(para)
    local passerbyId = char:queryBasicInt("passerbyId")
    char:cleanup()
    self.passerbyMan[passerbyId] = nil
  end
  local funData = {func = callBack, para = char}
  char:setEndPos(endPos.x, endPos.y, funData)
  self.passerbyMan[self.passerbyId] = char
end
function ChongyangfzlrDlg:initPasserbyTime(round)
  self:stopSchedule(self.timer)
  local ti = ROUND_INFO[round].TIME_MAGIN
  self.timer = self:startSchedule(function()
    local ran = math.random(1, 5)
    if ran <= ROUND_INFO[round].ZHENG then
      local road = math.random(1, 5)
      self:bornPasserby(PASSERBY_POS[road].START, PASSERBY_POS[road].END, round, road)
    else
      local road = math.random(1, 5)
      self:bornPasserby(PASSERBY_POS[road].END, PASSERBY_POS[road].START, round, road)
    end
  end, ti)
end
function ChongyangfzlrDlg:startGameByRound(round)
  self:initRoad(round)
  self:initPasserbyTime(round)
end
function ChongyangfzlrDlg:initOldMan()
  self.oldMan = require("obj/activityObj/FzlrNpc").new()
  self.oldMan:absorbBasicFields({icon = OLD_MAN_ICON, dir = 3})
  self.oldMan:setCanMove(true)
  self.oldMan.noX = OLD_MAN_POS.x
  self.oldMan.noY = OLD_MAN_POS.y
  self.oldMan:setAct(Const.FA_STAND)
  self.oldMan:setSpeed(0.2)
  self.oldMan:onEnterScene(OLD_MAN_POS.x, OLD_MAN_POS.y)
end
function ChongyangfzlrDlg:initTimePanel()
  local timePanel = self:getControl("TimePanel")
  if timePanel then
    local sz = timePanel:getContentSize()
    self.numImg = NumImg.new("bfight_num", DEFAULT_TIME_MAX, false, -5)
    self.numImg:setPosition(sz.width / 2, sz.height / 2)
    self.numImg:setVisible(false)
    self.numImg:setScale(0.5, 0.5)
    timePanel:addChild(self.numImg)
    self.waitImg = self:getControl("WaitImage", Const.UIImage)
    self.numImg:setPosition(sz.width / 2, sz.height / 2)
    self.waitImg:setVisible(false)
    timePanel:setVisible(false)
  end
end
function ChongyangfzlrDlg:onClickBlank()
  return true
end
function ChongyangfzlrDlg:cleanupObj()
  if self.oldMan then
    self.oldMan:cleanup()
    self.oldMan = nil
  end
  if self.passerbyMan then
    for _, char in pairs(self.passerbyMan) do
      char:cleanup()
    end
    self.passerbyMan = {}
  end
end
function ChongyangfzlrDlg:cleanup()
  performWithDelay(gf:getUILayer(), function()
    DlgMgr:showAllOpenedDlg(true)
  end)
  Me:setVisible(true)
  self:cleanupObj()
  gf:CmdToServer("CMD_CHONGYANG_2019_FZLR_QUIT")
  DlgMgr:showLoadingDlgAction()
  self.roundReadyTime = false
  Me:setPos(gf:convertToClientSpace(ActivityHelperMgr.fzlrPos.x, ActivityHelperMgr.fzlrPos.y))
  Me:setLastMapPos(ActivityHelperMgr.fzlrPos.x, ActivityHelperMgr.fzlrPos.y)
end
function ChongyangfzlrDlg:onStartButton(sender, eventType)
  local round = self.data.stage
  local text = round .. " #@#@# " .. 0
  text = gfEncrypt(text, self.data.dynamic_key)
  gf:CmdToServer("CMD_CHONGYANG_2019_FZLR_PLAY", {text = text})
  sender:setVisible(false)
  self:setCtrlVisible("ControlPanel", true)
  self.gameSatge = "ready"
  self:startGameByRound(round)
  self:startCountDown(DEFAULT_TIME_MAX, function()
    self.oldMan:setCanMove(false)
    self:gameFail(CHS[4010441])
  end)
  self.isLock = false
end
function ChongyangfzlrDlg:gameFail(tips)
  self.oldMan:setChat({msg = tips, show_time = 3}, nil, true)
  self.oldMan:setDieAction()
  self.numImg:stopCountDown()
  self:setCtrlVisible("TimePanel", false)
  performWithDelay(self.root, function()
    self:showFail()
  end, 2)
end
function ChongyangfzlrDlg:showFail()
  self:setCtrlVisible("ResultPanel", true)
  self:setCtrlVisible("FailPanel", true, "ResultPanel")
  self:setCtrlVisible("SuccPanel", false, "ResultPanel")
  self:stopSchedule(self.timer)
  self:setCtrlVisible("ControlPanel", false)
end
function ChongyangfzlrDlg:startCountDown(time, cb)
  if not self.numImg then
    return
  end
  self.numImg:setNum(time, false)
  self.numImg:setVisible(true)
  self.waitImg:setVisible(false)
  self:setCtrlVisible("TimePanel", true)
  self.numImg:startCountDown(function()
    if cb then
      cb()
    end
    self:setCtrlVisible("TimePanel", false)
  end)
end
function ChongyangfzlrDlg:succCrossRoad()
  self.numImg:stopCountDown()
  self:setCtrlVisible("TimePanel", false)
  self.isLock = true
  self:stopSchedule(self.timer)
  self.oldMan:setChat({
    msg = CHS[4010443],
    show_time = 3
  }, nil, true)
  self.oldMan:setAct(Const.FA_STAND)
  self.oldMan:setAct(Const.FA_ACTION_CAST_MAGIC, function()
    self.oldMan:setAct(Const.FA_ACTION_CAST_MAGIC_END, function()
      self.oldMan:setAct(Const.FA_STAND)
      self:completed()
      if self.data.stage == self.data.stage_max then
        self.numImg:stopCountDown()
        self:setCtrlVisible("TimePanel", false)
        return
      end
      performWithDelay(self.root, function()
        self.data.stage = self.data.stage + 1
        self:setRoundInfo(self.data)
        self:resetGame()
        self.roundReadyTime = true
        self:startCountDown(3, function()
          self.roundReadyTime = false
          local round = self.data.stage
          local text = round .. " #@#@# " .. 0
          text = gfEncrypt(text, self.data.dynamic_key)
          gf:CmdToServer("CMD_CHONGYANG_2019_FZLR_PLAY", {text = text})
          performWithDelay(self.root, function()
            self.isLock = false
            self:startGameByRound(self.data.stage)
            self:startCountDown(DEFAULT_TIME_MAX, function()
              self.oldMan:setCanMove(false)
              self:gameFail(CHS[4010444])
            end)
          end)
        end)
      end, 2)
    end)
  end)
end
function ChongyangfzlrDlg:moveTo(destX, destY)
  if self.roundReadyTime then
    gf:ShowSmallTips(CHS[4010458])
    return
  end
  if self.isLock then
    return
  end
  local key = string.format("%d@%d", destX, destY)
  if not self.posResult[key] then
    gf:ShowSmallTips(CHS[4010442])
    return
  end
  self.isLock = true
  self.oldMan.noX = destX
  self.oldMan.noY = destY
  local function callBack(para)
    self.isLock = false
    local key = string.format("%d@%d", destX, destY)
    if self.posResult[key] ~= 1 then
      return
    end
    self:succCrossRoad()
  end
  local funData = {func = callBack, para = char}
  self.oldMan:setEndPos(destX, destY, funData)
end
function ChongyangfzlrDlg:onDownButton(sender, eventType)
  local destX = self.oldMan.noX - 4
  local destY = self.oldMan.noY + 2
  self:moveTo(destX, destY)
end
function ChongyangfzlrDlg:completed()
  local round = self.data.stage
  local text = round .. " #@#@# " .. 1
  text = gfEncrypt(text, self.data.dynamic_key)
  gf:CmdToServer("CMD_CHONGYANG_2019_FZLR_PLAY", {text = text})
end
function ChongyangfzlrDlg:onRestartButton(sender, eventType)
  self:setRoundInfo(self.data)
  self:resetGame()
  self:setCtrlVisible("StartButton", true)
  self:setCtrlVisible("ResultPanel", false)
end
function ChongyangfzlrDlg:onQuitButton2(sender, eventType)
  DlgMgr:closeDlg(self.name)
end
function ChongyangfzlrDlg:onCloseButton(sender, eventType)
  if self:getCtrlVisible("ResultPanel") and self:getCtrlVisible("SuccPanel", "ResultPanel") then
    DlgMgr:closeDlg(self.name)
    return
  end
  gf:confirm(CHS[4010459], function()
    DlgMgr:closeDlg(self.name)
  end)
end
function ChongyangfzlrDlg:onRightButton(sender, eventType)
  local destX = self.oldMan.noX + 2
  local destY = self.oldMan.noY + 1
  self:moveTo(destX, destY)
end
function ChongyangfzlrDlg:onUpButton(sender, eventType)
  local destX = self.oldMan.noX + 4
  local destY = self.oldMan.noY - 2
  self:moveTo(destX, destY)
end
function ChongyangfzlrDlg:onLeftButton(sender, eventType)
  local destX = self.oldMan.noX - 2
  local destY = self.oldMan.noY - 1
  self:moveTo(destX, destY)
end
function ChongyangfzlrDlg:MSG_CHONGYANG_2019_FZLR_QUIT(data)
  DlgMgr:closeDlg(self.name)
end
function ChongyangfzlrDlg:MSG_CHONGYANG_2019_FZLR_START(data)
end
function ChongyangfzlrDlg:MSG_CHONGYANG_2019_FZLR_BONUS(data)
  self:setCtrlVisible("ResultPanel", true)
  self:stopSchedule(self.timer)
  self:setCtrlVisible("FailPanel", false, "ResultPanel")
  self:setCtrlVisible("SuccPanel", true, "ResultPanel")
  local xinPanel = self:getControl("Item1Panel")
  self:setImagePlist("RewardImage", ResMgr.ui.experience, xinPanel)
  self:setLabelText("NumLabel", data.exp, xinPanel)
  local daoPanel = self:getControl("Item2Panel")
  self:setImagePlist("RewardImage", ResMgr.ui.daohang, daoPanel)
  self:setLabelText("NumLabel", gf:getTaoStr(data.tao) .. CHS[4100886], daoPanel)
  local daoPanel = self:getControl("Item3Panel")
  self:setImagePlist("RewardImage", ResMgr.ui.item_common, daoPanel)
  if data.item_name == "" then
    self:setLabelText("NumLabel", "无", daoPanel)
  else
    self:setLabelText("NumLabel", data.item_name .. "*" .. data.item_count, daoPanel)
  end
  self:setCtrlVisible("ControlPanel", false)
end
return ChongyangfzlrDlg
