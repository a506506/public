local MARGIN = 10
local BACK_WIDTH = 11600
local TIP_WIDTH = BACK_WIDTH - MARGIN * 2
local i = 0
local text_width
local MOVE = 2
local AnnouncementDlg = Singleton("AnnouncementDlg", Dialog)
local KEEP_TIME = 10
local actionTips = {}
local HORN_MAGIC_TAG = 999
local HORN_OFFSET_X = 68
local NORMAL_TIMES = 1
function AnnouncementDlg:init()
  self.blank:setLocalZOrder(-1)
  self.notePanel = self:getControl("NotePanel")
  self:addHornMagic()
end
function AnnouncementDlg:cleanup()
  self:removeHornMagic()
  self:cleanData()
end
function AnnouncementDlg:cleanData()
  local j
  for j = 1, #actionTips do
    actionTips[j]:stopAllActions()
    actionTips[j]:removeFromParent(true)
  end
  actionTips = {}
end
function AnnouncementDlg:addTip(str)
  local tipCtrl = self:generateTip(str)
  tipCtrl.addTime = gf:getServerTime()
  local panelCtrl = self.notePanel
  panelCtrl:addChild(tipCtrl)
  table.insert(actionTips, tipCtrl)
end
function AnnouncementDlg:generateTip(str)
  local tip = CGAColorTextList:create()
  tip:setFontSize(20)
  tip:setString(str)
  tip:setContentSize(TIP_WIDTH, 0)
  tip:updateNow()
  local w, h = tip:getRealSize()
  tip:setPosition(MARGIN, h + MARGIN)
  local panelCtrl = self.notePanel
  local layer = ccui.Layout:create()
  layer:setContentSize(cc.size(w + MARGIN * 2, h + MARGIN * 2))
  layer:setPosition(panelCtrl:getContentSize().width, (30 - (h + MARGIN * 2)) / 2)
  layer:ignoreAnchorPointForPosition(false)
  layer:setAnchorPoint(0, 0)
  local colorLayer = tolua.cast(tip, "cc.LayerColor")
  colorLayer:setName("word")
  layer:addChild(colorLayer)
  return layer
end
function AnnouncementDlg:onUpdate()
  if actionTips[1] == nil then
    return
  end
  text_width = actionTips[1]:getContentSize()
  if text_width == nil then
    return
  end
  if gf:getServerTime() - actionTips[1].addTime > KEEP_TIME * 60 then
    actionTips[1]:removeFromParent(true)
    table.remove(actionTips, 1)
    i = 0
    if actionTips[1] == nil then
      AnnouncementDlg:close()
    end
    return
  end
  local x, y = actionTips[1]:getPosition()
  local w = x - MOVE
  actionTips[1]:setPosition(w, y)
  if x < -text_width.width - MOVE * 30 then
    local panelCtrl = self.notePanel
    actionTips[1]:setPosition(panelCtrl:getContentSize().width, actionTips[1]:getPositionY())
    i = i + 1
    if i == NORMAL_TIMES then
      actionTips[1]:removeFromParent(true)
      table.remove(actionTips, 1)
      i = 0
      if actionTips[1] == nil then
        AnnouncementDlg:close()
      end
    end
  end
end
function AnnouncementDlg:addHornMagic()
  self:removeHornMagic()
  local root = self:getControl("MainPanel")
  local magic = ArmatureMgr:createArmature(ResMgr.ArmatureMagic.announcement_horn.name)
  local rootSize = root:getContentSize()
  local pos = cc.p(HORN_OFFSET_X, rootSize.height / 2)
  magic:setPosition(pos)
  root:addChild(magic)
  magic:getAnimation():play(ResMgr.ArmatureMagic.announcement_horn.action)
  magic:setTag(HORN_MAGIC_TAG)
end
function AnnouncementDlg:removeHornMagic()
  local panel = self:getControl("MainPanel")
  if not panel then
    return
  end
  local magic = panel:getChildByTag(HORN_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
    magic = nil
  end
end
return AnnouncementDlg
