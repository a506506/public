local FamousRedBagDlg = Singleton("FamousRedBagDlg", Dialog)
function FamousRedBagDlg:init()
  self:bindListener("NoteButton", self.onNoteButton)
  self:bindListener("DelAllButton", self.onDelAllButton)
  self:bindListener("StartButton", self.onStartButton)
  self:bindFloatPanelListener("RulePanel")
  self:bindEditFieldForSafe("MessageInputPanel", 20, "DelAllButton", cc.VERTICAL_TEXT_ALIGNMENT_TOP, nil, true)
  if gf:isLimitChangeUserInfo(true) then
    self:setCtrlTouchEnabled("TextField", false)
    self:setCtrlTouchEnabled("WritePanel", true)
    self:setCtrlVisible("WritePanel", true)
    self:bindListener("WritePanel", function()
      gf:isLimitChangeUserInfo()
    end)
  end
  self:hookMsg("MSG_ENTER_ROOM")
end
function FamousRedBagDlg:setData(data)
  local root = self:getControl("SettingPanel")
  local mapPanel = self:getControl("PlacePanel", nil, root)
  self:setLabelText("PlaceLabel", string.format(CHS[7100800], MapMgr:getCurrentMapName()), mapPanel)
  self:setCtrlVisible("NoLabel", data.is_map_open == 0, mapPanel)
  local timePanel = self:getControl("TimePanel", nil, root)
  self:refreshTimePanel()
  self:setCtrlVisible("NoLabel", data.is_time_open == 0, timePanel)
  if not string.isNilOrEmpty(data.text) then
    self:setInputText("TextField", gf:filtTextOnly(data.text), "MessageInputPanel")
    self:setCtrlVisible("DefaultLabel", false, "MessageInputPanel")
  end
end
function FamousRedBagDlg:refreshTimePanel()
  local timePanel = self:getControl("TimePanel", nil, root)
  local timeStr = gf:getServerDate(CHS[7100801], gf:getServerTime(), timePanel)
  self:setLabelText("TimeLabel", timeStr, timePanel)
  performWithDelay(self.root, function()
    self:refreshTimePanel()
  end, 60)
end
function FamousRedBagDlg:onNoteButton(sender, eventType)
  self:setCtrlVisible("RulePanel", true)
end
function FamousRedBagDlg:onDelAllButton(sender, eventType)
  local parentPanel = sender:getParent()
  local textCtrl = self:getControl("TextField", nil, parentPanel)
  textCtrl:setText("")
  sender:setVisible(false)
  self:setCtrlVisible("DefaultLabel", true, "MessageInputPanel")
end
function FamousRedBagDlg:onStartButton(sender, eventType)
  if self:checkSafeLockRelease("onStartButton") then
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  if Me:isInCombat() then
    gf:ShowSmallTips(CHS[3003433])
    return
  end
  if Me:isLookOn() then
    gf:ShowSmallTips(CHS[3002640])
    return
  end
  if GameMgr:IsCrossDist() then
    gf:ShowSmallTips(CHS[7100802])
    return
  end
  local msg = self:getInputText("TextField", "MessageInputPanel")
  if string.isNilOrEmpty(msg) then
    msg = self:getLabelText("DefaultLabel", "MessageInputPanel")
  end
  local msg, isFilt = gf:filtText(msg, Me:queryBasic("gid"), true, nil, true)
  if isFilt then
    self:setInputText("TextField", msg, "MessageInputPanel")
    gf:ShowSmallTips(CHS[2300065])
    return
  end
  gf:CmdToServer("CMD_OPEN_FAMOUS_RED_BAG", {text = msg})
end
function FamousRedBagDlg:MSG_ENTER_ROOM()
  DlgMgr:closeDlg(self.name)
  DlgMgr:closeDlg("ConfirmDlg")
end
function FamousRedBagDlg:onClickBlank()
  return true
end
return FamousRedBagDlg
