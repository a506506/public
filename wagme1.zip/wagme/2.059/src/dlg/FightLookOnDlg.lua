local FightLookOnDlg = Singleton("FightLookOnDlg", Dialog)
local NEED_SHOW_ESCAPE_TYPE = {
  [COMBAT_MODE.COMBAT_MODE_LCHJ] = 1,
  [COMBAT_MODE.COMBAT_MODE_DCDH] = 2
}
function FightLookOnDlg:init()
  self:bindListener("ExitButton", self.onExitButton)
  self:bindListener("SkipButton", self.onSkipButton)
  self:bindListener("EscapeButton", self.onEscapeButton)
  self:setFullScreen()
  self:setCtrlVisible("ExitButton", true)
  self:setCtrlVisible("SkipButton", false)
  self:setCtrlVisible("EscapeButton", false)
  self:hookMsg("MSG_SHOW_LOOKON_ESCAPE")
end
function FightLookOnDlg:swicthSkipModel()
  self:setCtrlVisible("ExitButton", false)
  self:setCtrlVisible("SkipButton", true)
end
function FightLookOnDlg:onExitButton(sender, eventType)
  FightMgr:cmdQuitLookOn()
end
function FightLookOnDlg:onSkipButton(sender, eventType)
  FightMgr:cmdSkipLookOn()
end
function FightLookOnDlg:onEscapeButton(sender, eventType)
  if FightMgr.combatMode and NEED_SHOW_ESCAPE_TYPE[FightMgr.combatMode] then
    gf:confirm(CHS[7150277], function()
      FightMgr:cmdEscapeLookOn(NEED_SHOW_ESCAPE_TYPE[FightMgr.combatMode])
    end)
  end
end
function FightLookOnDlg:MSG_SHOW_LOOKON_ESCAPE(data)
  self:setCtrlVisible("EscapeButton", true)
end
return FightLookOnDlg
