local ChildDailyMission5Dlg = require("dlg/ChildDailyMission5Dlg")
local DiGongMonkeyGhostDlg = Singleton("DiGongMonkeyGhostDlg", ChildDailyMission5Dlg)
local PartMap = require("obj/PartMap")
local SHAPE_ICON = {
  10001,
  10002,
  10003,
  10004,
  10005,
  11001,
  11002,
  11003,
  11004,
  11005
}
function DiGongMonkeyGhostDlg:getCfgFileName()
  return ResMgr:getDlgCfg("ChildDailyMission5Dlg")
end
function DiGongMonkeyGhostDlg:init(data)
  self.result = nil
  self:setCtrlFullClient("PlacePanel")
  local mapPanel = self:getControl("PlacePanel")
  mapPanel:setVisible(true)
  local size = mapPanel:getContentSize()
  local partMap = PartMap.new(17200, 22, 32, size, true)
  local mapSize = partMap:getContentSize()
  local x = mapSize.width - size.width
  partMap:setPosition(-80, -size.height * 0.5 - 100)
  mapPanel:addChild(partMap)
  local colorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 153))
  colorLayer:setContentSize(size)
  mapPanel:addChild(colorLayer)
  ChildDailyMission5Dlg.init(self, data)
  self:initMonkeyGhost()
  self:hookMsg("MSG_DIGONG_GAME_RESULT")
end
function DiGongMonkeyGhostDlg:beginRun()
  self.isGuss = false
  for _, char in pairs(self.objectList) do
    char:setBasic("icon", self.data.child_icon)
    char.charAction:setIcon(self.data.child_icon)
    char:setAct(Const.FA_STAND)
    char:addMagicOnWaist(ResMgr.magic.grey_fog, false, nil, nil, nil, function()
    end)
    if char:queryBasicInt("myChild") == 1 then
      char:setChat({
        msg = CHS[4101503],
        show_time = 2
      }, nil, true)
    end
  end
  performWithDelay(self.root, function()
    self:everyBabyRun()
  end, 2)
end
function DiGongMonkeyGhostDlg:getIconList()
  local shapeIcon = gf:deepCopy(SHAPE_ICON)
  for _, icon in pairs(shapeIcon) do
    if icon == self.data.child_icon then
      table.remove(shapeIcon, _)
    end
  end
  local pool = {}
  table.insert(pool, self.data.child_icon)
  for i = 1, 5 do
    local ran = math.random(1, #shapeIcon)
    table.insert(pool, shapeIcon[ran])
    table.remove(shapeIcon, ran)
  end
  local ret = {}
  for i = 1, 6 do
    local ran = math.random(1, #pool)
    table.insert(ret, pool[ran])
    table.remove(pool, ran)
  end
  return ret
end
function DiGongMonkeyGhostDlg:initChildNpc()
  local iconList = self:getIconList()
  self.objectList = {}
  for i = 1, #self:getNpcPos() do
    local info = {
      icon = iconList[i],
      name = CHS[4200831],
      dir = 5,
      life = 150
    }
    if iconList[i] == self.data.child_icon then
      info.myChild = 1
    end
    local char = self:createChar(info, self:getNpcPos()[i])
    char:setMoveSpeed(0.8)
    char.flag = i
    table.insert(self.objectList, char)
  end
  local info = {
    icon = Me:queryBasicInt("org_icon"),
    name = Me:queryBasic("name"),
    dir = 1
  }
  local x, y = self:getControl("MyPanel"):getPosition()
  self.char = self:createChar(info, cc.p(x, y))
end
function DiGongMonkeyGhostDlg:initMonkeyGhost()
  self:setLabelText("Label_0", CHS[4200832])
  self:setCtrlVisible("RoundPanel", false)
end
function DiGongMonkeyGhostDlg:onCloseButton()
  if self.isResulting then
    DlgMgr:closeDlg(self.name)
    gf:CmdToServer("CMD_DIGONG_QUIT_GAME", {game_type = 1})
    return
  end
  gf:confirm(CHS[4200833], function()
    DlgMgr:closeDlg(self.name)
    gf:CmdToServer("CMD_DIGONG_QUIT_GAME", {game_type = 1})
  end)
end
function DiGongMonkeyGhostDlg:beginRun()
  self.isGuss = false
  for _, char in pairs(self.objectList) do
    char:setBasic("icon", self.data.child_icon)
    char.charAction:setIcon(self.data.child_icon)
    char:setAct(Const.FA_STAND)
    char:addMagicOnWaist(ResMgr.magic.grey_fog, false)
    if char:queryBasicInt("myChild") == 1 then
      char:setChat({
        msg = CHS[4200834],
        show_time = 2
      }, nil, true)
    end
  end
  performWithDelay(self.root, function()
    self:everyBabyRun()
  end, 2)
end
function DiGongMonkeyGhostDlg:gussMyChild()
  self.isGuss = true
  local map = {
    1,
    2,
    3,
    4,
    5,
    6
  }
  local ran = math.random(1, #map)
  self.objectList[map[ran]]:setChat({
    msg = CHS[4200835],
    show_time = 3
  }, nil, true)
  table.remove(map, ran)
  local ran = math.random(1, #map)
  self.objectList[map[ran]]:setChat({
    msg = CHS[4200835],
    show_time = 3
  }, nil, true)
end
function DiGongMonkeyGhostDlg:resetGame()
  self:nextGuank(1)
  self.isWin = false
end
function DiGongMonkeyGhostDlg:onChooseButton(sender, eventType)
  if self.isWin then
    return
  end
  self.isSelected = true
  local tag = sender:getTag()
  local selectChar
  for i = 1, 6 do
    if self.objectList[i].flag == tag then
      selectChar = self.objectList[i]
    end
  end
  if selectChar:queryBasicInt("myChild") == 1 then
    selectChar:setChat({
      msg = CHS[4200836],
      show_time = 3
    }, nil, true)
    if self.guanka == 1 then
      local panel = self:getControl("CharPanel" .. tag)
      local x, y = panel:getPosition()
      self.char:setEndPos(x + 50, y - 30, nil, 1)
      performWithDelay(self.root, function()
        self.guanka = self.guanka + 1
        self:nextGuank(self.guanka)
      end, 2)
    else
      performWithDelay(self.root, function()
        self.guanka = self.guanka + 1
        self:nextGuank(self.guanka)
      end, 2)
    end
  else
    local key = gfEncrypt(0, self.gameData.encrypt_id)
    gf:CmdToServer("CMD_DIGONG_FINISH_GAME", {game_type = 1, key = key})
    self.result = 0
    selectChar:setChat({
      msg = CHS[4200837],
      show_time = 3
    }, nil, true)
  end
  self:setChoosePanelVisible(false)
end
function DiGongMonkeyGhostDlg:setGameData(data)
  self.gameData = data
end
function DiGongMonkeyGhostDlg:nextGuank(guanka)
  self.guanka = guanka
  if guanka > 1 then
    local key = gfEncrypt(1, self.gameData.encrypt_id)
    gf:CmdToServer("CMD_DIGONG_FINISH_GAME", {game_type = 1, key = key})
    self.isWin = true
    self.result = 1
    return
  end
  self:updateGuanka()
  self:cleanAllChild()
  self:initChildNpc()
  self.times = 0
  self:beginRun()
end
function DiGongMonkeyGhostDlg:everyBabyRun()
  ChildDailyMission5Dlg.everyBabyRun(self, CHS[4200838])
end
function DiGongMonkeyGhostDlg:MSG_DIGONG_GAME_RESULT(data)
  if data.game_type ~= 1 then
    return
  end
  data.result = self.result
  DlgMgr:openDlgEx("UndergroundGameResultDlg", data)
end
function DiGongMonkeyGhostDlg:cleanup()
  gf:CmdToServer("CMD_DIGONG_QUIT_GAME", {game_type = 1})
  ChildDailyMission5Dlg.cleanup(self)
end
return DiGongMonkeyGhostDlg
