local AchievementListDlg = Singleton("AchievementListDlg", Dialog)
local BIG_MENU = {
  CHS[4100797],
  CHS[4100798],
  CHS[4100799],
  CHS[4100800],
  CHS[4100801],
  CHS[4100802],
  CHS[4100803]
}
local SMALL_MENU = {
  [CHS[4100798]] = {
    CHS[4100804],
    CHS[6000164],
    CHS[4100805],
    CHS[4100806],
    CHS[6000080],
    CHS[5401001]
  },
  [CHS[4100799]] = {
    CHS[4100807],
    CHS[4100808]
  },
  [CHS[4100800]] = {
    CHS[7002314],
    CHS[7002313],
    CHS[7000144],
    CHS[7190683]
  },
  [CHS[4100801]] = {
    CHS[7002308],
    CHS[6000149],
    CHS[4100809],
    CHS[7150017]
  },
  [CHS[4100802]] = {
    CHS[4100810],
    CHS[4100811],
    CHS[4100813]
  },
  [CHS[4100803]] = {
    CHS[4100814],
    CHS[4100815]
  }
}
local FINISH_MAP = {
  [CHS[4100826]] = 1,
  [CHS[4100827]] = 2,
  [CHS[4100828]] = 3
}
local CHANNEL_MAP = {
  1,
  2,
  5,
  4,
  9
}
local PAGE_UNIT_COUNT = 12
function AchievementListDlg:init(defaultId)
  self:bindListener("RewardButton", self.onRewardButton)
  self:bindListener("ChoseButton", self.onChoseButton)
  self:bindListener("AllButton", self.onSelectAchieveType)
  self:bindListener("CompleteButton", self.onSelectAchieveType)
  self:bindListener("UnfinishButton", self.onSelectAchieveType)
  self:bindListener("ShareButton_1", self.onShareButton_1)
  for i = 1, 5 do
    local bth = self:getControl("ShareButton_" .. i, nil, "TotalShareListPanel")
    bth:setTag(CHANNEL_MAP[i])
    self:bindTouchEndEventListener(bth, self.onShareButton_1)
    local bth = self:getControl("ShareButton_" .. i, nil, "SingleShareListPanel")
    bth:setTag(CHANNEL_MAP[i])
    self:bindTouchEndEventListener(bth, self.onShareButton_1)
  end
  self:initClone()
  self:bindFloatPanelListener("TotalShareListPanel")
  self:bindFloatPanelListener("SingleShareListPanel")
  self:bindFloatPanelListener("ChoseListPanel")
  if not self.lastCloseTime then
    self.lastCloseTime = {}
  end
  if not self.lastCloseTime[Me:queryBasic("gid")] or gfGetTickCount() - self.lastCloseTime[Me:queryBasic("gid")] > 150000 then
    self.oneMenu = nil
    self.twoMenu = nil
    self.lastCloseTime = {}
  end
  if defaultId then
    local cateStr = AchievementMgr:getRawKeyById(defaultId)
    local menuTab = gf:split(cateStr, "-")
    self.oneMenu = menuTab[1]
    self.twoMenu = menuTab[2]
  end
  self.defaultId = defaultId
  self.selectId = nil
  self.data = nil
  self:initMenu()
  self:hookMsg("MSG_ACHIEVE_VIEW")
  RedDotMgr:removeOneRedDot("GameFunctionDlg", "AchievementButton")
  local data = AchievementMgr.achieveOverViewData
  self:setData(data)
  self:bindListViewByPageLoad("ListView", "TouchPanel", function(dlg, percent)
    if percent > 100 then
      local ret = self:getShowData()
      local list = self:getControl("ListView", nil, "ListPanel")
      self:setListData(list, ret)
    end
  end, "ListPanel")
  self:bindListViewByPageLoad("ListView", "TouchPanel", function(dlg, percent)
    if percent > 100 then
      local ret = self:getShowData()
      local list = self:getControl("ListView", nil, "RecentlyPanel")
      self:setListData(list, ret)
    end
  end, "RecentlyPanel")
end
function AchievementListDlg:initClone()
  self.bigPanel = self:retainCtrl("BigPanel")
  self.selectBigEff = self:retainCtrl("BChosenEffectImage", self.bigPanel)
  self:bindTouchEndEventListener(self.bigPanel, self.onSelectBigMenuButton)
  self.smallPanel = self:retainCtrl("SmallPanel")
  self.selectSmallEff = self:retainCtrl("SChosenEffectImage", self.smallPanel)
  self:bindTouchEndEventListener(self.smallPanel, self.onSelectSmallMenuButton)
  self.unitAchieve = self:retainCtrl("ListPanel_1")
  self:bindTouchEndEventListener(self.unitAchieve, self.onSelectAcheveButton)
  self:bindListener("ShareButton", self.onShareButton, self.unitAchieve)
  self.unitExpandBar = self:retainCtrl("TipPanel_2", nil, "ListPanel_2")
  self.unitExpandTarget = self:retainCtrl("TipPanel_3", nil, "ListPanel_2")
  self.unitExpandReward = self:retainCtrl("TipPanel_4", nil, "ListPanel_2")
  self.unitExpandFinishTime = self:retainCtrl("TipPanel_5", nil, "ListPanel_2")
  self.unitAchieveExpand = self:retainCtrl("ListPanel_2")
end
function AchievementListDlg:initMenu()
  local list = self:resetListView("CategoryListView")
  list:setBounceEnabled(false)
  for i = 1, #BIG_MENU do
    local btn = self.bigPanel:clone()
    btn:setTag(i * 100)
    btn:setName(BIG_MENU[i])
    self:setLabelText("Label", BIG_MENU[i], btn)
    list:pushBackCustomItem(btn)
    self:setArrow(btn)
    if self.oneMenu == BIG_MENU[i] then
      self:onSelectBigMenuButton(btn)
    end
    if not self.oneMenu then
      self:onSelectBigMenuButton(btn)
    end
  end
end
function AchievementListDlg:onSelectBigMenuButton(sender, eventType)
  self.root:stopAllActions()
  if self.oneMenu == sender:getName() and sender.isExp then
    self:removeAllSecondMenu()
    return
  end
  if self.oneMenu ~= sender:getName() then
    self.twoMenu = nil
  end
  self.oneMenu = sender:getName()
  self:addEffBigMenu(sender)
  self:removeAllSecondMenu()
  self:setCtrlVisible("TotalPanel", sender:getName() == CHS[4100797])
  self:setCtrlVisible("SinglePanel", sender:getName() ~= CHS[4100797])
  if not SMALL_MENU[sender:getName()] then
    self:setLastChieve(AchievementMgr.achieveOverViewData)
  elseif self.oneMenu == CHS[4100824] then
    if not self.twoMenu then
      self.twoMenu = CHS[4100814]
    end
    local key = string.format("%s-%s", self.oneMenu, self.twoMenu)
    local tData = AchievementMgr.achieveData[key]
    if not tData then
      local cType = AchievementMgr.CATEGORY[self.oneMenu]
      AchievementMgr:queryAchieveByCategory(cType)
    else
      self:addSecondMenu(sender)
    end
  else
    self:addSecondMenu(sender)
    local key = string.format("%s-%s", self.oneMenu, self.twoMenu)
    local tData = AchievementMgr.achieveData[key]
    if not tData then
      local cType = AchievementMgr.CATEGORY[self.oneMenu]
      AchievementMgr:queryAchieveByCategory(cType)
    end
  end
end
function AchievementListDlg:addEffSmallMenu(sender)
  self.selectSmallEff:removeFromParent()
  sender:addChild(self.selectSmallEff)
end
function AchievementListDlg:onSelectSmallMenuButton(sender, eventType)
  self.root:stopAllActions()
  self:addEffSmallMenu(sender)
  self.twoMenu = sender:getName()
  self:setTwoData()
end
function AchievementListDlg:setTwoData()
  local panel = self:getControl("ChosePanel")
  self:setLabelText("NameLabel", self.twoMenu, panel)
  local key = string.format("%s-%s", self.oneMenu, self.twoMenu)
  local data = AchievementMgr.achieveSecondData[key]
  self:setLabelText("CompleteLabel", string.format(CHS[4100829], data.task, data.task_max), panel)
  self:setProcessBarByAchievement(data.point or 0, data.point_max, "TotalAchievePanel", panel)
  local fType = FINISH_MAP[self:getLabelText("ChoseLabel", "ChoseButton")]
  local ret = self:getSingleAchieveData(key, fType)
  if ret and next(ret) then
    table.sort(ret, function(l, r)
      if l.order < r.order then
        return true
      end
      if l.order > r.order then
        return false
      end
    end)
  end
  self:setAchieveList(ret, "ListPanel")
end
function AchievementListDlg:getSingleAchieveData(key, finishType)
  local tData = AchievementMgr.achieveData[key]
  if not tData then
    return
  end
  local finishData = {}
  local notFinishData = {}
  if finishType == 1 then
    return tData
  else
    for _, uData in pairs(tData) do
      if uData.is_finished == 1 then
        table.insert(finishData, uData)
      else
        table.insert(notFinishData, uData)
      end
    end
  end
  if finishType == 2 then
    return finishData
  else
    return notFinishData
  end
end
function AchievementListDlg:cleanup()
  AchievementMgr:clearData()
  AchievementMgr:setDefaultSelectId()
  if not self.lastCloseTime then
    self.lastCloseTime = {}
  end
  self.lastCloseTime[Me:queryBasic("gid")] = gfGetTickCount()
end
function AchievementListDlg:addSecondMenu(sender)
  if not SMALL_MENU[sender:getName()] then
    return
  end
  local list = self:getControl("CategoryListView")
  local menuData = gf:deepCopy(SMALL_MENU[sender:getName()])
  if self.isExsitJBCJ and sender:getName() == CHS[4100824] then
    table.insert(menuData, CHS[4100942])
  end
  sender.isExp = true
  self:setArrow(sender)
  for i = 1, #menuData do
    local smallMenu = self.smallPanel:clone()
    self:setLabelText("Label", menuData[i], smallMenu)
    smallMenu:setName(menuData[i])
    list:insertCustomItem(smallMenu, math.floor(sender:getTag() / 100) + i - 1)
    if not self.twoMenu or self.twoMenu == menuData[i] then
      self:onSelectSmallMenuButton(smallMenu)
    end
  end
  list:requestRefreshView()
end
function AchievementListDlg:removeAllSecondMenu()
  local list = self:getControl("CategoryListView")
  local items = list:getItems()
  for _, panel in pairs(items) do
    if panel:getTag() % 100 ~= 0 then
      list:removeChild(panel)
    else
      panel.isExp = false
      if not panel.secondMenu or panel.secondMenu.count == 0 then
        self:setArrow(panel)
      else
        self:setArrow(panel)
      end
    end
  end
  list:requestRefreshView()
end
function AchievementListDlg:setArrow(sender)
  if SMALL_MENU[sender:getName()] then
    if sender.isExp then
      self:setCtrlVisible("DownArrowImage", false, sender)
      self:setCtrlVisible("UpArrowImage", true, sender)
    else
      self:setCtrlVisible("DownArrowImage", true, sender)
      self:setCtrlVisible("UpArrowImage", false, sender)
    end
  else
    self:setCtrlVisible("DownArrowImage", false, sender)
    self:setCtrlVisible("UpArrowImage", false, sender)
  end
end
function AchievementListDlg:addEffBigMenu(sender)
  self.selectBigEff:removeFromParent()
  sender:addChild(self.selectBigEff)
end
function AchievementListDlg:setProcessBarByAchievement(cur, max, panelName, root)
  local panel = self:getControl(panelName, nil, root)
  self:setProgressBar("ProgressBar", cur, max, panel)
  self:setLabelText("ValueLabel", string.format("%d/%d", cur, max), panel)
  self:setLabelText("ValueLabel_1", string.format("%d/%d", cur, max), panel)
end
function AchievementListDlg:setTotalView(data)
  self:setProcessBarByAchievement(data.total, data.total_max, "TotalAchievePanel", "TotalPanel")
  local category = AchievementMgr.CATEGORY.AHVE_CG_RWCZ
  self:setProcessBarByAchievement(data.category[category].category_total, data.category[category].category_total_max, "PersonPanel", "TotalPanel")
  category = AchievementMgr.CATEGORY.AHVE_CG_HBPY
  self:setProcessBarByAchievement(data.category[category].category_total, data.category[category].category_total_max, "FriendsPanel", "TotalPanel")
  category = AchievementMgr.CATEGORY.AHVE_CG_ZBDZ
  self:setProcessBarByAchievement(data.category[category].category_total, data.category[category].category_total_max, "EquipPanel", "TotalPanel")
  category = AchievementMgr.CATEGORY.AHVE_CG_RWSJ
  self:setProcessBarByAchievement(data.category[category].category_total, data.category[category].category_total_max, "SocietyPanel", "TotalPanel")
  category = AchievementMgr.CATEGORY.AHVE_CG_RWHD
  self:setProcessBarByAchievement(data.category[category].category_total, data.category[category].category_total_max, "TaskPanel", "TotalPanel")
  category = AchievementMgr.CATEGORY.AHVE_CG_ZZYS
  self:setProcessBarByAchievement(data.category[category].category_total, data.category[category].category_total_max, "AnecdotePanel", "TotalPanel")
end
function AchievementListDlg:onRewardButton(sender, eventType)
  if not self.data then
    return
  end
  local dlg = DlgMgr:openDlg("AchievementRewardDlg")
  dlg:setData(AchievementMgr.achieveOverViewData or self.data)
end
function AchievementListDlg:onShareButton(sender, eventType)
  self.selectId = sender:getParent():getParent().data.achieve_id
  if self.oneMenu == CHS[4100797] then
    self:setCtrlVisible("TotalShareListPanel", true)
  else
    self:setCtrlVisible("SingleShareListPanel", true)
  end
end
function AchievementListDlg:onShareButton_1(sender, eventType)
  local achieve = AchievementMgr:getAchieveInfoById(self.selectId)
  local tag = sender:getTag()
  local sendInfo = string.format("{\t%s=%s=%s}", achieve.name, CHS[4100818], self.selectId)
  local showInfo = string.format(string.format("{\029%s\029}", achieve.name))
  DlgMgr:reorderDlgByName("ChannelDlg")
  if sender:getTag() == CHAT_CHANNEL.FRIEND then
    DlgMgr:openDlgWithParam(string.format("ChannelDlg=%d", tag))
    gf:ShowSmallTips(CHS[4100850])
    local copyInfo = string.format("{%s}", achieve.name)
    gf:copyTextToClipboardEx(copyInfo, {
      copyInfo = copyInfo,
      showInfo = showInfo,
      sendInfo = sendInfo
    })
    return
  end
  sender:getParent():getParent():getParent():setVisible(false)
  DlgMgr:openDlgWithParam(string.format("ChannelDlg=%d", tag))
  DlgMgr:sendMsg("ChannelDlg", "setChannelInputChat", tag, "addCardInfo", sendInfo, showInfo)
end
function AchievementListDlg:onChoseButton(sender, eventType)
  self:setCtrlVisible("ChoseListPanel", true)
end
function AchievementListDlg:onSelectAchieveType(sender, eventType)
  local text = self:getLabelText("Label_90", sender)
  self:setLabelText("ChoseLabel", text, "ChoseButton")
  self:setCtrlVisible("ChoseListPanel", false)
  local fType = FINISH_MAP[self:getLabelText("ChoseLabel", "ChoseButton")]
  if text == CHS[4100827] then
    self:setLabelText("Label_66", CHS[5410157], "ListPanel")
  elseif text == CHS[4100828] then
    self:setLabelText("Label_66", CHS[5410158], "ListPanel")
  end
  self:setTwoData()
end
function AchievementListDlg:setAchieveList(data, root)
  self.startIdx = 1
  self.curMenuData = data
  local list = self:resetListView("ListView", 5, nil, root)
  list.panelIndex = 0
  if not data then
    self:setCtrlVisible("TipsImage", false, root)
    self:setCtrlVisible("Label_66", false, root)
    return
  elseif not next(data) then
    self:setCtrlVisible("TipsImage", true, root)
    self:setCtrlVisible("Label_66", true, root)
    return
  end
  self:setCtrlVisible("TipsImage", false, root)
  self:setCtrlVisible("Label_66", false, root)
  local ret = self:getShowData()
  self:setListData(list, ret)
end
function AchievementListDlg:setListData(list, data)
  if not data or #data == 0 then
    return
  end
  local innerContainer = list:getInnerContainerSize()
  local num = #list:getItems() + #data
  innerContainer.height = num * self.unitAchieve:getContentSize().height + (num - 1) * 5
  list:setInnerContainerSize(innerContainer)
  for _, unitData in pairs(data) do
    local unitPanel = self.unitAchieve:clone()
    unitPanel:setTag((list.panelIndex + 1) * 100)
    self:setUnitAchievePanel(unitData, unitPanel)
    list:pushBackCustomItem(unitPanel)
    list.panelIndex = list.panelIndex + 1
  end
  list:requestRefreshView()
  if self.defaultId then
    local items = list:getItems()
    for _, panel in pairs(items) do
      if panel.data.achieve_id == self.defaultId then
        self:setListInnerPosByIndex(list, _)
        self:onSelectAcheveButton(panel)
      end
    end
  end
end
function AchievementListDlg:getShowData()
  local ret = {}
  if self.defaultId then
    for i = 1, #self.curMenuData do
      table.insert(ret, self.curMenuData[i])
      if self.defaultId == self.curMenuData[i].achieve_id then
        self.startIdx = i + 1
        break
      end
    end
  end
  local limitCount = math.min(self.startIdx + PAGE_UNIT_COUNT - 1, #self.curMenuData)
  for i = self.startIdx, limitCount do
    table.insert(ret, self.curMenuData[i])
  end
  self.startIdx = self.startIdx + PAGE_UNIT_COUNT
  return ret
end
function AchievementListDlg:setUnitAchievePanel(data, panel)
  local achieve = AchievementMgr:getAchieveInfoById(data.achieve_id)
  self:setLabelText("NameLabel", achieve.name, panel)
  self:setLabelText("DescLabel", string.format(achieve.achieve_desc, achieve.progress), panel)
  self:setImage("GuardImage", AchievementMgr:getIconById(data.achieve_id), panel)
  AchievementMgr:addJBCJImageByCategory(self:getControl("GuardImage", nil, panel), data.category)
  self:setLabelText("AchieveLabel", achieve.point, panel)
  self:setCtrlVisible("CompleteImage", data.is_finished == 1, panel)
  self:setCtrlVisible("RewardImage", achieve.bonus_desc ~= "", panel)
  panel.data = data
  panel.achieve = achieve
end
function AchievementListDlg:onSelectAcheveButton(sender, eventType)
  local list = sender:getParent():getParent()
  if sender.isExpand then
    local items = list:getItems()
    for _, panel in pairs(items) do
      panel.isExpand = false
      if panel:getTag() % 100 ~= 0 then
        list:removeChild(panel)
      end
    end
    list:refreshView()
    return
  end
  local items = list:getItems()
  for _, panel in pairs(items) do
    panel.isExpand = false
    if panel:getTag() % 100 ~= 0 then
      list:removeChild(panel)
    end
  end
  local unitPanel = self.unitAchieveExpand:clone()
  local pos = math.floor(sender:getTag() / 100)
  unitPanel:setTag(sender:getTag() + 1)
  self:setExpandPanel(sender, unitPanel)
  list:insertCustomItem(unitPanel, pos)
  sender.expHeight = unitPanel:getContentSize().height
  sender.isExpand = true
  list:refreshView()
  local y = self:getListItemIsInScreen(list, unitPanel, 5)
  if y then
    list:getInnerContainer():setPositionY(y)
  end
end
function AchievementListDlg:getListItemIsInScreen(listView, dPanel, margin)
  if not listView then
    return
  end
  margin = margin or 0
  local height = -1
  local items = listView:getItems()
  for _, panel in pairs(items) do
    if height >= 0 then
      height = height + margin
      height = height + panel:getContentSize().height
    end
    if dPanel == panel then
      height = 0
    end
  end
  if height < math.abs(listView:getInnerContainer():getPositionY()) then
    return -height
  end
end
function AchievementListDlg:setExpandPanel(sender, panel)
  local UNIT_HEIGHT = 49
  local panelCount = 0
  local data = sender.data
  local achieve = AchievementMgr:getAchieveInfoById(data.achieve_id)
  if string.match(achieve.achieve_desc, "%%d") then
    panelCount = panelCount + 1
  end
  if 0 < achieve.target_count then
    panelCount = panelCount + math.ceil(achieve.target_count / 3)
  end
  if achieve.bonus_desc ~= "" then
    panelCount = panelCount + 1
  end
  panelCount = panelCount + 1
  local sz = panel:getContentSize()
  panel:setContentSize(sz.width, UNIT_HEIGHT * panelCount)
  local bkImage = self:getControl("PanelBKImage", nil, panel)
  bkImage:setContentSize(sz.width, UNIT_HEIGHT * panelCount)
  bkImage:setPosition(0, 5)
  local startPosY = UNIT_HEIGHT * (panelCount - 1)
  if string.match(achieve.achieve_desc, "%%d") then
    local barPanel = self.unitExpandBar:clone()
    if data.is_finished == 0 then
      self:setProgressBar("ProgressBar", data.progress_or_time, data.progress, barPanel)
      self:setLabelText("ValueLabel", string.format("%d/%d", data.progress_or_time, data.progress), barPanel)
      self:setLabelText("ValueLabel_1", string.format("%d/%d", data.progress_or_time, data.progress), barPanel)
    else
      self:setProgressBar("ProgressBar", achieve.progress, achieve.progress, barPanel)
      self:setLabelText("ValueLabel", string.format("%d/%d", achieve.progress, achieve.progress), barPanel)
      self:setLabelText("ValueLabel_1", string.format("%d/%d", achieve.progress, achieve.progress), barPanel)
    end
    panel:addChild(barPanel)
    barPanel:setPosition(cc.p(0, startPosY))
    startPosY = startPosY - UNIT_HEIGHT
  end
  local targetData = data
  if data.is_finished == 1 then
    targetData = achieve
    for i = 1, targetData.target_count do
      targetData.target_list[i].is_finished = true
    end
  end
  if 0 < targetData.target_count then
    local row = math.ceil(targetData.target_count / 3)
    for i = 1, row do
      local targetPanel = self.unitExpandTarget:clone()
      for j = 1, 3 do
        local info = targetData.target_list[(i - 1) * 3 + j]
        if info then
          self:setCtrlVisible("FinishImage" .. j, info.is_finished, targetPanel)
          if info.is_finished then
            self:setLabelText("DescLabel_" .. j, info.des, targetPanel, COLOR3.GREEN)
          else
            self:setLabelText("DescLabel_" .. j, info.des, targetPanel, COLOR3.GRAY)
          end
        else
          self:setCtrlVisible("FinishImage" .. j, false, targetPanel)
          self:setLabelText("DescLabel_" .. j, info.des, targetPanel, COLOR3.GRAY)
        end
      end
      panel:addChild(targetPanel)
      targetPanel:setPosition(cc.p(0, startPosY))
      startPosY = startPosY - UNIT_HEIGHT
    end
  end
  if achieve.bonus_desc ~= "" then
    local rewardPanel = self.unitExpandReward:clone()
    local classList = TaskMgr:getRewardList(achieve.bonus_desc)
    local content = string.match(classList[1][1][2], "#r(.+)")
    self:setLabelText("RewardLabel", content, rewardPanel)
    panel:addChild(rewardPanel)
    rewardPanel:setPosition(cc.p(0, startPosY))
    startPosY = startPosY - UNIT_HEIGHT
  end
  local timePanel = self.unitExpandFinishTime:clone()
  if data.is_finished == 0 then
    self:setLabelText("TimeLabel_2", CHS[4100831], timePanel)
  else
    self:setLabelText("TimeLabel_2", gf:getServerDate("%Y-%m-%d", data.achieve_time or data.progress_or_time), timePanel)
  end
  panel:addChild(timePanel)
  timePanel:setPosition(cc.p(0, startPosY))
  panel:requestDoLayout()
end
function AchievementListDlg:setData(data)
  if not data then
    return
  end
  self.data = data
  self:setTotalView(data)
  self:setLastChieve(data)
  if data.can_bonus == 0 then
    RedDotMgr:removeOneRedDot("AchievementListDlg", "RewardButton")
  end
end
function AchievementListDlg:setLastChieve(data)
  if not data then
    return
  end
  self:setAchieveList(data.last_achieve, "RecentlyPanel")
end
function AchievementListDlg:MSG_ACHIEVE_VIEW(data)
  if not self.oneMenu then
    return
  end
  if AchievementMgr.CATEGORY[self.oneMenu] ~= data.category then
    return
  end
  if self.oneMenu == CHS[4100824] then
    self.isExsitJBCJ = false
    for i = 1, data.count do
      if AchievementMgr:getAchieveInfoById(data[i].achieve_id).category == AchievementMgr.CATEGORY.AHVE_CG_ZZYS_JB then
        self.isExsitJBCJ = true
      end
    end
    self:addSecondMenu(self:getControl(self.oneMenu))
    local key = string.format("%s-%s", self.oneMenu, self.twoMenu)
    local tData = AchievementMgr.achieveData[key]
    if not tData then
      local cType = AchievementMgr.CATEGORY[self.oneMenu]
      AchievementMgr:queryAchieveByCategory(cType)
    end
  else
    self:setTwoData()
  end
  self.defaultId = nil
end
return AchievementListDlg
