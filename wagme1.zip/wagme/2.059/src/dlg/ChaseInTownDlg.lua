local ChaseInTownDlg = Singleton("ChaseInTownDlg", Dialog)
local CharAction = require("animate/CharAction")
local NumImg = require("ctrl/NumImg")
local GAME_START_COUNT_DOWM = 4
local MOVE_DISTANCE_X = 1920
local MOVE_DISTANCE_Y = 960
local MAP_BLOCK_POS1 = cc.p(0, 0)
local MAP_BLOCK_POS2 = cc.p(MOVE_DISTANCE_X, MOVE_DISTANCE_Y)
local ROAD_BLOCK_SIZE = cc.size(94, 47)
local ROAD_NEXT_DIS = cc.size(82, 41)
local MARGIN_ROAD = 60
local MOVE_ROUND_FRAME = 240
local GRASS_IAMGE_PATH = ResMgr:getMapBlockPathByName(28100, 10039, 1, "")
local FLOOR_IMAGE_PATH = ResMgr:getMapBlockPathByName(28100, "o:10036xiaolufang", 2, "")
local FLOWER_IMAGE_PATH = ResMgr:getFurniturePath(10137)
local LAMP_IMAGE_PATH = ResMgr:getFurniturePath(10020)
local HOUSE_IMAGE_PATH = {
  ResMgr:getMapBlockPathByName(28100, "co:10036fangzi", nil, ""),
  ResMgr:getMapBlockPathByName(28100, "co:10036fangzi02", nil, ""),
  ResMgr:getMapBlockPathByName(28100, "co:10036fangzi03", nil, "")
}
local ITEM_PATH = {
  ResMgr.ui.tanan_mshc_obstacle_stone,
  ResMgr.ui.tanan_mshc_obstacle_palisaide,
  ResMgr:getItemIconPath(10121),
  ResMgr.ui.tanan_mshc_gather_stone,
  ResMgr.ui.tanan_mshc_gather_drug
}
local GATHER_TYPE = {STONE = 4, DRUG = 5}
local OBSTACLE_SPEED_X = 8
local OBSTACLE_SPEED_Y = 4
local BORN_GATHER_PERCENT = 120
local ADD_MINUS_SPEED_TIME = 3
local ADD_MINUS_SPEED_TICK = 90
local OBJ_SPEED_X = 1.2
local OBJ_SPEED_Y = 0.6
local GRASS_ZORDER = 10
local FLOOR_ZORDER = 20
local FLOWER_ZORDER = 30
local HOUSE_ZORDER = 40
local OBSTACLE_ZORDER = 50
local PLAYER_ZORDER = 100
local GAME_TIME = 45
function ChaseInTownDlg:init()
  self:setFullScreen()
  self:bindListener("RuleButton", self.onRuleButton)
  self:bindListener("StoneButton", self.onStoneButton)
  self:bindListener("MedicineButton", self.onMedicineButton)
  self:bindListener("StarButton", self.onStarButton)
  self:setCtrlFullClient("TouchPanel")
  self:bindListener("TouchPanel", self.onTouchPanel, nil, true)
  self.grassPanel = self:retainCtrl("GrassPanel")
  self.roadPanel = self:retainCtrl("RoadPanel")
  self.itemPanel = self:retainCtrl("ItemPanel")
  self.buildingPanel = self:retainCtrl("BuildingPanel")
  self.mapPanel = self:getControl("BackPanel")
  self:setCtrlFullClient("BackPanel")
  self.mapPanel:removeAllChildren()
  self:initMapPanel()
  self.playerPanel = self:getControl("PlayerPanel")
  self:setCtrlFullClient("PlayerPanel")
  self:initPlayer()
  self.gatherPanel = self:retainCtrl("GatherPanel")
  self.gatherPanel:setScale(0.8)
  self:refreshGatherCount()
  self.speedUpTimePanel = self:getControl("SpeedUpTimePanel")
  self.speedUpTimePanel:setVisible(false)
  self:pauseGame()
  DlgMgr:openDlg("ChaseInTownRuleDlg")
  DlgMgr:sendMsg("ChaseInTownRuleDlg", "setClickBlankNoClose", true)
  self.moveFrame = 0
  self.bornGatherPercent = 0
  self.drugGatherTipCount = 0
  self.playerKnockTimes = 0
  self.firstTipGetItemTag = 0
  self.firstTipUseItemtag = 0
  EventDispatcher:addEventListener(EVENT.CLOSE_GENENAL_FLOAT_DLG, self.onCloseRuleDlg, self)
end
function ChaseInTownDlg:setData(data)
  self.cookie = data.cookie
end
function ChaseInTownDlg:initMapPanel()
  self:initGrassPanel()
  self:initRoadPanel()
  self:initItemPanel()
  self:initBuildingPanel()
end
function ChaseInTownDlg:initPlayer()
  local midRoadStarPos = self:getMidRoadStarPos()
  if not midRoadStarPos then
    return
  end
  self.player = CharAction.new()
  self.player:set(Me:getDlgIcon(true), Me:getDlgWeaponIcon(true), Const.SA_STAND, 3, nil, nil, nil, Me:getDlgPartIndex(true), Me:getDlgPartColorIndex(true))
  self.player:setPosition(cc.p(midRoadStarPos.x, midRoadStarPos.y - 20))
  self.playerPanel:addChild(self.player, PLAYER_ZORDER)
  self.player.road = 2
  local midRoadEndPos = cc.p(midRoadStarPos.x + ROAD_BLOCK_SIZE.width * 6, midRoadStarPos.y + ROAD_BLOCK_SIZE.height * 6)
  self.monster = CharAction.new()
  self.monster:set(6213, nil, Const.SA_STAND, 3)
  self.monster:setPosition(cc.p(midRoadEndPos.x, midRoadEndPos.y - 20))
  self.playerPanel:addChild(self.monster, PLAYER_ZORDER)
  self.monster.road = 2
end
function ChaseInTownDlg:getMidRoadStarPos()
  local midRoadBlockStarIndex = math.ceil(Const.WINSIZE.width / ROAD_BLOCK_SIZE.width / 2) - 3
  local roadBlock = self.roadPanel1:getChildByName("RoadImage" .. tostring(midRoadBlockStarIndex) .. "2")
  if roadBlock then
    return cc.p(roadBlock:getPosition())
  end
end
function ChaseInTownDlg:initGrassPanel()
  self.grassPanel:removeAllChildren()
  local blockSize = ROAD_BLOCK_SIZE
  local imageSize = cc.size(192, 96)
  for i = 1, 20 do
    for j = 1, 20 do
      if i <= 15 or j <= 15 then
        local image1 = ccui.ImageView:create(GRASS_IAMGE_PATH)
        self.grassPanel:addChild(image1)
        image1:setPosition(cc.p(imageSize.width * (i - 1), imageSize.height * (j - 1)))
        local image2 = ccui.ImageView:create(GRASS_IAMGE_PATH)
        self.grassPanel:addChild(image2)
        image2:setPosition(cc.p(imageSize.width * (i - 1) + imageSize.width / 2, imageSize.height * (j - 1) + imageSize.height / 2))
      end
    end
  end
  self.grassPanel1 = self.grassPanel:clone()
  self.grassPanel1:setPosition(MAP_BLOCK_POS1)
  self.grassPanel1.orgPos = gf:deepCopy(MAP_BLOCK_POS1)
  self.grassPanel2 = self.grassPanel:clone()
  self.grassPanel2:setPosition(MAP_BLOCK_POS2)
  self.grassPanel2.orgPos = gf:deepCopy(MAP_BLOCK_POS2)
  self.mapPanel:addChild(self.grassPanel1, GRASS_ZORDER)
  self.mapPanel:addChild(self.grassPanel2, GRASS_ZORDER - 1)
end
function ChaseInTownDlg:initRoadPanel()
  self.roadPanel:removeAllChildren()
  local startPos = cc.p(-42, 49)
  local blockSize = ROAD_BLOCK_SIZE
  local roadSize = ROAD_NEXT_DIS
  local blockCount = math.ceil(MOVE_DISTANCE_X / blockSize.width)
  for j = 1, 3 do
    for i = 1, blockCount do
      local image = ccui.ImageView:create(FLOOR_IMAGE_PATH)
      self.roadPanel:addChild(image)
      image:setName("RoadImage" .. tostring(i) .. tostring(j))
      local posX = startPos.x + roadSize.width * (j - 1) + blockSize.width * (i - 1)
      local posY = startPos.y - roadSize.height * (j - 1) + blockSize.height * (i - 1)
      image:setPosition(cc.p(posX, posY))
    end
  end
  self.roadPanel1 = self.roadPanel:clone()
  self.roadPanel1:setPosition(MAP_BLOCK_POS1)
  self.roadPanel1.orgPos = gf:deepCopy(MAP_BLOCK_POS1)
  self.roadPanel2 = self.roadPanel:clone()
  self.roadPanel2:setPosition(MAP_BLOCK_POS2)
  self.roadPanel2.orgPos = gf:deepCopy(MAP_BLOCK_POS2)
  self.mapPanel:addChild(self.roadPanel1, FLOOR_ZORDER)
  self.mapPanel:addChild(self.roadPanel2, FLOOR_ZORDER - 1)
end
function ChaseInTownDlg:initItemPanel()
  self.itemPanel:removeAllChildren()
  local startPos1 = cc.p(63, 288)
  local startPos2 = cc.p(298, 402)
  local startPos3 = cc.p(539, 51)
  local startPos4 = cc.p(774, 165)
  local blockSize = cc.size(482, 240)
  for i = 1, 4 do
    local image = ccui.ImageView:create(FLOWER_IMAGE_PATH)
    self.itemPanel:addChild(image)
    local posX = startPos1.x + blockSize.width * (i - 1)
    local posY = startPos1.y + blockSize.height * (i - 1)
    image:setPosition(cc.p(posX, posY))
    local image = ccui.ImageView:create(LAMP_IMAGE_PATH)
    self.itemPanel:addChild(image)
    local posX = startPos2.x + blockSize.width * (i - 1)
    local posY = startPos2.y + blockSize.height * (i - 1)
    image:setPosition(cc.p(posX, posY))
    local image = ccui.ImageView:create(FLOWER_IMAGE_PATH)
    self.itemPanel:addChild(image)
    local posX = startPos3.x + blockSize.width * (i - 1)
    local posY = startPos3.y + blockSize.height * (i - 1)
    image:setPosition(cc.p(posX, posY))
    local image = ccui.ImageView:create(LAMP_IMAGE_PATH)
    self.itemPanel:addChild(image)
    local posX = startPos4.x + blockSize.width * (i - 1)
    local posY = startPos4.y + blockSize.height * (i - 1)
    image:setPosition(cc.p(posX, posY))
  end
  self.itemPanel1 = self.itemPanel:clone()
  self.itemPanel1:setPosition(MAP_BLOCK_POS1)
  self.itemPanel1.orgPos = gf:deepCopy(MAP_BLOCK_POS1)
  self.itemPanel2 = self.itemPanel:clone()
  self.itemPanel2:setPosition(MAP_BLOCK_POS2)
  self.itemPanel2.orgPos = gf:deepCopy(MAP_BLOCK_POS2)
  self.mapPanel:addChild(self.itemPanel1, FLOWER_ZORDER)
  self.mapPanel:addChild(self.itemPanel2, FLOWER_ZORDER - 1)
end
function ChaseInTownDlg:initBuildingPanel()
  self.buildingPanel:removeAllChildren()
  local HOUSE_NUM = 5
  local startPos1 = cc.p(-63, 755)
  local startPos2 = cc.p(1007, -139)
  local blockSize = cc.size(493, 260)
  for i = 1, 3 do
    local image = ccui.ImageView:create(HOUSE_IMAGE_PATH[math.random(1, 3)])
    image:setName("LeftHouse" .. i)
    self.buildingPanel:addChild(image, HOUSE_NUM - i)
    local posX = startPos1.x + blockSize.width * (i - 1)
    local posY = startPos1.y + blockSize.height * (i - 1)
    image:setPosition(cc.p(posX, posY))
    local image = ccui.ImageView:create(HOUSE_IMAGE_PATH[math.random(1, 3)])
    image:setName("RightHouse" .. i)
    self.buildingPanel:addChild(image, HOUSE_NUM - i)
    local posX = startPos2.x + blockSize.width * (i - 1)
    local posY = startPos2.y + blockSize.height * (i - 1)
    image:setPosition(cc.p(posX, posY))
  end
  local image = ccui.ImageView:create(HOUSE_IMAGE_PATH[math.random(1, 3)])
  image:setName("LeftHouse4")
  self.buildingPanel:addChild(image, HOUSE_NUM - 4)
  image:setPosition(cc.p(1397, 1501))
  local image = ccui.ImageView:create(HOUSE_IMAGE_PATH[math.random(1, 3)])
  image:setName("LeftHouse4")
  self.buildingPanel:addChild(image, HOUSE_NUM - 4)
  image:setPosition(cc.p(2488, 578))
  self.buildingPanel1 = self.buildingPanel:clone()
  self.buildingPanel1:setPosition(MAP_BLOCK_POS1)
  self.buildingPanel1.orgPos = gf:deepCopy(MAP_BLOCK_POS1)
  self.buildingPanel2 = self.buildingPanel:clone()
  self.buildingPanel2:setPosition(MAP_BLOCK_POS2)
  self.buildingPanel2.orgPos = gf:deepCopy(MAP_BLOCK_POS2)
  self.mapPanel:addChild(self.buildingPanel1, HOUSE_ZORDER)
  self.mapPanel:addChild(self.buildingPanel2, HOUSE_ZORDER - 1)
end
function ChaseInTownDlg:randomBuildingImage(panel1)
  local imageList = {}
  local leftHouse3 = panel1:getChildByName("LeftHouse3")
  if leftHouse3 then
    table.insert(imageList, leftHouse3)
  end
  local leftHouse4 = panel1:getChildByName("LeftHouse4")
  if leftHouse4 then
    table.insert(imageList, leftHouse4)
  end
  local rightHouse3 = panel1:getChildByName("RightHouse3")
  if rightHouse3 then
    table.insert(imageList, rightHouse3)
  end
  local rightHouse4 = panel1:getChildByName("RightHouse4")
  if rightHouse4 then
    table.insert(imageList, rightHouse4)
  end
  for i = 1, #imageList do
    imageList[i]:loadTexture(HOUSE_IMAGE_PATH[math.random(1, 3)], ccui.TextureResType.localType)
  end
end
function ChaseInTownDlg:onUpdate()
  if self.inPauseStatus then
    return
  end
  if not self.moveFrame then
    return
  end
  if self.moveFrame == MOVE_ROUND_FRAME then
    self.moveFrame = 0
    self:changeMovePanelPos(self.grassPanel1, self.grassPanel2)
    self:changeMovePanelPos(self.roadPanel1, self.roadPanel2)
    self:changeMovePanelPos(self.itemPanel1, self.itemPanel2)
    self:changeMovePanelPos(self.buildingPanel1, self.buildingPanel2)
    self:randomBuildingImage(self.buildingPanel1)
  end
  self.moveFrame = self.moveFrame + 1
  local moveX = self.moveFrame * MOVE_DISTANCE_X / MOVE_ROUND_FRAME
  local moveY = self.moveFrame * MOVE_DISTANCE_Y / MOVE_ROUND_FRAME
  self:updateMovePanelPos(self.grassPanel1, self.grassPanel2, moveX, moveY)
  self:updateMovePanelPos(self.roadPanel1, self.roadPanel2, moveX, moveY)
  self:updateMovePanelPos(self.itemPanel1, self.itemPanel2, moveX, moveY)
  self:updateMovePanelPos(self.buildingPanel1, self.buildingPanel2, moveX, moveY)
  local curTick = gfGetTickCount()
  if not self.lastCreateObstacleTick then
    self.lastCreateObstacleTick = curTick
  end
  if curTick - self.lastCreateObstacleTick > self.nextCreateObstacleTime then
    self:createObstacle()
    self.lastCreateObstacleTick = curTick
    self:updateCreateObstacleTime()
  end
  self:updateObstaclePos()
  self:checkMonsterDistanceWithObstacle()
  if not self.player.blinkAction and self:checkPlayerDistanceWithObstacle() then
    if self.playerKnockTimes < 2 then
      self.playerKnockTimes = self.playerKnockTimes + 1
      self:setPropaganda(self.player, string.format(CHS[7100928], 3 - self.playerKnockTimes))
      self.player.blinkAction = self.player:runAction(cc.Sequence:create(cc.Blink:create(0.5, 4), cc.CallFunc:create(function()
        self.player.blinkAction = nil
      end)))
    else
      self:pauseGame()
      self:doFailGameDrama()
    end
  end
  self.bornGatherPercent = self.bornGatherPercent + 1
  self:updatePlayerAddSpeedBar(curTick)
  self:updatePlayerAddSpeedDis()
  self:updateMonsterMinusSpeedDis()
  self:checkPlayerMonsterDis()
end
function ChaseInTownDlg:doFailGameDrama()
  local dramaList = self:getDramaList()
  local dlg = DlgMgr:openDlg("ClientDramaDlg")
  dlg:setData(dramaList, function()
    self:doGameResult("lose", nil, "2")
  end)
end
function ChaseInTownDlg:getDramaList()
  local dramaList = {
    {
      player = Me:getName(),
      icon = Me:queryBasicInt("org_icon"),
      content = CHS[7100929]
    },
    {
      player = CHS[7120466],
      icon = 6213,
      content = CHS[7100930]
    }
  }
  local count = #dramaList
  local ret = {}
  for i = 1, count do
    local data = {}
    data.pic_no = 0
    data.isComplete = 0
    data.isInCombat = 0
    data.task_type = ""
    data.name = dramaList[i].player
    data.content = dramaList[i].content
    data.portrait = dramaList[i].icon
    data.id = 0
    table.insert(ret, data)
  end
  local endDrama = gf:deepCopy(ret[#ret])
  endDrama.isComplete = 1
  table.insert(ret, endDrama)
  return ret
end
function ChaseInTownDlg:getMemo()
  if not self.bornFirstItemTime then
    self.bornFirstItemTime = -1
  end
  if not self.getFirstGatherTime then
    self.getFirstGatherTime = -1
  end
  if not self.getGatherCount then
    self.getGatherCount = 0
  end
  if not self.useGatherCount then
    self.useGatherCount = 0
  end
  local memo = string.format("1:{%d},2:{%d},3:{%d},4:{%d},5:{%d}", self.bornFirstItemTime, self.getFirstGatherTime, self.getGatherCount, self.useGatherCount, self.gameOverTime)
  return memo
end
function ChaseInTownDlg:doGameResult(type, noMemo, para)
  local memo = ""
  if not noMemo then
    if not self.gameOverTime then
      if self.numImg then
        self.gameOverTime = self.numImg.num
      else
        self.gameOverTime = GAME_TIME
      end
    end
    memo = self:getMemo()
  end
  if not self.numImg then
    para = ""
  end
  gf:CmdToServer("CMD_TANAN_MSHC_RESULT", {
    result = gfEncrypt(tostring(type), self.cookie),
    memo = memo,
    para = para
  })
  DlgMgr:closeDlg(self.name)
end
function ChaseInTownDlg:checkPlayerMonsterDis()
  if not self.player or not self.monster then
    return
  end
  local playerX, playerY = self.player:getPosition()
  local monsterX, monsterY = self.monster:getPosition()
  local roadMargin = self.monster.road - self.player.road
  local monsterCheckX, monsterCheckY = playerX + roadMargin * ROAD_NEXT_DIS.width, playerY - roadMargin * ROAD_NEXT_DIS.height
  local isOk = monsterX <= monsterCheckX + 40 and monsterY <= monsterCheckY + 20
  if isOk then
    self:pauseGame()
    self:doGameResult("win", nil, "0")
  end
end
function ChaseInTownDlg:checkPlayerDistanceWithObstacle()
  if not self.obstacle then
    return
  end
  local function checkPlayerDistance(obstacle)
    local pos = cc.p(obstacle:getPosition())
    local playerX, playerY = self.player:getPosition()
    if math.abs(pos.x - playerX) <= ROAD_NEXT_DIS.width * 0.2 then
      if not obstacle.type then
        return true
      else
        obstacle:setVisible(false)
        self:addGatherCount(obstacle.type)
        if self.firstTipGetItemAction then
          self.root:stopAction(self.firstTipGetItemAction)
          self.firstTipGetItemAction = nil
        end
        if self.firstTipUseItemtag == 0 then
          self.firstTipUseItemtag = 1
          self.firstTipUseItemAction = performWithDelay(self.root, function()
            gf:ShowSmallTips(CHS[7150711])
            self.firstTipUseItemAction = nil
          end, 10)
        end
      end
    end
  end
  local isPlayerKnockObstacle = false
  for j = 1, 3 do
    local roadObstacle = self.obstacle[j]
    if roadObstacle then
      for i = 1, #roadObstacle do
        local obstacle = roadObstacle[i]
        if obstacle:isVisible() and self.player and self.player.road == obstacle.road and checkPlayerDistance(obstacle) then
          isPlayerKnockObstacle = true
        end
      end
    end
  end
  return isPlayerKnockObstacle
end
function ChaseInTownDlg:checkMonsterDistanceWithObstacle()
  if not self.obstacle then
    return
  end
  local function isInDangerousArea(obj, pos)
    local objX, objY = obj:getPosition()
    if objX < pos.x and pos.x - objX <= ROAD_NEXT_DIS.width * 2 then
      return true
    end
  end
  local function getBetterRoadMonsterChoose()
    local monsterX, monsterY = self.monster:getPosition()
    local roadDis1
    if self.obstacle and self.obstacle[1] then
      for i = 1, #self.obstacle[1] do
        local x, y = self.obstacle[1][i]:getPosition()
        if monsterX < x and (not roadDis1 or roadDis1 < x - monsterX) then
          roadDis1 = x - monsterX
        end
      end
    end
    local roadDis3
    if self.obstacle and self.obstacle[3] then
      for i = 1, #self.obstacle[3] do
        local x, y = self.obstacle[3][i]:getPosition()
        if monsterX < x and (not roadDis3 or roadDis3 < x - monsterX) then
          roadDis3 = x - monsterX
        end
      end
    end
    if not roadDis1 or roadDis3 and roadDis1 > roadDis3 then
      return 1
    else
      return 3
    end
  end
  local function checkMonsterDistance(obstacle)
    local pos = cc.p(obstacle:getPosition())
    if not isInDangerousArea(self.monster, pos) then
      return
    end
    if self.monster.road == 1 then
      self:moveToRight(self.monster)
    elseif self.monster.road == 3 then
      self:moveToLeft(self.monster)
    else
      local road = getBetterRoadMonsterChoose()
      if road == 3 then
        self:moveToRight(self.monster)
      else
        self:moveToLeft(self.monster)
      end
    end
  end
  for j = 1, 3 do
    local roadObstacle = self.obstacle[j]
    if roadObstacle then
      for i = 1, #roadObstacle do
        local obstacle = roadObstacle[i]
        if obstacle:isVisible() and self.monster and self.monster.road == obstacle.road then
          checkMonsterDistance(obstacle)
        end
      end
    end
  end
end
function ChaseInTownDlg:updateObstaclePos()
  if not self.obstacle then
    return
  end
  for j = 1, 3 do
    local roadObstacle = self.obstacle[j]
    if roadObstacle then
      local notRemoveObstacle = {}
      local removeObstacle = {}
      for i = 1, #roadObstacle do
        local obstacle = roadObstacle[i]
        local pos = cc.p(obstacle:getPosition())
        pos.x = pos.x - OBSTACLE_SPEED_X
        pos.y = pos.y - OBSTACLE_SPEED_Y
        obstacle:setPosition(pos)
        if pos.y >= -100 then
          table.insert(notRemoveObstacle, obstacle)
        else
          table.insert(removeObstacle, obstacle)
        end
      end
      self.obstacle[j] = notRemoveObstacle
      for i = 1, #removeObstacle do
        removeObstacle[i]:removeFromParent()
      end
    end
  end
end
function ChaseInTownDlg:createObstacle()
  local count = 1
  if math.random(1, 100) < 20 then
    count = 2
  end
  if count == 1 then
    local road
    if not self.lastObstacleRoad then
      road = math.random(1, 3)
    else
      local array = {
        1,
        2,
        3
      }
      array[self.lastObstacleRoad] = nil
      local newArray = {}
      for k, v in pairs(array) do
        table.insert(newArray, v)
      end
      road = newArray[math.random(1, 2)]
    end
    self.lastObstacleRoad = road
    self:insertRoadObstacle(road)
  else
    local array = {
      1,
      2,
      3
    }
    array[math.random(1, #array)] = nil
    local newArray = {}
    for k, v in pairs(array) do
      table.insert(newArray, v)
    end
    for i = 1, 2 do
      self:insertRoadObstacle(newArray[i])
    end
    self.lastObstacleRoad = nil
  end
end
function ChaseInTownDlg:addGatherCount(type)
  if not self.gatherCount then
    self.gatherCount = {}
  end
  if not self.gatherCount[type] then
    self.gatherCount[type] = 1
  else
    self.gatherCount[type] = self.gatherCount[type] + 1
  end
  self:refreshGatherCount()
  if not self.getFirstGatherTime then
    self.getFirstGatherTime = self.numImg.num
  end
  if not self.getGatherCount then
    self.getGatherCount = 0
  end
  self.getGatherCount = self.getGatherCount + 1
end
function ChaseInTownDlg:refreshGatherCount()
  local stoneCount = 0
  local drugCount = 0
  if self.gatherCount and self.gatherCount[GATHER_TYPE.STONE] then
    stoneCount = self.gatherCount[GATHER_TYPE.STONE]
  end
  if self.gatherCount and self.gatherCount[GATHER_TYPE.DRUG] then
    drugCount = self.gatherCount[GATHER_TYPE.DRUG]
  end
  self:setLabelText("StoneNumLabel", string.format("x%d", stoneCount), "StoneButtonPanel")
  self:setLabelText("MedicineNumLabel", string.format("x%d", drugCount), "MedicineButtonPanel")
end
function ChaseInTownDlg:insertRoadObstacle(road)
  local obstacle
  local pos = self:getObstacleBornPos(road)
  if self.bornGatherPercent > 60 and math.random(1, BORN_GATHER_PERCENT) < self.bornGatherPercent then
    self.bornGatherPercent = 0
    local gatherType = GATHER_TYPE.STONE
    if 60 >= math.random(1, 100) then
      gatherType = GATHER_TYPE.DRUG
    end
    obstacle = self:createItemResource(gatherType)
    if gatherType == GATHER_TYPE.DRUG then
      pos = cc.p(self.monster:getPosition())
      pos.y = pos.y + 20
      road = self.monster.road
      if 1 > self.drugGatherTipCount then
        self:setPropaganda(self.monster, CHS[7100931])
        self.drugGatherTipCount = self.drugGatherTipCount + 1
      end
    end
    if not self.bornFirstItemTime then
      self.bornFirstItemTime = self.numImg.num
    end
    if self.firstTipGetItemTag == 0 then
      self.firstTipGetItemTag = 1
      self.firstTipGetItemAction = performWithDelay(self.root, function()
        gf:ShowSmallTips(CHS[7150710])
        self.firstTipGetItemAction = nil
      end, 10)
    end
  else
    obstacle = self:createItemResource(math.random(1, 3))
  end
  obstacle:setPosition(pos)
  obstacle.road = road
  self.playerPanel:addChild(obstacle, OBSTACLE_ZORDER)
  if not self.obstacle then
    self.obstacle = {}
  end
  if not self.obstacle[road] then
    self.obstacle[road] = {}
  end
  table.insert(self.obstacle[road], obstacle)
end
function ChaseInTownDlg:getObstacleBornPos(road)
  local midRoadBlockEndIndex = math.ceil(Const.WINSIZE.width / ROAD_BLOCK_SIZE.width) + 1
  local roadBlock = self.roadPanel1:getChildByName("RoadImage" .. tostring(midRoadBlockEndIndex) .. "2")
  if roadBlock then
    local pos = cc.p(roadBlock:getPosition())
    if road == 1 then
      return cc.p(pos.x - ROAD_NEXT_DIS.width, pos.y + ROAD_NEXT_DIS.height)
    elseif road == 3 then
      return cc.p(pos.x + ROAD_NEXT_DIS.width, pos.y - ROAD_NEXT_DIS.height)
    else
      return pos
    end
  end
end
function ChaseInTownDlg:createItemResource(index)
  if index <= 3 then
    local path = ITEM_PATH[index]
    local image = ccui.ImageView:create(path)
    if path == ResMgr:getItemIconPath(10121) then
      image:setFlippedX(true)
    end
    return image
  else
    local gatherPanel = self.gatherPanel:clone()
    gatherPanel:getChildByName("ItemImage"):loadTexture(ITEM_PATH[index])
    gatherPanel.type = index
    return gatherPanel
  end
end
function ChaseInTownDlg:changeMovePanelPos(panel1, panel2)
  panel1:setPosition(panel2.orgPos)
  local panel = panel1
  panel1 = panel2
  panel2 = panel1
  panel1.orgPos = gf:deepCopy(MAP_BLOCK_POS1)
  panel2.orgPos = gf:deepCopy(MAP_BLOCK_POS2)
end
function ChaseInTownDlg:updateMovePanelPos(panel1, panel2, moveX, moveY)
  panel1:setPosition(cc.p(panel1.orgPos.x - moveX, panel1.orgPos.y - moveY))
  panel2:setPosition(cc.p(panel2.orgPos.x - moveX, panel2.orgPos.y - moveY))
end
function ChaseInTownDlg:updateCreateObstacleTime()
  self.nextCreateObstacleTime = math.random(8, 12) / 10 * 1000
end
function ChaseInTownDlg:setPropaganda(charAction, text)
  if charAction.propaganda then
    charAction.propaganda:removeFromParent()
    charAction.propaganda = nil
  end
  local headX, headY = charAction:getHeadOffset()
  local sz = charAction:getContentSize()
  local anchorPoint = charAction:getAnchorPoint()
  local dlg = DlgMgr:openDlg("PopUpDlg")
  local bg = dlg:addTip(text)
  bg:setPosition(headX + sz.width * anchorPoint.x, headY + sz.height * anchorPoint.y)
  local action = cc.Sequence:create(cc.DelayTime:create(3), cc.RemoveSelf:create(), cc.CallFunc:create(function()
    charAction.propaganda = nil
  end))
  charAction:addChild(bg)
  charAction.propaganda = bg
  bg:runAction(action)
end
function ChaseInTownDlg:startCountDown()
  local timePanel = self:getControl("TimePanel")
  local sz = timePanel:getContentSize()
  local numImg = NumImg.new("bfight_num", GAME_TIME, false, -5)
  numImg:setPosition(sz.width / 2, sz.height / 2)
  numImg:setVisible(true)
  numImg:setScale(0.5, 0.5)
  timePanel:addChild(numImg, 999)
  numImg:startCountDown(function()
    self:pauseGame()
    self:doGameResult("lose", nil, "1")
  end)
  self.numImg = numImg
end
function ChaseInTownDlg:startGame()
  self.player:setAction(Const.SA_WALK)
  self.monster:setAction(Const.SA_WALK)
  self:updateCreateObstacleTime()
  self:resumeGame()
  self:startCountDown()
  self.bornFirstItemTime = nil
  self.getFirstGatherTime = nil
  self.getGatherCount = 0
  self.useGatherCount = 0
  self.gameOverTime = nil
end
function ChaseInTownDlg:pauseGame()
  self.inPauseStatus = true
  if self.player then
    if self.player.propaganda then
      self.player.propaganda:removeFromParent()
      self.player.propaganda = nil
    end
    self.player:setAction(Const.SA_STAND)
  end
  if self.monster then
    if self.monster.propaganda then
      self.monster.propaganda:removeFromParent()
      self.monster.propaganda = nil
    end
    self.monster:setAction(Const.SA_STAND)
  end
  if self.numImg then
    self.numImg:pauseCountDown()
  end
  self.pauseGameTick = gfGetTickCount()
end
function ChaseInTownDlg:resumeGame()
  self.inPauseStatus = nil
  if self.player then
    self.player:setAction(Const.SA_WALK)
  end
  if self.monster then
    self.monster:setAction(Const.SA_WALK)
  end
  if self.numImg then
    self.numImg:continueCountDown()
  end
  if self.lastCreateObstacleTick and self.pauseGameTick then
    self.lastCreateObstacleTick = self.lastCreateObstacleTick + gfGetTickCount() - self.pauseGameTick
  end
end
function ChaseInTownDlg:cleanup()
  self.inPauseStatus = nil
  self.playerKnockTimes = 0
  self.obstacle = nil
  self.lastCreateObstacleTick = nil
  self.gatherCount = nil
  self.drugGatherTipCount = 0
  self.numImg = nil
  self.firstTipUseItemAction = nil
  self.firstTipGetItemAction = nil
  self.gameOverTime = nil
  self.getGatherCount = nil
  self.useGatherCount = nil
  DlgMgr:closeDlg("ChaseInTownRuleDlg")
  gf:closeCountDown()
  EventDispatcher:removeEventListener(EVENT.CLOSE_GENENAL_FLOAT_DLG, self.onCloseRuleDlg, self)
end
function ChaseInTownDlg:moveToLeft(obj)
  if not obj.road then
    return
  end
  if obj.road == 1 then
    return
  end
  obj.road = obj.road - 1
  local curX, curY = obj:getPosition()
  obj:setPosition(curX - ROAD_NEXT_DIS.width, curY + ROAD_NEXT_DIS.height)
end
function ChaseInTownDlg:moveToRight(obj)
  if not obj.road then
    return
  end
  if obj.road == 3 then
    return
  end
  obj.road = obj.road + 1
  local curX, curY = obj:getPosition()
  obj:setPosition(curX + ROAD_NEXT_DIS.width, curY - ROAD_NEXT_DIS.height)
end
function ChaseInTownDlg:checkTouchPanelWithPlayer()
  local playerX, playerY = self.player:getPosition()
  local bPlayer = playerY - 0.5 * playerX
  local touchPos = self.mapPanel:convertToNodeSpace(GameMgr.curTouchPos)
  local bTouch = touchPos.y - 0.5 * touchPos.x
  if bTouch < bPlayer - MARGIN_ROAD + 20 then
    self:moveToRight(self.player)
  elseif bTouch > bPlayer + MARGIN_ROAD then
    self:moveToLeft(self.player)
  end
end
function ChaseInTownDlg:updatePlayerAddSpeedBar()
  if not self.speedUpTimePanel:isVisible() then
    return
  end
  if not self.speedUpTimePanel.tick or self.speedUpTimePanel.tick <= 0 then
    self.speedUpTimePanel:setVisible(false)
    return
  end
  local percent = self.speedUpTimePanel.tick / ADD_MINUS_SPEED_TICK * 100
  if percent <= 0 then
    self.speedUpTimePanel:setVisible(false)
  else
    self:getControl("SpeedUpLoadingBar", nil, self.speedUpTimePanel):setPercent(percent)
  end
  self.speedUpTimePanel.tick = self.speedUpTimePanel.tick - 1
end
function ChaseInTownDlg:updatePlayerAddSpeedDis()
  if not self.player or not self.player.speedTick or self.player.speedTick <= 0 then
    return
  end
  self.player.speedTick = self.player.speedTick - 1
  local curX, curY = self.player:getPosition()
  curX = curX + OBJ_SPEED_X
  curY = curY + OBJ_SPEED_Y
  self.player:setPosition(curX, curY)
end
function ChaseInTownDlg:doPlayerAddSpeed()
  if not self.player then
    return
  end
  self.speedUpTimePanel.tick = ADD_MINUS_SPEED_TICK
  self.speedUpTimePanel:setVisible(true)
  self:updatePlayerAddSpeedBar(self.speedUpTimePanel.tick)
  self.player.speedTick = ADD_MINUS_SPEED_TICK
end
function ChaseInTownDlg:updateMonsterMinusSpeedDis()
  if not self.monster or not self.monster.speedTick or self.monster.speedTick <= 0 then
    return
  end
  self.monster.speedTick = self.monster.speedTick - 1
  local curX, curY = self.monster:getPosition()
  curX = curX - OBJ_SPEED_X
  curY = curY - OBJ_SPEED_Y
  self.monster:setPosition(curX, curY)
end
function ChaseInTownDlg:doMonsterMinusSpeed()
  if not self.monster then
    return
  end
  if not self.monster.speedTick then
    self.monster.speedTick = 0
  end
  self.monster.speedTick = self.monster.speedTick + ADD_MINUS_SPEED_TICK
end
function ChaseInTownDlg:doMonsterAttacked()
  local pos = cc.p(self.monster:getPosition())
  local sz = self.monster:getContentSize()
  local anchorPoint = self.monster:getAnchorPoint()
  local waistX, waistY = self.monster:getWaistOffset()
  local magic = gf:createCallbackMagic(ResMgr.magic.obj_attacked_eff, function(node)
    node:removeFromParent()
    node = nil
  end)
  self:setPropaganda(self.monster, CHS[7100950])
  self:doMonsterMinusSpeed()
  magic:setPosition(cc.p(sz.width * anchorPoint.x + waistX, sz.height * anchorPoint.y + waistY))
  self.monster:addChild(magic, PLAYER_ZORDER + 1)
end
function ChaseInTownDlg:throwStone()
  local headX, headY = self.player:getHeadOffset()
  local pos = cc.p(self.player:getPosition())
  local effectPanel = self.gatherPanel:clone()
  effectPanel:getChildByName("ItemImage"):loadTexture(ITEM_PATH[GATHER_TYPE.STONE])
  local size = effectPanel:getContentSize()
  local pos = cc.p(pos.x, pos.y + headY + size.height / 2)
  effectPanel:setPosition(pos)
  self.playerPanel:addChild(effectPanel)
  local callFunc = cc.CallFunc:create(function()
    effectPanel:removeFromParent()
    effectPanel = nil
    self:doMonsterAttacked()
  end)
  local fadeOut = cc.FadeOut:create(0.6)
  local moveTo = cc.MoveTo:create(0.6, cc.p(pos.x, pos.y + size.height))
  effectPanel:runAction(cc.Sequence:create(cc.Spawn:create(fadeOut, moveTo), callFunc))
end
function ChaseInTownDlg:onTouchPanel(sender, eventType)
  if eventType == ccui.TouchEventType.ended then
    if self.inPauseStatus then
      return
    end
    self:checkTouchPanelWithPlayer()
  end
end
function ChaseInTownDlg:onRuleButton(sender, eventType)
  if DlgMgr:getDlgByName("ChaseInTownRuleDlg") then
    return
  end
  DlgMgr:openDlg("ChaseInTownRuleDlg")
  self:pauseGame()
end
function ChaseInTownDlg:onCloseButton(sender, eventType)
  if not self.inPauseStatus then
    self:pauseGame()
  end
  gf:confirm(CHS[7100927], function()
    self:doGameResult("lose", nil, "3")
    DlgMgr:closeDlg(self.name)
  end, function()
    if self:getControl("StarPanel"):isVisible() then
      return
    end
    if DlgMgr:getDlgByName("CountDownDlg") then
      return
    end
    if self.inPauseStatus then
      self:resumeGame()
    end
  end)
end
function ChaseInTownDlg:onStarButton(sender, eventType)
  self:setCtrlVisible("StarPanel", false)
  DlgMgr:sendMsg("ChaseInTownRuleDlg", "setClickBlankNoClose")
  gf:startCountDowm(GAME_START_COUNT_DOWM + gf:getServerTime(), "start", function()
    local dlg = DlgMgr.dlgs.ChaseInTownDlg
    if dlg then
      self:startGame()
    end
  end)
  DlgMgr:closeDlg("ChaseInTownRuleDlg")
end
function ChaseInTownDlg:onStoneButton(sender, eventType)
  if self:getControl("StarPanel"):isVisible() then
    return
  end
  if not self.gatherCount or not self.gatherCount[GATHER_TYPE.STONE] or self.gatherCount[GATHER_TYPE.STONE] <= 0 then
    gf:ShowSmallTips(CHS[7100932])
    return
  end
  local curTick = gfGetTickCount()
  if sender.lastTick and curTick - sender.lastTick < 1000 then
    gf:ShowSmallTips(CHS[7100952])
    return
  end
  sender.lastTick = curTick
  self.gatherCount[GATHER_TYPE.STONE] = self.gatherCount[GATHER_TYPE.STONE] - 1
  self:refreshGatherCount()
  self:setPropaganda(self.player, CHS[7100933])
  self:throwStone()
  if self.firstTipUseItemAction then
    self.root:stopAction(self.firstTipUseItemAction)
    self.firstTipUseItemAction = nil
  end
  if not self.useGatherCount then
    self.useGatherCount = 0
  end
  self.useGatherCount = self.useGatherCount + 1
end
function ChaseInTownDlg:onMedicineButton(sender, eventType)
  if self:getControl("StarPanel"):isVisible() then
    return
  end
  if not self.gatherCount or not self.gatherCount[GATHER_TYPE.DRUG] or self.gatherCount[GATHER_TYPE.DRUG] <= 0 then
    gf:ShowSmallTips(CHS[7100951])
    return
  end
  local curTick = gfGetTickCount()
  if sender.lastTick and curTick - sender.lastTick < ADD_MINUS_SPEED_TIME * 1000 then
    gf:ShowSmallTips(CHS[7100953])
    return
  end
  sender.lastTick = curTick
  self.gatherCount[GATHER_TYPE.DRUG] = self.gatherCount[GATHER_TYPE.DRUG] - 1
  self:refreshGatherCount()
  self:setPropaganda(self.player, CHS[7100954])
  self:doPlayerAddSpeed()
  if self.firstTipUseItemAction then
    self.root:stopAction(self.firstTipUseItemAction)
    self.firstTipUseItemAction = nil
  end
  if not self.useGatherCount then
    self.useGatherCount = 0
  end
  self.useGatherCount = self.useGatherCount + 1
end
function ChaseInTownDlg:onCloseRuleDlg()
  if self:getControl("StarPanel"):isVisible() then
    return
  end
  if DlgMgr:getDlgByName("CountDownDlg") then
    return
  end
  if self.inPauseStatus then
    self:resumeGame()
  end
end
return ChaseInTownDlg
