local Bitset = require("core/Bitset")
local DataObject = require("core/DataObject")
local CharMenuContentDlg = Singleton("CharMenuContentDlg", Dialog)
local ButtonList = {
  [1] = {
    button = CHS[3002315],
    tag = 1
  },
  [2] = {
    button = CHS[3000057],
    tag = 2
  },
  [3] = {
    button = CHS[5000064],
    tag = 3
  },
  [4] = {
    button = CHS[3002316],
    tag = 4
  },
  [5] = {
    button = CHS[3002317],
    tag = 5
  },
  [6] = {
    button = CHS[4000302],
    tag = 6
  },
  [7] = {
    button = CHS[4000303],
    tag = 7
  },
  [8] = {
    button = CHS[5000065],
    tag = 8
  },
  [9] = {
    button = CHS[3002318],
    tag = 9
  },
  [10] = {
    button = CHS[6000268],
    tag = 10
  },
  [11] = {
    button = CHS[6000426],
    tag = 11
  },
  [12] = {
    button = CHS[6000427],
    tag = 12
  },
  [13] = {
    button = CHS[4100299],
    tag = 13
  },
  [14] = {
    button = CHS[4300124],
    tag = 14
  },
  [15] = {
    button = CHS[2100086],
    tag = 15
  },
  [16] = {
    button = CHS[2000425],
    tag = 16
  },
  [17] = {
    button = CHS[5400502],
    tag = 17
  },
  [18] = {
    button = CHS[4300311],
    tag = 18
  },
  [19] = {
    button = CHS[5450428],
    tag = 19
  },
  [20] = {
    button = CHS[7120367],
    tag = 20,
    normalbg = ResMgr.ui.famous_button_normal_bg,
    pressedbg = ResMgr.ui.famous_button_pressed_bg
  }
}
local TEAM_BUTTON_TYPE = {invite = 1, request = 2}
function CharMenuContentDlg:init()
  local mainPanel = self:getControl("InfoPanel")
  self.panelSize = self.panelSize or mainPanel:getContentSize()
  self.rootSize = self.rootSize or self.root:getContentSize()
  self.rect = nil
  self.backCharInfo = nil
  self.charPanelOrgSz = self:getCtrlContentSize("CharInfoPanel")
  self.remarkPanelOrgHeight = self:getCtrlContentSize("RemarkValuePanel").height
  self.showBtnCou = 1
  self:bindListener("RelationshipButton", self.onRelationshipButton)
  self:bindListener("SpouseButton", self.onSpouseButton)
  self.buttonCell = self:retainCtrl("Button1")
  self:hookMsg("MSG_FRIEND_ADD_CHAR")
  self:hookMsg("MSG_FRIEND_REMOVE_CHAR")
  self:hookMsg("MSG_CHAR_INFO")
  self:hookMsg("MSG_LOOK_PLAYER_EQUIP")
  self:hookMsg("MSG_FIND_CHAR_MENU_FAIL")
  self:hookMsg("MSG_FRIEND_MEMO")
  self:hookMsg("MSG_TEMP_FRIEND_STATE")
end
function CharMenuContentDlg:setMuneType(type, param)
  self.muneType = type
  self.param = param
end
function CharMenuContentDlg:isFromChatGroup()
  return self.muneType == CHAR_MUNE_TYPE.GROUP_MEMBER or self.muneType == CHAR_MUNE_TYPE.GROUP_OWNER
end
function CharMenuContentDlg:setting(gid)
  self.gid = gid
  self:MSG_CHAR_INFO()
end
function CharMenuContentDlg:setInfoByDataObject(char)
  local charTemp = {}
  charTemp.id = char:queryBasicInt("id")
  charTemp.icon = char:queryBasicInt("icon")
  charTemp.gid = char:queryBasic("gid")
  charTemp.level = char:queryBasicInt("level")
  charTemp.name = char:queryBasic("name")
  charTemp.party = char:queryBasic("party")
  charTemp.vip = char:queryBasicInt("vip_type")
  charTemp.masquerade = char:queryBasicInt("masquerade")
  charTemp.alicename = char:queryBasic("alicename")
  charTemp.comeback_flag = char:queryBasicInt("comeback_flag")
  charTemp.titleInfo = char.titleInfo
  self.backCharInfo = charTemp
end
function CharMenuContentDlg:setbackCharInfo(char)
  self.backCharInfo = char
end
function CharMenuContentDlg:setInfo(char)
  self.curChar = char
  self.gid = self.curChar.gid
  if string.isNilOrEmpty(self.curChar.party) and FriendMgr:isTempByGid(self.gid) then
    self.curChar.party = FriendMgr:getTemFriendByGid(self.gid):queryBasic("party/name")
  end
  self:setImage("PortraitImage", ResMgr:getSmallPortrait(char.icon))
  self:setItemImageSize("PortraitImage")
  if char.ringScore then
    local satge, level = RingMgr:getStepAndLevelByScore(char.ringScore)
    self:setLabelText("ArenaValueLabel", RingMgr:getJobChs(satge, level))
  else
    self:setLabelText("ArenaValueLabel", "")
  end
  if self.muneType == CHAR_MUNE_TYPE.FAMOUS_KUAFU or self.muneType == CHAR_MUNE_TYPE.FAMOUS_NORMAL then
    self:refreshCharWorshipTimes(char.gid)
  else
    self:setLabelText("RemarksLabel", CHS[7120365])
    self:setColorText(gf:filtTextOnly(FriendMgr:getMemoByGid(char.gid)), "RemarkValuePanel", nil, nil, nil, COLOR3.WHITE, 21)
  end
  self:setLabelText("LineLabel", "")
  self:setCtrlVisible("LineBKImage", false)
  if char.isOnline == 2 then
    self:setCtrlEnabled("PortraitImage", false)
  else
    self:setCtrlEnabled("PortraitImage", true)
    if not string.isNilOrEmpty(self.curChar.serverId) and not MapMgr:isInMasquerade() then
      self:setLabelText("LineLabel", self.curChar.serverId)
      self:setCtrlVisible("LineBKImage", true)
    end
  end
  local level = tonumber(char.level)
  if level and level > 0 then
    self:setNumImgForPanel("PortraitPanel", ART_FONT_COLOR.NORMAL_TEXT, level, false, LOCATE_POSITION.LEFT_TOP, 21)
  else
    self:removeNumImgForPanel("PortraitPanel", LOCATE_POSITION.LEFT_TOP)
  end
  local nameColor = CharMgr:getNameColorByType(OBJECT_TYPE.CHAR, char.vip, nil, true)
  local realName, flagName = gf:getRealNameAndFlag(char.name)
  if self:isOperateMonsterInMasquerade() and char.alicename then
    realName = char.alicename
  end
  self:setLabelText("NameLabel", realName, nil, nameColor)
  if flagName then
    self:setLabelText("PartyValueLabel", flagName)
    self:setLabelText("PartyTypeLabel", CHS[2000110])
  else
    local partyName = char.party or ""
    self:setLabelText("PartyValueLabel", gf:filtTextOnly(partyName))
    self:setLabelText("PartyTypeLabel", CHS[5420149])
  end
  self:setLabelText("IDValueLabel", gf:getShowId(char.gid))
  self:setLabelText("FDValueLabel", FriendMgr:getFriendScore(char.gid) or char.friend_score or 0)
  local dist = FriendMgr:getKuafObjDist(self.gid)
  if not dist and char.dist_name and char.dist_name ~= GameMgr:getDistName() then
    dist = char.dist_name
  end
  self:setCtrlVisible("SpouseButton", false)
  if not string.isNilOrEmpty(dist) then
    gf:addKuafLogo(self:getControl("PortraitPanel"), true)
    self:setCtrlVisible("KuafTipLabel", true)
    self:setCtrlVisible("ServerTypeLabel", true)
    self:setCtrlVisible("ServerValueLabel", true)
    self:setCtrlVisible("FDValueLabel", false)
    self:setCtrlVisible("FDTypeLabel", false)
    self:setCtrlVisible("PartyValueLabel", false)
    self:setCtrlVisible("PartyTypeLabel", false)
    self:setCtrlVisible("ArenaValueLabel", false)
    self:setCtrlVisible("ArenaTypeLabel", false)
    self:setCtrlVisible("RelationshipButton", false)
    self:setCtrlVisible("RelationshipImage", false)
    self:setCtrlVisible("BackPlayerImage", false)
    self:setLabelText("ServerValueLabel", dist)
  else
    gf:removeKuafLogo(self:getControl("PortraitPanel"))
    self:setCtrlVisible("KuafTipLabel", false)
    self:setCtrlVisible("ServerTypeLabel", false)
    self:setCtrlVisible("ServerValueLabel", false)
    self:setCtrlVisible("PartyValueLabel", true)
    self:setCtrlVisible("PartyTypeLabel", true)
    self:setCtrlVisible("ArenaValueLabel", true)
    self:setCtrlVisible("ArenaTypeLabel", true)
    if FriendMgr:hasFriend(self.gid) then
      self:setCtrlVisible("FDValueLabel", true)
      self:setCtrlVisible("FDTypeLabel", true)
    else
      self:setCtrlVisible("FDValueLabel", false)
      self:setCtrlVisible("FDTypeLabel", false)
    end
    self:setCtrlVisible("BackPlayerImage", char.comeback_flag == 1)
    self:updateRelationShip()
    if MapMgr:isInMasquerade() and self.muneType == CHAR_MUNE_TYPE.SCENE or (self.muneType == CHAR_MUNE_TYPE.FAMOUS_KUAFU or self.muneType == CHAR_MUNE_TYPE.FAMOUS_NORMAL) and self.gid == Me:queryBasic("gid") then
      self:setCtrlVisible("RelationshipButton", false)
      self:setCtrlVisible("RelationshipImage", false)
    else
      self:setCtrlVisible("RelationshipButton", true)
      self:setCtrlVisible("RelationshipImage", true)
    end
    local info = MarryMgr:getLoverInfo()
    if MarryMgr:isMarried() and info and info.gid == char.gid then
      self:setCtrlVisible("SpouseButton", true)
    end
  end
  self.showBtnCou = self:initButtonList(self:isFromChatGroup())
  self:setVisible(true)
  self:refreshDlgHeight()
  self:somethingForChild()
end
function CharMenuContentDlg:refreshCharWorshipTimes(gid)
  if string.isNilOrEmpty(gid) or gid ~= self.curChar.gid then
    return
  end
  self:setLabelText("RemarksLabel", CHS[7120366])
  local worShipTimes = DlgMgr:sendMsg("FamousDlg", "getWorShipTimesByGid", gid)
  if worShipTimes then
    self:setColorText(gf:filtTextOnly(worShipTimes), "RemarkValuePanel", nil, nil, nil, COLOR3.WHITE, 21)
  else
    self:setColorText("", "RemarkValuePanel", nil, nil, nil, COLOR3.WHITE, 21)
  end
end
function CharMenuContentDlg:somethingForChild()
end
function CharMenuContentDlg:refreshDlgHeight(btnCou)
  local remarkPanelHeight = math.max(self.remarkPanelOrgHeight, self:getCtrlContentSize("RemarkValuePanel").height)
  local charInfoSetHeight = self.charPanelOrgSz.height
  if remarkPanelHeight ~= self.remarkPanelOrgHeight then
    charInfoSetHeight = self.charPanelOrgSz.height - self.remarkPanelOrgHeight + remarkPanelHeight
  end
  self:setCtrlContentSize("CharInfoPanel", self.charPanelOrgSz.width, charInfoSetHeight)
  if not self.showBtnCou then
    return
  end
  local operatePanelSz = self:getCtrlContentSize("OperatePanel")
  local addHeight = (math.ceil(self.showBtnCou / 2) - 1) * self.buttonCell:getContentSize().height
  local rootHeight = charInfoSetHeight + operatePanelSz.height + addHeight + 10
  self:setCtrlContentSize("InfoPanel", self.rootSize.width, rootHeight)
  self.root:setContentSize(self.rootSize.width, rootHeight)
  self:updateLayout("InfoPanel")
end
function CharMenuContentDlg:initButtonList(isFromChatGroup)
  local btnMenu = self:getMenuList(isFromChatGroup)
  local panel = self:getControl("OperatePanel")
  panel:removeAllChildren()
  local columnSpace = 2
  local lineSpace = 2
  local cou = #btnMenu
  local size = self.buttonCell:getContentSize()
  local x, y = self.buttonCell:getPosition()
  for i = 1, #btnMenu do
    local btn = self.buttonCell:clone()
    btn:setTag(btnMenu[i].tag)
    if btnMenu[i].normalbg then
      btn:loadTextureNormal(btnMenu[i].normalbg)
    end
    if btnMenu[i].pressedbg then
      btn:loadTexturePressed(btnMenu[i].pressedbg)
    end
    btn:setTitleText(btnMenu[i].button)
    btn:setPosition(x + (i + 1) % 2 * (size.width + columnSpace), y)
    if i % 2 == 0 then
      y = y - size.height - lineSpace
    end
    panel:addChild(btn)
    self:blindLongPress(btn, self.longChooseButton, self.chooseButton, nil, not btnMenu[i] or 4 ~= btnMenu[i].tag)
  end
  return cou
end
function CharMenuContentDlg:getMenuListByCity(isFromChatGroup)
  local menus = {}
  table.insert(menus, ButtonList[2])
  if CitySocialMgr:hasCityFriendByGid(self.curChar.gid) then
    table.insert(menus, {
      button = CHS[5400503],
      tag = 17
    })
  else
    table.insert(menus, {
      button = CHS[5400502],
      tag = 17
    })
  end
  table.insert(menus, ButtonList[16])
  if FriendMgr:hasFriend(self.curChar.gid) or CitySocialMgr:hasCityFriendByGid(self.curChar.gid) or FriendMgr:isBlackByGId(self.curChar.gid) then
    table.insert(menus, ButtonList[11])
  end
  if FriendMgr:isBlackByGId(self.gid) then
    table.insert(menus, {
      button = CHS[5000063],
      tag = 8
    })
  elseif not isFromChatGroup then
    table.insert(menus, {
      button = CHS[5000065],
      tag = 8
    })
  end
  table.insert(menus, ButtonList[18])
  return menus
end
function CharMenuContentDlg:getMenuListByTeamEnlist(isFromChatGroup)
  local menus = {}
  table.insert(menus, ButtonList[16])
  table.insert(menus, ButtonList[18])
  return menus
end
function CharMenuContentDlg:getMenuListByBaozqy()
  local menus = {}
  table.insert(menus, ButtonList[1])
  table.insert(menus, ButtonList[2])
  if not FriendMgr:hasFriend(self.gid) then
    table.insert(menus, {
      button = CHS[5000064],
      tag = 3
    })
  end
  table.insert(menus, ButtonList[16])
  return menus
end
function CharMenuContentDlg:getMenuListByFamousKuafu()
  local menus = {}
  if DlgMgr:sendMsg("FamousDlg", "needShowWorShipButton") then
    table.insert(menus, ButtonList[20])
  end
  table.insert(menus, ButtonList[1])
  table.insert(menus, ButtonList[16])
  return menus
end
function CharMenuContentDlg:getMenuListByFamouseMe()
  local menus = {}
  if DlgMgr:sendMsg("FamousDlg", "needShowWorShipButton") then
    table.insert(menus, ButtonList[20])
  end
  table.insert(menus, ButtonList[16])
  return menus
end
function CharMenuContentDlg:getMenuListByKuafuBlog(isFromChatGroup)
  local menus = {}
  table.insert(menus, ButtonList[2])
  table.insert(menus, ButtonList[16])
  if FriendMgr:hasFriend(self.curChar.gid) or CitySocialMgr:hasCityFriendByGid(self.curChar.gid) or FriendMgr:isBlackByGId(self.curChar.gid) then
    table.insert(menus, ButtonList[11])
  end
  if FriendMgr:isBlackByGId(self.gid) then
    table.insert(menus, {
      button = CHS[5000063],
      tag = 8
    })
  elseif not isFromChatGroup then
    table.insert(menus, {
      button = CHS[5000065],
      tag = 8
    })
  end
  table.insert(menus, ButtonList[18])
  return menus
end
function CharMenuContentDlg:getMenuList(isFromChatGroup)
  local menus = {}
  if self.muneType == CHAR_MUNE_TYPE.CITY then
    return self:getMenuListByCity(isFromChatGroup)
  elseif self.muneType == CHAR_MUNE_TYPE.TEAM_ENLIST and FriendMgr:getKuafObjDist(self.gid) then
    return self:getMenuListByTeamEnlist(isFromChatGroup)
  elseif self.muneType == CHAR_MUNE_TYPE.KUAFU_BLOG then
    return self:getMenuListByKuafuBlog(isFromChatGroup)
  elseif (self.muneType == CHAR_MUNE_TYPE.FAMOUS_KUAFU or self.muneType == CHAR_MUNE_TYPE.FAMOUS_NORMAL) and self.gid == Me:queryBasic("gid") then
    return self:getMenuListByFamouseMe()
  elseif self.muneType == CHAR_MUNE_TYPE.BAOZQY_RANK then
    return self:getMenuListByBaozqy(isFromChatGroup)
  elseif self.muneType == CHAR_MUNE_TYPE.FAMOUS_KUAFU then
    return self:getMenuListByFamousKuafu(isFromChatGroup)
  end
  if self.muneType == CHAR_MUNE_TYPE.FAMOUS_NORMAL and DlgMgr:sendMsg("FamousDlg", "needShowWorShipButton") then
    table.insert(menus, ButtonList[20])
  end
  if FriendMgr:getKuafObjDist(self.gid) then
    table.insert(menus, ButtonList[2])
    if CitySocialMgr:hasCityFriendByGid(self.gid) then
      table.insert(menus, {
        button = CHS[5400503],
        tag = 17
      })
    else
      table.insert(menus, {
        button = CHS[5400502],
        tag = 17
      })
    end
    if FriendMgr:isBlackByGId(self.gid) then
      table.insert(menus, {
        button = CHS[5000063],
        tag = 8
      })
    elseif not isFromChatGroup then
      table.insert(menus, {
        button = CHS[5000065],
        tag = 8
      })
    end
    if CitySocialMgr:hasCityFriendByGid(self.gid) or FriendMgr:isBlackByGId(self.gid) then
      table.insert(menus, ButtonList[11])
    end
    return menus
  end
  table.insert(menus, ButtonList[1])
  table.insert(menus, ButtonList[2])
  if self.muneType == CHAR_MUNE_TYPE.GROUP_OWNER then
    table.insert(menus, ButtonList[19])
  end
  local name = self.curChar.name
  if not MapMgr:isInMasquerade() or self.muneType ~= CHAR_MUNE_TYPE.SCENE then
    if FriendMgr:hasFriend(self.gid) then
      if not isFromChatGroup then
        table.insert(menus, {
          button = CHS[5000062],
          tag = 3
        })
      end
    else
      table.insert(menus, {
        button = CHS[5000064],
        tag = 3
      })
    end
  end
  if TeamMgr:inTeamEx(Me:getId()) == false then
    if (not self:isOperateMonsterInMasquerade() and self.curChar.charStatus and self.curChar.charStatus:isSet(CHAR_STATUS.IN_TEAM)) == true then
      table.insert(menus, {
        button = CHS[4000276],
        tag = 6
      })
      self.teamButtonType = TEAM_BUTTON_TYPE.request
    end
  elseif TeamMgr:getLeaderId() == Me:getId() then
    table.insert(menus, {
      button = CHS[4000275],
      tag = 6
    })
    self.teamButtonType = TEAM_BUTTON_TYPE.invite
  elseif not TeamMgr:inTeamEx(Me:getId()) and (self:isOperateMonsterInMasquerade() or self.curChar.charStatus and not self.curChar.charStatus:isSet(CHAR_STATUS.IN_TEAM)) then
    table.insert(menus, {
      button = CHS[4000275],
      tag = 6
    })
    self.teamButtonType = TEAM_BUTTON_TYPE.invite
  end
  table.insert(menus, ButtonList[16])
  if not isFromChatGroup and self.muneType ~= CHAR_MUNE_TYPE.FAMOUS_NORMAL then
    table.insert(menus, ButtonList[4])
  end
  if self:isOperateMonsterInMasquerade() and self.backCharInfo and self.backCharInfo.titleInfo[Const.TITLE_IN_COMBAT] or self.curChar.charStatus and (self.curChar.charStatus:isSet(CHAR_STATUS.IN_COMBAT) == true or self.curChar.charStatus:isSet(CHAR_STATUS.IN_LOOKON) == true) and self.muneType == CHAR_MUNE_TYPE.SCENE then
    table.insert(menus, ButtonList[5])
  end
  if not MapMgr:isInMasquerade() or self.muneType ~= CHAR_MUNE_TYPE.SCENE then
    if Me:queryBasic("party/name") ~= "" and string.isNilOrEmpty(self.curChar.party) and not string.isNilOrEmpty(self.curChar.isOnline) and self.curChar.isOnline ~= 2 then
      if PartyMgr:checkAgreeOrDenyApply() then
        table.insert(menus, {
          button = CHS[4000303],
          tag = 7
        })
      end
    elseif Me:queryBasic("party/name") == "" and not string.isNilOrEmpty(self.curChar.party) then
      table.insert(menus, {
        button = CHS[4000319],
        tag = 7
      })
    end
  end
  if GMMgr:isGM() then
    table.insert(menus, {
      button = CHS[3002320],
      tag = 9
    })
  end
  if FriendMgr:hasFriend(self.gid) and not isFromChatGroup and (not MapMgr:isInMasquerade() or self.muneType ~= CHAR_MUNE_TYPE.SCENE) then
    table.insert(menus, ButtonList[12])
  end
  if not isFromChatGroup and (not MapMgr:isInMasquerade() or self.muneType ~= CHAR_MUNE_TYPE.SCENE) then
    table.insert(menus, ButtonList[14])
  end
  return menus
end
function CharMenuContentDlg:getMoreCount(isFromChatGroup)
  local count = 0
  if not isFromChatGroup then
    count = count + 1
  end
  if not isFromChatGroup then
    count = count + 1
  end
  if (FriendMgr:hasFriend(self.gid) or FriendMgr:isBlackByGId(self.gid)) and not isFromChatGroup then
    count = count + 1
  end
  if FriendMgr:isBlackByGId(self.gid) then
    count = count + 1
  elseif not isFromChatGroup then
    count = count + 1
  end
  count = count + 1
  count = count + 1
  return count
end
function CharMenuContentDlg:longChooseButton(sender, eventType)
  local tag = sender:getTag()
  if 4 == tag then
    self:onFightButton(true)
    self:onCloseButton()
  end
end
function CharMenuContentDlg:chooseButton(sender, eventType)
  if not self.curChar then
    return
  end
  local tag = sender:getTag()
  if tag == 1 then
    self:onViewEquipmentButton()
  elseif tag == 2 then
    self:onCommunicatButton()
    self:onCloseButton()
  elseif tag == 3 then
    self:onAddFriendButton(self.curChar)
    self:onCloseButton()
  elseif tag == 4 then
    self:onFightButton()
    self:onCloseButton()
  elseif tag == 5 then
    self:onLookonButton()
    self:onCloseButton()
  elseif tag == 6 then
    self:onTeamButton()
    self:onCloseButton()
  elseif tag == 7 then
    self:onPartyButton()
    self:onCloseButton()
  elseif tag == 8 then
    self:onAddBlacklistButton()
    self:onCloseButton()
  elseif tag == 9 then
    local dlg = DlgMgr:openDlg("GMUserManageDlg")
    local data = {
      account = self.curChar.account,
      name = self.curChar.name,
      gid = self.curChar.gid,
      level = self.curChar.level,
      polar = self.curChar.polar
    }
    dlg:setUser(data)
    GMMgr:cmdQueryByPlayer(self.curChar.name, "name")
  elseif tag == 10 then
    self:sendToFriend(self.curChar)
  elseif tag == 11 then
    self:remark(self.curChar)
  elseif tag == 12 then
    self:friendGroup(self.curChar)
  elseif tag == 13 then
    self:givingThings(self.curChar)
  elseif tag == 14 then
    self:theMore(self.curChar, self:isFromChatGroup())
  elseif tag == 15 then
    gf:copyTextToClipboard(self.curChar and self.curChar.name or "")
    gf:ShowSmallTips(CHS[2100087])
  elseif tag == 16 then
    BlogMgr:openBlog(self.curChar.gid, nil, nil, self.curChar.dist_name)
    self:onCloseButton()
  elseif tag == 17 then
    self:onAddCityFriendButton()
    self:onCloseButton()
  elseif tag == 18 then
    self:onJubao(self.curChar)
    self:onCloseButton()
  elseif tag == 19 then
    self:onChangeGroupOwner(self.curChar)
    self:onCloseButton()
  elseif tag == 20 then
    if DlgMgr:sendMsg("FamousDlg", "onMoBaiButton", self.curChar.gid) then
      self:onCloseButton()
    end
  else
    self:onClickButton(sender)
    self:onCloseButton()
  end
end
function CharMenuContentDlg:onClickButton(sender)
end
function CharMenuContentDlg:onRelationshipButton(sender)
  if not self.curChar then
    return
  end
  if FriendMgr:hasFriend(self.gid) then
    self:setCtrlVisible("FDValueLabel", true)
  else
    do
      local char = self.curChar
      gf:confirm(CHS[3002322], function()
        self:onAddFriendButton(char)
      end)
    end
  end
end
function CharMenuContentDlg:onSpouseButton(sender)
  if not self.curChar then
    return
  end
  local rect = self:getBoundingBoxInWorldSpace(self.root)
  local dlg = DlgMgr:openDlg("SpouseDlg")
  dlg:setData(self.curChar)
  dlg:setFloatingFramePos(rect)
end
function CharMenuContentDlg:onViewEquipmentButton()
  if self:isOperateMonsterInMasquerade() then
    gf:ShowSmallTips(CHS[7002121])
    return
  end
  gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_LOOK_PLAYER_EQUIP, self.curChar.gid, self.curChar.dist_name)
end
function CharMenuContentDlg:MSG_LOOK_PLAYER_EQUIP(data)
  self:onCloseButton()
end
function CharMenuContentDlg:onCommunicatButton()
  if self:isOperateMonsterInMasquerade() and self.backCharInfo then
    local charInfo = self.backCharInfo
    FriendMgr:communicat(charInfo.alicename, charInfo.gid, charInfo.icon, charInfo.level, true, charInfo.dist_name)
  else
    local gid = self.curChar.gid
    if self.muneType == CHAR_MUNE_TYPE.FRIEND_SEARCH then
      if FriendMgr:isBlackByGId(gid) then
        gf:ShowSmallTips(CHS[5000075])
        return
      end
      if self.curChar.isOnline == 2 and not FriendMgr:hasFriend(gid) and not FriendMgr:isTempByGid(gid) then
        gf:ShowSmallTips(CHS[5420473])
        return
      end
    end
    FriendMgr:communicat(self.curChar.name, gid, self.curChar.icon, self.curChar.level, true, self.curChar.dist_name)
  end
end
function CharMenuContentDlg:onAddFriendButton(char)
  local name = char.name
  local gid = self.gid or char.gid
  if not name or not gid then
    return
  end
  if not GameMgr:IsCrossDist() then
    name = gf:getRealName(name, true)
  end
  if FriendMgr:hasFriend(gid) then
    local str = string.format(CHS[5000060], gf:getRealName(name))
    gf:confirm(str, function()
      FriendMgr:deleteFriend(name, gid)
    end)
  else
    FriendMgr:addFriend(name)
  end
  DlgMgr:closeDlg(self.name)
end
function CharMenuContentDlg:onAddCityFriendButton()
  local name = self.curChar.name
  if nil == name then
    return
  end
  CitySocialMgr:tryToAddCityFriend(name, self.gid, self.curChar.isOnline)
end
function CharMenuContentDlg:onFightButton(isPk)
  if GameMgr:IsCrossDist() and not DistMgr:isInZBYLServer() and not DistMgr:isInQcldServer() and not QuanminPK2Mgr:isCanFightInQuanmpk() and not DistMgr:isInKFZC2019Server() and not DistMgr:isInKFBZServer() then
    gf:ShowSmallTips(CHS[5000267])
    return
  end
  if Me:isInPrison() then
    gf:ShowSmallTips(CHS[7000070])
    return
  end
  if self:isOperateMonsterInMasquerade() and self.backCharInfo then
    gf:CmdToServer("CMD_KILL", {
      victim_id = self.backCharInfo.id,
      flag = isPk and 1 or 0,
      gid = self.backCharInfo.gid or ""
    })
    return
  end
  if not self.curChar then
    return
  end
  if self.curChar.id then
    gf:CmdToServer("CMD_KILL", {
      victim_id = self.curChar.id,
      flag = isPk and 1 or 0,
      gid = self.curChar.gid or ""
    })
  else
    gf:ShowSmallTips(CHS[3000118])
  end
end
function CharMenuContentDlg:onLookonButton()
  if self:isOperateMonsterInMasquerade() and self.backCharInfo then
    FightMgr:lookFight(self.backCharInfo.id)
    return
  end
  if not self.curChar.id then
    return
  end
  FightMgr:lookFight(self.curChar.id)
end
function CharMenuContentDlg:onTeamButton()
  if Me:isInPrison() then
    gf:ShowSmallTips(CHS[7000071])
    return
  end
  if self:isOperateMonsterInMasquerade() and self.teamButtonType and self.backCharInfo then
    if self.teamButtonType == TEAM_BUTTON_TYPE.invite then
      if TaskMgr:isInTaskBKTX() then
        gf:ShowSmallTips(CHS[4010222])
        return
      end
      gf:CmdToServer("CMD_REQUEST_JOIN", {
        peer_name = self.backCharInfo.name,
        id = self.backCharInfo.id,
        ask_type = Const.INVITE_JOIN_TEAM
      })
      return
    elseif self.teamButtonType == TEAM_BUTTON_TYPE.request then
      gf:CmdToServer("CMD_REQUEST_JOIN", {
        peer_name = self.backCharInfo.name,
        id = self.backCharInfo.id,
        ask_type = Const.REQUEST_JOIN_TEAM
      })
      return
    end
  end
  if not self.curChar then
    return
  end
  if Me:isTeamLeader() then
    if TaskMgr:isInTaskBKTX() then
      gf:ShowSmallTips(CHS[4010222])
      return
    end
    gf:CmdToServer("CMD_REQUEST_JOIN", {
      peer_name = self.curChar.name,
      id = self.curChar.id,
      ask_type = Const.INVITE_JOIN_TEAM
    })
    return
  end
  if not self.curChar.charStatus then
    return
  end
  if not self.curChar.charStatus:isSet(CHAR_STATUS.IN_TEAM) then
    if TaskMgr:isInTaskBKTX() then
      gf:ShowSmallTips(CHS[4010222])
      return
    end
    gf:CmdToServer("CMD_REQUEST_JOIN", {
      peer_name = self.curChar.name,
      id = self.curChar.id,
      ask_type = Const.INVITE_JOIN_TEAM
    })
  else
    gf:CmdToServer("CMD_REQUEST_JOIN", {
      peer_name = self.curChar.name,
      id = self.curChar.id,
      ask_type = Const.REQUEST_JOIN_TEAM
    })
  end
end
function CharMenuContentDlg:onPartyButton()
  if not self.curChar.party then
    return
  end
  if Me:queryBasic("party/name") == "" and not string.isNilOrEmpty(self.curChar.party) then
    PartyMgr:addParties(self.curChar.party)
    self:onCloseButton()
    return
  end
  PartyMgr:inviteJionParty(self.curChar.name)
  self:onCloseButton()
end
function CharMenuContentDlg:onAddBlacklistButton()
  local name = self.curChar.name
  if nil == name then
    return
  end
  if FriendMgr:isBlackByGId(self.gid) then
    FriendMgr:deleteFromBlack(self.gid)
  else
    do
      local curChar = self.curChar
      local gid = self.gid
      if FriendMgr:hasFriend(self.gid) then
        local str = string.format(CHS[5000061], gf:getRealName(name))
        gf:confirm(str, function()
          FriendMgr:addBlack(name, curChar.icon, curChar.level, gid, curChar.dist_name)
        end)
      else
        FriendMgr:addBlack(name, curChar.icon, curChar.level, gid, curChar.dist_name)
      end
    end
  end
end
function CharMenuContentDlg:updateFriendButton()
  if not self.curChar then
    return
  end
  local name = self.curChar.name
  if FriendMgr:hasFriend(self.gid) then
    self:setButtonText("AddFriendButton", CHS[5000062])
  else
    self:setButtonText("AddFriendButton", CHS[5000064])
  end
  if FriendMgr:isBlackByGId(self.gid) then
    self:setButtonText("AddFriendButton", CHS[5000063])
  else
    self:setButtonText("AddFriendButton", CHS[5000065])
  end
end
function CharMenuContentDlg:sendToFriend(friend)
  if not FriendMgr:hasFriend(friend.gid) then
    gf:ShowSmallTips(string.format(CHS[6000269], friend.name))
    return
  elseif friend.isOnline == 2 then
    gf:ShowSmallTips(CHS[6000270])
    return
  end
  if not FriendMgr:hasUpdateCharInfo(friend.gid) then
    gf:ShowSmallTips(CHS[2200064])
    return
  end
  if friend.isInThereFrend == 1 then
    local dlg = DlgMgr:openDlgEx("SubmitFDIDlg", friend.gid)
  else
    gf:ShowSmallTips(string.format(CHS[4200168], friend.name))
  end
end
function CharMenuContentDlg:onChangeGroupOwner(char)
  if not char then
    return
  end
  if not self.param or not self.param.groupId then
    return
  end
  gf:CmdToServer("CMD_CHANGE_CHAT_GROUP_LEADER", {
    changer_gid = char.gid,
    group_id = self.param.groupId
  })
end
function CharMenuContentDlg:theMore(char, isFromChatGroup)
  if self:getMoreCount(isFromChatGroup) == 0 then
    return
  end
  local dlg = DlgMgr:openDlg("MoreCharMenuDlg")
  dlg:getMenu(char, isFromChatGroup)
  local dlgRect = self:getBoundingBoxInWorldSpace(dlg.root)
  local rect = self:getBoundingBoxInWorldSpace(self.root)
  if rect.x + rect.width + dlgRect.width > Const.WINSIZE.width then
    dlg.root:setPosition(rect.x - dlgRect.width, rect.y + rect.height)
  else
    dlg.root:setPosition(rect.x + rect.width, rect.y + rect.height)
  end
end
function CharMenuContentDlg:remark(friend)
  local dlg = DlgMgr:openDlg("RemarksDlg")
  dlg:onDlgOpened(friend.gid)
end
function CharMenuContentDlg:friendGroup(friend)
  local rect = self.root:getBoundingBox()
  local rect = self:getBoundingBoxInWorldSpace(self.root)
  local gidsStr = friend.gid .. ";"
  local nameStr = friend.name .. ";"
  if FriendMgr:getFriendGroupCount() <= 1 then
    gf:ShowSmallTips(CHS[6000443])
    return
  end
  local dlg = DlgMgr:openDlg("SingleFlockMoveDlg")
  local group = FriendMgr:getFriendByGid(friend.gid)
  dlg:setMoveGidsString(group:queryBasic("group"), gidsStr, nameStr)
  dlg.root:setPosition(rect.x + rect.width, rect.y)
end
function CharMenuContentDlg:givingThings(friend)
  if not DistMgr:checkCrossDist() then
    return
  end
  GiveMgr:tryRequestGiving(friend)
  self:onCloseButton()
end
function CharMenuContentDlg:MSG_FRIEND_ADD_CHAR(data)
  self:updateFriendButton()
end
function CharMenuContentDlg:MSG_FRIEND_REMOVE_CHAR(data)
  self:updateFriendButton()
end
function CharMenuContentDlg:MSG_CHAR_INFO()
  if nil == self.gid then
    return
  end
  local data = FriendMgr:getCharMenuInfoByGid(self.gid)
  if nil == data then
    return
  end
  self.curChar = data
  self.curChar.settingFlag = Bitset.new(data.setting_flag)
  self.curChar.charStatus = Bitset.new(data.char_status)
  self:setInfo(self.curChar)
  self:updateRelationShip()
  self:setVisible(true)
  if self.rect then
    self:setFloatingFramePos(self.rect)
  end
end
function CharMenuContentDlg:MSG_FIND_CHAR_MENU_FAIL(data)
  if self.backCharInfo then
    local friend = FriendMgr:getFriendByGid(self.backCharInfo.gid)
    if friend then
      self.backCharInfo.friend_score = friend:queryInt("friend")
      self.backCharInfo.party = friend:queryBasic("party/name")
    end
    self.backCharInfo.isOnline = 2
    self:setInfo(self.backCharInfo)
  end
  if self.curChar then
    self.curChar.isOnline = 2
    self:setInfo(self.curChar)
  end
  gf:ShowSmallTips(CHS[3003112])
  self:setCtrlEnabled("PortraitImage", false)
  self:setLabelText("LineLabel", "")
  self:setCtrlVisible("LineBKImage", false)
end
function CharMenuContentDlg:setFloatingFramePos(rect)
  self.rect = rect
  Dialog.setFloatingFramePos(self, rect)
end
function CharMenuContentDlg:updateRelationShip()
  local file = ""
  if FriendMgr:hasFriend(self.gid) then
    file = ResMgr.ui.friend_heart_filled
  else
    file = ResMgr.ui.friend_heart_empty
  end
  self:setImagePlist("RelationshipImage", file)
end
function CharMenuContentDlg:MSG_FRIEND_MEMO()
  if not self.curChar then
    return
  end
  self:setColorText(gf:filtTextOnly(FriendMgr:getMemoByGid(self.curChar.gid)), "RemarkValuePanel", nil, nil, nil, COLOR3.WHITE, 21)
  self:updateLayout("CharInfoPanel")
  self:refreshDlgHeight()
end
function CharMenuContentDlg:isOperateMonsterInMasquerade()
  if MapMgr:isInMasquerade() and self.backCharInfo and self.backCharInfo.masquerade == 1 then
    return true
  end
end
function CharMenuContentDlg:setMonsterInMasqueradeInfo()
  self:setInfo(self.backCharInfo)
end
function CharMenuContentDlg:MSG_TEMP_FRIEND_STATE(data)
  if not self.curChar or self.curChar.gid ~= data.gid then
    return
  end
  if data.online == 2 then
    gf:ShowSmallTips(CHS[3003112])
    self:setCtrlEnabled("PortraitImage", false)
  else
    self:setCtrlEnabled("PortraitImage", true)
  end
  self.curChar.isOnline = data.online
end
function CharMenuContentDlg:cleanup()
  self.curChar = nil
  self.muneType = nil
  DlgMgr:closeDlg("SpouseDlg")
end
function CharMenuContentDlg:onJubao(char)
  local function doIt()
    if Me:queryInt("level") < 35 then
      gf:ShowSmallTips(CHS[4300312])
      self:onCloseButton()
      return
    end
    local data = {}
    data.user_gid = char.gid
    data.user_name = char.name
    data.type = "dlg"
    data.content = {}
    data.count = 0
    data.user_dist = char.dist_name
    if not data.user_dist or data.user_dist == "" then
      data.user_dist = GameMgr:getDistName()
    end
    gf:CmdToServer("CMD_REPORT_USER", data)
    self:onCloseButton()
    return
  end
  if ChatMgr.hasTipOffUser[char.gid] and ChatMgr.hasTipOffUser[char.gid] == 1 then
    if not FriendMgr:isBlackByGId(char.gid) then
      gf:confirm(string.format(CHS[4300318], char.name), function()
        FriendMgr:addBlack(char.name, char.icon, char.level, char.gid, char.dist_name or GameMgr:getDistName())
      end, function()
        doIt()
      end)
      self:onCloseButton()
      return
    else
      doIt()
    end
  else
    doIt()
  end
end
return CharMenuContentDlg
