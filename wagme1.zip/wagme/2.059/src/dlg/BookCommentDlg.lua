local BookCommentDlg = Singleton("BookCommentDlg", Dialog)
local LEVEL_LIMIT = 40
local WORD_LIMIT = 50
local MIN_LIKE_NUM = 10
local REQUEST_SPACE = 1000
function BookCommentDlg:init()
  self:bindListener("CommentButton", self.onCommentButton)
  self:bindListener("DelButton", self.onDelButton)
  self:bindListener("ExpressionButton", self.onExpressionButton)
  self:bindListener("ThumbButton", self.onThumbButton)
  self:bindListener("TouchPanel", self.swichWordInput)
  self:bindListener("PlayerNameLabel", self.onPlayerNameLabel, "OneMessagePanel")
  self:blindLongPress("OneMessagePanel", self.onOneMessagePanel)
  self.oneMessagePanel = self:retainCtrl("OneMessagePanel")
  self.seperatePanel = self:retainCtrl("SeperatePanel")
  self.loadingPanel = self:retainCtrl("LoadingPanel")
  self.listView = self:resetListView("ListView", 1)
  self:initView()
  self.data = nil
  self.selectChar = nil
  self.isLoading = nil
  self.isLoadEnd = nil
  self.notCallListView = nil
  if not Me:isBindName() then
    gf:CmdToServer("CMD_REQUEST_FUZZY_IDENTITY", {force_request = 0})
  end
  self:hookMsg("MSG_HANDBOOK_COMMENT_QUERY_LIST")
  self:hookMsg("MSG_HANDBOOK_COMMENT_PUBLISH")
  self:hookMsg("MSG_HANDBOOK_COMMENT_DELETE")
  self:hookMsg("MSG_HANDBOOK_COMMENT_LIKE")
  self:hookMsg("MSG_CHAR_INFO_EX")
  self:hookMsg("MSG_OFFLINE_CHAR_INFO")
end
function BookCommentDlg:setCommentObj(info, type)
  if type == "boss" then
    self:setCtrlVisible("PetTitlePanel", false)
    self:setCtrlVisible("BossTitlePanel", true)
    self:setCtrlVisible("QishaTitlePanel", false)
    self.petName = CHS[5400589] .. info.name
  elseif type == "jiutian" then
    self:setCtrlVisible("PetTitlePanel", false)
    self:setCtrlVisible("BossTitlePanel", true)
    self:setCtrlVisible("QishaTitlePanel", false)
    self.petName = CHS[5400589] .. info.name
    self:setLabelText("TitleLabel_1", info.name .. CHS[4010188], "BossTitlePanel")
    self:setLabelText("TitleLabel_2", info.name .. CHS[4010188], "BossTitlePanel")
  elseif type == "qisha_shilian" then
    self:setCtrlVisible("PetTitlePanel", false)
    self:setCtrlVisible("BossTitlePanel", false)
    self:setCtrlVisible("QishaTitlePanel", true)
    self.petName = CHS[5400589] .. info.name
  elseif type == "difu_sheny" then
    self:setCtrlVisible("PetTitlePanel", false)
    self:setCtrlVisible("BossTitlePanel", false)
    self:setCtrlVisible("QishaTitlePanel", true)
    self.petName = CHS[5400589] .. info.name
    self:setLabelText("TitleLabel_1", CHS[4101656], "QishaTitlePanel")
    self:setLabelText("TitleLabel_2", CHS[4101656], "QishaTitlePanel")
  else
    self:setCtrlVisible("PetTitlePanel", true)
    self:setCtrlVisible("BossTitlePanel", false)
    self:setCtrlVisible("QishaTitlePanel", false)
    self.petName = CHS[5400588] .. info.name
  end
  self:setImage("PortraitImage", ResMgr:getSmallPortrait(info.icon), "PetTypePanel")
  self:setLabelText("PetNameLabel", info.name, "PetTypePanel")
  self:requestCommentList(0, "")
end
function BookCommentDlg:requestCommentList(time, id)
  self.lastRequestId = id
  self.lastRequestTime = gfGetTickCount()
  gf:CmdToServer("CMD_HANDBOOK_COMMENT_QUERY_LIST", {
    key_name = self.petName,
    last_time = time,
    last_id = id
  })
end
function BookCommentDlg:requestComment(comment)
  gf:CmdToServer("CMD_HANDBOOK_COMMENT_PUBLISH", {
    key_name = self.petName,
    comment = comment
  })
end
function BookCommentDlg:requestDeleteComment(id)
  gf:CmdToServer("CMD_HANDBOOK_COMMENT_DELETE", {
    key_name = self.petName,
    id = id
  })
end
function BookCommentDlg:requestLikeComment(id)
  gf:CmdToServer("CMD_HANDBOOK_COMMENT_LIKE", {
    key_name = self.petName,
    id = id
  })
end
function BookCommentDlg:initView()
  self:setCtrlVisible("NoticePanel", false)
  local function onScrollView(sender, eventType)
    if self.notCallListView or self.isLoadEnd or self.isLoading then
      return
    end
    if ccui.ScrollviewEventType.scrolling == eventType or ccui.ScrollviewEventType.scrollToTop == eventType or ccui.ScrollviewEventType.scrollToBottom == eventType then
      do
        local listInnerContent = sender:getInnerContainer()
        local innerSize = listInnerContent:getContentSize()
        local scrollViewSize = sender:getContentSize()
        local lastData = self:getLoadedLastData()
        if not lastData then
          return
        end
        local innerPosY = listInnerContent:getPositionY() + 0.5
        if innerPosY > 10 then
          self:setLoadingVisible(true)
          local curTime = gfGetTickCount()
          local cTime = REQUEST_SPACE - (curTime - self.lastRequestTime)
          cTime = math.max(cTime, 0)
          performWithDelay(sender, function()
            self:requestCommentList(lastData.time, lastData.id)
          end, cTime / 1000)
        end
      end
    end
  end
  self.listView:addScrollViewEventListener(onScrollView)
  self:setCtrlVisible("DelButton", false, "InputPanel")
  self.editBox = self:createEditBox("TextPanel", "InputPanel", nil, function(sender, type)
    if "ended" == type then
    elseif "changed" == type then
      if not self.editBox then
        return
      end
      local content = self.editBox:getText()
      local len = gf:getTextLength(content)
      if len > WORD_LIMIT * 2 then
        content = gf:subString(content, WORD_LIMIT * 2)
        self.editBox:setText(content)
        gf:ShowSmallTips(string.format(CHS[5400591], WORD_LIMIT))
      end
      if len == 0 then
        self:setCtrlVisible("DelButton", false, "InputPanel")
      else
        self:setCtrlVisible("DelButton", true, "InputPanel")
      end
    end
  end)
  self.editBox:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
  self.editBox:setPlaceholderFont(CHS[3003794], 19)
  self.editBox:setFont(CHS[3003794], 19)
  self.editBox:setFontColor(COLOR3.ORANGE)
  self.editBox:setPlaceHolder(CHS[5400587])
  self.editBox:setPlaceholderFontSize(19)
  self.editBox:setPlaceholderFontColor(cc.c3b(102, 102, 102))
  local circleCtrl = self:getControl("LoadingImage", nil, self.loadingPanel)
  local rotate = cc.RotateBy:create(1, 360)
  local action = cc.RepeatForever:create(rotate)
  circleCtrl:runAction(action)
end
function BookCommentDlg:getLoadedLastData()
  local list = self.listView
  local items = list:getItems()
  local count = #items
  if count ~= 0 then
    return items[count].data
  end
end
function BookCommentDlg:onThumbButton(sender, eventType)
  local data = sender:getParent().data
  if Me:queryBasicInt("level") < LEVEL_LIMIT then
    gf:ShowSmallTips(string.format(CHS[5400581], LEVEL_LIMIT))
    return
  end
  if not data then
    return
  end
  if data.has_like == 1 then
    gf:ShowSmallTips(CHS[5450119])
    return
  end
  if data.like_num >= 9999 then
    gf:ShowSmallTips(CHS[5400582])
    return
  end
  self:requestLikeComment(data.id)
end
function BookCommentDlg:onCommentButton(sender, eventType)
  if gf:isLimitChangeUserInfo() then
    return
  end
  self:sendMessage()
end
function BookCommentDlg:onDelButton(sender, eventType)
  self.editBox:setText("")
  sender:setVisible(false)
end
function BookCommentDlg:onPlayerNameLabel(sender, eventType)
  local data = sender:getParent().data
  if not data then
    return
  end
  if data and data.gid ~= Me:queryBasic("gid") then
    self.selectChar = {
      gid = data.gid,
      sender = sender
    }
    FriendMgr:requestCharMenuInfo(data.gid, nil, "BookCommentDlg", 1)
  end
end
function BookCommentDlg:MSG_CHAR_INFO_EX(data)
  if data.msg_type ~= "BookCommentDlg" or not self.selectChar or self.selectChar.gid ~= data.gid then
    return
  end
  local dlg = DlgMgr:openDlg("CharMenuContentDlg")
  dlg:setInfo(data)
  local rect = self:getBoundingBoxInWorldSpace(self.selectChar.sender)
  dlg:setFloatingFramePos(rect)
end
function BookCommentDlg:MSG_OFFLINE_CHAR_INFO(data)
  self:MSG_CHAR_INFO_EX(data)
end
function BookCommentDlg:onReportCommentForBlog(sender)
  local para = "@spcial@;" .. self.data.comment .. CHS[4300498] .. GameMgr:getDistName() .. ":" .. self.data.id
  ChatMgr:questOpenReportDlg(self.data.gid, self.data.name, GameMgr:getDistName(), para)
end
function BookCommentDlg:onOneMessagePanel(sender, eventType)
  local data = sender.data
  if not data then
    return
  end
  if data.gid ~= Me:queryBasic("gid") then
    self.data = data
    BlogMgr:showButtonList(self, sender, "onReportComment", self.name)
    return
  end
  BlogMgr:showButtonList(self, sender, "petDelCommentOp", self.name)
end
function BookCommentDlg:onDelComment(sender, eventType)
  if not sender then
    return
  end
  local data = sender.data
  if data then
    self:requestDeleteComment(data.id)
  end
end
function BookCommentDlg:onExpressionButton(sender, eventType)
  if Me:queryBasicInt("level") < LEVEL_LIMIT then
    gf:ShowSmallTips(string.format(CHS[5400584], LEVEL_LIMIT))
    return
  end
  local dlg = DlgMgr:getDlgByName("LinkAndExpressionDlg")
  if dlg then
    DlgMgr:closeDlg("LinkAndExpressionDlg")
    return
  end
  dlg = DlgMgr:openDlg("LinkAndExpressionDlg")
  dlg:setCallObj(self, "bookComment")
  local height = dlg:getMainBodyHeight()
  DlgMgr:upDlg("BookCommentDlg", height - 50)
end
function BookCommentDlg:addExpression(expression)
  if not self.editBox then
    return
  end
  local content = self.editBox:getText()
  if gf:getTextLength(content .. expression) > WORD_LIMIT * 2 then
    gf:ShowSmallTips(string.format(CHS[5400591], WORD_LIMIT))
    return
  end
  content = content .. expression
  self.editBox:setText(content)
  self:setCtrlVisible("DelButton", true, "InputPanel")
end
function BookCommentDlg:addSpace()
  if not self.editBox then
    return
  end
  local content = self.editBox:getText()
  if gf:getTextLength(content .. " ") > WORD_LIMIT * 2 then
    gf:ShowSmallTips(string.format(CHS[5400591], WORD_LIMIT))
    return
  end
  self.editBox:setText(content .. " ")
  self:setCtrlVisible("DelButton", true, "InputPanel")
end
function BookCommentDlg:deleteWord()
  if not self.editBox then
    return
  end
  local text = self.editBox:getText()
  local len = string.len(text)
  local deletNum = 0
  if len > 0 then
    if string.byte(text, len) < 128 then
      deletNum = 1
    elseif 128 <= string.byte(text, len - 1) and string.byte(text, len - 2) >= 224 then
      deletNum = 3
    elseif string.byte(text, len - 1) >= 192 then
      deletNum = 2
    end
    local newtext = string.sub(text, 0, len - deletNum)
    self.editBox:setText(newtext)
    if len - deletNum <= 0 then
      self:setCtrlVisible("DelButton", false, "InputPanel")
    end
  else
    self:setCtrlVisible("DelButton", false, "InputPanel")
  end
end
function BookCommentDlg:sendMessage()
  local content = self.editBox:getText()
  if Me:queryBasicInt("level") < LEVEL_LIMIT then
    gf:ShowSmallTips(string.format(CHS[5400584], LEVEL_LIMIT))
    return
  end
  if Me:getAdultStatus() == 2 then
    gf:ShowSmallTips(CHS[5400583])
    return
  end
  if content == "" then
    gf:ShowSmallTips(CHS[5400585])
    return
  end
  local filtTextStr, haveFilt = gf:filtTextByTwo(content, nil, true)
  if haveFilt then
    ChatMgr:shieldLog("wenzpb", 7, content)
    gf:ShowSmallTips(CHS[5400586])
    self.editBox:setText(filtTextStr)
    return
  end
  self:requestComment(content)
end
function BookCommentDlg:LinkAndExpressionDlgcleanup()
  DlgMgr:resetUpDlg("BookCommentDlg")
end
function BookCommentDlg:swichWordInput()
  if not self.editBox then
    return
  end
  if Me:queryBasicInt("level") < LEVEL_LIMIT then
    gf:ShowSmallTips(string.format(CHS[5400584], LEVEL_LIMIT))
    return
  end
  self.editBox:sendActionsForControlEvents(cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)
end
function BookCommentDlg:setOneMessagePanel(cell, data)
  self:setLabelText("PlayerNameLabel", "[" .. gf:getRealName(data.name) .. "]", cell)
  if data.isHot == 1 then
    self:setCtrlVisible("HotImage", true, cell)
  else
    self:setCtrlVisible("HotImage", false, cell)
  end
  if data.like_num > 9999 then
    self:setLabelText("ThumbNumberLabel", 9999, cell)
  else
    self:setLabelText("ThumbNumberLabel", data.like_num, cell)
  end
  self:setCtrlVisible("HotThumbedImage", false, cell)
  self:setCtrlVisible("OrdinaryThumbedImage", false, cell)
  self:setCtrlVisible("HotThumbImage", false, cell)
  self:setCtrlVisible("OrdinaryThumbImage", false, cell)
  if data.has_like == 1 then
    if data.isHot == 1 then
      self:setCtrlVisible("HotThumbedImage", true, cell)
    else
      self:setCtrlVisible("OrdinaryThumbedImage", true, cell)
    end
  elseif data.isHot == 1 then
    self:setCtrlVisible("HotThumbImage", true, cell)
  else
    self:setCtrlVisible("OrdinaryThumbImage", true, cell)
  end
  local str = gf:getServerDate("%Y-%m-%d", data.time)
  self:setLabelText("TimeLabel", str, cell)
  local msg = data.comment
  msg = gf:filtTextOnly(msg, true)
  local curHeight, oldHeight = self:setColorText(msg, "TextPanel", cell, nil, nil, nil, 19, nil, nil, data.sender_vip ~= 0)
  if oldHeight < curHeight then
    local size = cell:getContentSize()
    local height = size.height - oldHeight + curHeight
    cell:setContentSize(size.width, height)
    self:setCtrlContentSize("BKImage", size.width, height - 2, cell)
  end
  cell.data = data
end
function BookCommentDlg:setLoadingVisible(visible)
  if self.isLoading == visible then
    return
  end
  local listView = self.listView
  self:setCtrlVisible("LoadingPanel", visible, "LoadPanel")
  self.isLoading = visible
  if visible then
    listView:pushBackCustomItem(self.loadingPanel)
  elseif self.loadingPanel:getParent() then
    listView:removeChild(self.loadingPanel, false)
  end
  self.notCallListView = true
  listView:refreshView()
  self.notCallListView = false
end
function BookCommentDlg:refreshList(data, isReset)
  if isReset then
    self.listView:removeAllItems()
    if #data == 0 then
      self:setCtrlVisible("NoticePanel", true)
      self.listView:setVisible(false)
      return
    else
      self:setCtrlVisible("NoticePanel", false)
      self.listView:setVisible(true)
    end
  end
  local lastHeight = self.listView:getInnerContainer():getContentSize().height
  for i = 1, #data do
    local panel = self.oneMessagePanel:clone()
    self:setOneMessagePanel(panel, data[i])
    panel:setName(data[i].id)
    self.listView:pushBackCustomItem(panel)
  end
  if isReset and 0 < self.hotNum then
    self.seperatePanel:removeFromParent()
    self.listView:insertCustomItem(self.seperatePanel, self.hotNum)
  end
  if not isReset and #data > 0 then
    self.notCallListView = true
    self.listView:requestRefreshView()
    self.listView:doLayout()
    performWithDelay(self.root, function()
      self:jumpToItem(lastHeight)
      self.notCallListView = false
    end, 0)
  end
end
function BookCommentDlg:jumpToItem(offsetY)
  local contentSize = self.listView:getContentSize()
  local innerContainer = self.listView:getInnerContainer()
  local minY = contentSize.height - innerContainer:getContentSize().height
  offsetY = minY + offsetY - contentSize.height
  if offsetY <= 0 then
    offsetY = math.max(offsetY, minY)
  end
  innerContainer:setPositionY(offsetY)
end
function BookCommentDlg:MSG_HANDBOOK_COMMENT_QUERY_LIST(data)
  if data.key_name ~= self.petName then
    return
  end
  if self.lastRequestId ~= data.last_id then
    return
  end
  self.lastRequestId = ""
  self:setLoadingVisible(false)
  if data.count == -1 then
    return
  end
  if data.count == 0 then
    self.isLoadEnd = true
    if data.last_id ~= "" then
      gf:ShowSmallTips(CHS[5450120])
    end
  end
  if data.last_id == "" then
    for i = 1, 3 do
      if data[i] and data[i].like_num >= MIN_LIKE_NUM then
        data[i].isHot = 1
        self.hotNum = i
      else
        self.hotNum = i - 1
        break
      end
    end
    self:refreshList(data, true)
  else
    self:refreshList(data)
  end
end
function BookCommentDlg:MSG_HANDBOOK_COMMENT_PUBLISH(data)
  if data.key_name ~= self.petName then
    return
  end
  self:onDelButton(self:getControl("DelButton"))
end
function BookCommentDlg:checkHot(data)
  if data and data.isHot then
    self.hotNum = self.hotNum - 1
  end
  if self.hotNum <= 0 then
    self.listView:removeChild(self.seperatePanel, true)
  end
end
function BookCommentDlg:MSG_HANDBOOK_COMMENT_DELETE(data)
  local cell = self.listView:getChildByName(data.id)
  if cell then
    self:checkHot(cell.data)
    self.listView:removeChild(cell, true)
    self.listView:requestRefreshView()
    local items = self.listView:getItems()
    if #items == 0 then
      self:setCtrlVisible("NoticePanel", true)
      self.listView:setVisible(false)
    end
  end
end
function BookCommentDlg:MSG_HANDBOOK_COMMENT_LIKE(data)
  local cell = self.listView:getChildByName(data.id)
  if cell and cell.data then
    cell.data.like_num = cell.data.like_num + 1
    cell.data.has_like = 1
    self:setOneMessagePanel(cell, cell.data)
  end
end
function BookCommentDlg:cleanup()
  local circleCtrl = self:getControl("LoadingImage", nil, self.loadingPanel)
  circleCtrl:stopAllActions()
end
return BookCommentDlg
