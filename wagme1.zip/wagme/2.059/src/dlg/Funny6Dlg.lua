local FunnyDlg = require("dlg/FunnyDlg")
local Funny6Dlg = Singleton("Funny6Dlg", FunnyDlg)
return Funny6Dlg
