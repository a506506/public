local FunnyDlg = require("dlg/FunnyDlg")
local Funny3Dlg = Singleton("Funny3Dlg", FunnyDlg)
return Funny3Dlg
