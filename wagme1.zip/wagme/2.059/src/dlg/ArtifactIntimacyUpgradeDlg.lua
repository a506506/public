local ArtifactIntimacyUpgradeDlg = Singleton("ArtifactIntimacyUpgradeDlg", Dialog)
local lastClick
local MAX_NUM = 999
local SINGLE_ADD_NUM = 1000
local MAX_INTIMACY = 500000
function ArtifactIntimacyUpgradeDlg:init(pos)
  self:bindListener("UpgradeButton", self.onUpgradeButton)
  self:bindListener("InfoButton", self.onInfoButton)
  self:bindListener("ArtifactPillPanel", self.onShowItemInfo)
  self:bindPressForIntervalCallback("ReduceButton", 0.1, self.onSubOrAddNum, "times")
  self:bindPressForIntervalCallback("AddButton", 0.1, self.onSubOrAddNum, "times")
  self:bindNumInput("UsePanel2")
  self.artifactPanel = self:retainCtrl("ArtifactPanel")
  self.listView = self:getControl("ArtifactListView")
  self:initArtifactList(pos)
  self.hasLong = nil
  self.clickButtonTime = 0
  self.canUse = true
  lastClick = nil
  self:hookMsg("MSG_INVENTORY")
  self:hookMsg("MSG_ADD_FABAO_INTIMACY_RESULT")
end
function ArtifactIntimacyUpgradeDlg:initArtifactList(pos)
  self.listView:removeAllChildren()
  self:setCtrlVisible("NonePanel", false)
  local artifactsInfo = EquipmentMgr:getAllArtifacts()
  if #artifactsInfo == 0 then
    self:setCtrlVisible("NonePanel", true)
    return
  end
  for i = 1, #artifactsInfo do
    local artifact = artifactsInfo[i]
    local cell = self.artifactPanel:clone()
    cell:setTag(artifact.pos)
    self:setCellInfo(cell, artifact)
    local function func(sender, eventType)
      if eventType == ccui.TouchEventType.ended then
        local tag = sender:getTag()
        self:onSelectArtifact(tag)
      end
    end
    cell:addTouchEventListener(func)
    self.listView:pushBackCustomItem(cell)
  end
  if pos then
    self:onSelectArtifact(pos)
  elseif #artifactsInfo > 0 then
    local cell = self.listView:getItem(0)
    self:onSelectArtifact(cell:getTag())
  else
    self:refreshRightPanel()
  end
end
function ArtifactIntimacyUpgradeDlg:onSelectArtifact(tag)
  for k, v in pairs(self.listView:getChildren()) do
    self:setCtrlVisible("ChosenEffectImage", false, v)
  end
  local selectItem = self.listView:getChildByTag(tag)
  self:setCtrlVisible("ChosenEffectImage", true, selectItem)
  self.selectArtifact = InventoryMgr:getItemByPos(tag)
  self:refreshRightPanel()
end
function ArtifactIntimacyUpgradeDlg:refreshRightPanel()
  self.itemAmount = InventoryMgr:getAmountByName(CHS[5420366], true)
  self.useNum = 0
  if not self.selectArtifact then
    self.ownIntimacy = 0
  else
    self.ownIntimacy = self.selectArtifact.intimacy
    if self.ownIntimacy < MAX_INTIMACY then
      local canAddIntimacy = self.itemAmount * SINGLE_ADD_NUM
      if self.ownIntimacy + canAddIntimacy > MAX_INTIMACY then
        self.useNum = math.ceil((MAX_INTIMACY - self.ownIntimacy) / SINGLE_ADD_NUM)
      else
        self.useNum = self.itemAmount
      end
    end
  end
  self:setNumView()
  self:setImage("ArtifactPillImage", ResMgr:getIconPathByName(CHS[5420366]))
  if self.itemAmount > 999 then
    self:setNumImgForPanel("ArtifactPillPanel", ART_FONT_COLOR.NORMAL_TEXT, "*", false, LOCATE_POSITION.RIGHT_BOTTOM, 19, nil, nil, -2, 3)
  elseif self.itemAmount > 0 then
    self:setNumImgForPanel("ArtifactPillPanel", ART_FONT_COLOR.NORMAL_TEXT, self.itemAmount, false, LOCATE_POSITION.RIGHT_BOTTOM, 19, nil, nil, -2, 3)
  else
    self:setNumImgForPanel("ArtifactPillPanel", ART_FONT_COLOR.RED, self.itemAmount, false, LOCATE_POSITION.RIGHT_BOTTOM, 19, nil, nil, -2, 3)
  end
end
function ArtifactIntimacyUpgradeDlg:setCellInfo(cell, artifact)
  if not artifact then
    return
  end
  local isEquippedArtifact = false
  if artifact.pos and (artifact.pos == EQUIP.ARTIFACT or artifact.pos == EQUIP.BACK_ARTIFACT) then
    isEquippedArtifact = true
  end
  self:setCtrlVisible("StatusImage", isEquippedArtifact, cell)
  self:setImage("GuardImage", InventoryMgr:getIconFileByName(artifact.name), cell)
  self:setItemImageSize("GuardImage", cell)
  self:setNumImgForPanel("ShapePanel", ART_FONT_COLOR.NORMAL_TEXT, artifact.level, false, LOCATE_POSITION.LEFT_TOP, 21, cell)
  local img = self:getControl("GuardImage", nil, cell)
  if artifact.item_polar then
    InventoryMgr:addArtifactPolarImage(img, artifact.item_polar)
  end
  if InventoryMgr:isTimeLimitedItem(artifact) then
    InventoryMgr:addLogoTimeLimit(img)
  elseif InventoryMgr:isLimitedItem(artifact) then
    InventoryMgr:addLogoBinding(img)
  end
  if isEquippedArtifact then
    self:setLabelText("NameLabel", artifact.name, cell, COLOR3.GREEN)
  else
    self:setLabelText("NameLabel", artifact.name, cell)
  end
  local artifactSpSkillName = SkillMgr:getArtifactSpSkillName(artifact.extra_skill)
  if artifactSpSkillName then
    local artifactSpSkillLevel = tonumber(artifact.extra_skill_level)
    self:setLabelText("SkillNameLabel", artifactSpSkillName, cell)
    self:setLabelText("SkillLevelLabel", string.format(CHS[2000131], artifactSpSkillLevel), cell)
  else
    self:setLabelText("SkillNameLabel", CHS[7000329], cell, COLOR3.GRAY)
  end
end
function ArtifactIntimacyUpgradeDlg:cleanup()
  self.selectArtifact = nil
end
function ArtifactIntimacyUpgradeDlg:onSubOrAddNum(ctrlName, times, sender, eventType)
  if not self.selectArtifact then
    return
  end
  if lastClick ~= ctrlName then
    self.clickButtonTime = 0
    lastClick = ctrlName
  end
  if eventType == ccui.TouchEventType.canceled or eventType == ccui.TouchEventType.ended then
    if self.hasLong then
      self.clickButtonTime = 0
      self.hasLong = nil
    elseif ctrlName == "AddButton" then
      self:onAddButton()
    elseif ctrlName == "ReduceButton" then
      self:onReduceButton()
    end
  else
    self.clickButtonTime = 0
    self.hasLong = true
    local falg = true
    if ctrlName == "AddButton" then
      falg = self:onAddButton()
    elseif ctrlName == "ReduceButton" then
      falg = self:onReduceButton()
    end
    if not falg then
      sender:stopAllActions()
    end
  end
end
function ArtifactIntimacyUpgradeDlg:onAddButton(sender, eventType)
  if self.itemAmount == 0 and 0 <= self.useNum then
    gf:ShowSmallTips(CHS[5420371])
    return
  elseif self.useNum >= self.itemAmount or self.useNum >= MAX_NUM then
    if self.itemAmount >= MAX_NUM then
      gf:ShowSmallTips(CHS[5420376])
    else
      gf:ShowSmallTips(CHS[5420370])
    end
    return
  end
  self.clickButtonTime = self.clickButtonTime + 1
  if self.clickButtonTime == 3 then
    gf:ShowSmallTips(CHS[5420372])
  end
  self.useNum = self.useNum + 1
  self:setNumView()
  return true
end
function ArtifactIntimacyUpgradeDlg:onReduceButton(sender, eventType)
  if self.useNum == 0 then
    return
  end
  self.clickButtonTime = self.clickButtonTime + 1
  if self.clickButtonTime == 3 then
    gf:ShowSmallTips(CHS[5420372])
  end
  self.useNum = self.useNum - 1
  self:setNumView()
  return true
end
function ArtifactIntimacyUpgradeDlg:onShowItemInfo(sender, eventType)
  local rect = self:getBoundingBoxInWorldSpace(sender)
  InventoryMgr:showBasicMessageDlg(CHS[5420366], rect)
end
function ArtifactIntimacyUpgradeDlg:onUpgradeButton(sender, eventType)
  if not self.selectArtifact then
    gf:ShowSmallTips(CHS[7150636])
    return
  end
  if not self.canUse then
    return
  end
  self.clickButtonTime = 0
  if Me:isInCombat() and InventoryMgr:isEquipPos(self.selectArtifact.pos) then
    gf:ShowSmallTips(CHS[5000229])
    return
  end
  if Me:getLevel() < 70 then
    gf:ShowSmallTips(CHS[4200319])
    return
  end
  if InventoryMgr:isTimeLimitedItem(self.selectArtifact) then
    gf:ShowSmallTips(CHS[5420373])
    return
  end
  if self.useNum < 1 then
    gf:ShowSmallTips(CHS[7100169])
    return
  end
  if self.useNum > self.itemAmount then
    gf:ShowSmallTips(CHS[5420374])
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[5000228])
    return
  end
  if self.selectArtifact.intimacy > MAX_INTIMACY then
    gf:confirm(CHS[7150637], function()
      self:onConfirmUse(sender)
    end)
  elseif 1000 <= self.selectArtifact.intimacy + self.useNum * 1000 - MAX_INTIMACY then
    gf:confirm(CHS[7150638], function()
      self:onConfirmUse(sender)
    end)
  else
    self:onConfirmUse(sender)
  end
end
function ArtifactIntimacyUpgradeDlg:onConfirmUse(sender)
  self.canUse = false
  sender:stopAllActions()
  performWithDelay(sender, function()
    self.canUse = true
  end, 5)
  gf:CmdToServer("CMD_ADD_FABAO_INTIMACY_COUNT", {
    pos = self.selectArtifact.pos,
    num = self.useNum
  })
end
function ArtifactIntimacyUpgradeDlg:onInfoButton(sender, eventType)
  DlgMgr:openDlg("ArtifactIntimacyRuleDlg")
end
function ArtifactIntimacyUpgradeDlg:setNumView()
  self:setLabelText("NumLabel1", self.useNum, "UsePanel2")
  self:setLabelText("NumLabel2", self.useNum, "UsePanel2")
  if self.useNum > 0 then
    self:setLabelText("NowLevelLabel_1", self.useNum * 1000 + self.ownIntimacy, "DataPanel", COLOR3.GREEN)
  else
    self:setLabelText("NowLevelLabel_1", self.useNum * 1000 + self.ownIntimacy, "DataPanel", COLOR3.TEXT_DEFAULT)
  end
  self:setCtrlEnabled("ReduceButton", self.useNum > 0)
  self:setCtrlEnabled("AddButton", self.useNum < self.itemAmount and self.useNum < MAX_NUM)
  if not self.selectArtifact or self.useNum == 0 then
    self:setCtrlEnabled("UpgradeButton", false)
  else
    self:setCtrlEnabled("UpgradeButton", true)
  end
end
function ArtifactIntimacyUpgradeDlg:insertNumber(num)
  self.clickButtonTime = 0
  self.useNum = num
  if 0 > self.useNum then
    self.useNum = 0
  end
  if self.itemAmount == 0 and 0 < self.useNum then
    gf:ShowSmallTips(CHS[5420371])
    self.useNum = 0
  elseif self.useNum > self.itemAmount or self.useNum >= MAX_NUM then
    if self.itemAmount >= MAX_NUM then
      gf:ShowSmallTips(CHS[5420376])
      self.useNum = MAX_NUM
    else
      gf:ShowSmallTips(CHS[5420370])
      self.useNum = self.itemAmount
    end
  end
  self:setNumView()
  DlgMgr:sendMsg("SmallNumInputDlg", "setInputValue", self.useNum)
end
function ArtifactIntimacyUpgradeDlg:MSG_INVENTORY(data)
  local artifact = InventoryMgr:getItemByPos(self.selectArtifact.pos)
  if not artifact or artifact.equip_type ~= EQUIP_TYPE.ARTIFACT then
    self:onCloseButton()
    return
  end
  self.selectArtifact = artifact
end
function ArtifactIntimacyUpgradeDlg:MSG_ADD_FABAO_INTIMACY_RESULT(data)
  if data.result == 1 and self.selectArtifact then
    self.ownIntimacy = self.selectArtifact.intimacy or 0
    self.itemAmount = InventoryMgr:getAmountByName(CHS[5420366], true)
    if self.itemAmount > 999 then
      self:setNumImgForPanel("ArtifactPillPanel", ART_FONT_COLOR.NORMAL_TEXT, "*", false, LOCATE_POSITION.RIGHT_BOTTOM, 19, nil, nil, -2, 3)
    elseif 0 < self.itemAmount then
      self:setNumImgForPanel("ArtifactPillPanel", ART_FONT_COLOR.NORMAL_TEXT, self.itemAmount, false, LOCATE_POSITION.RIGHT_BOTTOM, 19, nil, nil, -2, 3)
    else
      self:setNumImgForPanel("ArtifactPillPanel", ART_FONT_COLOR.RED, self.itemAmount, false, LOCATE_POSITION.RIGHT_BOTTOM, 19, nil, nil, -2, 3)
    end
    self.useNum = 0
    self:setNumView()
  end
  self.canUse = true
end
return ArtifactIntimacyUpgradeDlg
