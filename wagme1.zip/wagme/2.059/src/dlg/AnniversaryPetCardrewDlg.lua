local AnniversaryPetCardrewDlg = Singleton("AnniversaryPetCardrewDlg", Dialog)
local NumImg = require("ctrl/NumImg")
function AnniversaryPetCardrewDlg:init(data)
  self:setCtrlVisible("ScorePanel", true)
  self:bindListener("CloseImage", self.onCloseButton)
  self:setCtrlFullClient("BlackPanel")
  for i = 1, 3 do
    self:setCtrlVisible("StarImage_" .. i, i <= data.bonus_level)
  end
  if data.hightest_socre then
    self:setLabelText("HighestNumLabel", string.format(CHS[4101200], data.hightest_socre))
  else
    self:setLabelText("HighestNumLabel", string.format(""))
  end
  if data.exp and data.exp ~= "" and data.exp ~= "0" then
    self:setLabelText("NumLabel_1", data.exp, "ExpPanel")
  else
    self:setLabelText("NumLabel_1", CHS[5000059], "ExpPanel")
  end
  if data.tao and data.tao ~= "0" and data.tao ~= "" then
    self:setLabelText("NumLabel_1", gf:getTaoStr(math.floor(tonumber(data.tao))) .. CHS[4100702], "DaoPanel")
  else
    self:setLabelText("NumLabel_1", CHS[5000059], "DaoPanel")
  end
  if data.item and data.item ~= "" then
    self:setLabelText("NumLabel_1", data.item .. " * 1", "ItemPanel")
  else
    self:setLabelText("NumLabel_1", CHS[5000059], "ItemPanel")
  end
  if data.dlgName == "dkfz" and data.fp_num == 0 then
    self:setCtrlVisible("ResultBKPanel", true)
    self:setCtrlVisible("BKPanel", false)
    self:setCtrlVisible("StarPanel", false)
  elseif data.fp_num then
    local timePanel = self:getControl("NumPanel", nil, "ScorePanel")
    if timePanel then
      local sz = timePanel:getContentSize()
      self.numImg = NumImg.new("bfight_num", 5, false, -5)
      self.numImg:setPosition(sz.width / 2, sz.height / 2)
      self.numImg:setVisible(false)
      self.numImg:setScale(0.5, 0.5)
      timePanel:addChild(self.numImg)
      self.numImg:setPosition(sz.width / 2, sz.height / 2)
      self.numImg:setNum(data.fp_num, false)
      self.numImg:setVisible(true)
    end
  end
end
function AnniversaryPetCardrewDlg:cleanup()
end
return AnniversaryPetCardrewDlg
