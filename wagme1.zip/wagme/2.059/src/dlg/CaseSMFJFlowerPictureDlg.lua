local CaseSMFJFlowerPictureDlg = Singleton("CaseSMFJFlowerPictureDlg", Dialog)
local MAP = {
  [CHS[5400985]] = 4,
  [CHS[5400986]] = 2,
  [CHS[5400987]] = 3,
  [CHS[5400988]] = 1
}
function CaseSMFJFlowerPictureDlg:init()
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel")
  self:bindListener("LockButton01", self.onLockButton01, nil, true)
  self:bindListener("LockButton02", self.onLockButton02, nil, true)
  self:bindListener("ClosePanel", self.onCloseButton)
  self.hasClickBtn1 = false
  self.hasClickBtn2 = false
  for i = 1, 4 do
    local img = self:getControl(string.format("KeyWordsImage%02d", i), nil, "MainPanel02")
    img:setOpacity(0)
  end
end
function CaseSMFJFlowerPictureDlg:cleanup()
  self.indexs = nil
  self.hasClickBtn1 = nil
  self.hasClickBtn2 = nil
end
function CaseSMFJFlowerPictureDlg:setData(para)
  if not para then
    return
  end
  self.indexs = {}
  local info = gf:split(para, ",")
  for i = 1, #info do
    self.indexs[i] = MAP[info[i]]
  end
  if not TanAnSMFJMgr:checkHasTips("flower") then
    ChatMgr:sendMiscMsg(CHS[5400989])
    gf:ShowSmallTips(CHS[5400989])
    TanAnSMFJMgr:setFlagTips("flower", 1)
  end
end
function CaseSMFJFlowerPictureDlg:onLockButton01(sender, eventType)
  if eventType == ccui.TouchEventType.began then
    self.hasClickBtn1 = true
    if gf:isWindows() and ATM_IS_DEBUG_VER then
      self.hasClickBtn2 = true
    end
    self:tryShowFlower()
  elseif eventType == ccui.TouchEventType.moved then
  else
    self.hasClickBtn1 = false
    self:tryShowFlower()
  end
end
function CaseSMFJFlowerPictureDlg:onLockButton02(sender, eventType)
  if eventType == ccui.TouchEventType.began then
    self.hasClickBtn2 = true
    self:tryShowFlower()
  elseif eventType == ccui.TouchEventType.moved then
  else
    self.hasClickBtn2 = false
    self:tryShowFlower()
  end
end
function CaseSMFJFlowerPictureDlg:tryShowFlower()
  if not self.indexs then
    return
  end
  local panel = self:getControl("MaskPanel01")
  if self.hasClickBtn1 and self.hasClickBtn2 then
    if not self.hasAction then
      do
        local function func(index)
          if index > 4 then
            return
          end
          local img = self:getControl(string.format("KeyWordsImage%02d", self.indexs[index]), nil, "MainPanel02")
          local opacity = img:getOpacity()
          img:stopAllActions()
          if opacity == 255 then
            func(index + 1)
          else
            img:runAction(cc.Sequence:create(cc.FadeIn:create(0.00392156862745098 * (255 - opacity)), cc.DelayTime:create(0.5), cc.CallFunc:create(function()
              func(index + 1)
            end)))
          end
        end
        local img = self:getControl("KeyWordsImage01")
        img:runAction(cc.Sequence:create(cc.DelayTime:create(2), cc.CallFunc:create(function()
          func(1)
        end)))
        self.hasAction = true
        panel:runAction(cc.FadeOut:create(20))
      end
    end
  else
    self.hasAction = nil
    for i = 1, 4 do
      local img = self:getControl(string.format("KeyWordsImage%02d", i))
      img:stopAllActions()
      local opacity = img:getOpacity()
      if opacity > 0 then
        img:runAction(cc.FadeOut:create(0.00392156862745098 * opacity))
      end
    end
    local opacity = panel:getOpacity()
    if opacity < 255 then
      panel:stopAllActions()
      panel:runAction(cc.FadeIn:create(0.00392156862745098 * opacity))
    end
  end
end
return CaseSMFJFlowerPictureDlg
