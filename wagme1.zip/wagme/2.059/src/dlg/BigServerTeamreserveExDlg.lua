local BigServerTeamreserveDlg = require("dlg/BigServerTeamreserveDlg")
local BigServerTeamreserveExDlg = Singleton("BigServerTeamreserveExDlg", BigServerTeamreserveDlg)
function BigServerTeamreserveExDlg:init()
  BigServerTeamreserveDlg.init(self)
end
function BigServerTeamreserveExDlg:getCfgFileName()
  return ResMgr:getDlgCfg("BigServerTeamreserveDlg")
end
return BigServerTeamreserveExDlg
