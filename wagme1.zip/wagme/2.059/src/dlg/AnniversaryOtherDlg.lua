local AnniversaryOtherDlg = Singleton("AnniversaryOtherDlg", Dialog)
function AnniversaryOtherDlg:init()
  self:bindListener("HLImage", self.onHLImage)
  self:bindListener("TZImage", self.onTZImage)
  self:bindListener("CGImage", self.onCGImage)
  self:bindListener("YHImage", self.onYHImage)
  self:updateView()
  self:hookMsg("MSG_FIREWORKS_PARTY_INFO")
end
function AnniversaryOtherDlg:updateView()
  local data = ActivityHelperMgr.fireworksData
  local curTime = gf:getServerTime()
  if GameMgr:getDistName() ~= CHS[2200198] or not data or curTime >= data.end_time or Me:getLevel() < 10 then
    local contentSize1 = self:getControl("YHImage"):getContentSize()
    local contentSize2 = self:getControl("ImagePanel"):getContentSize()
    local contentSize3 = self:getControl("LineImage_3"):getContentSize()
    self:getControl("YHImage"):removeFromParent()
    self:getControl("LineImage_3"):removeFromParent()
    self:getControl("ImagePanel"):setContentSize(contentSize2.width, contentSize2.height - contentSize1.height - contentSize3.height - 20)
    local contentSize2 = self:getControl("ImagePanel"):getContentSize()
    local scroview = self:getControl("ScrollView")
    scroview:setInnerContainerSize(contentSize2)
  else
    local contentSize2 = self:getControl("ImagePanel"):getContentSize()
    local scroview = self:getControl("ScrollView")
    scroview:setInnerContainerSize(contentSize2)
  end
end
function AnniversaryOtherDlg:onHLImage(sender, eventType)
  DlgMgr:openDlgWithParam({
    "ActivitiesDlg",
    CHS[5420152] .. ":" .. CHS[5410496]
  })
end
function AnniversaryOtherDlg:onTZImage(sender, eventType)
  DlgMgr:openDlgWithParam({
    "ActivitiesDlg",
    CHS[5420152] .. ":" .. CHS[2100361]
  })
end
function AnniversaryOtherDlg:onCGImage(sender, eventType)
  DlgMgr:openDlgWithParam({
    "ActivitiesDlg",
    CHS[5420152] .. ":" .. CHS[4300753]
  })
end
function AnniversaryOtherDlg:onYHImage(sender, eventType)
  DlgMgr:sendMsg("SystemFunctionDlg", "onFireWorksButton")
end
function AnniversaryOtherDlg:MSG_FIREWORKS_PARTY_INFO()
  self:updateView()
end
function AnniversaryOtherDlg:MSG_LEVEL_UP()
  if data.level >= 10 then
    self:updateView()
  end
end
return AnniversaryOtherDlg
