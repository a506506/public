local CHANNEL_CONFIG = {
  CurrentCheckBox = {
    "currentChatData",
    CHAT_CHANNEL.CURRENT
  },
  WorldCheckBox = {
    "worldChatData",
    CHAT_CHANNEL.WORLD
  },
  PartyCheckBox = {
    "partyChatData",
    CHAT_CHANNEL.PARTY
  },
  TeamCheckBox = {
    "teamChatData",
    CHAT_CHANNEL.TEAM
  },
  SystemCheckBox = {
    "systemChatData",
    CHAT_CHANNEL.SYSTEM
  },
  RumorCheckBox = {
    "rumorChatData",
    CHAT_CHANNEL.RUMOR
  },
  MiscCheckBox = {
    "miscChatData",
    CHAT_CHANNEL.MISC
  },
  AdnoticeCheckBox = {
    "adnoticeChatData",
    CHAT_CHANNEL.ADNOTICE
  }
}
local LAST_SENDTIME = {
  WorldCheckBox = 0,
  PartyCheckBox = 0,
  TeamCheckBox = 0,
  SystemCheckBox = 0
}
local HORN_POP_SHOW_TIME = 12
local SingleChatPanel = require("ctrl/SingleChatPanel")
local ChannelDlg = Singleton("ChannelDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
function ChannelDlg:init()
  self:setFullScreen()
  self:bindListener("CloseButton", self.onCloseButton_2)
  self:bindListViewListener("SystemListView", self.onSelectSystemListView)
  self:bindListener("FriendDlgButton", self.onFriedButton)
  self:bindListener("Button", self.onRumourInfoPanel, "RumourInfoPanel")
  self:bindListener("InfoPanel", self.onHornPanel, "HornPanel")
  self:bindFloatPanelListener(self:getControl("ChoseMenuPanel", nil, "RumourInfoPanel"))
  local root = self:getControl("ChoseMenuPanel", nil, "RumourInfoPanel")
  self:bindCheckBoxListener("CheckBox", self.onRumorChoseCheck, self:getControl("ShanggPanel", nil, root))
  self:bindCheckBoxListener("CheckBox", self.onRumorChoseCheck, self:getControl("TiangPanel", nil, root))
  self:bindCheckBoxListener("CheckBox", self.onRumorChoseCheck, self:getControl("DisPanel", nil, root))
  self:bindCheckBoxListener("CheckBox", self.onRumorChoseCheck, self:getControl("WenqPanel", nil, root))
  self.radioGroup = RadioGroup.new()
  self.radioGroup:setItems(self, {
    "CurrentCheckBox",
    "WorldCheckBox",
    "PartyCheckBox",
    "TeamCheckBox",
    "SystemCheckBox",
    "RumorCheckBox",
    "MiscCheckBox",
    "AdnoticeCheckBox"
  }, self.onChannelButton)
  self.list = self:getControl("SystemPanel")
  self.list:removeAllChildren()
  local btn = self:getControl("WorldCheckBox", Const.UICheckBox)
  local chatPanel = self:getControl("ChatPanel", Const.UIPanel)
  local winSize = self:getWinSize()
  local rootHeight = winSize.height / Const.UI_SCALE
  self.list:setContentSize(self.list:getContentSize().width, rootHeight - (chatPanel:getContentSize().height - self.list:getContentSize().height))
  chatPanel:setContentSize(chatPanel:getContentSize().width, rootHeight)
  self:moveToWinOutAtOnce()
  self:blinkMove()
  self:initRedDot()
  self.channelPanelTable = {}
  self.isShowDone = false
  self:setSingChannelData("CurrentCheckBox", ChatMgr:getChatData("currentChatData"))
  self.radioGroup:selectRadio(1)
  self:setCtrlVisible("HornPanel", false)
  if ChatMgr.curShowHornMsg then
    self:doHornPopup(ChatMgr.curShowHornMsg)
  end
  self:hookMsg("MSG_MESSAGE_EX")
  self:hookMsg("MSG_MESSAGE")
  self:hookMsg("MSG_PARTY_ZHIDUOXING_QUESTION")
  self:hookMsg("MSG_ENTER_ROOM")
  self:hookMsg("MSG_PT_RB_RECV_REDBAG")
  EventDispatcher:addEventListener("EVENT_CLEAR_CHANNEL_CHAT_DATA", self.clearChatData, self)
end
function ChannelDlg:clearChatData()
  if self.channelPanelTable then
    for k, v in pairs(self.channelPanelTable) do
      if v then
        local visible = v:isVisible()
        v:removeFromParent()
        self.channelPanelTable[k] = nil
        self:setSingChannelData(k, ChatMgr:getChatData(CHANNEL_CONFIG[k][1]))
        if self.channelPanelTable[k] then
          self.channelPanelTable[k]:setVisible(visible)
        end
      end
    end
  end
end
function ChannelDlg:blinkMove()
  local movePanel = self:getControl("MovePanel")
  local sartPos, rect, posx
  local winSize = self:getWinSize()
  gf:bindTouchListener(movePanel, function(touch, event)
    local toPos = touch:getLocation()
    local eventCode = event:getEventCode()
    if eventCode == cc.EventCode.BEGAN then
      local panelCtrl = self:getControl("FriendPanel")
      rect = self:getBoundingBoxInWorldSpace(movePanel)
      posx = self.root:getPositionX()
      if cc.rectContainsPoint(rect, toPos) and self:isVisible() then
        sartPos = toPos
        return true
      end
    elseif eventCode == cc.EventCode.MOVED then
      if toPos.x < sartPos.x then
        local dif = toPos.x - sartPos.x
        self.root:setPositionX(posx + dif)
      end
    elseif eventCode == cc.EventCode.ENDED then
      self.root:stopAllActions()
      if toPos.x < rect.x then
        self:moveToWinOut(0.5)
      else
        self:moveToWinIn(0.2)
      end
    end
  end, {
    cc.Handler.EVENT_TOUCH_BEGAN,
    cc.Handler.EVENT_TOUCH_MOVED,
    cc.Handler.EVENT_TOUCH_ENDED
  }, false)
end
function ChannelDlg:setHasOneCallMe(channel)
  local name = self:getCheckBoxNameByChannel(tonumber(channel))
  if self.channelPanelTable[name] then
    self.channelPanelTable[name]:setHasOneCallMe(true)
    return true
  end
end
function ChannelDlg:setOpenRedBag(channel)
  local name = self:getCheckBoxNameByChannel(tonumber(channel))
  if self.channelPanelTable[name] then
    self.channelPanelTable[name]:setOpenRedBag()
    return true
  end
end
function ChannelDlg:onCheckAddRedDot(ctrlName)
  local curChannel = self.radioGroup:getSelectedRadioName()
  if curChannel == ctrlName then
    return false
  end
  return true
end
function ChannelDlg:onChannelButton(sender, eventType)
  local name = sender:getName()
  for k, v in pairs(self.channelPanelTable) do
    if v then
      v:setVisible(false)
    end
  end
  if self.channelPanelTable[name] then
    self.channelPanelTable[name]:setVisible(true)
    if name == "WorldCheckBox" and not GameMgr:IsCrossDist() then
      local userDefault = cc.UserDefault:getInstance()
      local flag = userDefault:getIntegerForKey("worldDlgPlayGuideMagic" .. gf:getShowId(Me:queryBasic("gid")), 0) == 0
      if flag and Me:getLevel() >= 30 then
        local worldPanel = self.channelPanelTable[name]
        local arrowBtn = self:getControl("MenuButton", nil, worldPanel.inputPanel)
        local effect = arrowBtn:getChildByTag(ResMgr.magic.world_chat_under_arrow)
        if not effect then
          local effect = gf:createLoopMagic(ResMgr.magic.world_chat_under_arrow)
          local btnSize = arrowBtn:getContentSize()
          effect:setPosition(btnSize.width / 2, btnSize.height / 2 + 4)
          effect:setContentSize(arrowBtn:getContentSize())
          arrowBtn:addChild(effect, 1, ResMgr.magic.world_chat_under_arrow)
        end
      end
    end
  else
    self:setSingChannelData(name, ChatMgr:getChatData(CHANNEL_CONFIG[name][1]))
  end
  if ChatMgr.hasOneCallMe[CHANNEL_CONFIG[name][2]] then
    self.channelPanelTable[name]:setHasOneCallMe(true)
    ChatMgr.hasOneCallMe[CHANNEL_CONFIG[name][2]] = nil
  end
  self.channelPanelTable[name]:refreshChatPanel()
  if not self:isCanChat(name) then
    self:setCtrlVisible("SystemInfoPanel", true)
    self:setCtrlVisible("RumourInfoPanel", name == "RumorCheckBox")
  else
    self:setCtrlVisible("RumourInfoPanel", false)
    self:setCtrlVisible("SystemInfoPanel", false)
  end
  if name == "PartyCheckBox" and DlgMgr:sendMsg("ChatDlg", "haveRedbagImage") then
    DlgMgr:sendMsg("ChatDlg", "removeRedbagImage")
  end
  if name == "WorldCheckBox" and DlgMgr:sendMsg("ChatDlg", "haveRedbagImage") then
    DlgMgr:sendMsg("ChatDlg", "removeRedbagImage", REDBAG_TYPE.WORLD_HAPPY)
  end
  if name == "CurrentCheckBox" then
    self:MSG_PARTY_ZHIDUOXING_QUESTION(PartyMgr.partyZhidxQuestionInfo)
  else
    self:getControl("AnswerPanel"):setVisible(false)
  end
  self:doHornPopup({})
end
function ChannelDlg:setChannelInputChat(channalNo, funcName, ...)
  for k, v in pairs(self.channelPanelTable) do
    if CHANNEL_CONFIG[k][2] == channalNo then
      local func = v[funcName]
      if func then
        func(v, ...)
      end
      break
    end
  end
end
function ChannelDlg:sendMessage(text, voiceTime, token, channelName)
  local selectName = self.radioGroup:getSelectedRadioName()
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  end
  local channel = channelName or CHANNEL_CONFIG[selectName][2]
  if channel == CHAT_CHANNEL.WORLD and FiltrateMgr:checkShapedChar(text) then
    gf:ShowSmallTips(CHS[4300876])
    return
  end
  local filteText = text
  token = token or ""
  if ChatMgr:textIsALlSpace(text) and string.len(token) == 0 then
    gf:ShowSmallTips(CHS[3002303])
    return
  end
  local data = {}
  data.channel = channel
  data.compress = 0
  data.orgLength = string.len(filteText)
  data.msg = filteText
  data.voiceTime = voiceTime or 0
  data.token = token or ""
  if channel == CHAT_CHANNEL.PARTY then
    if DistMgr:isInKFBZServer() then
      data.channel = CHAT_CHANNEL.CHANNEL_CS_PARTY
    end
    if string.match(data.msg, string.format("\029@%s \029", CHS[5420488])) then
      data.para = "aite_party"
    end
  end
  local param = string.match(filteText, "{\t..-=(..-=..-)}")
  if param then
    data.cardCount = 1
    data.cardParam = param
  end
  ChatMgr:sendMessage(data)
  return true
end
function ChannelDlg:isCanChat(checkBoxName)
  if checkBoxName == "SystemCheckBox" or checkBoxName == "RumorCheckBox" or checkBoxName == "MiscCheckBox" or checkBoxName == "AdnoticeCheckBox" then
    return false
  else
    return true
  end
end
function ChannelDlg:getCurChannel()
  local selectName = self.radioGroup:getSelectedRadioName()
  return CHANNEL_CONFIG[selectName][2]
end
function ChannelDlg:setSingChannelData(name, data)
  local iSCanChat = true
  if not self:isCanChat(name) then
    iSCanChat = false
  end
  if self.list and self.channelPanelTable[name] then
    self.list:removeChild(self.channelPanelTable[name])
  end
  self.channelPanelTable[name] = SingleChatPanel.new(data, iSCanChat, self.list:getContentSize(), CHANNEL_CONFIG[name][2])
  self.channelPanelTable[name]:setCallBack(self, "sendMessage", CHANNEL_CONFIG[name][2])
  self.list:addChild(self.channelPanelTable[name])
end
function ChannelDlg:onCloseButton_2(sender, eventType)
  self:moveToWinOut()
  self.isShowDone = false
  RedDotMgr:removeOneRedDot("ChatDlg", "ChatButton")
end
function ChannelDlg:onCloseButton()
  DlgMgr:closeDlg(self.name)
  DlgMgr:closeDlg("CharMenuContentDlg")
end
function ChannelDlg:isOutsideWin()
  local winSize = self:getWinSize()
  if self.root:getPositionX() <= -self.root:getContentSize().width / 2 + winSize.x + 1 then
    return true
  else
    return false
  end
end
function ChannelDlg:onSelectSystemListView(sender, eventType)
end
function ChannelDlg:MSG_MESSAGE(data)
  if ChatMgr:isVoiceTranslateText(data) then
    local selectName = self.radioGroup:getSelectedRadioName()
    self.channelPanelTable[selectName]:refreshChatPanel(true)
  end
end
function ChannelDlg:MSG_MESSAGE_EX(data)
  self:MSG_MESSAGE(data)
end
function ChannelDlg:doHornPopup(data)
  local mainPanel = self:getControl("HornPanel")
  local size = mainPanel:getContentSize()
  mainPanel:stopAllActions()
  local lastData = mainPanel.data or {}
  local startTime = data.hornTime or lastData.hornTime or 0
  local message = data.hornMsg or lastData.hornMsg
  local icon = data.hornBackIcon or lastData.hornBackIcon
  local plist = data.hornBackIconPlist or lastData.hornBackIconPlist or 0
  local curChannel = self.radioGroup:getSelectedRadioName()
  local lastTime = HORN_POP_SHOW_TIME - (gf:getServerTime() - startTime)
  mainPanel.data = {
    hornMsg = message,
    hornTime = startTime,
    hornBackIcon = icon,
    hornBackIconPlist = plist
  }
  if lastTime > 0 and message and icon and curChannel == "WorldCheckBox" then
    mainPanel:setVisible(true)
  else
    mainPanel:setVisible(false)
    return
  end
  mainPanel:setBackGroundImage(icon, plist)
  mainPanel:setBackGroundImageCapInsets(Const.HORN_TIP_CAPINSECT_RECT)
  local height = self:setColorText(message, "InfoPanel", mainPanel, 10, 10, COLOR3.WHITE, nil, nil, true, true)
  mainPanel:setContentSize(size.width, height + 22)
  performWithDelay(mainPanel, function()
    mainPanel:setVisible(false)
  end, lastTime)
end
function ChannelDlg:isCanSpeak()
  local selectName = self.radioGroup:getSelectedRadioName()
  local isCanSpeak = true
  if CHANNEL_CONFIG[selectName][2] == CHAT_CHANNEL.PARTY then
    if Me:queryBasic("party/name") == "" then
      gf:ShowSmallTips(CHS[3002304])
      isCanSpeak = false
    end
  elseif CHANNEL_CONFIG[selectName][2] == CHAT_CHANNEL.TEAM then
    if not TeamMgr:inTeamEx(Me:getId()) then
      gf:ShowSmallTips(CHS[3002305])
      isCanSpeak = false
    end
  elseif MapMgr:isInYanwc() then
    gf:ShowSmallTips(CHS[2100328])
    isCanSpeak = false
  end
  return isCanSpeak
end
function ChannelDlg:show(noOpenAction)
  local friDlg = DlgMgr:getDlgByName("FriendDlg")
  if friDlg then
    if not friDlg:isOutsideWin() then
      noOpenAction = true
    end
    friDlg:moveToWinOutAtOnce()
  end
  if not self:isOutsideWin() then
    noOpenAction = true
  end
  if noOpenAction then
    self:moveToWinInAtOnce()
  else
    self:moveToWinOutAtOnce()
    self:moveToWinIn()
  end
end
function ChannelDlg:moveToWinInAtOnce()
  self.root:stopAllActions()
  local winSize = self:getWinSize()
  self.root:setPosition(Const.WINSIZE.width / Const.UI_SCALE / 2 + winSize.x, Const.WINSIZE.height / Const.UI_SCALE / 2 + winSize.y)
end
function ChannelDlg:moveToWinIn(time)
  self.root:stopAllActions()
  local winSize = self:getWinSize()
  local moveto = cc.MoveTo:create(time or 0.25, cc.p(Const.WINSIZE.width / Const.UI_SCALE / 2 + winSize.x, Const.WINSIZE.height / Const.UI_SCALE / 2 + winSize.y))
  local callBack = cc.CallFunc:create(function()
    self:moveDown()
  end)
  self.root:runAction(cc.Sequence:create(moveto, callBack))
end
function ChannelDlg:moveToWinOutAtOnce()
  self.root:stopAllActions()
  local winSize = self:getWinSize()
  self.root:setPosition(-self.root:getContentSize().width / 2 + winSize.x, Const.WINSIZE.height / Const.UI_SCALE / 2 + winSize.y)
end
function ChannelDlg:moveToWinOut(time)
  self.root:stopAllActions()
  local winSize = self:getWinSize()
  local moveto = cc.MoveTo:create(time or 0.25, cc.p(-self.root:getContentSize().width / 2 + winSize.x, Const.WINSIZE.height / Const.UI_SCALE / 2))
  self.root:runAction(moveto)
end
function ChannelDlg:refreshRumorChannel()
  if self.channelPanelTable.RumorCheckBox then
    self:setSingChannelData("RumorCheckBox", ChatMgr:getChatData(CHANNEL_CONFIG.RumorCheckBox[1]))
    self.channelPanelTable.RumorCheckBox:refreshChatPanel()
    self.channelPanelTable.RumorCheckBox:setVisible(self.radioGroup:getSelectedRadioName() == "RumorCheckBox")
  end
end
function ChannelDlg:onFriedButton()
  self:moveToWinOutAtOnce()
  RedDotMgr:removeOneRedDot("ChannelDlg", "FriendDlgButton")
  FriendMgr:openFriendDlg(true)
end
function ChannelDlg:onHornPanel()
  if self.channelPanelTable.WorldCheckBox then
    self.channelPanelTable.WorldCheckBox:moveToHornMsg()
  end
end
function ChannelDlg:onRumourInfoPanel()
  if Me:getVipType() < Const.VIP_SEASON then
    gf:ShowSmallTips(CHS[2100298])
    return
  end
  self:setCtrlVisible("ChoseMenuPanel", not self:getCtrlVisible("ChoseMenuPanel", nil, "RumourInfoPanel"), "RumourInfoPanel")
  local isVisible = self:getCtrlVisible("ChoseMenuPanel", nil, "RumourInfoPanel")
  local tbl = ChatMgr:getRumorShowTypes()
  local root = self:getControl("ChoseMenuPanel", nil, "RumourInfoPanel")
  self:setCheck("CheckBox", tbl and tbl["2"], self:getControl("TiangPanel", nil, root))
  self:setCheck("CheckBox", tbl and tbl["1"], self:getControl("DisPanel", nil, root))
  self:setCheck("CheckBox", tbl and tbl["3"], self:getControl("ShanggPanel", nil, root))
  self:setCheck("CheckBox", tbl and tbl["4"], self:getControl("WenqPanel", nil, root))
end
function ChannelDlg:onRumorChoseCheck(sender)
  local tbl = {}
  local root = self:getControl("ChoseMenuPanel", nil, "RumourInfoPanel")
  if self:isCheck("CheckBox", self:getControl("TiangPanel", nil, root)) then
    tbl["2"] = true
  end
  if self:isCheck("CheckBox", self:getControl("DisPanel", nil, root)) then
    tbl["1"] = true
  end
  if self:isCheck("CheckBox", self:getControl("ShanggPanel", nil, root)) then
    tbl["3"] = true
  end
  if self:isCheck("CheckBox", self:getControl("WenqPanel", nil, root)) then
    tbl["4"] = true
  end
  ChatMgr:setRumorShowTypes(tbl)
end
function ChannelDlg:cleanup()
  if self.channelPanelTable then
    for k, v in pairs(self.channelPanelTable) do
      if v then
        v:clear()
      end
    end
    self.channelPanelTable = nil
  end
  EventDispatcher:removeEventListener("EVENT_CLEAR_CHANNEL_CHAT_DATA", self.clearChatData, self)
end
function ChannelDlg:moveDown()
  self.isShowDone = true
  if self.guaidParam and self.guaidParam == "isShow63" then
    GuideMgr:youCanDoIt(self.name, self.guaidParam)
    self.guaidParam = false
  end
end
function ChannelDlg:youMustGiveMeOneNotify(param)
  if "isShow63" == param then
    if self.isShowDone then
      GuideMgr:youCanDoIt(self.name, param)
    else
      self.guaidParam = param
    end
  end
end
function ChannelDlg:getSelectItemBox(clickItem)
  if "partyLink" == clickItem then
    local ctrl = self:getControl("ExpressionButton", nil, self.channelPanelTable.PartyCheckBox)
    return self:getBoundingBoxInWorldSpace(ctrl)
  end
end
function ChannelDlg:getCheckBoxNameByChannel(channel)
  local name = "CurrentCheckBox"
  for k, v in pairs(CHANNEL_CONFIG) do
    if v[2] == channel then
      name = k
      break
    end
  end
  return name
end
function ChannelDlg:selectChannel(name)
  self.radioGroup:setSetlctByName(name)
end
function ChannelDlg:onDlgOpened(param)
  local channel = param[1]
  local name = self:getCheckBoxNameByChannel(tonumber(channel))
  self.radioGroup:setSetlctByName(name)
  if ChatMgr:channelDlgIsOutsideWin() then
    self:moveToWinInAtOnce()
  end
  local dlg = DlgMgr:getDlgByName("FriendDlg")
  if dlg then
    dlg:moveToWinOutAtOnce()
  end
  if tonumber(channel) == CHAT_CHANNEL.FRIEND then
    self:onFriedButton()
    local dlg = DlgMgr:getDlgByName("FriendDlg")
    if dlg then
      dlg:onCheckBoxClick(dlg:getControl("FriendCheckBox"), 1)
    end
  else
  end
end
function ChannelDlg:initRedDot()
  if RedDotMgr:hasRedDotInfo("ChannelDlg", "FriendDlgButton") then
    RedDotMgr:insertOneRedDot("ChannelDlg", "FriendDlgButton")
  end
end
function ChannelDlg:MSG_PARTY_ZHIDUOXING_QUESTION(data)
  local answerPanel = self:getControl("AnswerPanel")
  if not data or data.message == "" or MapMgr:getCurrentMapName() ~= CHS[4000199] or self.radioGroup:getSelectedRadioName() ~= "CurrentCheckBox" then
    answerPanel:setVisible(false)
    return
  end
  local showTime = data.duration - (gf:getServerTime() - data.showStartTime)
  if showTime then
    answerPanel:setVisible(true)
    self:setLabelText("NameLabel", string.format(CHS[5420468], data.question_index, data.question_count), answerPanel)
    local questionPanelSize = self:getControl("QuestionPanel", nil, answerPanel):getContentSize()
    local height = self:setColorText(data.message, "QuestionPanel", answerPanel)
    local size = answerPanel:getContentSize()
    local toHeight = size.height + height - questionPanelSize.height
    answerPanel:setContentSize(size.width, toHeight)
    answerPanel:stopAllActions()
    performWithDelay(answerPanel, function()
      answerPanel:setVisible(false)
    end, showTime)
  else
    answerPanel:setVisible(false)
  end
end
function ChannelDlg:MSG_ENTER_ROOM(data)
  local answerPanel = self:getControl("AnswerPanel")
  answerPanel:setVisible(false)
end
function ChannelDlg:MSG_PT_RB_RECV_REDBAG(data)
  local name = self:getCheckBoxNameByChannel(CHAT_CHANNEL.PARTY)
  if self.channelPanelTable[name] then
    self.channelPanelTable[name]:setRedBagHasOpen(data.redbag_gid)
  end
end
return ChannelDlg
