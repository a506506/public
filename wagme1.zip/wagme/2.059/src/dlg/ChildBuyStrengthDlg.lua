local ChildBuyStrengthDlg = Singleton("ChildBuyStrengthDlg", Dialog)
local UNIT_PRICE = 1000000
function ChildBuyStrengthDlg:init(data)
  self:bindListener("BuyButton", self.onBuyButton)
  self:blindPress("ReduceButton")
  self:blindPress("AddButton")
  self.data = data
  self.buyNum = 1
  self:bindNumInput("TouchPanel", "NumPanel")
  self:updateViewData()
  local cashText, fontColor = gf:getArtFontMoneyDesc(tonumber(UNIT_PRICE))
  self:setNumImgForPanel("MoneyNumPanel", fontColor, cashText, false, LOCATE_POSITION.RIGHT_BOTTOM, 23)
end
function ChildBuyStrengthDlg:insertNumber(num)
  if num <= 0 then
    num = 1
  end
  self.buyNum = num
  local limit = math.min(50, self.data.canGetEnergy, 100 - self.data.energy)
  limit = math.max(1, limit)
  if limit < self.buyNum then
    self.buyNum = limit
    gf:ShowSmallTips(CHS[4300622])
  end
  DlgMgr:sendMsg("SmallNumInputDlg", "setInputValue", self.buyNum)
  self:updateViewData()
end
function ChildBuyStrengthDlg:onClickBlank(sender, eventType)
  return true
end
function ChildBuyStrengthDlg:onReduceButton(sender, eventType)
end
function ChildBuyStrengthDlg:onAddButton(sender, eventType)
end
function ChildBuyStrengthDlg:onBuyButton(sender, eventType)
  gf:CmdToServer("CMD_CHILD_SUPPLY_ENERGY", {
    id = self.data.id,
    energy = self.buyNum
  })
  self:onCloseButton()
end
function ChildBuyStrengthDlg:onAddButton(sender, eventType)
  if self.data.energy + self.buyNum >= 100 then
    self:setCtrlEnabled("AddButton", false)
    gf:ShowSmallTips(CHS[4300623])
    return
  elseif self.buyNum >= self.data.canGetEnergy then
    self:setCtrlEnabled("AddButton", false)
    gf:ShowSmallTips(CHS[4300624])
    return
  end
  if self.buyNum + 1 >= self.data.canGetEnergy then
    gf:ShowSmallTips(CHS[4300624])
  end
  self.buyNum = self.buyNum + 1
  self:updateViewData()
end
function ChildBuyStrengthDlg:onReduceButton(sender, eventType)
  self.buyNum = self.buyNum - 1
  if self.buyNum < 1 then
    self.buyNum = 1
  end
  self:updateViewData()
end
function ChildBuyStrengthDlg:blindPress(name)
  local widget = self:getControl(name, nil, self.root)
  if not widget then
    Log:W("Dialog:bindListViewListener no control " .. name)
    return
  end
  local function updataCount(longClick)
    if self.touchStatus == TOUCH_BEGAN then
      if self.clickBtn == "AddButton" then
        self:onAddButton(longClick)
      elseif self.clickBtn == "ReduceButton" then
        self:onReduceButton(longClick)
      end
    elseif self.touchStatus == TOUCH_END then
    end
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.began then
      self.clickBtn = sender:getName()
      self.touchStatus = TOUCH_BEGAN
      schedule(widget, function()
        updataCount(true)
      end, 0.1)
    elseif eventType == ccui.TouchEventType.moved then
    else
      updataCount()
      self.touchStatus = TOUCH_END
      widget:stopAllActions()
    end
  end
  widget:addTouchEventListener(listener)
end
function ChildBuyStrengthDlg:updateViewData()
  self:setLabelText("NumLabel", self.buyNum, self:getControl("NumPanel"))
  self:setLabelText("NumLabel2", self.buyNum, self:getControl("NumPanel"))
  local cashText, fontColor = gf:getArtFontMoneyDesc(tonumber(self.buyNum * UNIT_PRICE))
  self:setNumImgForPanel("PayPanel", fontColor, cashText, false, LOCATE_POSITION.LEFT_BOTTOM, 23)
  self:setCtrlEnabled("ReduceButton", true)
  self:setCtrlEnabled("AddButton", true)
  if self.buyNum <= 1 then
    self:setCtrlEnabled("ReduceButton", false)
  end
  if self.buyNum >= self.data.canGetEnergy then
    self:setCtrlEnabled("AddButton", false)
  elseif self.data.energy + self.buyNum >= 100 then
    self:setCtrlEnabled("AddButton", false)
  end
end
return ChildBuyStrengthDlg
