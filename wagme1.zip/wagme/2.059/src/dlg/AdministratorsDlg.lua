local AdministratorsDlg = Singleton("AdministratorsDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
local CROSS_COMPET_CHECKBOX = {
  "MRZBCheckBox",
  "QMPKCheckBox",
  "CityWarCheckBox"
}
local QMPK_CHECKBOX = {
  "CheckBox_1",
  "CheckBox_2",
  "CheckBox_3",
  "CheckBox_4"
}
local QMPK_CITY_CHECKBOX = {
  "CheckBox_1",
  "CheckBox_2",
  "CheckBox_3"
}
function AdministratorsDlg:init()
  self.radioGroupCompetition = RadioGroup.new()
  self.radioGroupCompetition:setItemsCanReClick(self, CROSS_COMPET_CHECKBOX, self.onCompetitionCheckBoxClick)
  self.radioGroupQmpk = RadioGroup.new()
  self.radioGroupQmpk:setItemsCanReClick(self, QMPK_CHECKBOX, self.onQuanmpkCheckBoxClick)
  self.radioGroupQmpkCity = RadioGroup.new()
  self.radioGroupQmpkCity:setItemsCanReClick(self, QMPK_CITY_CHECKBOX, self.onQuanmpkCityCheckBoxClick, "CityWarPanel")
  self:setCtrlVisible("QuanmPKPanel", false)
  self:setCtrlVisible("CityWarPanel", false)
  self:hookMsg("MSG_CSQ_GM_REQUEST_CONTROL_INFO")
  self:hookMsg("MSG_CSQ_GM_REQUEST_CONTROL_CITY")
  self:hookMsg("MSG_CSQ_GM_OPEN_CONTROL_RESULT")
end
function AdministratorsDlg:onQuanmpkCheckBoxClick(sender, curIdx)
  local matchData = GMMgr:getQmpkGmData()
  if not matchData then
    return
  end
  local info = matchData.list[curIdx]
  if info.status == 1 then
    gf:ShowSmallTips(CHS[7100313])
  elseif info.status == 3 then
    gf:ShowSmallTips(CHS[7100314])
  else
    DlgMgr:openDlgEx("GMQuanmPKFightDlg", curIdx)
  end
end
function AdministratorsDlg:onQuanmpkCityCheckBoxClick(sender, curIdx)
  if curIdx == 1 then
    GMMgr:openGM_QMPK_CITY_START()
  elseif curIdx == 2 then
    GMMgr:openGM_QMPK_CITY_STOP()
  elseif curIdx == 3 then
    QuanminPK2Mgr:requestQmpkCityJfInfo(1)
  end
end
function AdministratorsDlg:onCompetitionCheckBoxClick(sender, curIdx)
  if curIdx == 1 then
    GMMgr:openGM_MRZB_CONTROL()
  elseif curIdx == 2 then
    GMMgr:openGM_QMPK_CONTROL()
  elseif curIdx == 3 then
    GMMgr:openGM_QMPK_CITY_CONTROL()
  end
end
function AdministratorsDlg:MSG_CSQ_GM_REQUEST_CONTROL_CITY(data)
  if data.flag == 1 then
    self:setCtrlVisible("CityWarPanel", true)
  else
    self:setCtrlVisible("CityWarPanel", false)
  end
end
function AdministratorsDlg:MSG_CSQ_GM_OPEN_CONTROL_RESULT(data)
  if data.flag == 1 then
    self:setCtrlVisible("QuanmPKPanel", true)
  else
    self:setCtrlVisible("QuanmPKPanel", false)
  end
end
function AdministratorsDlg:MSG_CSQ_GM_REQUEST_CONTROL_INFO()
  local data = GMMgr:getQmpkGmData()
  for i = 1, data.count do
    local ctrl = self:getControl("Label", nil, "CheckBox_" .. i)
    if data.list[i].status ~= 2 then
      ctrl:setColor(COLOR3.GRAY)
    else
      ctrl:setColor(COLOR3.WHITE)
    end
  end
end
function AdministratorsDlg:cleanup()
  if self:getControl("CityWarPanel") and self:getControl("CityWarPanel"):isVisible() then
    GMMgr:cancleGM_QMPK_CONTROL()
  end
end
return AdministratorsDlg
