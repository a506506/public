local AnniversaryShareDlg = Singleton("AnniversaryShareDlg", Dialog)
function AnniversaryShareDlg:init()
  self:setFullScreen()
  self:setCtrlFullClient("BKImage", "BKPanel", true)
  self:setLabelText("NameLabel", Me:getName())
  self:setLabelText("DistLabel", GameMgr:getDistName())
end
return AnniversaryShareDlg
