local BigServerTeamreserveDlg = Singleton("BigServerTeamreserveDlg", Dialog)
local LOAD_MAX_TIME = 10
local WEBPAGE_TAG = 999
local schemeMethods = {
  showArticle = "onShowArticle",
  shareUrlToWX = "onShareUrlToWX",
  shareImageToWX = "onShareImageToWX",
  saveImage = "onSaveImage"
}
local WAIT_PANEL_STR = {
  CHS[7150142],
  CHS[7150142] .. ".",
  CHS[7150142] .. "..",
  CHS[7150142] .. "..."
}
function BigServerTeamreserveDlg:init()
  self:bindListener("RefreshButton", self.onRefreshButton)
  self.curUrl = self:getUrl()
  print("request:  " .. self.curUrl)
  if gf:isWindows() and ATM_IS_DEBUG_VER then
    return
  end
  self:setMusicOnBeforeInfo(SoundMgr:isMusicOn(), SoundMgr:isSoundOn(), SoundMgr:isDubbingOn())
  self:beginLoadUrl()
end
function BigServerTeamreserveDlg:getUrl()
  local paras = string.format("sid=%s&zone_id=%s&t=%d", LeitingSdkMgr:getUserId(), Client:getWantLoginDistName() or "", gf:getServerTime())
  local sign = string.lower(gfGetMd5(string.format("%s&%s", paras, "SHVfyf8$")))
  paras = string.format("sid=%s&zone_id=%s&t=%d&sign=%s", LeitingSdkMgr:getUserId(), gf:encodeURI(Client:getWantLoginDistName() or ""), gf:getServerTime(), sign)
  return string.format("%s?%s", DistMgr:getPreTeamUrl() or "", paras)
end
function BigServerTeamreserveDlg:onCheckAddRedDot(ctrlName)
  local curChannel = self.radioGroup:getSelectedRadioName()
  if curChannel == ctrlName then
    return false
  end
  return true
end
function BigServerTeamreserveDlg:setMusicOnBeforeInfo(isMousicOn, isSoundOn, isDubbingOn)
  self.isMusicOnBeforeOpen = isMousicOn
  self.isSoundOnBeforeOpen = isSoundOn
  self.isDubbingOnBeforeOpen = isDubbingOn
end
function BigServerTeamreserveDlg:beginLoadUrl()
  if not self:createWebView() then
    return
  end
  self:createWaitPanel()
  self:setCtrlVisible("NoticePanel", false)
  self.webView:loadURL(self.curUrl)
  local startTime = LOAD_MAX_TIME
  self.waitPanel:setVisible(true)
  if not self.schedulId then
    self.schedulId = self:startSchedule(function()
      if startTime > 0 then
        startTime = startTime - 1
      else
        self:clearSchedule()
        self:removeWebView()
        self.waitPanel:setVisible(false)
        self:setCtrlVisible("NoticePanel", true)
      end
    end, 1)
  end
  self:setVisible(true)
  self:setWebViewVisible(false)
end
function BigServerTeamreserveDlg:setVisible(flag)
  if flag and not DlgMgr:canShowWebDlg(true, self.name) then
    flag = false
  end
  if flag then
    Dialog.setVisible(self, flag)
    if self.isPlayVideo then
      self:setMusicPauseOrOn(false)
    end
  else
    self.setVisibleAction = performWithDelay(self.root, function()
      Dialog.setVisible(self, flag)
      if self.isPlayVideo then
        self:setMusicPauseOrOn(true)
      end
    end, 0)
  end
  DlgMgr:sendMsg("ReserveRechargeTabDlg", "setVisible", flag)
  if self.webView then
    local noticePanel = self:getControl("NoticePanel")
    if flag and not noticePanel:isVisible() then
      self:setWebViewVisible(true)
    else
      self:setWebViewVisible(false)
    end
  end
end
function BigServerTeamreserveDlg:createWaitPanel()
  self.waitPanel = self:getControl("WaitPanel")
  self.waitPanelScheduleId = self:startSchedule(function()
    self:refreshWaitPanel()
  end, 0.3)
end
function BigServerTeamreserveDlg:refreshWaitPanel()
  local curStr = self:getLabelText("InfoLabel2", self.waitPanel)
  if curStr == WAIT_PANEL_STR[1] then
    self:setLabelText("InfoLabel2", WAIT_PANEL_STR[2], self.waitPanel)
  elseif curStr == WAIT_PANEL_STR[2] then
    self:setLabelText("InfoLabel2", WAIT_PANEL_STR[3], self.waitPanel)
  elseif curStr == WAIT_PANEL_STR[3] then
    self:setLabelText("InfoLabel2", WAIT_PANEL_STR[4], self.waitPanel)
  else
    self:setLabelText("InfoLabel2", WAIT_PANEL_STR[1], self.waitPanel)
  end
end
function BigServerTeamreserveDlg:refreshCurUrl()
  if not self.curUrl then
    return
  end
  self:setCtrlVisible("NoticePanel", false)
  self:clearSchedule()
  self:createWaitPanel()
  if not self:createWebView() then
    return
  end
  self.webView:loadURL(self.curUrl)
  local startTime = LOAD_MAX_TIME
  self.waitPanel:setVisible(true)
  if not self.schedulId then
    self.schedulId = self:startSchedule(function()
      if startTime > 0 then
        startTime = startTime - 1
      else
        self:clearSchedule()
        self:removeWebView()
        self.waitPanel:setVisible(false)
        self:setCtrlVisible("NoticePanel", true)
      end
    end, 1)
  end
end
function BigServerTeamreserveDlg:setMusicPauseOrOn(flag)
  if self.isMusicOnBeforeOpen then
    if flag then
      SoundMgr:resumeMusic()
    else
      SoundMgr:pauseMusic()
    end
  end
  if self.isSoundOnBeforeOpen then
    if flag then
      SoundMgr:resumeSound()
    else
      SoundMgr:pauseSound()
    end
  end
  if self.isDubbingOnBeforeOpen then
    if flag then
      SoundMgr:resumeDubbing()
    else
      SoundMgr:stopDubbing()
    end
  end
end
function BigServerTeamreserveDlg:tryToResumeMusic()
  if self.isPlayVideo then
    if self.isMusicOnBeforeOpen then
      SoundMgr:resumeMusic()
    end
    if self.isSoundOnBeforeOpen then
      SoundMgr:resumeSound()
    end
    if self.isDubbingOnBeforeOpen then
      SoundMgr:resumeDubbing()
    end
    self.isPlayVideo = false
  end
end
function BigServerTeamreserveDlg:onShowArticle(args)
  local type = args.type
  if type == "video" then
    self.isPlayVideo = true
    if self.isMusicOnBeforeOpen then
      SoundMgr:pauseMusic()
    end
    if self.isSoundOnBeforeOpen then
      SoundMgr:pauseSound()
    end
    if self.isDubbingOnBeforeOpen then
      SoundMgr:stopDubbing()
    end
  else
    self:tryToResumeMusic()
  end
end
function BigServerTeamreserveDlg:onShareUrlToWX(args)
  local type = SHARE_TYPE.WECHAT
  if args.type == "circle" then
    type = SHARE_TYPE.WECHATMOMENTS
  end
  ShareMgr:shareUrlToPlat(type, args.url, args.title, args.desc, self:getThumbPath(), function(result)
    if not self.webView then
      return
    end
    local r = tostring(result)
    local jsCode = "if (typeof(atmShareCallback) == 'function'){ atmShareCallback('" .. r .. "', ''); }else{ alert('" .. r .. "');}"
    self.webView:evaluateJS(jsCode)
  end)
end
function BigServerTeamreserveDlg:onSaveImage(args)
  local url = args.url
  if not gf:gfIsFuncEnabled(FUNCTION_ID.SAVE_TO_GALLERY) then
    local jsCode = string.format("atmDownloadFinish(\"%s\", \"%s\", \"%s\");", "unsupport", url, "")
    self.webView:evaluateJS(jsCode)
    return
  end
  local httpFile = HttpFile:create()
  self:regHttpReq(httpFile)
  local filePath = string.format("saves/atm%d%d.jpg", os.time(), gfGetTickCount())
  gfSaveFile("", filePath)
  filePath = cc.FileUtils:getInstance():getWritablePath() .. filePath
  local function _callback(state, value)
    if not self.reqs then
      return
    end
    if 1 == state then
      local jsCode = string.format("atmDownloadProgress(\"%s\", %d);", url, value)
      self.webView:evaluateJS(jsCode)
    elseif 0 == state then
      if gf:isAndroid() then
        local luaj = require("luaj")
        local className = "org/cocos2dx/lua/AppActivity"
        local sig = "(Ljava/lang/String;I)Ljava/lang/String;"
        local args = {filePath, 80}
        local fun = "saveImageToGallery"
        local ok, ret = luaj.callStaticMethod(className, fun, args, sig)
        if ok then
          filePath = ret
        end
      elseif gf:isIos() then
        local luaoc = require("luaoc")
        local args = {arg1 = filePath}
        local ok, ret = luaoc.callStaticMethod("AppController", "saveImageToGallery", args)
        if ok then
          filePath = ret
        end
      end
      local jsCode = string.format("atmDownloadFinish(\"%s\", \"%s\", \"%s\");", "success", url, filePath)
      self.webView:evaluateJS(jsCode)
      self:unregHttpReq(httpFile)
    elseif 2 == state then
      local jsCode = string.format("atmDownloadFinish(\"%s\", \"%s\", \"%s\");", "fail", url, "")
      self.webView:evaluateJS(jsCode)
      os.remove(filePath)
      self:unregHttpReq(httpFile)
    end
  end
  httpFile:setDelegate(_callback)
  httpFile:downloadFile(url, filePath)
end
function BigServerTeamreserveDlg:downloadCommunityFile(url, callback)
  local httpFile = HttpFile:create()
  self:regHttpReq(httpFile)
  local fileExt = gf:getFileExt(url)
  local filePath = "saves/atmCommunityShare." .. fileExt
  gfSaveFile("", filePath)
  filePath = cc.FileUtils:getInstance():getWritablePath() .. filePath
  local function _callback(state, value)
    if not self.reqs then
      return
    end
    if 1 == state then
      callback(filePath, state)
    elseif 0 == state then
      callback(filePath, state)
      Client:pushDebugInfo("[downloadCommunityFile]:download succ!")
    elseif 2 == state then
      callback(filePath, state)
      Client:pushDebugInfo("[downloadCommunityFile]:download fail!")
      self:unregHttpReq(httpFile)
    end
  end
  httpFile:setDelegate(_callback)
  httpFile:downloadFile(url, filePath)
end
function BigServerTeamreserveDlg:onShareImageToWX(args)
  local type = SHARE_TYPE.WECHAT
  if args.type == "circle" then
    type = SHARE_TYPE.WECHATMOMENTS
  end
  local url = args.url
  self:downloadCommunityFile(url, function(filePath, result)
    if result == 0 then
      ShareMgr:shareToPlat(type, {
        fileName = filePath,
        needNotifyServer = function(result)
          if not self.webView then
            return
          end
          local r = tostring(result)
          local jsCode = "if (typeof(atmShareCallback) == 'function'){ atmShareCallback('" .. r .. "', ''); }else{ alert('" .. r .. "');}"
          self.webView:evaluateJS(jsCode)
        end
      })
    elseif result == 2 then
      local sendTip = CHS[5420453]
      local jsCode = string.format("if (typeof(atmShareCallback) == 'function'){ atmShareCallback('%s', '%s'); }else{ alert('%s');}", "SHAREFAILED", sendTip, sendTip)
      self.webView:evaluateJS(jsCode)
    end
  end)
end
function BigServerTeamreserveDlg:regHttpReq(req)
  if not self.reqs then
    self.reqs = {}
  end
  self.reqs[tostring(req)] = req
  req:retain()
end
function BigServerTeamreserveDlg:unregHttpReq(req)
  if not self.reqs then
    return
  end
  if req then
    self.reqs[tostring(req)] = nil
    req:release()
  else
    for _, v in pairs(self.reqs) do
      if v then
        v:release()
      end
    end
    self.reqs = nil
  end
end
function BigServerTeamreserveDlg:getThumbPath()
  return cc.FileUtils:getInstance():fullPathForFilename(ResMgr.ui.atm_share_url_logo)
end
function BigServerTeamreserveDlg:parseAtmScheme(schemeUrl)
  local url = require("url")
  local info = {}
  info.scheme, info.host = string.match(schemeUrl, "([^:]+)://(.*)")
  local pos = gf:findStrByByte(info.host, "?")
  if not pos then
    info.method = info.host
    return info
  end
  info.method = string.sub(info.host, 1, pos - 1)
  info.args = {}
  local list = gf:split(string.sub(info.host, pos + 1) or "", "&")
  for i = 1, #list do
    local kv = list[i]
    pos = gf:findStrByByte(kv, "=")
    if pos and pos > 1 then
      info.args[string.sub(kv, 1, pos - 1)] = url.unescape(string.sub(kv, pos + 1))
    end
  end
  return info
end
function BigServerTeamreserveDlg:setWebViewVisible(flag)
  if flag then
    self.webView:setPositionX(0)
  else
    self.webView:setPositionX(10000)
  end
end
function BigServerTeamreserveDlg:onRefreshButton(sender, eventType)
  self:refreshCurUrl()
end
function BigServerTeamreserveDlg:createWebView()
  if self.webView then
    return true
  end
  self.webView = ccexp.WebView:create()
  if not self.webView then
    self:setCtrlVisible("RefreshPanel", false, "NoticePanel")
    self:setCtrlVisible("UpgradePanel", true)
    return
  end
  self:setCtrlVisible("UpgradePanel", false)
  local webPanel = self:getControl("WebPanel")
  webPanel:setLayoutType(ccui.LayoutType.ABSOLUTE)
  local panelSize = webPanel:getContentSize()
  if gf:isIos() and DeviceMgr:getOSVer() >= "8" and "function" == type(self.webView.useWKWebViewInIos) then
    self.webView:useWKWebViewInIos(true)
  end
  self.webView:setScalesPageToFit(true)
  self.webView:setContentSize(panelSize)
  self.webView:setAnchorPoint(0, 0)
  self.webView:setTag(WEBPAGE_TAG)
  webPanel:addChild(self.webView)
  self:setWebViewVisible(false)
  self.webView:setOnDidFailLoading(function(sender, url)
    self.loadOver = true
    if not DlgMgr:isDlgOpened(self.name) then
      return
    end
    self:clearSchedule()
    self.waitPanel:setVisible(false)
    self:setCtrlVisible("NoticePanel", true)
    self:removeWebView()
  end)
  self.webView:setOnDidFinishLoading(function(sender, url)
    self.loadOver = true
    if not DlgMgr:isDlgOpened(self.name) then
      return
    end
    self:clearSchedule()
    self.waitPanel:setVisible(false)
    self:setCtrlVisible("NoticePanel", false)
    if self.webView then
      self:setWebViewVisible(self:isVisible())
    end
    self.curUrl = url
  end)
  if "function" == type(self.webView.setOnJSCallback) then
    self.webView:setOnJSCallback(function(sender, url)
      Client:pushDebugInfo("OnJSCallback:" .. tostring(url))
      local info = self:parseAtmScheme(url)
      if info.scheme ~= "atm" then
        return
      end
      local methodName = info.method
      if string.isNilOrEmpty(methodName) then
        return
      end
      local method = schemeMethods[methodName]
      if not method or "function" ~= type(self[method]) then
        return
      end
      self[method](self, info.args)
    end)
    self.webView:setJavascriptInterfaceScheme("atm")
  end
  return true
end
function BigServerTeamreserveDlg:removeWebView()
  if self.webView then
    self.webView:removeFromParent()
    self.webView = nil
  end
end
function BigServerTeamreserveDlg:clearSchedule()
  if self.schedulId then
    self:stopSchedule(self.schedulId)
    self.schedulId = nil
  end
  if self.waitPanelScheduleId then
    self:stopSchedule(self.waitPanelScheduleId)
    self.waitPanelScheduleId = nil
  end
end
function BigServerTeamreserveDlg:cleanup()
  self:clearSchedule()
  self:removeWebView()
  self:tryToResumeMusic()
  self:unregHttpReq()
  self.loadOver = nil
end
return BigServerTeamreserveDlg
