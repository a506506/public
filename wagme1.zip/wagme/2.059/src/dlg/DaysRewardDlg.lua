local DaysRewardDlg = Singleton("DaysRewardDlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
local Days = {
  [1] = "第一天",
  [2] = "第二天",
  [3] = "第三天",
  [4] = "第四天",
  [5] = "第五天",
  [6] = "第六天",
  [7] = "第七天"
}
local SCROLLVIEW_CONTAINNER = 766
function DaysRewardDlg:init()
  self.rewardPanel = self:getControl("ItemPanel")
  self.rewardPanel:retain()
  self.rewardPanel:removeFromParent()
  self.rewardPanelContentSize = self.rewardPanel:getContentSize()
  self.isInitDone = false
  if self:getGiftData() then
    self.isInitDone = true
    self:initDataInfo()
  end
  self:requestRewardData()
  GiftMgr:setLastTime()
end
function DaysRewardDlg:getCfgFileName()
  return ResMgr:getDlgCfg("SevenDaysRewardDlg")
end
function DaysRewardDlg:cleanup()
  self:releaseCloneCtrl("rewardPanel")
end
function DaysRewardDlg:getGiftData()
  assert(false)
end
function DaysRewardDlg:requestRewardData()
  assert(false)
end
function DaysRewardDlg:takeReward(index)
  assert(false)
end
function DaysRewardDlg:undateButtonState()
  local contPanel = self:getControl("GiftListScrollView"):getChildByTag(SCROLLVIEW_CONTAINNER)
  local rewards = self:getGiftData()
  for i = 1, #rewards do
    local panel = contPanel:getChildByTag(i)
    self:setButtonState(rewards[i], i, i <= rewards.loginDays, panel)
  end
end
function DaysRewardDlg:initDataInfo()
  local rewards = self:getGiftData()
  local container = ccui.Layout:create()
  local giftListCtrl = self:getControl("GiftListScrollView")
  giftListCtrl:removeAllChildren()
  giftListCtrl:addChild(container, 1, SCROLLVIEW_CONTAINNER)
  container:setPosition(4, 0)
  local count = #rewards
  local isShowFirst = true
  for i = 1, count do
    local reward = rewards[i]
    local rewardPanel
    rewardPanel = self:createOneRewardPanel(reward, i, i <= rewards.loginDays)
    if i % 2 ~= 0 then
      self:setCtrlVisible("BackImage1", false, rewardPanel)
      self:setCtrlVisible("BackImage2", true, rewardPanel)
    else
      self:setCtrlVisible("BackImage2", false, rewardPanel)
      self:setCtrlVisible("BackImage1", true, rewardPanel)
    end
    rewardPanel:setPosition(0, (count - i) * self.rewardPanelContentSize.height + 1)
    container:addChild(rewardPanel, 1, i)
    if i == 1 and self:getCtrlVisible("GotButton", rewardPanel) then
      isShowFirst = false
    end
  end
  container:setContentSize(self.rewardPanelContentSize.width, self.rewardPanelContentSize.height * count)
  giftListCtrl:setInnerContainerSize(container:getContentSize())
  if not isShowFirst then
    giftListCtrl:getInnerContainer():setPosition(cc.p(0, 0))
  end
  local hasRecord = false
  local function onScrollView(sender, eventType)
    if ccui.ScrollviewEventType.scrolling == eventType and not hasRecord then
      hasRecord = true
      RecordLogMgr:isMeetPlugOrder(self.name .. "_GiftListScrollView")
    end
  end
  self:getControl("GiftListScrollView"):addEventListener(onScrollView)
end
function DaysRewardDlg:setButtonState(rewardInfo, days, isCanGet, rewardPanel)
  local noReachBtn = self:getControl("NoReachButton", nil, rewardPanel)
  local getBtn = self:getControl("GetButton", nil, rewardPanel)
  local gotBtn = self:getControl("GotButton", nil, rewardPanel)
  noReachBtn:setVisible(false)
  getBtn:setVisible(false)
  gotBtn:setVisible(false)
  if not isCanGet then
    noReachBtn:setVisible(true)
    self:setCtrlEnabled("NoReachButton", false, rewardPanel)
  elseif 0 == rewardInfo.flag then
    getBtn:setVisible(true)
  elseif 1 == rewardInfo.flag then
    gotBtn:setVisible(true)
    self:setCtrlEnabled("GotButton", false, rewardPanel)
  end
  self:bindTouchEndEventListener(getBtn, function()
    if not DistMgr:checkCrossDist() then
      return
    end
    self:takeReward(rewardInfo.index)
    getBtn.isRecordPlugOrder = true
    RecordLogMgr:isMeetPlugOrder(self.name .. "_" .. rewardInfo.index)
  end)
end
function DaysRewardDlg:getDay(days)
  return Days[days]
end
function DaysRewardDlg:createOneRewardPanel(rewardInfo, days, isCanGet)
  local rewardPanel = self.rewardPanel:clone()
  self:setLabelText("DaysLabel", self:getDay(days), rewardPanel)
  local itemListPanel = self:getControl("ItemListPanel", Const.UIPanel, rewardPanel)
  itemListPanel:removeAllChildren(true)
  local rewardContainer = RewardContainer.new(rewardInfo.desc, itemListPanel:getContentSize(), nil, nil, true, nil, true)
  rewardContainer:setAnchorPoint(0, 0.5)
  rewardContainer:setScale(0.8)
  rewardContainer:setPosition(10, itemListPanel:getContentSize().height / 2)
  itemListPanel:addChild(rewardContainer)
  self:setButtonState(rewardInfo, days, isCanGet, rewardPanel)
  return rewardPanel
end
return DaysRewardDlg
