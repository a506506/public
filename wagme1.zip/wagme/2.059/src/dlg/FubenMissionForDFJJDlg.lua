local FubenMissionDlg = require("dlg/FubenMissionDlg")
local FubenMissionForDFJJDlg = Singleton("FubenMissionForDFJJDlg", FubenMissionDlg)
function FubenMissionForDFJJDlg:getCfgFileName()
  return ResMgr:getDlgCfg("FubenMissionForDFJJDlg")
end
function FubenMissionForDFJJDlg:onCheckBox(sender, eventType)
  self:setCtrlVisible("DifjjPanel", sender:getName() == "MissionCheckBox")
  self:setCtrlVisible("TeamPanel", sender:getName() == "TeamCheckBox")
  if self.lastCheckBox == sender:getName() then
    if sender:getName() == "MissionCheckBox" then
      DlgMgr:openDlg("TaskDlg")
    elseif sender:getName() == "TeamCheckBox" then
      DlgMgr:openDlg("TeamDlg")
    end
  end
  if sender:getName() == "MissionCheckBox" then
    self:setCtrlVisible("UnChosenImage", true, "TeamCheckBox")
    self:setCtrlVisible("ChosenImage", false, "TeamCheckBox")
    self:setCtrlVisible("UnChosenImage", false, "MissionCheckBox")
    self:setCtrlVisible("ChosenImage", true, "MissionCheckBox")
    self:onMissionButton(sender)
  elseif sender:getName() == "TeamCheckBox" then
    self:setCtrlVisible("UnChosenImage", false, "TeamCheckBox")
    self:setCtrlVisible("ChosenImage", true, "TeamCheckBox")
    self:setCtrlVisible("UnChosenImage", true, "MissionCheckBox")
    self:setCtrlVisible("ChosenImage", false, "MissionCheckBox")
    self:onTeamButton(sender)
  end
  self.lastCheckBox = sender:getName()
end
function FubenMissionForDFJJDlg:init()
  FubenMissionDlg.init(self)
  self:bindListener("CombatButton", self.onDFJJCombatButton, "DifjjPanel")
  self:bindListener("NoteButton", self.onDFJJNoteButton, "DifjjPanel")
  self:hookMsg("MSG_DFJJC_NOTIFY_AUTO_MATCH")
  if ActivityHelperMgr.difjjData then
    self:MSG_DFJJC_NOTIFY_AUTO_MATCH(ActivityHelperMgr.difjjData)
  end
end
function FubenMissionForDFJJDlg:onDFJJNoteButton()
  DlgMgr:openDlg("DiFuJingJiRuleDlg")
end
function FubenMissionForDFJJDlg:onDFJJCombatButton()
  if self.difjjData.is_matching == 1 then
    gf:CmdToServer("CMD_DFJJC_SET_AUTO_MATCH", {status = 0})
  else
    gf:CmdToServer("CMD_DFJJC_SET_AUTO_MATCH", {status = 1})
  end
end
function FubenMissionForDFJJDlg:MSG_DFJJC_NOTIFY_AUTO_MATCH(data)
  self:refreshDFJJCPanel(data)
end
function FubenMissionForDFJJDlg:onLeaveButton(sender, eventType)
  gf:CmdToServer("CMD_LEAVE_ROOM", {
    type = CHS[4101863],
    extra = ""
  })
end
function FubenMissionForDFJJDlg:setInfoByTask(task)
end
function FubenMissionForDFJJDlg:onFubenInfo(sender, eventType)
end
function FubenMissionForDFJJDlg:cleanup()
  FubenMissionDlg.cleanup(self)
end
function FubenMissionForDFJJDlg:MSG_TASK_PROMPT(data)
end
function FubenMissionForDFJJDlg:getDifjjData()
  return self.difjjData
end
function FubenMissionForDFJJDlg:setTeamInfo(tips)
  self:setCtrlVisible("CurrentNotePanel1", #tips ~= 2)
  self:setCtrlVisible("CurrentNotePanel2", #tips == 2)
  local root = #tips == 2 and "CurrentNotePanel2" or "CurrentNotePanel1"
  if #tips == 1 then
    table.insert(tips, 1, {
      color = COLOR3.WHITE,
      fontSize = 19,
      content = ""
    })
  end
  for i = 1, 3 do
    if tips[i] then
      self:setColorTextEx(tips[i].content, self:getControl("ContentPanel" .. i, nil, root), tips[i].color, tips[i].fontSize)
    else
      self:setColorTextEx("", self:getControl("ContentPanel" .. i, nil, root))
    end
  end
end
function FubenMissionForDFJJDlg:refreshDFJJCPanel(data)
  local panel = self:getControl("DifjjPanel")
  self.difjjData = data
  if data.team_members_count == 1 then
    self:setLabelText("TeamPointLabel", CHS[4300794], panel)
  else
    self:setLabelText("TeamPointLabel", string.format(CHS[5200058], data.team_score), panel)
  end
  self:setLabelText("PlayerPointLabel", string.format(CHS[5200057], data.score), panel)
  self:stopSchedule(self.timerForDFJJ)
  self.timerForDFJJ = nil
  local descPanel = self:getControl("CurrentNotePanel", nil, panel)
  local timePanel = self:getControl("TimePanel", nil, panel)
  local tips = {}
  local btn = self:getControl("CombatButton", nil, panel)
  if data.is_matching ~= 1 then
    self:setLabelText("Label_1", CHS[5400349], btn)
    self:setLabelText("Label_2", CHS[5400349], btn)
  else
    self:setLabelText("Label_1", CHS[5400395], btn)
    self:setLabelText("Label_2", CHS[5400395], btn)
  end
  if self.timerDFjjTime then
    timePanel:stopAction(self.timerDFjjTime)
    self.timerDFjjTime = nil
  end
  self.timerDFjjTime = schedule(timePanel, function()
    local now = gf:getServerTime()
    if not self.lastDFjjTime then
      self.lastDFjjTime = now
    end
    if now - self.lastDFjjTime >= 15 then
      self:refreshDFJJCPanel(self.difjjData)
      self.lastDFjjTime = now
    elseif self.lastDFjjTime <= data.match_start_time and now >= data.match_start_time then
      self:refreshDFJJCPanel(self.difjjData)
      self.lastDFjjTime = now
    elseif self.lastDFjjTime <= data.match_end_time and now >= data.match_end_time then
      self:refreshDFJJCPanel(self.difjjData)
      self.lastDFjjTime = now
    end
  end, 1)
  if data.match_start_time > gf:getServerTime() then
    local last_min = math.ceil(math.max(0, data.match_start_time - gf:getServerTime()) / 60)
    self:setColorTextEx(string.format(CHS[5200059], last_min), timePanel, COLOR3.WHITE, 18)
  else
    local last_min = math.ceil(math.max(0, data.match_end_time - gf:getServerTime()) / 60)
    self:setColorTextEx(string.format(CHS[5200060], last_min), timePanel, COLOR3.WHITE, 18)
  end
  if data.team_members_count < 3 then
    local teamMemberStr = string.format(CHS[4101738], data.team_members_count)
    table.insert(tips, {
      color = COLOR3.WHITE,
      fontSize = 19,
      content = teamMemberStr
    })
    self:setTeamInfo(tips)
  else
    do
      local teamMemberStr = string.format(CHS[4300831], data.team_members_count)
      table.insert(tips, {
        color = COLOR3.WHITE,
        fontSize = 19,
        content = teamMemberStr
      })
      if data.is_matching ~= 1 then
        if data.match_start_time > gf:getServerTime() then
          table.insert(tips, {
            color = COLOR3.WHITE,
            fontSize = 19,
            content = CHS[5200061]
          })
        else
          table.insert(tips, {
            color = COLOR3.WHITE,
            fontSize = 19,
            content = CHS[5400394]
          })
        end
        self:setTeamInfo(tips)
        self:setLabelText("Label_1", CHS[5400349], btn)
        self:setLabelText("Label_2", CHS[5400349], btn)
      else
        self:setLabelText("Label_1", CHS[5400395], btn)
        self:setLabelText("Label_2", CHS[5400395], btn)
        if 0 < data.protect_time - gf:getServerTime() then
          local ti = math.max(0, data.protect_time - gf:getServerTime())
          table.insert(tips, {
            color = COLOR3.WHITE,
            fontSize = 19,
            content = CHS[5410221]
          })
          table.insert(tips, {
            color = COLOR3.WHITE,
            fontSize = 19,
            content = string.format(CHS[4300837], ti)
          })
          self:setTeamInfo(tips)
          self.timerForDFJJ = self:startSchedule(function()
            local tips2 = {}
            local ti = math.max(0, data.protect_time - gf:getServerTime())
            if ti <= 0 then
              table.insert(tips2, {
                color = COLOR3.WHITE,
                fontSize = 19,
                content = teamMemberStr
              })
              table.insert(tips2, {
                color = COLOR3.WHITE,
                fontSize = 19,
                content = CHS[5410221]
              })
              self:stopSchedule(self.timerForDFJJ)
              self.timerForDFJJ = nil
            else
              self:setColorTextEx(teamMemberStr .. "\n" .. string.format(CHS[4101739], ti), descPanel, COLOR3.WHITE, 19)
              table.insert(tips2, {
                color = COLOR3.WHITE,
                fontSize = 19,
                content = teamMemberStr
              })
              table.insert(tips2, {
                color = COLOR3.WHITE,
                fontSize = 19,
                content = CHS[5410221]
              })
              table.insert(tips2, {
                color = COLOR3.WHITE,
                fontSize = 19,
                content = string.format(CHS[4300837], ti)
              })
            end
            self:setTeamInfo(tips2)
          end)
        else
          table.insert(tips, {
            color = COLOR3.WHITE,
            fontSize = 19,
            content = CHS[5410221]
          })
          self:setTeamInfo(tips)
        end
      end
    end
  end
end
return FubenMissionForDFJJDlg
