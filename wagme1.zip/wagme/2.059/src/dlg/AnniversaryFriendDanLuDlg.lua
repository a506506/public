local AnniversaryFriendDanLuDlg = Singleton("AnniversaryFriendDanLuDlg", Dialog)
local ONE_PAGE_NUM = 40
local NIMBUS_MAGIC = {
  ResMgr.ArmatureMagic.danlu_nimbus_gold,
  ResMgr.ArmatureMagic.danlu_nimbus_wood,
  ResMgr.ArmatureMagic.danlu_nimbus_water,
  ResMgr.ArmatureMagic.danlu_nimbus_fire,
  ResMgr.ArmatureMagic.danlu_nimbus_earth
}
function AnniversaryFriendDanLuDlg:init()
  self:bindListener("SupplyButton", self.onSupplyButton)
  self:bindListener("SingleFriendPanel", self.onSelectFriendListView, "FriendlistPanel")
  self.chosenImage = self:retainCtrl("BChosenEffectImage", self:getControl("SingleFriendPanel", nil, "FriendlistPanel"))
  self.singleFriendPanel = self:retainCtrl("SingleFriendPanel", "FriendlistPanel")
  self:initFriends()
  self:hookMsg("MSG_ZNQ_2020_XDHX_HELP_DATA_LIST")
  self:hookMsg("MSG_ZNQ_2020_XDHX_FRIEND_DATA")
  self:hookMsg("MSG_ZNQ_2020_XDHX_FRIEND_DATA_FAILED")
  self:hookMsg("MSG_FRIEND_NOTIFICATION")
  self:hookMsg("MSG_FRIEND_UPDATE_PARTIAL")
  self:hookMsg("MSG_ZNQ_2020_XDHX_CLOSE_DLG")
end
function AnniversaryFriendDanLuDlg:cleanup()
  self.friends = nil
end
function AnniversaryFriendDanLuDlg:sortFriends()
  table.sort(self.friends, function(l, r)
    if l.isOnline > r.isOnline then
      return false
    end
    if l.isOnline < r.isOnline then
      return true
    end
    if self.data then
      if not self.data.friend_datas[l.gid] then
        local ldata = {has_danlu = 0}
      end
      if not self.data.friend_datas[r.gid] then
        local rdata = {has_danlu = 0}
      end
      if ldata.has_danlu > rdata.has_danlu then
        return true
      elseif ldata.has_danlu < rdata.has_danlu then
        return false
      end
    end
    if l.friendShip > r.friendShip then
      return true
    else
      return false
    end
  end)
end
function AnniversaryFriendDanLuDlg:initFriends()
  self.friends = FriendMgr:getFriends({minlevel = 30})
  self:sortFriends()
  self:bindListViewByPageLoad("FriendListView", "TouchPanel", function(dlg, percent)
    if percent > 100 and not self.isFirstPage then
      self:setFriendList()
    end
  end, "FriendlistPanel")
  if #self.friends <= 0 then
    self:setCtrlVisible("FriendListView", false, "FriendlistPanel")
    self:setCtrlVisible("NoticePanel", true, "MainPanel")
    self:setCtrlVisible("InfoBackImage4", true, self:getControl("NoticePanel", nil, "MainPanel"))
    return
  else
    self:setCtrlVisible("FriendListView", true, "FriendlistPanel")
    self:setCtrlVisible("NoticePanel", false, "MainPanel")
    self:setCtrlVisible("InfoBackImage4", false, self:getControl("NoticePanel", nil, "MainPanel"))
  end
end
function AnniversaryFriendDanLuDlg:setFriendList(isReset)
  local data = self.friends or {}
  if #data <= 0 then
    return
  end
  local list = self:getControl("FriendListView", nil, "FriendlistPanel")
  if isReset then
    list:removeAllItems()
    self.loadNum = 1
    self:sortFriends()
  end
  if not data[self.loadNum] then
    return
  end
  local loadNum = self.loadNum
  for i = 1, ONE_PAGE_NUM do
    if data[loadNum] then
      local cell = self.singleFriendPanel:clone()
      cell:setName(data[loadNum].gid)
      self:setOneFriendPanel(data[loadNum], cell)
      list:pushBackCustomItem(cell)
      if loadNum == 1 and not self.chosenImage:getParent() then
        self:onSelectFriendListView(cell)
      end
      loadNum = loadNum + 1
    else
      break
    end
  end
  list:doLayout()
  list:refreshView()
  self.loadNum = loadNum
end
function AnniversaryFriendDanLuDlg:setOneFriendPanel(data, cell)
  local friendData = self.data.friend_datas[data.gid]
  self:setImage("PortraitImage", ResMgr:getSmallPortrait(data.icon), cell)
  self:setItemImageSize("PortraitImage", cell)
  self:setCtrlEnabled("PortraitImage", data.isOnline == 1, cell, true)
  self:setNumImgForPanel("PortraitPanel", ART_FONT_COLOR.NORMAL_TEXT, data.lev or 1, false, LOCATE_POSITION.LEFT_TOP, 23, cell)
  self:setLabelText("NamePatyLabel", data.name, cell)
  local isShow = nil ~= friendData and data.isOnline == 1
  self:setCtrlVisible("Label_1", isShow, cell)
  self:setCtrlVisible("Label_2", isShow, cell)
  if friendData and friendData.level then
    if not (friendData.level > 0) or not cc.c3b(166, 99, 41) then
    end
    self:setCtrlColor("Label_1", cc.c3b(128, 128, 128), cell)
    if not (friendData.level > 0) or not cc.c3b(166, 99, 41) then
    end
    self:setLabelText("Label_2", friendData.level > 0 and "LV." .. friendData.level or CHS[2100353], cell, (cc.c3b(128, 128, 128)))
  else
    self:setLabelText("Label_2", CHS[2100354], cell, cc.c3b(128, 128, 128))
  end
  if self:isHelp(data.gid) then
    self:setImage("FireImage", ResMgr.ui.fire_helped, cell)
  else
    self:setImage("FireImage", ResMgr.ui.fire_unhelped, cell)
  end
  self:setCtrlVisible("FireImage", isShow, cell)
end
function AnniversaryFriendDanLuDlg:isHelp(gid)
  local helped_gids = self.data.helped_gids
  for i = 1, #helped_gids do
    if helped_gids[i] == gid then
      return true
    end
  end
end
function AnniversaryFriendDanLuDlg:showDanLuFloating(isClosed)
  local danLuPanel = self:getControl("OnlyDanLuPanel", nil, "DanLuPanel")
  if not danLuPanel.initPos then
    local x, y = danLuPanel:getPosition()
    danLuPanel.initPos = cc.p(x, y)
  end
  if isClosed then
    if danLuPanel.floatingAction then
      danLuPanel:stopAllActions()
    end
    danLuPanel.floatingAction = nil
    danLuPanel:setPosition(danLuPanel.initPos)
    return
  end
  if not danLuPanel.floatingAction then
    local act1 = cc.EaseSineInOut:create(cc.MoveBy:create(1, cc.p(0, 10)))
    local act2 = cc.EaseSineInOut:create(cc.MoveBy:create(1, cc.p(0, -10)))
    danLuPanel.floatingAction = danLuPanel:runAction(cc.RepeatForever:create(cc.Sequence:create(act1, act2)))
  end
end
function AnniversaryFriendDanLuDlg:setDanLuState(isOpen, level)
  local panel = self:getControl("DanLunWindowMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
  level = level or 1
  if not isOpen then
    local info = level >= 4 and ResMgr.ArmatureMagic.danlu_close_4_6 or ResMgr.ArmatureMagic.danlu_close_1_3
    local magic = gf:createArmatureLoopMagic(info.name, info.action, panel, 314, panel:getContentSize().height - 261, 1)
    magic:setTag(Const.ARMATURE_MAGIC_TAG)
  end
  self:setCtrlVisible("DanLunLevelImage_1", level <= 3, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_2", level == 2, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_3", level == 3, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_4", level >= 4, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_5", level >= 5, "DanLuPanel")
  self:setCtrlVisible("DanLunLevelImage_6", level == 6, "DanLuPanel")
end
function AnniversaryFriendDanLuDlg:setNimbusState(isOpen, nimbus_type)
  local panel = self:getControl("DanLunnimbusMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByTag(Const.ARMATURE_MAGIC_TAG)
  if magic then
    magic:removeFromParent()
  end
  if not isOpen then
    return
  end
  if not nimbus_type then
    return
  end
  local info = NIMBUS_MAGIC[nimbus_type]
  local magic = gf:createArmatureLoopMagic(info.name, info.action, panel, 314, panel:getContentSize().height - 262, 1)
  magic:setTag(Const.ARMATURE_MAGIC_TAG)
end
function AnniversaryFriendDanLuDlg:setFireMagic(isOpen, icon)
  local panel = self:getControl("FireMagicPanel", nil, "DanLuPanel")
  local magic = panel:getChildByName("FireMagic")
  if magic then
    magic:removeFromParent()
  end
  if not isOpen and icon <= 0 then
    return
  end
  magic = gf:createLoopMagic(icon, nil, {blendMode = "add"})
  magic:setAnchorPoint(0.5, 0.5)
  magic:setPosition(315, panel:getContentSize().height - 316)
  magic:setName("FireMagic")
  panel:addChild(magic, 1)
end
function AnniversaryFriendDanLuDlg:setFriendInfo(data)
  local statePanel = self:getControl("StatePanel", nil, "FriendTreePanel")
  local panel = self:getControl("LevelPanel", nil, statePanel)
  self:setLabelText("Label1", data and data.level or "", panel)
  self:setLabelText("Label2", data and data.level or "", panel)
  local isOpen
  if data then
    isOpen = data.nimbus_type ~= 0 and true
  else
    isOpen = false
  end
  self:setDanLuState(isOpen, data and data.level)
  self:setNimbusState(isOpen, data and data.nimbus_type or 1)
  self:setNote(data)
  local exp
  if data then
    local level = data.level or 0
    exp = level < 6 and string.format("%d/%d", data.exp, data.next_level_need_exp) or CHS[2100355]
  else
    exp = ""
  end
  self:setLabelText("Label3", exp, panel)
  self:setLabelText("Label4", exp, panel)
  self:setLabelText("Label5", exp, panel)
  self:setProgressBar("ProgressBar", data and data.exp or 1, data and data.next_level_need_exp or 1, panel, COLOR3.GREEN)
  panel = self:getControl("FoodPanel", nil, statePanel)
  local value = data and data.fire_point or -1
  local fireState = CHS[2100338]
  local icon = ResMgr.magic.danlu_fire_state_1
  local image = ResMgr.ui.danlu_fire_state_1
  if value >= 75 then
    fireState = CHS[2100339]
    icon = ResMgr.magic.danlu_fire_state_5
    image = ResMgr.ui.danlu_fire_state_5
  elseif value >= 50 then
    fireState = CHS[2100340]
    icon = ResMgr.magic.danlu_fire_state_4
    image = ResMgr.ui.danlu_fire_state_4
  elseif value >= 25 then
    fireState = CHS[2100341]
    icon = ResMgr.magic.danlu_fire_state_3
    image = ResMgr.ui.danlu_fire_state_3
  elseif value > 0 then
    fireState = CHS[2100342]
    icon = ResMgr.magic.danlu_fire_state_2
    image = ResMgr.ui.danlu_fire_state_2
  elseif value == 0 then
    fireState = CHS[2100338]
    icon = ResMgr.magic.danlu_fire_state_1
    image = ResMgr.ui.danlu_fire_state_1
  else
    fireState = ""
    icon = 0
    image = ResMgr.ui.danlu_fire_state_1
  end
  self:setLabelText("Label1", fireState, panel)
  self:setLabelText("Label2", fireState, panel)
  self:setImage("Image", image, panel)
  self:showDanLuFloating(not data or data.is_closed or not data or data.nimbus_type == 0)
  self:setFireMagic(data and data.nimbus_type ~= 0, icon)
  value = data and string.format("%d/%d", data.fire_point, 100) or ""
  self:setLabelText("Label3", value, panel)
  self:setLabelText("Label4", value, panel)
  self:setLabelText("Label5", value, panel)
  self:setProgressBar("ProgressBar", data and data.fire_point or 1, data and 100 or 1, panel, COLOR3.GREEN)
  panel = self:getControl("MoodPanel", nil, statePanel)
  value = data and string.format(CHS[2100343], math.ceil(data.remain_bonus_time / 60)) or ""
  if data and data.is_closed and not string.isNilOrEmpty(value) then
    value = value .. CHS[2200201]
  end
  self:setLabelText("Label3", value, panel)
  self:setLabelText("Label4", value, panel)
  self:setLabelText("Label5", value, panel)
  self:setProgressBar("ProgressBar", data and data.remain_bonus_time / 60 or 1, data and 30 or 1, panel, COLOR3.GREEN)
  if data then
    self:setCtrlVisible("DanLuPanel", true, "FriendTreePanel")
    self:setCtrlVisible("SupplyPanel", true, self:getControl("OperatePanel", nil, "FriendTreePanel"))
    panel = self:getControl("SupplyPanel", nil, self:getControl("OperatePanel", nil, "FriendTreePanel"))
    local usable_liveness = data.usable_liveness
    value = data and string.format("%d/20", usable_liveness) or ""
    self:setLabelText("Label1", value, panel)
    self:setLabelText("Label2", value, panel)
    self:setLabelText("Label3", value, panel)
  else
    self:setCtrlVisible("DanLuPanel", false, "FriendTreePanel")
    self:setCtrlVisible("SupplyPanel", false, self:getControl("OperatePanel", nil, "FriendTreePanel"))
  end
end
function AnniversaryFriendDanLuDlg:refreshFriendPanel(friend)
  if not friend then
    return
  end
  local listView = self:getControl("FriendListView", nil, "FriendlistPanel")
  local item = listView:getChildByName(friend.gid)
  if not item then
    return
  end
  self:setOneFriendPanel(friend, item)
end
function AnniversaryFriendDanLuDlg:setNote(data)
  if data and not data.is_closed then
    self:setLabelText("Label1", CHS[2100344], "NotePanel")
    self:setLabelText("Label1", CHS[2100344], "NotePanel")
  else
    self:setLabelText("Label1", CHS[2100345], "NotePanel")
    self:setLabelText("Label1", CHS[2100345], "NotePanel")
  end
end
function AnniversaryFriendDanLuDlg:onSupplyButton(sender, eventType)
  local parent = self.chosenImage:getParent()
  if not parent then
    gf:ShowSmallTips(CHS[2100356])
    return
  end
  local gid = parent:getName()
  gf:CmdToServer("CMD_ZNQ_2020_XDHX_HELP", {friend_gid = gid})
end
function AnniversaryFriendDanLuDlg:onSelectFriendListView(sender, eventType)
  self.chosenImage:removeFromParent()
  sender:addChild(self.chosenImage)
  gf:CmdToServer("CMD_ZNQ_2020_XDHX_FRIEND_DATA", {
    gid = sender:getName()
  })
end
function AnniversaryFriendDanLuDlg:MSG_ZNQ_2020_XDHX_HELP_DATA_LIST(data)
  self.data = data
  self:setFriendList(true)
end
function AnniversaryFriendDanLuDlg:MSG_ZNQ_2020_XDHX_FRIEND_DATA(data)
  self:setCtrlVisible("NoticePanel", false, "MainPanel")
  if self.data then
    self.data.friend_datas[data.gid] = {
      gid = data.gid,
      level = data.level,
      has_danlu = 1,
      is_closed = data.is_closed
    }
  end
  self:refreshFriendPanel(FriendMgr:convertToUserData(FriendMgr:getFriendByGid(data.gid)))
  self:setFriendInfo(data)
  local parent = self.chosenImage:getParent()
  if not parent or parent:getName() ~= data.gid then
    return
  end
  if 1 == data.is_helped then
    self:setImage("FireImage", ResMgr.ui.fire_helped, parent)
  else
    self:setImage("FireImage", ResMgr.ui.fire_unhelped, parent)
  end
end
function AnniversaryFriendDanLuDlg:MSG_ZNQ_2020_XDHX_FRIEND_DATA_FAILED(data)
  local parent = self.chosenImage:getParent()
  if not parent then
    return
  end
  local gid = parent:getName()
  if gid == data.gid then
    if 2 == data.reason and self.data then
      self.data.friend_datas[data.gid] = {
        gid = data.gid,
        has_danlu = 0,
        level = 0
      }
    end
    self:setFriendInfo()
    self:refreshFriendPanel(FriendMgr:convertToUserData(FriendMgr:getFriendByGid(data.gid)))
    self:setCtrlVisible("NoticePanel", true, "MainPanel")
    self:setCtrlVisible("InfoBackImage1", data.reason == 1, self:getControl("NoticePanel", nil, "MainPanel"))
    self:setCtrlVisible("InfoBackImage3", data.reason == 2, self:getControl("NoticePanel", nil, "MainPanel"))
    self:setCtrlVisible("InfoBackImage4", 0 >= #self.friends, self:getControl("NoticePanel", nil, "MainPanel"))
  else
    self:setCtrlVisible("NoticePanel", false, "MainPanel")
  end
end
function AnniversaryFriendDanLuDlg:MSG_FRIEND_NOTIFICATION(data)
  local name = data.char
  local newFriendInfo = FriendMgr:convertToUserData(FriendMgr:getFriendByName(name))
  self:refreshFriendPanel(newFriendInfo)
end
function AnniversaryFriendDanLuDlg:MSG_FRIEND_UPDATE_PARTIAL(data)
  local name = data.char
  local newFriendInfo = FriendMgr:convertToUserData(FriendMgr:getFriendByGid(data.gid))
  self:refreshFriendPanel(newFriendInfo)
end
function AnniversaryFriendDanLuDlg:MSG_ZNQ_2020_XDHX_CLOSE_DLG(data)
  self:onCloseButton()
end
return AnniversaryFriendDanLuDlg
