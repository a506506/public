local BangpyhtjDlg = Singleton("BangpyhtjDlg", Dialog)
local POSITION_NUM = {
  [1] = {149},
  [2] = {102, 195},
  [3] = {
    57,
    149,
    237
  }
}
function BangpyhtjDlg:init(data)
  self:bindListener("DiscardButton", self.onDiscardButton)
  self:bindListener("TipsButton", self.onTipsButton)
  self.unitRowPanel = self:retainCtrl("RowPanel")
  for i = 1, 4 do
    local panel = self:bindListener("ItemPanel" .. i, self.onMaterialPanel, self.unitRowPanel)
    self:setCtrlVisible("ChosenImage", false, panel)
  end
  for i = 1, 3 do
    self:bindListener("Image_" .. i, self.onMartail)
  end
  self.selectMaterial = {}
  self.data = data
  self:setCooking()
  self:setShapeIcon()
  self:setMartial(data)
  self:updateSelectCount(data.submitedCount)
  self:hookMsg("MSG_PARTY_BPYH_INFO")
end
function BangpyhtjDlg:setShapeIcon()
  local img = self:setImage("PortraitImage", ResMgr:getBigPortrait(6015))
  img:setScale(0.5)
end
function BangpyhtjDlg:setTipsInfo(data)
end
function BangpyhtjDlg:setMartial(info)
  local data = {}
  local mainData = PartyMgr:getPartyBpyhInfo()
  local order = {}
  for i = 1, mainData.count do
    order[mainData.material[i]] = i
  end
  local temp = gf:deepCopy(info.material)
  for i = 1, info.count do
    if order[temp[i].name] then
      temp[i].order = order[temp[i].name]
    else
      temp[i].order = 5
    end
  end
  table.sort(temp, function(l, r)
    if l.order < r.order then
      return true
    end
    if l.order > r.order then
      return false
    end
  end)
  for i = 1, info.count do
    for j = 1, temp[i].amount do
      table.insert(data, temp[i].name)
    end
  end
  local listView = self:resetListView("ListView")
  local count = math.floor((#data - 1) / 4) + 1
  local idx = 0
  for i = 1, count do
    local panel = self.unitRowPanel:clone()
    for j = 1, 4 do
      idx = idx + 1
      local itemPanel = self:getControl("ItemPanel" .. j, nil, panel)
      itemPanel:setTag(idx)
      itemPanel.name = data[idx]
      self:setUnitRowPanel(data[idx], itemPanel)
    end
    listView:pushBackCustomItem(panel)
  end
  self:setCtrlVisible("NoticePanel", count == 0)
end
function BangpyhtjDlg:setUnitRowPanel(data, panel)
  if not data then
    panel:setVisible(false)
    return
  end
  self:setImage("ItemImage", PartyMgr:getBpyhItemIconPath(data), panel)
end
function BangpyhtjDlg:changeDish()
  gf:ShowSmallTips(CHS[4101754])
end
function BangpyhtjDlg:setCooking()
  local data = PartyMgr:getPartyBpyhInfo()
  local tips = string.format(CHS[4010487], data.dishNo, data.dishName)
  self:setColorText(tips, "InforPanel")
  for i = 1, 3 do
    if data.material[i] then
      local image = self:setImage("Image_" .. i, PartyMgr:getBpyhItemIconPath(data.material[i]), "IngredientsPanel")
      image.name = data.material[i]
    else
      self:setCtrlVisible("Image_" .. i, false, "IngredientsPanel")
    end
  end
  if data.count == 1 then
    self:getControl("Image_1", nil, "IngredientsPanel"):setPositionX(POSITION_NUM[1][1])
  elseif data.count == 2 then
    self:getControl("Image_1", nil, "IngredientsPanel"):setPositionX(POSITION_NUM[2][1])
    self:getControl("Image_2", nil, "IngredientsPanel"):setPositionX(POSITION_NUM[2][2])
  else
    self:getControl("Image_1", nil, "IngredientsPanel"):setPositionX(POSITION_NUM[3][1])
    self:getControl("Image_2", nil, "IngredientsPanel"):setPositionX(POSITION_NUM[3][2])
    self:getControl("Image_3", nil, "IngredientsPanel"):setPositionX(POSITION_NUM[3][3])
  end
  local startNum = math.floor(data.quality / 2)
  local halfNUm = data.quality % 2
  for i = 1, 5 do
    local image = self:setCtrlVisible("StarAllImage", i <= startNum, "StarPanel" .. i)
    self.starTextureRect = self.starTextureRect or image:getVirtualRendererSize()
    self.starContentSize = self.starContentSize or image:getContentSize()
    local x, y = self:getControl("StarImage", nil, "StarPanel" .. i):getPosition()
    image:setTextureRect(self.starTextureRect)
    image:setContentSize(self.starContentSize)
    image:setPosition(x, y)
  end
  if halfNUm > 0 then
    local image = self:setCtrlVisible("StarAllImage", true, "StarPanel" .. startNum + 1)
    local x, y = self:getControl("StarImage", nil, "StarPanel" .. startNum + 1):getPosition()
    local size = image:getContentSize()
    local ret = {
      x = 0,
      y = 0,
      width = self.starTextureRect.width * 0.5,
      height = self.starTextureRect.height
    }
    image:setTextureRect(ret)
    image:setContentSize({
      width = self.starContentSize.width * 0.5,
      height = self.starContentSize.height
    })
    image:setPositionX(x - size.width * 0.25)
  end
  self:setLabelText("NumLabel_1", data.correct, "CookingPanel")
  self:setLabelText("NumLabel_2", data.error, "CookingPanel")
end
function BangpyhtjDlg:onDiscardButton(sender, eventType)
  local data = PartyMgr:getPartyBpyhInfo()
  local ret = {}
  ret.dishNo = data.dishNo
  ret.foodMaterial = {}
  local temp = {}
  for _, name in pairs(self.selectMaterial) do
    if not temp[name] then
      temp[name] = 1
    else
      temp[name] = temp[name] + 1
    end
  end
  ret.count = 0
  for name, amount in pairs(temp) do
    table.insert(ret.foodMaterial, {name = name, amount = amount})
    ret.count = ret.count + 1
  end
  gf:CmdToServer("CMD_PARTY_BPYH_SUBMIT", ret)
end
function BangpyhtjDlg:getSelectAmount()
  local amount = 0
  for _, info in pairs(self.selectMaterial) do
    amount = amount + 1
  end
  return amount
end
function BangpyhtjDlg:onMaterialPanel(sender, eventType)
  if self.selectMaterial[sender:getTag()] then
    self:setCtrlVisible("ChosenImage", false, sender)
    self.selectMaterial[sender:getTag()] = nil
  else
    local amount = self:getSelectAmount()
    if amount >= 10 - self.data.submitedCount then
      gf:ShowSmallTips(string.format(CHS[4010488], 10 - self.data.submitedCount))
      return
    end
    self.selectMaterial[sender:getTag()] = sender.name
    self:setCtrlVisible("ChosenImage", true, sender)
  end
end
function BangpyhtjDlg:updateSelectCount(submitedCount)
  self:setLabelText("Label_45", string.format(CHS[4010489], submitedCount))
end
function BangpyhtjDlg:onMartail(sender, eventType)
  gf:showTipInfo(sender.name, sender)
end
function BangpyhtjDlg:onTipsButton(sender, eventType)
  DlgMgr:openDlg("BangpyhgzDlg")
end
function BangpyhtjDlg:MSG_PARTY_BPYH_INFO(data)
  self:setCooking()
  self:updateSelectCount(self.data.submitedCount)
end
return BangpyhtjDlg
