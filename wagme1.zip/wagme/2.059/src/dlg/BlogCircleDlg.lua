local BlogCircleDlg = Singleton("BlogCircleDlg", Dialog)
function BlogCircleDlg:init(data)
  self:bindListener("WriteButton", self.onWriteButton)
  self:bindListener("CheckBoxPanel", self.onCheckBoxPanel)
  self:bindListener("UnReadNotePanel", self.onUnReadNotePanel)
  self:bindListener("BackButton", self.onBackButton, "OutPanel2")
  self:bindListViewListener("ListView", self.onSelectListView)
  self.unitStatePanel = self:retainCtrl("OneStatePanel")
  self:bindListener("DeleteButton", self.onDeleteButton, self.unitStatePanel)
  self:bindListener("ReportButton", self.onReportButton, self.unitStatePanel)
  self:bindListener("LikeButton", self.onLikeButton, self.unitStatePanel)
  self:bindListener("TalkButton", self.onTalkButton, self.unitStatePanel)
  self:bindListener("LikePanel", self.onLikeNamePanel, self.unitStatePanel)
  self:bindListener("ZanPanel4", self.onLikeNamePanel, self.unitStatePanel)
  self:bindListener("MoreButton", self.onMoreButton, self.unitStatePanel)
  self:bindListener("PortraitPanel", self.onCharInfoButton, self.unitStatePanel)
  self:bindListener("SheQuPanel", self.onSheQuPanel, self.unitStatePanel)
  for i = 1, 3 do
    self:bindListener("ZanPanel" .. i, self.onCharInfoButton, self.unitStatePanel)
  end
  self.unitTalkPanel = self:retainCtrl("UnitTalkPanel", self.unitStatePanel)
  self:bindTouchEndEventListenerBlog(self.unitTalkPanel, self.onReTalkButton)
  self:bindListener("UserNamePanel", self.onCharInfoButton, self.unitTalkPanel)
  self:bindListener("FirstNamePanel", self.onCharInfoButton, self.unitTalkPanel)
  self:bindListener("SecondNamePanel", self.onCharInfoButton, self.unitTalkPanel)
  for i = 1, 4 do
    local panel = self:getControl("PhotoPanel" .. i, nil, self.unitStatePanel)
    panel:setTag(i)
    panel:setVisible(false)
    self:bindTouchEndEventListener(panel, self.onPhotoPanel)
  end
  self:getControl("PhotoPanel3_2", nil, self.unitStatePanel):setTag(3)
  self:setCtrlVisible("PhotoPanel3_2", false, self.unitStatePanel)
  self:bindListener("PhotoPanel3_2", self.onPhotoPanel, self.unitStatePanel)
  self:setCtrlVisible("LoadingPanel", false)
  self:setCtrlVisible("UnReadNotePanel", false)
  if not Me:isBindName() then
    gf:CmdToServer("CMD_REQUEST_FUZZY_IDENTITY", {force_request = 0})
  end
  self.curListViewName = "ListView"
  self:setCheck("MineCheckBox", false)
  self.lastCheckBoxState = false
  self.isNewquery = false
  self.isUnReadView = false
  self.lastQueryTime = 0
  self.openTime = gfGetTickCount()
  self.listOrgSize = self.listOrgSize or self:getCtrlContentSize("ListView")
  self:setData(data)
  local function callback(dlg, percent)
    local list = self:getControl(self.curListViewName)
    if percent > 100 then
      do
        local viewType = self:isCheck("MineCheckBox") and 1 or 0
        local lastData = self:getLoadedLastData()
        if lastData and lastData.sid then
          if gfGetTickCount() - self.lastQueryTime > 1000 then
            do
              local isUnReadView = self.isUnReadView
              self.root:stopAction(self.delayRequest)
              self.delayRequest = performWithDelay(self.root, function()
                if isUnReadView then
                  BlogMgr:queryUnReadStatusList(lastData.sid)
                else
                  BlogMgr:queryBlogsList(BlogMgr:getUserGid(self.name), lastData.sid, viewType)
                end
              end, 0.5)
              self.lastQueryTime = gfGetTickCount()
              local lodingPanel = self:getControl("LoadingPanel"):clone()
              lodingPanel:setVisible(true)
              lodingPanel:setName("LoadingPanel")
              lodingPanel.data = {}
              list:pushBackCustomItem(lodingPanel)
            end
          else
            gf:ShowSmallTips(CHS[4200455])
          end
        end
      end
    elseif percent == 0 and not self.isUnReadView then
      if list:getInnerContainerSize().height == list:getContentSize().height and list:getInnerContainer():getPositionY() < -50 and not list:getChildByName("LoadingPanel") then
        if gfGetTickCount() - self.lastQueryTime > 1000 then
          self.root:stopAction(self.delayRequest)
          self.delayRequest = performWithDelay(self.root, function()
            local viewType = self:isCheck("MineCheckBox") and 1 or 0
            BlogMgr:queryBlogsList(BlogMgr:getUserGid(self.name), nil, viewType)
          end, 0.5)
          self.lastQueryTime = gfGetTickCount()
          local lodingPanel = self:getControl("LoadingPanel"):clone()
          lodingPanel:setVisible(true)
          lodingPanel:setName("LoadingPanel")
          lodingPanel.data = {}
          list:insertCustomItem(lodingPanel, 0)
          local viewType = self:isCheck("MineCheckBox") and 1 or 0
          self.isNewquery = true
        else
          gf:ShowSmallTips(CHS[4200455])
        end
      end
    elseif percent < 0 and not self.isUnReadView and math.abs(list:getInnerContainerSize().height * percent * 0.01) > 50 and not list:getChildByName("LoadingPanel") then
      if gfGetTickCount() - self.lastQueryTime > 1000 then
        self.root:stopAction(self.delayRequest)
        self.delayRequest = performWithDelay(self.root, function()
          local viewType = self:isCheck("MineCheckBox") and 1 or 0
          BlogMgr:queryBlogsList(BlogMgr:getUserGid(self.name), nil, viewType)
        end, 0.5)
        self.lastQueryTime = gfGetTickCount()
        local lodingPanel = self:getControl("LoadingPanel"):clone()
        lodingPanel:setVisible(true)
        lodingPanel:setName("LoadingPanel")
        lodingPanel.data = {}
        list:insertCustomItem(lodingPanel, 0)
        local viewType = self:isCheck("MineCheckBox") and 1 or 0
        self.isNewquery = true
      else
        gf:ShowSmallTips(CHS[4200455])
      end
    end
  end
  self:bindListViewByPageLoad("ListView", "TouchPanel", callback)
  self:bindListViewByPageLoad("UnReadListView", "UnReadTouchPanel", callback)
  self:setListViewItemVisible()
  performWithDelay(self.root, function()
    self:MSG_BLOG_STATUS_NUM_ABOUT_ME({
      count = BlogMgr.unReadStatueCount or 0
    })
  end, 0)
  self:hookMsg("MSG_BLOG_UPDATE_ONE_STATUS")
  self:hookMsg("MSG_BLOG_REQUEST_STATUS_LIST")
  self:hookMsg("MSG_BLOG_DELETE_ONE_STATUS")
  self:hookMsg("MSG_BLOG_ALL_COMMENT_LIST")
  self:hookMsg("MSG_BLOG_UPDATE_ONE_STATUS")
  self:hookMsg("MSG_BLOG_STATUS_NUM_ABOUT_ME")
  self:hookMsg("MSG_BLOG_STATUS_LIST_ABOUNT_ME")
  self:hookMsg("MSG_BLOG_LIKE_ONE_STATUS")
  self:hookMsg("MSG_OFFLINE_CHAR_INFO")
  self:hookMsg("MSG_CROSS_SERVER_CHAR_INFO")
  self:hookMsg("MSG_CHAR_INFO_EX")
  self:hookMsg("MSG_BLOG_DELETE_ALL_COMMENT_AND_MESSAGE")
end
function BlogCircleDlg:setListViewItemVisible()
  local function onScrollView(sender, eventType)
    if ccui.ScrollviewEventType.scrolling == eventType then
      performWithDelay(self.root, function()
        local items = sender:getItems()
        for _, panel in pairs(items) do
          local curListY = sender:getInnerContainer():getPositionY()
          local panelY = panel:getPositionY()
          local panelSize = panel:getContentSize()
          if sender:getContentSize().height >= sender:getInnerContainer():getContentSize().height then
            panel:setVisible(true)
          elseif curListY + panelY + panelSize.height > 0 and panelY + curListY < sender:getContentSize().height then
            panel:setVisible(true)
          else
            panel:setVisible(false)
          end
        end
      end, 0)
    end
  end
  self:getControl("ListView"):addScrollViewEventListener(onScrollView)
end
function BlogCircleDlg:cleanup()
  DlgMgr:closeDlg("BlogInfoDlg")
end
function BlogCircleDlg:onCheckBoxPanel(sender, eventType)
  sender.lastTime = sender.lastTime or 0
  if gfGetTickCount() - sender.lastTime < 1000 then
    gf:ShowSmallTips(CHS[4300276])
    return
  end
  sender.lastTime = gfGetTickCount()
  local check = self:getControl("MineCheckBox")
  if check:getSelectedState() then
    check:setSelectedState(false)
    BlogMgr:switchViewSetting(0)
  else
    check:setSelectedState(true)
    BlogMgr:switchViewSetting(1)
  end
  self:resetListView("ListView")
end
function BlogCircleDlg:setMyBlog(isMe)
  isMe = isMe or BlogMgr:isMySelf(self.name)
  self:setCtrlVisible("OutPanel", isMe)
  if isMe then
    self:setCtrlContentSize("ListView", nil, self.listOrgSize.height)
    self:setCtrlContentSize("UnReadListView", nil, self.listOrgSize.height)
  else
    self:setCtrlContentSize("ListView", nil, self.listOrgSize.height + 63)
    self:setCtrlContentSize("UnReadListView", nil, self.listOrgSize.height)
  end
  if isMe then
    self:setLabelText("TitleLabel_2", CHS[4100856])
  else
    local userName = BlogMgr:getUserName(self.name)
    if not string.isNilOrEmpty(userName) then
      self:setLabelText("TitleLabel_2", string.format(CHS[4100857], gf:getRealName(userName)))
    else
      self:setLabelText("TitleLabel_2", "")
    end
  end
end
function BlogCircleDlg:setData(data)
  self.gid = data.uid
  self:setMyBlog()
  self:setFriendsDynamics(data)
end
function BlogCircleDlg:setFriendsDynamics(data)
  local list = self:resetListView(self.curListViewName)
  BlogMgr:cleanAutoLoad(self.name)
  if data.count <= 0 then
    self:setCtrlVisible("NoticePanel", true)
    return
  end
  self:setCtrlVisible("NoticePanel", false)
  self:loadFriendsDynamics(data)
end
function BlogCircleDlg:loadFriendsDynamics(data)
  local list = self:getControl(self.curListViewName)
  local height = 0
  local items = list:getItems()
  for i = 1, #items do
    height = height + items[i]:getContentSize().height
  end
  for i = 1, data.count do
    local panel = self.unitStatePanel:clone()
    panel.data = data[i]
    list:pushBackCustomItem(panel)
    self:setUnitDynamics(data[i], panel)
    height = height + panel:getContentSize().height
    list:requestDoLayout()
    list:requestRefreshView()
    list:refreshView()
  end
end
function BlogCircleDlg:getCheckState()
  return self:isCheck("MineCheckBox") and 1 or 0
end
function BlogCircleDlg:getDisplayTime(time)
  local passTime = gf:getServerTime() - time
  if passTime < 3600 then
    return string.format(CHS[4100700], math.max(math.ceil(passTime / 60), 1))
  elseif passTime < 86400 then
    return string.format(CHS[4100775], math.floor(passTime / 3600))
  end
  return gf:getServerDate("%Y-%m-%d", time)
end
function BlogCircleDlg:setPhoto(path, para)
  local tab = gf:split(para, "|")
  if not tab then
    return
  end
  local sid = tab[1]
  local ctlName = tab[2]
  local list = self:getControl(self.curListViewName)
  local items = list:getItems()
  for _, panel in pairs(items) do
    if panel.data and sid == panel.data.sid then
      local ctlPanel = self:getControl(ctlName, nil, panel)
      if ctlPanel then
        if not path or path == "" then
          self:setCtrlVisible("PhotoBKImage3", true, ctlPanel)
        else
          self:setImage("PhotoImage", path, ctlPanel)
          self:setSmallImageSize("PhotoImage", ctlPanel)
        end
        self:setCtrlVisible("PhotoBKImage1", false, ctlPanel)
      end
    end
  end
  list:requestRefreshView()
end
function BlogCircleDlg:setSmallImageSize(imageName, panel)
  local image = self:getControl(imageName, nil, panel)
  local orgSize = image:getContentSize()
  local w1 = orgSize.width
  local h1 = orgSize.height
  local w2 = 144
  local h2 = 96
  if w1 / h1 > w2 / h2 then
    self:setImageSize(imageName, cc.size(w1 * h2 / h1, h2), panel)
  else
    self:setImageSize(imageName, cc.size(w2, h1 * w2 / w1), panel)
  end
end
function BlogCircleDlg:setUnitDynamics(data, panel)
  if not BlogMgr:isMySelf(self.name) then
    local info = BlogMgr:getUserDataByGid(self.gid)
    if not data.icon then
      local icon = ResMgr:getIconByPolarAndGender(info.polar, info.gender)
      data.icon = icon
    end
    if not data.level then
      data.level = info.level
    end
    if not data.name then
      data.name = info.name
    end
  end
  self:setLabelText("TimeLabel", self:getDisplayTime(data.time), panel)
  self:setImage("PortraitImage", ResMgr:getSmallPortrait(data.icon), panel)
  if data.dist ~= GameMgr:getDistName() then
    gf:addKuafLogo(self:getControl("PortraitPanel", nil, panel))
  end
  self:setNumImgForPanel("PortraitPanel", ART_FONT_COLOR.NORMAL_TEXT, data.level, false, LOCATE_POSITION.LEFT_TOP, 19, panel)
  self:getControl("PortraitPanel", nil, panel).data = {
    uid = data.uid,
    dist = data.dist
  }
  self:setLabelText("NameLabel", gf:getRealName(data.name), panel)
  panel.isExpand = self.isUnReadView and 1 or 0
  self:setCtrlVisible("ReportButton", data.uid ~= Me:queryBasic("gid"), panel)
  self:setCtrlVisible("ReportTextLabel", data.uid ~= Me:queryBasic("gid"), panel)
  self:setCtrlVisible("DeleteButton", data.uid == Me:queryBasic("gid"), panel)
  if data.text == "" then
    self:setCtrlContentSize("TextPanel", nil, 0, panel)
  else
    self:setUnitText(panel, data)
  end
  local pictureData = {}
  if data.img_str ~= "" then
    pictureData.path = gf:split(data.img_str, "|")
    pictureData.count = #pictureData.path
  else
    pictureData = {count = 0}
  end
  local photoPanel = self:getControl("PhotoPanel", nil, panel)
  photoPanel.img_str = data.img_str
  if pictureData.count > 3 then
    local op = {
      process = BlogMgr.PHOTO_SMALL_SIZE_STR
    }
    BlogMgr:assureFile("setPhoto", self.name, pictureData.path[1], op, data.sid .. "|PhotoPanel1")
    local panel1 = self:getControl("PhotoPanel1", nil, panel)
    panel1.path = pictureData.path[1]
    panel1.op = op
    panel1.para = data.sid .. "|PhotoPanel1"
    self:setCtrlVisible("PhotoPanel1", true, panel)
    BlogMgr:assureFile("setPhoto", self.name, pictureData.path[2], op, data.sid .. "|PhotoPanel2")
    local panel1 = self:getControl("PhotoPanel2", nil, panel)
    panel1.path = pictureData.path[2]
    panel1.op = op
    panel1.para = data.sid .. "|PhotoPanel2"
    self:setCtrlVisible("PhotoPanel2", true, panel)
    BlogMgr:assureFile("setPhoto", self.name, pictureData.path[3], op, data.sid .. "|PhotoPanel3_2")
    local panel1 = self:getControl("PhotoPanel3_2", nil, panel)
    panel1.path = pictureData.path[3]
    panel1.op = op
    panel1.para = data.sid .. "|PhotoPanel3"
    self:setCtrlVisible("PhotoPanel3_2", true, panel)
    BlogMgr:assureFile("setPhoto", self.name, pictureData.path[4], op, data.sid .. "|PhotoPanel4")
    local panel1 = self:getControl("PhotoPanel4", nil, panel)
    panel1.path = pictureData.path[4]
    panel1.op = op
    panel1.para = data.sid .. "|PhotoPanel4"
    self:setCtrlVisible("PhotoPanel4", true, panel)
  elseif 1 <= pictureData.count then
    for i = 1, 3 do
      if pictureData.path[i] then
        local op = {
          process = BlogMgr.PHOTO_SMALL_SIZE_STR
        }
        BlogMgr:assureFile("setPhoto", self.name, pictureData.path[i], op, data.sid .. "|PhotoPanel" .. i)
        local panel1 = self:getControl("PhotoPanel" .. i, nil, panel)
        panel1.path = pictureData.path[i]
        panel1.op = op
        panel1.para = data.sid .. "|PhotoPanel" .. i
        self:setCtrlVisible("PhotoPanel" .. i, true, photoPanel)
      end
    end
    local photoPanel = self:getControl("PhotoPanel", nil, panel)
    photoPanel:setContentSize(photoPanel:getContentSize().width, photoPanel:getContentSize().height * 0.5)
  else
    local photoPanel = self:getControl("PhotoPanel", nil, panel)
    if self:getCtrlVisible("SheQuPanel", panel) then
      local contentSize = self:getCtrlContentSize("SheQuPanel", panel)
      photoPanel:setContentSize(photoPanel:getContentSize().width, contentSize.height)
    else
      photoPanel:setContentSize(photoPanel:getContentSize().width, 0)
    end
  end
  self:setUnitDynamicsForZanData(data, panel)
  self:setUnitDynamicsForTalk(data, panel)
  self:setAutoSize(panel)
  panel.data = data
end
function BlogCircleDlg:setUnitDynamicsForTalk(data, panel)
  self:setLabelText("TalkNumLabel", data.comment_num, panel)
  local talkData = data.commentData
  local talkPanel = self:getControl("TalkTetPanel", nil, panel)
  talkPanel:removeAllChildren()
  talkPanel:setLayoutType(ccui.LayoutType.VERTICAL)
  local totalHeight = 0
  table.sort(talkData, function(l, r)
    if l.cid > r.cid then
      return true
    end
    if l.cid < r.cid then
      return false
    end
    return false
  end)
  for i = 1, data.comment_count do
    if talkData[i] then
      local unitTalkPanel = self.unitTalkPanel:clone()
      local height = self:setUnitDynamicsForUnitTalk(talkData[i], unitTalkPanel)
      local lp = ccui.LinearLayoutParameter:create()
      unitTalkPanel:setLayoutParameter(lp)
      lp:setGravity(ccui.LinearGravity.centerHorizontal)
      lp:setMargin({
        left = 0,
        top = 3,
        right = 0,
        bottom = 0
      })
      talkPanel:addChild(unitTalkPanel)
      totalHeight = totalHeight + height + 3
    end
  end
  if totalHeight ~= 0 then
    totalHeight = totalHeight + 10
  end
  talkPanel:requestDoLayout()
  local root = self:getControl("TalkPanel", nil, panel)
  root:setContentSize(root:getContentSize().width, totalHeight + self:getCtrlContentSize("ZanListPanel", panel).height)
  self:setCtrlContentSize("BKImage", nil, root:getContentSize().height - 2, root)
  self:setCtrlVisible("BKImage", root:getContentSize().height ~= 0, root)
  root:requestDoLayout()
  self:setCtrlVisible("MoreButton", data.comment_num > 5 and 1 ~= panel.isExpand, panel)
end
function BlogCircleDlg:setUnitDynamicsForUnitTalk(data, panel)
  local height = 0
  local nameStr = ""
  local talkPanel
  panel.data = data
  local showName = gf:getShowName(data.name)
  if data.reply_name ~= "" then
    self:setCtrlVisible("OneUserPanel", false, panel)
    talkPanel = self:getControl("TwoUserPanel", nil, panel)
    local nameStr1 = string.format("#G[%s]#n", showName)
    local namePanel1 = self:setColorTextAutoSetSize(nameStr1, "FirstNamePanel", panel)
    namePanel1.data = data
    namePanel1:removeAllChildren()
    local huifuPanel = self:setColorTextAutoSetSize(CHS[4100858], "MidPanel", panel)
    huifuPanel:removeAllChildren()
    local nameStr2 = string.format("#G[%s]#n", data.reply_name)
    local namePanel2 = self:setColorTextAutoSetSize(nameStr2, "SecondNamePanel", panel)
    namePanel2.data = {
      name = data.reply_name,
      uid = data.reply_uid,
      dist = data.reply_dist
    }
    namePanel2:removeAllChildren()
    nameStr = nameStr1 .. CHS[4100858] .. nameStr2
    local panel1 = self:getControl("FirstNamePanel", nil, panel)
    self:setCtrlOpacity("NameClick", 0, panel1)
    self:setCtrlVisible("NameClick", false, panel1)
    local panel1 = self:getControl("FirstNamePanel", nil, panel)
    self:setCtrlOpacity("MidPanel", 0, panel)
    self:setCtrlOpacity("SecondNamePanel", 0, panel)
  else
    self:setCtrlVisible("TwoUserPanel", false, panel)
    talkPanel = self:getControl("OneUserPanel", nil, panel)
    nameStr = string.format("#G[%s]#n", showName)
    local namePanel = self:setColorTextAutoSetSize(nameStr, "UserNamePanel", panel)
    namePanel:removeAllChildren()
    self:getControl("UserNamePanel", nil, panel).data = data
  end
  panel.talkPanel = talkPanel
  local contentStr = nameStr .. "：" .. gf:filtTextByTwo(data.text, nil, true)
  local conPanel = self:getControl("ContentPanel", nil, talkPanel)
  local isInsider = data.insider and data.insider >= 1 and true or false
  height = self:setColorText(contentStr, conPanel, nil, nil, nil, nil, 19, nil, nil, isInsider)
  local touchImage = self:getControl("TouchImage", nil, conPanel)
  touchImage:setContentSize(conPanel:getContentSize().width + 30, conPanel:getContentSize().height + 6)
  touchImage:setVisible(false)
  touchImage:setPosition(conPanel:getContentSize().width * 0.5, conPanel:getContentSize().height * 0.5)
  conPanel:requestDoLayout()
  panel:setContentSize(conPanel:getContentSize())
  return height
end
function BlogCircleDlg:setUnitDynamicsForZanData(data, panel)
  self:setLabelText("LikeNumLabel", data.like_num, panel)
  if data.isLike then
    self:setImage("LikeIconImage", ResMgr.ui.likeImage, panel)
  end
  local zanData = data.likeNameList
  for i = 1, 3 do
    if zanData[i] then
      local zanUnitPanel = self:getControl("ZanPanel" .. i, nil, panel)
      local nameStr = string.format("#G[%s]#n", gf:getRealName(zanData[i].name))
      self:setColorTextAutoSetSize(nameStr, zanUnitPanel, panel)
      zanUnitPanel.data = zanData[i]
    else
      self:setCtrlContentSize("ZanPanel" .. i, 0, nil, panel)
    end
  end
  if data.like_num > 3 then
    self:setCtrlVisible("ZanPanel4", true, panel)
    self:setColorText(" #G...#n", "ZanPanel4", panel, nil, nil, nil, 19)
  else
    self:setCtrlVisible("ZanPanel4", false, panel)
  end
  if data.like_count == 0 then
    self:setCtrlVisible("ZanListPanel", false, panel)
    self:setCtrlContentSize("ZanListPanel", nil, 0, panel)
  else
    self:setCtrlVisible("ZanListPanel", true, panel)
    local size = self:getCtrlContentSize("ZanListPanel", self.unitStatePanel)
    self:setCtrlContentSize("ZanListPanel", nil, size.height + 4, panel)
  end
  local zanListPanel = self:getControl("ZanListPanel", nil, panel)
  self:setCtrlVisible("LineImage", data.like_count ~= 0 and data.comment_num ~= 0, zanListPanel)
end
function BlogCircleDlg:setColorTextAutoSetSize(str, panelName, root, marginX, marginY, defColor, fontSize, isPunct, insider)
  marginX = marginX or 0
  marginY = marginY or 0
  root = root or self.root
  fontSize = fontSize or 19
  defColor = defColor or COLOR3.TEXT_DEFAULT
  local panel
  if type(panelName) == "string" then
    panel = self:getControl(panelName, Const.UIPanel, root)
  else
    panel = panelName
  end
  panel:removeAllChildren()
  local size = panel:getContentSize()
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(fontSize)
  textCtrl:setString(str, insider)
  textCtrl:setContentSize(400, 0)
  textCtrl:setDefaultColor(defColor.r, defColor.g, defColor.b)
  if textCtrl.setPunctTypesetting then
    textCtrl:setPunctTypesetting(true == isPunct)
  end
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  local colorTLayer = tolua.cast(textCtrl, "cc.LayerColor")
  colorTLayer:setPosition(0, textH)
  colorTLayer:setName("NameClick")
  panel:addChild(colorTLayer)
  local panelHeight = textH + 2 * marginY
  panel:setContentSize(textW, panelHeight)
  return panel
end
function BlogCircleDlg:setAutoSize(panel)
  local height1 = self:getCtrlContentSize("TextPanel", self.unitStatePanel).height - self:getCtrlContentSize("TextPanel", panel).height
  local height2 = self:getCtrlContentSize("PhotoPanel", self.unitStatePanel).height - self:getCtrlContentSize("PhotoPanel", panel).height
  local height3 = self:getCtrlContentSize("TalkPanel", panel).height
  local height4 = self:getCtrlContentSize("ZanListPanel", panel).height
  local height5 = 8
  if height5 ~= 0 then
    height5 = height5 + 10
  end
  panel:setContentSize(self.unitStatePanel:getContentSize().width, self.unitStatePanel:getContentSize().height - height1 - height2 + height3 + height5)
  panel:requestDoLayout()
end
function BlogCircleDlg:onPhotoPanel(sender, eventType)
  if self:getCtrlVisible("PhotoBKImage3", sender) then
    self:setCtrlVisible("PhotoBKImage3", false, sender)
    self:setCtrlVisible("PhotoBKImage1", true, sender)
    BlogMgr:assureFile("setPhoto", self.name, sender.path, sender.op, sender.para)
  else
    local img_str = sender:getParent().img_str
    local dlg = DlgMgr:openDlg("BlogPhotoDlg")
    dlg:setPicture(sender:getTag(), img_str)
  end
end
function BlogCircleDlg:onCharInfoButton(sender, eventType)
  if not sender.data then
    return
  end
  if sender.data.uid == Me:queryBasic("gid") then
    return
  end
  self.selectCharGid = sender.data.uid
  FriendMgr:requestCharMenuInfo(sender.data.uid, nil, nil, 1, nil, sender.data.dist)
end
function BlogCircleDlg:onWriteButton(sender, eventType)
  if Me:queryBasicInt("level") < 40 then
    gf:ShowSmallTips(CHS[4100859])
    return
  end
  if Me:getAdultStatus() == 2 then
    gf:ShowSmallTips(CHS[4100860])
    return
  end
  local userDefault = cc.UserDefault:getInstance()
  local isNeedAG = userDefault:getIntegerForKey("BlogAgreementDlg", 0)
  if isNeedAG == 0 then
    DlgMgr:openDlgEx("BlogAgreementDlg", self.name)
    return
  end
  DlgMgr:openDlgEx("BlogStateDlg", self.name)
end
function BlogCircleDlg:onLikeButton(sender, eventType)
  if Me:queryBasicInt("level") < 40 then
    gf:ShowSmallTips(CHS[4100861])
    return
  end
  local onePanel = sender:getParent():getParent()
  BlogMgr:likeStatusById(onePanel.data.sid, onePanel.data.dist, onePanel.data.uid)
end
function BlogCircleDlg:onLikeNamePanel(sender, eventType)
  local onePanel = sender:getParent():getParent():getParent()
  if sender:getName() == "ZanPanel4" then
    onePanel = sender:getParent():getParent():getParent():getParent()
  end
  local data = onePanel.data
  DlgMgr:openDlgEx("BlogRecordDlg", {
    type = "like",
    para = data.sid,
    gid = self.gid,
    dist = data.dist
  })
end
function BlogCircleDlg:onDelComment(sender, eventType)
  if not self.opComment then
    return
  end
  gf:confirm(CHS[4200464], function()
    if not DlgMgr:getDlgByName("BlogCircleDlg") then
      return
    end
    BlogMgr:deleteComment(self.opComment.sid, self.opComment.cid, self.opComment.isExpand, self.opComment.status_dist)
  end)
end
function BlogCircleDlg:onDelSomeOneAllComment(sender, eventType)
  if not self.opComment then
    return
  end
  local opComment = self.opComment
  gf:confirm(CHS[2200229], function()
    if not DlgMgr:getDlgByName("BlogCircleDlg") then
      return
    end
    BlogMgr:deleteSomeOneAllComment(opComment.charGid)
  end)
end
function BlogCircleDlg:onReComment(sender, eventType)
  if not self.opComment then
    return
  end
  local dlg = DlgMgr:openDlg("BlogCommentDlg")
  local ret = {
    name = self.opComment.name,
    uid = self.opComment.uid,
    sid = self.opComment.sid,
    reply_cid = self.opComment.cid,
    reply_dist = self.opComment.reply_dist,
    isExpand = self.opComment.isExpand,
    charGid = self.opComment.charGid,
    status_dist = self.opComment.status_dist
  }
  dlg:setData(ret)
end
function BlogCircleDlg:opTalkButton(sender)
  local data = sender.data
  local mainPanel = sender:getParent():getParent():getParent()
  local mainData = mainPanel.data
  if Me:queryBasic("gid") == mainData.uid then
    if Me:queryBasic("gid") ~= data.uid then
      BlogMgr:showButtonList(self, sender, "blogCommentOp", self.name)
      self.opComment = {
        text = data.text,
        name = data.name,
        uid = mainData.uid,
        reply_dist = data.dist,
        sid = mainData.sid,
        cid = data.cid,
        isExpand = mainPanel.isExpand,
        charGid = data.uid,
        status_dist = mainData.dist,
        reply_cid = data.cid
      }
    else
      BlogMgr:showButtonList(self, sender, "blogDelCommentOp", self.name)
      self.opComment = {
        name = data.name,
        uid = mainData.uid,
        reply_dist = data.dist,
        sid = mainData.sid,
        cid = data.cid,
        isExpand = mainPanel.isExpand,
        charGid = data.uid,
        status_dist = mainData.dist
      }
    end
    return
  end
  if Me:queryBasic("gid") ~= mainPanel.uid then
    if Me:queryBasic("gid") ~= data.uid then
      BlogMgr:showButtonList(self, sender, "blogCommentAndReport", self.name)
      self.opComment = {
        name = data.name,
        uid = mainData.uid,
        sid = mainData.sid,
        reply_cid = data.cid,
        reply_dist = data.dist,
        isExpand = mainPanel.isExpand,
        charGid = data.uid,
        status_dist = mainData.dist,
        text = data.text
      }
    else
      BlogMgr:showButtonList(self, sender, "blogDelCommentOp", self.name)
      self.opComment = {
        name = data.name,
        uid = mainData.uid,
        reply_dist = data.dist,
        sid = mainData.sid,
        cid = data.cid,
        isExpand = mainPanel.isExpand,
        charGid = data.uid,
        status_dist = mainData.dist
      }
    end
    return
  end
end
function BlogCircleDlg:onReportCommentForBlog(sender, eventType)
  if not self.opComment then
    return
  end
  local para = "@spcial@;" .. self.opComment.text .. CHS[4300500] .. self.opComment.status_dist .. ":" .. self.opComment.sid .. "-" .. self.opComment.reply_cid .. ";" .. BlogMgr:getBlogGidByDlgName(self.name)
  ChatMgr:questOpenReportDlg(self.opComment.charGid, self.opComment.name, self.opComment.reply_dist, para)
end
function BlogCircleDlg:onReplyCommentForBlog(sender, eventType)
  if not self.opComment then
    return
  end
  local dlg = DlgMgr:openDlg("BlogCommentDlg")
  dlg:setData(self.opComment)
end
function BlogCircleDlg:onReTalkButton(sender, eventType)
  if eventType == ccui.TouchEventType.ended then
    self:opTalkButton(sender)
    self:setCtrlVisible("TouchImage", false, sender.talkPanel)
  elseif eventType == ccui.TouchEventType.began then
    self:setCtrlVisible("TouchImage", true, sender.talkPanel)
  elseif eventType == ccui.TouchEventType.canceled then
    self:setCtrlVisible("TouchImage", false, sender.talkPanel)
  end
end
function BlogCircleDlg:onTalkButton(sender, eventType)
  if gf:isLimitChangeUserInfo() then
    return
  end
  local onePanel = sender:getParent():getParent()
  local data = onePanel.data
  local dlg = DlgMgr:openDlg("BlogCommentDlg")
  local ret = {
    uid = data.uid,
    sid = data.sid,
    reply_dist = data.dist,
    reply_cid = 0,
    isExpand = onePanel.isExpand,
    name = data.name,
    charGid = data.uid,
    status_dist = data.dist
  }
  dlg:setData(ret)
end
function BlogCircleDlg:onReportButton(sender, eventType)
  if Me:queryBasicInt("level") < 40 then
    gf:ShowSmallTips(CHS[4100862])
    return
  end
  local data = sender:getParent():getParent().data
  BlogMgr:reportStatus(data.uid, data.sid, data.dist)
end
function BlogCircleDlg:onMoreButton(sender, eventType)
  local data = sender:getParent():getParent().data
  BlogMgr:queryAllComment(data.sid, data.dist)
  sender:setVisible(false)
end
function BlogCircleDlg:onDeleteButton(sender, eventType)
  gf:confirm(CHS[4100863], function()
    if not DlgMgr:getDlgByName("BlogCircleDlg") then
      return
    end
    local onePanel = sender:getParent():getParent()
    local data = onePanel.data
    BlogMgr:deleteStatus(data.sid)
  end)
end
function BlogCircleDlg:onSheQuPanel(sender, eventType)
  local articleId = sender.articleId
  if not articleId then
    return
  end
  CommunityMgr:openCommunityDlg(articleId)
end
function BlogCircleDlg:onSelectListView(sender, eventType)
end
function BlogCircleDlg:MSG_BLOG_UPDATE_ONE_STATUS(data)
  local list = self:getControl("ListView")
  local items = list:getItems()
  for _, panel in pairs(items) do
    if panel.data and panel.data.sid == data.sid then
      self:setUnitDynamicsForZanData(data, panel)
      self:setUnitDynamicsForTalk(data, panel)
      self:setAutoSize(panel)
    end
  end
  list:requestRefreshView()
  if self.curListViewName ~= "UnReadListView" then
    return
  end
  local list = self:getControl("UnReadListView")
  local items = list:getItems()
  for _, panel in pairs(items) do
    if panel.data and panel.data.sid == data.sid then
      self:setUnitDynamicsForZanData(data, panel)
      self:setUnitDynamicsForTalk(data, panel)
      self:setAutoSize(panel)
    end
  end
  list:requestRefreshView()
end
function BlogCircleDlg:getLoadedLastData()
  local list = self:getControl(self.curListViewName)
  local items = list:getItems()
  local count = #items
  if count ~= 0 then
    return items[count].data
  end
end
function BlogCircleDlg:MSG_BLOG_REQUEST_STATUS_LIST(data)
  if data.uid ~= BlogMgr:getBlogGidByDlgName(self.name) then
    return
  end
  if self:isCheck("MineCheckBox") ~= (data.viewType ~= 0) then
    return
  end
  local listName = "ListView"
  local list = self:getControl(listName)
  local loadingPanel = list:getChildByName("LoadingPanel")
  list:removeChild(loadingPanel)
  list:refreshView()
  if gfGetTickCount() - self.openTime <= 1000 then
    return
  end
  local items = list:getItems()
  if #items == 0 then
    self:setFriendsDynamics(data)
  elseif data.count == 0 then
    gf:ShowSmallTips(CHS[4200456])
  else
    local lastData = items[#items].data
    if lastData.time and lastData.time > data[1].time then
      self:loadFriendsDynamics(data)
    else
      if self.lastCheckBoxState == (data.viewType ~= 0) and self.isNewquery and items[1].data.time ~= data[1].time then
        gf:ShowSmallTips(CHS[4200465])
        ChatMgr:sendMiscMsg(CHS[4200465])
      end
      self:setFriendsDynamics(data)
    end
  end
  list:refreshView()
  self.isNewquery = false
  self.lastCheckBoxState = self:isCheck("MineCheckBox")
end
function BlogCircleDlg:MSG_BLOG_LIKE_ONE_STATUS(data)
  local list = self:getControl("ListView")
  local items = list:getItems()
  for _, item in pairs(items) do
    if item.data and item.data.sid == data.sid then
      self:setImage("LikeIconImage", ResMgr.ui.likeImage, item)
      break
    end
  end
  if self.curListViewName == "UnReadListView" then
    local list = self:getControl("UnReadListView")
    local items = list:getItems()
    for _, item in pairs(items) do
      if item.data and item.data.sid == data.sid then
        self:setImage("LikeIconImage", ResMgr.ui.likeImage, item)
        break
      end
    end
  end
  if not DlgMgr:isDlgOpened("BlogCircleDlg") or self.name == "BlogCircleDlg" then
    gf:showTipAndMisMsg(CHS[5420322])
  end
end
function BlogCircleDlg:MSG_BLOG_STATUS_LIST_ABOUNT_ME(data)
  if data.uid ~= BlogMgr:getBlogGidByDlgName(self.name) then
    return
  end
  local listName = "UnReadListView"
  local list = self:getControl(listName)
  local loadingPanel = list:getChildByName("LoadingPanel")
  list:removeChild(loadingPanel)
  list:refreshView()
  local items = list:getItems()
  if #items == 0 then
    self:setFriendsDynamics(data)
  elseif data.count == 0 then
    gf:ShowSmallTips(CHS[4200456])
  else
    self:loadFriendsDynamics(data)
  end
  list:refreshView()
  self.isNewquery = false
  self.lastCheckBoxState = self:isCheck("MineCheckBox")
end
function BlogCircleDlg:onUnReadNotePanel()
  self.isNewquery = false
  self:setCtrlVisible("ListView", false)
  self:setCtrlVisible("UnReadListView", true)
  self:setCtrlVisible("TouchPanel", false)
  self:setCtrlVisible("UnReadTouchPanel", true)
  self:resetListView("UnReadListView")
  self.curListViewName = "UnReadListView"
  self.root:stopAction(self.delayRequest)
  BlogMgr:queryUnReadStatusList()
  BlogMgr.unReadStatueCount = 0
  self:setCtrlVisible("NoticePanel", false)
  self:setLabelText("InfoLabel1", CHS[5420237], "NoticePanel")
  self.isUnReadView = true
  self:setCtrlVisible("OutPanel2", true)
  self:setCtrlVisible("OutPanel", false)
  self:setCtrlVisible("UnReadNotePanel", false)
end
function BlogCircleDlg:onBackButton()
  self:setCtrlVisible("ListView", true)
  self:setCtrlVisible("UnReadListView", false)
  self:setCtrlVisible("TouchPanel", true)
  self:setCtrlVisible("UnReadTouchPanel", false)
  self.curListViewName = "ListView"
  self.root:stopAction(self.delayRequest)
  local list = self:getControl("ListView")
  local items = list:getItems()
  if #items <= 0 then
    self:setCtrlVisible("NoticePanel", true)
  else
    self:setCtrlVisible("NoticePanel", false)
  end
  self:setLabelText("InfoLabel1", CHS[5420238], "NoticePanel")
  self.isUnReadView = false
  self:setCtrlVisible("OutPanel2", false)
  self:setCtrlVisible("OutPanel", true)
end
function BlogCircleDlg:MSG_BLOG_STATUS_NUM_ABOUT_ME(data)
  if data.count > 0 and BlogMgr:isMySelf(self.name) then
    self:setLabelText("UnReadNoteLabel", string.format(CHS[5420233], data.count))
    self:setCtrlVisible("UnReadNotePanel", true)
    BlogMgr:setHasMailRedDotForCircle(nil)
  else
    self:setCtrlVisible("UnReadNotePanel", false)
  end
end
function BlogCircleDlg:MSG_BLOG_DELETE_ONE_STATUS(data)
  local list = self:getControl("ListView")
  local items = list:getItems()
  for _, panel in pairs(items) do
    if panel.data and data.sid == panel.data.sid then
      list:removeChild(panel)
    end
  end
  list:requestRefreshView()
  items = list:getItems()
  if #items <= 0 and self.curListViewName ~= "UnReadListView" then
    self:setCtrlVisible("NoticePanel", true)
  else
    self:setCtrlVisible("NoticePanel", false)
  end
  if self.curListViewName ~= "UnReadListView" then
    return
  end
  local list = self:getControl("UnReadListView")
  local items = list:getItems()
  for _, panel in pairs(items) do
    if panel.data and data.sid == panel.data.sid then
      list:removeChild(panel)
    end
  end
  list:requestRefreshView()
  items = list:getItems()
  if #items <= 0 and self.curListViewName ~= "ListView" then
    self:setCtrlVisible("NoticePanel", true)
  else
    self:setCtrlVisible("NoticePanel", false)
  end
end
function BlogCircleDlg:MSG_BLOG_ALL_COMMENT_LIST(data)
  local list = self:getControl("ListView")
  local items = list:getItems()
  for _, panel in pairs(items) do
    if data.sid == panel.data.sid then
      panel.isExpand = 1
      self:setUnitDynamicsForTalk(data, panel)
      self:setAutoSize(panel)
    end
  end
  list:requestRefreshView()
end
function BlogCircleDlg:MSG_CHAR_INFO_EX(data)
  if self.selectCharGid ~= data.gid then
    return
  end
  local dlg = DlgMgr:openDlg("CharMenuContentDlg")
  if FriendMgr:isKuafDist(data.dist_name) then
    dlg:setMuneType(CHAR_MUNE_TYPE.KUAFU_BLOG)
  end
  dlg:setting(data.id)
  dlg:setInfo(data)
end
function BlogCircleDlg:MSG_OFFLINE_CHAR_INFO(data)
  self:MSG_CHAR_INFO_EX(data)
end
function BlogCircleDlg:MSG_CROSS_SERVER_CHAR_INFO(data)
  self:MSG_CHAR_INFO_EX(data)
end
function BlogCircleDlg:sharePic(data)
  self:onWriteButton()
  DlgMgr:sendMsg("BlogStateDlg", "onDlgOpened", {
    "shareImage",
    data.fileName
  })
end
function BlogCircleDlg:bindTouchEndEventListenerBlog(ctrl, func, data)
  if not ctrl then
    Log:W("Dialog:bindTouchEndEventListenerBlog no control ")
    return
  end
  local ctrlName = ctrl:getName()
  local function listener(sender, eventType)
    local str = self.name .. ":" .. tostring(ctrlName) .. " receive event:" .. tostring(eventType)
    Log:I(str)
    func(self, sender, eventType, data)
  end
  ctrl:addTouchEventListener(listener)
end
function BlogCircleDlg:setUnitText(panel, data)
  local text = data.text
  if string.match(text, "{\t.*\t}") then
    local title, articleId, comment = string.match(text, "{\t(.*)\027(.*)\027(.*)\t}")
    text = gf:filtTextByTwo(comment or "", nil, true)
    local shequPanel = self:getControl("SheQuPanel", nil, panel)
    shequPanel:setVisible(true)
    shequPanel.articleId = articleId
    if gf:getTextLength(title) > 88 then
      title = gf:subString(title, 86) .. "..."
    end
    Dialog.setColorText(self, title, "TitlePanel", shequPanel, nil, nil, nil, 17, nil, nil, data.insider >= 1)
  else
    self:setCtrlVisible("SheQuPanel", false, panel)
  end
  local text = gf:filtTextByTwo(text, nil, true)
  self:setColorText(text, "TextPanel", panel, nil, nil, nil, 19, nil, nil, data.insider >= 1)
end
function BlogCircleDlg:setColorText(str, panelName, root, marginX, marginY, defColor, fontSize, inCenter, isPunct, isVip)
  marginX = marginX or 0
  marginY = marginY or 0
  root = root or self.root
  fontSize = fontSize or 20
  defColor = defColor or COLOR3.TEXT_DEFAULT
  local panel
  if type(panelName) == "string" then
    panel = self:getControl(panelName, Const.UIPanel, root)
  else
    panel = panelName
  end
  panel:removeChildByName("CGAColorTextList")
  local size = panel:getContentSize()
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(fontSize)
  textCtrl:setString(str, isVip)
  textCtrl:setContentSize(size.width - 2 * marginX, 0)
  textCtrl:setDefaultColor(defColor.r, defColor.g, defColor.b)
  if textCtrl.setPunctTypesetting then
    textCtrl:setPunctTypesetting(true == isPunct)
  end
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  if inCenter then
    textCtrl:setPosition((size.width - textW) / 2, textH + marginY)
  else
    textCtrl:setPosition(marginX, textH + marginY)
  end
  local textPanel = tolua.cast(textCtrl, "cc.LayerColor")
  textPanel:setName("CGAColorTextList")
  panel:addChild(textPanel)
  local panelHeight = textH + 2 * marginY
  panel:setContentSize(size.width, panelHeight)
  return panelHeight, size.height
end
function BlogCircleDlg:MSG_BLOG_DELETE_ALL_COMMENT_AND_MESSAGE(data)
  local viewType = self:isCheck("MineCheckBox") and 1 or 0
  BlogMgr:queryBlogsList(BlogMgr:getUserGid(self.name), nil, viewType)
end
return BlogCircleDlg
