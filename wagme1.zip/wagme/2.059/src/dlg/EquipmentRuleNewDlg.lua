local EquipmentRuleNewDlg = Singleton("EquipmentRuleNewDlg", Dialog)
local MENU_BIG_CLASS = {
  CHS[4200598],
  CHS[4200599],
  CHS[4200597],
  CHS[4200594],
  CHS[4200592],
  CHS[4200596],
  CHS[4200591]
}
local MENU_SMALL_CLASS = {
  [CHS[4200594]] = {
    CHS[4200594],
    CHS[4200600],
    CHS[4200601],
    CHS[4200602]
  },
  [CHS[4200592]] = {
    CHS[4200592],
    CHS[4200595],
    CHS[4200593]
  },
  [CHS[4200591]] = {
    CHS[4200591],
    CHS[4200603]
  }
}
local BIG_MENU_DLG = {
  [CHS[4200598]] = "EquipmentRuleNewFirstPageDlg",
  [CHS[4200599]] = "EquipmentRuleNewSplitDlg",
  [CHS[4200597]] = "EquipmentRuleNewReformDlg",
  [CHS[4200596]] = "EquipmentRuleNewSuitDlg"
}
local SMALL_MENU_DLG = {
  [CHS[4200594]] = "EquipmentRuleNewRefiningDlg",
  [CHS[4200600]] = "EquipmentRuleNewRefiningPinkDlg",
  [CHS[4200601]] = "EquipmentRuleNewRefiningYellowDlg",
  [CHS[4200602]] = "EquipmentRuleNewStrengthenDlg",
  [CHS[4200592]] = "EquipmentRuleNewUpgradeDlg",
  [CHS[4200595]] = "EquipmentRuleNewGongmingDlg",
  [CHS[4200593]] = "EquipmentRuleNewInheritDlg",
  [CHS[4200591]] = "EquipmentRuleNewEvovleDlg",
  [CHS[4200603]] = "EquipmentRuleNewDegenerationDlg"
}
function EquipmentRuleNewDlg:init(data)
  self.bigMenuPanel = self:retainCtrl("BigPanel")
  self.smallMenuPanel = self:retainCtrl("SPanel")
  self.relationDlgName = nil
  self:setMenuList("CategoryListView", self:getBigMenus(), self.bigMenuPanel, MENU_SMALL_CLASS, self.smallMenuPanel, self.onClickBigMenu, self.onClickSmallMenu, data)
end
function EquipmentRuleNewDlg:getBigMenus()
  local menus = {}
  table.insert(menus, CHS[4200598])
  if Me:queryBasicInt("level") >= 50 then
    table.insert(menus, CHS[4200599])
  end
  if Me:queryBasicInt("level") >= 50 then
    table.insert(menus, CHS[4200597])
  end
  if Me:queryBasicInt("level") >= 50 then
    table.insert(menus, CHS[4200594])
  end
  if Me:queryBasicInt("level") >= 40 then
    table.insert(menus, CHS[4200592])
  end
  if Me:queryBasicInt("level") >= 70 then
    table.insert(menus, CHS[4200596])
  end
  if Me:queryBasicInt("level") >= 70 then
    table.insert(menus, CHS[4200591])
  end
  return menus
end
function EquipmentRuleNewDlg:onClickBigMenu(sender, isDef)
  self:closeChildDlg()
  local dlgName = BIG_MENU_DLG[sender:getName()]
  if dlgName then
    self.childDlg = DlgMgr:openDlg(dlgName)
    self.relationDlgName = dlgName
  end
end
function EquipmentRuleNewDlg:onClickSmallMenu(sender, isDef)
  self:closeChildDlg()
  local dlgName = SMALL_MENU_DLG[sender:getName()]
  if dlgName then
    performWithDelay(self.root, function()
      self.childDlg = DlgMgr:openDlg(dlgName)
      self.relationDlgName = dlgName
    end)
  end
end
function EquipmentRuleNewDlg:closeChildDlg()
  if self.relationDlgName then
    DlgMgr:closeDlg(self.relationDlgName)
    self.relationDlgName = nil
    self.childDlg = nil
  end
end
function EquipmentRuleNewDlg:onGotoMenu(menuName, smallMenu)
  local data = {
    one = menuName,
    two = smallMenu,
    isScrollToDef = true
  }
  self:setMenuList("CategoryListView", self:getBigMenus(), self.bigMenuPanel, MENU_SMALL_CLASS, self.smallMenuPanel, self.onClickBigMenu, self.onClickSmallMenu, data)
end
function EquipmentRuleNewDlg:cleanup()
  self:closeChildDlg()
end
return EquipmentRuleNewDlg
