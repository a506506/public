local EquipXiangXingGuideDlg = Singleton("EquipXiangXingGuideDlg", Dialog)
function EquipXiangXingGuideDlg:init()
end
return EquipXiangXingGuideDlg
