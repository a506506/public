local BangpyhDlg = Singleton("BangpyhDlg", Dialog)
local POSITION_NUM = {
  [1] = {71},
  [2] = {41, 101},
  [3] = {
    11,
    71,
    131
  }
}
local openRuleTime = {}
function BangpyhDlg:init(data)
  self:setFullScreen()
  self:bindListener("InforButton", self.onInforButton)
  self:bindListener("OpenButton", self.onOpenButton)
  self:bindListener("HideButton", self.onHideButton)
  self:bindListener("LeaveButton", self.onLeaveButton)
  for i = 1, 3 do
    self:bindListener("TypeImage_" .. i, self.onMartail)
  end
  self:onOpenButton(self:getControl("OpenButton"))
  self:setLabelText("TimeLabel", "")
  self:setLabelText("CorrectNumLabel", "")
  self:setLabelText("ErrorNumLabel", "")
  DlgMgr:closeDlg("ChannelDlg")
  DlgMgr:closeDlg("FriendDlg")
  self:setCooking(data)
  self:setTitleInfo(data)
  if not openRuleTime.meGid or openRuleTime.meGid ~= Me:queryBasic("gid") or not gf:isSameDay5(openRuleTime.openGzTime, gf:getServerTime()) then
    openRuleTime.meGid = Me:queryBasic("gid")
    openRuleTime.openGzTime = gf:getServerTime()
    DlgMgr:openDlg("BangpyhgzDlg")
  end
  self:hookMsg("MSG_PARTY_BPYH_INFO")
  DlgMgr:sendMsg("HeadDlg", "setVisible", true)
end
function BangpyhDlg:setTitleInfo(data)
  self:stopSchedule(self.timer)
  if data.dishNo == 0 then
    self:setLabelText("TextLabel", CHS[4010480])
    local h = tonumber(gf:getServerDate("%H", data.endTime))
    local m = tonumber(gf:getServerDate("%M", data.endTime))
    self:setCtrlVisible("TimeLabel2", true, "TitlePanel")
    self:setCtrlVisible("BK2Image", false, "TitlePanel")
    self:setCtrlVisible("TimeLabel", false, "TitlePanel")
    self:setLabelText("TimeLabel2", string.format("%02d:%02d开启", h, m))
  else
    self:setCtrlVisible("TimeLabel2", false, "TitlePanel")
    self:setCtrlVisible("BK2Image", true, "TitlePanel")
    self:setCtrlVisible("TimeLabel", true, "TitlePanel")
    self:setLabelText("TextLabel", string.format(CHS[4010482], data.dishNo))
    do
      local limitTime = data.endTime
      local lTime = limitTime - gf:getServerTime()
      local m = math.floor(lTime / 60)
      local s = lTime % 60
      self:setLabelText("TimeLabel", string.format("%02d:%02d", m, s))
      self.timer = self:startSchedule(function()
        local lTime = limitTime - gf:getServerTime()
        local m = math.floor(lTime / 60)
        local s = lTime % 60
        if lTime <= 10 then
          self:setLabelText("TimeLabel", string.format("%02d:%02d", m, s), nil, COLOR3.RED)
          if lTime == 10 then
            gf:showTipAndMisMsg(string.format(CHS[7100836], data.dishName))
          end
        else
          self:setLabelText("TimeLabel", string.format("%02d:%02d", m, s), nil, COLOR3.WHITE)
        end
      end, 1)
    end
  end
end
function BangpyhDlg:setCooking(data)
  self:setLabelText("CheckpointLabel", data.dishName)
  self:setImage("TypeImage", PartyMgr:getBpyhDishIcon(data.dishName), "DishPanel")
  for i = 1, 3 do
    self:setCtrlVisible("TypePanel" .. i, false)
  end
  for i = 1, data.count do
    local image = self:setImage("TypeImage_" .. i, PartyMgr:getBpyhItemIconPath(data.material[i]))
    image.name = data.material[i]
    self:setCtrlVisible("TypeImage_" .. i, true)
    self:setCtrlVisible("TypePanel" .. i, true)
  end
  self:refreshMaterialHaveNum()
  if data.count == 1 then
    self:getControl("TypePanel1"):setPositionX(POSITION_NUM[1][1])
  elseif data.count == 2 then
    self:getControl("TypePanel1"):setPositionX(POSITION_NUM[2][1])
    self:getControl("TypePanel2"):setPositionX(POSITION_NUM[2][2])
  else
    self:getControl("TypePanel1"):setPositionX(POSITION_NUM[3][1])
    self:getControl("TypePanel2"):setPositionX(POSITION_NUM[3][2])
    self:getControl("TypePanel3"):setPositionX(POSITION_NUM[3][3])
  end
  self:setMaterialNumEffect(self:getControl("CorrectNumLabel"), data.correct)
  self:setMaterialNumEffect(self:getControl("ErrorNumLabel"), data.error)
  self:setLabelText("QualityLabel", string.format(CHS[4010486], data.quality))
end
function BangpyhDlg:setMaterialNumEffect(label, newNum)
  label:stopAllActions()
  local curText = label:getString()
  if string.isNilOrEmpty(curText) then
    label:setString(newNum)
    return
  end
  local curNum = tonumber(curText)
  if newNum <= curNum then
    label:setString(newNum)
    return
  end
  schedule(label, function()
    if curNum < newNum then
      curNum = curNum + 1
      label:setString(curNum)
    else
      label:stopAllActions()
    end
  end, 0.1)
end
function BangpyhDlg:refreshMaterialHaveNum()
  for i = 1, 3 do
    local image = self:getControl("TypeImage_" .. i)
    local materialInfo = PartyMgr:getBpyhMaterialInfoByName(image.name)
    if materialInfo then
      self:setNumImgForPanel("TypePanel" .. i, ART_FONT_COLOR.DEFAULT, materialInfo.amount, false, LOCATE_POSITION.RIGHT_BOTTOM, 15)
    else
      self:removeNumImgForPanel("TypePanel" .. i, LOCATE_POSITION.RIGHT_BOTTOM)
    end
  end
end
function BangpyhDlg:onInforButton(sender, eventType)
  DlgMgr:openDlg("BangpyhgzDlg")
end
function BangpyhDlg:onMartail(sender, eventType)
  gf:showTipInfo(sender.name, sender)
end
function BangpyhDlg:onLeaveButton(sender, eventType)
  gf:CmdToServer("CMD_LEAVE_ROOM", {type = "party_bpyh", extra = ""})
end
function BangpyhDlg:onHideButton(sender, eventType)
  self:setCtrlVisible("InforPanel", false)
  sender:setVisible(false)
  self:setCtrlVisible("OpenButton", true)
end
function BangpyhDlg:onOpenButton(sender, eventType)
  self:setCtrlVisible("InforPanel", true)
  sender:setVisible(false)
  self:setCtrlVisible("HideButton", true)
end
function BangpyhDlg:MSG_PARTY_BPYH_INFO(data)
  self:setCooking(data)
  self:setTitleInfo(data)
end
return BangpyhDlg
