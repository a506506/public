local ActivitiesDlg = Singleton("ActivitiesDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
local LINE_SAPCE = 0
local SCROLLVIEW_CHILD_TAG = 999
local COLUNM = 2
ActivitiesDlg.dailyCells = {}
local CHECKBOX_TO_REWARD_TYPE = {
  ExpCheckBox = ACTIVITY_REWARD_TYPE.EXP,
  DaowuCheckBox = ACTIVITY_REWARD_TYPE.TAO_AND_MARTIAL,
  ItemCheckBox = ACTIVITY_REWARD_TYPE.ITEM,
  EquipmentCheckBox = ACTIVITY_REWARD_TYPE.EQUIP
}
function ActivitiesDlg:init()
  self:bindListener("StatisticsButton", self.OnStatisticsButton)
  self:bindListener("PushButton", self.onPushButton)
  self:bindListener("WeekCalendarButton", self.onWeekCalendarButton)
  self.rewardTypeGroup = RadioGroup.new()
  self.rewardTypeGroup:setItems(self, {
    "WholeCheckBox",
    "ExpCheckBox",
    "DaowuCheckBox",
    "ItemCheckBox",
    "EquipmentCheckBox"
  }, self.onRewardTypeCheckBox)
  self.dailyCell = self:getControl("DailyListViewPanel_1", Const.UIPanel)
  self.dailyCell:retain()
  self.activityTable = {}
  self.radioGroup = RadioGroup.new()
  self.radioGroup:setItems(self, {
    "DailyCheckBox",
    "LimitedCheckBox",
    "FestivalCheckBox",
    "WelfareCheckBox",
    "ComingCheckBox",
    "OtherCheckBox"
  }, self.OnSiwchTab)
  self.positionYList = {}
  local tabPanel = self:getControl("TabPanel")
  for i = 1, 6 do
    self.positionYList[i] = tabPanel:getChildByTag(i):getPositionY()
  end
  self:hookMsg("MSG_LIVENESS_INFO")
  self:hookMsg("MSG_LIVENESS_REWARDS")
  self:hookMsg("MSG_GENERAL_NOTIFY")
  ActivityMgr:CMD_ACTIVITY_LIST()
  ActivityMgr:getActiviInfo()
  self.radioGroup:selectRadio(1, self.OnSiwchTab)
  self.curBoxName = "DailyCheckBox"
  self:initTab()
  self.rewardTypeGroup:selectRadio(1, self.onRewardTypeCheckBox)
  self:MSG_LIVENESS_INFO()
  self.hasNotReceiveMsg = true
  self.initDoneWithMsg = false
  if Me:queryBasicInt("level") >= 100 and TaskMgr.baijiTaskStatus == nil then
    TaskMgr:requestBaijiTask()
  end
end
function ActivitiesDlg:MSG_GENERAL_NOTIFY(data)
  if NOTIFY.NOTIFY_SEND_INIT_DATA_DONE == data.notify then
    if self.hasNotReceiveMsg then
      ActivityMgr:CMD_ACTIVITY_LIST()
      ActivityMgr:getActiviInfo()
    end
    if Me:queryBasicInt("level") >= 100 and TaskMgr.baijiTaskStatus == nil then
      TaskMgr:requestBaijiTask()
    end
  end
end
function ActivitiesDlg:initTab()
  local positionYList = self.positionYList
  local tabPanel = self:getControl("TabPanel")
  local dataList = {}
  dataList[1] = ActivityMgr:getDailyActivity()
  dataList[2] = ActivityMgr:getLimitActivity()
  dataList[3] = ActivityMgr:getFestivalActivity()
  dataList[4] = ActivityMgr:getWelfareActivity()
  dataList[5] = ActivityMgr:getComingActivity()
  dataList[6] = ActivityMgr:getOhterActivityData()
  local showTabList = {}
  for i = 1, 6 do
    if #dataList[i] == 0 then
      tabPanel:getChildByTag(i):setVisible(false)
    else
      table.insert(showTabList, tabPanel:getChildByTag(i))
      tabPanel:getChildByTag(i):setVisible(true)
    end
  end
  for i = 1, #showTabList do
    showTabList[i]:setPositionY(positionYList[i])
  end
end
function ActivitiesDlg:MSG_LIVENESS_INFO(data)
  self.hasNotReceiveMsg = false
  self.activityTable = {}
  self:initTab()
  self:setActivityTabData(self.curBoxName, self.curRewardType)
  self.activityTable[self.curBoxName]:setVisible(true)
  self:initRewardPanel()
  if data then
    self.initDoneWithMsg = true
  end
end
function ActivitiesDlg:MSG_LIVENESS_REWARDS()
  local rewardStatusTable = ActivityMgr:getRewardStatus() or {}
  local reward = ActivityMgr:getActivityReward()
  for i = 1, #reward do
    local rewardPanel = self:getControl(string.format("RewardPanel%d", i), Const.UIPanel)
    local rewardItemPanel = self:getControl("RewardItemPanel", Const.UIPanel, rewardPanel)
    local key = reward[i].activity
    if rewardStatusTable[key] and rewardStatusTable[key].status == 1 then
      self:setCtrlVisible("CoverImage", true, rewardPanel)
      self:removeMagic(rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
    elseif rewardStatusTable[key] and rewardStatusTable[key].status == 2 then
      self:setCtrlVisible("CoverImage", false, rewardPanel)
      gf:createArmatureMagic(ResMgr.ArmatureMagic.item_around, rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
    else
      self:setCtrlVisible("CoverImage", false, rewardPanel)
      self:removeMagic(rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
    end
  end
end
function ActivitiesDlg:OnStatisticsButton(sender, eventType)
  if not DlgMgr.statisticsDlgRect then
    DlgMgr.statisticsDlgRect = self:getBoundingBoxInWorldSpace(sender)
  end
  if self:isOutLimitTime("requestLast", 3000) or not DlgMgr.dailyStats then
    self:setLastOperTime("requestLast", gfGetTickCount())
    gf:CmdToServer("CMD_REQUEST_DAILY_STATS", {})
  else
    DlgMgr:MSG_DAILY_STATS(DlgMgr.dailyStats)
  end
end
function ActivitiesDlg:onPushButton(sender, eventType)
  DlgMgr:openDlg("SystemPushDlg")
end
function ActivitiesDlg:onWeekCalendarButton(sender, eventType)
  DlgMgr:openDlg("ActivitiesWeekCalendarDlg")
end
function ActivitiesDlg:onRewardTypeCheckBox(sender, eventType)
  local name = sender:getName()
  if name == self.curRewardType then
    return
  end
  self.curRewardType = CHECKBOX_TO_REWARD_TYPE[sender:getName()]
  self:setActivityTabData(self.curBoxName, self.curRewardType)
  self.activityTable[self.curBoxName]:setVisible(true)
end
function ActivitiesDlg:OnSiwchTab(sender, eventType)
  local name = sender:getName()
  if name == self.curBoxName then
    return
  end
  self.curBoxName = name
  for k, v in pairs(self.activityTable) do
    if v then
      v:setVisible(false)
    end
  end
  self:setActivityTabData(name, self.curRewardType)
  self.activityTable[name]:setVisible(true)
end
function ActivitiesDlg:setActivityTabData(name, rewardType)
  local scrollview
  local dataTable = {}
  local func, cell
  if name == "DailyCheckBox" then
    scrollview = self:getControl("DailyScrollView", Const.UIScrollView)
    dataTable = ActivityMgr:getDailyActivity(rewardType)
    func = self.setDailyCellInfo
    self.activityTable[name] = self:getControl("DailyPanel", Const.UIPanel)
  elseif name == "LimitedCheckBox" then
    scrollview = self:getControl("LimitedScrollView", Const.UIScrollView)
    dataTable = ActivityMgr:getLimitActivity(nil, nil, rewardType)
    func = self.setLimitCellInfo
    self.activityTable[name] = self:getControl("LimitedPanel", Const.UIPanel)
  elseif name == "FestivalCheckBox" then
    scrollview = self:getControl("FestivalScrollView", Const.UIScrollView)
    dataTable = ActivityMgr:getFestivalActivity(nil, rewardType)
    func = self.setFestivalCellInfo
    self.activityTable[name] = self:getControl("FestivalPanel", Const.UIPanel)
  elseif name == "WelfareCheckBox" then
    scrollview = self:getControl("WelfareScrollView", Const.UIScrollView)
    dataTable = ActivityMgr:getWelfareActivity(rewardType)
    func = self.setWelfareCellInfo
    self.activityTable[name] = self:getControl("WelfarePanel", Const.UIPanel)
  elseif name == "ComingCheckBox" then
    scrollview = self:getControl("ComingScrollView", Const.UIScrollView)
    dataTable = ActivityMgr:getComingActivity(rewardType)
    func = self.setComingCellInfo
    self.activityTable[name] = self:getControl("ComingPanel", Const.UIPanel)
  elseif name == "OtherCheckBox" then
    scrollview = self:getControl("OtherScrollView", Const.UIScrollView)
    dataTable = ActivityMgr:getOhterActivityData(rewardType)
    func = self.setOtherCellInfo
    self.activityTable[name] = self:getControl("OtherPanel", Const.UIPanel)
  end
  dataTable = self:filterLevel(dataTable)
  self:initScrollview(dataTable, scrollview, func, COLUNM)
end
function ActivitiesDlg:filterLevel(dataTable)
  local ret = {}
  for _, act in pairs(dataTable) do
    if act.showLevel and Me:queryBasicInt("level") < act.showLevel then
    else
      table.insert(ret, act)
    end
  end
  return ret
end
function ActivitiesDlg:removeDailyCellsFromParent(name)
  if not self.dailyCells then
    self.dailyCells = {}
  end
  if not self.dailyCells[name] then
    self.dailyCells[name] = {}
  end
  for key, value in pairs(self.dailyCells[name]) do
    self.dailyCells[name][key]:removeFromParent()
  end
end
function ActivitiesDlg:getDailyCellByTag(name, tag)
  if not self.dailyCells[name][tag] then
    self.dailyCells[name][tag] = self.dailyCell:clone()
    self.dailyCells[name][tag]:retain()
    return self.dailyCells[name][tag], false
  else
    return self.dailyCells[name][tag], true
  end
end
function ActivitiesDlg:initScrollview(data, scrollview, func, colunm)
  self:removeDailyCellsFromParent(self.curBoxName)
  scrollview:removeAllChildren()
  local contentLayer = ccui.Layout:create()
  local line = math.floor(#data / colunm)
  local left = #data % colunm
  if left ~= 0 then
    line = line + 1
  end
  local curColunm = 0
  local totalHeight = line * (self.dailyCell:getContentSize().height + LINE_SAPCE) - LINE_SAPCE
  for i = 1, line do
    if i == line and left ~= 0 then
      curColunm = left
    else
      curColunm = colunm
    end
    for j = 1, curColunm do
      local index = j + (i - 1) * colunm
      local tag = data[index].index
      local cell, initDone = self:getDailyCellByTag(self.curBoxName, tag)
      cell:setAnchorPoint(0, 1)
      local x = (j - 1) * self.dailyCell:getContentSize().width
      local y = totalHeight - (i - 1) * (self.dailyCell:getContentSize().height + LINE_SAPCE)
      cell:setPosition(x, y)
      cell:setTag(tag)
      contentLayer:addChild(cell)
      if not initDone or not self.initDoneWithMsg then
        func(self, cell, data[index])
      end
    end
  end
  contentLayer:setContentSize(scrollview:getContentSize().width, totalHeight)
  if totalHeight < scrollview:getContentSize().height then
    contentLayer:setPositionY(scrollview:getContentSize().height - totalHeight)
  end
  scrollview:addChild(contentLayer, 1, SCROLLVIEW_CHILD_TAG)
  scrollview:setInnerContainerSize(contentLayer:getContentSize())
end
function ActivitiesDlg:setDailyCellInfo(cell, data)
  self:setCellInfo(cell, data)
  local gotoBtn = self:getControl("GoButton", Const.UIButton, cell)
  local statusImage = self:getControl("StatusImage", Const.UIImage, cell)
  gotoBtn:setVisible(false)
  statusImage:setVisible(false)
  local dataTemp = data
  if dataTemp.name == CHS[3002189] then
    self:setLabelText("Label_1", CHS[3002190], gotoBtn)
    self:setLabelText("Label_2", CHS[3002190], gotoBtn)
    gotoBtn:setVisible(true)
  elseif dataTemp.times == 0 then
    gotoBtn:setVisible(true)
  elseif ActivityMgr:isFinishActivity(dataTemp) or dataTemp.name == CHS[5400835] and Me:queryBasicInt("digong/yangqi") == 0 then
    statusImage:setVisible(true)
  else
    gotoBtn:setVisible(true)
  end
end
function ActivitiesDlg:setOtherCellInfo(cell, data)
  self:setCellInfo(cell, data)
  local activiteTimePanel = self:getControl("ActiveTimePanel", Const.UIPanel, cell)
  local timeLabel = self:getControl("TimeLabel", Const.UILabel, activiteTimePanel, cell)
  local leftLabel = self:getControl("LeftTimeValueLabel", Const.UILabel, cell)
  local gotoBtn = self:getControl("GoButton", Const.UIButton, cell)
  local statusImage = self:getControl("StatusImage", Const.UIImage, cell)
  activiteTimePanel:setVisible(false)
  timeLabel:setVisible(false)
  leftLabel:setVisible(false)
  gotoBtn:setVisible(false)
  statusImage:setVisible(false)
  if data.name == CHS[3002191] then
    gotoBtn:setVisible(true)
    self:setLabelText("Label_1", CHS[3002190], gotoBtn)
    self:setLabelText("Label_2", CHS[3002190], gotoBtn)
    timeLabel:setString(ActivityMgr:getDayText(data) .. ActivityMgr:getTimeText(data))
    timeLabel:setVisible(true)
  elseif data.times == 0 then
    gotoBtn:setVisible(true)
  elseif ActivityMgr:isFinishActivity(data) then
    statusImage:setVisible(true)
  elseif data.name == CHS[6000108] or data.name == CHS[6000109] or data.name == CHS[6400005] or data.name == CHS[4010374] then
    activiteTimePanel:setVisible(true)
    timeLabel:setString(ActivityMgr:getDayText(data) .. ActivityMgr:getTimeText(data))
    timeLabel:setVisible(true)
  else
    gotoBtn:setVisible(true)
  end
end
function ActivitiesDlg:setLimitCellInfo(cell, data)
  local tempData
  if data.actitiveDate == "10" then
    self:setDailyCellInfo(cell, data)
    return
  end
  if ActivityMgr:isWeekActivity(data.name) and data.actitiveDate ~= "" and ActivityMgr:isWeekActivityFinish(data) then
    tempData = gf:deepCopy(data)
    tempData.name = CHS[7001059]
  end
  self:setCellInfo(cell, tempData or data)
  local activiteTimePanel = self:getControl("ActiveTimePanel", Const.UIPanel, cell)
  local timeLabel = self:getControl("TimeLabel", Const.UILabel, activiteTimePanel, cell)
  local leftTimeBKImage = self:getControl("LeftTimeBKImage", Const.UIImage, cell)
  local leftLabel = self:getControl("LeftTimeValueLabel", Const.UILabel, cell)
  local gotoBtn = self:getControl("GoButton", Const.UIButton, cell)
  local statusImage = self:getControl("StatusImage", Const.UIImage, cell)
  activiteTimePanel:setVisible(false)
  timeLabel:setVisible(false)
  leftTimeBKImage:setVisible(false)
  leftLabel:setVisible(false)
  gotoBtn:setVisible(false)
  statusImage:setVisible(false)
  local curActivetyTable = ActivityMgr:isCurActivity(data)
  local curActivity = data.activityTime[curActivetyTable[2]]
  if ActivityMgr:isFinishActivity(data) then
    statusImage:setVisible(true)
  elseif curActivetyTable[1] == false then
    activiteTimePanel:setVisible(true)
    local timeStr = ActivityMgr:getDayText(data) .. ActivityMgr:getTimeText(data)
    if data.name == CHS[3002192] then
      timeStr = CHS[3002193]
    end
    timeLabel:setString(timeStr)
    timeLabel:setVisible(true)
  else
    do
      local time = ActivityMgr:getLeftMin(curActivity)
      schedule(cell, function()
        if time == 0 then
          return
        end
        time = time - 1
        leftLabel:setString(string.format(CHS[6000116], time))
      end, 60)
      gotoBtn:setVisible(true)
      leftLabel:setVisible(true)
      leftTimeBKImage:setVisible(true)
      leftLabel:setString(string.format(CHS[6000116], time))
      if data.notShowLeftTime then
        leftLabel:setVisible(false)
        leftTimeBKImage:setVisible(false)
      end
    end
  end
end
function ActivitiesDlg:setComingCellInfo(cell, data)
  self:setCellInfo(cell, data)
  local activiteTimePanel = self:getControl("ActiveTimePanel", Const.UIPanel, cell)
  local timeLabel = self:getControl("TimeLabel", Const.UILabel, activiteTimePanel, cell)
  local leftTimeBKImage = self:getControl("LeftTimeBKImage", Const.UIImage, cell)
  leftTimeBKImage:setVisible(false)
  local gotoBtn = self:getControl("GoButton", Const.UIButton, cell)
  gotoBtn:setVisible(false)
  self:setCtrlVisible("ClockImage", false, activiteTimePanel)
  timeLabel:setString(string.format(CHS[6000117], data.level))
  timeLabel:setVisible(true)
  activiteTimePanel:setVisible(true)
end
function ActivitiesDlg:setFestivalCellInfo(cell, data)
  local gotoBtn = self:getControl("GoButton", Const.UIButton, cell)
  local activiteTimePanel = self:getControl("ActiveTimePanel", Const.UIPanel, cell)
  gotoBtn:setVisible(false)
  activiteTimePanel:setVisible(false)
  if ActivityMgr:isFestivalStart(data.activityTime[1][1]) then
    if data.name == CHS[6200075] then
      if data.goingTime and ActivityMgr:getActivityIsCurTime(data.goingTime, ActivityMgr:getActivityNewTime(data.name)) then
        self:setDailyCellInfo(cell, data)
      else
        self:setCellInfo(cell, data)
        self:setLabelText("Label_1", CHS[3002190], gotoBtn)
        self:setLabelText("Label_2", CHS[3002190], gotoBtn)
        gotoBtn:setVisible(true)
      end
    elseif data.name == CHS[7002140] then
      self:setCellInfo(cell, data)
      self:setLabelText("Label_1", CHS[3002190], gotoBtn)
      self:setLabelText("Label_2", CHS[3002190], gotoBtn)
      gotoBtn:setVisible(true)
    elseif data.name == CHS[7002097] then
      do
        local function func()
          if data.goingTime and ActivityMgr:getActivityIsCurTime(data.goingTime, ActivityMgr:getActivityNewTime(data.name)) then
            self:setDailyCellInfo(cell, data)
          else
            self:setCellInfo(cell, data)
            local timeLabel = self:getControl("TimeLabel", Const.UILabel, activiteTimePanel, cell)
            activiteTimePanel:setVisible(true)
            local nextTimeStr
            local time = gf:getServerTime()
            local timeList = gf:getServerDate("*t", time)
            if timeList.hour == 23 then
              nextTimeStr = "00:00"
            else
              nextTimeStr = ActivityMgr:getNearlyTime({
                activityTime = data.goingTime
              })
            end
            timeLabel:setString(nextTimeStr .. CHS[4000269])
          end
        end
        func()
        cell:stopAllActions()
        schedule(cell, function()
          func()
        end, 1)
      end
    else
      self:setDailyCellInfo(cell, data)
    end
  else
    self:setCellInfo(cell, data)
    local timeLabel = self:getControl("TimeLabel", Const.UILabel, activiteTimePanel, cell)
    activiteTimePanel:setVisible(true)
    self:setCtrlVisible("ClockImage", false, activiteTimePanel)
    timeLabel:setString(CHS[3004424])
  end
end
function ActivitiesDlg:setWelfareCellInfo(cell, data)
  local gotoBtn = self:getControl("GoButton", Const.UIButton, cell)
  local activiteTimePanel = self:getControl("ActiveTimePanel", Const.UIPanel, cell)
  gotoBtn:setVisible(false)
  activiteTimePanel:setVisible(false)
  if ActivityMgr:isFestivalStart(data.activityTime[1][1]) then
    if data.name == CHS[6200075] then
      if data.goingTime and ActivityMgr:getActivityIsCurTime(data.goingTime, ActivityMgr:getActivityNewTime(data.name)) then
        self:setDailyCellInfo(cell, data)
      else
        self:setCellInfo(cell, data)
        self:setLabelText("Label_1", CHS[3002190], gotoBtn)
        self:setLabelText("Label_2", CHS[3002190], gotoBtn)
        gotoBtn:setVisible(true)
      end
    else
      self:setDailyCellInfo(cell, data)
    end
  else
    self:setCellInfo(cell, data)
    local timeLabel = self:getControl("TimeLabel", Const.UILabel, activiteTimePanel, cell)
    activiteTimePanel:setVisible(true)
    self:setCtrlVisible("ClockImage", false, activiteTimePanel)
    timeLabel:setString(CHS[3004424])
  end
end
local touchCell = function(sender, eventType)
  local data = sender.data
  if not data then
    return
  end
  if ccui.TouchEventType.ended == eventType then
    if data and data.name and data.name == CHS[7001059] then
      gf:ShowSmallTips(CHS[7001060])
      return
    end
    local dlg = DlgMgr:openDlg("ActivitiesInfoFFDlg")
    dlg:setData(data, false)
  end
end
function ActivitiesDlg:setCellInfo(cell, data)
  cell.data = data
  local title = self:getControl("TitleLabel", Const.UILabel, cell)
  local name = data.name
  if data.showName then
    name = data.showName
  end
  if string.match(name, "Month") then
    local activityTime = ActivityMgr:getActivityStartTimeByMainType(data.mainType)
    local activityStartTime = activityTime.startTime
    local m = tonumber(gf:getServerDate("%m", activityStartTime - Const.FIVE_HOURS))
    local newActName = string.gsub(name, "Month", gf:changeNumber(m))
    title:setString(newActName)
  else
    title:setString(name)
  end
  local imagePanel = self:getControl("ImagePanel", Const.UIPanel, cell)
  local image = self:getControl("Image", Const.UIImage, imagePanel)
  self:setCtrlVisible("DoubleImage", ActivityMgr:isDoubleActive(data), cell)
  local path = ResMgr.ui.small_cash
  if data.name == CHS[6000255] or data.name == CHS[7000125] or data.name == CHS[2000192] or data.name == CHS[5420071] or data.name == CHS[7002160] or data.name == CHS[2200180] or data.name == CHS[5400063] then
    path = ResMgr:getItemIconPath(data.icon)
    image:loadTexture(path, ccui.TextureResType.localType)
    gf:setItemImageSize(image)
  elseif data.itemName then
    image:loadTexture(ResMgr:getItemIconPath(InventoryMgr:getIconByName(data.itemName)))
  elseif data.petIcon then
    image:loadTexture(ResMgr:getSmallPortrait(data.petIcon))
  elseif data.resType == 0 then
    image:loadTexture(data.icon, ccui.TextureResType.localType)
  else
    image:loadTexture(data.icon, ccui.TextureResType.plistType)
  end
  cell:addTouchEventListener(touchCell)
  local numberLabel = self:getControl("ProgressNumLabel", Const.UILabel, cell)
  if data.times == -1 then
    numberLabel:setString(CHS[6000115])
  elseif data.times == 0 then
    numberLabel:setVisible(false)
    self:setCtrlVisible("ActivityLabel", false, cell)
    self:setCtrlVisible("ProgressLabel", false, cell)
    self:setCtrlVisible("ActivityTextLabel", false, cell)
  else
    local thisTimes = ActivityMgr:getActivityCurTimes(data.name)
    if thisTimes > data.times then
      thisTimes = data.times
    end
    local maxTimes = data.times
    if data.newTimes then
      if data.effectTime and not DistMgr:curIsTestDist() and gf:getServerTime() >= data.effectTime then
        maxTimes = data.newTimes
      elseif data.effectTimeTest and DistMgr:curIsTestDist() and gf:getServerTime() >= data.effectTimeTest then
        maxTimes = data.newTimes
      end
    end
    if data.name == CHS[3002195] then
      numberLabel:setString(string.format("%d/%d", thisTimes, maxTimes + ActivityMgr.partyTaskAdd))
    else
      numberLabel:setString(string.format("%d/%d", thisTimes, maxTimes))
    end
  end
  local activityCurTimes = ActivityMgr:getActivityValue(data.name)
  if activityCurTimes > data.activeLimit then
    activityCurTimes = data.activeLimit
  end
  if 0 >= data.activeLimit then
    self:setLabelText("ActivityLabel", CHS[5000059], cell)
  else
    self:setLabelText("ActivityLabel", string.format("%d/%d", activityCurTimes, data.activeLimit), cell)
  end
  local gotoBtn = self:getControl("GoButton", Const.UIButton, cell)
  self:bindTouchEndEventListener(gotoBtn, self.gotoFunc, data)
  if data.name == CHS[6000106] then
    local rect = self:getBoundingBoxInWorldSpace(gotoBtn)
    self.rect = rect
  end
end
function ActivitiesDlg:gotoFunc(sender, type, data)
  if GMMgr:isStaticMode() then
    gf:ShowSmallTips(CHS[3002196])
    return
  end
  if Me:isInJail() then
    gf:ShowSmallTips(CHS[6000214])
    return
  elseif GameMgr.inCombat and self:getLabelText("Label_1", sender) == CHS[3002198] and not data.canGotoInCombat then
    gf:ShowSmallTips(CHS[3002197])
    return
  end
  if sender then
    sender.isRecordPlugOrder = true
    RecordLogMgr:isMeetPlugOrder("ActivitiesDlg_" .. data.name)
  end
  self:onGotoBtn(data)
  if self:getLabelText("Label_1", sender) == CHS[3002198] and not data.notClsoeDlgWhenGoto then
    self:onCloseButton()
  end
end
function ActivitiesDlg:onGotoBtn(data)
  if data.name == CHS[4100285] then
    local name = self.radioGroup:getSelectedRadioName()
    local actData
    actData = self:getActiveByName()
    if not actData then
      return
    end
    if Me:getLevel() < actData.level then
      gf:ShowSmallTips(string.format(CHS[4200167], actData.name, actData.level))
      return
    end
    self:onGotoBtn(actData)
  else
    ActivityMgr:doGoto(data)
  end
end
function ActivitiesDlg:getActiveByName()
  local getAct = function(data)
    for i = 1, #data do
      if ActivityMgr.doubleActvies[CHS[4100285]] and ActivityMgr.doubleActvies[CHS[4100285]][data[i].name] then
        return data[i]
      end
    end
    return nil
  end
  local data = ActivityMgr:getDailyActivity()
  local destAct = getAct(data)
  if destAct then
    return destAct
  end
  data = ActivityMgr:getLimitActivity()
  destAct = getAct(data)
  if destAct then
    return destAct
  end
  data = ActivityMgr:getFestivalActivity()
  destAct = getAct(data)
  if destAct then
    return destAct
  end
  data = ActivityMgr:getComingActivity()
  destAct = getAct(data)
  if destAct then
    return destAct
  end
  data = ActivityMgr:getOhterActivityData()
  destAct = getAct(data)
  if destAct then
    return destAct
  end
  data = ActivityMgr:getWelfareActivity()
  destAct = getAct(data)
  if destAct then
    return destAct
  end
  return nil
end
function ActivitiesDlg:initRewardPanel()
  local rewardStatusTable = ActivityMgr:getRewardStatus() or {}
  local reward = ActivityMgr:getActivityReward()
  local curValue = math.floor(ActivityMgr:getAllActivity())
  self:setProgressBar("activityProgressBar", curValue, 106)
  local activeValueImage = self:getControl("ActiveValueImage")
  self:setLabelText("Label_1", curValue, activeValueImage)
  self:setLabelText("Label_2", curValue, activeValueImage)
  local activeProgress = self:getControl("activityProgressBar")
  local posx
  if curValue > 106 then
    posx = activeProgress:getContentSize().width * 1
  else
    posx = activeProgress:getContentSize().width * (curValue / 106)
  end
  activeValueImage:setPositionX(posx)
  for i = 1, #reward do
    do
      local rewardPanel = self:getControl(string.format("RewardPanel%d", i), Const.UIPanel)
      local rewardItemPanel = self:getControl("RewardItemPanel", Const.UIPanel, rewardPanel)
      local image = self:getControl("BonusImage", Const.UIImage, rewardPanel)
      rewardItemPanel:setTag(i)
      local key = reward[i].activity
      if reward[i].icon then
        local path = ResMgr:getItemIconPath(reward[i].icon)
        image:loadTexture(path)
        gf:setItemImageSize(image)
      else
        image:loadTexture(ResMgr.ui.item_common, ccui.TextureResType.plistType)
      end
      if rewardStatusTable[key] and rewardStatusTable[key].status == 1 then
        self:setCtrlVisible("CoverImage", true, rewardPanel)
        self:removeMagic(rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
      elseif rewardStatusTable[key] and rewardStatusTable[key].status == 2 then
        self:setCtrlVisible("CoverImage", false, rewardPanel)
        gf:createArmatureMagic(ResMgr.ArmatureMagic.item_around, rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
      else
        self:setCtrlVisible("CoverImage", false, rewardPanel)
        self:removeMagic(rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
      end
      if reward[i].icon and ResMgr:getItemIconPath(reward[i].icon) == ResMgr.ui.yinyuanbao then
      elseif not reward[i].icon then
      else
        InventoryMgr:addLogoBinding(image)
      end
      local function showItemInfo(sender, type)
        if ccui.TouchEventType.ended == type then
          if not DistMgr:checkCrossDist() then
            return
          end
          RecordLogMgr:isMeetPlugOrder("ActivitiesDlg_" .. tostring(key))
          if rewardStatusTable[key] and rewardStatusTable[key].status == 2 then
            ActivityMgr:getReward(key)
            self:removeMagic(rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
          else
            local rect = self:getBoundingBoxInWorldSpace(rewardItemPanel)
            local pos = gf:findStrByByte(reward[i].reward, "X")
            local itemName = ""
            if not pos then
              InventoryMgr:showBasicMessageDlg(reward[i].reward, rect)
            else
              itemName = string.sub(reward[i].reward, 1, pos - 1)
              local count = string.sub(reward[i].reward, pos + 1, -1)
              if DistMgr:isTestDist(GameMgr.dist) and reward[i].testDistReward then
                count = string.sub(reward[i].testDistReward, pos + 1, -1)
              end
              local item = {}
              if itemName == CHS[6000080] or itemName == CHS[6000042] then
                item.Icon = InventoryMgr:getIconByName(itemName)
                item.name = itemName
                item.extra = nil
                item.desc2 = string.format(InventoryMgr:getDescript(itemName), count) .. "\n"
                item.isShowDesc = 0
                InventoryMgr:showBasicMessageByItem(item, rect)
              else
                InventoryMgr:showBasicMessageDlg(itemName, rect)
              end
            end
          end
        end
      end
      rewardItemPanel:addTouchEventListener(showItemInfo)
    end
  end
end
function ActivitiesDlg:cleanup()
  if self.dailyCell then
    self.dailyCell:release()
    self.dailyCell = nil
  end
  if self.limitCell then
    self.limitCell:release()
    self.limitCell = nil
  end
  if self.comingCell then
    self.comingCell:release()
    self.comingCell = nil
  end
  if self.dailyCells then
    for name, _ in pairs(self.dailyCells) do
      self:removeDailyCellsFromParent(name)
      for tag, __ in pairs(self.dailyCells[name]) do
        self.dailyCells[name][tag]:release()
        self.dailyCells[name][tag] = nil
      end
      self.dailyCells[name] = nil
    end
    self.dailyCells = nil
  end
  self.curRewardType = nil
end
function ActivitiesDlg:getSelectItemBox(type)
  local scrollview = self:getControl("DailyScrollView", Const.UIScrollView)
  local panel = scrollview:getChildByTag(SCROLLVIEW_CHILD_TAG):getChildByTag(1)
  local btn = self:getControl("GoButton", nil, panel)
  return self:getBoundingBoxInWorldSpace(btn)
end
function ActivitiesDlg:scrollToOneActivity(scrollview, tag, data)
  local contentLayer = scrollview:getChildByTag(SCROLLVIEW_CHILD_TAG)
  local cell = contentLayer:getChildByTag(data.index)
  if not cell then
    return
  end
  local scrollSize = scrollview:getContentSize()
  local scrollInnerSize = contentLayer:getContentSize()
  local canScrollHeight = scrollInnerSize.height - scrollSize.height
  local line = math.floor((tag - 1) / COLUNM)
  local scrollTime = 0.05 * line
  if line > 0 and canScrollHeight > 0 then
    local scrollHeight = line * (cell:getContentSize().height + LINE_SAPCE)
    if canScrollHeight < scrollHeight then
      scrollHeight = canScrollHeight
    end
    local percent = scrollHeight / canScrollHeight * 100
    scrollview:scrollToPercentVertical(percent, scrollTime, false)
  end
  gf:frozenScreen((scrollTime + 0.15) * 1000)
  performWithDelay(self.root, function()
    cell.data = data
    touchCell(cell, ccui.TouchEventType.ended)
  end, scrollTime + 0.15)
end
function ActivitiesDlg:onDlgOpened(list, param)
  if not list then
    return
  end
  local scrollview, activityData
  if list[1] == CHS[5420151] then
    self:OnSiwchTab(self:getControl("DailyCheckBox"))
    self:setCheck("DailyCheckBox", true)
    self:setCheck("LimitedCheckBox", false)
    self:setCheck("FestivalCheckBox", false)
    self:setCheck("ComingCheckBox", false)
    self:setCheck("OtherCheckBox", false)
    scrollview = self:getControl("DailyScrollView", Const.UIScrollView)
    activityData = ActivityMgr:getDailyActivity()
  elseif list[1] == CHS[3002230] then
    self:OnSiwchTab(self:getControl("LimitedCheckBox"))
    self:setCheck("LimitedCheckBox", true)
    self:setCheck("DailyCheckBox", false)
    self:setCheck("FestivalCheckBox", false)
    self:setCheck("ComingCheckBox", false)
    self:setCheck("OtherCheckBox", false)
    scrollview = self:getControl("LimitedScrollView", Const.UIScrollView)
    activityData = ActivityMgr:getLimitActivity()
  elseif list[1] == CHS[5420152] then
    self:OnSiwchTab(self:getControl("FestivalCheckBox"))
    self:setCheck("FestivalCheckBox", true)
    self:setCheck("DailyCheckBox", false)
    self:setCheck("LimitedCheckBox", false)
    self:setCheck("ComingCheckBox", false)
    self:setCheck("OtherCheckBox", false)
    scrollview = self:getControl("FestivalScrollView", Const.UIScrollView)
    activityData = ActivityMgr:getFestivalActivity()
  elseif list[1] == CHS[5420153] then
    self:OnSiwchTab(self:getControl("ComingCheckBox"))
    self:setCheck("ComingCheckBox", true)
    self:setCheck("DailyCheckBox", false)
    self:setCheck("FestivalCheckBox", false)
    self:setCheck("LimitedCheckBox", false)
    self:setCheck("OtherCheckBox", false)
    scrollview = self:getControl("ComingScrollView", Const.UIScrollView)
    activityData = ActivityMgr:getComingActivity()
  elseif list[1] == CHS[6400009] or list[1] == CHS[4100813] then
    self:OnSiwchTab(self:getControl("OtherCheckBox"))
    self:setCheck("OtherCheckBox", true)
    self:setCheck("DailyCheckBox", false)
    self:setCheck("FestivalCheckBox", false)
    self:setCheck("ComingCheckBox", false)
    self:setCheck("LimitedCheckBox", false)
    scrollview = self:getControl("OtherScrollView", Const.UIScrollView)
    activityData = ActivityMgr:getOhterActivityData()
  end
  if not scrollview then
    return
  end
  if list[2] then
    for key, v in pairs(activityData) do
      if activityData[key].name == list[2] then
        self:scrollToOneActivity(scrollview, key, activityData[key])
        return
      end
    end
  end
end
return ActivitiesDlg
