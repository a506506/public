local CgShowDlg = class("CgShowDlg", function()
  return cc.Layer:create()
end)
local VIDEO_SIZE = cc.size(1920, 1080)
local FILE_NAME = "cg.mp4"
local ASSETR_ESOURCE_ROOT = "assets/"
local CUR_VERSION = 1
function CgShowDlg:ctor(filePath, callback)
  self.filePath = filePath
  self.callback = callback
  self.root = ccui.Layout:create()
  local winSize = cc.Director:getInstance():getWinSize()
  self.root:setContentSize(cc.size(winSize.width, winSize.height))
  self.root:setAnchorPoint(cc.p(0.5, 0.5))
  self.root:setPosition(cc.p(winSize.width / 2, winSize.height / 2))
  self.root:setBackGroundColorType(1)
  self.root:setBackGroundColor(cc.c3b(0, 0, 0))
  self.root:setTouchEnabled(true)
  self:addChild(self.root)
  if gf:isAndroid() or gf:isIos() then
    self:playVideo()
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.began then
    elseif eventType == ccui.TouchEventType.ended or eventType == ccui.TouchEventType.canceled then
      if self.videoPlayer then
        self.videoPlayer:stop()
      end
      if gf:isIos() then
        self:removeFromParent()
      end
    end
  end
  self.root:addTouchEventListener(listener)
  local function onNodeEvent(event)
    if "cleanup" == event then
      self:onNodeCleanup()
    end
  end
  self:registerScriptHandler(onNodeEvent)
  performWithDelay(self, function()
    SoundMgr:stopMusicAndSound()
  end, 0)
  if gf.EndGameEx then
    do
      local curNode = self
      function gf.EndGameEx()
        if curNode and "function" == type(curNode.removeFromParent) then
          curNode:removeFromParent()
        end
      end
    end
  end
  EventDispatcher:addEventListener("ENTER_BACKGROUND", self.onEnterBackground, self)
end
function CgShowDlg:playVideo()
  if not self.videoPlayer then
    self.videoPlayer = ccexp.VideoPlayer:create()
  end
  local winSize = cc.Director:getInstance():getVisibleSize()
  local size
  if VIDEO_SIZE.width * winSize.height > VIDEO_SIZE.height * winSize.width then
    size = cc.size(winSize.width, VIDEO_SIZE.height * winSize.width / VIDEO_SIZE.width)
  else
    size = cc.size(VIDEO_SIZE.width * winSize.height / VIDEO_SIZE.height, winSize.height)
  end
  self.videoPlayer:setPosition(cc.p(winSize.width / 2, winSize.height / 2))
  self.videoPlayer:setAnchorPoint(cc.p(0.5, 0.5))
  local userDefault = cc.UserDefault:getInstance()
  local musicOn = userDefault:getBoolForKey("musicOn", true)
  local isStop
  self.videoPlayer:addEventListener(function(sender, event)
    if ("1" == tostring(event) or "2" == tostring(event) or "3" == tostring(event)) and not isStop then
      isStop = true
      performWithDelay(self, function()
        self:removeFromParent()
      end, 0)
    elseif "0" == tostring(event) and not musicOn and self:isMuteSupport() and "function" == type(self.videoPlayer.setVolumn) then
      self.videoPlayer:setVolumn(0)
    end
    if isStop then
      local userDefault = cc.UserDefault:getInstance()
      if userDefault then
        local curVer = userDefault:getIntegerForKey("CgVersion", CUR_VERSION)
        userDefault:setIntegerForKey("CgVersion", CUR_VERSION)
        if "3" == tostring(event) or curVer ~= CUR_VERSION then
          userDefault:setIntegerForKey("CgSkipTimes", 0)
        else
          local skipTimes = userDefault:getIntegerForKey("CgSkipTimes", 0)
          userDefault:setIntegerForKey("CgSkipTimes", skipTimes + 1)
        end
      end
    end
  end)
  if not musicOn and self:isMuteSupport() and gf:isIos() then
    self.curMediaVolumn = self.videoPlayer:getVolumn()
  end
  self:addChild(self.videoPlayer)
  self:setVisible(false)
  if gf:isAndroid() and not gf:gfIsFuncEnabled(FUNCTION_ID.VIDEOPLAY_V20171228) then
    self.videoPlayer:setContentSize(cc.size(winSize.width, winSize.height))
    self.videoPlayer:setFileName(self:getFilePath())
    self:setVisible(true)
    self.videoPlayer:play()
    self.videoPlayer:seekTo(0.9)
    if "function" == type(self.videoPlayer.setStyle) then
      self.videoPlayer:setStyle(1)
    end
    performWithDelay(self, function()
      if self.videoPlayer then
        self.videoPlayer:setFullScreenEnabled(true)
        self.videoPlayer:setKeepAspectRatioEnabled(true)
      end
    end, 0)
  elseif self.videoPlayer then
    self.videoPlayer:setContentSize(cc.size(size.width, size.height))
    self.videoPlayer:setFileName(self:getFilePath())
    self.videoPlayer:play()
    self.videoPlayer:seekTo(0.9)
    self:setVisible(true)
    if "function" == type(self.videoPlayer.setStyle) then
      self.videoPlayer:setStyle(1)
    end
    if "function" == type(self.videoPlayer.setUserInputEnabled) then
      self.videoPlayer:setUserInputEnabled(false)
    end
  end
end
function CgShowDlg:getFilePath()
  if 1 == string.find(self.filePath, ASSETR_ESOURCE_ROOT) then
    return string.sub(self.filePath, #ASSETR_ESOURCE_ROOT + 1)
  else
    return self.filePath
  end
end
function CgShowDlg:onEnterBackground(sender, eventType)
  if gf:isAndroid() then
    if self.videoPlayer then
      self.videoPlayer:stop()
    end
    self:removeFromParent()
  end
end
function CgShowDlg:onNodeCleanup()
  EventDispatcher:removeEventListener("ENTER_BACKGROUND", self.onEnterBackground, self)
  local platform = cc.Application:getInstance():getTargetPlatform()
  if platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_IPHONE then
    local luaoc = require("luaoc")
    luaoc.callStaticMethod("AppController", "finishVolumnView")
  end
  SoundMgr:replayMusicAndSound()
  if self.curMediaVolumn and self:isMuteSupport() and "function" == type(self.videoPlayer.setVolumn) then
    self.videoPlayer:setVolumn(self.curMediaVolumn)
  end
  if "function" == type(self.callback) then
    do
      local callback = self.callback
      local scene = cc.Director:getInstance():getRunningScene()
      if scene then
        performWithDelay(scene, function()
          callback()
        end, 0)
        if scene.updateDlg then
          scene.updateDlg:setVisible(false)
        end
      else
        callback()
      end
    end
  end
  package.loaded["global/GlobalFunc"] = nil
  require("global/GlobalFunc")
end
function CgShowDlg:isMuteSupport()
  local platform = cc.Application:getInstance():getTargetPlatform()
  if cc.PLATFORM_OS_ANDROID == platform then
    return true
  elseif platform == cc.PLATFORM_OS_IPAD or platform == cc.PLATFORM_OS_IPHONE then
    return "function" == type(ccexp.VideoPlayer.getVolumn)
  end
end
function CgShowDlg.canSkip()
  local userDefault = cc.UserDefault:getInstance()
  if not userDefault then
    return
  end
  local cgVer = userDefault:getIntegerForKey("CgVersion", 0)
  if cgVer < CUR_VERSION then
    return
  end
  local skipTimes = userDefault:getIntegerForKey("CgSkipTimes", 0)
  return skipTimes >= 5
end
return CgShowDlg
