local ChatHornDlg = Singleton("ChatHornDlg", Dialog)
local HORN_POP_SHOW_TIME = 12
function ChatHornDlg:init()
  self:setFullScreen()
  local hornPanel = self:getControl("HornPanel")
  local hornSize = hornPanel:getContentSize()
  hornPanel:setContentSize(hornSize.width - 960 + self.root:getContentSize().width, hornSize.height)
  hornPanel.origPos = cc.p(hornPanel:getPosition())
  hornPanel:setVisible(false)
  local hornConPanel = self:getControl("ContentPanel", nil, hornPanel)
  hornConPanel.origPosX = hornConPanel:getPositionX()
end
function ChatHornDlg:cleanup()
  local layout = gf:getUILayer():getChildByName("ChatHornDlg_TouchPanel")
  if layout then
    layout:removeFromParent()
  end
end
function ChatHornDlg:doHornPopup(data)
  local mainPanel = self:getControl("HornPanel")
  local size = mainPanel:getContentSize()
  mainPanel:stopAllActions()
  local itemInfo = InventoryMgr:getItemInfoByName(data.horn_name)
  if not itemInfo or not itemInfo.bubble_tip_horn then
    itemInfo = InventoryMgr:getItemInfoByName(CHS[5400319])
  end
  local textWidth = self.root:getContentSize().width - 24
  local msgStr = string.format("  #i%s#i  #cFFDB4B#<[%s]#>：%s#n", itemInfo.bubble_tip_horn or "", gf:getRealName(data.name), data.msg)
  mainPanel:setBackGroundImage(itemInfo.bubble_tip_back_main, ccui.TextureResType.plistType)
  local conPanel = self:getControl("ContentPanel", nil, mainPanel)
  conPanel:stopAllActions()
  conPanel:setPositionX(conPanel.origPosX)
  local clonePanel = self:getControl("clonePanel", nil, conPanel:getParent())
  if clonePanel then
    clonePanel:removeFromParent()
  end
  local width = self:setHornTextPanel(conPanel, msgStr, data, textWidth, true)
  local space = 100
  if textWidth < width then
    do
      local panel = conPanel:clone()
      panel:setPositionX(conPanel.origPosX + width + space)
      panel:setName("clonePanel")
      self:setHornTextPanel(panel, msgStr, data, textWidth)
      conPanel:getParent():addChild(panel)
      local speed = 0.015
      conPanel:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.MoveBy:create(width * speed, cc.p(-width, 0)), cc.CallFunc:create(function()
        conPanel:setPositionX(conPanel.origPosX + width + space * 2)
      end), cc.MoveBy:create((width + space * 2) * speed, cc.p(-width - space * 2, 0)))))
      panel:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.MoveBy:create((width * 2 + space) * speed, cc.p(-width * 2 - space, 0)), cc.CallFunc:create(function()
        panel:setPositionX(conPanel.origPosX + width + space * 2)
      end), cc.MoveBy:create(space * speed, cc.p(-space, 0)))))
    end
  end
  performWithDelay(mainPanel, function()
    mainPanel:runAction(cc.Sequence:create(cc.MoveTo:create(0.2, cc.p(mainPanel.origPos.x, mainPanel.origPos.y - size.height)), cc.CallFunc:create(function()
      conPanel:stopAllActions()
      mainPanel:setVisible(false)
      local clonePanel = self:getControl("clonePanel", nil, conPanel:getParent())
      if clonePanel then
        clonePanel:removeFromParent()
      end
      local layout = gf:getUILayer():getChildByName("ChatHornDlg_TouchPanel")
      if layout then
        layout:setVisible(false)
      end
    end)))
  end, HORN_POP_SHOW_TIME)
  if not mainPanel:isVisible() then
    mainPanel:setPosition(mainPanel.origPos.x, mainPanel.origPos.y - size.height)
  end
  mainPanel:runAction(cc.MoveTo:create(0.2, mainPanel.origPos))
  mainPanel:setVisible(true)
  mainPanel:requestDoLayout()
end
function ChatHornDlg:setHornTextPanel(conPanel, msgStr, data, textWidth, isFirst)
  local size = conPanel:getContentSize()
  conPanel:removeAllChildren()
  local scale = Const.MAIN_CHAT_MSG_SCALE
  local textCtrl = CGAColorTextList:create()
  textCtrl:setContentSize(10000, 0)
  textCtrl:setFontSize(31)
  textCtrl:setString(msgStr, data.show_extra)
  textCtrl:updateNow()
  local textW, textH = textCtrl:getRealSize()
  if textWidth < textW * scale then
    textCtrl:setPosition(5, size.height - (size.height - textH * scale) / 2)
  else
    textCtrl:setPosition((size.width - textW * scale) / 2, size.height - (size.height - textH * scale) / 2)
  end
  local layer = tolua.cast(textCtrl, "cc.LayerColor")
  layer:setScale(scale)
  conPanel:addChild(layer)
  local channelSprite = textCtrl:getChannelSprite()
  if channelSprite then
    local sprite = tolua.cast(channelSprite, "cc.Sprite")
    sprite:setScale(Const.MAIN_CHAT_CHANNEL_SCALE)
  end
  local nameLabelSprite = textCtrl:getNameStringSprite()
  if nameLabelSprite then
    local labelSprite = tolua.cast(nameLabelSprite, "cc.Sprite")
    local labelSize = labelSprite:getContentSize()
    labelSprite:retain()
    local labelLayout = ccui.Layout:create()
    layer:addChild(labelLayout)
    labelLayout:setContentSize(labelSize)
    labelLayout:setTouchEnabled(true)
    labelLayout:setPosition(labelSprite:getPosition())
    labelLayout:setAnchorPoint(labelSprite:getAnchorPoint())
    labelSprite:removeFromParent()
    labelLayout:addChild(labelSprite)
    labelSprite:release()
    labelSprite:setPosition(labelSize.width / 2, labelSize.height / 2)
    local function nameTouch(sender, eventType)
      if ccui.TouchEventType.ended == eventType then
        if data.gid and data.gid ~= 0 and data.gid ~= Me:queryBasic("gid") then
          FriendMgr:requestCharMenuInfo(data.gid)
          ChatMgr:setTipData(data)
          local char = {}
          char.gid = data.gid
          char.name = name
          char.level = data.level
          char.icon = data.icon
          local dlg = DlgMgr:openDlg("CharMenuContentDlg")
          dlg:setting(data.gid)
          dlg:setbackCharInfo(char)
          dlg.root:setPositionX(dlg.root:getPositionX() + 100)
        else
          DlgMgr:sendMsg("ChatDlg", "onChannelOpen")
        end
      end
    end
    labelLayout:addTouchEventListener(nameTouch)
  end
  if isFirst then
    do
      local layout = gf:getUILayer():getChildByName("ChatHornDlg_TouchPanel")
      if not layout then
        local panel = self:getControl("CutPanel")
        layout = ccui.Layout:create()
        layout:setContentSize(panel:getContentSize())
        layout:setAnchorPoint(cc.p(0, 0))
        local pos = panel:getParent():convertToWorldSpace(cc.p(panel:getPosition()))
        pos = gf:getUILayer():convertToNodeSpace(pos)
        layout:setPosition(pos)
        layout:setName("ChatHornDlg_TouchPanel")
        layout:setTouchEnabled(true)
        gf:getUILayer():addChild(layout, -2)
      end
      layout:setVisible(true)
      local mainPanel = self:getControl("HornPanel")
      local function ctrlTouch(sender, eventType)
        if not mainPanel:isVisible() then
          return
        end
        if ccui.TouchEventType.ended == eventType then
          if textCtrl:getCsType() ~= CONST_DATA.CS_TYPE_STRING then
            if not data.gid or data.gid == 0 then
              gf:onCGAColorText(textCtrl, sender)
            elseif textCtrl:getCsType() ~= CONST_DATA.CS_TYPE_ZOOM and textCtrl:getCsType() ~= CONST_DATA.CS_TYPE_NPC and textCtrl:getCsType() ~= CONST_DATA.CS_TYPE_CALL then
              gf:onCGAColorText(textCtrl, sender)
            else
              DlgMgr:sendMsg("ChatDlg", "onChannelOpen")
            end
          else
            DlgMgr:sendMsg("ChatDlg", "onChannelOpen")
          end
        end
      end
      layout:addTouchEventListener(ctrlTouch)
    end
  end
  return textW * scale
end
return ChatHornDlg
