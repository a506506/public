local CreateCharDescDlg = require("dlg/CreateCharDescDlg")
local CreateCharDescExDlg = Singleton("CreateCharDescExDlg", CreateCharDescDlg)
function CreateCharDescExDlg:init()
  CreateCharDescDlg.init(self)
  NoticeMgr:showPreCreateDescDlg(true)
end
return CreateCharDescExDlg
