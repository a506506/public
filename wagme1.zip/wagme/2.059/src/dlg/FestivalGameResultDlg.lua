local FestivalGameResultDlg = Singleton("FestivalGameResultDlg", Dialog)
function FestivalGameResultDlg:init(data)
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel")
  self:bindListener("CloseImage", self.onCloseButton)
  self:bindListener("ExitButton", self.onCloseButton)
  self:bindListener("CheckButton", self.onCheckButton)
  self:setCtrlVisible("WinImage", data.result == 1)
  self:setCtrlVisible("WinBkImage", data.result == 1)
  self:setCtrlVisible("FailImage", data.result == 2)
  self:setCtrlVisible("FailBkImage", data.result == 2)
  self:setCtrlVisible("PingImage", data.result == 3)
  self:setCtrlVisible("PingBkImage", data.result == 3)
  self:setCtrlVisible("ExpPanel", false)
  self:setCtrlVisible("DaoPanel", false)
  self:setCtrlVisible("ExpPanel2", false)
  self:setCtrlVisible("DaoPanel2", false)
  self:setCtrlVisible("ItemPanel", false)
  self:setCtrlVisible("TitlePanel", false)
  self:setCtrlVisible("ThreeRewardPanel", false)
  if data.gameType == "wuxdj" then
    self:setDataForWuxdj(data)
  else
    self:setData(data)
  end
end
function FestivalGameResultDlg:setDataForWuxdj(data)
  if data.bonus_count >= 3 then
    local panel = self:setCtrlVisible("ThreeRewardPanel", true)
    if data.exp then
      local panel = self:setCtrlVisible("ExpPanel", true, "ThreeRewardPanel")
      self:setLabelText("ExpLabel", data.exp, panel)
    else
      self:setCtrlVisible("ExpPanel", false, "ThreeRewardPanel")
    end
    if data.tao then
      local panel = self:setCtrlVisible("DaoPanel", true, "ThreeRewardPanel")
      self:setLabelText("DaoLabel", gf:getTaoStr(tonumber(data.tao)) .. CHS[5410102], panel)
    else
      self:setCtrlVisible("DaoPanel", false, "ThreeRewardPanel")
    end
    if data.item then
      local panel = self:setCtrlVisible("ItemPanel", true, "ThreeRewardPanel")
      self:setLabelText("ItemLabel", data.item, panel)
    else
      self:setCtrlVisible("ItemPanel", false, "ThreeRewardPanel")
    end
    if data.appellation then
      local panel = self:setCtrlVisible("TitlePanel", true, "ThreeRewardPanel")
      self:setLabelText("TitleLabel", data.appellation, panel)
    else
      self:setCtrlVisible("TitlePanel", false, "ThreeRewardPanel")
    end
  elseif data.item or data.appellation then
    if data.exp then
      self:setCtrlVisible("ExpPanel", true)
      self:setLabelText("ExpLabel", data.exp, "ExpPanel")
    end
    if data.tao then
      self:setCtrlVisible("DaoPanel", true)
      self:setLabelText("DaoLabel", gf:getTaoStr(tonumber(data.tao)) .. CHS[5410102], "DaoPanel")
    end
    if data.item then
      self:setCtrlVisible("ItemPanel", true)
      self:setLabelText("ItemLabel", data.item)
    end
    if data.appellation then
      if data.bonus_count == 1 then
        local panel = self:setCtrlVisible("TitlePanel2", true)
        self:setLabelText("TitleLabel", data.appellation, panel)
      else
        local panel = self:setCtrlVisible("TitlePanel", true)
        self:setLabelText("TitleLabel", data.appellation, panel)
      end
    end
  else
    if data.exp then
      self:setCtrlVisible("ExpPanel2", true)
      self:setLabelText("ExpLabel", data.exp, "ExpPanel2")
    end
    if data.tao then
      self:setCtrlVisible("DaoPanel2", true)
      self:setLabelText("DaoLabel", gf:getTaoStr(tonumber(data.tao)) .. CHS[5410102], "DaoPanel2")
    end
    self:setCtrlVisible("NoRewardLabel", data.bonus_count == 0)
  end
end
function FestivalGameResultDlg:setData(data)
  if data.exp then
    self:setCtrlVisible("ExpPanel", true)
    self:setLabelText("ExpLabel", data.exp, "ExpPanel")
  end
  if data.tao then
    self:setCtrlVisible("DaoPanel", true)
    self:setLabelText("DaoLabel", gf:getTaoStr(tonumber(data.tao)) .. CHS[5410102], "DaoPanel")
  end
  if data.item then
    self:setCtrlVisible("ItemPanel", true)
    self:setLabelText("ItemLabel", data.item)
  end
  if data.need_show_pos == 1 then
    self:setCtrlVisible("CheckButton", true)
    self:setCtrlVisible("ExitButton", true)
    self:setCtrlVisible("CloseImage", false)
  end
  self:setCtrlVisible("NoRewardLabel", data.bonus_count == 0)
end
function FestivalGameResultDlg:cleanup()
  DlgMgr:closeDlg("PolarDuelDlg")
end
function FestivalGameResultDlg:onCheckButton(sender, eventType)
  gf:CmdToServer("CMD_CHILD2020_TZHJ_GAME_DATA", {type = "pos", idx = 0})
  gf:ShowSmallTips(CHS[4300812])
  self:onCloseButton()
end
return FestivalGameResultDlg
