local ForeverCustomTitleDlg = Singleton("ForeverCustomTitleDlg", Dialog)
local MAX_LENTH = 12
function ForeverCustomTitleDlg:init()
  self:bindListener("ExchangeButton", self.onExchangeButton)
  self.inputEditBox = self:createEditBox("EnterNamePanel", nil, nil, function(dlg, event, sender)
    if "ended" == event then
      local text = sender:getText()
      if gf:getTextLength(text) > MAX_LENTH then
        text = gf:subString(text, MAX_LENTH)
        sender:setText(text)
        gf:ShowSmallTips(CHS[7150594])
      end
      sender:setText(text)
    end
  end)
  self.inputEditBox:setPlaceholderFont(CHS[3002184], 23)
  self.inputEditBox:setFont(CHS[3002184], 23)
  self.inputEditBox:setFontColor(COLOR3.TEXT_DEFAULT)
  self.inputEditBox:setPlaceHolder(CHS[7150593])
  self.inputEditBox:setPlaceholderFontColor(COLOR3.GRAY)
  self:hookMsg("MSG_NEW_DIST_ONLINEMALL_ITEM_LIST")
end
function ForeverCustomTitleDlg:setData(data)
  self.dlgData = data
  local priceText, fontColor = gf:getArtFontMoneyDesc(tonumber(data.price))
  if data.price > self.dlgData.coin then
    fontColor = ART_FONT_COLOR.RED
  end
  self:setNumImgForPanel("CoinValuePanel", fontColor, priceText, false, LOCATE_POSITION.MID, 23, "TotalPricePanel")
end
function ForeverCustomTitleDlg:onExchangeButton(sender, eventType)
  if self:checkSafeLockRelease("onExchangeButton") then
    return
  end
  if self.dlgData.price > self.dlgData.coin then
    gf:ShowSmallTips(CHS[7150591])
    return
  end
  local text = self.inputEditBox:getText()
  local _, fitStr = gf:filtTextEx(text, nil, nil, true)
  if fitStr then
    return
  end
  _, fitStr = gf:filtTextByTwo(string.format("%s%s", CHS[8000029], text))
  if fitStr then
    return
  end
  local para = string.format("%s_%s_%s", tostring(self.dlgData.index), tostring(1), text)
  gf:CmdToServer("CMD_NEW_DIST_ONLINEMALL_BUY_ITEM", {para = para})
end
function ForeverCustomTitleDlg:MSG_NEW_DIST_ONLINEMALL_ITEM_LIST()
  DlgMgr:closeDlg(self.name)
end
return ForeverCustomTitleDlg
