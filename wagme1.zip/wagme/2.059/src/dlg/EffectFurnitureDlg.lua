local EffectFurnitureDlg = Singleton("EffectFurnitureDlg", Dialog)
local TYPE_TO_NAME = {
  CHS[7190000],
  CHS[7190001],
  CHS[7190002]
}
local TYPE_TO_EFFECT_NAME = {
  CHS[7190004],
  CHS[7190005],
  CHS[7190006]
}
local TYPE_TO_NO_EFFECT_NAME = {
  CHS[7190010],
  CHS[7190011],
  CHS[7190012]
}
local TYPE_TO_BTN_NAME = {
  CHS[7190007],
  CHS[7190008],
  CHS[7190009]
}
local TYPE_TO_TITLE_NAME = {
  CHS[7190015],
  CHS[7190016],
  CHS[7190017]
}
function EffectFurnitureDlg:init(data)
  self:bindListener("RuleButton", self.onRuleButton)
  self:bindListener("WaitButton", self.onWaitButton)
  self:bindListener("StartButton", self.onStartButton)
  self:bindListener("EndButton", self.onEndButton)
  self:bindListener("CancelButton", self.onCancelButton)
  self:bindListener("OpenButton", self.onOpenButton)
  self.dlgType = data.type
  self.furniturePos = data.pos
  self.furnitureX, self.furnitureY = data.pX, data.pY
  self.usingBuffValue = 0
  self:setData()
  self:hookMsg("MSG_HOUSE_PRACTICE_BUFF_DATA")
  self:hookMsg("MSG_HOUSE_REFRESH_PRACTICE_BUFF_DATA")
end
function EffectFurnitureDlg:onRuleButton(sender, eventType)
  local dlg = DlgMgr:openDlg("EffectFurnitureRuleDlg")
  dlg:setRuleByType(self.dlgType)
end
function EffectFurnitureDlg:sendMessageToServer(action)
  HomeMgr:cmdHouseUseFurniture(self.furniturePos, "practice_buff", action)
end
function EffectFurnitureDlg:canOper()
  if not HomeMgr:isInMyHouse() then
    gf:ShowSmallTips(CHS[5410115])
    return
  end
  local info = HomeMgr:getFurnitureInfo(TYPE_TO_NAME[self.dlgType])
  if info then
    local place = string.match(info.furniture_type, "(.-)-.+")
    if not string.match(MapMgr:getCurrentMapName(), place) then
      gf:ShowSmallTips(string.format(CHS[5410116], place))
      return
    end
  end
  return true
end
function EffectFurnitureDlg:onWaitButton(sender, eventType)
  if not self:canOper() then
    return
  end
  local furn = HomeMgr:getFurnitureById(self.furniturePos)
  if not furn then
    gf:ShowSmallTips(CHS[5410041])
    self:onCloseButton()
    return
  end
  if self.furnitureX ~= furn.curX or self.furnitureY ~= furn.curY then
    gf:ShowSmallTips(CHS[4200418])
    self:onCloseButton()
    return
  end
  self:sendMessageToServer("wait")
end
function EffectFurnitureDlg:onStartButton(sender, eventType)
  if not self:canOper() then
    return
  end
  local furn = HomeMgr:getFurnitureById(self.furniturePos)
  if not furn then
    gf:ShowSmallTips(CHS[5410041])
    self:onCloseButton()
    return
  end
  if self.furnitureX ~= furn.curX or self.furnitureY ~= furn.curY then
    gf:ShowSmallTips(CHS[4200418])
    self:onCloseButton()
    return
  end
  self:sendMessageToServer("start")
end
function EffectFurnitureDlg:onEndButton(sender, eventType)
  if not self:canOper() then
    return
  end
  if MapMgr:isInHouse(MapMgr:getCurrentMapName()) then
    local furn = HomeMgr:getFurnitureById(self.furniturePos)
    if not furn then
      gf:ShowSmallTips(CHS[5410041])
      self:onCloseButton()
      return
    end
    if self.furnitureX ~= furn.curX or self.furnitureY ~= furn.curY then
      gf:ShowSmallTips(CHS[4200418])
      self:onCloseButton()
      return
    end
  end
  self:sendMessageToServer("stop")
end
function EffectFurnitureDlg:onCancelButton(sender, eventType)
  if not self:canOper() then
    return
  end
  local furn = HomeMgr:getFurnitureById(self.furniturePos)
  if not furn then
    gf:ShowSmallTips(CHS[5410041])
    self:onCloseButton()
    return
  end
  if self.furnitureX ~= furn.curX or self.furnitureY ~= furn.curY then
    gf:ShowSmallTips(CHS[4200418])
    self:onCloseButton()
    return
  end
  self:sendMessageToServer("nowait")
end
function EffectFurnitureDlg:onOpenButton(sender, eventType)
  if not self:canOper() then
    return
  end
  local furn = HomeMgr:getFurnitureById(self.furniturePos)
  if not furn then
    gf:ShowSmallTips(CHS[5410041])
    self:onCloseButton()
    return
  end
  if self.furnitureX ~= furn.curX or self.furnitureY ~= furn.curY then
    gf:ShowSmallTips(CHS[4200418])
    self:onCloseButton()
    return
  end
  self:sendMessageToServer("active")
end
function EffectFurnitureDlg:setData()
  local type = self.dlgType
  local effectFurnitureData = HomeMgr:getEffectFurnitureData()
  local furnitureStaus = effectFurnitureData.status
  local buffValue = effectFurnitureData.buffValue
  local tolerance = effectFurnitureData.tolerance
  self.furniturePos = effectFurnitureData.pos
  self.usingBuffValue = effectFurnitureData.startupBuffValue
  if not furnitureStaus or not buffValue or not tolerance then
    return
  end
  if furnitureStaus == 0 then
    if buffValue == 0 then
      self:setCtrlVisible("OpenButton", true)
      self:setCtrlVisible("WaitButton", false)
      self:setCtrlVisible("StartButton", false)
      self:setLabelText("EffectLabel_1", TYPE_TO_NO_EFFECT_NAME[type], "EffectPanel_1")
      self:setLabelText("Label_1", TYPE_TO_BTN_NAME[type], "OpenButton")
      self:setLabelText("Label_2", TYPE_TO_BTN_NAME[type], "OpenButton")
    else
      self:setCtrlVisible("OpenButton", false)
      self:setCtrlVisible("WaitButton", true)
      self:setCtrlVisible("StartButton", true)
      self:setLabelText("EffectLabel_1", string.format("%d%%", buffValue), "EffectPanel_1")
    end
    self:setCtrlVisible("EndButton", false)
    self:setCtrlVisible("CancelButton", false)
  elseif furnitureStaus == 1 then
    self:setCtrlVisible("WaitButton", false)
    self:setCtrlVisible("StartButton", false)
    self:setCtrlVisible("EndButton", false)
    self:setCtrlVisible("CancelButton", true)
    self:setCtrlVisible("OpenButton", false)
    self:setLabelText("EffectLabel_1", string.format("%d%%", buffValue), "EffectPanel_1")
  elseif furnitureStaus == 2 then
    self:setCtrlVisible("WaitButton", false)
    self:setCtrlVisible("StartButton", false)
    self:setCtrlVisible("EndButton", true)
    self:setCtrlVisible("CancelButton", false)
    self:setCtrlVisible("OpenButton", false)
    self:setLabelText("EffectLabel_1", string.format("%d%%", buffValue), "EffectPanel_1")
  end
  local maxTolerance = HomeMgr:getMaxDur(TYPE_TO_NAME[type])
  self:setLabelText("NaijiuLabel_1", string.format("%d/%d", tolerance, maxTolerance), "NaijiuPanel")
  self:setLabelText("Label_2", TYPE_TO_TITLE_NAME[type], "TitleNamePanel")
  self:setIconAndLabel(TYPE_TO_NAME[type], TYPE_TO_EFFECT_NAME[type])
end
function EffectFurnitureDlg:setIconAndLabel(name, effectName)
  local path = ResMgr:getItemIconPath(InventoryMgr:getIconByName(name))
  self:setImage("ShowImage", path, "ShowPanel")
  self:setLabelText("NameLabel_1", name, "NamePanel")
  self:setLabelText("EffectLabel_1", effectName, "EffectPanel")
end
function EffectFurnitureDlg:MSG_HOUSE_PRACTICE_BUFF_DATA()
  self:setData()
end
function EffectFurnitureDlg:MSG_HOUSE_REFRESH_PRACTICE_BUFF_DATA(data)
  if data.pos == self.furniturePos then
    local type = self.dlgType
    if data.status == 0 then
      if data.buffValue == 0 then
        self:setCtrlVisible("OpenButton", true)
        self:setCtrlVisible("WaitButton", false)
        self:setCtrlVisible("StartButton", false)
        self:setLabelText("EffectLabel_1", TYPE_TO_NO_EFFECT_NAME[type], "EffectPanel_1")
        self:setLabelText("Label_1", TYPE_TO_BTN_NAME[type], "OpenButton")
        self:setLabelText("Label_2", TYPE_TO_BTN_NAME[type], "OpenButton")
      else
        self:setCtrlVisible("OpenButton", false)
        self:setCtrlVisible("WaitButton", true)
        self:setCtrlVisible("StartButton", true)
        self:setLabelText("EffectLabel_1", string.format("%d%%", data.buffValue), "EffectPanel_1")
      end
      self:setCtrlVisible("EndButton", false)
      self:setCtrlVisible("CancelButton", false)
    elseif data.status == 1 then
      self:setCtrlVisible("WaitButton", false)
      self:setCtrlVisible("StartButton", false)
      self:setCtrlVisible("EndButton", false)
      self:setCtrlVisible("CancelButton", true)
      self:setCtrlVisible("OpenButton", false)
      self:setLabelText("EffectLabel_1", string.format("%d%%", data.buffValue), "EffectPanel_1")
    elseif data.status == 2 then
      self:setCtrlVisible("WaitButton", false)
      self:setCtrlVisible("StartButton", false)
      self:setCtrlVisible("EndButton", true)
      self:setCtrlVisible("CancelButton", false)
      self:setCtrlVisible("OpenButton", false)
      self:setLabelText("EffectLabel_1", string.format("%d%%", data.buffValue), "EffectPanel_1")
      self.usingBuffValue = data.buffValue
    end
    local maxTolerance = HomeMgr:getMaxDur(TYPE_TO_NAME[type])
    self:setLabelText("NaijiuLabel_1", string.format("%d/%d", data.tolerance, maxTolerance), "NaijiuPanel")
  else
    self.usingBuffValue = data.buffValue
  end
end
return EffectFurnitureDlg
