local CaseWDGameDlg = Singleton("CaseWDGameDlg", Dialog)
local QI_ZI_POS = {
  -2,
  97,
  202,
  317,
  448
}
local QI_PAN_MARGIN = 123
function CaseWDGameDlg:init()
  self:setFullScreen()
  self:setCtrlVisible("BKPanel", true)
  self:setCtrlFullClient("BlackPanel", "BKPanel")
  self:bindListener("InfoButton", self.onInfoButton)
  self:bindListener("StartButton", self.onStartButton)
  self:bindListener("QiZPanel", self.onQiPanPanel, "QiPPanel")
  self:bindFloatPanelListener("RulePanel")
  self:setCtrlVisible("StartButton", true)
  self.chess = {}
  for i = 1, 5 do
    local chess = self:retainCtrl("QiPanel" .. i, "QiZiSelectPanel")
    self.chess[i] = chess
  end
  local chessRoot = self:getControl("QiZiSelectPanel")
  for i = 1, 5 do
    local whiteChess = self.chess[i]:clone()
    whiteChess:setPosition(QI_ZI_POS[i], -5)
    whiteChess.level = i
    chessRoot:addChild(whiteChess)
    self:bindTouchEventListener(whiteChess, self.onSelectChess)
  end
  self.putChess = {}
  self.qipPanel = self:getControl("QiZPanel")
end
function CaseWDGameDlg:setData(data)
  self.data = data
  if self.selectChess then
    self.selectChess:setVisible(false)
    self.selectChess = nil
  end
  self:refreshBoardChess()
end
function CaseWDGameDlg:refreshBoardChess()
  for i = 1, self.data.count do
    local info = self.data.list[i]
    if self.putChess[info.pos] then
      self.putChess[info.pos]:removeFromParent()
    end
    local newChess = self:getChessCtrl(info.level, info.type)
    newChess:setTouchEnabled(false)
    local pos = self:getPosByIndex(info.pos)
    newChess:setPosition(pos)
    self.qipPanel:addChild(newChess)
    self.putChess[info.pos] = newChess
  end
end
function CaseWDGameDlg:getChessCtrl(index, type)
  if not self.chess[index] then
    return
  end
  local ctrl = self.chess[index]:clone()
  if type == 1 then
    self:getControl("QiImage", nilm, ctrl):loadTexture(ResMgr.ui.case_chess_black)
    self:getControl("IconImage", nilm, ctrl):setColor(cc.c3b(188, 188, 188))
  end
  return ctrl
end
function CaseWDGameDlg:getIndexByPos(pos)
  local xIndex = math.ceil(pos.x / QI_PAN_MARGIN)
  local yIndex = 4 - math.ceil(pos.y / QI_PAN_MARGIN)
  local index = (yIndex - 1) * 3 + xIndex
  return index
end
function CaseWDGameDlg:getPosByIndex(index)
  local xIndex = index % 3
  if xIndex == 0 then
    xIndex = 3
  end
  local yIndex = 4 - math.ceil(index / 3)
  return cc.p((xIndex - 1) * QI_PAN_MARGIN, (yIndex - 1) * QI_PAN_MARGIN)
end
function CaseWDGameDlg:onQiPanPanel(sender, eventType)
  if eventType ~= ccui.TouchEventType.ended then
    return
  end
  if not self.data then
    return
  end
  if self.data.round_type == 1 then
    gf:ShowSmallTips(CHS[7100894])
    return
  end
  if not self.selectChess then
    gf:ShowSmallTips(CHS[7100895])
    return
  end
  local pos = gf:deepCopy(GameMgr.curTouchPos)
  local nodePos = sender:convertToNodeSpace(pos)
  local index = self:getIndexByPos(nodePos)
  gf:CmdToServer("CMD_SSWD_PLAY_CHESS", {
    pos = index,
    level = self.selectChess.level
  })
end
function CaseWDGameDlg:onSelectChess(sender, eventType)
  if eventType ~= ccui.TouchEventType.ended then
    return
  end
  if self:getControl("StartButton"):isVisible() then
    return
  end
  local chessRoot = self:getControl("QiZiSelectPanel")
  local children = chessRoot:getChildren()
  for i = 1, #children do
    local selectImage = children[i]:getChildByName("ChosenImage")
    if selectImage then
      selectImage:setVisible(false)
    end
  end
  sender:getChildByName("ChosenImage"):setVisible(true)
  self.selectChess = sender
end
function CaseWDGameDlg:onInfoButton(sender, eventType)
  local infoPanel = self:getControl("RulePanel")
  infoPanel:setVisible(not infoPanel:isVisible())
end
function CaseWDGameDlg:onStartButton(sender, eventType)
  sender:setVisible(false)
  gf:CmdToServer("CMD_SSWD_CHESS_START", {})
end
function CaseWDGameDlg:onCloseButton(sender, eventType)
  if self:getControl("StartButton"):isVisible() then
    gf:CmdToServer("CMD_SSWD_QUIT_GAME", {type = 1})
    return
  end
  gf:confirm(CHS[7100893], function()
    gf:CmdToServer("CMD_SSWD_QUIT_GAME", {type = 1})
  end)
end
function CaseWDGameDlg:cleanup()
  self.data = nil
  self.selectChess = nil
  self.putChess = {}
end
return CaseWDGameDlg
