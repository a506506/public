local BarrageSwitchDlg = Singleton("BarrageSwitchDlg", Dialog)
function BarrageSwitchDlg:init()
  local settingTable = SystemSettingMgr:getSettingStatus()
  local interchangeOn = true
  if settingTable.refuse_cross_year_msg == 1 then
    interchangeOn = false
  end
  self:createSwichButton(self:getControl("UseOpenStatePanel"), interchangeOn, self.onSystemSwichBtn)
  if interchangeOn and not BarrageTalkMgr:getBarrageLayer() then
    BarrageTalkMgr:creatBarrageLayer()
  end
end
function BarrageSwitchDlg:onSystemSwichBtn(isOn, key)
  if isOn then
    SystemSettingMgr:sendSeting("refuse_cross_year_msg", 0)
    if not BarrageTalkMgr:getBarrageLayer() then
      BarrageTalkMgr:creatBarrageLayer()
    end
  else
    SystemSettingMgr:sendSeting("refuse_cross_year_msg", 1)
    BarrageTalkMgr:removeBarrageLayer()
  end
end
function BarrageSwitchDlg:cleanup()
  BarrageTalkMgr:removeBarrageLayer()
end
function BarrageSwitchDlg:onBarrageOpenButton(sender, eventType)
  SystemSettingMgr:sendSeting("refuse_cross_year_msg", 0)
end
return BarrageSwitchDlg
