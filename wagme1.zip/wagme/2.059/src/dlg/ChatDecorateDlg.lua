local ChatDecorateDlg = Singleton("ChatDecorateDlg", Dialog)
local BAG_COL_NUM = 4
local ROW_MAGIN = 6.4
local COL_MAGIN = 6.4
local DEFAULT_ICON_PATH = ResMgr.ui.default_icon
local DEFAULT_ICON_NAME = ""
local DEFAULT_CHAT_PATH = ResMgr.ui.chat_def_back_groud
function ChatDecorateDlg:init()
  self:bindListener("ConfirmButton", self.onConfirmButton)
  self:bindListener("ChatButton", self.onChatButton)
  self:bindListener("IconButton", self.onIconButton)
  self:setCtrlVisible("ChosenEffectImage", false, "IconListPanel")
  self.itemPanel = self:retainCtrl("ItemPanel", nil, "IconListPanel")
  self:setCtrlVisible("ItemPanel", false, "IconListPanel")
  self:setCtrlVisible("ItemPanel", false, "ChatBKListPanel")
  self.curSelectIcon = ChatDecorateMgr:getIconDecorateUsed()
  self.curSelectChat = ChatDecorateMgr:getChatDecorateUsed()
  self:initDlgInfo()
end
function ChatDecorateDlg:initDlgInfo()
  self:initItemList(true)
  self:initItemList(false)
  local iconList = ChatDecorateMgr:getIconDecorateList()
  local chatList = ChatDecorateMgr:getChatDecorateList()
  if #chatList > 0 and #iconList == 0 then
    self:onChatButton()
  else
    self:onIconButton()
  end
  self:setImage("IconImage", ResMgr:getUserSmallPortrait(Me:queryBasicInt("polar"), Me:queryBasicInt("gender")), "OtherPanel")
  self:setItemImageSize("IconImage")
  self:setNumImgForPanel("LevelPanel", ART_FONT_COLOR.NORMAL_TEXT, Me:getLevel(), false, LOCATE_POSITION.LEFT_TOP, 21, "OtherPanel")
  self:setLabelText("NameLabel", Me:getShowName(), "OtherPanel")
  self:setImage("IconImage", ResMgr:getUserSmallPortrait(Me:queryBasicInt("polar"), Me:queryBasicInt("gender")), "SelfPanel")
  self:setItemImageSize("IconImage")
  self:setNumImgForPanel("LevelPanel", ART_FONT_COLOR.NORMAL_TEXT, Me:getLevel(), false, LOCATE_POSITION.LEFT_TOP, 21, "SelfPanel")
end
function ChatDecorateDlg:onSelectItem(sender, eventType)
  local scrollView = sender:getParent()
  local isIcon
  if sender:getParent():getParent():getParent():getName() == "IconListPanel" then
    isIcon = true
  elseif sender:getParent():getParent():getParent():getName() == "ChatBKListPanel" then
    isIcon = false
  end
  local listCtrl = scrollView:getChildren()
  for i = 1, #listCtrl do
    self:setCtrlVisible("ChosenEffectImage", false, listCtrl[i])
  end
  self:setCtrlVisible("ChosenEffectImage", true, sender)
  if isIcon then
    self.curSelectIcon = sender:getName()
  else
    self.curSelectChat = sender:getName()
  end
  self:refreshShowPanel(isIcon)
end
function ChatDecorateDlg:refreshShowPanel(isIcon)
  if isIcon then
    local iconSelect = self.curSelectIcon
    local iconPath
    if not iconSelect or iconSelect == "" or iconSelect == DEFAULT_ICON_NAME then
      self:setCtrlVisible("IconDecorateImage", false, "OtherPanel")
      self:setCtrlVisible("IconDecorateImage", false, "SelfPanel")
    else
      local itemInfo = InventoryMgr:getItemInfoByName(iconSelect)
      self:setImagePlist("IconDecorateImage", itemInfo.chat_icon, "OtherPanel")
      self:setImagePlist("IconDecorateImage", itemInfo.chat_icon, "SelfPanel")
      self:setCtrlVisible("IconDecorateImage", true, "OtherPanel")
      self:setCtrlVisible("IconDecorateImage", true, "SelfPanel")
    end
  else
    local chatSelect = self.curSelectChat
    local chatPath
    if not chatSelect or chatSelect == "" or chatSelect == DEFAULT_ICON_NAME then
      chatPath = DEFAULT_CHAT_PATH
      self:setImagePlist("TalkImage", chatPath, "OtherPanel")
      self:setImagePlist("TalkImage", chatPath, "SelfPanel")
    else
      local itemInfo = InventoryMgr:getItemInfoByName(chatSelect)
      chatPath = itemInfo.chat_icon
      local image1, image2
      if itemInfo.chat_icon_res_type == ccui.TextureResType.plistType then
        image1 = self:setImagePlist("TalkImage", chatPath, "OtherPanel")
        image2 = self:setImagePlist("TalkImage", chatPath, "SelfPanel")
      else
        image1 = self:setImage("TalkImage", chatPath, "OtherPanel")
        image2 = self:setImage("TalkImage", chatPath, "SelfPanel")
      end
      image1:setCapInsets(cc.rect(48, 40, 2, 2))
      image2:setCapInsets(cc.rect(48, 40, 2, 2))
    end
  end
  local name
  if isIcon then
    name = self.curSelectIcon == DEFAULT_ICON_NAME and CHS[7120044] or self.curSelectIcon
  else
    name = self.curSelectChat == DEFAULT_ICON_NAME and CHS[7120045] or self.curSelectChat
  end
  self:setLabelText("UseLable", name, "InfoPanel")
  self:setLabelText("TimeLable", ChatDecorateMgr:getDecorateLeftTime(name, isIcon), "InfoPanel")
end
function ChatDecorateDlg:initItemList(isIcon)
  local listData, listCtrl
  if isIcon then
    listData = ChatDecorateMgr:getIconDecorateList()
    listCtrl = self:getControl("ItemsScrollView", nil, "IconListPanel")
  else
    listData = ChatDecorateMgr:getChatDecorateList()
    listCtrl = self:getControl("ItemsScrollView", nil, "ChatBKListPanel")
  end
  listCtrl:removeAllChildren()
  local count = #listData + 1
  local row = math.ceil(count / BAG_COL_NUM)
  local contentSize = self.itemPanel:getContentSize()
  local listContentSize = listCtrl:getContentSize()
  local innerHeight = math.max(row * (COL_MAGIN + contentSize.height) + COL_MAGIN, listContentSize.height)
  listCtrl:setInnerContainerSize({
    width = listContentSize.width,
    height = innerHeight
  })
  local defaultItem = self.itemPanel:clone()
  defaultItem:setPosition(ROW_MAGIN, innerHeight - contentSize.height - COL_MAGIN)
  listCtrl:addChild(defaultItem)
  defaultItem:setName(DEFAULT_ICON_NAME)
  self:setItemInfo(defaultItem, DEFAULT_ICON_NAME)
  self:bindListener(DEFAULT_ICON_NAME, self.onSelectItem, listCtrl)
  if isIcon and (not self.curSelectIcon or self.curSelectIcon == "") or not isIcon and (not self.curSelectChat or self.curSelectChat == "") then
    self:onSelectItem(defaultItem)
  end
  for i = 1, #listData do
    local item = self.itemPanel:clone()
    local newY = math.ceil((i + 1) / BAG_COL_NUM)
    local newX = (i + 1) % BAG_COL_NUM
    if newX == 0 then
      newX = BAG_COL_NUM or newX
    end
    item:setPosition(ROW_MAGIN + (newX - 1) * (contentSize.width + ROW_MAGIN), innerHeight - newY * (contentSize.height + COL_MAGIN))
    listCtrl:addChild(item)
    item:setName(listData[i].name)
    self:setItemInfo(item, listData[i].name)
    self:blindLongPress(item, self.onLongPressItem, self.onSelectItem, listCtrl)
    if self.curSelectChat == listData[i].name or self.curSelectIcon == listData[i].name then
      self:onSelectItem(item)
    end
  end
end
function ChatDecorateDlg:setItemInfo(ctrl, itemName)
  local iconPath
  if itemName == DEFAULT_ICON_NAME then
    iconPath = DEFAULT_ICON_PATH
  else
    iconPath = ResMgr:getItemIconPath(InventoryMgr:getIconByName(itemName))
  end
  self:setImage("IconImage", iconPath, ctrl)
  self:setItemImageSize("IconImage", ctrl)
end
function ChatDecorateDlg:onLongPressItem(sender)
  if sender then
    local itemName = sender:getName()
    local itemInfo = InventoryMgr:getItemInfoByName(itemName)
    itemInfo.name = itemName
    local rect = self:getBoundingBoxInWorldSpace(sender)
    InventoryMgr:showItemByItemData(itemInfo, rect)
  end
end
function ChatDecorateDlg:onIconButton(sender, eventType)
  self:setCtrlVisible("IconImage", true, "TabPanel")
  self:setCtrlVisible("ChatImage", false, "TabPanel")
  self:setCtrlVisible("IconListPanel", true)
  self:setCtrlVisible("ChatBKListPanel", false)
  self:refreshShowPanel(true)
end
function ChatDecorateDlg:onChatButton(sender, eventType)
  self:setCtrlVisible("IconImage", false, "TabPanel")
  self:setCtrlVisible("ChatImage", true, "TabPanel")
  self:setCtrlVisible("IconListPanel", false)
  self:setCtrlVisible("ChatBKListPanel", true)
  self:refreshShowPanel(false)
end
function ChatDecorateDlg:onConfirmButton(sender, eventType)
  if self.curSelectIcon == ChatDecorateMgr:getIconDecorateUsed() and self.curSelectChat == ChatDecorateMgr:getChatDecorateUsed() then
    self:onCloseButton()
    return
  end
  if ChatDecorateMgr:isIconTimeOver(self.curSelectIcon) then
    self:onIconButton()
    local listCtrl = self:getControl("ItemsScrollView", nil, "IconListPanel")
    local listItem = listCtrl:getChildren()
    if listItem and listItem[1] then
      self:onSelectItem(listItem[1])
    end
    gf:ShowSmallTips(CHS[7120042])
    ChatMgr:sendMiscMsg(CHS[7120042])
    return
  end
  if ChatDecorateMgr:isChatTimeOver(self.curSelectChat) then
    self:onIconButton()
    local listCtrl = self:getControl("ItemsScrollView", nil, "ChatBKListPanel")
    local listItem = listCtrl:getChildren()
    if listItem and listItem[1] then
      self:onSelectItem(listItem[1])
    end
    gf:ShowSmallTips(CHS[7120043])
    ChatMgr:sendMiscMsg(CHS[7120043])
    return
  end
  gf:CmdToServer("CMD_DECORATION_APPLY", {
    count = 2,
    list = {
      {
        type = "chat_head",
        name = self.curSelectIcon
      },
      {
        type = "chat_floor",
        name = self.curSelectChat
      }
    }
  })
  self:onCloseButton()
end
return ChatDecorateDlg
