local BaoscclDlg = Singleton("BaoscclDlg", Dialog)
local DEMS = {
  ResMgr.ui.bsccl_gem_red,
  ResMgr.ui.bsccl_gem_green,
  ResMgr.ui.bsccl_gem_yellow
}
function BaoscclDlg:init()
  self:bindListener("ExchangeButton", self.onExchangeButton)
  self:bindListener("MoneyPanel", self.onExchangeButton)
  self:bindListener("SweetPanel", self.onSweetPanel)
  self:bindListener("RuleButton", self.onRuleButton)
  self:bindListener("UnitPanel1", self.onUnitPanel1)
  self.unitPanel = self:retainCtrl("UnitPanel1")
  self:retainCtrl("UnitPanel2")
  self:retainCtrl("UnitPanel3")
  self.playItemsCou = 0
  self:initView()
  self:hookMsg("MSG_GHOST_2020_BSCCL_DATA")
end
function BaoscclDlg:cleanup()
  self.cells = nil
  self.data = nil
  DlgMgr:closeDlg("BaoscclShopDlg")
  DlgMgr:closeDlg("BaoscclgmDlg")
end
function BaoscclDlg:onUnitPanel1(sender, eventType)
  if self.playItemsCou > 0 then
    return
  end
  if self:checkEndTime() then
    return
  end
  if Me:getLevel() < 30 then
    gf:ShowSmallTips(CHS[5410654])
    return
  end
  local tag = sender:getTag()
  gf:CmdToServer("CMD_GHOST2020_OPEN_BAOSHI", {index = tag})
end
function BaoscclDlg:onExchangeButton(sender, eventType)
  if not self.data then
    return true
  end
  if self:checkEndTime() then
    return
  end
  gf:CmdToServer("CMD_GHOST2020_OPEN_SHOP")
end
function BaoscclDlg:onSweetPanel(sender, eventType)
  if self:checkEndTime() then
    return
  end
  local dlg = DlgMgr:openDlgEx("BaoscclgmDlg")
  dlg:setData(self.data)
end
function BaoscclDlg:onRuleButton(sender, eventType)
  if not self.data then
    return
  end
  ShowRuleDlgMgr:openDlg("BaoscclRuleDlg", function(cfgInfo)
    for i = 1, #cfgInfo do
      if string.match(cfgInfo[i].text, "YYYY1%-MM1%-YY1 HH:MM") then
        cfgInfo[i].text = string.gsub(cfgInfo[i].text, "YYYY1%-MM1%-YY1 HH:MM", gf:getServerDate("%Y-%m-%d %H:%M", self.data.act_end_time))
      elseif string.match(cfgInfo[i].text, "YYYY2%-MM2%-YY2 HH:MM") then
        cfgInfo[i].text = string.gsub(cfgInfo[i].text, "YYYY2%-MM2%-YY2 HH:MM", gf:getServerDate("%Y-%m-%d %H:%M", self.data.act_bonus_time))
      end
    end
  end)
end
function BaoscclDlg:checkEndTime()
  if not self.data then
    return true
  end
  if gf:getServerTime() > self.data.act_end_time then
    gf:ShowSmallTips(CHS[5410653])
    self:onCloseButton()
    return true
  end
end
function BaoscclDlg:creatCharDragonBones(icon, offPos, panel)
  local panel = panel or self:getControl("PortraitPanel")
  local magic = panel:getChildByName("charPortrait")
  if magic then
    if magic:getTag() == icon then
      return
    else
      magic:removeFromParent()
    end
  end
  local icon = icon or 6018
  local dbMagic = DragonBonesMgr:createCharDragonBones(icon, string.format("%05d", icon))
  if not dbMagic then
    return
  end
  local magic = tolua.cast(dbMagic, "cc.Node")
  magic:setPosition(panel:getContentSize().width * 0.5 + offPos.x, panel:getContentSize().height * 0.5 + offPos.y)
  magic:setName("charPortrait")
  magic:setTag(icon)
  magic:setScale(0.65)
  panel:addChild(magic)
  DragonBonesMgr:toPlay(dbMagic, "stand", 0)
end
function BaoscclDlg:initView()
  self:creatCharDragonBones(6240, cc.p(0, -150))
  local panel = self:getControl("OperatePanel")
  self.cells = {}
  local size = self.unitPanel:getContentSize()
  local initX, initY = self.unitPanel:getPosition()
  local x, y, cell, tag
  for i = 1, 4 do
    for j = 1, 4 do
      tag = (j - 1) * 4 + i
      x = initX + (i - 1) * (size.width - 3)
      y = initY - (j - 1) * (size.height - 3)
      cell = self.unitPanel:clone()
      cell:setPosition(x, y)
      cell:setTag(tag)
      self:setCtrlVisible("CoverImage", true, cell)
      panel:addChild(cell)
      self.cells[tag] = cell
    end
  end
end
function BaoscclDlg:getGenIcon(level)
  if level == 1 then
    return ResMgr.ui.bsccl_gem_red
  elseif level == 2 then
    return ResMgr.ui.bsccl_gem_green
  else
    return ResMgr.ui.bsccl_gem_yellow
  end
end
function BaoscclDlg:updateView(data)
  local tag, cell
  for i = 1, 4 do
    for j = 1, 4 do
      tag = (j - 1) * 4 + i
      cell = self.cells[tag]
      if cell then
        if data.open_list[tag] then
          if data.from == "open" and self.data and not self.data.open_list[tag] then
            local sz = cell:getContentSize()
            local x, y = cell:getPosition()
            local magic = gf:createSelfRemoveMagic(ResMgr.magic.baosccl_open, {blendMode = "add"})
            magic:setPosition(x + sz.width / 2, y + sz.height / 2)
            cell:getParent():addChild(magic, 100, 100)
          end
          self:setImagePlist("StoneImage", self:getGenIcon(data.open_list[tag]), cell)
          self:setCtrlVisible("CoverImage", false, cell)
        else
          self:setCtrlVisible("CoverImage", true, cell)
        end
      end
    end
  end
  self:setLabelText("NumLabel", data.tg_num, "SweetPanel")
end
function BaoscclDlg:showOwnCash(num)
  if not self.data then
    return
  end
  if self.playItemsCou == 0 or num then
    self:setLabelText("NumLabel", num or self.data.tb_num, "MoneyPanel")
  end
end
function BaoscclDlg:playAction(data, cash)
  local amount = 9
  local level = 1
  if cash == 300 then
    amount = 6
    level = 2
  elseif cash == 100 then
    amount = 3
    level = 3
  end
  local panel = self:getControl(string.format("ContentPanel_%d", level))
  local cashImg = self:getControl("Image_2", nil, panel)
  local rect = cashImg:getBoundingBox()
  local pos = cashImg:convertToWorldSpace(cc.p(rect.width / 2, rect.height / 2))
  pos = self.blank:convertToNodeSpace(pos)
  local oneNum = cash / amount
  local function func()
    local cell = cashImg:clone()
    cell:setPosition(pos.x, pos.y)
    self.blank:addChild(cell, 20)
    local coinImage = self:getControl("MoneyImage", nil, "MoneyPanel")
    local destPos = coinImage:getParent():convertToWorldSpace(cc.p(coinImage:getPosition()))
    destPos = self.blank:convertToNodeSpace(destPos)
    local time = gf:distance(destPos.x, destPos.y, pos.x, pos.y) / 400
    local isLast = amount == 1
    local action = cc.Sequence:create(cc.BezierTo:create(time, {
      pos,
      cc.p(destPos.x, pos.y),
      destPos
    }), cc.CallFunc:create(function()
      local num = tonumber(self:getLabelText("NumLabel", "MoneyPanel")) or 0
      num = num + oneNum
      self:showOwnCash(math.floor(num))
      if isLast then
        self.playItemsCou = self.playItemsCou - 1
        self:showOwnCash()
        if self.playItemsCou == 0 and self.data then
          self:updateView(self.data)
        end
      end
    end), cc.RemoveSelf:create())
    cell:runAction(action)
    amount = amount - 1
    if amount > 0 then
      performWithDelay(self.root, function()
        func()
      end, 0.06)
    end
  end
  self.playItemsCou = self.playItemsCou + 1
  local num = {
    0,
    0,
    0
  }
  local type, tag, cell
  for i = 1, 4 do
    for j = 1, 4 do
      tag = (j - 1) * 4 + i
      if data.open_list[tag] then
        num[data.open_list[tag]] = num[data.open_list[tag]] + 1
        if num[data.open_list[tag]] == 3 then
          type = data.open_list[tag]
          break
        end
      end
    end
    if type then
      break
    end
  end
  local index = 0
  if type then
    performWithDelay(self.root, function()
      for i = 1, 4 do
        for j = 1, 4 do
          tag = (j - 1) * 4 + i
          cell = self.cells[tag]
          if cell and data.open_list[tag] == type then
            local sz = cell:getContentSize()
            index = index + 1
            local magic = gf:createCallbackMagic(ResMgr.magic.baosccl_succ, function(magic)
              index = index - 1
              magic:removeFromParent()
              if index == 0 then
                func()
                for i = 1, 4 do
                  for j = 1, 4 do
                    tag = (j - 1) * 4 + i
                    local cell = self.cells[tag]
                    if data.open_list[tag] then
                      local img = self:setCtrlVisible("CoverImage", true, cell)
                      img:setOpacity(0)
                      img:runAction(cc.FadeIn:create(0.26))
                    end
                  end
                end
              end
            end, {blendMode = "add"})
            local x, y = cell:getPosition()
            magic:setPosition(x + sz.width / 2, y + sz.height / 2)
            cell:getParent():addChild(magic, 100, 100)
          end
        end
      end
    end, 0.5)
  end
end
function BaoscclDlg:MSG_GHOST_2020_BSCCL_DATA(data)
  if data.from == "alarm" then
    return
  end
  if self.playItemsCou > 0 then
    self.data = data
    return
  end
  if data.from == "add_tb" and self.data then
    self:playAction(self.data, data.tb_num - self.data.tb_num)
  end
  self:updateView(data)
  self.data = data
  if data.from == "add_tb" then
    data.open_list = {}
  end
  self:showOwnCash()
  if data.open_rule_flag == 1 then
    self:onRuleButton()
  end
end
return BaoscclDlg
