local DiFuPointDlg = Singleton("DiFuPointDlg", Dialog)
local PROGRESS = {
  [20] = 17,
  [40] = 37,
  [60] = 56,
  [80] = 75,
  [100] = 94
}
local TASK_INFO = {
  [1] = {
    img = ResMgr.ui.simple_banner
  },
  [2] = {
    img = ResMgr.ui.simple_banner
  },
  [3] = {
    img = ResMgr.ui.normal_banner
  },
  [4] = {
    img = ResMgr.ui.simple_banner
  },
  [5] = {
    img = ResMgr.ui.normal_banner
  },
  [6] = {
    img = ResMgr.ui.difficult_banner
  },
  [7] = {
    img = ResMgr.ui.normal_banner
  },
  [8] = {
    img = ResMgr.ui.simple_banner
  },
  [9] = {
    img = ResMgr.ui.simple_banner
  },
  [10] = {
    img = ResMgr.ui.simple_banner
  },
  [11] = {
    img = ResMgr.ui.normal_banner
  },
  [12] = {
    img = ResMgr.ui.normal_banner
  },
  [13] = {
    img = ResMgr.ui.normal_banner
  }
}
local REWARD_IMAGE = {
  [1] = {
    [1] = ResMgr.ui.copper_close_box,
    [2] = ResMgr.ui.copper_open_box
  },
  [2] = {
    [1] = ResMgr.ui.copper_close_box,
    [2] = ResMgr.ui.copper_open_box
  },
  [3] = {
    [1] = ResMgr.ui.silver_close_box,
    [2] = ResMgr.ui.silver_open_box
  },
  [4] = {
    [1] = ResMgr.ui.silver_close_box,
    [2] = ResMgr.ui.silver_open_box
  },
  [5] = {
    [1] = ResMgr.ui.gold_close_box,
    [2] = ResMgr.ui.gold_open_box
  }
}
function DiFuPointDlg:init()
  self:bindListener("StrategyButton", self.onStrategyButton)
  self:bindListViewListener("TaskListView", self.onSelectTaskListView)
  self.workUnit = self:retainCtrl("WorkUnitPanel", "TaskListView")
  self:bindListener("GoButton", self.onGoButton, self.workUnit)
  gf:CmdToServer("CMD_REQUEST_DIFU_LILIAN_INFO")
  GiftMgr.lastIndex = "WelfareButton32"
  GiftMgr:setLastTime()
  self:setCtrlVisible("MainPanel", false)
  self:MSG_NOTIFY_DIFU_LILIAN_INFO()
  self:hookMsg("MSG_NOTIFY_DIFU_LILIAN_INFO")
end
function DiFuPointDlg:onGoButton(sender, eventType)
  if not sender or not sender:getParent() then
    return
  end
  local itemPanel = sender:getParent()
  local data = itemPanel.data
  if not data then
    return
  end
  if data.taskNo == 1 then
    gf:ShowSmallTips(CHS[4200883])
  elseif data.taskNo == 2 then
    gf:ShowSmallTips(CHS[4200884])
  elseif data.taskNo == 3 then
    if not ShenHunMgr:isShenHunOpen() then
      gf:ShowSmallTips(CHS[4200885])
      return
    end
    DlgMgr:openDlg("InnerAlchemyDlg")
    self:onCloseButton()
  elseif data.taskNo == 4 then
    if not GuideMgr:isIconExist(37) then
      gf:ShowSmallTips(CHS[4200891])
      return
    end
    DlgMgr:sendMsg("GameFunctionDlg", "onHorcruxButton")
    self:onCloseButton()
  elseif data.taskNo == 5 then
    if not next(PetMgr.ghostPets) then
      gf:ShowSmallTips(CHS[4200892])
      return
    end
    local dlg = DlgMgr:openDlg("PetAttribDlg")
    local petList = DlgMgr:openDlg("PetListChildDlg")
    petList:setSelectType(PET_LOCATE.DIFU)
    self:onCloseButton()
  elseif data.taskNo >= 6 and data.taskNo <= 9 then
    local activityData = ActivityMgr:getActivityByName(CHS[5400835])
    if activityData and ActivityMgr:doGoto(activityData) then
      self:onCloseButton()
    end
  elseif data.taskNo >= 10 and data.taskNo <= 13 then
    local activityData = ActivityMgr:getActivityByName(CHS[7190752])
    if activityData and ActivityMgr:doGoto(activityData) then
      self:onCloseButton()
    end
  end
end
function DiFuPointDlg:onStrategyButton(sender, eventType)
  gf:openUrlByType(OPEN_URL_TYPE.URL_PARA, "https://vwd.leiting.com/index?redirect_url=/difu_topic")
end
function DiFuPointDlg:onSelectTaskListView(sender, eventType)
end
function DiFuPointDlg:setUnitData(item, task, bonus, isShowState)
  self:setLabelText("NameLabel", string.format("%s(%d/%d)", task.taskName, math.min(task.completedCount, task.maxCount), task.maxCount), item)
  self:setLabelText("PointLabel", task.rewardScore, item)
  self:setCtrlVisible("StateImage1", isShowState and task.completedCount >= task.maxCount, item)
  self:setCtrlVisible("StateImage2", isShowState and task.completedCount < task.maxCount, item)
  self:setCtrlVisible("GoButton", isShowState and task.completedCount < task.maxCount, item)
  self:setImage("HardImage", TASK_INFO[task.taskNo].img, item)
  item.data = task
end
function DiFuPointDlg:refreshListView(isShowState)
  local listView = self:resetListView("TaskListView")
  local livenessInfo = GiftMgr.difuPointData
  if not livenessInfo then
    return
  end
  local item
  for i = 1, #livenessInfo.taskInfo do
    item = self.workUnit:clone()
    self:setUnitData(item, livenessInfo.taskInfo[i], livenessInfo.rewadInfo[i], isShowState)
    listView:pushBackCustomItem(item)
  end
end
function DiFuPointDlg:refreshBonus()
  local livenessInfo = GiftMgr.difuPointData
  if not livenessInfo then
    return
  end
  local scoreText = gf:getArtFontMoneyDesc(tonumber(livenessInfo.curScore))
  self:setNumImgForPanel("NumPanel", ART_FONT_COLOR.DEFAULT, scoreText, false, LOCATE_POSITION.MID, 23)
  local curValue = math.floor(livenessInfo.curScore)
  self:setProgressBar("activityProgressBar", self:getProgress(curValue), 100)
  local activeValueImage = self:getControl("ActiveValueImage")
  self:setLabelText("Label_1", curValue, activeValueImage)
  self:setLabelText("Label_2", curValue, activeValueImage)
  local activeProgress = self:getControl("activityProgressBar")
  local posx = activeProgress:getContentSize().width * self:getProgress(curValue) / 100
  activeValueImage:setPositionX(posx)
  local reward = livenessInfo.rewadInfo
  for i = 1, #reward do
    do
      local rewardPanel = self:getControl(string.format("RewardPanel%d", i), Const.UIPanel)
      local rewardItemPanel = self:getControl("RewardItemPanel", Const.UIPanel, rewardPanel)
      local image = self:getControl("BonusImage", Const.UIImage, rewardPanel)
      rewardItemPanel:setTag(i)
      local key = reward[i]
      if reward[i] then
        local path
        if reward[i].status == 2 then
          path = REWARD_IMAGE[i][2]
        else
          path = REWARD_IMAGE[i][1]
        end
        image:loadTexture(path)
        gf:setItemImageSize(image)
      end
      if reward[i] and reward[i].status == 2 then
        self:setCtrlVisible("CoverImage", true, rewardPanel)
        self:removeMagic(rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
      elseif reward[i] and reward[i].status == 1 then
        self:setCtrlVisible("CoverImage", false, rewardPanel)
        gf:createArmatureMagic(ResMgr.ArmatureMagic.item_around, rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
      else
        self:setCtrlVisible("CoverImage", false, rewardPanel)
        self:removeMagic(rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
      end
      local function showItemInfo(sender, type)
        if ccui.TouchEventType.ended == type then
          if not DistMgr:checkCrossDist() then
            return
          end
          if reward[i] and reward[i].status == 1 then
            gf:CmdToServer("CMD_FETCH_DIFU_LILIAN_BONUS", {rewardNo = i})
            self:removeMagic(rewardItemPanel, Const.ARMATURE_MAGIC_TAG)
          else
            local dlg = DlgMgr:openDlgEx("BonusInfo3Dlg", reward[i].reward)
          end
          if GiftMgr.difuPointData and gf:getServerTime() > GiftMgr.difuPointData.closeTime then
            self:onCloseButton()
          end
        end
      end
      rewardItemPanel:addTouchEventListener(showItemInfo)
    end
  end
end
function DiFuPointDlg:getProgress(curValue)
  if curValue <= 20 then
    return curValue / 20 * PROGRESS[20]
  elseif curValue <= 40 then
    return PROGRESS[20] + (curValue - 20) / 20 * (PROGRESS[40] - PROGRESS[20])
  elseif curValue <= 60 then
    return PROGRESS[40] + (curValue - 40) / 20 * (PROGRESS[60] - PROGRESS[40])
  elseif curValue <= 80 then
    return PROGRESS[60] + (curValue - 60) / 20 * (PROGRESS[80] - PROGRESS[60])
  elseif curValue <= 100 then
    return PROGRESS[80] + (curValue - 80) / 20 * (PROGRESS[100] - PROGRESS[80])
  else
    return math.min(100, PROGRESS[100] + (curValue - 100) / 7 * (100 - PROGRESS[100]))
  end
end
function DiFuPointDlg:MSG_NOTIFY_DIFU_LILIAN_INFO(data)
  self:refreshListView(nil ~= data)
  self:refreshBonus()
  data = data or GiftMgr.difuPointData
  if not data then
    return
  end
  self:setCtrlVisible("MainPanel", true)
  local startTimeStr = gf:getServerDate(CHS[7150119], data.openTime)
  local endTimeStr = gf:getServerDate(CHS[7150119], data.closeTime)
  local timeStr = string.format(CHS[4200886], startTimeStr, endTimeStr)
  self:setLabelText("NoteLabel", timeStr, panel)
end
return DiFuPointDlg
