local FireworksRewardDlg = Singleton("FireworksRewardDlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
function FireworksRewardDlg:init(data)
  self:bindListener("NeiceLeaveButton", self.onCloseButton)
  local lightEffect = self:getControl("LightEffectImage2")
  local rotate = cc.RotateBy:create(15, 360)
  local action = cc.RepeatForever:create(rotate)
  lightEffect:runAction(action)
  self:setItemView(data.reward)
  DlgMgr:closeDlg("FireworksCountdownDlg")
end
function FireworksRewardDlg:onClickBlank()
  return true
end
function FireworksRewardDlg:setItemView(reward)
  local classList = TaskMgr:getRewardList(reward)
  if not classList[1] or not next(classList[1]) then
    return
  end
  for i = 1, 3 do
    self:setCtrlVisible("RewardPanel" .. i, false)
  end
  local count = #classList[1]
  for i = 1, count do
    local panel = count == 1 and self:getControl("RewardPanel3") or self:getControl("RewardPanel" .. i)
    panel:setVisible(true)
    reward = classList[1][i]
    local imgPath, textureResType = RewardContainer:getRewardPath(reward)
    if textureResType == ccui.TextureResType.plistType then
      self:setImagePlist("Reward1Image", imgPath, panel)
    else
      self:setImage("Reward1Image", imgPath, panel)
    end
    local itemInfoList = gf:splitBydelims(reward[2], {
      "%",
      "$",
      "#r"
    })
    local item = TaskMgr:spliteItemInfo(itemInfoList, reward)
    if item.name == CHS[6400071] then
      self:setLabelText("Reward1Label", string.format("x%s", item.number), panel)
    else
      self:setLabelText("Reward1Label", item.name, panel)
    end
    local img = self:getControl("Reward1Image", nil, panel)
    img.reward = reward
    self:bindTouchEndEventListener(img, function(dlg, sender, eventType)
      RewardContainer:imagePanelTouch(sender, eventType)
    end)
  end
end
return FireworksRewardDlg
