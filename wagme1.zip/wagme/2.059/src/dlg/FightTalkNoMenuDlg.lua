local NpcDlg = require("dlg/NpcDlg")
local FightTalkNoMenuDlg = Singleton("FightTalkNoMenuDlg", NpcDlg)
function FightTalkNoMenuDlg:getCfgFileName()
  return ResMgr:getDlgCfg("NpcDlg")
end
function FightTalkNoMenuDlg:createMenuItem(text, id, key)
end
function FightTalkNoMenuDlg:cleanup()
  NpcDlg.cleanup(self)
  GFightMgr:EndCurUnit("GUnitObjWait")
end
return FightTalkNoMenuDlg
