local EffectFurnitureRuleDlg = Singleton("EffectFurnitureRuleDlg", Dialog)
function EffectFurnitureRuleDlg:init()
  self.ruleOne = self:getControl("RulePanel1", nil, "MainPanel")
end
function EffectFurnitureRuleDlg:setRuleByType(type)
  self:setCtrlVisible("RulePanel1", type == 1, "MainPanel")
  self:setCtrlVisible("RulePanel2", type == 2, "MainPanel")
  self:setCtrlVisible("RulePanel3", type == 3, "MainPanel")
end
return EffectFurnitureRuleDlg
