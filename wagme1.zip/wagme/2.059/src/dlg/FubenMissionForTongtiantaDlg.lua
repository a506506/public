local FubenMissionDlg = require("dlg/FubenMissionDlg")
local FubenMissionForTongtiantaDlg = Singleton("FubenMissionForTongtiantaDlg", FubenMissionDlg)
function FubenMissionForTongtiantaDlg:getCfgFileName()
  return ResMgr:getDlgCfg("FubenMissionForTongtiantaDlg")
end
function FubenMissionForTongtiantaDlg:init()
  FubenMissionDlg.init(self)
  self.isBuyLingPai = nil
  self:bindListener("FlyButton", self.onFlyButton)
  self:bindListener("InfoButton", self.onInfoButton)
  self:bindListener("ChangeButton", self.onChangeButton)
  self:bindTongtiantaButtons()
  self:hookMsg("MSG_TONGTIANTA_INFO")
  self:hookMsg("MSG_OPEN_FEISHENG_DLG")
  self:hookMsg("MSG_STALL_BUY_RESULT")
end
function FubenMissionForTongtiantaDlg:onCheckBox(sender, eventType)
  self:setCtrlVisible("LevelInfoPanel", sender:getName() == "MissionCheckBox")
  self:setCtrlVisible("TeamPanel", sender:getName() == "TeamCheckBox")
  if self.lastCheckBox == sender:getName() then
    if sender:getName() == "MissionCheckBox" then
      DlgMgr:openDlg("TaskDlg")
    elseif sender:getName() == "TeamCheckBox" then
      DlgMgr:openDlg("TeamDlg")
    end
  end
  if sender:getName() == "MissionCheckBox" then
    self:setCtrlVisible("UnChosenImage", true, "TeamCheckBox")
    self:setCtrlVisible("ChosenImage", false, "TeamCheckBox")
    self:setCtrlVisible("UnChosenImage", false, "MissionCheckBox")
    self:setCtrlVisible("ChosenImage", true, "MissionCheckBox")
    self:onMissionButton(sender)
  elseif sender:getName() == "TeamCheckBox" then
    self:setCtrlVisible("UnChosenImage", false, "TeamCheckBox")
    self:setCtrlVisible("ChosenImage", true, "TeamCheckBox")
    self:setCtrlVisible("UnChosenImage", true, "MissionCheckBox")
    self:setCtrlVisible("ChosenImage", false, "MissionCheckBox")
    self:onTeamButton(sender)
  end
  self.lastCheckBox = sender:getName()
end
function FubenMissionForTongtiantaDlg:onChallengeButton(sender, eventType)
  if not self.info then
    return
  end
  TaskMgr:setIsAutoChallengeTongtian(true)
  if self.info.curType == 2 then
    gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_TTT_GO_NEXT_LAYER)
  else
    local task = TaskMgr:getTongtianTowerTaskInfo()
    if task and task.task_prompt then
      if MapMgr:isInMapByName(CHS[4010293]) and self.info and self.info.hasNotCompletedSmfj ~= 1 then
        AutoWalkMgr:beginAutoWalk(gf:findDest(CHS[4101291]))
      elseif MapMgr:isInMapByName(CHS[4010293]) then
        local beidouNpc = CharMgr:getCharByName(CHS[4200636])
        if beidouNpc and not beidouNpc.visible and CharMgr:getCharByName(CHS[4010302]) then
          AutoWalkMgr:beginAutoWalk(gf:findDest(CHS[4200637]))
        else
          AutoWalkMgr:beginAutoWalk(gf:findDest(task.task_prompt))
        end
      else
        AutoWalkMgr:beginAutoWalk(gf:findDest(task.task_prompt))
      end
    end
  end
end
function FubenMissionForTongtiantaDlg:bindTongtiantaButtons()
  local function resFunc(sender, eventType)
    self:getControl("ChallengePanel"):setScale(1)
  end
  self:blindLongPressTakView(self:getControl("ChallengePanel"), nil, self.onChallengeButton, resFunc)
end
function FubenMissionForTongtiantaDlg:isInMMFJ()
  return MapMgr:isInMapByName(CHS[4010293])
end
function FubenMissionForTongtiantaDlg:blindLongPressTakView(widget, OneSecondLaterFunc, func, resFunc)
  if not widget then
    return
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.began then
      local callFunc = cc.CallFunc:create(function()
        if OneSecondLaterFunc then
          OneSecondLaterFunc(self, sender, eventType)
        end
        widget:stopAction(self.longPress)
        self.longPress = nil
      end)
      widget:setScale(0.95)
      self.longPress = cc.Sequence:create(cc.DelayTime:create(1), callFunc)
      widget:runAction(self.longPress)
    elseif eventType == ccui.TouchEventType.ended then
      if self.longPress ~= nil then
        self.root:stopAction(self.longPress)
        self.longPress = nil
        func(self, sender, eventType)
      end
      widget:setScale(1)
    elseif eventType == ccui.TouchEventType.moved then
    elseif resFunc then
      resFunc(self, sender, eventType)
    end
  end
  widget:addTouchEventListener(listener)
end
function FubenMissionForTongtiantaDlg:setBuyLingPai(isBuy)
  self.isBuyLingPai = isBuy
end
function FubenMissionForTongtiantaDlg:MSG_STALL_BUY_RESULT(data)
  if self.isBuyLingPai and data.result == 1 and data.goods_name == CHS[7000081] then
    DlgMgr:closeDlg("MarketBuyDlg")
    self.isBuyLingPai = nil
    self:onChangeButton()
  end
end
function FubenMissionForTongtiantaDlg:MSG_OPEN_FEISHENG_DLG(data)
  local dlg = DlgMgr:openDlg("TongtiantaFlyDlg")
  dlg:setData(self.info)
end
function FubenMissionForTongtiantaDlg:MSG_TONGTIANTA_INFO(data)
  self:setCtrlVisible("MissionButton", false)
  self:setCtrlVisible("TongtiantaButton", true)
  self.info = data
  self:displayTongtianta(data)
  Me.lastPaths = nil
end
function FubenMissionForTongtiantaDlg:getTowerType(data)
  if data.curLayer < data.breakLayer then
    return CHS[3003134]
  elseif data.curLayer == data.breakLayer then
    if data.curType == 2 then
      return CHS[3003135]
    else
      return CHS[3003134]
    end
  else
    return CHS[3003135]
  end
end
function FubenMissionForTongtiantaDlg:displayTongtianta(data)
  local towerPanel = self:getControl("LevelInfoPanel")
  if self:isInMMFJ() then
    self:setLabelText("BreachLevelLabel", CHS[4010293], towerPanel)
    if data.hasNotCompletedSmfj == 1 then
      self:setLabelText("CurrentLabel", CHS[4010294], towerPanel)
    else
      self:setLabelText("CurrentLabel", CHS[4101287], towerPanel)
    end
  else
    local towerType = self:getTowerType(data)
    local towerLevelStr = towerType .. " " .. data.curLayer .. "/" .. data.breakLayer
    self:setLabelText("BreachLevelLabel", towerLevelStr, towerPanel)
    self:setLabelText("CurrentLabel", CHS[3003136] .. data.npc, towerPanel)
  end
  if data.curType == 1 then
    self:setCtrlVisible("ChallengeButton", true)
    self:setCtrlVisible("ReChallengeButton", false)
    self:setCtrlVisible("NextLevelButton", false)
  elseif data.curType == 3 then
    self:setCtrlVisible("ChallengeButton", false)
    self:setCtrlVisible("ReChallengeButton", true)
    self:setCtrlVisible("NextLevelButton", false)
    self:setLabelText("CurrentLabel", string.format(CHS[3003137], data.npc, data.challengeCount), towerPanel)
  else
    self:setCtrlVisible("ChallengeButton", false)
    self:setCtrlVisible("ReChallengeButton", false)
    self:setCtrlVisible("NextLevelButton", true)
    self:setLabelText("CurrentLabel", CHS[3003138], towerPanel)
  end
  if data.bonusType == "exp" then
    self:setLabelText("NameLabel", CHS[4300081], towerPanel)
  elseif data.bonusType == "tao" then
    self:setLabelText("NameLabel", CHS[4300082], towerPanel)
  end
  towerPanel:requestDoLayout()
end
function FubenMissionForTongtiantaDlg:onLeaveButton(sender, eventType)
  if TeamMgr:isTeamMeber(Me) then
    gf:ShowSmallTips(CHS[3003127])
    return
  end
  gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_TTT_LEAVE_TOWER)
end
function FubenMissionForTongtiantaDlg:onFlyButton(sender, eventType)
  if self:isInMMFJ() then
    gf:ShowSmallTips(CHS[4010292])
    return
  end
  if not self.info then
    return
  end
  if TeamMgr:isTeamMeber(Me) then
    gf:ShowSmallTips(CHS[3003127])
    return
  end
  if self.info.curType ~= 2 then
    gf:ShowSmallTips(CHS[3003129])
    return
  end
  local dlg = DlgMgr:openDlg("TongtiantaFlyDlg")
  dlg:setData(self.info)
end
function FubenMissionForTongtiantaDlg:onInfoButton(sender, eventType)
  local dlg = DlgMgr:openDlg("TongtiantaRuleDlg")
  dlg:setRuleType("MissionDlg")
end
function FubenMissionForTongtiantaDlg:onChangeButton(sender, eventType)
  if not self.info then
    return
  end
  local curType = self:getTowerType(self.info)
  if TeamMgr:getMemberById(Me:getId()) and not Me:isTeamLeader() and curType == CHS[3003134] then
    gf:ShowSmallTips(CHS[4300844])
    return
  end
  if not MapMgr:isInMapByName(CHS[4010103]) then
    gf:ShowSmallTips(CHS[4300845])
    return
  end
  if self.info.curType == 2 then
    gf:ShowSmallTips(CHS[4300846])
    return
  end
  local count = InventoryMgr:getAmountByName(CHS[7000081])
  count = count + InventoryMgr:getAmountByName(CHS[4200614])
  local superCount = InventoryMgr:getAmountByName(CHS[4101286])
  if superCount > 0 then
    gf:npcAskDlg(CHS[4300847], {
      CHS[7000081],
      CHS[4101286],
      CHS[4300848]
    }, CHS[4010309], 6223, function(class, para)
      performWithDelay(gf:getUILayer(), function(...)
        if para == CHS[7000081] then
          self:useTongtianlingpai()
        elseif para == CHS[4101286] then
          local pos = self:getPriorityItem()
          if not pos then
            gf:ShowSmallTips(CHS[4300851])
            return
          end
          InventoryMgr:applyItem(pos, 1)
          return
        end
      end, 0.1)
    end)
  else
    self:useTongtianlingpai()
  end
end
function FubenMissionForTongtiantaDlg:useTongtianlingpai()
  local count = InventoryMgr:getAmountByName(CHS[7000081])
  count = count + InventoryMgr:getAmountByName(CHS[4200614])
  if count > 0 then
    local items = InventoryMgr:getItemsByName(CHS[7000081])
    if not next(items) then
      items = InventoryMgr:getItemsByName(CHS[4200614])
    end
    if not next(items) then
      return
    end
    InventoryMgr:applyItem(items[1].pos, 1)
    return
  else
    gf:confirm(CHS[4300849], function()
      local paramList = gf:split(CHS[4300850], "=")
      DlgMgr:openDlgWithParam(paramList)
      self:setBuyLingPai(true)
    end)
  end
end
function FubenMissionForTongtiantaDlg:getPriorityItem()
  local inventory = InventoryMgr.inventory
  local pos
  local durability = 100
  for _, v in pairs(inventory) do
    if v.name == CHS[4101286] and durability > v.durability then
      pos = v.pos
      durability = v.durability
    end
  end
  return pos
end
return FubenMissionForTongtiantaDlg
