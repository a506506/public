local FunnyDlg = require("dlg/FunnyDlg")
local Funny4Dlg = Singleton("Funny4Dlg", FunnyDlg)
return Funny4Dlg
