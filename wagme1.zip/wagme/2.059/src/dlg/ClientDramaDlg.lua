local DramaDlg = require("dlg/DramaDlg")
local ClientDramaDlg = Singleton("ClientDramaDlg", DramaDlg)
function ClientDramaDlg:getCfgFileName()
  return ResMgr:getDlgCfg("DramaDlg")
end
function ClientDramaDlg:setData(dramaList, callBack)
  self.dramaList = dramaList
  self.callBack = callBack
  self.count = #self.dramaList
  self.index = 1
  self:MSG_PLAY_SCENARIOD(self.dramaList[self.index])
end
function ClientDramaDlg:cmdOperScenariod(type, para)
  if type == self.OPER.NEXT_SCENE then
    if self.index < self.count then
      self.index = self.index + 1
      self:MSG_PLAY_SCENARIOD(self.dramaList[self.index])
    else
      self:onSkipButton()
    end
  end
end
function ClientDramaDlg:isCanResetMainDlgs()
  return false
end
function ClientDramaDlg:cleanup()
  DramaDlg.cleanup(self)
  if self.callBack and type(self.callBack) == "function" then
    self.callBack()
  end
end
return ClientDramaDlg
