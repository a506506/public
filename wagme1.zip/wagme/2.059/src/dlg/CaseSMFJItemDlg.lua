local CaseSMFJItemDlg = Singleton("CaseSMFJItemDlg", Dialog)
function CaseSMFJItemDlg:init()
  self:setFullScreen()
  self:bindListener("ShowButton", self.onShowButton)
  self:bindListener("CloseButton", self.onHideButton)
  self.furnPanel = self:retainCtrl("ImagePanel")
  self.scrollView = self:getControl("ListScrollView")
  local btn = self:getControl("ShowButton")
  btn.origPos = cc.p(btn:getPosition())
  self:setCtrlVisible("ShowButton", not GameMgr:isHideAllUI())
  self:MSG_TANAN_TASK_ITEM_LIST()
  self:hookMsg("MSG_TANAN_TASK_ITEM_LIST")
  self:hookMsg("MSG_SHAKE_SCREEN")
end
function CaseSMFJItemDlg:onShowButton(sender, eventType)
  if GameMgr:isHideAllUI() then
    return
  end
  self:setCtrlVisible("ListPanel", true)
  self:setCtrlVisible("ShowButton", false)
  DlgMgr:sendMsg("GameFunctionDlg", "onHideButton")
end
function CaseSMFJItemDlg:doHide(duringTime)
  self:onHideButton()
  local btn = self:getControl("ShowButton")
  local size = btn:getContentSize()
  btn:stopAllActions()
  if duringTime == 0 then
    btn:setPosition(btn.origPos.x + size.width, btn.origPos.y)
    btn.lastVisible = button:isVisible()
    btn:setVisible(false)
  else
    btn:runAction(cc.Sequence:create(cc.MoveTo:create(duringTime, cc.p(btn.origPos.x + size.width, btn.origPos.y)), cc.CallFunc:create(function()
      btn:setVisible(false)
    end)))
  end
end
function CaseSMFJItemDlg:doShow(duringTime)
  local btn = self:getControl("ShowButton")
  btn:stopAllActions()
  if duringTime == 0 then
    btn:setPosition(btn.origPos.x, btn.origPos.y)
    btn.lastVisible = button:isVisible()
    btn:setVisible(true)
  else
    btn:runAction(cc.Sequence:create(cc.MoveTo:create(duringTime, cc.p(btn.origPos.x, btn.origPos.y)), cc.CallFunc:create(function()
      btn:setVisible(true)
    end)))
  end
end
function CaseSMFJItemDlg:onHideButton(sender, eventType)
  self:setCtrlVisible("ListPanel", false)
  self:setCtrlVisible("ShowButton", true)
end
function CaseSMFJItemDlg:setOneItemPanel(cell, info)
  if not info.name then
    self:setCtrlVisible("IconImage", false, cell)
    self:setImagePlist("BKImage", ResMgr.ui.bag_no_item_bg_img, cell)
  else
    self:setImage("IconImage", ResMgr:getIconPathByName(info.name), cell)
    self:bindTouchEndEventListener(cell, function()
      local rect = self:getBoundingBoxInWorldSpace(cell)
      local dlg = DlgMgr:openDlg("ItemInfoDlg")
      dlg:setInfoFormSMFJ(info)
      dlg:setFloatingFramePos(rect)
    end)
  end
end
function CaseSMFJItemDlg:MSG_TANAN_TASK_ITEM_LIST(data)
  if TanAnSMFJMgr.actNum and TanAnSMFJMgr.actNum > 0 then
    return
  end
  local furnsInfo = TanAnSMFJMgr:getEvidenceItems()
  local count = #furnsInfo
  if count == 0 then
    self:setCtrlVisible("NoneImage", true)
  else
    self:setCtrlVisible("NoneImage", false)
  end
  if count > 0 then
    for i = count + 1, 4 do
      table.insert(furnsInfo, {})
    end
  end
  self:initScrollViewPanel(furnsInfo, self.furnPanel, self.setOneItemPanel, self.scrollView, #furnsInfo, 7, 10, 0, 0, ccui.ScrollViewDir.horizontal)
end
function CaseSMFJItemDlg:MSG_SHAKE_SCREEN(data)
  if HomeMgr.furnitures then
    for _, v in pairs(HomeMgr.furnitures) do
      if v:isOper() and v.cmdPut then
        v:cmdPut()
      end
    end
  end
end
return CaseSMFJItemDlg
