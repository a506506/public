local CaseSMFJVoiceKeyDlg = Singleton("CaseSMFJVoiceKeyDlg", Dialog)
local SCRATCH_NUM = 1
local MAP = {
  [CHS[5400981]] = 1,
  [CHS[5400982]] = 2,
  [CHS[5400983]] = 3,
  [CHS[5400984]] = 4
}
function CaseSMFJVoiceKeyDlg:init()
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel")
  self:bindListener("ClosePanel", self.onCloseButton)
  self.eraser = GiftMgr:getEraser("CaseSMFJVoiceKeyDlg", SCRATCH_NUM, 75, 10)
  if TanAnSMFJMgr:checkHasTips("scratch") then
    self.scratchStatus = 1
  end
  self:initScratchPanel()
end
function CaseSMFJVoiceKeyDlg:setData(para)
  self:setImagePlist("KeyWordsImage", ResMgr.ui[string.format("case_smfj_chat%d", MAP[para or ""] or 1)])
end
function CaseSMFJVoiceKeyDlg:initScratchPanel()
  local path = ResMgr.ui.case_scratch
  if self.rText and self.rText:getParent() then
    self.rText:removeFromParent()
  end
  self.canTouchFlag = true
  local ctrlName = "ShadePanel"
  self.rText = GiftMgr:getScratchRTextbByName(self.name, ctrlName)
  if not self.rText then
    if self.scratchStatus ~= 1 then
      self.rText = self:createScratch(ctrlName, path, self.eraser[1], 0.6, self.onErased, 0.62, "canTouchFlag", nil, {
        FlipX = true,
        FlipY = true,
        anchorPos = cc.p(0, 1),
        scaleX = 1.6463,
        scaleY = 1.3634,
        rotate = -90,
        size = cc.size(270, 120)
      })
      GiftMgr:setScratchRText(self.name, ctrlName, self.rText)
    end
  elseif not self.rText:getParent() then
    local panel = self:getControl(ctrlName)
    panel:addChild(self.rText)
  end
  self:setCtrlVisible("MaskImage", false)
end
function CaseSMFJVoiceKeyDlg:onErased()
  if self.scratchStatus ~= 1 then
    self.scratchStatus = 1
    TanAnSMFJMgr:setFlagTips("scratch", 1)
  end
end
function CaseSMFJVoiceKeyDlg:cleanup()
  self.rText = nil
  self.eraser = nil
  self.scratchStatus = nil
end
return CaseSMFJVoiceKeyDlg
