local CockFightingBasicDlg = require("dlg/CockFightingBasicDlg")
local CockFightingDlg = Singleton("CockFightingDlg", CockFightingBasicDlg)
local CHICKEN_LEVEL = {
  XIA = 1,
  ZHONG = 2,
  SHANG = 3,
  BAO = 4,
  LAO = 5
}
local CARD_PANELS = {
  "XiaPanel",
  "ZhongPanel",
  "ShangPanel",
  "BaoPanel",
  "LaoPanel"
}
local CHICKEN_PANEL_INFO = {
  XiaPanel = {
    name = CHS[4101822],
    level = CHICKEN_LEVEL.XIA,
    flag = CHS[4101827],
    desc1 = CHS[4101832],
    desc2 = CHS[4101837],
    img_path = "CockFightImage/CockAvatarImage00001.png"
  },
  ZhongPanel = {
    name = CHS[4101823],
    level = CHICKEN_LEVEL.ZHONG,
    flag = CHS[4101828],
    desc1 = CHS[4101833],
    desc2 = CHS[4101838],
    img_path = "CockFightImage/CockAvatarImage00002.png"
  },
  ShangPanel = {
    name = CHS[4101824],
    level = CHICKEN_LEVEL.SHANG,
    flag = CHS[4101829],
    desc1 = CHS[4101834],
    desc2 = CHS[4101839],
    img_path = "CockFightImage/CockAvatarImage00003.png"
  },
  BaoPanel = {
    name = CHS[4101825],
    level = CHICKEN_LEVEL.BAO,
    flag = CHS[4101830],
    desc1 = CHS[4101835],
    desc2 = CHS[4101840],
    img_path = "CockFightImage/CockAvatarImage00004.png"
  },
  LaoPanel = {
    name = CHS[4101826],
    level = CHICKEN_LEVEL.LAO,
    flag = CHS[4101831],
    desc1 = CHS[4101836],
    desc2 = CHS[4101841],
    img_path = "CockFightImage/CockAvatarImage00005.png"
  }
}
local CHICKEN_TYPE_PANEL = {
  "XiaPanel",
  "ZhongPanel",
  "ShangPanel",
  "BaoPanel",
  "LaoPanel"
}
local POWER_MAP = {
  [CHICKEN_LEVEL.XIA] = {
    afraid = {
      CHICKEN_LEVEL.ZHONG,
      CHICKEN_LEVEL.SHANG,
      CHICKEN_LEVEL.BAO
    },
    restraint = {
      CHICKEN_LEVEL.LAO
    }
  },
  [CHICKEN_LEVEL.ZHONG] = {
    afraid = {
      CHICKEN_LEVEL.SHANG,
      CHICKEN_LEVEL.BAO
    },
    restraint = {
      CHICKEN_LEVEL.XIA,
      CHICKEN_LEVEL.LAO
    }
  },
  [CHICKEN_LEVEL.SHANG] = {
    afraid = {
      CHICKEN_LEVEL.LAO,
      CHICKEN_LEVEL.BAO
    },
    restraint = {
      CHICKEN_LEVEL.XIA,
      CHICKEN_LEVEL.ZHONG
    }
  },
  [CHICKEN_LEVEL.BAO] = {
    afraid = {
      CHICKEN_LEVEL.LAO
    },
    restraint = {}
  },
  [CHICKEN_LEVEL.LAO] = {
    afraid = {
      CHICKEN_LEVEL.XIA,
      CHICKEN_LEVEL.ZHONG
    },
    restraint = {
      CHICKEN_LEVEL.SHANG,
      CHICKEN_LEVEL.BAO
    }
  }
}
function CockFightingDlg:init()
  CockFightingBasicDlg.init(self)
  self:setFullScreen()
  local panel = self:getControl("MyselfCockPanel")
  local panelEx = self:getControl("CompetitorCockPanel")
  for _, pName in pairs(CARD_PANELS) do
    local panel1 = self:getControl(pName, nil, panel)
    self:bindListener("SelectButton", self.onSelectButton, panel1)
  end
  self:bindListener("PlayButton", self.onPlayButton)
  self:bindListener("Button", self.onButton)
  self:bindListener("StarButton", self.onStarButton)
  self:bindListener("BlackPanel", self.onBlackPanel)
  self.cockTipsPanel = self:retainCtrl("CockTipsPanel")
  self.winPanel = self:retainCtrl("WinPanel")
  self.failPanel = self:retainCtrl("FailPanel")
  self.pingPanel = self:retainCtrl("PingjuPanel")
  self:initCtrlState()
  self.selectChicken = nil
  self:setReadyInfo()
  self:setPlayerInfo()
  self:setCards()
  self:setTimer()
  local data = ActivityHelperMgr:getCockFightData()
  if data and data.game_data then
    self:setCardsAction(data.game_data.left_cards, data.game_data.my_cards)
    self:setCardsAction(data.game_data.oppo_left_cards, data.game_data.op_cards, true)
  end
  self:hookMsg("MSG_QINGMING2020_QMDJ_USER_DATA")
  self:hookMsg("MSG_QINGMING2020_QMDJ_GAME_DATA")
  self:hookMsg("MSG_QINGMING2020_QMDJ_RESULT")
end
function CockFightingDlg:initCtrlState()
  local panel = self:getControl("MyselfCockPanel")
  local panelEx = self:getControl("CompetitorCockPanel")
  for _, pName in pairs(CARD_PANELS) do
    local panel1 = self:getControl(pName, nil, panel)
    self:setCtrlVisible("StatusPanel", false, panel1)
    self:setCtrlVisible("PressedPanel", false, panel1)
    panel1.info = CHICKEN_PANEL_INFO[pName]
    local panel2 = self:getControl(pName, nil, panelEx)
    self:setCtrlVisible("StatusPanel", false, panel2)
    self:setCtrlVisible("PressedPanel", false, panel2)
    self:setCtrlVisible("StrengthPanel", false, panel2)
    panel2.info = CHICKEN_PANEL_INFO[pName]
  end
  self:setLabelText("TimeTextAtlas", "")
  self:setCtrlVisible("SmallResultPanel", false)
end
function CockFightingDlg:onSelectButton(sender, eventType)
  local data = ActivityHelperMgr:getCockFightData()
  if data.game_data.fight_card > 0 then
    gf:ShowSmallTips(CHS[4101842])
    return
  end
  if self.isResult then
    return
  end
  if not sender:getParent().isExsit then
    gf:ShowSmallTips(CHS[4101843])
    return
  end
  if self.selectChicken == sender:getParent().info then
    self:onBlackPanel()
    return
  end
  self:setSelectEffect(sender:getParent())
  local info = sender:getParent().info
  self.selectChicken = info
  local panel = self:getControl("TipsPanel0" .. info.level, nil, "RightTipsPanel")
  self:setSelectChickenTips(info, panel)
  self:setOperColors(info.level)
end
function CockFightingDlg:setSelectChickenTips(info, panel)
  self.cockTipsPanel:removeFromParent()
  if not info then
    local panelEx = self:getControl("CompetitorCockPanel")
    for _, pName in pairs(CARD_PANELS) do
      local panel2 = self:getControl(pName, nil, panelEx)
      self:setCtrlVisible("StrengthPanel", false, panel2)
    end
    return
  end
  self:setLabelText("NameLabel", info.name, self.cockTipsPanel)
  self:setLabelText("TypeLabel", info.flag, self.cockTipsPanel)
  self:setLabelText("Label01", info.desc1, self.cockTipsPanel)
  self:setLabelText("Label02", info.desc2, self.cockTipsPanel)
  self:setImagePlist("AvatarImage", info.img_path, self.cockTipsPanel)
  panel:addChild(self.cockTipsPanel)
end
function CockFightingDlg:onPlayButton(sender, eventType)
  gf:CmdToServer("CMD_QINGMING2020_QMDJ_USE_CARD", {
    index = self.selectChicken.level
  })
end
function CockFightingDlg:onButton(sender, eventType)
  DlgMgr:openDlg("CockFightingRuleExDlg")
end
function CockFightingDlg:cleanup()
  if self.timer then
    self:stopSchedule(self.timer)
    self.timer = nil
  end
  if self.resultTimer then
    self:stopSchedule(self.resultTimer)
    self.resultTimer = nil
  end
  self.data = nil
  self.isResult = nil
  DlgMgr:closeDlg("CockFightingRuleExDlg")
  DlgMgr:closeDlg("CockFightingRuleDlg")
  DlgMgr:closeDlg("ConfirmDlg")
  gf:closeCountDown()
end
function CockFightingDlg:onCloseButton(sender, eventType)
  gf:CmdToServer("CMD_QINGMING2020_QMDJ_LOSE")
end
function CockFightingDlg:onBlackPanel(sender, eventType)
  self:setSelectChickenTips()
  self:setSelectEffect()
  self:setOperColors()
  self.selectChicken = nil
end
function CockFightingDlg:onStarButton(sender, eventType)
  gf:CmdToServer("CMD_QINGMING2020_QMDJ_PREPARE")
  DlgMgr:closeDlg("CockFightingResultDlg")
end
function CockFightingDlg:setReadyInfo()
  local data = ActivityHelperMgr:getCockFightData()
  self:setCtrlVisible("ReadyPanel", data.player_info.stage == 0)
  if data.player_info.stage == 0 then
    DlgMgr:openDlg("CockFightingRuleDlg")
    gf:startCountDowm(math.min(data.player_info.left_time, gf:getServerTime() + 60))
  end
  for gid, info in pairs(data.player_info.user_info) do
    local panel = gid == Me:queryBasic("gid") and self:getControl("PlayerPanel01") or self:getControl("PlayerPanel02")
    self:setImage("ItemImageView", ResMgr:getSmallPortrait(info.icon), panel)
    self:setLabelText("NameLabel", info.name, panel)
    local prepare = info.is_prepare == 1 and CHS[4200963] or CHS[4200988]
    self:setLabelText("ReadyLabel", prepare, panel)
    self:setLabelText("LevelTextBMFont", info.level, panel)
    if gid == Me:queryBasic("gid") then
      self:setCtrlEnabled("StarButton", info.is_prepare ~= 1)
    end
  end
end
function CockFightingDlg:setPlayerInfo()
  local data = ActivityHelperMgr:getCockFightData()
  local titlePanel = self:getControl("TitlePanel")
  for gid, info in pairs(data.player_info.user_info) do
    local panel = gid == Me:queryBasic("gid") and self:getControl("MyselfInfoPanel", nil, titlePanel) or self:getControl("CompetitorInfoPanel", nil, titlePanel)
    self:setLabelText("NameLabel", info.name, panel)
  end
  local myPanel = self:getControl("MyselfInfoPanel", nil, titlePanel)
  local opPanel = self:getControl("CompetitorInfoPanel", nil, titlePanel)
  for i = 1, 2 do
    if not data.game_data then
      local panel = self:getControl("Panel0" .. i, nil, myPanel)
      self:setCtrlVisible("PressedPanel", false, panel)
      self:setLabelText("ReadyLabel", "", myPanel)
      local panel = self:getControl("Panel0" .. i, nil, self:getControl("CompetitorInfoPanel", nil, titlePanel))
      self:setCtrlVisible("PressedPanel", false, panel)
      self:setLabelText("ReadyLabel", "", opPanel)
    else
      local panel = self:getControl("Panel0" .. i, nil, myPanel)
      self:setCtrlVisible("PressedPanel", i <= data.game_data.score, panel)
      self:setLabelText("ReadyLabel", data.game_data.fight_card == 0 and "冥思苦想..." or "准备就绪", myPanel)
      local panel = self:getControl("Panel0" .. i, nil, self:getControl("CompetitorInfoPanel", nil, titlePanel))
      self:setCtrlVisible("PressedPanel", i <= data.game_data.opporate_score, panel)
      self:setLabelText("ReadyLabel", data.game_data.opporate_fight_card == 0 and "冥思苦想..." or "准备就绪", opPanel)
    end
  end
end
function CockFightingDlg:setCardsAction(count, list, flag)
  local fullCard = {}
  for i = 1, 5 do
    local findIt = false
    for j = 1, count do
      if list[j] == i then
        findIt = true
        break
      end
    end
    if findIt then
      fullCard[i] = i
    else
      fullCard[i] = 0
    end
  end
  for i = 1, #fullCard do
    local cardType = fullCard[i]
    local panelType = CHICKEN_TYPE_PANEL[i]
    if cardType == 0 then
      if flag then
        self:setOppChickenFailIn(panelType)
      else
        self:setMyChickenFailIn(panelType)
      end
    elseif flag then
      self:setOppChickenIn(panelType)
    else
      self:setMyChickenIn(panelType)
    end
  end
end
function CockFightingDlg:setCarsExsitState(data, panel)
  local ret = {}
  for i = 1, 5 do
    local isActive = false
    for _, vle in pairs(data) do
      if vle == i then
        isActive = true
      end
    end
    ret[i] = isActive
  end
  for _, pName in pairs(CARD_PANELS) do
    local panel1 = self:getControl(pName, nil, panel)
    panel1.isExsit = ret[_]
    if not panel1.isExsit then
      local magic = panel1:getChildByName("SmallCockActionPanel"):getChildByName("Chick")
      if magic then
        local animation = magic:getAnimation()
        if panel:getName() == "MyselfCockPanel" then
          if animation:getCurrentMovementID() ~= "Top105" then
            animation:play("Top105", -1, -1)
          end
        elseif animation:getCurrentMovementID() ~= "Top205" then
          animation:play("Top205", -1, -1)
        end
      elseif panel:getName() == "MyselfCockPanel" then
        self:setMyChickenFailIn(pName)
      else
        self:setOppChickenFailIn(pName)
      end
    end
  end
end
function CockFightingDlg:setSelectEffect(sender)
  local panel = self:getControl("MyselfCockPanel")
  for _, pName in pairs(CARD_PANELS) do
    local panel1 = self:getControl(pName, nil, panel)
    if sender then
      self:setCtrlVisible("PressedPanel", sender:getName() == pName, panel1)
    else
      self:setCtrlVisible("PressedPanel", false, panel1)
    end
  end
end
function CockFightingDlg:setFightCard(panelName, level)
  local panel = self:getControl(panelName)
  for _, pName in pairs(CARD_PANELS) do
    local panel1 = self:getControl(pName, nil, panel)
    self:setCtrlVisible("StatusPanel", level == panel1.info.level, panel1)
  end
end
function CockFightingDlg:setTimer()
  local data = ActivityHelperMgr:getCockFightData()
  if not data.game_data then
    self:setLabelText("TimeTextAtlas", "")
    return
  end
  if self.timer then
    self:stopSchedule(self.timer)
    self.timer = nil
  end
  if data.game_data.fight_result > 0 then
    self:setLabelText("TimeTextAtlas", "")
    return
  end
  self:setCtrlVisible("TimeTextAtlas", true)
  self:setCtrlVisible("FightImage", false)
  self.timer = self:startSchedule(function()
    local leftTime = math.min(data.game_data.left_time - gf:getServerTime(), 20)
    self:setLabelText("TimeTextAtlas", math.max(leftTime, 0))
    if leftTime <= 0 and self.timer then
      self:stopSchedule(self.timer)
      self.timer = nil
    end
  end, 0.3)
end
function CockFightingDlg:setCards()
  local data = ActivityHelperMgr:getCockFightData()
  local myCardsPanel = self:getControl("CockPanel", nil, "MyselfCockPanel")
  local opCardsPanel = self:getControl("CockPanel", nil, "CompetitorCockPanel")
  if not data.game_data then
    self:setCarsExsitState({
      1,
      2,
      3,
      4,
      5
    }, myCardsPanel)
    self:setCarsExsitState({
      1,
      2,
      3,
      4,
      5
    }, opCardsPanel)
    self:setFightCard("MyselfCockPanel", 0)
    self:setFightCard("CompetitorCockPanel", 0)
    return
  end
  self:setCarsExsitState(data.game_data.my_cards, myCardsPanel)
  self:setCarsExsitState(data.game_data.op_cards, opCardsPanel)
  if data.game_data.fight_result == 0 then
    self:setFightCard("MyselfCockPanel", data.game_data.fight_card)
    self:setFightCard("CompetitorCockPanel", data.game_data.opporate_fight_card)
  end
end
function CockFightingDlg:setOperColors(level)
  local panel = self:getControl("CompetitorCockPanel")
  local rekationMap = POWER_MAP[level]
  for _, pName in pairs(CARD_PANELS) do
    local panel1 = self:getControl(pName, nil, panel)
    if panel1.isExsit then
      local colorPanel = self:setCtrlVisible("StrengthPanel", true, panel1)
      local img = self:getControl("Image", nil, colorPanel)
      if not rekationMap then
        img:setVisible(false)
      else
        img:setVisible(true)
        local color = COLOR3.WHITE
        for _, vle in pairs(rekationMap.afraid) do
          if panel1.info.level == vle then
            color = COLOR3.RED
          end
        end
        for _, vle in pairs(rekationMap.restraint) do
          if panel1.info.level == vle then
            color = COLOR3.GREEN
          end
        end
        img:setColor(color)
      end
    end
  end
end
function CockFightingDlg:setActive(isNotAct)
  self:getControl("BottomFightingActionPanel"):removeAllChildren()
  self:getControl("TopFightingActionPanel01"):removeAllChildren()
  self.isNotActive = isNotAct
end
function CockFightingDlg:getActive()
  return self.isNotActive
end
function CockFightingDlg:playCockMagic(data, callBack)
  self:setCtrlVisible("TimeTextAtlas", false)
  self:setCtrlVisible("FightImage", true)
  self:setFightCard("MyselfCockPanel", 0)
  self:setFightCard("CompetitorCockPanel", 0)
  local myType = CHICKEN_TYPE_PANEL[data.fight_card]
  local oppType = CHICKEN_TYPE_PANEL[data.opporate_fight_card]
  self:setMyChickenOut(myType)
  self:setOppChickenOut(oppType, function()
    self:playChickFight(data.fight_result, myType, oppType, function()
      self:setChickBackToCard(data.fight_result, myType, oppType, function()
        callBack()
      end)
    end)
  end)
end
function CockFightingDlg:MSG_QINGMING2020_QMDJ_USER_DATA(data)
  self:setReadyInfo()
end
function CockFightingDlg:setData(data)
  self.data = data
  self:setCtrlVisible("ReadyPanel", false)
  gf:closeCountDown()
  DlgMgr:closeDlg("CockFightingRuleDlg")
  if data.round > 0 then
    self:setCtrlVisible("SmallResultPanel", false)
  end
  self:setPlayerInfo()
  if 0 < data.fight_card then
    self:setSelectChickenTips()
    self:setSelectEffect()
    self:setOperColors()
  end
  self:setCards()
  self:setTimer()
  self:setCtrlVisible("TipsTextPanel", 0 >= data.fight_card)
end
function CockFightingDlg:MSG_QINGMING2020_QMDJ_GAME_DATA(data)
  self.isResult = false
  local oldData
  if self.data then
    oldData = gf:deepCopy(self.data)
  end
  self:setData(data)
  if not oldData or oldData.num ~= data.num or data.is_client_active == 1 then
    self:setCardsAction(data.left_cards, data.my_cards)
    self:setCardsAction(data.oppo_left_cards, data.op_cards, true)
  end
end
function CockFightingDlg:setGameResult(data)
  self:setCtrlVisible("SmallResultPanel", true)
  self:setCtrlVisible("TipsTextPanel", false)
  self:setLabelText("RoundNumTextAtlas", data.num)
  local wPanel = self.winPanel:clone()
  local fPanel = self.failPanel:clone()
  local panel1 = self:getControl("CompetitorResultPanel")
  local panel2 = self:getControl("MyselfResultPanel")
  panel1:removeAllChildren()
  panel2:removeAllChildren()
  if data.result == 1 then
    panel1:addChild(fPanel)
    panel2:addChild(wPanel)
  elseif data.result == 2 then
    panel1:addChild(wPanel)
    panel2:addChild(fPanel)
  else
    local pPanel1 = self.pingPanel:clone()
    local pPanel2 = self.pingPanel:clone()
    panel1:addChild(pPanel1)
    panel2:addChild(pPanel2)
  end
  self.resultTimer = self:startSchedule(function()
    local leftTime = math.min(data.left_time - gf:getServerTime(), 5)
    leftTime = math.max(leftTime, 0)
    self:setLabelText("daijishiLabel", string.format(CHS[4200962], leftTime))
    if leftTime <= 0 then
      gf:CmdToServer("CMD_QINGMING2020_QMDJ_CONTINUE", {flag = 1})
      if self.resultTimer then
        self:stopSchedule(self.resultTimer)
        self.resultTimer = nil
      end
    end
  end, 0.3)
end
function CockFightingDlg:MSG_QINGMING2020_QMDJ_RESULT(data)
  local panel1 = self:getControl("MyselfCockPanel")
  local panel2 = self:getControl("CompetitorCockPanel")
  local count = #CARD_PANELS
  for i = 1, count do
    self:setRoundOverMyChidckOut(CARD_PANELS[i], data.result)
    if i == count then
      self:setRoundOverOppChidckOut(CARD_PANELS[i], data.result, function()
        self:setGameResult(data)
      end)
    else
      self:setRoundOverOppChidckOut(CARD_PANELS[i], data.result)
    end
  end
  self:setSelectChickenTips()
  self.isResult = true
end
return CockFightingDlg
