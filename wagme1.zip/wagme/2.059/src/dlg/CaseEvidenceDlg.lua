local CaseEvidenceDlg = Singleton("CaseEvidenceDlg", Dialog)
function CaseEvidenceDlg:init()
  self.itemPanel = self:retainCtrl("OneItemPanel")
  self:bindListViewListener("ItemListView", self.onSelectItemListView, self.onLongTouchListViewListener)
  self:initData()
end
function CaseEvidenceDlg:initData()
  local items = TanAnMgr:getEvidenceItems()
  if #items == 0 then
    self:setCtrlVisible("NonePanel", true)
  else
    self:setCtrlVisible("NonePanel", false)
    local listView = self:getControl("ItemListView")
    listView:removeAllItems()
    for i = 1, #items do
      local itemPanel = self.itemPanel:clone()
      self:setImage("ItemImage", ResMgr:getItemIconPath(items[i].icon), itemPanel)
      self:setLabelText("ItemNameLabel", items[i].name, itemPanel)
      itemPanel.itemName = items[i].name
      listView:pushBackCustomItem(itemPanel)
    end
  end
end
function CaseEvidenceDlg:onSelectItemListView(sender, eventType)
  local itemPanel = self:getListViewSelectedItem(sender)
  if not itemPanel then
    return
  end
  local iconImage = self:getControl("ItemBackImage", nil, itemPanel)
  local touchPos = iconImage:getParent():convertToNodeSpace(GameMgr.curTouchPos)
  if iconImage:getBoundingBox() and not cc.rectContainsPoint(iconImage:getBoundingBox(), touchPos) then
    return
  end
  if not Me:getTalkId() then
    return
  end
  if MapMgr:isInTanAnSTCS() then
    local npcDlg = DlgMgr:getDlgByName("NpcDlg")
    if npcDlg then
      gf:CmdToServer("CMD_STMZ_USE_ITEM", {
        npc_name = npcDlg.npcName,
        item_name = itemPanel.itemName
      })
    end
  elseif MapMgr:isInTanAnSswd() then
    gf:CmdToServer("CMD_SSWD_USE_TASK_ITEM", {
      npcId = Me:getTalkId(),
      name = itemPanel.itemName
    })
  else
    gf:CmdToServer("CMD_MXAZ_USE_EXHIBIT", {
      npcId = Me:getTalkId(),
      name = itemPanel.itemName
    })
  end
end
function CaseEvidenceDlg:onLongTouchListViewListener(sender, eventType)
  local itemPanel = self:getListViewSelectedItem(sender)
  if not itemPanel then
    return
  end
  local iconImage = self:getControl("ItemBackImage", nil, itemPanel)
  local touchPos = iconImage:getParent():convertToNodeSpace(GameMgr.curTouchPos)
  if iconImage:getBoundingBox() and not cc.rectContainsPoint(iconImage:getBoundingBox(), touchPos) then
    return
  end
  local rect = self:getBoundingBoxInWorldSpace(itemPanel)
  InventoryMgr:showBasicMessageDlg(itemPanel.itemName, rect)
end
return CaseEvidenceDlg
