local DeathRecordDlg = Singleton("DeathRecordDlg", Dialog)
local ONE_LOAD_NUM = 12
function DeathRecordDlg:init()
  self:bindListener("CommunicationButton", self.onCommunicationButton)
  self:bindListViewListener("MemberListView", self.onSelectMemberListView)
  self.unitPanel = self:retainCtrl("OneRowMemberPanel")
  self.loadNum = 1
  self:bindListViewByPageLoad("MemberListView", "TouchPanel", function(dlg, percent)
    if percent > 100 then
      performWithDelay(self.root, function()
        self:setListView()
      end, 0.5)
    end
  end)
end
function DeathRecordDlg:setDeathList(data)
  self.data = data
  local list = self:resetListView("MemberListView")
  local nextIdx = math.min(data.count, self.loadNum + ONE_LOAD_NUM)
  for i = self.loadNum, nextIdx do
    local panel = self.unitPanel:clone()
    self:setUnitPanel(data[i], panel, i)
    list:pushBackCustomItem(panel)
  end
  self.loadNum = nextIdx
  self:setCtrlVisible("NoticePanel", data.count == 0)
end
function DeathRecordDlg:setListView()
  local nextIdx = math.min(self.data.count, self.loadNum + ONE_LOAD_NUM)
  local list = self:getControl("MemberListView")
  for i = self.loadNum + 1, nextIdx do
    local panel = self.unitPanel:clone()
    self:setUnitPanel(self.data[i], panel, i)
    list:pushBackCustomItem(panel)
  end
  self.loadNum = nextIdx
end
function DeathRecordDlg:setUnitPanel(data, panel, idx)
  panel.data = data
  self:setCtrlVisible("BackImage_2", idx % 2 == 0, panel)
  local timeStr = gf:getServerDate("%m-%d %H:%M", data.update_time)
  self:setLabelText("TimeLabel", timeStr, panel)
  self:setLabelText("TeamLeaderLabel", string.isNilOrEmpty(data.leader_name) and CHS[5000347] or gf:getRealName(data.leader_name), panel)
  self:setLabelText("CombatTypeLabel", data.cob_template, panel)
  if data.type == 0 then
    self:setLabelText("AvoidLabel", CHS[4300682], panel)
  elseif data.type == 1 then
    self:setLabelText("AvoidLabel", CHS[3001148], panel)
  elseif data.type == 2 then
    self:setLabelText("AvoidLabel", CHS[4300683], panel)
  end
  self:setCtrlVisible("CommunicationButton", not string.isNilOrEmpty(data.leader_gid) and data.leader_gid ~= Me:queryBasic("gid"), panel)
end
function DeathRecordDlg:onCommunicationButton(sender, eventType)
  local data = sender:getParent().data
  FriendMgr:communicat(data.leader_name, data.leader_gid, data.leader_icon, data.leader_level)
  self:onCloseButton()
end
function DeathRecordDlg:onSelectMemberListView(sender, eventType)
end
return DeathRecordDlg
