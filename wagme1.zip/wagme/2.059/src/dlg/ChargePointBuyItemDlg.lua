local ChargePointBuyItemDlg = Singleton("ChargePointBuyItemDlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
function ChargePointBuyItemDlg:init()
  self:bindListener("SellReduceButton", self.onSellReduceButton)
  self:bindListener("SellAddButton", self.onSellAddButton)
  self:bindListener("BuyButton", self.onBuyButton)
  self:bindNumInput("NumPanel")
end
function ChargePointBuyItemDlg:setData(data, ownPoint, deadline)
  self.itemInfo = data
  self.ownPoint = ownPoint
  self.deadline = deadline
  if data.textureResType == ccui.TextureResType.plistType then
    self:setImagePlist("IconImage", data.imgPath)
  else
    self:setImage("IconImage", data.imgPath)
  end
  local num = data.num
  self:setLabelText("SellFloatLabel", CHS[5440000] .. " " .. num)
  if data.deadline then
    InventoryMgr:addLogoTimeLimit(self:getControl("IconImage", nil))
  elseif data.limted then
    InventoryMgr:addLogoBinding(self:getControl("IconImage", nil))
  end
  self:setLabelText("NameLabel", data.name)
  if data.alias and data.alias ~= "" then
    self:setLabelText("NameLabel", data.alias)
  end
  local pointDesc = gf:getArtFontMoneyDesc(data.point, true)
  self:setNumImgForPanel("PointPanel", ART_FONT_COLOR.DEFAULT, pointDesc, false, LOCATE_POSITION.CENTER, 23)
  local iconPanel = self:getControl("IconPanel")
  iconPanel.reward = data.reward
  self:bindTouchEndEventListener(iconPanel, self.onShowItemInfo)
  self.inputNum = 1
  self:updateChargeNum(1)
  self.root:requestDoLayout()
end
function ChargePointBuyItemDlg:getItemUnit(type, name)
  if type == CHS[6000079] then
    return CHS[5420143]
  else
    return InventoryMgr:getUnit(name)
  end
end
function ChargePointBuyItemDlg:getShopLimit(type, name)
  if type == CHS[6000079] then
    return PetMgr:getFreePetCapcity()
  elseif type == CHS[3002168] then
    return InventoryMgr:getEmptyPosCount()
  else
    return InventoryMgr:getCountCanAddToBag(name, 99, self.itemInfo.limted)
  end
end
function ChargePointBuyItemDlg:onShowItemInfo(sender, eventType)
  RewardContainer:imagePanelTouch(sender, eventType)
end
function ChargePointBuyItemDlg:onSellReduceButton(sender, eventType)
  if self.inputNum <= 1 then
    gf:ShowSmallTips(CHS[5420140])
    return
  end
  self.inputNum = self.inputNum - 1
  self:updateChargeNum(self.inputNum)
end
function ChargePointBuyItemDlg:onSellAddButton(sender, eventType)
  if self.inputNum >= self.itemInfo.num then
    gf:ShowSmallTips(string.format(CHS[5420139], self.itemInfo.num))
    return
  end
  self.inputNum = self.inputNum + 1
  self:updateChargeNum(self.inputNum)
end
function ChargePointBuyItemDlg:onBuyButton(sender, eventType)
  local curTime = gf:getServerTime()
  if curTime > self.deadline then
    gf:ShowSmallTips(CHS[5420148])
    ChatMgr:sendMiscMsg(CHS[5420148])
    DlgMgr:closeDlg("ChargePointBuyItemDlg")
    DlgMgr:closeDlg("ChargePointDlg")
    DlgMgr:closeDlg("ConsumePointDlg")
    return
  end
  if self.inputNum < 1 then
    self.inputNum = 1
    self:updateChargeNum(1)
    gf:ShowSmallTips(CHS[5420140])
    return
  end
  if self.inputNum > self.itemInfo.num then
    self.inputNum = self.itemInfo.num
    self:updateChargeNum(self.inputNum)
    gf:ShowSmallTips(CHS[5420139], self.inputNum)
    return
  end
  local type = GiftMgr:getPointWelfareType()
  if type == "charge" then
    GiftMgr:buyChargePointGoods(self.itemInfo.no, self.inputNum)
  elseif type == "consume" then
    GiftMgr:buyConsumePointGoods(self.itemInfo.no, self.inputNum)
  end
end
function ChargePointBuyItemDlg:updateChargeNum(num)
  self:setColorText(tostring(num), "MoneyValuePanel", nil, 0, 0, COLOR3.WHITE, 21, true)
  local totalPoint = num * self.itemInfo.point
  local fontColor = ART_FONT_COLOR.DEFAULT
  if totalPoint > self.ownPoint then
    fontColor = ART_FONT_COLOR.RED
  end
  local pointDesc = gf:getArtFontMoneyDesc(totalPoint)
  self:setNumImgForPanel("PointValuePanel", fontColor, pointDesc, false, LOCATE_POSITION.MID, 23)
end
function ChargePointBuyItemDlg:bindNumInput(inputPanelName)
  local inputPanel = self:getControl(inputPanelName)
  local function openNumIuputDlg()
    local rect = self:getBoundingBoxInWorldSpace(inputPanel)
    local dlg = DlgMgr:openDlg("NumInputDlg")
    dlg:setObj(self)
    dlg:updatePosition(rect)
  end
  self:bindListener(inputPanelName, openNumIuputDlg)
end
function ChargePointBuyItemDlg:deleteNumber()
  self.inputNum = math.floor((self.inputNum or 0) / 10)
  self:updateChargeNum(self.inputNum)
end
function ChargePointBuyItemDlg:deleteAllNumber()
  self.inputNum = 0
  self:updateChargeNum(0)
end
function ChargePointBuyItemDlg:insertNumber(num)
  local curNumber = self.inputNum or 0
  if num == "00" then
    curNumber = curNumber * 100
  elseif num == "0000" then
    curNumber = curNumber * 10000
  else
    curNumber = curNumber * 10 + num
  end
  if curNumber >= self.itemInfo.num then
    curNumber = self.itemInfo.num
    gf:ShowSmallTips(string.format(CHS[5420139], curNumber))
  end
  self.inputNum = curNumber
  self:updateChargeNum(curNumber)
end
function ChargePointBuyItemDlg:cleanup()
  self.itemInfo = {}
end
return ChargePointBuyItemDlg
