local CockFightingRuleDlg = require("dlg/CockFightingRuleDlg")
local CockFightingRuleExDlg = Singleton("CockFightingRuleExDlg", CockFightingRuleDlg)
function CockFightingRuleExDlg:getCfgFileName()
  return ResMgr:getDlgCfg("CockFightingRuleDlg")
end
return CockFightingRuleExDlg
