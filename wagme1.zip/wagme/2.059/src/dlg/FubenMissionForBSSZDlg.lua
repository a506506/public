local FubenMissionDlg = require("dlg/FubenMissionDlg")
local FubenMissionForBSSZDlg = Singleton("FubenMissionForBSSZDlg", FubenMissionDlg)
function FubenMissionForBSSZDlg:init()
  FubenMissionDlg.init(self)
  local task = TaskMgr:getTaskByShowName(CHS[4101863])
  if task then
    self:setInfoByTask(task)
    if tonumber(task.task_state) < 3 then
      self.magic = ArmatureMgr:createArmature(ResMgr.ArmatureMagic.famous_entry.name)
      self.magic:setPosition(Const.WINSIZE.width / 2, Const.WINSIZE.height / 2)
      gf:getUILayer():addChild(self.magic, -1, -1)
      local anim = self.magic:getAnimation()
      anim:play("Top01")
    end
  end
end
function FubenMissionForBSSZDlg:onLeaveButton(sender, eventType)
  gf:CmdToServer("CMD_LEAVE_ROOM", {
    type = CHS[4101863],
    extra = ""
  })
end
function FubenMissionForBSSZDlg:setInfoByTask(task)
  self.task = task
  self:setLabelText("NameLabel", task.task_type)
  self:setColorTextEx(task.task_prompt, self:getControl("CurrentPanel"), COLOR3.WHITE)
  local temp = gf:split(task.task_extra_para, ";")
  if tonumber(temp[1]) ~= 3 then
    return
  end
  local dlg = DlgMgr:getDlgByName("CountDownDlg")
  if not dlg then
    gf:startCountDowm(tonumber(temp[3]), nil, nil, {
      magicType = 1,
      magicName = ResMgr.magic.bssz1615,
      blendMode = "add"
    })
  end
end
function FubenMissionForBSSZDlg:onFubenInfo(sender, eventType)
  if not self.task then
    return
  end
  AutoWalkMgr:beginAutoWalk(gf:findDest(self.task.task_prompt))
end
function FubenMissionForBSSZDlg:cleanup()
  self.task = nil
  FubenMissionDlg.cleanup(self)
  if self.magic then
    self.magic:removeFromParent()
    self.magic = nil
  end
  gf:closeCountDown()
end
function FubenMissionForBSSZDlg:MSG_TASK_PROMPT(data)
  local task = TaskMgr:getTaskByShowName(CHS[4101863])
  if task then
    self.task = task
    self:setInfoByTask(task)
    if tonumber(task.task_state) >= 3 then
      if self.magic then
        local fade = cc.FadeOut:create(2)
        local callFunc = cc.CallFunc:create(function()
          if self.magic then
            self.magic:removeFromParent()
            self.magic = nil
          end
        end)
        self.magic:runAction(cc.Sequence:create(fade, callFunc))
      end
    elseif not self.magic then
      self.magic = ArmatureMgr:createArmature(ResMgr.ArmatureMagic.famous_entry.name)
      self.magic:setPosition(Const.WINSIZE.width / 2, Const.WINSIZE.height / 2)
      gf:getUILayer():addChild(self.magic, -1, -1)
      local anim = self.magic:getAnimation()
      anim:play("Top01")
    end
  end
end
return FubenMissionForBSSZDlg
