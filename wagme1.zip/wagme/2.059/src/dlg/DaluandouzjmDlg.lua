local DaluandouzjmDlg = Singleton("DaluandouzjmDlg", Dialog)
function DaluandouzjmDlg:init()
  self:setFullScreen()
  self:bindListener("RuleButton", self.onRuleButton)
  self:bindListener("TujianButton", self.onTujianButton)
  self:bindListener("RetinueButton", self.onRetinueButton)
  self:bindListener("BagButton", self.onBagButton)
  self:bindListener("ShrinkButton", self.onShrinkButton)
  self:bindListener("OpenButton", self.onOpenButton)
  self:bindListener("TvButton", self.onTvButton)
  self:bindListener("ReadyButton", self.onReadyButton)
  self.playerListPanel = self:getControl("PlayerListPanel")
  self.playerListPanelSz = self.playerListPanel:getContentSize()
  self.playerListPanel.org_size = self.playerListPanel:getContentSize()
  self.shrinkButtonSz = self:getControl("ShrinkButton"):getContentSize()
  self:updateShrinkAndOpenButton()
  self.itemPanel = self:retainCtrl("ItemPanel")
  DlgMgr:sendMsg("HeadDlg", "setVisible", true)
  self.fromDlgInit = true
  self.hasClickReadyBtn = false
  self:onRetinueButton()
  self:updateScTipsPanel()
  self:openCombatViewDlg()
  self:hookMsg("MSG_FFA_MY_INFO")
  self:hookMsg("MSG_FFA_PLAYER_LIST")
  self:hookMsg("MSG_FFA_RETINUE_LIST")
  self:hookMsg("MSG_ENTER_ROOM")
  self:hookMsg("MSG_GENERAL_NOTIFY")
  EventDispatcher:addEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:addEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
end
function DaluandouzjmDlg:openCombatViewDlg()
  DlgMgr:closeDlg("CombatViewDlg")
  local dlg = DlgMgr:openDlg("CombatViewDlg")
  dlg:setDlgType("daluandou")
  if dlg then
    performWithDelay(dlg.root, function()
      DlgMgr:sendMsg("CombatViewDlg", "setDlgViewOutCombat", "daluandou")
    end, 0)
  end
end
function DaluandouzjmDlg:setData(data)
  self.dlgData = data
  local allTimeLabel = self:getControl("TimeLabel", nil, "PlayerPanel")
  allTimeLabel:stopAllActions()
  schedule(allTimeLabel, function()
    local allLeftTime = math.max(0, data.end_time - gf:getServerTime())
    local min = math.floor(allLeftTime / 60)
    local sec = math.floor(allLeftTime % 60)
    if min > 0 then
      allTimeLabel:setString(string.format(CHS[3002678], min, sec))
    else
      allTimeLabel:setString(string.format(CHS[3002677], sec))
    end
    if allLeftTime > 0 then
      allLeftTime = allLeftTime - 1
    else
      allTimeLabel:stopAllActions()
    end
  end, 1)
  local titlePanel = self:getControl("TitlePanel")
  self:setLabelText("NumLabel", string.format(CHS[7100739], data.round), titlePanel)
  if data.has_combat == 1 then
    self:setLabelText("StageLabel", CHS[7100740], titlePanel)
    do
      local leftTime = math.max(0, data.protect_time - gf:getServerTime())
      local timeLabel = self:getControl("TimeLabel", Const.UIAtlasLabel, titlePanel)
      if leftTime <= 10 then
        self:setLabelText("TimeLabel", leftTime, titlePanel, COLOR3.RED)
      else
        self:setLabelText("TimeLabel", leftTime, titlePanel, COLOR3.WHITE)
      end
      self:addCountDownEffect(true)
      timeLabel:stopAllActions()
      schedule(timeLabel, function()
        leftTime = math.max(0, data.protect_time - gf:getServerTime())
        timeLabel:setString(leftTime)
        if leftTime <= 10 then
          self:addCountDownEffect()
          timeLabel:setColor(COLOR3.RED)
        else
          timeLabel:setColor(COLOR3.WHITE)
        end
        if 0 > data.protect_time - gf:getServerTime() then
          timeLabel:stopAllActions()
          self:addCountDownEffect(true)
        end
      end, 1)
    end
  else
    gf:closeConfirmByType("DaluandouzjmDlg")
    self:setLabelText("StageLabel", CHS[7100741], titlePanel)
    self:getControl("TimeLabel", Const.UIAtlasLabel, titlePanel):stopAllActions()
    self:setLabelText("TimeLabel", 60, titlePanel, COLOR3.WHITE)
  end
  self:refreshPlayerList()
end
function DaluandouzjmDlg:updateScTipsPanel()
  self:setCtrlVisible("CallTipsPanel", true)
  if self.retinueList and self.retinueList.count > 0 then
    self:setCtrlVisible("CallTipsPanel", false)
  end
end
function DaluandouzjmDlg:addCountDownEffect(remove)
  local panel = self:getControl("TitlePanel")
  if remove then
    if panel:getChildByName("DaluandouCountDown") then
      panel:removeChildByName("DaluandouCountDown")
    end
    return
  end
  if panel:getChildByName("DaluandouCountDown") then
    return
  end
  local magic = gf:createSelfRemoveMagic(ResMgr.magic.daluandou_count_down, {blendMode = "add"})
  local sz = panel:getContentSize()
  magic:setPosition(sz.width / 2, sz.height)
  magic:setName("DaluandouCountDown")
  panel:addChild(magic)
end
function DaluandouzjmDlg:refreshScore(point)
  self:setLabelText("ScoreLabel", point or self.myData.score, "TitlePanel")
end
function DaluandouzjmDlg:getDlgData()
  return self.dlgData
end
function DaluandouzjmDlg:getMyData()
  return self.myData
end
function DaluandouzjmDlg:getPlayerByGid(gid)
  for i = 1, #self.dlgData.list do
    if self.dlgData.list[i].gid == gid then
      return self.dlgData.list[i]
    end
  end
end
function DaluandouzjmDlg:refreshPlayerList()
  if not self.playerListPanel then
    return
  end
  self.playerListPanel:removeAllChildren()
  local playerList = self.dlgData.list
  local count = #playerList
  if count <= 0 then
    return
  end
  self.playerListPanelSz.height = count * self.itemPanel:getContentSize().height + 10
  self.playerListPanel:setContentSize(self.playerListPanelSz)
  table.sort(playerList, function(l, r)
    if l.is_giveup == 1 and r.is_giveup ~= 1 then
      return true
    end
    if l.is_giveup ~= 1 and r.is_giveup == 1 then
      return false
    end
    if l.win_times < r.win_times then
      return true
    end
    if l.win_times > r.win_times then
      return false
    end
  end)
  for i = 1, count do
    local itemPanel = self.itemPanel:clone()
    self:setSingleItemInfo(itemPanel, playerList[i])
    itemPanel:setPositionY(6 + (i - 1) * self.itemPanel:getContentSize().height)
    self.playerListPanel:addChild(itemPanel)
  end
  self.playerListPanel:setPositionY(self.playerListPanel.org_size.height - self.playerListPanelSz.height)
  self.playerListPanel:requestDoLayout()
  self:updateLayout("PlayerPanel")
  self:onOpenButton()
end
function DaluandouzjmDlg:setSingleItemInfo(panel, info)
  self:setImage("HeadImage", ResMgr:getSmallPortrait(info.icon), panel)
  self:setItemImageSize("HeadImage", panel)
  if info.is_giveup == 1 then
    gf:grayImageView(self:getControl("HeadImage", nil, panel))
  else
    gf:resetImageView(self:getControl("HeadImage", nil, panel))
  end
  self:setLabelText("LvLabel", info.level, panel)
  if info.name == Me:getName() then
    self:setLabelText("NameLabel", gf:getRealName(info.name), panel, COLOR3.GREEN)
  else
    self:setLabelText("NameLabel", gf:getRealName(info.name), panel, cc.c3b(217, 213, 195))
  end
  self:setLabelText("NumLabel", string.format(CHS[7100742], info.win_times, info.lost_times), panel)
  if info.in_combat == 1 then
    self:getControl("TvButton", nil, panel).id = info.id
    self:setCtrlVisible("TvButton", true, panel)
  else
    self:setCtrlVisible("TvButton", false, panel)
  end
  self:setCtrlVisible("ReadyImage", info.is_ready ~= 1 and info.is_giveup == 0 and self.dlgData.has_combat == 1, panel)
  if info.gid == Me:queryBasic("gid") then
    self:setLabelText("WinNumLabel", info.win_times, "TitlePanel")
    self:setCtrlVisible("ReadyButton", info.is_ready ~= 1 and 1 < self.dlgData.round and self.dlgData.has_combat == 1)
  end
end
function DaluandouzjmDlg:updateShrinkAndOpenButton()
  if not self.playerListPanel then
    return
  end
  if self.playerListPanel:getPositionX() < 0 then
    self:setCtrlVisible("OpenButton", true)
    self:setCtrlVisible("ShrinkButton", false)
    self:getControl("OpenButton"):setPositionX(self.shrinkButtonSz.width / 2)
    self:getControl("ShrinkButton"):setPositionX(self.shrinkButtonSz.width / 2)
  else
    self:setCtrlVisible("OpenButton", false)
    self:setCtrlVisible("ShrinkButton", true)
    self:getControl("OpenButton"):setPositionX(self.shrinkButtonSz.width / 2 + self.playerListPanelSz.width)
    self:getControl("ShrinkButton"):setPositionX(self.shrinkButtonSz.width / 2 + self.playerListPanelSz.width)
  end
end
function DaluandouzjmDlg:cleanup()
  self.playerListPanel = nil
  self.shrinkButtonSz = nil
  self.dlgData = nil
  self.myData = nil
  self.retinueList = nil
  self.fromDlgInit = nil
  EventDispatcher:removeEventListener(EVENT.ENTER_COMBAT, self.onEnterCombat, self)
  EventDispatcher:removeEventListener(EVENT.EVENT_END_COMBAT, self.onEndCombat, self)
  DlgMgr:closeDlg("CombatViewDlg")
end
function DaluandouzjmDlg:onTvButton(sender, eventType)
  if string.isNilOrEmpty(sender.id) then
    return
  end
  FightMgr:lookFight(sender.id)
end
function DaluandouzjmDlg:onReadyButton(sender, eventType)
  if self.hasClickReadyBtn then
    gf:CmdToServer("CMD_FFA_PREPARE_OK", {})
  else
    self.hasClickReadyBtn = true
    gf:confirm(CHS[5420397], function()
      gf:CmdToServer("CMD_FFA_PREPARE_OK", {})
    end, nil, nil, nil, nil, nil, nil, "DaluandouzjmDlg")
  end
end
function DaluandouzjmDlg:onTujianButton(sender, eventType)
  DlgMgr:openDlg("DaluandoutjDlg")
end
function DaluandouzjmDlg:onRetinueButton(sender, eventType)
  gf:CmdToServer("CMD_FFA_REQUEST_RETINUE_DATA", {type = 1})
end
function DaluandouzjmDlg:onBagButton(sender, eventType)
  DlgMgr:sendMsg("GameFunctionDlg", "onBagButton")
end
function DaluandouzjmDlg:onRuleButton(sender, eventType)
  DlgMgr:openDlg("DaluandouRuleDlg")
end
function DaluandouzjmDlg:onShrinkButton(sender, eventType)
  if not self.playerListPanel then
    return
  end
  self.playerListPanel:setPositionX(-self.playerListPanelSz.width - 100)
  self:updateShrinkAndOpenButton()
end
function DaluandouzjmDlg:onOpenButton(sender, eventType)
  if not self.playerListPanel then
    return
  end
  self.playerListPanel:setPositionX(0)
  self:updateShrinkAndOpenButton()
end
function DaluandouzjmDlg:MSG_FFA_MY_INFO(data)
  self.myData = data
  self:refreshScore()
  DlgMgr:sendMsg("DaluandousxqhDlg", "setData")
  DlgMgr:sendMsg("DaluandouscDlg", "refreshStorageInfo")
  DlgMgr:sendMsg("DaluandouzmscDlg", "refreshLockPanel")
end
function DaluandouzjmDlg:MSG_FFA_PLAYER_LIST(data)
  self:setData(data)
  DlgMgr:sendMsg("DaluandouscDlg", "refreshTimePanel")
end
function DaluandouzjmDlg:MSG_FFA_RETINUE_LIST(data)
  if self.fromDlgInit then
    self.fromDlgInit = nil
  else
    local dlg = DlgMgr:getDlgByName("DaluandouscDlg")
    dlg = dlg or DlgMgr:openDlg("DaluandouscDlg")
    dlg:setData(data)
  end
  self.retinueList = data
  self:updateScTipsPanel()
end
function DaluandouzjmDlg:MSG_ENTER_ROOM(data)
  if not MapMgr:isInDifuDaluandou() then
    DlgMgr:closeDlg(self.name)
  else
    self:updateScTipsPanel()
  end
end
function DaluandouzjmDlg:MSG_GENERAL_NOTIFY(data)
  if NOTIFY.NOTIFY_SEND_INIT_DATA_DONE == data.notify and not Me:isInCombat() then
    self:openCombatViewDlg()
  end
end
function DaluandouzjmDlg:onEndCombat()
  DlgMgr:sendMsg("HeadDlg", "setVisible", true)
  self:onOpenButton()
  if not DlgMgr:getDlgByName("DaluandouscDlg") then
    DlgMgr:setVisible("DaluandouzjmDlg", true)
  end
  self:updateScTipsPanel()
  self:openCombatViewDlg()
end
function DaluandouzjmDlg:onEnterCombat()
  DlgMgr:closeDlg("DaluandousxqhDlg")
  DlgMgr:closeDlg("DaluandouzmscDlg")
  DlgMgr:closeDlg("DaluandouscDlg")
  DlgMgr:closeDlg("DaluandoudzlsDlg")
  DlgMgr:closeDlg("DaluandouppDlg")
  DlgMgr:closeDlg("DaluandouScCardDlg")
  DlgMgr:closeDlg("DaluandouscxqDlg")
  DlgMgr:closeDlg("DaluandoutjDlg")
end
return DaluandouzjmDlg
