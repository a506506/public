local ArtifactRuleSkillDlg = Singleton("ArtifactRuleSkillDlg", Dialog)
local QMPK_CFG = require(ResMgr:getCfgPath("QuanmmPKCfg.lua"))
function ArtifactRuleSkillDlg:init()
  local fabao = QMPK_CFG[CHS[4100509]]
  for i, name in pairs(fabao) do
    local panel = self:getControl("UnitPanel" .. i)
    self:setImage("ItemImage", InventoryMgr:getIconFileByName(name), panel)
    self:setLabelText("NameLabel", name, panel)
    self:setLabelText("DescLabel", EquipmentMgr:getArtifactSkillDesc(name), panel)
  end
end
return ArtifactRuleSkillDlg
