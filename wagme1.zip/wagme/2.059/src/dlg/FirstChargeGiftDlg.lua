local DataObject = require("core/DataObject")
local FirstChargeGiftDlg = Singleton("FirstChargeGiftDlg", Dialog)
local REWARD_INFO = {
  [0] = CHS[7190018],
  [1] = CHS[7190021],
  [2] = CHS[7190022],
  [3] = CHS[7190023],
  [4] = CHS[7190024],
  [5] = CHS[3001259],
  [6] = CHS[3001147],
  [7] = CHS[3002595],
  [8] = CHS[3002598],
  [9] = CHS[4000357]
}
local SPIRIT_TO_GUARD = {
  [CHS[7190021]] = CHS[3000523],
  [CHS[7190022]] = CHS[3000524],
  [CHS[7190023]] = CHS[3000525],
  [CHS[7190024]] = CHS[3000528]
}
function FirstChargeGiftDlg:init()
  self:bindListener("GotButton", self.onGotButton)
  self:bindListener("GetButton", self.onGetButton)
  self:bindListener("ChargeButton", self.onChargeButton)
  local firstState = GiftMgr:getWelfareData()
  self:setFirstState(firstState.firstChargeState)
  self:initReward()
  self:hookMsg("MSG_SHOUCHONG_CARD_INFO")
  self:hookMsg("MSG_OPEN_WELFARE")
  GiftMgr.lastIndex = "WelfareButton4"
  GiftMgr:setLastTime()
end
function FirstChargeGiftDlg:initReward()
  local panel = self:getControl("ItemImagePanel")
  self:setImage("ItemImage", ResMgr:getSmallPortrait(6320), panel)
  self:setItemImageSize("ItemImage", panel)
  local itemImage = self:getControl("ItemImage", nil, panel)
  InventoryMgr:addLogoBinding(itemImage)
  self:bindTouchEndEventListener(panel, function()
    gf:CmdToServer("CMD_SHOUCHONG_CARD_INFO", {
      type = CHS[3001218],
      name = CHS[7190018]
    })
  end)
  for i = 1, 4 do
    local guardIcon = GuardMgr:getGuardInfoByKey(SPIRIT_TO_GUARD[REWARD_INFO[i]], "icon")
    local imgPath = ResMgr:getSmallPortrait(guardIcon)
    local panel = self:getControl("ItemImagePanel" .. i)
    panel:setTag(i)
    self:setImage("ItemImage", imgPath, panel)
    self:setItemImageSize("ItemImage", panel)
    self:bindTouchEndEventListener(panel, self.onShowItemInfo)
    local itemImage = self:getControl("ItemImage", nil, panel)
    InventoryMgr:addLogoBinding(itemImage)
  end
  for i = 5, 9 do
    local panel = self:getControl("ItemImagePanel" .. i)
    panel:setTag(i)
    self:setImage("ItemImage", ResMgr:getItemIconPath(InventoryMgr:getIconByName(REWARD_INFO[i])), panel)
    self:setItemImageSize("ItemImage", panel)
    self:bindTouchEndEventListener(panel, self.onShowItemInfo)
    local itemImage = self:getControl("ItemImage", nil, panel)
    InventoryMgr:addLogoBinding(itemImage)
  end
  self:setCtrlEnabled("GotButton", false)
end
function FirstChargeGiftDlg:onShowItemInfo(sender, eventType)
  local rect = self:getBoundingBoxInWorldSpace(sender)
  InventoryMgr:showBasicMessageDlg(REWARD_INFO[sender:getTag()], rect, true)
end
function FirstChargeGiftDlg:onGotButton(sender, eventType)
end
function FirstChargeGiftDlg:onGetButton(sender, eventType)
  gf:sendGeneralNotifyCmd(NOTIFY.NOTIFY_FETCH_SHOUCHONG_GIFT)
end
function FirstChargeGiftDlg:onChargeButton(sender, eventType)
  local dlg = DlgMgr:getDlgByName("OnlineRechargeDlg")
  if dlg then
    dlg:reopen()
    DlgMgr:reopenRelativeDlg("OnlineRechargeDlg")
  else
    OnlineMallMgr:openOnlineMall("OnlineRechargeDlg")
  end
end
function FirstChargeGiftDlg:setFirstState(state)
  self:setCtrlVisible("GotButton", false)
  self:setCtrlVisible("GetButton", false)
  self:setCtrlVisible("ChargeButton", false)
  if state == 0 then
    self:setCtrlVisible("ChargeButton", true)
  elseif state == 1 then
    self:setCtrlVisible("GetButton", true)
  elseif state == 2 then
    self:setCtrlVisible("GotButton", true)
  end
end
function FirstChargeGiftDlg:MSG_OPEN_WELFARE(data)
  self:setFirstState(data.firstChargeState)
end
function FirstChargeGiftDlg:MSG_SHOUCHONG_CARD_INFO(data)
  local cardInfo = data.cardInfo
  if data.type == CHS[6000079] then
    local dlg = DlgMgr:openDlg("PetCardDlg")
    local objcet = DataObject.new()
    objcet:absorbBasicFields(cardInfo)
    dlg:setPetInfo(objcet)
  end
end
return FirstChargeGiftDlg
