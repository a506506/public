local FamousAccountDlg = Singleton("FamousAccountDlg", Dialog)
function FamousAccountDlg:init(data)
  self:bindListener("CloseLabel", self.onCloseButton)
  if data then
    self:setInfoPanel(data)
  end
  self.cfg = require(ResMgr:getCfgPath("CreateCharInfo.lua"))
  local magic = self:creatCharDragonBones(self:getBoneIconRes(), "PortraitPanel", "PortraitShowPanel")
  magic:setLocalZOrder(6)
  self:playAnim()
end
function FamousAccountDlg:setInfoPanel(data)
  self:setLabelText("ValueLabel", data.be_worship, "PersonNumPanel")
  if data.be_worship == 0 then
    self:setCtrlVisible("PersonNumPanel", false)
    local infoPanel = self:getControl("InfoPanel")
    infoPanel:setContentSize(infoPanel:getContentSize().width, infoPanel:getContentSize().height + 128)
  end
  local hous, minutes = math.modf(data.duration / 60 / 60)
  minutes = math.floor(minutes * 60)
  if hous ~= 0 then
    local str = string.format(CHS[4000435], hous, minutes)
    if minutes == 0 then
      str = string.format(CHS[4100093], hous)
    end
    self:setLabelText("ValueLabel", str, "TimePanel")
  else
    if minutes == 0 then
      minutes = 1
    end
    local str = string.format(CHS[4300223], minutes)
    self:setLabelText("ValueLabel", str, "TimePanel")
  end
  self:setCtrlVisible("InfoLabel", data.famous_count == 1, "TimePanel")
  self:setLabelText("HourLabel", "", "TimePanel")
  self:setLabelText("ValueLabel", data.score, "PointsPanel")
  self:setCtrlVisible("InfoLabel", data.is_overflow == 1, "PointsPanel")
end
function FamousAccountDlg:playAnim()
  local sz = self.root:getContentSize()
  local magic = ArmatureMgr:createArmature(ResMgr.ArmatureMagic.famous_congra.name)
  self.root:addChild(magic, 3)
  magic:setPosition(sz.width / 2, sz.height / 2)
  local anim = magic:getAnimation()
  anim:play("Top", -1, 100000)
  magic:setLocalZOrder(7)
end
function FamousAccountDlg:creatCharDragonBones(icon, panelName, root)
  local panel = self:getControl(panelName, nil, root)
  local magic = panel:getChildByName("charPortrait")
  if magic then
    if magic:getTag() == icon then
      return magic
    else
      magic:removeFromParent()
    end
  end
  local dbMagic = DragonBonesMgr:createCharDragonBones(icon, string.format("%05d", icon))
  if not dbMagic then
    return
  end
  local magic = tolua.cast(dbMagic, "cc.Node")
  magic:setPosition(panel:getContentSize().width / 2, panel:getContentSize().height / 2 - 75)
  magic:setName("charPortrait")
  magic:setTag(icon)
  panel:addChild(magic)
  magic:setRotationSkewY(180)
  DragonBonesMgr:toPlay(dbMagic, "stand", 0)
  return magic
end
function FamousAccountDlg:getBoneIconRes()
  local gender = Me:queryInt("gender")
  local polar = Me:queryBasicInt("polar")
  local flag = polar * 2
  if gender == 1 then
    flag = flag - 1
  end
  return self.cfg[flag][3]
end
return FamousAccountDlg
