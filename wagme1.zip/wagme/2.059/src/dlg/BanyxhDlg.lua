local BanyxhDlg = Singleton("BanyxhDlg", Dialog)
local DIR = {
  LEFT_DOWN = 1,
  RIGHT_DOWN = 2,
  RIGHT_UP = 3,
  LEFT_UP = 4
}
local ROCK_PANEL_WIDTH = 48
local ROCK_PANEL_HEIGHT = 25
local ITEMS_MAP = {
  CHS[5450367],
  CHS[5450368],
  CHS[6000262]
}
local GAME_STATE = {READY = 0, MOVING = 1}
function BanyxhDlg:init(data)
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel", "BKPanel")
  DlgMgr:closeDlg("ChannelDlg")
  DlgMgr:closeDlg("FriendDlg")
  self:bindListener("InfoButton", self.onInfoButton)
  self:bindListener("ExitButton", self.onExitButton)
  self:blindLongPress("RightButton", self.onRightButtonEx, self.onRightButton)
  self:blindLongPress("UpButton", self.onUpButtonEx, self.onUpButton)
  self:blindLongPress("DownButton", self.onDownButtonEx, self.onDownButton)
  self:blindLongPress("LeftButton", self.onLeftButtonEx, self.onLeftButton)
  self:bindListener("EnterButton", self.onEnterButton)
  self:bindListener("ResetButton", self.onResetButton)
  self:bindListener("ExitButton_1", self.onExitButton_1)
  self:bindListener("ContinueButton", self.onContinueButton)
  self:bindListener("ExitButton_2", self.onExitButton_2)
  self:bindFloatPanelListener("RulePanel")
  self:bindListener("RulePanel", function()
    self:setCtrlVisible("RulePanel", false)
  end)
  self.selectImage = self:retainCtrl("ChosenImage")
  DlgMgr:getDlgByName("ChatDlg"):setVisible(false)
  DlgMgr:closeDlgWhenNoramlDlgOpen(nil, true)
  CharMgr:doCharHideStatus(Me)
  for i = 1, 36 do
    local panel = self:getControl("RockPanel_" .. i)
    panel:setTag(i)
    for j = 1, 5 do
      local unitPanel = self:getControl("Panel_" .. j, nil, panel)
      if not unitPanel then
      else
        unitPanel:setTag(i)
        self:bindTouchEndEventListener(unitPanel, self.onClockRock)
      end
    end
  end
  self.round = nil
  self.enterPanel = nil
  self.flowersNum = 0
  self.gameSate = GAME_STATE.READY
  self.steps = {}
  self.randomFlowers = {}
  self:updateButtonsVisible()
  self:createPlayer()
  self:hookMsg("MSG_GUOQJ_BYXH_GAME_DATA")
  self:hookMsg("MSG_GUOQJ_BYXH_GAME_RESULT")
  local hasShowYSGT = cc.UserDefault:getInstance():getIntegerForKey("BanyxhDlg" .. gf:getShowId(Me:queryBasic("gid"))) or 0
  if not gf:isSameDay5(hasShowYSGT, gf:getServerTime()) then
    self:onInfoButton()
    cc.UserDefault:getInstance():setIntegerForKey("BanyxhDlg" .. gf:getShowId(Me:queryBasic("gid")), gf:getServerTime())
  end
end
function BanyxhDlg:updateButtonsVisible()
  self:setCtrlVisible("EnterButton", self.gameSate == GAME_STATE.READY)
  self:setCtrlVisible("ResetButton", self.gameSate ~= GAME_STATE.READY)
  self:setCtrlVisible("RightButton", self.gameSate ~= GAME_STATE.READY)
  self:setCtrlVisible("UpButton", self.gameSate ~= GAME_STATE.READY)
  self:setCtrlVisible("DownButton", self.gameSate ~= GAME_STATE.READY)
  self:setCtrlVisible("LeftButton", self.gameSate ~= GAME_STATE.READY)
end
function BanyxhDlg:onUpdate()
  if self.player then
    self.player:update()
  end
end
function BanyxhDlg:onClickBlank()
  return true
end
function BanyxhDlg:cleanup()
  if self.player then
    self.player:cleanup()
    self.player = nil
  end
  DlgMgr:sendMsg("ChatDlg", "setVisible", true)
end
function BanyxhDlg:onClockRock(sender, eventType)
  if self.player.curNo then
    return
  end
  local panel = sender:getParent()
  local flower = self:getControl("Image_1", nil, panel):getChildByName("flowers")
  if not flower then
    gf:ShowSmallTips(CHS[4101611])
    return
  end
  self.enterPanel = panel
  self.selectImage:removeFromParent()
  panel:addChild(self.selectImage)
end
function BanyxhDlg:createPlayer()
  self.player = require("obj/activityObj/BanyxhNpc").new()
  self.player:absorbBasicFields({
    icon = Me:queryBasicInt("icon"),
    name = "",
    dir = 5
  })
  self.player:setSeepPrecent(-30)
  local panel = self:getControl("InitPanel")
  local x, y = panel:getPosition()
  self.player:onEnterScene(x, y, self:getControl("YibhPanel"))
  self.player:setAct(Const.SA_STAND)
end
function BanyxhDlg:onInfoButton(sender, eventType)
  self:setCtrlVisible("RulePanel", true)
end
function BanyxhDlg:onExitButton(sender, eventType)
  gf:confirm(CHS[4101612], function()
    gf:CmdToServer("CMD_GUOQJ_BYXH_QUIT_GAME")
  end)
end
function BanyxhDlg:setRound(round, panelName)
  local panel = self:getControl("StagePanel", nil, panelName)
  if panelName == "ResultPanel" then
    if round == 10 then
      round = 13
    end
    self:setImagePlist("Image_2", string.format("lingyzmword%04d.png", round), panel)
  else
    self:setLabelText("Label", string.format(CHS[4200815], round), panel)
  end
end
function BanyxhDlg:moveToByDir(dir, notTips)
  local destNo = self:checkCanGo(dir)
  if not destNo then
    if not notTips then
      gf:ShowSmallTips(CHS[4101613])
    end
    return
  elseif destNo == -1 then
    return
  end
  local panel = self:getControl("YibhPanel")
  local destPanel = panel:getChildByName("RockPanel_" .. destNo)
  if destPanel.flag == "NoFlower" then
    if not notTips then
      gf:ShowSmallTips(CHS[4101613])
    end
    return
  elseif destPanel.flag == "gotFlower" then
    if not notTips then
      gf:ShowSmallTips(CHS[4101614])
    end
    return
  end
  local x, y = destPanel:getPosition()
  self.player:setEndPos(x + ROCK_PANEL_WIDTH, y + ROCK_PANEL_HEIGHT, function()
    self.player.curNo = destNo
    table.insert(self.steps, self.player.curNo)
    local panel = self:getControl("RockPanel_" .. destNo)
    self:removeFlower(panel)
    self:checkResult()
  end)
end
function BanyxhDlg:checkResult()
  if #self.steps == self.flowersNum then
    local ret = {
      gate_index = self.data.gate_index
    }
    ret.count = self.flowersNum
    for i = 1, self.flowersNum do
      ret[i] = self.steps[i] - 1
    end
    gf:CmdToServer("CMD_GUOQJ_BYXH_GAME_RESULT", ret)
  end
end
function BanyxhDlg:checkCanGo(dir)
  if self.player.isMoving then
    return -1
  end
  if not self.player.curNo then
    return
  end
  local curNo = self.player.curNo
  if dir == DIR.LEFT_DOWN then
    if curNo % 6 == 1 then
      return
    end
    curNo = curNo - 1
  elseif dir == DIR.RIGHT_UP then
    if curNo % 6 == 0 then
      return
    end
    curNo = curNo + 1
  elseif dir == DIR.LEFT_UP then
    if curNo <= 6 then
      return
    end
    curNo = curNo - 6
  elseif dir == DIR.RIGHT_DOWN then
    if curNo > 30 then
      return
    end
    curNo = curNo + 6
  end
  return curNo
end
function BanyxhDlg:onRightButton(sender, eventType)
  self:moveToByDir(DIR.RIGHT_DOWN)
end
function BanyxhDlg:onRightButtonEx(sender, eventType)
  self:moveToByDir(DIR.RIGHT_DOWN, true)
end
function BanyxhDlg:onUpButton(sender, eventType)
  self:moveToByDir(DIR.RIGHT_UP)
end
function BanyxhDlg:onUpButtonEx(sender, eventType)
  self:moveToByDir(DIR.RIGHT_UP, true)
end
function BanyxhDlg:onDownButton(sender, eventType)
  self:moveToByDir(DIR.LEFT_DOWN)
end
function BanyxhDlg:onDownButtonEx(sender, eventType)
  self:moveToByDir(DIR.LEFT_DOWN, true)
end
function BanyxhDlg:onLeftButton(sender, eventType)
  self:moveToByDir(DIR.LEFT_UP)
end
function BanyxhDlg:onLeftButtonEx(sender, eventType)
  self:moveToByDir(DIR.LEFT_UP, true)
end
function BanyxhDlg:onEnterButton(sender, eventType)
  if not self.enterPanel then
    gf:ShowSmallTips(CHS[4101615])
    return
  end
  gf:confirm(CHS[4101616], function()
    if not self.enterPanel or not self.player then
      return
    end
    local x, y = self.enterPanel:getPosition()
    self.player:setPos(x + ROCK_PANEL_WIDTH, y + ROCK_PANEL_HEIGHT)
    self.player.curNo = self.enterPanel:getTag()
    table.insert(self.steps, self.player.curNo)
    self.gameSate = GAME_STATE.MOVING
    self:updateButtonsVisible()
    self:removeFlower(self.enterPanel)
    self.enterPanel = nil
    self.selectImage:removeFromParent()
  end)
end
function BanyxhDlg:removeFlower(panel)
  local flower = self:getControl("Image_1", nil, panel):getChildByName("flowers")
  flower:removeFromParent()
  panel.flag = "gotFlower"
end
function BanyxhDlg:onResetButton(sender, eventType)
  local curStep = #self.steps
  if curStep == self.flowersNum then
    gf:ShowSmallTips(CHS[4101617])
    return
  end
  gf:confirm(CHS[4101618], function()
    self:resetGame(true)
  end)
end
function BanyxhDlg:resetGame(isResetData)
  if not self.player then
    return
  end
  local panel = self:getControl("InitPanel")
  local x, y = panel:getPosition()
  self.player:onEnterScene(x, y, self:getControl("YibhPanel"))
  self.player:setAct(Const.SA_STAND)
  self.player:setDir(5)
  self.player.curNo = nil
  self.steps = {}
  self.gameSate = GAME_STATE.READY
  self:updateButtonsVisible()
  if isResetData then
    self:MSG_GUOQJ_BYXH_GAME_DATA(self.data)
  end
end
function BanyxhDlg:onExitButton_1(sender, eventType)
  gf:CmdToServer("CMD_GUOQJ_BYXH_QUIT_GAME")
end
function BanyxhDlg:onContinueButton(sender, eventType)
  self:setCtrlVisible("ResultPanel", false)
  gf:CmdToServer("CMD_GUOQJ_BYXH_RESTART")
end
function BanyxhDlg:onExitButton_2(sender, eventType)
  gf:CmdToServer("CMD_GUOQJ_BYXH_QUIT_GAME")
end
function BanyxhDlg:MSG_GUOQJ_BYXH_GAME_RESULT(data)
  if data.gate_index == 3 or data.gate_index == 6 then
    self:setCtrlVisible("ResultPanel", true)
    self:setCtrlVisible("RulePanel", false)
    self:setRound(data.gate_index, "ResultPanel")
    self:setCtrlVisible("ExitButton_1", data.gate_index <= 5)
    self:setCtrlVisible("ContinueButton", data.gate_index <= 5)
    self:setCtrlVisible("ExitButton_2", data.gate_index > 5)
    for i = 1, 36 do
      local panel = self:getControl("RockPanel_" .. i)
      local image = self:setImage("Image_1", ResMgr.ui.hqzm_grid_dark, panel)
      panel.flag = "NoFlower"
      image:removeAllChildren()
    end
  else
    performWithDelay(self.root, function()
      self:onContinueButton()
    end, 0.3)
  end
end
function BanyxhDlg:MSG_GUOQJ_BYXH_GAME_DATA(data)
  self:setCtrlVisible("ResultPanel", false)
  self.data = data
  self.flowersNum = 0
  self:setRound(data.gate_index)
  self:resetGame(false)
  for i = 1, 36 do
    local panel = self:getControl("RockPanel_" .. i)
    if data.cells[i] == 0 then
      local image = self:setImage("Image_1", ResMgr.ui.hqzm_grid_dark, panel)
      panel.flag = "NoFlower"
      image:removeAllChildren()
    elseif data.cells[i] == 1 then
      local image = self:setImage("Image_1", ResMgr.ui.hqzm_grid_white, panel)
      image:removeAllChildren()
      local idx = data.seed % 3 + 1
      self.randomFlowers[i] = idx
      local itemIconPath = ResMgr:getItemIconPath(InventoryMgr:getIconByName(ITEMS_MAP[idx]))
      local mapSprite = cc.Sprite:create(itemIconPath)
      mapSprite:setName("flowers")
      mapSprite:setAnchorPoint(0.5, 0.5)
      mapSprite:setPosition(ROCK_PANEL_WIDTH * 1.25, ROCK_PANEL_HEIGHT * 1.5)
      mapSprite:setScale(0.45)
      image:addChild(mapSprite)
      panel.flag = "hasFlower"
      self.flowersNum = self.flowersNum + 1
    end
  end
end
function BanyxhDlg:blindLongPressWithCtrl(widget, OneSecondLaterFunc, func, needJudgeCancled, isCallTouchEnd, cancelFun)
  if type(widget) ~= "userdata" then
    return
  end
  if not widget then
    Log:W("Dialog:bindListViewListener no control " .. self.name)
    return
  end
  local function listener(sender, eventType)
    if eventType == ccui.TouchEventType.began then
      local callFunc = cc.CallFunc:create(function()
        if GuideMgr:isRunning() then
          return
        end
        sender:stopAction(self.longPress)
        self.longPress = nil
        if type(OneSecondLaterFunc) == "function" then
          if needJudgeCancled and not sender:isHighlighted() then
            return
          end
          self.lpSchedule = self:startSchedule(function()
            OneSecondLaterFunc(self, sender, eventType)
          end, 0.1)
        end
      end)
      self:stopSchedule(self.lpSchedule)
      self.longPress = cc.Sequence:create(cc.DelayTime:create(GameMgr:getLongPressTime()), callFunc)
      sender:runAction(self.longPress)
    elseif eventType == ccui.TouchEventType.ended then
      if self.longPress ~= nil then
        sender:stopAction(self.longPress)
        self.longPress = nil
        if type(func) == "function" then
          GuideMgr:touchLongCtrl(self.name, widget:getName())
          func(self, sender, eventType)
          return
        end
      end
      if isCallTouchEnd and type(func) == "function" then
        func(self, sender, eventType)
        GuideMgr:touchLongCtrl(self.name, widget:getName())
      end
      self:stopSchedule(self.lpSchedule)
    elseif eventType == ccui.TouchEventType.canceled then
      self:stopSchedule(self.lpSchedule)
      if self.longPress ~= nil then
        sender:stopAction(self.longPress)
        self.longPress = nil
      end
      if cancelFun and type(cancelFun) == "function" then
        cancelFun(self, sender, eventType)
      end
    end
  end
  widget:addTouchEventListener(listener)
end
return BanyxhDlg
