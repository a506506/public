local DramaDlg = Singleton("DramaDlg", Dialog)
local DragonBones = require("animate/DragonBones")
DramaDlg.OPER = {
  SKIP_SCENAROID = 1,
  NEXT_SCENE = 2,
  CLOSED = 3
}
local AUTO_DELAY = 20
local SCENAROID_END = 1
local MARGIN = 10
local isEnd = false
local hasNewOne = false
local curData = {}
local SHAPE_OFFSET = {
  [1273] = {
    imgOff = {y = -30, x = 0},
    bonesOff = {y = -56, x = -20}
  },
  [1274] = {
    bonesOff = {y = -26, x = -20}
  },
  [6321] = {
    bonesOff = {y = -26, x = -20}
  }
}
local ICON_OPACITY_CFG = {
  [CHS[7190301]] = 153,
  [CHS[5400826]] = 180,
  [CHS[5400827]] = 180,
  [CHS[5400832]] = 180,
  [CHS[5400833]] = 180
}
function DramaDlg:init()
  AutoWalkMgr:cleanup()
  self:bindListener("SkipButton", self.onSkipButton)
  self:bindListener("TouchPanel", self.onNextScene)
  self.turnToNextScene = false
  local contentSize = self.root:getContentSize()
  self:setFullScreen()
  self:setCtrlVisible("OtherNameLabel", false)
  self:setCtrlVisible("OtherShapeImage", false)
  self.blank:setLocalZOrder(Const.ZORDER_TOPMOST)
  local winSize = self:getWinSize()
  local bkCtrl = self:getControl("BKPanel")
  bkCtrl:setContentSize(winSize.width / Const.UI_SCALE, bkCtrl:getContentSize().height)
  local dramaCtrl = self:getControl("DramaPanel")
  dramaCtrl:setContentSize(winSize.width / Const.UI_SCALE, dramaCtrl:getContentSize().height)
  local touchPanel = self:getControl("TouchPanel")
  touchPanel:setContentSize(cc.size(Const.WINSIZE.width / Const.UI_SCALE, Const.WINSIZE.height / Const.UI_SCALE))
  touchPanel:setPosition(cc.p(-winSize.ox or 0 - (winSize.x or 0), (-winSize.oy or 0) - (winSize.y or 0)))
  local screenPanel = self:getControl("LockScreenPanel")
  screenPanel:setContentSize(cc.size(Const.WINSIZE.width / Const.UI_SCALE, Const.WINSIZE.height / Const.UI_SCALE))
  screenPanel:setPosition(cc.p(-winSize.ox or 0 - (winSize.x or 0), (-winSize.oy or 0) - (winSize.y or 0)))
  self:startAction()
  local x, y = self:getControl("ShapeImage", nil, "NpcNormalPanel"):getPosition()
  self.shapeImgPos = {x = x, y = y}
  x, y = self:getControl("ShapeChildPanel", nil, "NpcBonesPanel"):getPosition()
  self.shapeBonesPos = {x = x, y = y}
  MapSpecialEventMgr:checkPauseOrResume(nil, true)
  self:hookMsg("MSG_PLAY_SCENARIOD")
end
function DramaDlg:startAction()
  self:closeAllAction()
  local bkCtrl = self:getControl("BKPanel")
  local dramaCtrl = self:getControl("DramaPanel")
  self:setCtrlVisible("NpcPanel", false)
  bkCtrl:setAnchorPoint(cc.p(0, 1))
  bkCtrl:setPosition(0, Const.WINSIZE.height / Const.UI_SCALE + bkCtrl:getContentSize().height)
  local bkMoveAction = cc.MoveBy:create(0.3, cc.p(0, -bkCtrl:getContentSize().height))
  bkCtrl:stopAllActions()
  bkCtrl:runAction(bkMoveAction)
  local winSize = self:getWinSize()
  dramaCtrl:setPosition(0, -dramaCtrl:getContentSize().height - winSize.oy)
  dramaCtrl:setAnchorPoint(cc.p(0, 0))
  local dramaMoveAction = cc.MoveBy:create(0.3, cc.p(0, dramaCtrl:getContentSize().height))
  local func = cc.CallFunc:create(function()
    self.isOpenFinish = true
    self:setCtrlVisible("NpcPanel", true)
    Log:D(CHS[3002382])
    local winSize = self:getWinSize()
    if winSize and winSize.fullback then
      DlgMgr:setVisible(winSize.fullback, false)
    end
  end)
  dramaCtrl:stopAllActions()
  dramaCtrl:runAction(cc.Sequence:create(dramaMoveAction, func))
  self.blank.colorLayer:setVisible(false)
  local upPanel = self:getControl("LockScreenPanel")
  upPanel:setContentSize(Const.WINSIZE.width / Const.UI_SCALE, Const.WINSIZE.height / Const.UI_SCALE)
  local imageCtrl = self:getControl("LockScreenUpImage")
  imageCtrl:setContentSize(Const.WINSIZE.width / Const.UI_SCALE, imageCtrl:getContentSize().height)
  imageCtrl = self:getControl("LockScreenDownImage")
  imageCtrl:setContentSize(Const.WINSIZE.width / Const.UI_SCALE, imageCtrl:getContentSize().height)
end
function DramaDlg:closeAction()
  local bkCtrl = self:getControl("BKPanel")
  local dramaCtrl = self:getControl("DramaPanel")
  bkCtrl:setAnchorPoint(cc.p(0, 1))
  local bkMoveAction = cc.MoveBy:create(0.3, cc.p(0, bkCtrl:getContentSize().height))
  bkCtrl:runAction(bkMoveAction)
  local winSize = self:getWinSize()
  dramaCtrl:setAnchorPoint(cc.p(0, 0))
  local dramaMoveAction = cc.MoveBy:create(0.3, cc.p(0, -dramaCtrl:getContentSize().height - winSize.oy))
  local func = cc.CallFunc:create(function()
    self:setCtrlVisible("NpcPanel", false)
    Log:D(CHS[3002383])
  end)
  local func2 = cc.CallFunc:create(function()
    local winSize = self:getWinSize()
    if winSize and winSize.fullback then
      DlgMgr:setVisible(winSize.fullback, true)
    end
    self:FrozenScreen()
    local fadeOut1 = cc.FadeOut:create(0.2)
    local fadeOut2 = cc.FadeOut:create(0.2)
    local panel1 = self:getControl("NpcBonesPanel")
    local panel2 = self:getControl("NpcNormalPanel")
    panel2:runAction(fadeOut2)
  end)
  local delay = cc.DelayTime:create(0.2)
  local func3 = cc.CallFunc:create(function()
    self:releaseBones()
  end)
  dramaCtrl:stopAllActions()
  dramaCtrl:runAction(cc.Spawn:create(cc.Sequence:create(func, dramaMoveAction, func3), func2))
end
function DramaDlg:isCanResetMainDlgs()
  if HomeChildMgr:isInDailyTask() then
    return false
  end
  if DlgMgr:getDlgByName("ChongyangfzlrDlg") then
    return false
  end
  if TanAnJnszMgr.followStatus and TanAnJnszMgr.followStatus ~= 0 then
    return false
  end
  if TanAnJnszMgr.pullCarStatus and TanAnJnszMgr.pullCarStatus ~= 0 then
    return false
  end
  return true
end
function DramaDlg:cmdOperScenariod(type, para)
  gf:CmdToServer("CMD_OPER_SCENARIOD", {
    id = self.id,
    type = type,
    para = para
  })
end
function DramaDlg:cleanup()
  if nil ~= self.id then
    if not BattleSimulatorMgr:isRunning() and not isEnd then
      self:cmdOperScenariod(self.OPER.SKIP_SCENAROID, " ")
    end
    self:cmdOperScenariod(self.OPER.CLOSED, "")
  end
  local winSize = self:getWinSize()
  if winSize and winSize.fullback then
    DlgMgr:setVisible(winSize.fullback, true)
  end
  if not Me:isInCombat() and not Me:isLookOn() then
    if self:isCanResetMainDlgs() then
      DlgMgr:setAllDlgVisible(true)
    end
  else
    FightMgr:openFightDlgs()
  end
  self.id = nil
  isEnd = nil
  hasNewOne = nil
  curData = {}
  self.totalDelay = nil
  if Me.selectTarget then
    Me.selectTarget:removeFocusMagic()
  end
  self:releaseBones()
  if not DlgMgr:getDlgByName("NpcDlg") then
    MapSpecialEventMgr:checkPauseOrResume()
  end
end
function DramaDlg:releaseBones()
  local panel = self:getControl("ShapeChildPanel")
  panel:removeAllChildren()
end
function DramaDlg:getRealName(name, banRule)
  return gf:getShowName(gf:getRealName(name, true), banRule)
end
function DramaDlg:updateView(data)
  curData = data
  self.id = data.id
  self.content = data.content
  if SCENAROID_END == data.isComplete then
    if Me:isInCombat() or Me:isLookOn() then
      self:closeAction()
    end
    isEnd = data.isComplete
    return
  end
  local ctrl = self:getControl("SkipButton")
  local visible = (1 ~= curData.isInCombat or nil ~= GFightMgr.SkipSyncMessage) and not BattleSimulatorMgr:isRunning()
  self:setCtrlVisible("SkipImage_1", visible)
  self:setCtrlVisible("SkipNoteLabel", visible)
  ctrl:setVisible(visible)
  local textLableCtrl = self:getControl("Panel_21")
  local box = textLableCtrl:getContentSize()
  local width = Const.WINSIZE.width / Const.UI_SCALE - textLableCtrl:getPositionX() + box.width / 2 - 100 * Const.UI_SCALE
  box.width = box.width * (Const.WINSIZE.width / Const.UI_DESIGN_WIDTH)
  local tip = CGAColorTextList:create()
  if data.portrait ~= 0 then
    tip:setDefaultColor(COLOR3.DRAMA_TEXT_DEFAULT.r, COLOR3.DRAMA_TEXT_DEFAULT.g, COLOR3.DRAMA_TEXT_DEFAULT.b)
  else
    tip:setDefaultColor(COLOR3.BLUE.r, COLOR3.BLUE.g, COLOR3.BLUE.b)
  end
  tip:setFontSize(25)
  if tip.setPunctTypesetting then
    tip:setPunctTypesetting(true)
  end
  tip:setContentSize(box.width, 0)
  tip:setString(data.content, true)
  tip:setPosition(MARGIN, box.height)
  tip:updateNow()
  textLableCtrl:removeAllChildren()
  textLableCtrl:addChild(tolua.cast(tip, "cc.LayerColor"))
  self:setLabelText("ContentLabel", "")
  self:setCtrlVisible("NpcBonesPanel", false)
  self:setCtrlVisible("NpcNormalPanel", false)
  if data.portrait ~= 0 then
    local bonesPath, texturePath = ResMgr:getBonesCharFilePath(data.portrait)
    local bExist = cc.FileUtils:getInstance():isFileExist(bonesPath)
    local showName = self:getRealName(data.name, data.name_ban_rule)
    local portrait
    if bExist then
      local portraitsPanel = self:getControl("NpcBonesPanel")
      portraitsPanel:setVisible(true)
      portrait = self:creatCharDragonBones(data.portrait, "ShapeChildPanel")
      self:setLabelText("NameLabel_1", showName, portraitsPanel)
      self:setLabelText("NameLabel_2", showName, portraitsPanel)
      local shapePanel = self:getControl("ShapeChildPanel", nil, portraitsPanel)
      local offsets = SHAPE_OFFSET[data.portrait]
      if offsets and offsets.bonesOff then
        local offset = offsets.bonesOff
        shapePanel:setPosition(self.shapeBonesPos.x + offset.x, self.shapeBonesPos.y + offset.y)
      else
        shapePanel:setPosition(self.shapeBonesPos.x, self.shapeBonesPos.y)
      end
      if ICON_OPACITY_CFG[data.name] then
        portrait:setAlpha(ICON_OPACITY_CFG[data.name])
      end
    else
      local portraitsPanel = self:getControl("NpcNormalPanel")
      portraitsPanel:setVisible(true)
      portraitsPanel:setOpacity(255)
      portraitsPanel:stopAllActions()
      self:setLabelText("NameLabel_1", showName, portraitsPanel)
      self:setLabelText("NameLabel_2", showName, portraitsPanel)
      local iconPath = ResMgr:getBigPortrait(data.portrait)
      self:setImage("ShapeImage", iconPath, portraitsPanel)
      self:setCtrlVisible("ShapeImage", true, portraitsPanel)
      self:setCtrlVisible("NamePanel", true, portraitsPanel)
      self:updateLayout("ShapePanel", portraitsPanel)
      local img = self:getControl("ShapeImage", nil, portraitsPanel)
      local offsets = SHAPE_OFFSET[data.portrait]
      if offsets and offsets.imgOff then
        local offset = offsets.imgOff
        img:setPosition(self.shapeImgPos.x + offset.x, self.shapeImgPos.y + offset.y)
      else
        img:setPosition(self.shapeImgPos.x, self.shapeImgPos.y)
      end
      if ICON_OPACITY_CFG[data.name] then
        img:setOpacity(ICON_OPACITY_CFG[data.name])
      end
    end
  else
    self:setCtrlVisible("ShapeImage", false, "NpcBonesPanel")
    self:setCtrlVisible("NamePanel", false, "NpcBonesPanel")
    self:setCtrlVisible("ShapeImage", false, "NpcNormalPanel")
    self:setCtrlVisible("NamePanel", false, "NpcNormalPanel")
  end
end
function DramaDlg:creatCharDragonBones(icon, panelName)
  local panel = self:getControl(panelName)
  local magic = panel:getChildByName("charPortrait")
  if magic then
    if magic:getTag() == icon then
      return magic
    else
      magic:removeFromParent()
    end
  end
  local magic = DragonBones.new(icon)
  local size = panel:getContentSize()
  magic:setPosition(size.width * 0.5 + 16, 26)
  magic:setName("charPortrait")
  magic:setTag(icon)
  panel:addChild(magic)
  magic:setRTextSizeAndPos(size, cc.p(size.width * 0.5 + 16, 26))
  panel:setClippingEnabled(false)
  magic:toPlay("stand", 0)
  return magic
end
function DramaDlg:onSkipButton(sender, eventType)
  if nil == self.id then
    return
  end
  if SCENAROID_END == isEnd then
    if not Me:isInCombat() and not Me:isLookOn() then
      if self:isCanResetMainDlgs() then
        DlgMgr:setAllDlgVisible(true)
      end
    else
      FightMgr:openFightDlgs()
    end
    isEnd = nil
    return
  end
  if not BattleSimulatorMgr:isRunning() then
    self:cmdOperScenariod(self.OPER.SKIP_SCENAROID, "")
  else
    self:cmdOperScenariod(self.OPER.SKIP_SCENAROID, " ")
  end
  if 1 == curData.isInCombat then
    GFightMgr:SkipSyncMessage(45056)
  end
  self:cmdOperScenariod(self.OPER.CLOSED, "")
  self.id = nil
  isEnd = nil
  DlgMgr:closeDlg(self.name)
  if not Me:isInCombat() and not Me:isLookOn() then
    TaskMgr:continueTaskAutoWalk()
    if self:isCanResetMainDlgs() then
      DlgMgr:setAllDlgVisible(true)
    end
  else
    FightMgr:openFightDlgs()
  end
end
function DramaDlg:onNextScene(sender, eventType)
  if nil == self.id then
    return
  end
  if SCENAROID_END == isEnd then
    self:FrozenScreen()
    return
  end
  self.lastClickTime = gfGetTickCount()
  self.turnToNextScene = true
  if not BattleSimulatorMgr:isRunning() then
    self:cmdOperScenariod(self.OPER.NEXT_SCENE, "")
  else
    BattleSimulatorMgr:sendCombatDoActionToBattleSimulator("CMD_OPER_SCENARIOD", {
      id = self.id,
      type = 1,
      para = ""
    })
  end
end
function DramaDlg:FrozenScreen()
  if not self.totalDelay then
    self.frozenStartTime = gfGetTickCount()
    self.totalDelay = 3
  end
  if gfGetTickCount() - self.frozenStartTime >= self.totalDelay * 1000 then
    return
  end
  local func = cc.CallFunc:create(function()
    local funcClose = cc.CallFunc:create(function()
      if hasNewOne then
        return
      end
      self.totalDelay = nil
      DlgMgr:closeDlg(self.name)
      if not Me:isInCombat() and not Me:isLookOn() then
        if self:isCanResetMainDlgs() then
          DlgMgr:setAllDlgVisible(true)
        end
      else
        FightMgr:openFightDlgs()
      end
    end)
    local fadeOut = cc.FadeOut:create(0.5)
    local imageCtrl = self:getControl("LockScreenPanel")
    imageCtrl:stopAllActions()
    imageCtrl:runAction(cc.Sequence:create(fadeOut, funcClose))
  end)
  local delayTime = math.min(math.max(0, self.totalDelay * 1000 - (gfGetTickCount() - self.frozenStartTime)) / 1000, 0.3)
  local action = cc.Sequence:create(cc.DelayTime:create(delayTime), func)
  self.root:stopAllActions()
  self.root:runAction(action)
end
function DramaDlg:closeAllAction()
  self:stopAllAction("BKPanel")
  self:stopAllAction("DramaPanel")
  self:stopAllAction("LockScreenPanel")
  self:stopAllAction(self.root)
end
function DramaDlg:MSG_PLAY_SCENARIOD(data)
  if not DlgMgr:isDlgOpened(self.name) then
    return
  end
  self:updateView(data)
  self.turnToNextScene = false
  self.totalDelay = nil
  if SCENAROID_END == data.isComplete then
    hasNewOne = false
    self:closeAction()
    DlgMgr:sendMsg("GameFunctionDlg", "openFastUseDlg")
    TaskMgr:continueTaskAutoWalk()
    return
  end
  if isEnd and not hasNewOne then
    self:startAction()
  end
  hasNewOne = true
  isEnd = false
  local delay = cc.DelayTime:create(data.playTime or AUTO_DELAY)
  local func = cc.CallFunc:create(function()
    self:onNextScene()
  end)
  local action = cc.Sequence:create(delay, func)
  self.root:stopAllActions()
  self.root:runAction(action)
end
function DramaDlg:getDramaState()
  return isEnd
end
function DramaDlg:isTurnToNextScene()
  return self.turnToNextScene
end
function DramaDlg:juestShowBlackBackground()
  self:setCtrlVisible("NpcNormalPanel", false, "DramaPanel")
  self:setCtrlVisible("NpcBonesPanel", false, "DramaPanel")
  self:setCtrlVisible("NoteLabel", false, "BKPanel")
  self:setCtrlVisible("SkipPanel", false, "BKPanel")
end
return DramaDlg
