local CountDownDlg = Singleton("CountDownDlg", Dialog)
local NumImg = require("ctrl/NumImg")
function CountDownDlg:init()
  self:setFullScreen()
  self.cdType = nil
  self.callBack = nil
  self.para = nil
  self.nextCdType = nil
  self.nextCallBack = nil
  self.nextPara = nil
  self:setCtrlVisible("StartImage", false)
  self.numImg = self:initTimePanel("TimePanel")
  self.numImg2 = self:initTimePanel("TimePanel2")
end
function CountDownDlg:initTimePanel(panelName)
  local timePanel = self:getControl(panelName)
  if timePanel then
    local sz = timePanel:getContentSize()
    local numImg = timePanel:getChildByTag(999)
    numImg = numImg or NumImg.new("bfight_num", 5, false, -5)
    numImg:setPosition(sz.width / 2, sz.height / 2)
    numImg:setVisible(true)
    numImg:setScale(0.5, 0.5)
    timePanel:addChild(numImg, 999)
    numImg:setPosition(sz.width / 2, sz.height / 2)
    return numImg
  end
end
function CountDownDlg:setNextData(cdType, callBack, para, endTime)
  self.nextCdType = cdType
  self.nextCallBack = callBack
  self.nextPara = para
  self.nextEndTime = endTime
  if self.schId then
    self.root:stopAction(self.schId)
    self.schId = nil
    self:setData(cdType, callBack, para)
    self:setNextData(nil, nil, nil, nil)
    local leftTime = endTime - gf:getServerTime()
    self:startCountDown(leftTime)
  end
end
function CountDownDlg:getNumImgByPara(para)
  self.numImg:setVisible(false)
  self.numImg2:setVisible(false)
  if para and type(para) == "table" and para.panelName == "TimePanel2" then
    self:setCtrlVisible("TimePanel", false)
    self:setCtrlVisible("TimePanel2", true)
    self.numImg2:setVisible(true)
    return self.numImg2, "TimePanel2"
  end
  self.numImg:setVisible(true)
  self:setCtrlVisible("TimePanel", true)
  self:setCtrlVisible("TimePanel2", false)
  return self.numImg, "TimePanel"
end
function CountDownDlg:setData(cdType, callBack, para)
  self.cdType = cdType
  self.callBack = callBack
  self.para = para
  local numImg = self:getNumImgByPara(para)
  if para and type(para) == "table" then
    if para.scale and numImg then
      numImg:setScale(para.scale)
    end
    if para.magicType == 1 then
      self:addMagic(self:getControl("TimePanel"), para.magicName, {
        extraPara = {
          blendMode = para.blendMode
        }
      })
    end
  elseif para == "FubenMissionForBSSZDlg" then
  end
end
function CountDownDlg:resetCountDown(time)
  local numImg = self:getNumImgByPara(self.para)
  if not numImg then
    return
  end
  if self.cdType == "start" or self.cdType == "end" then
    time = time - 1
  else
  end
  self:setCtrlVisible("StartImage", false)
  numImg:setVisible(true)
  numImg:startCountDown()
end
function CountDownDlg:startCountDown(time)
  local numImg, panelName = self:getNumImgByPara(self.para)
  if not numImg then
    local timePanel = self:getControl(panelName)
    local sz = timePanel:getContentSize()
    numImg = NumImg.new("bfight_num", 5, false, -5)
    numImg:setPosition(sz.width / 2, sz.height / 2)
    numImg:setVisible(true)
    numImg:setScale(0.5, 0.5)
    timePanel:addChild(numImg, 999)
    numImg:setPosition(sz.width / 2, sz.height / 2)
  end
  if self.schId then
    self.root:stopAction(self.schId)
    self.schId = nil
  end
  numImg:unscheduleUpdate()
  if self.cdType == "start" or self.cdType == "end" then
    time = time - 1
  else
  end
  numImg:setNum(time, false)
  numImg:setVisible(true)
  self:setCtrlVisible(panelName, true)
  self:setCtrlVisible("StartImage", false)
  numImg:startCountDown(function()
    numImg:setVisible(false)
    local delayTime = 0
    if self.cdType == "start" then
      self:setImage("StartImage", ResMgr.ui.start_icon)
      self:setCtrlVisible("StartImage", true)
      delayTime = 1
    else
      if self.cdType == "end" then
        self:setImage("StartImage", ResMgr.ui.end_icon)
        self:setCtrlVisible("StartImage", true)
        delayTime = 1
      else
      end
    end
    if delayTime > 0 and self.nextEndTime then
      self.schId2 = performWithDelay(self.root, function()
        if self.callBack and type(self.callBack) == "function" then
          self.callBack(self.para)
        end
        local leftTime = self.nextEndTime - gf:getServerTime()
        self:setData(self.nextCdType, self.callBack, self.para)
        self:setNextData(nil, nil, nil, nil)
        self:startCountDown(leftTime)
      end, delayTime)
    else
      self.schId = performWithDelay(self.root, function()
        if self.callBack and type(self.callBack) == "function" then
          self.callBack(self.para)
        end
        self:onCloseButton()
      end, delayTime)
    end
  end)
end
function CountDownDlg:startCountDownWithDelay(time, delay)
  local numImg, panelName = self:getNumImgByPara(self.para)
  if not numImg then
    local timePanel = self:getControl(panelName)
    local sz = timePanel:getContentSize()
    numImg = NumImg.new("bfight_num", 5, false, -5)
    numImg:setPosition(sz.width / 2, sz.height / 2)
    numImg:setVisible(true)
    numImg:setScale(0.5, 0.5)
    timePanel:addChild(numImg, 999)
    numImg:setPosition(sz.width / 2, sz.height / 2)
  end
  if self.schId then
    self.root:stopAction(self.schId)
    self.schId = nil
  end
  numImg:unscheduleUpdate()
  numImg:setNum(time, false)
  numImg:setVisible(true)
  self:setCtrlVisible(panelName, true)
  self:setCtrlVisible("StartImage", false)
  self:stopDelayCountDown()
  self.delayCountDown = self:startSchedule(function()
    time = time - 1
    if time > 0 then
      numImg:setNum(time, false)
    else
      if self.callBack and type(self.callBack) == "function" then
        self.callBack(self.para)
      end
      self:onCloseButton()
    end
  end, delay)
end
function CountDownDlg:stopDelayCountDown()
  if self.delayCountDown then
    self.root:stopAction(self.delayCountDown)
    self.delayCountDown = nil
  end
end
function CountDownDlg:cleanup()
  if self.schId then
    self.root:stopAction(self.schId)
    self.schId = nil
  end
  if self.schId2 then
    self.root:stopAction(self.schId2)
    self.schId2 = nil
  end
  self:stopDelayCountDown()
end
return CountDownDlg
