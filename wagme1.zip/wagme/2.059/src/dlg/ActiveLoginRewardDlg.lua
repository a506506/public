local LoginRewardDlg = require("dlg/LoginRewardDlg")
local ActiveLoginRewardDlg = Singleton("ActiveLoginRewardDlg", LoginRewardDlg)
local RewardContainer = require("ctrl/RewardContainer")
local CONTAINNER_TAG = 99
function ActiveLoginRewardDlg:init()
  LoginRewardDlg.init(self)
  self:hookMsg("MSG_SEVENDAY_GIFT_FLAG")
end
function ActiveLoginRewardDlg:getGiftData()
  return GiftMgr:getActiveLoginGiftData()
end
function ActiveLoginRewardDlg:getGiftFlagData()
  return GiftMgr:getActiveLoginGiftFlagData()
end
function ActiveLoginRewardDlg:requestGiftData()
  gf:CmdToServer("CMD_SEVENDAY_GIFT_LIST", {})
end
function ActiveLoginRewardDlg:takeReward(index)
  gf:CmdToServer("CMD_SEVENDAY_GIFT_FETCH", {day = index})
end
function ActiveLoginRewardDlg:MSG_SEVENDAY_GIFT_FLAG(data)
  self:initDataInfo(GiftMgr:getActiveLoginGiftData())
  self:undateButtonState(GiftMgr:getActiveLoginGiftFlagData())
end
function ActiveLoginRewardDlg:cleanup()
end
return ActiveLoginRewardDlg
