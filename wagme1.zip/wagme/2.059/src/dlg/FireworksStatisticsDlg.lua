local FireworksStatisticsDlg = Singleton("FireworksStatisticsDlg", Dialog)
local RewardContainer = require("ctrl/RewardContainer")
function FireworksStatisticsDlg:init()
end
function FireworksStatisticsDlg:setData(data, rewards)
  local panel, classList, reward, imgPath, textureResType
  for i = 1, #rewards do
    panel = self:getControl(string.format("RewardPanel%d", i))
    classList = TaskMgr:getRewardList(rewards[i][2])
    if not classList[1] or not next(classList[1]) then
      return
    end
    reward = classList[1][1]
    local name = RewardContainer:getTextList(reward)[1]
    if i == 1 then
      name = 300 .. name
    end
    imgPath, textureResType = RewardContainer:getRewardPath(reward)
    if textureResType == ccui.TextureResType.plistType then
      self:setImagePlist("ItemImage", imgPath, panel)
    else
      self:setImage("ItemImage", imgPath, panel)
    end
    local numIndex = DistMgr:curIsTestDist() and 5 or 3
    local num = rewards[i][numIndex]
    if data.shoot_num >= rewards[i][1] then
      num = num * 2
    end
    self:setLabelText("NumLabel", string.format(CHS[5420442], num), panel)
    self:setLabelText("NameLabel", name, panel)
  end
end
return FireworksStatisticsDlg
