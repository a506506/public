local FubenMissionDlg = Singleton("FubenMissionDlg", Dialog)
local RadioGroup = require("ctrl/RadioGroup")
local BUTTON_STATE = {BUTTTON_STATE_HIDE = 0, BUTTON_STATE_SHOW = 1}
function FubenMissionDlg:getCfgFileName()
  return ResMgr:getDlgCfg("FubenMissionDlg")
end
function FubenMissionDlg:init()
  self:setFullScreen()
  self:bindListener("HideDialogButton", self.onHideDialogButton)
  self:bindListener("ShowDialogButton", self.onShowDialogButton)
  self:bindListener("ExitMatchButton", self.onExitMatchButton)
  self:bindListener("LeaveButton", self.onLeaveButton)
  self:bindListViewListener("TeamListView", self.onSelectTeamListView)
  self:bindListener("ChallengePanel", self.onFubenInfo)
  self:bindListener("EmptyPanel", self.onEmptyPanel)
  self:bindListener("TaskEmptyPanel", self.onTaskEmptyPanel)
  self.missionListSize = self.missionListSize or self:getCtrlContentSize("InfoPanel")
  self.titleGroup = RadioGroup.new()
  self.titleGroup:setItemsCanReClick(self, {
    "MissionCheckBox",
    "TeamCheckBox"
  }, self.onCheckBox)
  self:onCheckBox(self:getControl("MissionCheckBox"))
  self:getControl("MissionCheckBox"):setSelectedState(true)
  self.singleMemberPanel = self:retainCtrl("SingleMemberPanel")
  DlgMgr:sendMsg("MissionDlg", "setVisible", false)
  self:hookMsg("MSG_UPDATE_TEAM_LIST_EX")
  self:hookMsg("MSG_TASK_PROMPT")
  self:updateTeamInfo()
  local zOrder = DlgMgr:sendMsg("GameFunctionDlg", "getDlgZOrder")
  if zOrder then
    self:setDlgZOrder(zOrder - 1)
  end
end
function FubenMissionDlg:onCheckBox(sender, eventType)
  self:setCtrlVisible("GeneralPanel", sender:getName() == "MissionCheckBox")
  self:setCtrlVisible("TeamPanel", sender:getName() == "TeamCheckBox")
  if self.lastCheckBox == sender:getName() then
    if sender:getName() == "MissionCheckBox" then
      DlgMgr:openDlg("TaskDlg")
    elseif sender:getName() == "TeamCheckBox" then
      DlgMgr:openDlg("TeamDlg")
    end
  end
  if sender:getName() == "MissionCheckBox" then
    self:setCtrlVisible("UnChosenImage", true, "TeamCheckBox")
    self:setCtrlVisible("ChosenImage", false, "TeamCheckBox")
    self:setCtrlVisible("UnChosenImage", false, "MissionCheckBox")
    self:setCtrlVisible("ChosenImage", true, "MissionCheckBox")
    self:onMissionButton(sender)
  elseif sender:getName() == "TeamCheckBox" then
    self:setCtrlVisible("UnChosenImage", false, "TeamCheckBox")
    self:setCtrlVisible("ChosenImage", true, "TeamCheckBox")
    self:setCtrlVisible("UnChosenImage", true, "MissionCheckBox")
    self:setCtrlVisible("ChosenImage", false, "MissionCheckBox")
    self:onTeamButton(sender)
  end
  self.lastCheckBox = sender:getName()
end
function FubenMissionDlg:onMissionButton(sender, eventType)
end
function FubenMissionDlg:onTeamButton(sender, eventType)
end
function FubenMissionDlg:onHideDialogButton(sender, eventType)
  self.lastState = BUTTON_STATE.BUTTTON_STATE_HIDE
  self:hide(true)
end
function FubenMissionDlg:onShowDialogButton(sender, eventType)
  self.lastState = BUTTON_STATE.BUTTON_STATE_SHOW
  self:hide(false)
end
function FubenMissionDlg:onExitMatchButton(sender, eventType)
end
function FubenMissionDlg:onLeaveButton(sender, eventType)
  self:onCloseButton()
end
function FubenMissionDlg:onFubenInfo(sender, eventType)
end
function FubenMissionDlg:onEmptyPanel(sender, eventType)
  DlgMgr:openDlg("TeamDlg")
end
function FubenMissionDlg:onTaskEmptyPanel(sender, eventType)
  DlgMgr:openDlg("TaskDlg")
end
function FubenMissionDlg:cleanup()
  DlgMgr:sendMsg("MissionDlg", "setVisible", true, true)
  self.lastCheckBox = nil
end
function FubenMissionDlg:hide(bHide)
  local size = self.root:getContentSize()
  local move
  local winSize = self:getWinSize()
  if bHide == true then
    local action1 = cc.MoveTo:create(0.25, cc.p(Const.WINSIZE.width / 2 / Const.UI_SCALE + self.missionListSize.width + 10 + winSize.x, Const.WINSIZE.height / 2 / Const.UI_SCALE + winSize.y))
    local action2 = cc.CallFunc:create(function()
      self:getControl("HideDialogButton"):setVisible(false)
      self:getControl("ShowDialogButton"):setVisible(true)
      self:setCtrlVisible("InfoPanel", false)
    end)
    move = cc.Sequence:create(action1, action2)
  else
    local action1 = cc.CallFunc:create(function()
      self:getControl("HideDialogButton"):setVisible(true)
      self:getControl("ShowDialogButton"):setVisible(false)
      self:setCtrlVisible("InfoPanel", true)
    end)
    local action2 = cc.MoveTo:create(0.25, cc.p(Const.WINSIZE.width / 2 / Const.UI_SCALE + winSize.x, Const.WINSIZE.height / 2 / Const.UI_SCALE + winSize.y))
    move = cc.Sequence:create(action1, action2)
  end
  self.root:stopAllActions()
  self.root:runAction(move)
  self.isHide = bHide
  self:updateLayout("InfoPanel")
end
function FubenMissionDlg:onSelectTeamListView(sender, eventType)
end
function FubenMissionDlg:setColorTextEx(str, panel, color, fontSize, pos)
  fontSize = fontSize or 19
  color = color or COLOR3.TEXT_DEFAULT
  if not panel then
    return
  end
  panel:removeAllChildren()
  local size = panel:getContentSize()
  local textCtrl = CGAColorTextList:create()
  textCtrl:setFontSize(fontSize)
  textCtrl:setString(str)
  textCtrl:setDefaultColor(color.r, color.g, color.b)
  textCtrl:setContentSize(size.width, 0)
  textCtrl:updateNow()
  if pos then
    local textW, textH = textCtrl:getRealSize()
    textCtrl:setPosition(0, (size.height + textH) * 0.5)
  else
    local textW, textH = textCtrl:getRealSize()
    textCtrl:setPosition((size.width - textW) * 0.5, (size.height + textH) * 0.5)
  end
  panel:addChild(tolua.cast(textCtrl, "cc.LayerColor"))
end
function FubenMissionDlg:updateTeamInfo()
  local teamPanel = self:getControl("TeamPanel")
  local list, size = self:resetListView("TeamListView", TEAM_MEMBER_MARGIN, nil, teamPanel)
  list:setBounceEnabled(false)
  self.teamListSize = size
  local members = TeamMgr.members_ex
  list:setAnchorPoint(0, 1)
  local state = TeamMgr:getCurMatchInfo().state
  if state == MATCH_STATE.NORMAL then
    self:setCtrlVisible("MatchPanel", false, teamPanel)
    self:getControl("MatchPanel"):setEnabled(false)
    self:setCtrlVisible("TeamListPanel", true, teamPanel)
    self:setCtrlVisible("EmptyPanel", true, teamPanel)
  elseif state == MATCH_STATE.LEADER then
    self:setCtrlVisible("MatchPanel", false, teamPanel)
    self:setCtrlVisible("TeamListPanel", true, teamPanel)
  else
    self:setCtrlVisible("MatchPanel", true, teamPanel)
    self:getControl("MatchPanel"):setEnabled(true)
    self:setCtrlVisible("TeamListPanel", false, teamPanel)
    self:setCtrlVisible("EmptyPanel", false, teamPanel)
    self:setLabelText("MatchLabel", TeamMgr:getCurMatchInfo().name)
  end
  list:setContentSize(size.width, 0)
  if nil == members or members.count == nil or members.count == 0 then
    self:setCtrlVisible("TeamListPanel", false, teamPanel)
  else
    self:setCtrlVisible("TeamListPanel", true, teamPanel)
    self:setCtrlVisible("EmptyPanel", false, teamPanel)
    for i, v in ipairs(members) do
      local memberPanel = self.singleMemberPanel:clone()
      self:setMembers(v, memberPanel)
      memberPanel:setTag(i)
      list:pushBackCustomItem(memberPanel)
      memberPanel:setTouchEnabled(true)
      self:blindLongPress(memberPanel, self.longPressFun, self.chooseMember)
    end
    local height = members.count * self.singleMemberPanel:getContentSize().height
    list:setContentSize(size.width, height)
    if state == MATCH_STATE.MEMBER then
      self:setCtrlVisible("MatchPanel", false, teamPanel)
      TeamMgr:stopMatchMember()
    end
  end
  self:updateLayout("TeamPanel")
end
function FubenMissionDlg:setMembers(member, panel)
  self:setImage("ShapeImage", ResMgr:getSmallPortrait(member.org_icon), panel)
  self:setItemImageSize("ShapeImage", panel)
  local level = member.level
  self:setNumImgForPanel("LevelPanel", ART_FONT_COLOR.NORMAL_TEXT, level, false, LOCATE_POSITION.LEFT_TOP, 19, panel)
  self:setLabelText("MemberNameLabel", gf:getRealName(member.name), panel)
  self:setCtrlVisible("Zanli", false, panel)
  self:setCtrlVisible("OverlineStatusImage", false, panel)
  if member.team_status == 2 then
    self:setCtrlVisible("Zanli", true, panel)
    self:setCtrlEnabled("ShapeImage", false, panel)
  elseif member.team_status == 3 then
    self:setCtrlVisible("OverlineStatusImage", true, panel)
    self:setCtrlEnabled("ShapeImage", false, panel)
  end
end
function FubenMissionDlg:MSG_TASK_PROMPT(data)
end
function FubenMissionDlg:MSG_UPDATE_TEAM_LIST_EX(data)
  self:updateTeamInfo()
end
function FubenMissionDlg:chooseMember(sender, eventType)
  local myId = Me:getId()
  local pos = self:getBoundingBoxInWorldSpace(sender)
  local tag = sender:getTag()
  local members = TeamMgr.members_ex
  if not members[tag] then
    return
  end
  TeamMgr.selectMember = members[tag]
  if members[tag].name ~= Me:queryBasic("name") then
    if members[tag].type == OBJECT_TYPE.MONSTER or members[tag].type == OBJECT_TYPE.NPC or members[tag].type == OBJECT_TYPE.FOLLOW_NPC then
      gf:ShowSmallTips(CHS[4000395])
      return
    end
    local rect = self:getBoundingBoxInWorldSpace(sender)
    local dlg = DlgMgr:openDlg("FloatingMenuDlg")
    dlg:setData(members[tag])
    if TeamMgr:getLeaderId() == myId then
      local panel = sender:getParent()
      local item = panel:getChildByTag(1)
      if item then
        dlg:adjustPos(rect, self:getBoundingBoxInWorldSpace(item))
      else
        dlg:adjustPos(rect, rect)
      end
    else
      dlg:adjustPos(rect, rect)
    end
    return
  end
  if TeamMgr:inTeamEx(myId) and not TeamMgr:inTeam(myId) and TeamMgr:getLeaderId() ~= myId and members[tag].name == Me:queryBasic("name") then
    local dlg = DlgMgr:openDlg("TeamOPMenuDlg")
    dlg:setDlgDisplayType(3, nil, pos)
    return
  end
  if TeamMgr:inTeam(myId) and TeamMgr:getLeaderId() ~= myId and members[tag].name == Me:queryBasic("name") then
    local dlg = DlgMgr:openDlg("TeamOPMenuDlg")
    dlg:setDlgDisplayType(4, nil, pos)
    return
  end
  if TeamMgr:getLeaderId() == myId and members[tag].name ~= Me:queryBasic("name") then
    local dlg = DlgMgr:openDlg("TeamOPMenuDlg")
    dlg:setDlgDisplayType(2, members[tag], pos)
    return
  end
  if TeamMgr:getLeaderId() == myId and members[tag].name == Me:queryBasic("name") then
    local dlg = DlgMgr:openDlg("TeamOPMenuDlg")
    dlg:setDlgDisplayType(1, nil, pos)
    return
  end
end
return FubenMissionDlg
