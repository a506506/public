local BinghkyDlg = Singleton("BinghkyDlg", Dialog)
local Npc = require("obj/Npc")
local LIGHT_EFFECT = require("cfg/LightEffect")
local COUNT_DOWN_TIME = 5
local GAME_AREA = {
  {x = 612, y = 0},
  {x = 450, y = 84},
  {x = 450, y = 335},
  {x = 630, y = 460},
  {x = 1050, y = 460},
  {x = 1250, y = 335},
  {x = 1236, y = 84},
  {x = 1068, y = 0}
}
local GAME_AREA_LENTH = math.ceil(math.sqrt(829396))
local MAP_NPC_CFG = {
  {
    id = 100,
    icon = 6223,
    x = 17,
    y = 31,
    dir = 3,
    effPos = GAME_AREA[2]
  },
  {
    id = 200,
    icon = 6223,
    x = 16,
    y = 19,
    dir = 5,
    effPos = GAME_AREA[3]
  },
  {
    id = 300,
    icon = 6223,
    x = 25,
    y = 13,
    dir = 5,
    effPos = GAME_AREA[4]
  },
  {
    id = 400,
    icon = 6223,
    x = 44,
    y = 13,
    dir = 7,
    effPos = GAME_AREA[5]
  },
  {
    id = 500,
    icon = 6223,
    x = 53,
    y = 19,
    dir = 7,
    effPos = GAME_AREA[6]
  },
  {
    id = 600,
    icon = 6223,
    x = 51,
    y = 31,
    dir = 1,
    effPos = GAME_AREA[7]
  }
}
local TARGET_ATTACK_RADIUS = 192
local ATTACKED_STATUS = {
  NONE = 0,
  FIRE = 1,
  ICE = 2
}
local FIRE_ATTACK_OPACITY = 50
local GAME_SIGHT_POS = cc.p(35, 24)
local ICE_ATTACK_SPEED = -50
function BinghkyDlg:init()
  self:setFullScreen()
  self:setCtrlFullClientEx("BKPanel", nil, true)
  self:bindListener("RestartButton", self.onRestartButton)
  self:bindListener("QuitButton", self.onQuitButton)
  self:bindListener("CloseButton", self.onCloseButton)
  self.infoPanel = self:getControl("InfoPanel")
  self.mapNpc = {}
  self.npcAttackEff = {}
  self.npcAttackEffTime = {}
  self:bornMapNpc()
  self:resetGame()
  self:hookMsg("MSG_ENTER_ROOM")
end
function BinghkyDlg:setData(data)
  self.resultData = data
end
function BinghkyDlg:resetGame()
  Me:setLastMapPos(GAME_SIGHT_POS.x, GAME_SIGHT_POS.y)
  Me:setPos(gf:convertToClientSpace(GAME_SIGHT_POS.x, GAME_SIGHT_POS.y))
  self:setResultInfo(false)
  self.life = 3
  self:setLifePanel()
  Me:setSeepPrecentByClient(0)
  self.gameingTime = 0
  self:refreshGamingTime()
  self.infoPanel:setVisible(false)
  gf:startCountDowm(COUNT_DOWN_TIME + gf:getServerTime(), "start", function()
    local dlg = DlgMgr.dlgs.BinghkyDlg
    if dlg then
      self:startGame()
      self.infoPanel:setVisible(true)
    end
  end)
  self:clearNpcAttackEff()
end
function BinghkyDlg:startGame()
  self:setMeCheckKnockItem()
  self:stopSchedule(self.timeScheduleId)
  self.timeScheduleId = self:startSchedule(function()
    self.gameingTime = self.gameingTime + 1
    self:refreshGamingTime()
  end, 1)
  self:playNpcCaseAction()
  self:stopSchedule(self.tickScheduleId)
  self.tickScheduleId = self:startSchedule(function()
    self:checkAttackEff()
  end, 0)
end
function BinghkyDlg:endGame()
  self:stopSchedule(self.timeScheduleId)
  self.timeScheduleId = nil
  self:stopSchedule(self.tickScheduleId)
  self.tickScheduleId = nil
  self:clearNpcAttackEff()
  self:playNpcCaseAction(true)
  Me:setSeepPrecentByClient(nil)
  self:setResultInfo(true)
end
function BinghkyDlg:checkAttackEff()
  for k, v in pairs(self.npcAttackEff) do
    if "boolean" == type(v) then
      local curTick = gfGetTickCount()
      if not self.npcAttackEffTime[k] or curTick - self.npcAttackEffTime[k] > 1000 then
        self.npcAttackEff[k] = self:createAttackEff(k)
        self.npcAttackEffTime[k] = curTick
        self:doNpcCastMagic(k)
      end
    else
      if not v.bottomLayer then
        return
      end
      v:updatePos()
      local attackedMe = self:checkMeAttacked(v)
      local inGameArea = self:isInGameArea(cc.p(v.curX, v.curY))
      if attackedMe then
        if v.type == ATTACKED_STATUS.FIRE then
          self:setMeFireStatus()
        elseif v.type == ATTACKED_STATUS.ICE then
          self:setMeIceStatus()
        end
        if not self.tickScheduleId then
          return
        end
        v:cleanup()
        self.npcAttackEff[k] = true
      elseif inGameArea then
        v.inGameAreaEd = true
      elseif v.inGameAreaEd or not v.inMoveAction or v.curX < 0 or v.curX > MapMgr.mapSize.width or v.curY < 0 or v.curY > MapMgr.mapSize.height then
        v:cleanup()
        self.npcAttackEff[k] = true
      end
    end
  end
end
function BinghkyDlg:setMeFireStatus()
  if Me.bhkyStatus and Me.bhkyStatus == ATTACKED_STATUS.FIRE then
    return
  end
  Me.bhkyStatus = ATTACKED_STATUS.FIRE
  Me:setOpacity(FIRE_ATTACK_OPACITY)
  performWithDelay(Me.middleLayer, function()
    Me:setOpacity(255)
  end, 0.2)
  performWithDelay(Me.middleLayer, function()
    Me:setOpacity(FIRE_ATTACK_OPACITY)
  end, 0.4)
  performWithDelay(Me.middleLayer, function()
    Me:setOpacity(255)
  end, 0.6)
  performWithDelay(Me.middleLayer, function()
    Me:setOpacity(FIRE_ATTACK_OPACITY)
  end, 0.8)
  performWithDelay(Me.middleLayer, function()
    Me:setOpacity(255)
    Me.bhkyStatus = ATTACKED_STATUS.NONE
  end, 1)
  self.life = self.life - 1
  self:setLifePanel()
  if self.life <= 0 then
    self:endGame()
  end
end
function BinghkyDlg:setMeIceStatus()
  Me:setSeepPrecentByClient(ICE_ATTACK_SPEED)
  local effectCfg = LIGHT_EFFECT[1357]
  if Me.middleLayer.iceAction then
    Me.middleLayer:stopAction(Me.middleLayer.iceAction)
    Me:deleteMagic(effectCfg.icon)
  end
  Me:addMagicOnWaist(effectCfg.icon, effectCfg.behind, effectCfg.icon, effectCfg.armatureType)
  Me.middleLayer.iceAction = performWithDelay(Me.middleLayer, function()
    Me:setSeepPrecentByClient(0)
    Me.bhkyStatus = ATTACKED_STATUS.NONE
    Me:deleteMagic(effectCfg.icon)
  end, 3)
end
function BinghkyDlg:checkMeAttacked(char)
  if not char then
    return
  end
  if not Me or not Me.charAction or not Me.charAction.char then
    return
  end
  local meKnockItem = Me.topLayer:getChildByName("KnockLayer")
  if not meKnockItem then
    return
  end
  local itemSize = meKnockItem:getContentSize()
  local pos11 = meKnockItem:convertToWorldSpace(cc.p(0, 0))
  local pos21 = char.image:convertToWorldSpace(cc.p(0, 0))
  local pos12 = cc.p(pos11.x + itemSize.width, pos11.y + itemSize.height)
  local pos22 = cc.p(pos21.x + char.width, pos21.y + char.height)
  if 0 < Formula:getRectOvelLapArea(pos11.x, pos11.y, pos12.x, pos12.y, pos21.x, pos21.y, pos22.x, pos22.y) then
    return true
  end
end
function BinghkyDlg:createAttackEff(id)
  local path, icon, type = self:getRandomEffect()
  local cfg = MAP_NPC_CFG[id / 100]
  local mapX, mapY = gf:convertToMapSpace(cfg.effPos.x, cfg.effPos.y)
  local effectObj = require("obj/EffectItem").new(mapX, mapY)
  local sprite = effectObj:addImage(path)
  if sprite then
    sprite:setVisible(false)
  end
  effectObj:addMagic(icon)
  effectObj.type = type
  effectObj:setSpeedPercent(self:getSpeedPercent())
  local tarX, tarY, angle = self:getAttackTargetPos(cfg.effPos.x, cfg.effPos.y)
  if effectObj.magic then
    effectObj.magic:setRotation(angle)
  end
  effectObj:moveTo(tarX, tarY)
  return effectObj
end
function BinghkyDlg:getSpeedPercent()
  return 100 + self.gameingTime / 120 * 300
end
function BinghkyDlg:getAttackTargetPos(startX, startY)
  local x = math.random(Me.curX - TARGET_ATTACK_RADIUS, Me.curX + TARGET_ATTACK_RADIUS)
  local y = math.random(Me.curY - TARGET_ATTACK_RADIUS, Me.curY + TARGET_ATTACK_RADIUS)
  if not self:isInGameArea(cc.p(x, y)) then
    x, y = Me.curX, Me.curY
  end
  local k = (y - startY) / (x - startX)
  local addX = math.sqrt(GAME_AREA_LENTH * GAME_AREA_LENTH / (1 + k * k))
  local addY = math.ceil(math.abs(k * addX))
  addX = math.ceil(addX)
  if x == startX then
    addX = 0
    addY = GAME_AREA_LENTH
  end
  local tarX = startX < x and x + addX or x - addX
  local tarY = startY < y and y + addY or y - addY
  local vecX = tarX - startX
  local vecY = tarY - startY
  local angle = math.atan2(-vecY, vecX) * 180 / math.pi
  return tarX, tarY, angle
end
function BinghkyDlg:isInGameArea(pos)
  if Formula:ptInPolygon(pos, GAME_AREA) then
    return true
  end
  return false
end
function BinghkyDlg:getRandomEffect()
  if math.random(0, 1) == 0 then
    return ResMgr.ui.small_right_arrow, ResMgr.magic.bhky_fire_ball, ATTACKED_STATUS.FIRE
  else
    return ResMgr.ui.small_right_arrow, ResMgr.magic.bhky_ice_ball, ATTACKED_STATUS.ICE
  end
end
function BinghkyDlg:bornMapNpc()
  for i = 1, #MAP_NPC_CFG do
    local cfg = MAP_NPC_CFG[i]
    local npc = Npc.new()
    npc:absorbBasicFields({
      id = cfg.id,
      icon = cfg.icon,
      dir = cfg.dir,
      name = "",
      sub_type = OBJECT_NPC_TYPE.CANNOT_TOUCH
    })
    npc:setAct(Const.FA_STAND)
    npc:onEnterScene(cfg.x, cfg.y)
    self.mapNpc[cfg.id] = npc
  end
end
function BinghkyDlg:playNpcCaseAction(isRecover)
  for k, v in pairs(self.mapNpc) do
    if isRecover then
      v:setAct(Const.FA_STAND)
    else
      local npcId = v:getId()
      self.npcAttackEff[npcId] = true
      self:doNpcCastMagic(npcId)
    end
  end
end
function BinghkyDlg:doNpcCastMagic(id)
  local function callback()
    self:doNpcCastMagicEnd(id)
  end
  local npc = self.mapNpc[id]
  if not npc then
    return
  end
  npc:setActAndCB(Const.FA_ACTION_CAST_MAGIC, callback)
end
function BinghkyDlg:doNpcCastMagicEnd(id)
  local function callback()
    local npc = self.mapNpc[id]
    if not npc or npc.faAct ~= Const.FA_ACTION_CAST_MAGIC_END then
      return
    end
    npc:setAct(Const.FA_STAND)
  end
  local npc = self.mapNpc[id]
  if not npc then
    return
  end
  npc:setActAndCB(Const.FA_ACTION_CAST_MAGIC_END, callback)
end
function BinghkyDlg:clearNpcAttackEff()
  for k, v in pairs(self.npcAttackEff) do
    if "boolean" ~= type(v) then
      v:cleanup()
    end
  end
  self.npcAttackEff = {}
end
function BinghkyDlg:clearMapNpc()
  for k, v in pairs(self.mapNpc) do
    v:cleanup()
  end
  self.mapNpc = {}
end
function BinghkyDlg:setMeCheckKnockItem()
  if Me.topLayer:getChildByName("KnockLayer") then
    return
  end
  local rect = Me.charAction.char.contentRect
  local colorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 0))
  colorLayer:setContentSize(rect.width - 25, rect.height - 35)
  colorLayer:setPosition(cc.p(-rect.width / 2 + 13, 0))
  Me:addToTopLayer(colorLayer)
  colorLayer:setName("KnockLayer")
end
function BinghkyDlg:removeMeCheckKnockItem()
  local item = Me.charAction.char:getChildByName("KnockLayer")
  if item then
    item:removeFromParent()
    item = nil
  end
end
function BinghkyDlg:setLifePanel()
  for i = 1, 3 do
    local panel = self:getControl("LifePanel_" .. i, nil, self.infoPanel)
    self:setCtrlVisible("Image_1", false, panel)
    self:setCtrlVisible("Image_2", false, panel)
    if i <= self.life then
      self:setCtrlVisible("Image_1", true, panel)
    else
      self:setCtrlVisible("Image_2", true, panel)
    end
  end
end
function BinghkyDlg:refreshGamingTime()
  local minute = math.floor(self.gameingTime / 60)
  local second = self.gameingTime % 60
  local timeStr = string.format("%02d:%02d", minute, second)
  self:setLabelText("TimeLabel", timeStr, self.infoPanel)
end
function BinghkyDlg:setResultInfo(flag)
  local bkPanel = self:getControl("BKPanel")
  local resultPanel = self:getControl("ResultPanel")
  bkPanel:setVisible(flag)
  resultPanel:setVisible(flag)
  if flag then
    gf:CmdToServer("CMD_SUMMER_2019_BHKY_RESULT", {
      result = gfEncrypt(tostring(self.gameingTime), self.resultData.cookie)
    })
    self:setCtrlVisible("FailImage", false, resultPanel)
    self:setCtrlVisible("SuccessImage", false, resultPanel)
    self:setCtrlVisible("GoodNoticePanel")
    self:setLabelText("ReqPointLabel2", string.format(CHS[7120167], self.resultData.sucess_time))
    self:setLabelText("YourPointLabel2", string.format(CHS[7120167], self.gameingTime))
    local goodNoticePanel = self:getControl("GoodNoticePanel", nil, resultPanel)
    local normalNoticePanel = self:getControl("NormalNoticePanel", nil, resultPanel)
    local failNoticePanel = self:getControl("FailNoticePanel", nil, resultPanel)
    goodNoticePanel:setVisible(false)
    normalNoticePanel:setVisible(false)
    failNoticePanel:setVisible(false)
    if self.gameingTime >= self.resultData.sucess_time then
      self:setCtrlVisible("SuccessImage", true, resultPanel)
      local maxTime = math.max(self.gameingTime, self.resultData.max_time)
      if maxTime < self.resultData.title_time then
        normalNoticePanel:setVisible(true)
        self:setLabelText("Label_1", string.format(CHS[7190504], maxTime), normalNoticePanel)
        self:setLabelText("Label_3", string.format(CHS[7190505], self.resultData.title_time), normalNoticePanel)
      else
        goodNoticePanel:setVisible(true)
        self:setLabelText("Label_1", string.format(CHS[7190506], maxTime, self.resultData.title_time), goodNoticePanel)
      end
    else
      self:setCtrlVisible("FailImage", true, resultPanel)
      failNoticePanel:setVisible(true)
    end
  end
end
function BinghkyDlg:cleanup()
  self:endGame()
  self:stopSchedule(self.timeScheduleId)
  self:stopSchedule(self.tickScheduleId)
  self:clearNpcAttackEff()
  self.npcAttackEffTime = {}
  self:clearMapNpc()
  self.resultData = nil
end
function BinghkyDlg:onRestartButton(sender, eventType)
  self:resetGame()
end
function BinghkyDlg:onQuitButton(sender, eventType)
  gf:confirm(CHS[7190507], function()
    gf:CmdToServer("CMD_SUMMER_2019_BHKY_QUIT", {})
  end)
end
function BinghkyDlg:onCloseButton()
  gf:confirm(CHS[7190507], function()
    gf:CmdToServer("CMD_SUMMER_2019_BHKY_QUIT", {})
  end)
end
function BinghkyDlg:MSG_ENTER_ROOM()
  self:endGame()
  DlgMgr:closeDlg(self.name)
  local chatDlg = DlgMgr.dlgs.ChatDlg
  if chatDlg then
    chatDlg:setVisible(true)
  end
end
return BinghkyDlg
