local TabDlg = require("dlg/TabDlg")
local AnniversaryTabDlg = Singleton("AnniversaryTabDlg", TabDlg)
AnniversaryTabDlg.dlgs = {
  DLLBCheckBox = "AnniversaryRewardDlg",
  CWMXCheckBox = "AnniversaryXianDanDlg",
  ZNLBCheckBox = "AnniversaryGiftDlg",
  GDJCCheckBox = "AnniversaryOtherDlg"
}
AnniversaryTabDlg.orderList = {
  DLLBCheckBox = 1,
  CWMXCheckBox = 2,
  ZNLBCheckBox = 3,
  GDJCCheckBox = 4
}
function AnniversaryTabDlg:init()
  TabDlg.init(self)
  self.scrollCtrl = self:getControl("AnniversaryScrollView")
  if RedDotMgr:hasRedDotInfoByDlgName("SystemFunctionDlg", "AnniversaryButton") then
    RedDotMgr:removeOneRedDot("SystemFunctionDlg", "AnniversaryButton")
  end
end
local AUTO_SCROLL_TIME = 0.3
function AnniversaryTabDlg:setScrollViewLocation(sender)
  local idx = self.orderList[sender:getName()]
  local scrollY = self.scrollCtrl:getInnerContainer():getPositionY()
  local labelSize = sender:getContentSize()
  local senderHeight = idx * labelSize.height
  local scrollHeight = self.scrollCtrl:getInnerContainer():getContentSize().height - self.scrollCtrl:getContentSize().height
  if scrollHeight + scrollY + self.scrollCtrl:getContentSize().height < senderHeight - idx * 2 then
    local percent = (senderHeight - self.scrollCtrl:getContentSize().height - idx * 2) / scrollHeight * 100
    self.scrollCtrl:scrollToPercentVertical(percent, AUTO_SCROLL_TIME, false)
  elseif senderHeight - labelSize.height < scrollHeight + scrollY then
    local percent = (senderHeight - labelSize.height) / scrollHeight * 100
    self.scrollCtrl:scrollToPercentVertical(percent, AUTO_SCROLL_TIME, false)
  end
end
function AnniversaryTabDlg:onPreCallBack(sender, idx)
  if not sender then
    return true
  end
  local task = TaskMgr:getTaskByName(CHS[2100357])
  if sender:getName() == "CWMXCheckBox" and task and task.task_extra_para == "0" then
    gf:confirm(CHS[2200199], function()
      gf:doActionByColorText(TaskMgr:getTaskByName(CHS[2100357]).task_prompt, task)
      local last = self.lastDlg
      DlgMgr:closeDlg(last)
    end)
    return
  end
  self:setScrollViewLocation(sender)
  return true
end
return AnniversaryTabDlg
