local ChargePointDlg = require("dlg/ChargePointDlg")
local ConsumePointDlg = Singleton("ConsumePointDlg", ChargePointDlg)
function ConsumePointDlg:getCfgFileName()
  return ResMgr:getDlgCfg("ChargePointDlg")
end
return ConsumePointDlg
