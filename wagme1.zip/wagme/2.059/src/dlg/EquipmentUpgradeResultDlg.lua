local EquipmentUpgradeResultDlg = Singleton("EquipmentUpgradeResultDlg", Dialog)
function EquipmentUpgradeResultDlg:init(data)
  self:setFullScreen()
  self:setCtrlFullClient("BlackPanel")
  self.data = data
  self:bindListener("ShareButton", self.onShareButton)
  self:setLabelText("UpgradeValueTextBMFont", string.format(CHS[2200195], data.rebuild_level), "TitlePanel")
  if data.progress <= 0 then
    self:setLabelText("ProgressValueTextBMFont", string.format("%d%%", data.progress), "ProgressTipsPanel")
  else
    self:setLabelText("ProgressValueTextBMFont", string.format(CHS[2200196], data.progress), "ProgressTipsPanel")
  end
  self:setLabelText("LevelTextBMFont", data.level, "LevelPanel")
  self:setLabelText("NameLabel", data.name, "NamePanel")
  self:setImage("ItemImage", ResMgr:getItemIconPath(data.icon))
  local itemPanel = self:getControl("ItemPanel")
  local magic = gf:createLoopMagic(1573, nil, {blend = "add"})
  magic:setAnchorPoint(0.5, 0.5)
  magic:setPosition(itemPanel:getContentSize().width / 2, itemPanel:getContentSize().height / 2)
  itemPanel:addChild(magic, 999)
  gf:createArmatureLoopMagic("02065", "Top", self.root, nil, nil, 999)
  if data.showContinue then
    self:setLabelText("TextLabel", CHS[2200197], "ClosePanel")
    self:setLabelText("ShadowLabel", CHS[2200197], "ClosePanel")
  end
end
function EquipmentUpgradeResultDlg:cleanup()
  self.data = nil
end
function EquipmentUpgradeResultDlg:onShareButton(sender, eventType)
  ShareMgr:share(SHARE_FLAG.GZCG, function()
    self:setCtrlVisible("ClosePanel", false)
    self:setCtrlVisible("SharePanel", false)
  end, function()
    self:setCtrlVisible("ClosePanel", true)
    self:setCtrlVisible("SharePanel", true)
  end)
end
function EquipmentUpgradeResultDlg:onCloseButton()
  if self.data and self.data.isOneClick then
    DlgMgr:sendMsg("EquipmentUpgradeDlg", "startUpgrade")
  end
  Dialog.onCloseButton(self)
end
return EquipmentUpgradeResultDlg
