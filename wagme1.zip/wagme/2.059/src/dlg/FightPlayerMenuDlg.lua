local FightPlayerMenuDlg = Singleton("FightPlayerMenuDlg", Dialog)
function FightPlayerMenuDlg:init()
  self:setFullScreen()
  self:bindListener("AutoFightButton", self.onAutoFightButton)
  self:bindListener("UseSkillButton", self.onUseSkillButton)
  self:bindListener("UseItemButton", self.onUseItemButton)
  self:bindListener("DefenseButton", self.onDefenseButton)
  self:bindListener("CatchButton", self.onCatchButton)
  self:bindListener("CallPetButton", self.onCallPetButton)
  self:bindListener("CallBackPetButton", self.onCallBackPetButton)
  self:bindListener("EscapeButton", self.onEscapeButton)
  self:bindListener("FastSkillButton", self.onFastSkillButton)
  self:updateFastSkillButton()
end
function FightPlayerMenuDlg:updateFastSkillButton()
  if Me:queryBasicInt("c_me_finished_cmd") == 1 then
    self:setCtrlVisible("FastSkillButton", false)
    return
  end
  SkillMgr:removeArtifactSpSkillImage(self:getControl("SkillImage", nil, "FastSkillButton"))
  local skill = tonumber(FightMgr.fastSkill.Me.skillNo)
  local isQinMiWuJianCopySkill = FightMgr.fastSkill.Me.isQinMiWuJianCopySkill
  if not skill or skill == -1 then
    self:setCtrlVisible("FastSkillButton", false)
  else
    self:setCtrlVisible("FastSkillButton", true)
    local path = SkillMgr:getSkillIconPath(skill)
    local mySkill = SkillMgr:getSkill(Me:getId(), skill)
    local skillName = SkillMgr:getSkillName(skill)
    if not mySkill and (SkillMgr:isArtifactSpSkillByNo(skill) or isQinMiWuJianCopySkill) then
      self:setCtrlVisible("FastSkillButton", false)
    elseif mySkill and mySkill.skill_disabled == 1 then
      self:setCtrlVisible("FastSkillButton", false)
    end
    if mySkill then
      local skillName = SkillMgr:getSkillName(skill)
      local isQinMiWuJianSkill = SkillMgr:isQinMiWuJianCopySkill(skillName, Me:getId())
      local hasEnoughNimbus = SkillMgr:isArtifactSpSkillCanUse(CHS[3001947])
      if Me:queryInt("mana") < mySkill.skill_mana_cost or isQinMiWuJianSkill and not hasEnoughNimbus or not SkillMgr:isArtifactSpSkillCanUse(skillName) then
        self:blindLongPress("FastSkillButton", function(dlg, sender, eventType)
          self:OneSecondLater(sender, eventType, 2, skill)
        end, function(dlg, sender, eventType)
          self:onFastSkillButton(sender, eventType)
        end)
        self:setCtrlVisible("NoManaImage", true, "FastSkillButton")
      else
        self:blindLongPress("FastSkillButton", function(dlg, sender, eventType)
          self:OneSecondLater(sender, eventType, nil, skill)
        end, function(dlg, sender, eventType)
          self:onFastSkillButton(sender, eventType)
        end)
        self:setCtrlVisible("NoManaImage", false, "FastSkillButton")
      end
      if SkillMgr:isArtifactSpSkill(mySkill.skill_name) then
        SkillMgr:addArtifactSpSkillImage(self:getControl("SkillImage", nil, "FastSkillButton"))
      end
    end
    self:setImage("SkillImage", path, "FastSkillButton")
    self:setItemImageSize("SkillImage", "FastSkillButton")
  end
end
function FightPlayerMenuDlg:onAutoFightButton(sender, eventType)
  self:AutoFightStatus()
  FightMgr.useFastSkill = false
end
function FightPlayerMenuDlg:OneSecondLater(sender, eventType, type, skillNo)
  local rect = self:getBoundingBoxInWorldSpace(sender)
  SkillMgr:showSkillDescDlg(SkillMgr:getSkillName(skillNo), Me:getId(), false, rect, type)
end
function FightPlayerMenuDlg:AutoFightStatus()
  if Me:queryBasicInt("auto_fight") == 0 then
    Me:setBasic("auto_fight", 1)
    AutoFightMgr:autoFightSiwchStatus(1)
    if self.onEscapeBtn then
      gf:CmdToServer("CMD_AUTO_FIGHT_INFO")
    end
    FightMgr:showSelectImg(false)
    DlgMgr:closeDlg("FightPlayerMenuDlg")
    DlgMgr:openDlg("AutoFightSettingDlg")
  end
end
function FightPlayerMenuDlg:onFastSkillButton(sender, eventType)
  local skill = tonumber(FightMgr.fastSkill.Me.skillNo)
  local skillName = SkillMgr:getSkillName(skill)
  if not skill or skill ~= -1 then
    if SkillMgr:isQinMiWuJianCopySkill(skillName, Me:getId()) then
      local pet = FightMgr:getCurFightPet()
      if not pet or not SkillMgr:getSkill(pet:getId(), skill) then
        gf:ShowSmallTips(CHS[7000318])
        return
      end
      if EquipmentMgr:getEquippedArtifactNimbus() < SkillMgr:getArtifactSpSkillCostNimbus(CHS[3001947]) then
        gf:ShowSmallTips(CHS[7000317])
        return
      end
    end
    if SkillMgr:isArtifactSpSkill(skillName) then
      local nimbus = EquipmentMgr:getEquippedArtifactNimbus()
      if nimbus < SkillMgr:getArtifactSpSkillCostNimbus(skillName) then
        gf:ShowSmallTips(CHS[7000314])
        return false
      end
    end
    Me.op = ME_OP.FIGHT_SKILL
    if SkillMgr:canUseSkillOnlyToSelf(skill, "me") then
      local curRoundLeftTime = FightMgr:getRoundLeftTime()
      self.confirmDlg = gf:confirm(string.format(CHS[7150019], skillName), function()
        Me:setBasic("sel_skill_no", skill)
        self:setVisible(false)
        FightMgr:getObjectById(Me:getId()):onSelectChar()
      end, function()
        if self.confirmDlg and self.confirmDlg.hourglassTime < 1 then
          self:setVisible(false)
          return
        end
        Me.op = ME_OP.FIGHT_ATTACK
        Me:setBasic("sel_skill_no", 0)
        self:setVisible(true)
      end, nil, curRoundLeftTime - 1)
      if self.confirmDlg then
        self.confirmDlg:setCombatOpenType()
      end
      return
    end
    self:setVisible(false)
    Me:setBasic("sel_skill_no", skill)
    local dlg = DlgMgr:openDlg("FightTargetChoseDlg")
    local cmdDesc = SkillMgr:getSkillCmdDesc(Me:getId(), skill)
    local logSkills = SkillMgr.idSkills and SkillMgr.idSkills[Me:getId()]
    dlg:setTips(SkillMgr:getSkillName(skill), cmdDesc)
    FightMgr.useFastSkill = true
  end
end
function FightPlayerMenuDlg:onUseSkillButton(sender, eventType)
  if not SkillMgr:haveCombatSkill(Me:getId()) and not BattleSimulatorMgr:isRunning() then
    gf:ShowSmallTips(CHS[3002608])
    return
  end
  self:setVisible(false)
  local dlg = DlgMgr:showDlg("FightPlayerSkillDlg", true)
  if dlg then
    dlg:initSkill()
  end
  FightMgr.useFastSkill = false
  GuideMgr:needCallBack("UseSkillButton")
end
function FightPlayerMenuDlg:onUseItemButton(sender, eventType)
  self:setVisible(false)
  local dlg = DlgMgr:showDlg("FightUseResDlg", true)
  dlg:getItemsInFight()
  FightMgr.useFastSkill = false
end
function FightPlayerMenuDlg:onDefenseButton(sender, eventType)
  gf:sendFightCmd(Me:getId(), Me:getId(), FIGHT_ACTION.DEFENSE, 0)
  FightMgr:changeMeActionFinished()
  FightMgr.useFastSkill = false
end
function FightPlayerMenuDlg:onCatchButton(sender, eventType)
  if sender.tips then
    sender.tips:removeFromParent()
    sender.tips = nil
  end
  if not FightMgr.notCatchCondition then
    if PetMgr:getFreePetCapcity(MapMgr:curIsInDifu() and PET_LOCATE.DIFU or PET_LOCATE.YANGJIAN) <= 0 then
      gf:ShowSmallTips(CHS[3000030])
      return
    end
  end
  Me.op = ME_OP.FIGHT_CATCH
  self:setVisible(false)
  local dlg = DlgMgr:showDlg("FightTargetChoseDlg", true)
  dlg:setTips(CHS[3000001], CHS[3002609])
  FightMgr.useFastSkill = false
end
function FightPlayerMenuDlg:onCallPetButton(sender, eventType)
  local pet = FightMgr:getCurFightPet()
  if pet and FightMgr:getObjectById(pet:getId()) and FightMgr:getObjectById(pet:getId()):isXuWu() then
    gf:ShowSmallTips(string.format(CHS[7000275], pet:getShowName()))
    return
  end
  local lst = FightMgr:getCurCanCallPets()
  if #lst <= 0 then
    gf:ShowSmallTips(CHS[3002610])
    return
  end
  self:setVisible(false)
  DlgMgr:showDlg("FightCallPetMenuDlg", true)
  FightMgr.useFastSkill = false
end
function FightPlayerMenuDlg:onCallBackPetButton(sender, eventType)
  local pet = FightMgr:getCurFightPet()
  local kid = HomeChildMgr:getFightKid()
  local fightObj = pet
  local confirmTips = CHS[2000112]
  if Me:isInCombat() and kid then
    fightObj = kid
    confirmTips = CHS[7100439]
  end
  if not fightObj or not FightMgr:getObjectById(fightObj:getId()) then
    gf:ShowSmallTips(CHS[2000111])
    return
  end
  if FightMgr:getObjectById(fightObj:getId()):isXuWu() then
    gf:ShowSmallTips(string.format(CHS[7000275], fightObj:getShowName()))
    return
  end
  local dlg = gf:confirm(confirmTips, function()
    gf:sendFightCmd(Me:getId(), fightObj:getId(), FIGHT_ACTION.CALLBACK_PET, 0)
    FightMgr:changeMeActionFinished()
    FightMgr.useFastSkill = false
  end)
  if dlg then
    dlg:setCombatOpenType()
  end
end
function FightPlayerMenuDlg:onEscapeButton(sender, eventType)
  gf:sendFightCmd(Me:getId(), Me:getId(), FIGHT_ACTION.FLEE, 0)
  FightMgr:changeMeActionFinished()
  FightMgr.useFastSkill = false
  self.onEscapeBtn = true
end
function FightPlayerMenuDlg:showTipsOnCatchButton(round)
  if Me:isTeamLeader() then
    return
  end
  local button = self:getControl("CatchButton")
  if button.round == round then
    return
  end
  local rect = self:getBoundingBoxInWorldSpace(button)
  button.tips = gf:showGeneralGuide(CHS[7150709], rect, "up", button)
end
function FightPlayerMenuDlg:youMustGiveMeOneNotify(param)
  if "hasPet" == param then
    if FightMgr:getCurFightPet() then
      GuideMgr:youCanDoIt(self.name, param)
    else
      GuideMgr:youCanDoIt(self.name)
    end
  end
end
function FightPlayerMenuDlg:showOnlyAutoFightButton(isOnly)
  self:setCtrlVisible("UseSkillButton", not isOnly)
  self:setCtrlVisible("UseItemButton", not isOnly)
  self:setCtrlVisible("DefenseButton", not isOnly)
  self:setCtrlVisible("CallPetButton", not isOnly)
  self:setCtrlVisible("CallBackPetButton", not isOnly)
  self:setCtrlVisible("CatchButton", not isOnly)
  self:setCtrlVisible("EscapeButton", not isOnly)
  if not isOnly then
    self:updateFastSkillButton()
  else
    self:setCtrlVisible("FastSkillButton", false)
  end
end
function FightPlayerMenuDlg:cleanup()
  self.onEscapeBtn = nil
end
return FightPlayerMenuDlg
