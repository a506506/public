local BlogButtonListDlg = Singleton("BlogButtonListDlg", Dialog)
local BUTTON_LIST = {
  showPortrait = {
    {
      text = CHS[2000429],
      func = "onOpenPhoto"
    },
    {
      text = CHS[2000430],
      func = "onOpenCamera",
      cond = function()
        return gf:gfIsFuncEnabled(FUNCTION_ID.IMAGE_PICK_FIXED)
      end
    },
    {
      text = CHS[2000431],
      func = "onDelPortrait",
      cond = function(dlgName, typeStr, sender)
        return dlgName == "CityInfoDlg" and not CitySocialMgr:isDefaultIcon() or dlgName == "MatchmakingDlg" and not MatchMakingMgr:isDefaultIcon() or dlgName ~= "CityInfoDlg" and not BlogMgr:isDefaultIcon(dlgName)
      end
    }
  },
  reportPortrait = {
    {
      text = CHS[2000432],
      func = "onReportPortrait"
    }
  },
  reportSign = {
    {
      text = CHS[2000433],
      func = "onReportSign"
    }
  },
  blogCommentOp = {
    {
      text = CHS[4100852],
      func = "onReComment"
    },
    {
      text = CHS[4100853],
      func = "onDelComment"
    },
    {
      text = CHS[4300502],
      func = "onReportCommentForBlog"
    },
    {
      text = CHS[2200240],
      func = "onDelSomeOneAllComment"
    }
  },
  blogDelCommentOp = {
    {
      text = CHS[4100853],
      func = "onDelComment"
    }
  },
  petDelCommentOp = {
    {
      text = CHS[4100853],
      func = "onDelComment"
    }
  },
  blogStateDel = {
    {
      text = CHS[4200452],
      func = "onDeletePhote"
    },
    {
      text = CHS[4300292],
      func = "onViewPhoto"
    }
  },
  blogStateSel = {
    {
      text = CHS[4200466],
      func = "onSelectPhote"
    },
    {
      text = CHS[2000430],
      func = "onSelectCamera",
      cond = function()
        return gf:gfIsFuncEnabled(FUNCTION_ID.IMAGE_PICK_FIXED)
      end
    }
  },
  weddingBookPhotoMenu = {
    {
      text = CHS[2000469],
      func = "onOpenPhoto"
    },
    {
      text = CHS[2000470],
      func = "onOpenCamera"
    },
    {
      text = CHS[2000471],
      func = "onReset",
      cond = function(dlgName)
        return not DlgMgr:sendMsg(dlgName, "isDefaultPhoto")
      end
    }
  },
  weddingBookViewPhoto = {
    {
      text = CHS[2000472],
      func = "onViewPhoto"
    },
    {
      text = CHS[2000473],
      func = "onEditComment",
      cond = function(dlgName)
        return DlgMgr:sendMsg(dlgName, "isBookOwner")
      end
    },
    {
      text = CHS[2000474],
      func = "onDeletePhote",
      cond = function(dlgName)
        return DlgMgr:sendMsg(dlgName, "isBookOwner")
      end
    }
  },
  weddingBookShare = {
    {
      text = CHS[2100151],
      func = "onShareWBToCurrent"
    },
    {
      text = CHS[2100152],
      func = "onShareWBToWorld"
    },
    {
      text = CHS[2100153],
      func = "onShareWBToParty"
    },
    {
      text = CHS[2100154],
      func = "onShareWBToTeam"
    },
    {
      text = CHS[2100155],
      func = "onShareWBToFriend"
    }
  },
  reportWBCover = {
    {
      text = CHS[2100163],
      func = "onReportWBCover"
    }
  },
  reportWBPhoto = {
    {
      text = CHS[2100163],
      func = "onReportWBPhoto"
    }
  },
  TipOffMarket = {
    {
      text = CHS[4300467],
      func = "onTipOffMarket"
    }
  },
  partyAnnouce = {
    {
      text = CHS[4300311],
      func = "onPartyAnnouce"
    }
  },
  teamFixedMore = {
    {
      text = CHS[2100274],
      func = "onViewProp"
    },
    {
      text = CHS[7150258],
      func = "onSeeReserve",
      cond = function(dlgName, typeStr, sender)
        return DlgMgr:sendMsg(dlgName, "isOtherMemberForSeeReserve", sender)
      end
    },
    {
      text = CHS[2100275],
      func = "onReserve",
      cond = function(dlgName, typeStr, sender)
        return DlgMgr:sendMsg(dlgName, "isOtherMemberForReserve", sender)
      end
    },
    {
      text = CHS[2100276],
      func = "onCommunicate",
      cond = function(dlgName, typeStr, sender)
        return DlgMgr:sendMsg(dlgName, "isOtherMemberForCommunicate", sender)
      end
    },
    {
      text = CHS[2100277],
      func = "onViewBlog"
    }
  },
  playerEnlistPolar = {
    {
      text = CHS[4200046],
      func = "onEnlistPolar",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[4200046]]
      end
    },
    {
      text = CHS[3000253],
      func = "onEnlistPolar",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[3000253]]
      end
    },
    {
      text = CHS[3000256],
      func = "onEnlistPolar",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[3000256]]
      end
    },
    {
      text = CHS[3000259],
      func = "onEnlistPolar",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[3000259]]
      end
    },
    {
      text = CHS[3000261],
      func = "onEnlistPolar",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[3000261]]
      end
    },
    {
      text = CHS[3000263],
      func = "onEnlistPolar",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[3000263]]
      end
    }
  },
  playerEnlistPoint = {
    {
      text = CHS[4200046],
      func = "onEnlistPoint",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[4200046]]
      end
    },
    {
      text = CHS[5410280],
      func = "onEnlistPoint",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[5410280]]
      end
    },
    {
      text = CHS[5410281],
      func = "onEnlistPoint",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[5410281]]
      end
    },
    {
      text = CHS[5410282],
      func = "onEnlistPoint",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[5410282]]
      end
    },
    {
      text = CHS[5410283],
      func = "onEnlistPoint",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[5410283]]
      end
    }
  },
  TeamEnlistOther = {
    {
      text = CHS[4300311],
      func = "onReportEnlist"
    },
    {
      text = CHS[5000062],
      func = "onOperFriend",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[5000062]]
      end
    },
    {
      text = CHS[5000064],
      func = "onOperFriend",
      cond = function(dlgName, typeStr, sender, param)
        return param and not param.excepts[CHS[5000064]]
      end
    }
  },
  copy_content = {},
  show_list = {},
  matchMakingOther = {
    {
      text = CHS[2000506],
      func = "onReportMatchMaking"
    },
    {
      text = CHS[2000507],
      func = "onAddFriend",
      cond = function(dlgName)
        return DlgMgr:sendMsg(dlgName, "isCanAddFriend")
      end
    },
    {
      text = CHS[2000508],
      func = "onDeleteFriend",
      cond = function(dlgName)
        return DlgMgr:sendMsg(dlgName, "isCanDeleteFriend")
      end
    }
  },
  matchMakeShow = {
    {
      text = CHS[2000429],
      func = "onOpenPhoto"
    },
    {
      text = CHS[2000430],
      func = "onOpenCamera",
      cond = function()
        return gf:gfIsFuncEnabled(FUNCTION_ID.IMAGE_PICK_FIXED)
      end
    },
    {
      text = CHS[2000542],
      func = "onDelPortrait",
      cond = function(dlgName)
        return dlgName == "MatchmakingDlg" and not MatchMakingMgr:isDefaultIcon()
      end
    }
  },
  taier1 = {
    {
      text = CHS[4010389],
      func = "onKidInfoDlgCare"
    },
    {
      text = CHS[4010390],
      func = "onKidInfoDlgCare"
    },
    {
      text = CHS[4010391],
      func = "onKidInfoDlgCare"
    }
  },
  goodVoiceMsg = {
    {
      text = CHS[4200664],
      func = "onGoodVoiceDetailsDlgjbly"
    },
    {
      text = CHS[4200665],
      func = "onGoodVoiceDetailsDlghfly"
    }
  },
  goodVoiceMsgEx = {
    {
      text = CHS[4200664],
      func = "onGoodVoiceDetailsDlgjbly"
    },
    {
      text = CHS[4200706],
      func = "onGoodVoiceDetailsDlgchly"
    }
  },
  goodVoiceOnlyJb = {
    {
      text = CHS[4200664],
      func = "onGoodVoiceDetailsDlgjbly"
    }
  },
  blogCommentAndReport = {
    {
      text = CHS[4300501],
      func = "onReplyCommentForBlog"
    },
    {
      text = CHS[4300502],
      func = "onReportCommentForBlog"
    }
  },
  blogCommentAndReportForMessage = {
    {
      text = CHS[4300509],
      func = "onReplyCommentForBlog"
    },
    {
      text = CHS[4300510],
      func = "onReportCommentForBlog"
    }
  },
  blogCommentAndReportForMyMessage = {
    {
      text = CHS[4300509],
      func = "onReplyCommentForBlog"
    },
    {
      text = CHS[4300510],
      func = "onReportCommentForBlog"
    },
    {
      text = CHS[2200240],
      func = "onDelSomeOneAllComment"
    }
  },
  onReportComment = {
    {
      text = CHS[4300502],
      func = "onReportCommentForBlog"
    }
  },
  reportLookonDlg = {
    {
      text = CHS[4101601],
      func = "onReportLookonDlg"
    }
  },
  shock = {
    {
      text = CHS[4300620],
      func = "onShockButton"
    }
  },
  MenpmzDlgRemardBomb = {
    {
      text = CHS[4200805],
      func = "onRemardBomb"
    }
  },
  MenpmzDlgRemoveBomb = {
    {
      text = CHS[4200806],
      func = "onRemoveBomb"
    }
  },
  BaosjcDlgMairu = {
    {
      text = CHS[4101644],
      func = "onBaosjcDlgMairu"
    }
  },
  BaosjcDlgZhakai = {
    {
      text = CHS[4101645],
      func = "onBaosjcDlgZhakai"
    }
  },
  LottoCommentAndReport = {
    {
      text = CHS[5400899],
      func = "onReplyCommentForBlog"
    },
    {
      text = CHS[5400898],
      func = "onReportCommentForBlog"
    }
  },
  LottoDeleteMessage = {
    {
      text = CHS[5400897],
      func = "onLottoDeleteMessage"
    }
  },
  MiaoYCommentAndReport = {
    {
      text = CHS[5410575],
      func = "onReplyCommentForBlog"
    },
    {
      text = CHS[5410574],
      func = "onReportCommentForBlog"
    }
  },
  MiaoYDeleteMessage = {
    {
      text = CHS[5410573],
      func = "onLottoDeleteMessage"
    }
  },
  MiaoYProjectMessage = {
    {
      text = CHS[5410575],
      func = "onReplyCommentForBlog"
    },
    {
      text = CHS[5410573],
      func = "onLottoDeleteMessage"
    },
    {
      text = CHS[5410574],
      func = "onReportCommentForBlog"
    }
  },
  MiaoYProject = {
    {
      text = CHS[5410535],
      func = "onMiaoYReportPorject"
    }
  },
  MiaoYProjectGM = {
    {
      text = CHS[5410535],
      func = "onMiaoYReportPorject"
    },
    {
      text = CHS[5410536],
      func = "onMiaoYDeletePorject"
    }
  },
  MiaoYProjectSelf = {
    {
      text = CHS[5410533],
      func = "onMiaoYChangeImage"
    },
    {
      text = CHS[5410536],
      func = "onMiaoYDeletePorject"
    }
  },
  MiaoYDeleteRecord = {
    {
      text = CHS[5410543],
      func = "onMiaoYDeleteRecord"
    }
  },
  MiaoYRadioMore = {
    {
      text = CHS[5420464],
      func = "onMiaoYChangeName"
    },
    {
      text = CHS[5410533],
      func = "onMiaoYChangeImage"
    },
    {
      text = CHS[5410558],
      func = "onMiaoYGuyRadio"
    }
  },
  MiaoYShowPortrait = {
    {
      text = CHS[2000429],
      func = "onOpenPhoto"
    },
    {
      text = CHS[2000430],
      func = "onOpenCamera",
      cond = function()
        return gf:gfIsFuncEnabled(FUNCTION_ID.IMAGE_PICK_FIXED)
      end
    },
    {
      text = CHS[4200452],
      func = "onDelPortrait",
      cond = function(dlgName, typeStr, sender)
        return DlgMgr:sendMsg("MiaoYRadioPictureDlg", "showDelete", sender)
      end
    }
  }
}
function BlogButtonListDlg:init(info)
  self:bindListener("UserButton", self.onButton, "ListView")
  self.btnItem = self:retainCtrl("UserButton")
  local listView = self:getControl("ListView")
  self.viewSize = listView:getContentSize()
  self.dlgSize = self.root:getContentSize()
  self.sender = info.sender
  self.gid = nil
  self.typeStr = info.typeStr
  self.parentDlg = info.dlgName
  self.param = info.param
  self:initList(info.typeStr, info.param)
end
function BlogButtonListDlg:setGid(gid)
  self.gid = gid
end
function BlogButtonListDlg:setCallbackObj(sender)
  self.sender = sender
end
function BlogButtonListDlg:initListForCopyContent(listView, param)
  for i = 1, #param do
    local item = self.btnItem:clone()
    local list = gf:split(param[i], "=")
    item.copeContent = list[2]
    self:setLabelText("NameLabel", list[1], item)
    listView:pushBackCustomItem(item)
    self:bindTouchEndEventListener(item, self.onCopyButton)
  end
end
function BlogButtonListDlg:onCopyButton(sender)
  gf:copyTextToClipboard(sender.copeContent)
  gf:ShowSmallTips(CHS[4200610])
  self:onCloseButton()
end
function BlogButtonListDlg:initListForButtonList(listView, param)
  for i = 1, #param do
    local item = self.btnItem:clone()
    item.param = param[i]
    self:setLabelText("NameLabel", param[i].title, item)
    listView:pushBackCustomItem(item)
    self:bindTouchEndEventListener(item, self.onClickButton)
  end
end
function BlogButtonListDlg:onClickButton(sender)
  local param = sender.param
  if not param then
    return
  end
  DlgMgr:sendMsg(self.parentDlg, param.action, self.sender, param.actionStr)
  self:onCloseButton()
end
function BlogButtonListDlg:initList(typeStr, param)
  local list = BUTTON_LIST[typeStr]
  if not list then
    return
  end
  local listView = self:resetListView("ListView")
  if typeStr == "copy_content" then
    self:initListForCopyContent(listView, param)
  elseif typeStr == "show_list" then
    self:initListForButtonList(listView, param)
  else
    for i = 1, #list do
      if "function" ~= type(list[i].cond) or list[i].cond(self.parentDlg, typeStr, self.sender, param) then
        local item = self.btnItem:clone()
        self:setLabelText("NameLabel", list[i].text, item)
        item.func = list[i].func
        item.info = list[i]
        listView:pushBackCustomItem(item)
      end
    end
  end
  local cnt = #listView:getItems()
  local itemSize = self.btnItem:getContentSize()
  local height = itemSize.height * cnt
  listView:setContentSize(cc.size(self.viewSize.width, height))
  self.root:setContentSize(cc.size(self.dlgSize.width, self.dlgSize.height - self.viewSize.height + height))
end
function BlogButtonListDlg:onButton(sender, eventType)
  local func = sender.func
  if func then
    self[func](self, sender)
  end
  self:onCloseButton()
end
function BlogButtonListDlg:onOpenPhoto()
  DlgMgr:sendMsg(self.parentDlg, "openPhoto", 0)
end
function BlogButtonListDlg:onOpenCamera()
  DlgMgr:sendMsg(self.parentDlg, "openPhoto", 1)
end
function BlogButtonListDlg:onDelPortrait()
  DlgMgr:sendMsg(self.parentDlg, "deleteIcon")
end
function BlogButtonListDlg:onReportPortrait()
  DlgMgr:sendMsg(self.parentDlg, "reportIcon", self.sender)
end
function BlogButtonListDlg:onReportSign()
  DlgMgr:sendMsg(self.parentDlg, "reportSign")
end
function BlogButtonListDlg:onReComment()
  DlgMgr:sendMsg(self.parentDlg, "onReComment")
end
function BlogButtonListDlg:onEditComment()
  DlgMgr:sendMsg(self.parentDlg, "onEditComment", self.sender)
end
function BlogButtonListDlg:onDelComment()
  DlgMgr:sendMsg(self.parentDlg, "onDelComment", self.sender)
end
function BlogButtonListDlg:onDelSomeOneAllComment()
  DlgMgr:sendMsg(self.parentDlg, "onDelSomeOneAllComment", self.sender)
end
function BlogButtonListDlg:onSelectPhote()
  DlgMgr:sendMsg(self.parentDlg, "onSelectPhote", self.sender, 0)
end
function BlogButtonListDlg:onSelectCamera()
  DlgMgr:sendMsg(self.parentDlg, "onSelectPhote", self.sender, 1)
end
function BlogButtonListDlg:onDeletePhote()
  DlgMgr:sendMsg(self.parentDlg, "onDeletePhote", self.sender)
end
function BlogButtonListDlg:onViewPhoto()
  DlgMgr:sendMsg(self.parentDlg, "onViewPhoto", self.sender)
end
function BlogButtonListDlg:onReset()
  DlgMgr:sendMsg(self.parentDlg, "doReset", self.sender)
end
function BlogButtonListDlg:onShareWBToCurrent()
  DlgMgr:sendMsg(self.parentDlg, "doShareWeddingBook", self.sender, CHAT_CHANNEL.CURRENT)
end
function BlogButtonListDlg:onShareWBToWorld()
  DlgMgr:sendMsg(self.parentDlg, "doShareWeddingBook", self.sender, CHAT_CHANNEL.WORLD)
end
function BlogButtonListDlg:onShareWBToParty()
  DlgMgr:sendMsg(self.parentDlg, "doShareWeddingBook", self.sender, CHAT_CHANNEL.PARTY)
end
function BlogButtonListDlg:onShareWBToTeam()
  DlgMgr:sendMsg(self.parentDlg, "doShareWeddingBook", self.sender, CHAT_CHANNEL.TEAM)
end
function BlogButtonListDlg:onShareWBToFriend()
  DlgMgr:sendMsg(self.parentDlg, "doShareWeddingBook", self.sender, CHAT_CHANNEL.FRIEND)
end
function BlogButtonListDlg:onReportWBCover()
  DlgMgr:sendMsg(self.parentDlg, "doReportCover", self.sender)
end
function BlogButtonListDlg:onReportWBPhoto()
  DlgMgr:sendMsg(self.parentDlg, "doReportPhoto", self.sender)
end
function BlogButtonListDlg:onViewProp()
  DlgMgr:sendMsg(self.parentDlg, "doViewProp", self.param)
end
function BlogButtonListDlg:onSeeReserve()
  DlgMgr:sendMsg(self.parentDlg, "doSeeReserve", self.param)
end
function BlogButtonListDlg:onReserve()
  DlgMgr:sendMsg(self.parentDlg, "doReserve", self.param)
end
function BlogButtonListDlg:onCommunicate()
  DlgMgr:sendMsg(self.parentDlg, "doCommunicate", self.param)
end
function BlogButtonListDlg:onViewBlog()
  DlgMgr:sendMsg(self.parentDlg, "doViewBlog", self.param)
end
function BlogButtonListDlg:onEnlistPolar(sender)
  DlgMgr:sendMsg(self.parentDlg, "doSelectPolar", sender.info.text)
end
function BlogButtonListDlg:onEnlistPoint(sender)
  DlgMgr:sendMsg(self.parentDlg, "doSelectPoint", sender.info.text)
end
function BlogButtonListDlg:onOperFriend()
  DlgMgr:sendMsg(self.parentDlg, "doOperFriend")
end
function BlogButtonListDlg:onReportEnlist()
  DlgMgr:sendMsg(self.parentDlg, "doReport")
end
function BlogButtonListDlg:cleanup()
  DlgMgr:sendMsg(self.parentDlg, "doCloseButtonListDlg")
end
function BlogButtonListDlg:onReportMatchMaking()
  DlgMgr:sendMsg(self.parentDlg, "doReport", self.sender)
end
function BlogButtonListDlg:onAddFriend()
  DlgMgr:sendMsg(self.parentDlg, "doAddFriend", self.sender)
end
function BlogButtonListDlg:onDeleteFriend()
  DlgMgr:sendMsg(self.parentDlg, "doDeleteFriend", self.sender)
end
function BlogButtonListDlg:setFloatingFramePos(rect, clickPos)
  if self.typeStr == "blogDelCommentOp" or self.typeStr == "blogCommentOp" or self.typeStr == "blogCommentAndReportForMessage" or self.typeStr == "blogCommentAndReport" or self.typeStr == "LottoCommentAndReport" or self.typeStr == "LottoDeleteMessage" or self.typeStr == "MiaoYDeleteRecord" then
    local size = self.root:getContentSize()
    self:setCtrlVisible("PointImage", true)
    local x = rect.x + rect.width * 0.5
    local y = rect.y + rect.height * 0.5
    local dlgSize = self.root:getContentSize()
    dlgSize.width = dlgSize.width * Const.UI_SCALE
    dlgSize.height = dlgSize.height * Const.UI_SCALE
    local ap = self.root:getAnchorPoint()
    self.root:setAnchorPoint(0, 0)
    local posX, posY, isUp
    posX = rect.x - dlgSize.width - 14
    posY = y - dlgSize.height * 0.5
    self:setPosition(cc.p(posX, posY))
  elseif self.typeStr == "petDelCommentOp" or "onReportComment" == self.typeStr then
    local size = self.root:getContentSize()
    local x = rect.x + rect.width * 0.5
    local y = rect.y + rect.height * 0.5
    self.root:setAnchorPoint(0.5, 0.5)
    self:setPosition(cc.p(x, y))
  elseif self.typeStr == "MiaoYProjectMessage" or self.typeStr == "MiaoYDeleteMessage" or self.typeStr == "MiaoYCommentAndReport" then
    local x = clickPos.x or rect.x
    local y = clickPos.y or rect.y
    self.root:setAnchorPoint(0.5, 0.5)
    self:setPosition(cc.p(x, y))
  elseif self.typeStr == "playerEnlistPolar" or self.typeStr == "playerEnlistPoint" or self.typeStr == "TeamEnlistOther" then
    local x = rect.x + rect.width * 0.5
    local y = rect.y + rect.height
    self.root:setAnchorPoint(0.5, 0)
    self:setPosition(cc.p(x, y))
  else
    Dialog.setFloatingFramePos(self, rect)
  end
end
function BlogButtonListDlg:onTipOffMarket()
  DlgMgr:sendMsg(self.parentDlg, "onTipOffMarket", self.sender)
end
function BlogButtonListDlg:onGoodVoiceDetailsDlgjbly()
  DlgMgr:sendMsg(self.parentDlg, "onReportMsg", self.sender)
end
function BlogButtonListDlg:onShockButton()
  DlgMgr:sendMsg(self.parentDlg, "onShockButton", self.sender, self.param)
end
function BlogButtonListDlg:onBaosjcDlgMairu()
  DlgMgr:sendMsg(self.parentDlg, "onBaosjcDlgMairu", self.sender)
end
function BlogButtonListDlg:onBaosjcDlgZhakai()
  DlgMgr:sendMsg(self.parentDlg, "onBaosjcDlgZhakai", self.sender)
end
function BlogButtonListDlg:onReportLookonDlg()
  DlgMgr:sendMsg(self.parentDlg, "onViewButton", self.sender)
end
function BlogButtonListDlg:onReportCommentForBlog()
  DlgMgr:sendMsg(self.parentDlg, "onReportCommentForBlog", self.sender)
end
function BlogButtonListDlg:onReplyCommentForBlog()
  if gf:isLimitChangeUserInfo() then
    return
  end
  DlgMgr:sendMsg(self.parentDlg, "onReplyCommentForBlog", self.sender)
end
function BlogButtonListDlg:onLottoDeleteMessage()
  DlgMgr:sendMsg(self.parentDlg, "onDeleteMessage", self.sender)
end
function BlogButtonListDlg:onMiaoYDeletePorject()
  DlgMgr:sendMsg(self.parentDlg, "onMiaoYDeletePorject", self.sender)
end
function BlogButtonListDlg:onMiaoYDeleteRecord()
  DlgMgr:sendMsg(self.parentDlg, "onDelButton", self.sender)
end
function BlogButtonListDlg:onMiaoYChangeImage()
  DlgMgr:sendMsg(self.parentDlg, "onMiaoYChangeImage", self.sender)
end
function BlogButtonListDlg:onMiaoYChangeName()
  if gf:isLimitChangeUserInfo() then
    return
  end
  DlgMgr:sendMsg(self.parentDlg, "onMiaoYChangeName", self.sender)
end
function BlogButtonListDlg:onMiaoYGuyRadio()
  DlgMgr:sendMsg(self.parentDlg, "onMiaoYGuyRadio", self.sender)
end
function BlogButtonListDlg:onMiaoYReportPorject()
  DlgMgr:sendMsg(self.parentDlg, "onMiaoYReportPorject", self.sender)
end
function BlogButtonListDlg:onGoodVoiceDetailsDlgchly()
  DlgMgr:sendMsg(self.parentDlg, "onChehly", self.sender)
end
function BlogButtonListDlg:onGoodVoiceDetailsDlghfly()
  DlgMgr:sendMsg(self.parentDlg, "onCommentMsg", self.sender)
end
function BlogButtonListDlg:onRemardBomb()
  DlgMgr:sendMsg(self.parentDlg, "onRemardBomb", self.sender)
end
function BlogButtonListDlg:onRemoveBomb()
  DlgMgr:sendMsg(self.parentDlg, "onRemoveBomb", self.sender)
end
function BlogButtonListDlg:onPartyAnnouce()
  if not self.sender.partyInfo then
    return
  end
  local announce = self.sender.partyInfo.partyAnnounce or self.sender.partyInfo.annouce
  if not announce or announce == "" then
    gf:ShowSmallTips(CHS[4300479])
    return
  end
  if Me:queryBasicInt("level") < 35 then
    gf:ShowSmallTips(CHS[4300480])
    return
  end
  local data = {}
  data.user_gid = self.sender.partyInfo.partyId
  data.user_name = self.sender.partyInfo.partyName
  data.type = "dlg"
  data.content = {}
  data.count = 1
  data.user_dist = ""
  data.content[1] = {}
  data.content[1].reason = "party_annouce"
  gf:CmdToServer("CMD_REPORT_USER", data)
  ChatMgr:setTipDataForAnnounce(self.sender.partyInfo)
end
function BlogButtonListDlg:onKidInfoDlgCare(sender)
  local text = self:getLabelText("NameLabel", sender)
  DlgMgr:sendMsg("KidInfoDlg", "onKidInfoDlgCare", text)
end
return BlogButtonListDlg
