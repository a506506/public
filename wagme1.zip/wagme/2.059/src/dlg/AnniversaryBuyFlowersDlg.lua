local AnniversaryBuyFlowersDlg = Singleton("AnniversaryBuyFlowersDlg", Dialog)
function AnniversaryBuyFlowersDlg:init()
  self:setFullScreen()
  self:initData()
  self:refreshData()
  self:hookMsg("MSG_C_FRIENDS")
  self:hookMsg("MSG_ZHOUNIANQING2020_CGLH_DATA")
  EventDispatcher:addEventListener(EVENT.ADD_FIGHT_OBJ, self.onAddFightObj, self)
end
function AnniversaryBuyFlowersDlg:cleanup()
  EventDispatcher:removeEventListener(EVENT.ADD_FIGHT_OBJ, self.onAddFightObj, self)
end
function AnniversaryBuyFlowersDlg:initData()
  self.flower1 = 0
  self.flower2 = 0
  self.flower3 = 0
  for i = FightPosMgr.NUM_PER_LINE * 2, FightPosMgr.NUM_PER_LINE * 4 - 1 do
    local obj = FightMgr:getCreatedObj(i)
    if obj then
      local name = obj:getName()
      if name == CHS[2100365] then
        self.flower1 = self.flower1 + 1
      elseif name == CHS[2100366] then
        self.flower2 = self.flower2 + 1
      elseif name == CHS[2100367] then
        self.flower3 = self.flower3 + 1
      end
    end
  end
end
function AnniversaryBuyFlowersDlg:onAddFightObj()
  self:initData()
  self:refreshData()
end
function AnniversaryBuyFlowersDlg:getColorString(n, m)
  n = n or 0
  m = m or 0
  if n < m then
    return string.format("#c666666%d#n#c14A314/%d#n", n, m)
  elseif n == m then
    return string.format("#c14A314%d#n#c14A314/%d#n", n, m)
  else
    return string.format("#cBD3939%d#n#c14A314/%d#n", n, m)
  end
end
function AnniversaryBuyFlowersDlg:refreshData()
  local cglhData = AnniversaryMgr:getZnqCglhData()
  self:setColorTextEx(self:getColorString(self.flower3, cglhData.fnum_lanh), self:getControl("ValuePanel", nil, "FlowerPanel01"), nil, 18)
  self:setColorTextEx(self:getColorString(self.flower2, cglhData.fnum_mud), self:getControl("ValuePanel", nil, "FlowerPanel02"), nil, 18)
  self:setColorTextEx(self:getColorString(self.flower1, cglhData.fnum_yul), self:getControl("ValuePanel", nil, "FlowerPanel03"), nil, 18)
end
function AnniversaryBuyFlowersDlg:MSG_C_FRIENDS(data)
  self:initData()
end
function AnniversaryBuyFlowersDlg:MSG_ZHOUNIANQING2020_CGLH_DATA(data)
  self:refreshData()
end
return AnniversaryBuyFlowersDlg
