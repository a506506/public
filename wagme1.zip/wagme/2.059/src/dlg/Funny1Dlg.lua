local FunnyDlg = require("dlg/FunnyDlg")
local Funny1Dlg = Singleton("Funny1Dlg", FunnyDlg)
return Funny1Dlg
