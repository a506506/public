local FrozenMoneyDlg = Singleton("FrozenMoneyDlg", Dialog)
local DataObject = require("core/DataObject")
local PAGE_COUNT = 10
function FrozenMoneyDlg:init(data)
  self:bindListener("InfoButton", self.onInfoButton)
  self:bindListViewListener("ItemsListView", self.onSelectItemsListView)
  self:bindFloatingEvent("RulePanel")
  self.unitPanel = self:retainCtrl("UnitPanel")
  self:bindListener("ItemImagePanel", self.onItemImagePanel, self.unitPanel)
  if not self.cardInfo then
    self.cardInfo = {}
  end
  self.curIdx = 0
  self:hookMsg("MSG_STALL_RECORD_DETAIL")
  self:bindListViewByPageLoad("ItemsListView", "TouchPanel", function(dlg, percent)
    if percent > 100 then
      performWithDelay(self.root, function()
        gf:CmdToServer("CMD_STALL_REQUEST_FROZEN_RECORD", {
          from_pos = self.data.from_pos + PAGE_COUNT
        })
      end, 0.5)
    end
  end)
end
function FrozenMoneyDlg:setData(data)
  if data.count == 0 then
    return
  end
  if data.from_pos == 0 then
    self:resetListView("ItemsListView")
  end
  self:pushData(data)
  local cashText, fontColor = gf:getArtFontMoneyDesc(tonumber(data.all_remain_money))
  self:setNumImgForPanel("NumPanel1", fontColor, cashText, false, LOCATE_POSITION.MID, 23, "TotalPanel")
  local cashText, fontColor = gf:getArtFontMoneyDesc(tonumber(data.all_active_money))
  self:setNumImgForPanel("NumPanel2", fontColor, cashText, false, LOCATE_POSITION.MID, 23, "TotalPanel")
end
function FrozenMoneyDlg:pushData(data)
  self.data = data
  local list = self:getControl("ItemsListView")
  for i = 1, data.count do
    local uPanel = self.unitPanel:clone()
    self:setUnitPanel(data[i], uPanel, i)
    list:pushBackCustomItem(uPanel)
  end
  self.curIdx = self.curIdx + data.count
end
function FrozenMoneyDlg:setUnitPanel(data, panel, idx)
  panel.data = data
  self:setLabelText("TimeLabel1", gf:getServerDate(CHS[4300233], data.frozen_time), panel)
  self:setLabelText("TimeLabel1_2", gf:getServerDate(CHS[4100718], data.frozen_time), panel)
  local leftTi = data.end_time - gf:getServerTime()
  leftTi = math.max(leftTi, 0)
  leftTi = math.ceil(leftTi / 86400)
  self:setLabelText("TimeLabel2", gf:getServerDate(CHS[4300233], data.end_time), panel)
  self:setLabelText("TimeLabel2_2", gf:getServerDate(CHS[4100718], data.end_time), panel)
  local cashText, fontColor = gf:getArtFontMoneyDesc(tonumber(data.remain_money))
  self:setNumImgForPanel("LeftMoneyLabelPanel", fontColor, cashText, false, LOCATE_POSITION.MID, 19, panel)
  local cashText, fontColor = gf:getArtFontMoneyDesc(tonumber(data.active_money))
  self:setNumImgForPanel("DayMoneyLabelPanel", fontColor, cashText, false, LOCATE_POSITION.MID, 19, panel)
  self:setCtrlVisible("BackImage2", idx % 2 == 0, panel)
  if string.match(data.name, CHS[3003018]) then
    local name = string.gsub(data.name, CHS[3003019], "")
    local list = gf:split(name, "|")
    self:setLabelText("NameLabel", list[1], panel)
    local field = EquipmentMgr:getAttribChsOrEng(list[1])
    local str = field .. "_" .. Const.FIELDS_EXTRA1
    local value = 0
    local maxValue = 0
    local bai = ""
    if list[2] then
      value = tonumber(list[2])
      local equip = {
        req_level = data.level,
        equip_type = list[3]
      }
      maxValue = EquipmentMgr:getAttribMaxValueByField(equip, field) or ""
      if EquipmentMgr:getAttribsTabByName(CHS[3003020])[field] then
        bai = "%"
      end
    end
    local valueText = value .. bai .. "/" .. maxValue .. bai
    self:setLabelText("ItemNameLabel", list[1] .. CHS[3003588] .. valueText, panel)
  else
    self:setLabelText("ItemNameLabel", PetMgr:trimPetRawName(data.name), panel)
  end
  local cashText, fontColor = gf:getArtFontMoneyDesc(tonumber(data.price))
  self:setNumImgForPanel("NumPanel", fontColor, cashText, false, LOCATE_POSITION.MID, 19, panel)
  local imgPath
  if PetMgr:getPetIcon(data.name) then
    imgPath = ResMgr:getSmallPortrait(PetMgr:getPetIcon(data.name))
  else
    local icon = InventoryMgr:getIconByName(data.name)
    imgPath = ResMgr:getItemIconPath(icon)
  end
  self:setImage("ItemImage", imgPath, panel)
end
function FrozenMoneyDlg:onItemImagePanel(sender, eventType)
  local item = sender:getParent().data
  MarketMgr:setOpenType(MARKET_CARD_TYPE.FLOAT_DLG)
  if self.cardInfo[item.rid] then
    self:MSG_STALL_RECORD_DETAIL(self.cardInfo[item.rid])
  else
    gf:CmdToServer("CMD_STALL_RECORD_DETAIL", {
      record_id = item.rid
    })
  end
end
function FrozenMoneyDlg:onInfoButton(sender, eventType)
  self:setCtrlVisible("RulePanel", true)
end
function FrozenMoneyDlg:onSelectItemsListView(sender, eventType)
end
function FrozenMoneyDlg:MSG_STALL_RECORD_DETAIL(data)
  self.cardInfo[data.record_id] = data
  if data.goods_type == TRANSFER_ITEM_TYPE.OTHER then
  elseif data.goods_type == TRANSFER_ITEM_TYPE.CASH then
  elseif data.goods_type == TRANSFER_ITEM_TYPE.PET then
    local objcet = DataObject.new()
    data.raw_name = PetMgr:getShowNameByRawName(data.raw_name)
    data.icon = PetMgr:getPetIcon(data.raw_name)
    data.id = 0
    objcet:absorbBasicFields(data)
    MarketMgr:showPetFloatBox(objcet)
  elseif data.goods_type == TRANSFER_ITEM_TYPE.CHARGE then
    MarketMgr.pram = nil
    MarketMgr.selectItem = nil
    MarketMgr:showItemFloatBox({item = data})
  elseif data.goods_type == TRANSFER_ITEM_TYPE.NOT_COMBINE then
    MarketMgr.pram = nil
    MarketMgr.selectItem = nil
    MarketMgr:showItemFloatBox({item = data})
  elseif data.goods_type == TRANSFER_ITEM_TYPE.COMBINE then
    MarketMgr.pram = nil
    MarketMgr.selectItem = nil
    MarketMgr:showItemFloatBox({item = data})
  end
end
return FrozenMoneyDlg
