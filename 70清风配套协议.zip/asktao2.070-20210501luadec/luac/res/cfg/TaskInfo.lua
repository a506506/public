return {
  [CHS[3001724]] = {
    taskDesc = CHS[3001725],
    curNoteInfo = CHS[3001726],
    taskReward = CHS[3001727],
    removeInfo = CHS[3001728],
    tasksName = {
      "sm-001",
      "sm-002",
      "sm-003",
      "sm-004",
      "sm-005",
      "sm-006",
      "sm-007",
      "sm-008",
      "sm-009",
      "sm-010",
      "sm-011"
    }
  },
  ["sm-001"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-002"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-003"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-004"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-005"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-006"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-007"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-008"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-009"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-010"] = {
    removeInfo = CHS[3001728]
  },
  ["sm-011"] = {
    removeInfo = CHS[3001728]
  },
  [CHS[3001729]] = {
    removeInfo = CHS[3001730]
  },
  [CHS[3001731]] = {
    removeInfo = CHS[3001730]
  },
  [CHS[3001732]] = {
    removeInfo = CHS[3001730]
  },
  [CHS[3001733]] = {
    removeInfo = CHS[3001730]
  },
  [CHS[3001734]] = {
    removeInfo = CHS[3001730]
  },
  [CHS[3001735]] = {
    removeInfo = CHS[3001736]
  },
  [CHS[3001737]] = {
    removeInfo = CHS[3001736]
  },
  [CHS[3001738]] = {
    removeInfo = CHS[3001736]
  },
  [CHS[3001739]] = {
    removeInfo = CHS[3001736]
  },
  [CHS[3001740]] = {
    removeInfo = CHS[3001736]
  },
  [CHS[3001741]] = {
    removeInfo = CHS[3001742]
  },
  ["sm-016"] = {
    removeInfo = CHS[6400037]
  },
  ["sm-017"] = {
    removeInfo = CHS[6400037]
  },
  ["sm-018"] = {
    removeInfo = CHS[6400037]
  },
  ["sm-019"] = {
    removeInfo = CHS[6400037]
  },
  [CHS[5200003]] = {
    removeInfo = CHS[5200004]
  },
  [CHS[7002083]] = {
    removeInfo = CHS[7002081]
  },
  [CHS[7002084]] = {
    removeInfo = CHS[7002082]
  },
  [CHS[7002220]] = {removeInfo = ""},
  [CHS[5430456]] = {
    removeInfo = CHS[5430457]
  },
  [CHS[5430458]] = {notShowHideBtn = true},
  [CHS[5430459]] = {notShowHideBtn = true},
  [CHS[5430460]] = {notShowHideBtn = true},
  [CHS[5430461]] = {notShowHideBtn = true},
  [CHS[5430462]] = {notShowHideBtn = true},
  ["魔龙之祸—剿灭分魂"] = {
    removeInfo = "放弃#R魔龙之祸任务#n需要等待#R5分钟#n之后才能再次领取，是否确认放弃。"
  },
  ["魔龙之祸—解救玉兔"] = {
    removeInfo = "放弃#R魔龙之祸任务#n需要等待#R5分钟#n之后才能再次领取，是否确认放弃。"
  },
  ["魔龙之祸—拾取龙鳞"] = {
    removeInfo = "放弃#R魔龙之祸任务#n需要等待#R5分钟#n之后才能再次领取，是否确认放弃。"
  },
  ["魔龙之祸—拯救金吒"] = {
    removeInfo = "放弃#R魔龙之祸任务#n需要等待#R5分钟#n之后才能再次领取，是否确认放弃。"
  },
  ["魔龙之祸—五行逆转"] = {
    removeInfo = "放弃#R魔龙之祸任务#n需要等待#R5分钟#n之后才能再次领取，是否确认放弃。"
  }
}
