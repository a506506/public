return {
  ["辣椒"] = {
    icon = 7203,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["娃娃菜"] = {
    icon = 7200,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["黄豆"] = {
    icon = 9221,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["花椒"] = {
    icon = 9222,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["青椒"] = {
    icon = 9223,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["蒜苗"] = {
    icon = 9224,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["花生"] = {
    icon = 9225,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["葱"] = {
    icon = 9226,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["木耳"] = {
    icon = 9227,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["莴笋"] = {
    icon = 9228,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["姜"] = {
    icon = 9229,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["八角"] = {
    icon = 9230,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["梅菜"] = {
    icon = 9231,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["香菜"] = {
    icon = 9232,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["大白萝卜"] = {
    icon = 9233,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["猪肉"] = {
    icon = 9234,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["鸡肉"] = {
    icon = 9235,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["乳鸽"] = {
    icon = 9236,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["牛肉"] = {
    icon = 9237,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["海参"] = {
    icon = 9238,
    unit = "份",
    double_type = 0,
    descript = "",
    rescourse = {
      "帮派宴会"
    }
  },
  ["龙虾"] = {
    icon = 9239,
    descript = "",
    rescourse = {
      "帮派宴会"
    },
    unit = "份"
  },
  ["鱼翅"] = {
    icon = 9240,
    descript = "",
    rescourse = {
      "帮派宴会"
    },
    unit = "份"
  },
  ["鱼"] = {
    icon = 9241,
    descript = "",
    rescourse = {
      "帮派宴会"
    },
    unit = "份"
  },
  ["鲍鱼"] = {
    icon = 9242,
    descript = "",
    rescourse = {
      "帮派宴会"
    },
    unit = "份"
  }
}
