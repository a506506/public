return {
  [CHS[7002136]] = {
    name = CHS[7002136],
    icon = 6301,
    zoon = {},
    polar = CHS[34310],
    level_req = 1,
    life = 45,
    mana = 25,
    speed = 10,
    phy_attack = -40,
    mag_attack = 35,
    skills = {
      CHS[3000078],
      CHS[3000075],
      CHS[3000071]
    },
    price = 100,
    order = 1,
    artName = "ui/Icon0842.png"
  },
  [CHS[7002137]] = {
    name = CHS[7002137],
    icon = 6302,
    zoon = {},
    polar = CHS[3001385],
    level_req = 1,
    life = 50,
    mana = 0,
    speed = 5,
    phy_attack = 60,
    mag_attack = -40,
    skills = {
      CHS[3000079],
      CHS[3000076],
      CHS[3000074]
    },
    price = 100,
    order = 2,
    artName = "ui/Icon0843.png"
  },
  [CHS[5450106]] = {
    name = CHS[5450106],
    icon = 6321,
    zoon = {},
    polar = CHS[3001388],
    level_req = 1,
    life = 40,
    mana = 15,
    speed = 25,
    phy_attack = -40,
    mag_attack = 35,
    skills = {
      CHS[3000083],
      CHS[3000071],
      CHS[3000078]
    },
    price = 100,
    order = 3,
    artName = "ui/Icon1604.png"
  },
  [CHS[5450108]] = {
    name = CHS[5450108],
    icon = 6322,
    zoon = {},
    polar = CHS[3001385],
    level_req = 1,
    life = 35,
    mana = 0,
    speed = 20,
    phy_attack = 60,
    mag_attack = -40,
    skills = {
      CHS[3000072],
      CHS[3000071],
      CHS[3000079]
    },
    price = 100,
    order = 4,
    artName = "ui/Icon1605.png"
  },
  [CHS[5450375]] = {
    name = CHS[5450375],
    icon = 6323,
    zoon = {},
    polar = CHS[3001393],
    level_req = 1,
    life = 30,
    mana = 15,
    speed = 30,
    phy_attack = -40,
    mag_attack = 40,
    skills = {
      CHS[3000082],
      CHS[3000079],
      CHS[3000076]
    },
    price = 100,
    order = 5,
    artName = "ui/Icon2338.png"
  },
  [CHS[5450376]] = {
    name = CHS[5450376],
    icon = 6324,
    zoon = {},
    polar = CHS[3001385],
    level_req = 1,
    life = 60,
    mana = 0,
    speed = 0,
    phy_attack = 55,
    mag_attack = -40,
    skills = {
      CHS[3000078],
      CHS[3000073],
      CHS[3000075]
    },
    price = 100,
    order = 6,
    artName = "ui/Icon2337.png"
  },
  [CHS[5420449]] = {
    name = CHS[5420449],
    icon = 6325,
    zoon = {},
    polar = CHS[3001385],
    level_req = 1,
    life = 30,
    mana = 0,
    speed = 25,
    phy_attack = 60,
    mag_attack = -40,
    skills = {
      CHS[3000079],
      CHS[3000076],
      CHS[3000073]
    },
    price = 100,
    order = 7,
    artName = "ui/BitmapLabel0037.png"
  },
  [CHS[5420450]] = {
    name = CHS[5420450],
    icon = 6326,
    zoon = {},
    polar = CHS[34310],
    level_req = 1,
    life = 40,
    mana = 10,
    speed = 30,
    phy_attack = -40,
    mag_attack = 35,
    skills = {
      CHS[3000077],
      CHS[3000074],
      CHS[3000075]
    },
    price = 100,
    order = 8,
    artName = "ui/BitmapLabel0038.png"
  },
  [CHS[4102198]] = {
    name = CHS[4102198],
    icon = 6327,
    zoon = {},
    polar = CHS[34048],
    level_req = 1,
    life = 30,
    mana = 0,
    speed = 30,
    phy_attack = 55,
    mag_attack = -40,
    skills = {
      CHS[3000078],
      CHS[3000074],
      CHS[3000076]
    },
    price = 100,
    order = 9,
    artName = "ui/BitmapLabel0038.png"
  },
  [CHS[4102199]] = {
    name = CHS[4102199],
    icon = 6328,
    zoon = {},
    polar = CHS[34310],
    level_req = 1,
    life = 35,
    mana = 10,
    speed = 35,
    phy_attack = -40,
    mag_attack = 35,
    skills = {
      CHS[3000079],
      CHS[3000075],
      CHS[3000071]
    },
    price = 100,
    order = 10,
    artName = "ui/BitmapLabel0038.png"
  }
}
