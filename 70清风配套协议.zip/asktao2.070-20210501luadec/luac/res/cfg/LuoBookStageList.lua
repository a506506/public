return {
  [1] = {
    name = "凝气·初阶",
    level = 1,
    phy_power = 190,
    mag_power = 105,
    def = 0,
    speed = 0
  },
  [2] = {
    name = "凝气·中阶",
    level = 5,
    phy_power = 0,
    mag_power = 0,
    def = 380,
    speed = 0
  },
  [3] = {
    name = "凝气·高阶",
    level = 10,
    phy_power = 0,
    mag_power = 0,
    def = 0,
    speed = 30
  },
  [4] = {
    name = "聚灵·初阶",
    level = 15,
    phy_power = 190,
    mag_power = 105,
    def = 0,
    speed = 0
  },
  [5] = {
    name = "聚灵·中阶",
    level = 20,
    phy_power = 0,
    mag_power = 0,
    def = 380,
    speed = 0
  },
  [6] = {
    name = "聚灵·高阶",
    level = 25,
    phy_power = 0,
    mag_power = 0,
    def = 0,
    speed = 30
  },
  [7] = {
    name = "破邪·初阶",
    level = 30,
    phy_power = 190,
    mag_power = 105,
    def = 0,
    speed = 0
  },
  [8] = {
    name = "破邪·中阶",
    level = 35,
    phy_power = 0,
    mag_power = 0,
    def = 380,
    speed = 0
  },
  [9] = {
    name = "破邪·高阶",
    level = 40,
    phy_power = 0,
    mag_power = 0,
    def = 0,
    speed = 30
  },
  [10] = {
    name = "镇魔·初阶",
    level = 45,
    phy_power = 190,
    mag_power = 105,
    def = 0,
    speed = 0
  },
  [11] = {
    name = "镇魔·中阶",
    level = 50,
    phy_power = 0,
    mag_power = 0,
    def = 380,
    speed = 0
  },
  [12] = {
    name = "镇魔·高阶",
    level = 55,
    phy_power = 0,
    mag_power = 0,
    def = 0,
    speed = 30
  },
  [13] = {
    name = "阴阳·初阶",
    level = 60,
    phy_power = 190,
    mag_power = 105,
    def = 0,
    speed = 0
  },
  [14] = {
    name = "阴阳·中阶",
    level = 65,
    phy_power = 0,
    mag_power = 0,
    def = 380,
    speed = 0
  },
  [15] = {
    name = "阴阳·高阶",
    level = 70,
    phy_power = 0,
    mag_power = 0,
    def = 0,
    speed = 30
  },
  [16] = {
    name = "乾坤·初阶",
    level = 75,
    phy_power = 190,
    mag_power = 105,
    def = 0,
    speed = 0
  },
  [17] = {
    name = "乾坤·中阶",
    level = 80,
    phy_power = 0,
    mag_power = 0,
    def = 380,
    speed = 0
  },
  [18] = {
    name = "乾坤·高阶",
    level = 85,
    phy_power = 0,
    mag_power = 0,
    def = 0,
    speed = 30
  },
  [19] = {
    name = "无极·初阶",
    level = 90,
    phy_power = 190,
    mag_power = 105,
    def = 0,
    speed = 0
  },
  [20] = {
    name = "无极·中阶",
    level = 95,
    phy_power = 0,
    mag_power = 0,
    def = 380,
    speed = 0
  },
  [21] = {
    name = "无极·高阶",
    level = 100,
    phy_power = 0,
    mag_power = 0,
    def = 0,
    speed = 30
  }
}
