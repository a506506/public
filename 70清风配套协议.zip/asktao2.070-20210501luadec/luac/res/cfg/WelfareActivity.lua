return {
  {
    name = CHS[6000216],
    mainType = "share_with_friends",
    level = 32,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[6000221],
        "dlg",
        "ShareDlg"
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[6000219],
    reward = CHS[6000220],
    icon = "BigRewardIcon0025.png"
  },
  {
    name = CHS[6000255],
    mainType = "tianjiangbaohe",
    level = 30,
    times = 50,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[6000246],
        "npc",
        CHS[6000245]
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6400026],
    desc = CHS[6000257],
    reward = CHS[6000258],
    icon = "08009"
  },
  {
    name = CHS[6400025],
    mainType = "shidao_double",
    level = 60,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6400026],
    desc = CHS[6400027],
    reward = CHS[6400028],
    itemName = CHS[3000176]
  },
  {
    name = CHS[6400081],
    mainType = "shengji_kuanghuan",
    level = 71,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[3000730],
    desc = CHS[6400082],
    reward = CHS[6400083],
    icon = "BigRewardIcon0005.png"
  },
  {
    name = CHS[4100285],
    mainType = "suiji_richange",
    level = 10,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000730],
    desc = CHS[4100286],
    reward = CHS[4100287],
    icon = "BigRewardIcon0005.png"
  },
  {
    name = CHS[6200075],
    mainType = "quanfu_hongbao",
    level = 30,
    times = 30,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[6200076],
    testDistDesc = CHS[6200093],
    reward = CHS[6200077],
    icon = "BigRewardIcon0022.png",
    goingTime = {
      {
        "12:00-12:02:30"
      },
      {
        "18:00-18:02:30"
      },
      {
        "22:00-22:02:30"
      }
    }
  },
  {
    name = CHS[7000125],
    mainType = "huanlebaoxiang",
    level = 30,
    times = 10,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[3000730],
    desc = CHS[7000126],
    testDistDesc = CHS[7000126],
    reward = CHS[7000127],
    icon = 8043
  },
  {
    name = CHS[2000192],
    mainType = "discount_coupon",
    level = 30,
    times = 5,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[3000730],
    desc = CHS[2000193],
    testDistDesc = CHS[2000193],
    reward = CHS[2000194],
    icon = 1631
  },
  {
    name = CHS[7002150],
    mainType = "chongbang_dasai",
    level = 10,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7002152],
    reward = CHS[7002153],
    icon = "BigRewardIcon0016.png"
  },
  {
    name = CHS[7002154],
    mainType = "liveness_lottery",
    level = 35,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7002155],
    reward = CHS[7002156],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7002157],
    mainType = "insider_discount",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7002158],
    reward = CHS[7002159],
    icon = "BigRewardIcon0023.png"
  },
  {
    name = CHS[7150679],
    mainType = "baibaodai_2020",
    level = 35,
    times = 10,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7150680],
    testDistDesc = CHS[7150691],
    reward = CHS[7150681],
    testDistReward = CHS[7150690],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[2000903],
    mainType = "baifudai",
    level = 35,
    times = 3,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[2000904],
    testDistDesc = CHS[2000904],
    reward = CHS[2000905],
    testDistReward = CHS[2000905],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7002160],
    mainType = "nvwabaoxiang",
    level = 1,
    times = 2,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7002161],
    reward = CHS[7002162],
    icon = 9151
  },
  {
    name = CHS[2200180],
    mainType = "limit_purchase_gift_new_dist_nwbx",
    level = 1,
    times = 2,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7002161],
    reward = CHS[7002162],
    icon = 9151
  },
  {
    name = CHS[7002163],
    mainType = "recharge_score",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "ChargePointDlg"
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7002164],
    reward = CHS[7002165],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7001055],
    mainType = "consume_score",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "ConsumePointDlg"
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7001056],
    reward = CHS[7001057],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4200312],
    mainType = "recall_user_2017",
    level = 70,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[4200313],
    reward = CHS[4200314],
    icon = "BigRewardIcon0044.png"
  },
  {
    name = CHS[7003049],
    mainType = "active_bonus_vip_2017",
    level = 1,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7003050],
    reward = CHS[7003051],
    icon = "BigRewardIcon0023.png"
  },
  {
    name = CHS[7003073],
    mainType = "limit_purchase",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7003071],
    reward = CHS[7003072],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4300236],
    mainType = "month_charge_gift",
    level = 1,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "ChargeGiftPerMonthDlg"
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[4300237],
    reward = CHS[4300238],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4300244],
    mainType = "realname_gift",
    level = 20,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[4300245],
    testDistDesc = CHS[4300246],
    reward = CHS[4300247],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5420168],
    mainType = "welcome_draw",
    level = 1,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[5420177],
    testDistDesc = CHS[5420199],
    reward = CHS[5420178],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5420240],
    mainType = "boss_num_double",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[5000250],
    desc = CHS[5420242],
    testDistDesc = CHS[5420242],
    reward = CHS[5420243],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5420244],
    mainType = "sevenday_gift",
    level = 35,
    testLevel = 75,
    times = 7,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[5420245],
    testDistDesc = CHS[5420245],
    reward = CHS[5420246],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5400523],
    mainType = "jingyan_fanbei",
    level = 10,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[5400521]
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    needLevelTip = true,
    team = CHS[6400026],
    desc = CHS[5400522],
    reward = CHS[5400524],
    icon = "BigRewardIcon0005.png"
  },
  {
    name = CHS[2000906],
    mainType = "merge_xundao_cifu",
    level = 70,
    times = 5,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "XunDaoCiFuDlg"
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    needLevelTip = true,
    team = CHS[6000218],
    desc = CHS[2000907],
    reward = CHS[2000908],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[2200095],
    mainType = "merge_login_gift",
    level = 70,
    times = 7,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    needLevelTip = true,
    team = CHS[6000218],
    desc = CHS[2200096],
    reward = CHS[2200097],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[2200098],
    mainType = "merge_huoyue_jiangli",
    level = 70,
    times = 7,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    needLevelTip = true,
    team = CHS[6400026],
    desc = CHS[2200099],
    reward = CHS[2200100],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5420296],
    mainType = "wedding_discount",
    level = 40,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[5420299]
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    needLevelTip = true,
    team = CHS[6400026],
    desc = CHS[5420297],
    reward = CHS[5420298],
    itemName = CHS[7100168]
  },
  {
    name = CHS[7150086],
    mainType = "movie_hancheng_fenxiang",
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[7150087]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[7150089],
    reward = CHS[7150090],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7150185],
    mainType = "tianci_xiangrui",
    level = 45,
    times = 400,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000288],
    desc = CHS[7150186],
    reward = CHS[7150187],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[7100781],
    mainType = "ghostdom_double",
    level = 75,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[7100782]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000730],
    desc = CHS[7100783],
    reward = CHS[7100784],
    icon = "BigRewardIcon0064.png"
  },
  {
    name = CHS[4200887],
    mainType = "difu_lilian",
    level = 75,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[7100782]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[4200888],
    reward = CHS[4200889],
    icon = "BigRewardIcon0064.png"
  },
  {
    name = CHS[4300635],
    mainType = "yanluo_mibao",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[4300636],
    reward = CHS[4300637],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4300629],
    mainType = "double_lottery",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[4300630],
    reward = CHS[4300631],
    icon = "BigRewardIcon0027.png"
  },
  {
    name = CHS[5420411],
    mainType = "new_year_bless",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "XinnianqfDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7150088],
    desc = CHS[5420412],
    reward = CHS[5420413],
    icon = "Icon0074.png"
  },
  {
    name = CHS[4300710],
    mainType = "fixed_team_welfare",
    level = 50,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "GuDingDuiFuLiDlg"
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[4300709],
    reward = CHS[5420246],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5420494],
    mainType = "fixed_team_cooperate",
    level = 50,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "FixedTeamEffortDlg"
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000288],
    desc = CHS[5420495],
    reward = CHS[5420496],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5430427],
    mainType = "newyear_redbag_2020",
    level = 70,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "cmd",
        "CMD_NEWYEAR_REDBAG_2020_OPEN_DLG"
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    canGotoInCombat = true,
    team = CHS[7150088],
    desc = CHS[5430428],
    reward = CHS[5430429],
    resType = 0,
    icon = "ui/Icon0542.png"
  },
  {
    name = CHS[4300895],
    mainType = "ruyi_hongbaoyu",
    level = 10,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "cmd",
        "CMD_RUYI_HBY_RECORD"
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    canGotoInCombat = true,
    team = CHS[7150088],
    desc = CHS[4300896],
    reward = CHS[4300897],
    icon = "BigRewardIcon0022.png",
    ActivitiesButtonShowText = CHS[7333474]
  },
  {
    name = CHS[5401113],
    mainType = "yaomoling",
    level = 30,
    times = 3,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[5401114]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    canGotoInCombat = true,
    team = CHS[7150088],
    desc = CHS[5401115],
    reward = CHS[5401116],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[4201256],
    mainType = "world_chat_password",
    level = 20,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[4201257]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    canGotoInCombat = true,
    team = CHS[7150088],
    desc = CHS[4201258],
    reward = CHS[4201259],
    icon = "BigRewardIcon0052.png",
    itemName = CHS[4201260]
  },
  {
    name = CHS[4201261],
    mainType = "cross_year_2020",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[4300704]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[4201255],
    reward = CHS[4201263],
    petIcon = "6180"
  },
  {
    name = CHS[4300971],
    mainType = "caishen_zengli",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "MammonGiftDlg"
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[4300972],
    testDistDesc = CHS[4300990],
    reward = CHS[4300973],
    icon = "BigRewardIcon0102.png"
  },
  {
    name = CHS[7350088],
    mainType = "lantern_day_2021_tyyh",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[7350089],
    reward = CHS[7350092],
    icon = "BigRewardIcon0022.png",
    ActivitiesButtonShowText = CHS[7333474]
  },
  {
    name = CHS[7350087],
    mainType = "lantern_day_2021_yxzf",
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[7350090],
    reward = CHS[7350091],
    icon = "BigRewardIcon0022.png",
    ActivitiesButtonShowText = CHS[7333474]
  },
  {
    name = CHS[4400073],
    mainType = "wendao_guonian",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[4400074]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7150088],
    desc = CHS[4400075],
    reward = CHS[4400076],
    icon = "BigRewardIcon0022.png",
    ActivitiesButtonShowText = CHS[7333474]
  },
  {
    name = CHS[7366785],
    mainType = "limit_purchase_gift_mhbx",
    level = 1,
    times = 2,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    notClsoeDlgWhenGoto = true,
    team = CHS[6000218],
    desc = CHS[7366786],
    reward = CHS[7366787],
    icon = 9153,
    itemName = CHS[7366785]
  },
  {
    name = CHS[7366793],
    mainType = "zhounianqing_2021_lgxxw",
    level = 30,
    times = 2,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    needLevelTip = true,
    team = CHS[6400026],
    desc = CHS[7366794],
    reward = CHS[7366795],
    icon = "BigRewardIcon0022.png"
  }
}
