return {
  [CHS[6000485]] = {
    name = CHS[6000485],
    icon = 30006,
    zoon = {},
    polar = CHS[3001774],
    level_req = 1,
    life = 45,
    mana = 25,
    speed = 10,
    phy_attack = -40,
    mag_attack = 35,
    skills = {
      CHS[3000081],
      CHS[3001413],
      CHS[3001435]
    },
    price = 100,
    order = 1,
    artName = "ui/Icon0570.png",
    capacity_level = 2
  },
  [CHS[6000486]] = {
    name = CHS[6000486],
    icon = 30019,
    zoon = {},
    polar = CHS[3002409],
    level_req = 1,
    life = 45,
    mana = 25,
    speed = 20,
    phy_attack = -40,
    mag_attack = 25,
    skills = {
      CHS[3001434],
      CHS[3001584],
      CHS[3001585]
    },
    price = 100,
    order = 2,
    artName = "ui/Icon0566.png",
    capacity_level = 3
  },
  [CHS[6000487]] = {
    name = CHS[6000487],
    icon = 30003,
    zoon = {},
    polar = CHS[3001758],
    level_req = 1,
    life = 60,
    mana = 25,
    speed = 15,
    phy_attack = -40,
    mag_attack = 15,
    skills = {
      CHS[3001656],
      CHS[3001759],
      CHS[3001760]
    },
    price = 100,
    order = 3,
    artName = "ui/Icon0565.png",
    capacity_level = 4
  },
  [CHS[6000497]] = {
    name = CHS[6000497],
    icon = 30013,
    zoon = {},
    polar = CHS[3001758],
    level_req = 1,
    life = 50,
    mana = 25,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20,
    skills = {
      CHS[3001656],
      CHS[3001766],
      CHS[3001768]
    },
    price = 100,
    order = 4,
    artName = "ui/Icon0563.png",
    capacity_level = 4
  },
  [CHS[7333364]] = {
    name = CHS[7333364],
    icon = 30007,
    zoon = {},
    polar = CHS[3001758],
    level_req = 1,
    life = 45,
    mana = 25,
    speed = 10,
    phy_attack = -40,
    mag_attack = 35,
    skills = {
      CHS[4000170],
      CHS[3001413],
      CHS[4000179]
    },
    price = 100,
    order = 5,
    capacity_level = 5
  },
  [CHS[6000499]] = {
    name = CHS[6000499],
    icon = 30020,
    zoon = {},
    polar = CHS[34309],
    level_req = 1,
    life = 45,
    mana = 25,
    speed = 20,
    phy_attack = -40,
    mag_attack = 25,
    skills = {
      CHS[3001862],
      CHS[3001854],
      CHS[3001861]
    },
    price = 100,
    order = 6,
    artName = "ui/Icon0571.png",
    capacity_level = 5
  },
  [CHS[6000500]] = {
    name = CHS[6000500],
    icon = 30011,
    zoon = {},
    polar = CHS[3001774],
    level_req = 1,
    life = 50,
    mana = 25,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20,
    skills = {
      CHS[3003425],
      CHS[3004238],
      CHS[3004282]
    },
    price = 100,
    order = 7,
    artName = "ui/Icon0569.png",
    capacity_level = 5
  },
  [CHS[6000498]] = {
    name = CHS[6000498],
    icon = 30023,
    zoon = {},
    polar = CHS[3001774],
    level_req = 1,
    life = 55,
    mana = 25,
    speed = 5,
    phy_attack = -40,
    mag_attack = 30,
    skills = {
      CHS[3001775],
      CHS[3001855],
      CHS[3001859]
    },
    price = 100,
    order = 8,
    artName = "ui/Icon0568.png",
    capacity_level = 5
  },
  [CHS[6000501]] = {
    name = CHS[6000501],
    icon = 30010,
    zoon = {},
    polar = CHS[3002409],
    level_req = 1,
    life = 45,
    mana = 25,
    speed = 10,
    phy_attack = -40,
    mag_attack = 35,
    skills = {
      CHS[3001578],
      CHS[3001588],
      CHS[3001591]
    },
    price = 100,
    order = 9,
    artName = "ui/Icon0572.png",
    capacity_level = 6
  },
  [CHS[6000521]] = {
    name = CHS[6000521],
    icon = 30001,
    zoon = {},
    polar = CHS[3001774],
    level_req = 1,
    life = 60,
    mana = 25,
    speed = 15,
    phy_attack = -40,
    mag_attack = 15,
    skills = {
      CHS[3004290],
      CHS[3004316],
      CHS[3001453]
    },
    price = 100,
    order = 10,
    artName = "ui/Icon0564.png",
    capacity_level = 6
  },
  [CHS[6000502]] = {
    name = CHS[6000502],
    icon = 30021,
    zoon = {},
    polar = CHS[34310],
    level_req = 1,
    life = 55,
    mana = 25,
    speed = 5,
    phy_attack = -40,
    mag_attack = 30,
    skills = {
      CHS[3001650],
      CHS[3001764],
      CHS[3001768]
    },
    price = 100,
    order = 11,
    artName = "ui/Icon0562.png",
    capacity_level = 6
  },
  [CHS[2000546]] = {
    name = CHS[2000546],
    icon = 30026,
    zoon = {},
    polar = CHS[34310],
    level_req = 1,
    life = 55,
    mana = 20,
    speed = 10,
    phy_attack = -40,
    mag_attack = 30,
    skills = {
      CHS[3001650],
      CHS[3001453],
      CHS[3001854]
    },
    price = 100,
    order = 12,
    artName = "ui/Icon2358.png",
    capacity_level = 6
  },
  [CHS[6000503]] = {
    name = CHS[6000503],
    icon = 30025,
    zoon = {},
    polar = CHS[3002409],
    level_req = 1,
    life = 55,
    mana = 25,
    speed = 5,
    phy_attack = -40,
    mag_attack = 30,
    skills = {
      CHS[3001788],
      CHS[3001855],
      CHS[3001768]
    },
    price = 100,
    order = 13,
    artName = "ui/Icon0567.png",
    capacity_level = 8
  },
  [CHS[2000547]] = {
    name = CHS[2000547],
    icon = 30029,
    zoon = {},
    polar = CHS[2000548],
    level_req = 1,
    life = 60,
    mana = 0,
    speed = 0,
    phy_attack = 55,
    mag_attack = -40,
    skills = {
      CHS[3004238],
      CHS[3001855],
      CHS[3001591]
    },
    price = 100,
    order = 14,
    artName = "ui/Icon2359.png",
    capacity_level = 8
  },
  [CHS[4102086]] = {
    name = CHS[4102086],
    icon = 30538,
    zoon = {},
    polar = CHS[3002409],
    level_req = 1,
    life = 55,
    mana = 25,
    speed = 5,
    phy_attack = -40,
    mag_attack = 30,
    skills = {
      CHS[3001788],
      CHS[3001855],
      CHS[3001768]
    },
    price = 100,
    order = 15,
    artName = "ui/Icon0567.png",
    capacity_level = 9,
    gray_zhjg = 1,
    canNotSummon = 1
  }
}
