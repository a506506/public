return {
  ["xue"] = {
    name = "xue",
    icon = 3,
    xSpeed = -1,
    ySpeed = -2
  },
  ["yu"] = {
    name = "yu",
    icon = 5,
    xSpeed = -5,
    ySpeed = -40,
    blendMode = {
      org = gl.ONE,
      tar = gl.ONE
    },
    bgColor = cc.c4b(0, 0, 0, 76)
  },
  [19002] = "xue",
  [18001] = "xue"
}
