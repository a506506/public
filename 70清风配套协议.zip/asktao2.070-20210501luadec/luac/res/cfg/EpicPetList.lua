return {
  [CHS[7190025]] = {
    name = CHS[7190025],
    icon = 6189,
    zoon = {},
    polar = CHS[3001385],
    level_req = 1,
    life = 55,
    mana = -35,
    speed = 30,
    phy_attack = 100,
    mag_attack = -40,
    skills = {
      CHS[3000071],
      CHS[3000073],
      CHS[3000079]
    },
    price = 100,
    order = 1,
    artName = "ui/Icon1270.png"
  },
  [CHS[7190026]] = {
    name = CHS[7190026],
    icon = 6190,
    zoon = {},
    polar = CHS[3001383],
    level_req = 1,
    life = 65,
    mana = 20,
    speed = 35,
    phy_attack = -50,
    mag_attack = 40,
    skills = {
      CHS[3000075],
      CHS[3000072],
      CHS[3000078]
    },
    price = 100,
    order = 2,
    artName = "ui/Icon1269.png"
  },
  [CHS[7190027]] = {
    name = CHS[7190027],
    icon = 6191,
    zoon = {},
    polar = CHS[3001383],
    level_req = 1,
    life = 80,
    mana = 30,
    speed = 20,
    phy_attack = -50,
    mag_attack = 30,
    skills = {
      CHS[3000071],
      CHS[3000075],
      CHS[3000078]
    },
    price = 100,
    order = 3,
    artName = "ui/Icon1271.png"
  },
  [CHS[7190028]] = {
    name = CHS[7190028],
    icon = 6192,
    zoon = {},
    polar = CHS[3001417],
    level_req = 1,
    life = 55,
    mana = 20,
    speed = 40,
    phy_attack = -50,
    mag_attack = 45,
    skills = {
      CHS[3000072],
      CHS[3000074],
      CHS[3000079]
    },
    price = 100,
    order = 4,
    artName = "ui/Icon1272.png"
  },
  [CHS[7120179]] = {
    name = CHS[7120179],
    icon = 6176,
    zoon = {},
    polar = CHS[3001787],
    level_req = 1,
    life = 55,
    mana = 25,
    speed = 45,
    phy_attack = -50,
    mag_attack = 35,
    skills = {
      CHS[3000071],
      CHS[3000074],
      CHS[3001768]
    },
    price = 100,
    order = 5,
    artName = "ui/Icon2568.png"
  },
  [CHS[7120180]] = {
    name = CHS[7120180],
    icon = 6193,
    zoon = {},
    polar = CHS[3001770],
    level_req = 1,
    life = 75,
    mana = 20,
    speed = 40,
    phy_attack = -50,
    mag_attack = 25,
    skills = {
      CHS[3001771],
      CHS[3001785],
      CHS[3000079]
    },
    price = 100,
    order = 6,
    artName = "ui/Icon2569.png"
  },
  [CHS[5420698]] = {
    name = CHS[5420698],
    icon = 31062,
    zoon = {},
    polar = CHS[3001774],
    level_req = 1,
    life = 55,
    mana = 25,
    speed = 30,
    phy_attack = -50,
    mag_attack = 50,
    skills = {
      CHS[3001780],
      CHS[3001766],
      CHS[3001765]
    },
    price = 100,
    order = 7,
    artName = "ui/Icon2569.png"
  },
  [CHS[5420699]] = {
    name = CHS[5420699],
    icon = 6194,
    zoon = {},
    polar = CHS[3001763],
    level_req = 1,
    life = 55,
    mana = -35,
    speed = 40,
    phy_attack = 90,
    mag_attack = -40,
    skills = {
      CHS[3001785],
      CHS[3001764],
      CHS[3001765]
    },
    price = 100,
    order = 8,
    artName = "ui/Icon2569.png"
  }
}
