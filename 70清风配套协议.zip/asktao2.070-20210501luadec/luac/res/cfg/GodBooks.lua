return {
  [CHS[3001605]] = {
    name = CHS[3001605],
    skill_no = 350,
    skill_icon = 9201
  },
  [CHS[3001606]] = {
    name = CHS[3001606],
    skill_no = 351,
    skill_icon = 9202
  },
  [CHS[3001607]] = {
    name = CHS[3001607],
    skill_no = 352,
    skill_icon = 9204
  },
  [CHS[3001608]] = {
    name = CHS[3001608],
    skill_no = 353,
    skill_icon = 9206
  },
  [CHS[3001609]] = {
    name = CHS[3001609],
    skill_no = 354,
    skill_icon = 9207
  },
  [CHS[3001610]] = {
    name = CHS[3001610],
    skill_no = 355,
    skill_icon = 9205
  },
  [CHS[3001611]] = {
    name = CHS[3001611],
    skill_no = 356,
    skill_icon = 9209
  },
  [CHS[3001612]] = {
    name = CHS[3001612],
    skill_no = 357,
    skill_icon = 9210
  },
  [CHS[3001613]] = {
    name = CHS[3001613],
    skill_no = 358,
    skill_icon = 9208
  },
  [CHS[3001614]] = {
    name = CHS[3001614],
    skill_no = 359,
    skill_icon = 9203
  },
  [CHS[3001615]] = {
    name = CHS[3001615],
    skill_no = 360,
    skill_icon = 9211
  },
  [CHS[3001616]] = {
    name = CHS[3001616],
    skill_no = 361,
    skill_icon = 9212
  },
  [CHS[3001617]] = {
    name = CHS[3001617],
    skill_no = 362,
    skill_icon = 9213
  },
  [CHS[3001618]] = {
    name = CHS[3001618],
    skill_no = 363,
    skill_icon = 9214
  },
  [CHS[3001619]] = {
    name = CHS[3001619],
    skill_no = 364,
    skill_icon = 9215
  }
}
