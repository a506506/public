return {
  all_attrib = {
    key = "all_attrib",
    order = 1,
    is_rare = 1,
    is_percent = 0,
    prop_max = 120,
    prop_name = "所有属性"
  },
  enhanced_phy = {
    key = "enhanced_phy",
    order = 2,
    is_rare = 1,
    is_percent = 1,
    prop_max = 10,
    prop_name = "强物理伤害"
  },
  enhanced_mag = {
    key = "enhanced_mag",
    order = 3,
    is_rare = 1,
    is_percent = 1,
    prop_max = 10,
    prop_name = "强法术伤害"
  },
  stunt_rate = {
    key = "stunt_rate",
    order = 4,
    is_rare = 1,
    is_percent = 1,
    prop_max = 10,
    prop_name = "物理必杀率"
  },
  mstunt_rate = {
    key = "mstunt_rate",
    order = 5,
    is_rare = 1,
    is_percent = 1,
    prop_max = 10,
    prop_name = "法术必杀率"
  },
  dodge = {
    key = "dodge",
    order = 6,
    is_rare = 1,
    is_percent = 1,
    prop_max = 10,
    prop_name = "几率躲避攻击"
  },
  relive_rate = {
    key = "relive_rate",
    order = 7,
    is_rare = 1,
    is_percent = 1,
    prop_max = 10,
    prop_name = "复活率"
  },
  max_life = {
    key = "max_life",
    order = 8,
    is_rare = 0,
    is_percent = 0,
    prop_max = 21600,
    prop_name = "气血"
  },
  def = {
    key = "def",
    order = 9,
    is_rare = 0,
    is_percent = 0,
    prop_max = 10800,
    prop_name = "防御"
  },
  phy_power = {
    key = "phy_power",
    order = 10,
    is_rare = 0,
    is_percent = 0,
    prop_max = 10800,
    prop_name = "物伤"
  },
  mag_power = {
    key = "mag_power",
    order = 11,
    is_rare = 0,
    is_percent = 0,
    prop_max = 10800,
    prop_name = "法伤"
  },
  speed = {
    key = "speed",
    order = 12,
    is_rare = 0,
    is_percent = 0,
    prop_max = 2160,
    prop_name = "速度"
  },
  reduce_mag = {
    key = "reduce_mag",
    order = 13,
    is_rare = 0,
    is_percent = 1,
    prop_max = 10,
    prop_name = "法伤减免"
  },
  reduce_phy = {
    key = "reduce_phy",
    order = 14,
    is_rare = 0,
    is_percent = 1,
    prop_max = 10,
    prop_name = "物伤减免"
  },
  counter_attack_rate = {
    key = "counter_attack_rate",
    order = 15,
    is_rare = 0,
    is_percent = 1,
    prop_max = 30,
    prop_name = "反击率"
  },
  counter_attack = {
    key = "counter_attack",
    order = 16,
    is_rare = 0,
    is_percent = 0,
    prop_max = 10,
    prop_name = "反击次数"
  },
  damage_sel_rate = {
    key = "damage_sel_rate",
    order = 17,
    is_rare = 0,
    is_percent = 1,
    prop_max = 30,
    prop_name = "反震率"
  },
  damage_sel = {
    key = "damage_sel",
    order = 18,
    is_rare = 0,
    is_percent = 0,
    prop_max = 30,
    prop_name = "反震度"
  },
  accurate = {
    key = "accurate",
    order = 19,
    is_rare = 0,
    is_percent = 1,
    prop_max = 10,
    prop_name = "准确"
  },
  ignore_relive_rate = {
    key = "ignore_relive_rate",
    order = 20,
    is_rare = 0,
    is_percent = 1,
    prop_max = 10,
    prop_name = "忽视目标复活"
  },
  suck_blood_rate = {
    key = "suck_blood_rate",
    order = 21,
    is_rare = 0,
    is_percent = 1,
    prop_max = 10,
    prop_name = "吸血率"
  },
  ignore_suck_blood_rate = {
    key = "ignore_suck_blood_rate",
    order = 22,
    is_rare = 0,
    is_percent = 1,
    prop_max = 10,
    prop_name = "抗吸血"
  },
  penetrate_rate = {
    key = "penetrate_rate",
    order = 23,
    is_rare = 0,
    is_percent = 1,
    prop_max = 30,
    prop_name = "破防率"
  },
  penetrate = {
    key = "penetrate",
    order = 24,
    is_rare = 0,
    is_percent = 1,
    prop_max = 30,
    prop_name = "破防"
  }
}
