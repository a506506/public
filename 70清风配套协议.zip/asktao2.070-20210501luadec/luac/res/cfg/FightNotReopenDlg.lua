return {GMCombatlogDlg = 1, WatchCentreDlg = 1}
