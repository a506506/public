return {
  [20122] = {
    clickRect = {
      x = 248,
      y = 81,
      height = 258,
      width = 122
    },
    fixDir = 5
  },
  [51501] = {
    fixDir = 5,
    nameOffset = {x = 0, y = -40},
    clickRect = {
      x = 60,
      y = 20,
      height = 190,
      width = 200
    }
  },
  [51508] = {
    fixDir = 5,
    nameOffset = {x = 15, y = -40}
  },
  [6274] = {
    fixDir = 3,
    clickRect = {
      x = 99,
      y = 52,
      height = 220,
      width = 170
    }
  },
  [51502] = {
    ["48"] = {
      fixDir = 5,
      nameOffset = {x = -18, y = 0}
    }
  },
  [51500] = {
    ["48"] = {
      fixDir = 5,
      nameOffset = {x = 18, y = 0}
    }
  },
  [20015] = {fixDir = 5},
  [6310] = {
    clickRect = {
      x = 235,
      y = 148,
      height = 180,
      width = 180
    }
  },
  [6139] = {
    clickRect = {
      x = 145,
      y = 57,
      height = 134,
      width = 42
    }
  },
  [20121] = {
    fixDir = 5,
    clickRect = {
      x = 96,
      y = 48,
      height = 216,
      width = 240
    },
    opacityNotObstacle = 127
  },
  [31501] = {
    clickRect = {
      x = 344,
      y = 334,
      height = 168,
      width = 176
    }
  },
  [52060] = {fixDir = 5, notShowShadow = true},
  [20123] = {
    fixDir = 5,
    clickRect = {
      x = 80,
      y = 48,
      height = 216,
      width = 140
    },
    opacityNotObstacle = 127
  },
  [31026] = {
    showMountTime = 30,
    showMountIcons = {
      31026,
      31027,
      31028
    }
  },
  [4001] = {
    nameOffset = {x = 0, y = 90},
    weaponBlendMode = {
      [1406] = "add"
    }
  },
  [4002] = {
    nameOffset = {x = 0, y = 90},
    weaponBlendMode = {
      [1406] = "add"
    }
  },
  [51540] = {fixDir = 5},
  [50115] = {fixDir = 5},
  [50116] = {fixDir = 5},
  [50117] = {fixDir = 5},
  [20125] = {
    fixDir = 5,
    clickRect = {
      x = 100,
      y = 80,
      height = 160,
      width = 184
    },
    opacityNotObstacle = 127
  },
  [20124] = {
    fixDir = 5,
    clickRect = {
      x = 77,
      y = 84,
      height = 260,
      width = 231
    },
    opacityNotObstacle = 127
  },
  [6610] = {
    clickRect = {
      x = 375,
      y = 290,
      height = 280,
      width = 160
    }
  },
  [20121] = {
    clickRect = {
      x = 40,
      y = 30,
      height = 320,
      width = 260
    }
  },
  [6603] = {
    clickRect = {
      x = 280,
      y = 220,
      height = 320,
      width = 260
    }
  },
  [6604] = {
    clickRect = {
      x = 330,
      y = 337,
      height = 340,
      width = 260
    }
  },
  [6605] = {
    clickRect = {
      x = 180,
      y = 230,
      height = 300,
      width = 300
    }
  },
  [6510] = {
    clickRect = {
      x = 300,
      y = 220,
      height = 300,
      width = 280
    }
  },
  [51534] = {
    icon = 2050,
    actName = "Top01",
    armatureType = ARMATURE_TYPE.ARMATURE_UI,
    offY = 50
  },
  [21029] = {
    actionFixDir = {
      [Const.SA_QINQIN] = {fixDir = 5, flip = false},
      [Const.SA_JIAOBEI] = {fixDir = 5, flip = false},
      [Const.SA_YONGBAO] = {fixDir = 5, flip = false}
    }
  },
  [6730] = {
    nameOffset = {x = -50, y = 0},
    footOffset = cc.p(-50, 0)
  },
  [6740] = {
    nameOffset = {x = -50, y = 0},
    footOffset = cc.p(-50, 0)
  },
  [6750] = {
    nameOffset = {x = -50, y = 0},
    footOffset = cc.p(-50, 0)
  }
}
