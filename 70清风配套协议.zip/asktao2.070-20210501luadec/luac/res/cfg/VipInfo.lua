return {
  [CHS[3001789]] = {
    days = 30,
    price = 30,
    rebateMoney = 300,
    rebateEveryDay = 100,
    totalRebate = 3000,
    level = CHS[3001790],
    iosReviewLevel = CHS[3001791]
  },
  [CHS[3001792]] = {
    days = 90,
    price = 90,
    rebateMoney = 900,
    rebateEveryDay = 120,
    totalRebate = 10800,
    level = CHS[3001793],
    iosReviewLevel = CHS[3001794]
  },
  [CHS[3001795]] = {
    days = 360,
    price = 360,
    rebateMoney = 3600,
    rebateEveryDay = 150,
    totalRebate = 54000,
    level = CHS[3001796],
    iosReviewLevel = CHS[3001797]
  }
}
