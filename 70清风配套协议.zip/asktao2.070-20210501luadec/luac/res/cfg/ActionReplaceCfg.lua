return {
  [51536] = {
    icon = 51531,
    replaceAct = {cry = 1}
  },
  [51535] = {
    icon = 51530,
    replaceAct = {cry = 1}
  }
}
