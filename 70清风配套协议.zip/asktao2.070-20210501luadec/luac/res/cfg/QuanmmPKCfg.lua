return {
  ["100级装备基本信息"] = {
    [1] = {
      [1] = {
        name = "风火游龙枪",
        icon = 1162
      },
      [2] = {name = "啼血爪", icon = 1155},
      [3] = {
        name = "乙木神剑",
        icon = 1133
      },
      [4] = {
        name = "五彩神焰扇",
        icon = 1157
      },
      [5] = {name = "加持杵", icon = 1122}
    },
    [2] = {
      [1] = {
        name = "九霄烈焰冠",
        icon = 1211
      },
      [2] = {
        name = "九霄凤鸣冠",
        icon = 1615
      }
    },
    [3] = {
      [1] = {name = "天衣", icon = 1232},
      [2] = {
        name = "霓裳羽衣",
        icon = 1243
      }
    },
    [4] = {
      name = "金碧莲花",
      icon = 1308
    },
    [5] = {
      name = "通灵宝玉",
      icon = 1316
    },
    [6] = {
      name = "天星奇光",
      icon = 1324
    },
    [10] = {name = "踏云靴", icon = 1254}
  },
  ["120级装备基本信息"] = {
    [1] = {
      [1] = {
        name = "混元斩龙戟",
        icon = 1144
      },
      [2] = {
        name = "镇魂摄天刺",
        icon = 1164
      },
      [3] = {
        name = "封神诛仙剑",
        icon = 1161
      },
      [4] = {
        name = "赤霄烈焰扇",
        icon = 1156
      },
      [5] = {
        name = "风雷如意杵",
        icon = 1159
      }
    },
    [2] = {
      [1] = {
        name = "七星宝冠",
        icon = 1256
      },
      [2] = {
        name = "天灵宝冠",
        icon = 1258
      }
    },
    [3] = {
      [1] = {
        name = "诸天法袍",
        icon = 1260
      },
      [2] = {
        name = "神鸢凤裘",
        icon = 1262
      }
    },
    [4] = {
      name = "五蕴悯光",
      icon = 1326
    },
    [5] = {
      name = "八宝如意",
      icon = 1328
    },
    [6] = {
      name = "九天霜华",
      icon = 1330
    },
    [10] = {name = "钧天履", icon = 1264}
  },
  ["130级装备基本信息"] = {
    [1] = {
      [1] = {
        name = "赤眼神龙枪",
        icon = 1168
      },
      [2] = {
        name = "红绫火毒爪",
        icon = 1166
      },
      [3] = {
        name = "九天玄冥剑",
        icon = 1169
      },
      [4] = {
        name = "红云火霞扇",
        icon = 1167
      },
      [5] = {
        name = "玄黄破坚锤",
        icon = 1170
      }
    },
    [2] = {
      [1] = {
        name = "白玉星冠",
        icon = 1266
      },
      [2] = {
        name = "九彩玲珠冠",
        icon = 1265
      }
    },
    [3] = {
      [1] = {
        name = "天玄真神甲",
        icon = 1267
      },
      [2] = {
        name = "万霞霓罗裳",
        icon = 1268
      }
    },
    [4] = {
      name = "千彩流光",
      icon = 1332
    },
    [5] = {
      name = "游火灵焰",
      icon = 1331
    },
    [6] = {
      name = "岚金火链",
      icon = 1333
    },
    [10] = {name = "雷弧闪", icon = 1269}
  },
  ["推荐装备属性"] = {
    [1] = {
      MagTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "金相性",
        blue3 = "伤害",
        pink = "所有相性",
        yellow = "伤害",
        green = "强polar法伤害",
        black = "法伤",
        gongming = "法术必杀率"
      },
      PhyTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "土相性",
        blue3 = "伤害",
        pink = "所有相性",
        yellow = "伤害",
        green = "强物理伤害",
        black = "物伤",
        gongming = "物理必杀率"
      },
      SpeedTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "火相性",
        blue3 = "敏捷",
        pink = "所有相性",
        yellow = "火相性",
        green = "强力XX",
        black = "速度",
        gongming = "敏捷"
      },
      DefTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "木相性",
        blue3 = "体质",
        pink = "所有相性",
        yellow = "木相性",
        green = "强力XX",
        black = "防御",
        gongming = "体质"
      },
      ObstacleTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "所有技能上升",
        blue3 = "忽视所有抗异常",
        pink = "所有技能上升",
        yellow = "忽视所有抗异常",
        green = "强力XX",
        black = "速度",
        gongming = "忽视目标抗XX"
      }
    },
    [2] = {
      MagTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "灵力",
        blue3 = "敏捷",
        pink = "所有属性",
        yellow = "灵力",
        green = "法攻技能消耗降低",
        black = "法伤",
        gongming = "法术必杀率"
      },
      PhyTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "力量",
        blue3 = "敏捷",
        pink = "所有属性",
        yellow = "力量",
        green = "辅助技能消耗降低",
        black = "物伤",
        gongming = "物理必杀率"
      },
      SpeedTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "灵力",
        blue3 = "敏捷",
        pink = "所有属性",
        yellow = "敏捷",
        green = "辅助技能消耗降低",
        black = "速度",
        gongming = "敏捷"
      },
      DefTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "体质",
        blue3 = "防御",
        pink = "所有属性",
        yellow = "体质",
        green = "辅助技能消耗降低",
        black = "防御",
        gongming = "体质"
      },
      ObstacleTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "灵力",
        blue3 = "敏捷",
        pink = "所有属性",
        yellow = "敏捷",
        green = "障碍技能消耗降低",
        black = "速度",
        gongming = "忽视目标抗XX"
      }
    },
    [3] = {
      MagTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "灵力",
        blue3 = "敏捷",
        pink = "所有属性",
        yellow = "灵力",
        green = "抗XX",
        black = "法伤",
        gongming = "法术必杀率"
      },
      PhyTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "力量",
        blue3 = "敏捷",
        pink = "所有属性",
        yellow = "力量",
        green = "抗XX",
        black = "物伤",
        gongming = "物理必杀率"
      },
      SpeedTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "灵力",
        blue3 = "敏捷",
        pink = "所有属性",
        yellow = "敏捷",
        green = "抗XX",
        black = "速度",
        gongming = "敏捷"
      },
      DefTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "体质",
        blue3 = "防御",
        pink = "所有属性",
        yellow = "体质",
        green = "抗XX",
        black = "防御",
        gongming = "体质"
      },
      ObstacleTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "灵力",
        blue3 = "敏捷",
        pink = "所有属性",
        yellow = "敏捷",
        green = "抗XX",
        black = "速度",
        gongming = "忽视目标抗XX"
      }
    },
    [10] = {
      MagTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "灵力",
        blue3 = "速度",
        pink = "所有属性",
        yellow = "灵力",
        green = "几率躲避攻击",
        black = "法伤",
        gongming = "法术必杀率"
      },
      PhyTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "力量",
        blue3 = "速度",
        pink = "所有属性",
        yellow = "力量",
        green = "几率躲避攻击",
        black = "物伤",
        gongming = "物理必杀率"
      },
      SpeedTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "敏捷",
        blue3 = "速度",
        pink = "速度",
        yellow = "敏捷",
        green = "几率躲避攻击",
        black = "速度",
        gongming = "敏捷"
      },
      DefTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "体质",
        blue3 = "防御",
        pink = "所有属性",
        yellow = "体质",
        green = "几率躲避攻击",
        black = "防御",
        gongming = "体质"
      },
      ObstacleTypeCheckBox = {
        blue1 = "所有属性",
        blue2 = "敏捷",
        blue3 = "速度",
        pink = "速度",
        yellow = "敏捷",
        green = "几率躲避攻击",
        black = "速度",
        gongming = "忽视目标抗XX"
      }
    },
    [4] = {
      MagTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "灵力",
        blue3 = "灵力",
        blue4 = "敏捷",
        blue5 = "敏捷",
        blue6 = "所有技能上升"
      },
      PhyTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "力量",
        blue3 = "力量",
        blue4 = "敏捷",
        blue5 = "敏捷",
        blue6 = "所有技能上升"
      },
      SpeedTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "敏捷",
        blue3 = "敏捷",
        blue4 = "所有技能上升",
        blue5 = "所有抗异常",
        blue6 = "灵力"
      },
      DefTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "体质",
        blue3 = "体质",
        blue4 = "所有技能上升",
        blue5 = "所有抗异常",
        blue6 = "灵力"
      },
      ObstacleTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "所有抗异常",
        blue3 = "所有技能上升",
        blue4 = "敏捷",
        blue5 = "敏捷",
        blue6 = "灵力"
      }
    },
    [5] = {
      MagTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "灵力",
        blue3 = "灵力",
        blue4 = "敏捷",
        blue5 = "敏捷",
        blue6 = "所有技能上升"
      },
      PhyTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "力量",
        blue3 = "力量",
        blue4 = "敏捷",
        blue5 = "敏捷",
        blue6 = "所有技能上升"
      },
      SpeedTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "敏捷",
        blue3 = "敏捷",
        blue4 = "所有技能上升",
        blue5 = "所有抗异常",
        blue6 = "灵力"
      },
      DefTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "体质",
        blue3 = "体质",
        blue4 = "所有技能上升",
        blue5 = "所有抗异常",
        blue6 = "灵力"
      },
      ObstacleTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "所有抗异常",
        blue3 = "所有技能上升",
        blue4 = "敏捷",
        blue5 = "敏捷",
        blue6 = "灵力"
      }
    },
    [6] = {
      MagTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "灵力",
        blue3 = "灵力",
        blue4 = "敏捷",
        blue5 = "敏捷",
        blue6 = "所有技能上升"
      },
      PhyTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "力量",
        blue3 = "力量",
        blue4 = "敏捷",
        blue5 = "敏捷",
        blue6 = "所有技能上升"
      },
      SpeedTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "敏捷",
        blue3 = "敏捷",
        blue4 = "忽视目标抗XX",
        blue5 = "忽视目标抗XX",
        blue6 = "所有技能上升"
      },
      DefTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "体质",
        blue3 = "体质",
        blue4 = "所有技能上升",
        blue5 = "灵力",
        blue6 = "灵力"
      },
      ObstacleTypeCheckBox = {
        blue1 = "所有相性",
        blue2 = "忽视目标抗XX",
        blue3 = "忽视目标抗XX",
        blue4 = "所有技能上升",
        blue5 = "忽视所有抗异常",
        blue6 = "敏捷"
      }
    },
    [8] = {
      PhyTypeCheckBox = {
        name = "魂器·伏虎",
        yanAtt1 = "物伤",
        yinAtt1 = "所有抗异常",
        yanAtt2 = "物伤",
        yinAtt2 = "所有抗异常",
        yanAtt3 = "力量",
        yinAtt3 = "所有抗性"
      },
      MagTypeCheckBox = {
        name = "魂器·灵咒",
        yanAtt1 = "法伤",
        yinAtt1 = "所有抗异常",
        yanAtt2 = "法伤",
        yinAtt2 = "所有抗异常",
        yanAtt3 = "灵力",
        yinAtt3 = "所有抗性"
      },
      SpeedTypeCheckBox = {
        name = "魂器·润泽",
        yanAtt1 = "速度",
        yinAtt1 = "所有抗异常",
        yanAtt2 = "速度",
        yinAtt2 = "所有抗异常",
        yanAtt3 = "敏捷",
        yinAtt3 = "所有抗性"
      },
      DefTypeCheckBox = {
        name = "魂器·薄暮",
        yanAtt1 = "速度",
        yinAtt1 = "防御",
        yanAtt2 = "速度",
        yinAtt2 = "防御",
        yanAtt3 = "敏捷",
        yinAtt3 = "体质"
      },
      ObstacleTypeCheckBox = {
        name = "魂器·润泽",
        yanAtt1 = "忽视目标抗XX",
        yinAtt1 = "所有抗异常",
        yanAtt2 = "忽视目标抗XX",
        yinAtt2 = "所有抗异常",
        yanAtt3 = "忽视所有抗异常",
        yinAtt3 = "所有抗性"
      }
    },
    [9] = {
      PhyTypeCheckBox = {
        name = "混元金斗",
        polar = 5,
        skill = "亲密无间"
      },
      MagTypeCheckBox = {
        name = "番天印",
        polar = 1,
        skill = "亲密无间"
      },
      SpeedTypeCheckBox = {
        name = "阴阳镜",
        polar = 4,
        skill = "颠倒乾坤"
      },
      DefTypeCheckBox = {
        name = "定海珠",
        polar = 3,
        skill = "嘲讽"
      },
      ObstacleTypeCheckBox = {
        name = "九龙神火罩",
        polar = 4,
        skill = "物极必反"
      }
    }
  },
  ["角色配置"] = {
    [1] = {
      attrib = "三力一敏",
      polar = "土相＞火相＞水相",
      spirit = 2,
      xianmo = "魔道点",
      attribToServer = "0;0;3;1",
      polarToServer = "5;4;3;0;0"
    },
    [2] = {
      attrib = "三灵一敏",
      polar = "金相＞X相＞火相＞木相",
      spirit = 1,
      xianmo = "魔道点",
      attribToServer = "0;3;0;1",
      polarToServer = "1;X;4;2;0"
    },
    [3] = {
      attrib = "全敏",
      polar = "火相＞木相＞水相",
      spirit = 3,
      xianmo = "仙道点",
      attribToServer = "0;0;0;4",
      polarToServer = "4;2;3;0;0"
    },
    [4] = {
      attrib = "全体",
      polar = "木相＞水相＞火相",
      spirit = 4,
      xianmo = "仙道点",
      attribToServer = "4;0;0;0",
      polarToServer = "2;3;4;0;0"
    },
    [5] = {
      attrib = "全敏",
      polar = "火相＞木相＞水相",
      spirit = 3,
      xianmo = "仙道点",
      attribToServer = "0;0;0;4",
      polarToServer = "4;2;3;0;0"
    }
  },
  ["宠物配置"] = {
    [1] = {
      attrib = "三力一敏",
      resist = "抗中毒＞抗冰冻＞抗昏睡＞抗混乱",
      spirit = 2,
      dunwuSkills = {
        "养精蓄锐"
      },
      godBook = {
        "狂暴",
        "魔引",
        "破天"
      },
      stone = {
        "枯月流魂",
        "炫影霜星",
        "凝香幻彩"
      },
      attribToServer = "0;0;3;1",
      resistToServer = "7;8;9;10",
      stoneToServer = "kylh|xysx|nxhc",
      godBookToServer = "kuangbao|moyin|potian"
    },
    [2] = {
      attrib = "三灵一敏",
      resist = "抗冰冻＞抗昏睡＞抗遗忘＞抗混乱",
      spirit = 1,
      dunwuSkills = {
        "养精蓄锐"
      },
      godBook = {
        "修罗术",
        "魔引",
        "怒击"
      },
      stone = {
        "雷极弧光",
        "炫影霜星",
        "凝香幻彩"
      },
      attribToServer = "0;3;0;1",
      resistToServer = "8;9;6;10",
      stoneToServer = "ljhg|xysx|nxhc",
      godBookToServer = "xiuluoshu|moyin|nuji"
    },
    [3] = {
      attrib = "全敏",
      resist = "抗冰冻＞抗遗忘＞抗混乱＞抗中毒",
      spirit = 3,
      dunwuSkills = {
        "闻风丧胆"
      },
      godBook = {
        "云体",
        "仙风",
        "尽忠"
      },
      stone = {
        "炫影霜星",
        "风寂云清",
        "凝香幻彩"
      },
      attribToServer = "0;0;0;4",
      resistToServer = "8;6;10;7",
      stoneToServer = "xysx|fjyq|nxhc",
      godBookToServer = "yunti|xianfeng|jinzhong"
    },
    [4] = {
      attrib = "全体",
      resist = "抗冰冻＞抗遗忘＞抗混乱＞抗中毒",
      spirit = 4,
      dunwuSkills = {
        "闻风丧胆"
      },
      godBook = {
        "云体",
        "仙风",
        "尽忠"
      },
      stone = {
        "炫影霜星",
        "风寂云清",
        "凝香幻彩"
      },
      attribToServer = "4;0;0;0",
      resistToServer = "8;6;10;7",
      stoneToServer = "xysx|fjyq|nxhc",
      godBookToServer = "yunti|xianfeng|jinzhong"
    }
  },
  ["法宝种类"] = {
    "定海珠",
    "混元金斗",
    "金蛟剪",
    "阴阳镜",
    "卸甲金葫",
    "九龙神火罩",
    "番天印"
  },
  ["法宝技能"] = {
    "颠倒乾坤",
    "金刚圈",
    "物极必反",
    "天眼",
    "嘲讽",
    "亲密无间"
  },
  ["法宝相性"] = {
    "金",
    "木",
    "水",
    "火",
    "土"
  },
  ["顿悟技能"] = {
    "缓兵之计",
    "束手就擒",
    "闻风丧胆",
    "哀痛欲绝",
    "养精蓄锐",
    "翻转乾坤",
    "神圣之光",
    "如意圈",
    "游说之舌",
    "漫天血舞",
    "舍命一击",
    "乾坤罩",
    "神龙罩",
    "死亡缠绵",
    polar = {
      [1] = "天生神力",
      [2] = "拔苗助长",
      [3] = "防微杜渐",
      [4] = "十万火急",
      [5] = "鞭长莫及"
    }
  },
  ["妖     石"] = {
    "凝香幻彩",
    "枯月流魂",
    "风寂云清",
    "炫影霜星",
    "雷极弧光",
    "冰落残阳"
  },
  ["变     身"] = {
    "九曲玲珑笔",
    "超级伶俐鼠卡",
    "超级笨笨牛卡",
    "超级威威虎卡",
    "超级跳跳兔卡",
    "超级酷酷龙卡",
    "超级花花蛇卡",
    "超级溜溜马卡",
    "超级咩咩羊卡",
    "超级帅帅猴卡",
    "超级蛋蛋鸡卡",
    "超级乖乖狗卡",
    "超级招财猪卡"
  },
  ["变     身2"] = {
    "九曲玲珑笔",
    "超级疆良卡",
    "超级东山神灵卡",
    "超级玄武卡",
    "超级朱雀卡",
    "超级九尾狐卡",
    "超级白矖卡"
  },
  ["药     品"] = {"血玲珑", "法玲珑"},
  ["法宝技能编号"] = {
    ["颠倒乾坤"] = 1,
    ["金刚圈"] = 2,
    ["物极必反"] = 3,
    ["天眼"] = 4,
    ["嘲讽"] = 5,
    ["亲密无间"] = 6
  }
}
