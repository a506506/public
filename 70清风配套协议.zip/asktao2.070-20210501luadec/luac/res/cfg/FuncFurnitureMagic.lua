return {
  [CHS[7190000]] = {
    icon = 10027,
    isDragonBones = true,
    offsetX = 0,
    offsetY = 0,
    armatureName = "armatureName",
    needHideImage = 1,
    flipX = 8,
    flipY = -3,
    flipAction = "10027_5",
    notFlipX = -8,
    notFlipY = -3,
    notFlipAction = "10027_7",
    time = -1
  },
  [CHS[7190001]] = {
    icon = 1216,
    isDragonBones = false,
    offsetX = 0,
    offsetY = 0,
    flipAction = "Bottom02",
    notFlipAction = "Bottom01"
  },
  [CHS[7190002]] = {
    icon = 1217,
    isDragonBones = false,
    offsetX = 0,
    offsetY = 0,
    flipAction = "Bottom02",
    notFlipAction = "Bottom01"
  },
  ["天地灵石"] = {
    icon = 2050,
    isDragonBones = false,
    flipAction = "Top02",
    notFlipAction = "Top01",
    isAlwaysShowMaigc = true,
    needHideImage = 1
  },
  ["摇篮"] = {
    icon = 2047,
    isDragonBones = true,
    offsetX = 0,
    offsetY = 0,
    armatureName = "02047",
    needHideImage = 1,
    flipAction = "stand_3",
    notFlipAction = "stand_5",
    time = -1
  }
}
