return {
  [-1] = {
    name = CHS[3001502],
    skill_no = -1,
    skill_icon = 9001
  },
  [2] = {
    name = CHS[3001503],
    skill_no = 2,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_A,
    skill_sound = 2,
    skill_effect = "JinDunShu",
    skill_icon = 9000,
    skill_use_normal = 1
  },
  [11] = {
    name = CHS[3001504],
    skill_no = 11,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6054, layer = "normal"},
    stricken = true,
    skill_icon = 9001
  },
  [12] = {
    name = CHS[3001505],
    skill_no = 12,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 2011, layer = "normal"},
    stricken = true,
    skill_icon = 9002
  },
  [13] = {
    name = CHS[3001506],
    skill_no = 13,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6035, layer = "normal"},
    stricken = true,
    skill_icon = 9003
  },
  [14] = {
    name = CHS[3001507],
    skill_no = 14,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3019, layer = "normal"},
    stricken = true,
    skill_icon = 9004
  },
  [15] = {
    name = CHS[3001508],
    skill_no = 15,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 2013,
      layer = "top_most",
      type = "armature",
      icon_ex = 2013,
      layer_ex = "bottom_most",
      type_ex = "armature"
    },
    stricken = true,
    skill_icon = 9005
  },
  [21] = {
    name = CHS[3001509],
    skill_no = 21,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 2014, layer = "normal"},
    stricken = true,
    skill_icon = 9006
  },
  [22] = {
    name = CHS[3001510],
    skill_no = 22,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6046, layer = "normal"},
    stricken = true,
    skill_icon = 9007
  },
  [23] = {
    name = CHS[3001511],
    skill_no = 23,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6057, layer = "normal"},
    stricken = true,
    skill_icon = 9008
  },
  [24] = {
    name = CHS[3001512],
    skill_no = 24,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3023, layer = "normal"},
    stricken = true,
    skill_icon = 9009
  },
  [25] = {
    name = CHS[3001513],
    skill_no = 25,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 5001, layer = "normal"},
    stricken = true,
    skill_icon = 9010
  },
  [31] = {
    name = CHS[3001514],
    skill_no = 31,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 2015, layer = "bottom"},
    skill_icon = 9011
  },
  [32] = {
    name = CHS[3001515],
    skill_no = 32,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6038, layer = "top"},
    skill_icon = 9012
  },
  [33] = {
    name = CHS[3001516],
    skill_no = 33,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6056, layer = "top"},
    skill_icon = 9013
  },
  [34] = {
    name = CHS[3001517],
    skill_no = 34,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3022, layer = "bottom"},
    skill_icon = 9014
  },
  [35] = {
    name = CHS[3001518],
    skill_no = 35,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 5002, layer = "normal"},
    skill_icon = 9015
  },
  [52] = {
    name = CHS[3001519],
    skill_no = 52,
    skill_class = SKILL.CLASS_WOOD,
    skill_sound = 4,
    skill_effect = "MuDunShu",
    skill_sound_failed = 5,
    skill_effect_failed = "MuDunShuFailed",
    skill_icon = 9000,
    skill_use_normal = 1
  },
  [61] = {
    name = CHS[3001520],
    skill_no = 61,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6063, layer = "normal"},
    stricken = true,
    skill_icon = 9001
  },
  [62] = {
    name = CHS[3001521],
    skill_no = 62,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6034, layer = "normal"},
    stricken = true,
    skill_icon = 9002
  },
  [63] = {
    name = CHS[3001522],
    skill_no = 63,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 2016, layer = "normal"},
    stricken = true,
    skill_icon = 9003
  },
  [64] = {
    name = CHS[3001523],
    skill_no = 64,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3020, layer = "normal"},
    stricken = true,
    skill_icon = 9004
  },
  [65] = {
    name = CHS[3001524],
    skill_no = 65,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 5003,
      layer = "top_most",
      type = "armature"
    },
    stricken = true,
    skill_icon = 9005
  },
  [71] = {
    name = CHS[3001525],
    skill_no = 71,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 2017, layer = "normal"},
    stricken = true,
    skill_icon = 9006
  },
  [72] = {
    name = CHS[3001526],
    skill_no = 72,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6037, layer = "normal"},
    stricken = true,
    skill_icon = 9007
  },
  [73] = {
    name = CHS[3001527],
    skill_no = 73,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6062, layer = "normal"},
    stricken = true,
    skill_icon = 9008
  },
  [74] = {
    name = CHS[3001528],
    skill_no = 74,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3026, layer = "normal"},
    stricken = true,
    skill_icon = 9009
  },
  [75] = {
    name = CHS[3001529],
    skill_no = 75,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 5004, layer = "normal"},
    stricken = true,
    skill_icon = 9010
  },
  [81] = {
    name = CHS[3001530],
    skill_no = 81,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 2018, layer = "normal"},
    skill_icon = 9011
  },
  [82] = {
    name = CHS[3001531],
    skill_no = 82,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6052, layer = "normal"},
    skill_icon = 9012
  },
  [83] = {
    name = CHS[3001532],
    skill_no = 83,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6058, layer = "normal"},
    skill_icon = 9013
  },
  [84] = {
    name = CHS[3001533],
    skill_no = 84,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3015, layer = "normal"},
    skill_icon = 9014
  },
  [85] = {
    name = CHS[3001534],
    skill_no = 85,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 5005, layer = "normal"},
    skill_icon = 9015
  },
  [102] = {
    name = CHS[3001535],
    skill_no = 102,
    skill_class = SKILL.CLASS_WATER,
    skill_sound = 4,
    skill_effect = "ShuiDunShu",
    skill_icon = 9000,
    skill_use_normal = 1
  },
  [110] = {
    name = CHS[3001536],
    skill_no = 110,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 2019, layer = "top"},
    stricken = true,
    skill_icon = 9001
  },
  [111] = {
    name = CHS[3001537],
    skill_no = 111,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6049, layer = "top"},
    stricken = true,
    skill_icon = 9002
  },
  [112] = {
    name = CHS[3001538],
    skill_no = 112,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6042, layer = "top"},
    stricken = true,
    skill_icon = 9003
  },
  [113] = {
    name = CHS[3001539],
    skill_no = 113,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3021, layer = "normal"},
    stricken = true,
    skill_icon = 9004
  },
  [114] = {
    name = CHS[3001540],
    skill_no = 114,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 5006,
      layer = "top_most",
      type = "armature",
      icon_ex = 5006,
      layer_ex = "bottom_most",
      type_ex = "armature"
    },
    stricken = true,
    skill_icon = 9005
  },
  [121] = {
    name = CHS[3001541],
    skill_no = 121,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3001, layer = "normal"},
    skill_icon = 9006
  },
  [122] = {
    name = CHS[3001542],
    skill_no = 122,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6059, layer = "bottom"},
    skill_icon = 9007
  },
  [123] = {
    name = CHS[3001543],
    skill_no = 123,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6045, layer = "normal"},
    skill_icon = 9008
  },
  [124] = {
    name = CHS[3001544],
    skill_no = 124,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3017, layer = "bottom"},
    skill_icon = 9009
  },
  [125] = {
    name = CHS[3001545],
    skill_no = 125,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 5007, layer = "top"},
    skill_icon = 9010
  },
  [131] = {
    name = CHS[3001546],
    skill_no = 131,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6047, layer = "top"},
    skill_icon = 9011
  },
  [132] = {
    name = CHS[3001547],
    skill_no = 132,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6060, layer = "top"},
    skill_icon = 9012
  },
  [133] = {
    name = CHS[3001548],
    skill_no = 133,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3002, layer = "bottom"},
    skill_icon = 9013
  },
  [134] = {
    name = CHS[3001549],
    skill_no = 134,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3025, layer = "bottom"},
    skill_icon = 9014
  },
  [135] = {
    name = CHS[3001550],
    skill_no = 135,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 5009, layer = "bottom"},
    skill_icon = 9015
  },
  [152] = {
    name = CHS[3001551],
    skill_no = 152,
    skill_class = SKILL.CLASS_FIRE,
    skill_sound = 4,
    skill_effect = "HuoDunShu",
    skill_icon = 9000,
    skill_use_normal = 1
  },
  [161] = {
    name = CHS[3001552],
    skill_no = 161,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3005, layer = "top"},
    stricken = true,
    skill_icon = 9001
  },
  [162] = {
    name = CHS[3001553],
    skill_no = 162,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6041, layer = "top"},
    stricken = true,
    skill_icon = 9002
  },
  [163] = {
    name = CHS[3001554],
    skill_no = 163,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6043, layer = "top"},
    stricken = true,
    skill_icon = 9003
  },
  [164] = {
    name = CHS[3001555],
    skill_no = 164,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3018, layer = "normal"},
    stricken = true,
    skill_icon = 9004
  },
  [165] = {
    name = CHS[3001556],
    skill_no = 165,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 5010,
      layer = "top_most",
      type = "armature"
    },
    stricken = true,
    skill_icon = 9005
  },
  [171] = {
    name = CHS[3001557],
    skill_no = 171,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6040, layer = "normal"},
    skill_icon = 9006
  },
  [172] = {
    name = CHS[3001558],
    skill_no = 172,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3006, layer = "normal"},
    skill_icon = 9007
  },
  [173] = {
    name = CHS[3001559],
    skill_no = 173,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6051, layer = "normal"},
    skill_icon = 9008
  },
  [174] = {
    name = CHS[3001560],
    skill_no = 174,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3016, layer = "normal"},
    skill_icon = 9009
  },
  [175] = {
    name = CHS[3001561],
    skill_no = 175,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 5011, layer = "normal"},
    skill_icon = 9010
  },
  [181] = {
    name = CHS[3001562],
    skill_no = 181,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3007, layer = "bottom"},
    skill_icon = 9011
  },
  [182] = {
    name = CHS[3001563],
    skill_no = 182,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6061, layer = "top"},
    skill_icon = 9012
  },
  [183] = {
    name = CHS[3001564],
    skill_no = 183,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6053, layer = "top"},
    skill_icon = 9013
  },
  [184] = {
    name = CHS[3001565],
    skill_no = 184,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3014, layer = "normal"},
    skill_icon = 9014
  },
  [185] = {
    name = CHS[3001566],
    skill_no = 185,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 5012, layer = "bottom"},
    skill_icon = 9015
  },
  [202] = {
    name = CHS[3001567],
    skill_no = 202,
    skill_class = SKILL.CLASS_EARTH,
    skill_sound = 4,
    skill_effect = "TuDunShu",
    skill_icon = 9000,
    skill_use_normal = 1
  },
  [210] = {
    name = CHS[3001568],
    skill_no = 210,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3009, layer = "normal"},
    stricken = true,
    skill_icon = 9001
  },
  [211] = {
    name = CHS[3001569],
    skill_no = 211,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6039, layer = "normal"},
    stricken = true,
    skill_icon = 9002
  },
  [212] = {
    name = CHS[3001570],
    skill_no = 212,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6036, layer = "normal"},
    stricken = true,
    skill_icon = 9003
  },
  [213] = {
    name = CHS[3001571],
    skill_no = 213,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3024, layer = "normal"},
    stricken = true,
    skill_icon = 9004
  },
  [214] = {
    name = CHS[3001572],
    skill_no = 214,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 5013,
      layer = "top_most",
      type = "armature"
    },
    stricken = true,
    skill_icon = 9005
  },
  [221] = {
    name = CHS[3001573],
    skill_no = 221,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3010, layer = "normal"},
    stricken = true,
    skill_icon = 9006
  },
  [222] = {
    name = CHS[3001574],
    skill_no = 222,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6048, layer = "normal"},
    stricken = true,
    skill_icon = 9007
  },
  [223] = {
    name = CHS[3001575],
    skill_no = 223,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6055, layer = "normal"},
    stricken = true,
    skill_icon = 9008
  },
  [224] = {
    name = CHS[3001576],
    skill_no = 224,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3013, layer = "normal"},
    stricken = true,
    skill_icon = 9009
  },
  [225] = {
    name = CHS[3001577],
    skill_no = 225,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_C,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 5014, layer = "bottom"},
    stricken = true,
    skill_icon = 9010
  },
  [231] = {
    name = CHS[3001578],
    skill_no = 231,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6044, layer = "normal"},
    skill_icon = 9011
  },
  [232] = {
    name = CHS[3001579],
    skill_no = 232,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3011, layer = "normal"},
    skill_icon = 9012
  },
  [233] = {
    name = CHS[3001580],
    skill_no = 233,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6050, layer = "normal"},
    skill_icon = 9013
  },
  [234] = {
    name = CHS[3001581],
    skill_no = 234,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3012, layer = "normal"},
    skill_icon = 9014
  },
  [235] = {
    name = CHS[3001582],
    skill_no = 235,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_D,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 5015, layer = "normal"},
    skill_icon = 9015
  },
  [252] = {
    name = CHS[3001583],
    skill_no = 252,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect = {icon = 6002, layer = "top_most"},
    stricken = true,
    skill_icon = 9016
  },
  [253] = {
    name = CHS[3001584],
    skill_no = 253,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect = {icon = 6003, layer = "normal"},
    skill_icon = 9017
  },
  [254] = {
    name = CHS[3001585],
    skill_no = 254,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect = {icon = 6005, layer = "normal"},
    skill_icon = 9018
  },
  [255] = {
    name = CHS[3001586],
    skill_no = 255,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_4,
    skill_sound = 4,
    skill_effect = {icon = 6007, layer = "normal"},
    stricken = true,
    skill_icon = 9019
  },
  [257] = {
    name = CHS[3001588],
    skill_no = 257,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_5,
    skill_sound = 4,
    skill_effect = {icon = 6010, layer = "normal"},
    stricken = true,
    skill_icon = 9020
  },
  [258] = {
    name = CHS[3001589],
    skill_no = 258,
    skill_sound = 4,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_6,
    skill_effect_to_whom = 3,
    skill_effect_who_first = 1,
    skill_effect = {icon = 6012, layer = "normal"},
    skill_effect_ex = {icon = 6013, layer = "normal"},
    stricken = true,
    skill_icon = 9021
  },
  [259] = {
    name = CHS[3001590],
    skill_no = 259,
    skill_sound = 4,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_7,
    skill_effect = {icon = 6014, layer = "normal"},
    skill_icon = 9022
  },
  [260] = {
    name = CHS[3001591],
    skill_no = 260,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_8,
    skill_sound = 4,
    skill_effect = {icon = 6016, layer = "normal"},
    skill_icon = 9023
  },
  [261] = {
    name = CHS[3001592],
    skill_no = 261,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_9,
    skill_sound = 4,
    skill_effect = {icon = 6019, layer = "bottom"},
    skill_icon = 9024
  },
  [262] = {
    name = CHS[3001593],
    skill_no = 262,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_10,
    skill_sound = 4,
    skill_effect = {icon = 1070, layer = "normal"},
    skill_icon = 9029
  },
  [263] = {
    name = CHS[3001594],
    skill_no = 263,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect = {icon = 8089, layer = "normal"},
    skill_icon = 9031
  },
  [264] = {
    name = CHS[3001595],
    skill_no = 264,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_2,
    skill_sound = 4,
    skill_effect = {icon = 8090, layer = "normal"},
    skill_icon = 9032
  },
  [265] = {
    name = CHS[3001596],
    skill_no = 265,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_3,
    skill_sound = 4,
    skill_effect_to_whom = 3,
    skill_effect_who_first = 1,
    skill_effect = {icon = 8091, layer = "normal"},
    skill_effect_ex = {icon = 8092, layer = "normal"},
    skill_icon = 9030
  },
  [9999] = {
    name = CHS[3001598],
    skill_no = 9999,
    skill_sound = 4,
    skill_effect = "JiJiRuLvLing",
    skill_icon = 9000
  },
  [301] = {
    name = CHS[3001601],
    skill_no = 301,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_F,
    skill_ladder = SKILL.LADDER_1,
    skill_icon = 9169
  },
  [302] = {
    name = CHS[3001602],
    skill_no = 302,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_F,
    skill_ladder = SKILL.LADDER_2,
    skill_icon = 9170
  },
  [303] = {
    name = CHS[4000442],
    skill_no = 303,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_F,
    skill_ladder = SKILL.LADDER_3,
    skill_icon = 9174,
    skill_max_level = 1
  },
  [304] = {
    name = CHS[4000443],
    skill_no = 304,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_F,
    skill_ladder = SKILL.LADDER_4,
    skill_icon = 9175,
    skill_max_level = 1
  },
  [305] = {
    name = "冥界穿行",
    skill_no = 305,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_F,
    skill_ladder = SKILL.LADDER_5,
    skill_icon = 9176,
    skill_max_level = 1
  },
  [350] = {
    name = CHS[3001605],
    skill_no = 350,
    skill_icon = 9201
  },
  [351] = {
    name = CHS[3001606],
    skill_no = 351,
    skill_icon = 9202
  },
  [352] = {
    name = CHS[3001607],
    skill_no = 352,
    skill_icon = 9204
  },
  [353] = {
    name = CHS[3001608],
    skill_no = 353,
    skill_icon = 9206
  },
  [354] = {
    name = CHS[3001609],
    skill_no = 354,
    skill_icon = 9207
  },
  [355] = {
    name = CHS[3001610],
    skill_no = 355,
    skill_icon = 9205
  },
  [356] = {
    name = CHS[3001611],
    skill_no = 356,
    skill_icon = 9209
  },
  [357] = {
    name = CHS[3001612],
    skill_no = 357,
    skill_icon = 9210
  },
  [358] = {
    name = CHS[3001613],
    skill_no = 358,
    skill_icon = 9208
  },
  [359] = {
    name = CHS[3001614],
    skill_no = 359,
    skill_icon = 9203
  },
  [360] = {
    name = CHS[3001615],
    skill_no = 360,
    skill_icon = 9211
  },
  [361] = {
    name = CHS[3001616],
    skill_no = 361,
    skill_icon = 9212
  },
  [362] = {
    name = CHS[3001617],
    skill_no = 362,
    skill_icon = 9213
  },
  [363] = {
    name = CHS[3001618],
    skill_no = 363,
    skill_icon = 9214
  },
  [364] = {
    name = CHS[3001619],
    skill_no = 364,
    skill_icon = 9215
  },
  [501] = {
    name = CHS[3001620],
    skill_no = 501,
    skill_class = SKILL.CLASS_PHY,
    skill_subclass = SKILL.SUBCLASS_J,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 8117, layer = "top"},
    stricken = true,
    skill_icon = 9601
  },
  [601] = {
    name = CHS[6000281],
    skill_no = 601,
    skill_icon = 9301
  },
  [602] = {
    name = CHS[6000282],
    skill_no = 602,
    skill_icon = 9302
  },
  [603] = {
    name = CHS[6000283],
    skill_no = 603,
    skill_icon = 9303
  },
  [604] = {
    name = CHS[7002210],
    skill_no = 604,
    skill_icon = 9304
  },
  [701] = {
    name = CHS[6000482],
    skill_no = 701,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 8238,
      layer = "top_most",
      type = "armature",
      icon_ex = 8238,
      layer_ex = "bottom_most",
      type_ex = "armature"
    },
    stricken = true,
    shake_screen = 2
  },
  [702] = {
    name = CHS[3002022],
    skill_no = 702,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 8389,
      layer = "top_most",
      type = "armature"
    },
    stricken = true,
    shake_screen = 2
  },
  [703] = {
    name = CHS[7002096],
    skill_no = 703,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 8221,
      layer = "top_most",
      type = "armature"
    },
    stricken = true,
    shake_screen = 2
  },
  [704] = {
    name = CHS[7002307],
    skill_no = 704,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 8222,
      layer = "bottom_most",
      type = "armature"
    },
    stricken = true,
    shake_screen = 2
  },
  [9166] = {
    name = CHS[3001621],
    skill_no = 9166,
    skill_icon = 9166
  },
  [9167] = {
    name = CHS[3001622],
    skill_no = 9167,
    skill_icon = 9167
  },
  [9169] = {
    name = CHS[3001623],
    skill_no = 9169,
    skill_icon = 9169
  },
  [9170] = {
    name = CHS[3001624],
    skill_no = 9170,
    skill_icon = 9170
  },
  [801] = {
    name = CHS[3001987],
    skill_no = 801,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_O,
    skill_icon = 9161,
    skill_effect = {icon = 8375, layer = "normal"},
    skill_effect_to_whom = 2
  },
  [802] = {
    name = CHS[3001988],
    skill_no = 802,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_O,
    skill_icon = 9162,
    skill_effect = {icon = 8377, layer = "normal"},
    skill_effect_to_whom = 2
  },
  [803] = {
    name = CHS[3001989],
    skill_no = 803,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_O,
    skill_icon = 9163,
    skill_effect = {icon = 8379, layer = "normal"},
    skill_effect_to_whom = 2
  },
  [804] = {
    name = CHS[3001990],
    skill_no = 804,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_O,
    skill_icon = 9164,
    skill_effect = {icon = 8381, layer = "normal"},
    skill_effect_to_whom = 2
  },
  [805] = {
    name = CHS[3001991],
    skill_no = 805,
    skill_class = SKILL.CLASS_PET,
    skill_subclass = SKILL.SUBCLASS_O,
    skill_icon = 9165,
    skill_effect = {icon = 8383, layer = "normal"},
    skill_effect_to_whom = 1
  },
  [471] = {
    name = CHS[3001942],
    skill_no = 471,
    skill_icon = 9251,
    skill_effect = {icon = 8245, layer = "normal"},
    skill_effect_to_whom = 2
  },
  [472] = {
    name = CHS[3001943],
    skill_no = 472,
    skill_icon = 9252,
    skill_effect = {icon = 8246, layer = "normal"},
    skill_effect_to_whom = 2
  },
  [473] = {
    name = CHS[3001944],
    skill_no = 473,
    skill_icon = 9253
  },
  [474] = {
    name = CHS[3001945],
    skill_no = 474,
    skill_icon = 9254,
    skill_effect = {icon = 6070, layer = "normal"},
    skill_effect_to_whom = 2
  },
  [475] = {
    name = CHS[3001946],
    skill_no = 475,
    skill_icon = 9255,
    skill_effect = {
      icon = 8248,
      layer = "normal",
      blendMode = "add"
    },
    skill_effect_to_whom = 2
  },
  [476] = {
    name = CHS[3001947],
    skill_no = 476,
    skill_icon = 9256
  },
  [710] = {
    name = CHS[4100966],
    skill_no = 710,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 8400,
      layer = "top_most",
      type = "armature",
      icon_ex = 8400,
      layer_ex = "bottom_most",
      type_ex = "armature"
    },
    stricken = true,
    shake_screen = 2
  },
  [711] = {
    name = CHS[4100967],
    skill_no = 711,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 8401,
      layer = "top",
      blendMode = "normal"
    }
  },
  [712] = {
    name = CHS[4100968],
    skill_no = 712,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 8403,
      layer = "top",
      blendMode = "normal"
    }
  },
  [900] = {
    name = CHS[7002075],
    skill_no = 900,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 8238,
      layer = "top_most",
      type = "armature",
      icon_ex = 8238,
      layer_ex = "bottom_most",
      type_ex = "armature"
    },
    stricken = true,
    shake_screen = 2
  },
  [901] = {
    name = CHS[5450138],
    flyWord = CHS[3001556],
    skill_no = 901,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 5010,
      layer = "top_most",
      type = "armature"
    },
    stricken = true,
    skill_icon = 9005,
    shake_screen = 2
  },
  [902] = {
    name = CHS[5450139],
    flyWord = CHS[3001992],
    skill_no = 902,
    skill_effect = {icon = 8383, layer = "normal"},
    skill_effect_to_whom = 1
  },
  [903] = {
    name = CHS[5450280],
    skill_no = 903,
    skill_effect = {
      icon = 1319,
      layer = "normal",
      pos = "waist"
    },
    skill_effect_to_whom = 1
  },
  [904] = {
    name = CHS[4010155],
    flyWord = CHS[4010155],
    skill_no = 904,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 1332,
      layer = "top_most",
      type = "armature"
    },
    stricken = true,
    shake_screen = 2
  },
  [905] = {
    name = CHS[4010156],
    skill_no = 905,
    flyWord = CHS[4010156],
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    stricken = true,
    shake_screen = 2,
    skill_effect = {
      icon = 1330,
      layer = "top",
      type = "armature"
    }
  },
  [906] = {
    name = CHS[4010157],
    skill_no = 906,
    flyWord = CHS[4010157],
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 1328,
      layer = "top_most",
      type = "armature",
      icon_ex = 1328,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [907] = {
    name = CHS[4101205],
    flyWord = CHS[4101205],
    skill_no = 907,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 1347,
      layer = "top_most",
      type = "armature",
      icon_ex = 1347,
      layer_ex = "bottom_most",
      type_ex = "armature"
    },
    stricken = true
  },
  [909] = {
    name = CHS[2200151],
    flyWord = CHS[2200151],
    skill_no = 909,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {
      icon = 1349,
      layer = "top_most",
      type = "armature",
      icon_ex = 1349,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [1000] = {
    name = "",
    skill_no = 1000,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2
  },
  [1001] = {
    name = CHS[34308],
    skill_no = 1001,
    skill_class = SKILL.CLASS_METAL,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6054, layer = "normal"},
    stricken = true,
    skill_icon = 9401,
    skill_para = 1
  },
  [1002] = {
    name = CHS[34309],
    skill_no = 1002,
    skill_class = SKILL.CLASS_WOOD,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 6063, layer = "normal"},
    stricken = true,
    skill_icon = 9402,
    skill_para = 1
  },
  [1003] = {
    name = CHS[34310],
    skill_no = 1003,
    skill_class = SKILL.CLASS_WATER,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 2019, layer = "top"},
    stricken = true,
    skill_icon = 9403,
    skill_para = 1
  },
  [1004] = {
    name = CHS[34311],
    skill_no = 1004,
    skill_class = SKILL.CLASS_FIRE,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3005, layer = "top"},
    stricken = true,
    skill_icon = 9404,
    skill_para = 1
  },
  [1005] = {
    name = CHS[34312],
    skill_no = 1005,
    skill_class = SKILL.CLASS_EARTH,
    skill_subclass = SKILL.SUBCLASS_B,
    skill_ladder = SKILL.LADDER_1,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3009, layer = "normal"},
    stricken = true,
    skill_icon = 9405,
    skill_para = 1
  },
  [1006] = {
    name = "",
    skill_no = 1006,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect_who_first = 1,
    skill_effect = {icon = 3015, layer = "normal"},
    skill_icon = 9014
  },
  [8001] = {
    name = CHS[5410349],
    skill_no = 8001,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 3013, layer = "normal"},
    stricken = true,
    skill_icon = 9009
  },
  [910] = {
    name = CHS[4101723],
    flyWord = CHS[4101723],
    skill_no = 910,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect = {
      icon = 2093,
      layer = "top_most",
      type = "armature",
      icon_ex = 2093,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [911] = {
    name = CHS[4101736],
    flyWord = CHS[4101736],
    skill_no = 911,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2092,
      layer = "top_most",
      type = "armature"
    }
  },
  [912] = {
    name = CHS[4101724],
    flyWord = CHS[4101724],
    skill_no = 912,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect = {icon = 1484, layer = "normal"}
  },
  [913] = {
    name = "九幽冥火",
    flyWord = "九幽冥火",
    skill_no = 913,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2122,
      layer = "top_most",
      type = "armature",
      icon_ex = 2122,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [914] = {
    name = "九幽火",
    flyWord = "九幽火",
    skill_no = 914,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2123,
      layer = "top_most",
      type = "armature"
    }
  },
  [915] = {
    name = "离魂之火",
    flyWord = "离魂之火",
    skill_no = 915,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2124,
      layer = "top_most",
      type = "armature"
    }
  },
  [916] = {
    name = "长生冥炎",
    flyWord = "长生冥炎",
    skill_no = 916,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect = {icon = 1576, layer = "normal"}
  },
  [917] = {
    name = "真武魔印",
    flyWord = "真武魔印",
    skill_no = 917,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect = {
      icon = 2129,
      layer = "top_most",
      type = "armature",
      icon_ex = 2129,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [918] = {
    name = "玄武印",
    flyWord = "玄武印",
    skill_no = 918,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect = {icon = 1616, layer = "normal"}
  },
  [920] = {
    name = "邪气斩",
    flyWord = "邪气斩",
    skill_no = 920,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2138,
      layer = "top_most",
      type = "armature",
      topAction = "Top01",
      icon_ex = 2138,
      layer_ex = "bottom_most",
      type_ex = "armature",
      bottomAction = "Bottom01"
    }
  },
  [921] = {
    name = "邪气斩2",
    flyWord = "邪气斩",
    skill_no = 921,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2138,
      layer = "top_most",
      type = "armature",
      topAction = "Top02",
      icon_ex = 2138,
      layer_ex = "bottom_most",
      type_ex = "armature",
      bottomAction = "Bottom02"
    }
  },
  [919] = {
    name = "腥风毒雨",
    flyWord = "腥风毒雨",
    skill_no = 919,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2133,
      layer = "top_most",
      type = "armature",
      icon_ex = 2133,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [922] = {
    name = "魔龙摆尾",
    flyWord = "魔龙摆尾",
    skill_no = 922,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2188,
      layer = "top_most",
      type = "armature",
      icon_ex = 2188,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [923] = {
    name = "李代桃僵",
    skill_no = 923,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    skill_effect = {icon = 1699, layer = "Bottom"}
  },
  [924] = {
    name = "裂魂魔爪",
    skill_no = 924,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2189,
      layer = "top_most",
      type = "armature",
      icon_ex = 2189,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [925] = {
    name = "吞天破月",
    skill_no = 925,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2190,
      layer = "top_most",
      type = "armature",
      icon_ex = 2190,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [926] = {
    name = "吞天破月(魔龙吞天)",
    flyWord = "吞天破月",
    skill_no = 926,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2190,
      layer = "top_most",
      type = "armature",
      icon_ex = 2190,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [927] = {
    name = "龙息施法",
    skill_no = 927,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 1,
    shake_screen = 0,
    skill_effect = {
      icon = 1724,
      layer = "top",
      pos = "waist"
    },
    skill_effect_ex = 0
  },
  [928] = {
    name = "吞天破月(魔龙吞天怒)",
    flyWord = "吞天破月",
    skill_no = 928,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 2,
    shake_screen = 2,
    skill_effect = {
      icon = 2190,
      layer = "top_most",
      type = "armature",
      icon_ex = 2190,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  },
  [930] = {
    name = "千玉诀",
    flyWord = "",
    skill_no = 930,
    skill_class = SKILL.CLASS_PUBLIC,
    skill_subclass = SKILL.SUBCLASS_E,
    skill_ladder = SKILL.LADDER_0,
    skill_sound = 4,
    skill_effect_to_whom = 1,
    shake_screen = 2,
    skill_effect = {
      icon = 2133,
      layer = "top_most",
      type = "armature",
      icon_ex = 2133,
      layer_ex = "bottom_most",
      type_ex = "armature"
    }
  }
}
