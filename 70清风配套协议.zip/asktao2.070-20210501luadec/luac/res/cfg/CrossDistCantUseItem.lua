return {
  [CHS[4100951]] = true,
  [CHS[4100952]] = true,
  [CHS[4100953]] = true,
  [CHS[4100954]] = true,
  [CHS[6400034]] = true,
  [CHS[6400035]] = true,
  [CHS[4100323]] = true,
  [CHS[5400070]] = true,
  [CHS[7000044]] = true,
  [CHS[7000045]] = true,
  [CHS[4200404]] = true,
  [CHS[3001111]] = true,
  [CHS[5400319]] = true,
  [CHS[4101029]] = true,
  [CHS[7150649]] = true,
  [CHS[7150650]] = true,
  [CHS[7150651]] = true
}
