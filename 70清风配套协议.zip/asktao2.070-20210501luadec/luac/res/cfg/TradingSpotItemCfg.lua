return {
  [1] = {
    name = CHS[7190424],
    npc = CHS[7190465]
  },
  [2] = {
    name = CHS[7190425],
    npc = CHS[7190466]
  },
  [3] = {
    name = CHS[7190426],
    npc = CHS[7190467]
  },
  [4] = {
    name = CHS[7190427],
    npc = CHS[7190466]
  },
  [5] = {
    name = CHS[7190428],
    npc = CHS[7190467]
  },
  [6] = {
    name = CHS[7190429],
    npc = CHS[7190468]
  },
  [7] = {
    name = CHS[7190430],
    npc = CHS[7190467]
  },
  [8] = {
    name = CHS[7190431],
    npc = CHS[7190468]
  },
  [9] = {
    name = CHS[7190432],
    npc = CHS[7190466]
  },
  [10] = {
    name = CHS[7190433],
    npc = CHS[7190467]
  },
  [11] = {
    name = CHS[7190434],
    npc = CHS[7190467]
  },
  [12] = {
    name = CHS[7190435],
    npc = CHS[7190467]
  },
  [13] = {
    name = CHS[7190436],
    npc = CHS[7190467]
  },
  [14] = {
    name = CHS[7190437],
    npc = CHS[7190465]
  },
  [15] = {
    name = CHS[7190438],
    npc = CHS[7190468]
  },
  [16] = {
    name = CHS[7190439],
    npc = CHS[7190466]
  },
  [17] = {
    name = CHS[7190440],
    npc = CHS[7190467]
  },
  [18] = {
    name = CHS[7190441],
    npc = CHS[7190465]
  },
  [19] = {
    name = CHS[7190442],
    npc = CHS[7190468]
  },
  [20] = {
    name = CHS[7190443],
    npc = CHS[7190466]
  },
  [21] = {
    name = CHS[7190444],
    npc = CHS[7190465]
  },
  [22] = {
    name = CHS[7190445],
    npc = CHS[7190468]
  },
  [23] = {
    name = CHS[7190446],
    npc = CHS[7190467]
  },
  [24] = {
    name = CHS[7190447],
    npc = CHS[7190468]
  },
  [25] = {
    name = CHS[7190448],
    npc = CHS[7190466]
  },
  [26] = {
    name = CHS[7190449],
    npc = CHS[7190467]
  },
  [27] = {
    name = CHS[7190450],
    npc = CHS[7190465]
  },
  [28] = {
    name = CHS[7190451],
    npc = CHS[7190465]
  },
  [29] = {
    name = CHS[7190452],
    npc = CHS[7190465]
  },
  [30] = {
    name = CHS[7190453],
    npc = CHS[7190467]
  }
}
