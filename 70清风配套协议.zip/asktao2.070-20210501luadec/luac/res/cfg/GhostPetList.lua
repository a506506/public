return {
  ["炼狱魔"] = {
    name = "炼狱魔",
    icon = 31052,
    zoon = {},
    polar = "无",
    rank = 6,
    level_req = 75,
    life = 45,
    mana = 0,
    speed = 5,
    phy_attack = 50,
    mag_attack = -25,
    skills = {
      "如意圈",
      "舍命一击",
      "游说之舌"
    },
    order = 1,
    artName = "ui/BitmapLabel0020.png"
  },
  ["阴阳师"] = {
    name = "阴阳师",
    icon = 31055,
    zoon = {},
    polar = "土",
    rank = 6,
    level_req = 75,
    life = 40,
    mana = 20,
    speed = 20,
    phy_attack = -35,
    mag_attack = 30,
    skills = {
      "鞭长莫及",
      "神龙罩",
      "神圣之光"
    },
    order = 2,
    artName = "ui/BitmapLabel0021.png"
  },
  ["魅灵"] = {
    name = "魅灵",
    icon = 31053,
    zoon = {},
    polar = "火",
    rank = 6,
    level_req = 75,
    life = 45,
    mana = 10,
    speed = 30,
    phy_attack = -30,
    mag_attack = 20,
    skills = {
      "十万火急",
      "游说之舌",
      "死亡缠绵"
    },
    order = 3,
    artName = "ui/BitmapLabel0022.png"
  },
  ["狱獒"] = {
    name = "狱獒",
    icon = 31054,
    zoon = {},
    polar = "水",
    rank = 6,
    level_req = 75,
    life = 55,
    mana = 20,
    speed = 10,
    phy_attack = -25,
    mag_attack = 15,
    skills = {
      "防微杜渐",
      "漫天血舞",
      "乾坤罩"
    },
    order = 4,
    artName = "ui/BitmapLabel0023.png"
  },
  ["范无救"] = {
    name = "范无救",
    icon = 20059,
    zoon = {},
    polar = "无",
    rank = 7,
    level_req = 75,
    life = 40,
    mana = -20,
    speed = 5,
    phy_attack = 70,
    mag_attack = -40,
    skills = {
      "翻转乾坤",
      "乾坤罩",
      "游说之舌"
    },
    order = 100,
    artName = "ui/BitmapLabel0024.png"
  },
  ["牛头狱卒"] = {
    name = "牛头狱卒",
    icon = 20056,
    zoon = {},
    polar = "金",
    rank = 7,
    level_req = 75,
    life = 50,
    mana = 5,
    speed = 15,
    phy_attack = -50,
    mag_attack = 35,
    skills = {
      "翻转乾坤",
      "神龙罩",
      "天生神力"
    },
    order = 101,
    artName = "ui/BitmapLabel0025.png"
  },
  ["谢必安"] = {
    name = "谢必安",
    icon = 20058,
    zoon = {},
    polar = "火",
    rank = 7,
    level_req = 75,
    life = 50,
    mana = 0,
    speed = 35,
    phy_attack = -50,
    mag_attack = 20,
    skills = {
      "翻转乾坤",
      "如意圈",
      "十万火急"
    },
    order = 102,
    artName = "ui/BitmapLabel0026.png"
  },
  ["马面罗刹"] = {
    name = "马面罗刹",
    icon = 20057,
    zoon = {},
    polar = "木",
    rank = 7,
    level_req = 75,
    life = 65,
    mana = 25,
    speed = 0,
    phy_attack = -50,
    mag_attack = 15,
    skills = {
      "舍命一击",
      "乾坤罩",
      "拔苗助长"
    },
    order = 103,
    artName = "ui/BitmapLabel0027.png"
  },
  ["冥炎之灵"] = {
    name = "冥炎之灵",
    icon = 31057,
    zoon = {},
    polar = "无",
    rank = 8,
    level_req = 75,
    life = 45,
    mana = -45,
    speed = 25,
    phy_attack = 90,
    mag_attack = -50,
    skills = {
      "翻转乾坤",
      "死亡缠绵",
      "如意圈"
    },
    order = 200,
    artName = "ui/BitmapLabel0028.png"
  },
  ["孟姑"] = {
    name = "孟姑",
    icon = 31056,
    zoon = {},
    polar = "木",
    rank = 8,
    level_req = 75,
    life = 50,
    mana = 10,
    speed = 30,
    phy_attack = -60,
    mag_attack = 35,
    skills = {
      "舍命一击",
      "漫天血舞",
      "神龙罩"
    },
    order = 201,
    artName = "ui/BitmapLabel0029.png"
  },
  ["谛听"] = {
    name = "谛听",
    icon = 31058,
    zoon = {},
    polar = "火",
    rank = 8,
    level_req = 75,
    life = 45,
    mana = 15,
    speed = 40,
    phy_attack = -60,
    mag_attack = 25,
    skills = {
      "神圣之光",
      "游说之舌",
      "如意圈"
    },
    order = 202,
    artName = "ui/BitmapLabel0030.png"
  },
  ["阎摩"] = {
    name = "阎摩",
    icon = 20051,
    zoon = {},
    polar = "土",
    rank = 8,
    level_req = 75,
    life = 70,
    mana = 10,
    speed = 30,
    phy_attack = -60,
    mag_attack = 15,
    skills = {
      "翻转乾坤",
      "游说之舌",
      "乾坤罩"
    },
    order = 203,
    artName = "ui/BitmapLabel0031.png"
  }
}
