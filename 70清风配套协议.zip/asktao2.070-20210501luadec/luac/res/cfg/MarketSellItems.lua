return {
  [CHS[3001206]] = {},
  [CHS[7000306]] = {},
  [CHS[3001207]] = {
    {
      name = CHS[4300170],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = "BigRewardIcon0037.png",
      isPlist = 1,
      sellType = 2
    },
    {
      name = CHS[4300171],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = "BigRewardIcon0014.png",
      isPlist = 1,
      sellType = 2
    },
    {
      name = CHS[3001208],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1168,
      sellType = 1
    },
    {
      name = CHS[3001209],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1166,
      sellType = 1
    },
    {
      name = CHS[3001210],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1169,
      sellType = 1
    },
    {
      name = CHS[3001211],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1167,
      sellType = 1
    },
    {
      name = CHS[3001212],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1170,
      sellType = 1
    },
    {
      name = CHS[3001213],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1266,
      sellType = 1
    },
    {
      name = CHS[3001214],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1265,
      sellType = 1
    },
    {
      name = CHS[3001215],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1267,
      sellType = 1
    },
    {
      name = CHS[3001216],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1268,
      sellType = 1
    },
    {
      name = CHS[3001217],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1269,
      sellType = 1
    }
  },
  [CHS[3001218]] = {
    {
      name = CHS[3001219],
      list = {
        CHS[6200027],
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338],
        sellType = 1
      },
      icon = 6173,
      isPortraits = true
    },
    {
      name = CHS[3001220],
      icon = 6177,
      isPortraits = true
    },
    {
      name = CHS[3003814],
      icon = 6189,
      isPortraits = true
    },
    {
      name = CHS[6000082],
      icon = 6660,
      isPortraits = true
    },
    {
      name = CHS[6000504],
      list = {
        CHS[2100032],
        CHS[2100033],
        CHS[2100034],
        CHS[7000304],
        CHS[7000305],
        sellType = 1
      },
      icon = 30025,
      isPortraits = true
    },
    {
      name = CHS[7002139],
      icon = 6301,
      isPortraits = true
    },
    {
      name = "鬼宠",
      list = {
        "鬼卒",
        "鬼将",
        "鬼仙",
        sellType = 1
      },
      icon = 20051,
      isPortraits = true
    }
  },
  [CHS[3001221]] = {
    {
      name = CHS[3001222],
      list = {
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1331
    },
    {
      name = CHS[3001223],
      list = {
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1332
    },
    {
      name = CHS[3001224],
      list = {
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1333
    }
  },
  [CHS[3001225]] = {
    {
      name = CHS[3001226],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1168
    },
    {
      name = CHS[3001227],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1265
    },
    {
      name = CHS[3001228],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1267
    },
    {
      name = CHS[3001229],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1269
    }
  },
  [CHS[3001230]] = {
    {
      name = CHS[3001231],
      icon = 8077
    },
    {
      name = CHS[3001232],
      icon = 8001
    },
    {
      name = CHS[3001233],
      icon = 8057
    },
    {
      name = CHS[3001234],
      icon = 8057
    },
    {
      name = CHS[3001235],
      icon = 8057
    },
    {
      name = CHS[3001236],
      icon = 8057
    },
    {
      name = CHS[3001237],
      icon = 8057
    },
    {
      name = CHS[3001238],
      icon = 8057
    },
    {
      name = CHS[3001239],
      icon = 8057
    },
    {
      name = CHS[3001240],
      icon = 8057
    },
    {
      name = CHS[3001241],
      icon = 8057
    },
    {
      name = CHS[3001242],
      icon = 8057
    },
    {
      name = CHS[3001243],
      icon = 8057
    },
    {
      name = CHS[3001244],
      icon = 8057
    },
    {
      name = CHS[3001245],
      icon = 8057
    },
    {
      name = CHS[3001246],
      icon = 8057
    }
  },
  [CHS[3001247]] = {
    {
      name = CHS[3001208],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1168
    },
    {
      name = CHS[3001209],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1166
    },
    {
      name = CHS[3001210],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1169
    },
    {
      name = CHS[3001211],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1167
    },
    {
      name = CHS[3001212],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1170
    },
    {
      name = CHS[3001213],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1266
    },
    {
      name = CHS[3001214],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1265
    },
    {
      name = CHS[3001215],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1267
    },
    {
      name = CHS[3001216],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1268
    },
    {
      name = CHS[3001217],
      list = {
        50,
        60,
        70,
        80,
        90,
        100,
        110,
        120,
        130
      },
      icon = 1269
    }
  },
  [CHS[3001248]] = {
    {
      name = CHS[3001225],
      icon = 9040
    },
    {
      name = CHS[3001249],
      icon = 9117
    },
    {
      name = CHS[3001250],
      icon = 9021
    },
    {
      name = CHS[3001251],
      icon = 9022
    },
    {
      name = CHS[3001252],
      icon = 9145
    },
    {
      name = CHS[3001253],
      icon = 9066
    },
    {
      name = CHS[3001254],
      icon = 9077
    },
    {
      name = CHS[3001255],
      icon = 9138
    },
    {
      name = CHS[3001256],
      icon = 1716
    },
    {
      name = CHS[6200048],
      icon = 9180
    },
    {
      name = CHS[7190126],
      icon = 9147
    },
    {
      name = CHS[7190658],
      icon = 1717
    }
  },
  [CHS[3001257]] = {
    {
      name = CHS[3001258],
      icon = 9006
    },
    {
      name = CHS[3001259],
      icon = 9008
    },
    {
      name = CHS[3001260],
      icon = 7102
    },
    {
      name = CHS[3001261],
      icon = 9065
    },
    {
      name = CHS[3001262],
      icon = 1841,
      list = {
        CHS[3001262],
        "高级宠物经验丹"
      }
    },
    {
      name = CHS[3001263],
      icon = 9104
    },
    {
      name = "召唤令·梅兰竹菊",
      icon = 1801
    },
    {
      name = CHS[3001264],
      icon = 1800
    },
    {
      name = CHS[7190029],
      icon = 2006
    },
    {
      name = CHS[4000383],
      icon = 9172
    },
    {name = "羽化丹", icon = 9365},
    {
      name = CHS[6000505],
      icon = 9091
    },
    {
      name = CHS[6000506],
      icon = 9097,
      list = {
        CHS[6000507],
        CHS[6000508],
        CHS[6000509],
        CHS[6000510],
        CHS[6000511],
        CHS[6000512]
      }
    },
    {
      name = CHS[6000522],
      icon = 9135
    },
    {
      name = CHS[2000128],
      icon = 9170
    },
    {
      name = CHS[7000210],
      icon = 9219
    },
    {
      name = CHS[2100031],
      icon = 12003,
      list = {
        CHS[2100032],
        CHS[2100033],
        CHS[2100034]
      }
    },
    {
      name = CHS[5400066],
      icon = 2189,
      testIcon = 2189,
      list = {
        CHS[4200506],
        CHS[4200508],
        CHS[4200509],
        CHS[5450373],
        CHS[5450374],
        "元神碎片·流风",
        "元神碎片·回雪",
        CHS[7383488],
        CHS[7383489]
      }
    },
    {name = "凝神草", icon = 2132},
    {
      name = "鬼宠亲密丹",
      icon = 2133
    },
    {
      name = "鬼卒灵魄",
      icon = 12007
    }
  },
  [CHS[3001265]] = {
    {
      name = CHS[3001265],
      icon = 9068
    },
    {
      name = CHS[3001266],
      icon = 9052
    },
    {
      name = CHS[3001267],
      icon = 9052
    },
    {
      name = CHS[3001268],
      icon = 9052
    },
    {
      name = CHS[3001269],
      icon = 9052
    },
    {
      name = CHS[3001270],
      icon = 9052
    },
    {
      name = CHS[3001271],
      icon = 9052
    },
    {
      name = CHS[3001272],
      icon = 9052
    },
    {
      name = CHS[3001273],
      icon = 9052
    },
    {
      name = CHS[3001274],
      icon = 9052
    },
    {
      name = CHS[3001275],
      icon = 9052
    },
    {
      name = CHS[3001276],
      icon = 9052
    },
    {
      name = CHS[3001277],
      icon = 9052
    },
    {
      name = CHS[3001278],
      icon = 9052
    },
    {
      name = CHS[3001279],
      icon = 9052
    },
    {
      name = CHS[3001280],
      icon = 9052
    }
  },
  [CHS[3001281]] = {
    {
      name = CHS[3001282],
      list = {
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13
      },
      icon = 1560
    },
    {
      name = CHS[3001283],
      list = {
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13
      },
      icon = 1563
    },
    {
      name = CHS[3001284],
      list = {
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13
      },
      icon = 1562
    },
    {
      name = CHS[3001285],
      list = {
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13
      },
      icon = 1561
    },
    {
      name = CHS[3001286],
      list = {
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13
      },
      icon = 1564
    },
    {
      name = CHS[3004454],
      list = {
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13
      },
      icon = 1566
    }
  },
  [CHS[3001287]] = {
    {
      name = CHS[3001288],
      list = {
        CHS[3001289],
        CHS[3001290],
        CHS[3001291],
        CHS[3001292]
      },
      icon = 9050
    },
    {
      name = CHS[3001295],
      icon = 9031
    },
    {
      name = "各类藏宝图",
      icon = 1514,
      list = {
        CHS[8000000],
        CHS[3001145],
        "特级藏宝图"
      }
    },
    {
      name = CHS[3001297],
      icon = 9010
    },
    {
      name = CHS[3001298],
      icon = 9002
    },
    {
      name = CHS[6200026],
      icon = 9081
    },
    {
      name = CHS[7000277],
      icon = 9210
    },
    {
      name = CHS[3001299],
      icon = 9007
    },
    {
      name = CHS[4100323],
      icon = 7706
    },
    {
      name = CHS[2000095],
      icon = 9028
    },
    {
      name = CHS[6000252],
      icon = 9043
    },
    {
      name = CHS[7000206],
      icon = 9030,
      list = {
        CHS[6000265],
        CHS[6000263],
        CHS[6000264],
        CHS[6000262]
      }
    },
    {
      name = CHS[4100425],
      icon = 8085,
      list = {
        CHS[4100421],
        CHS[4100422],
        CHS[4100423],
        CHS[4100424]
      }
    },
    {
      name = CHS[7000081],
      icon = 8065
    },
    {
      name = "真灵精粹",
      icon = 9182
    },
    {
      name = CHS[7000043],
      icon = 9076
    },
    {
      name = CHS[7000044],
      icon = 8042,
      list = {
        CHS[4200207],
        CHS[4200208],
        CHS[4200209],
        CHS[4200210],
        CHS[4200211]
      }
    },
    {
      name = CHS[7000045],
      icon = 8061,
      list = {
        CHS[4200207],
        CHS[4200208],
        CHS[4200209],
        CHS[4200210],
        CHS[4200211],
        CHS[4100553],
        CHS[2000748]
      }
    },
    {
      name = CHS[7000120],
      icon = 8043
    },
    {
      name = CHS[7000207],
      icon = 9086,
      list = {
        CHS[7000121],
        CHS[7000122],
        CHS[7000123],
        CHS[7000124]
      }
    },
    {
      name = "时装",
      icon = 9502,
      list = {
        "30天时装",
        "90天时装",
        "永久时装"
      }
    },
    {
      name = "洗点道具",
      icon = 9004,
      list = {
        "易经洗髓丹",
        "五行合缘露",
        "仙魔散"
      }
    },
    {
      name = CHS[5420176],
      icon = 10051,
      list = {
        CHS[7100032],
        CHS[7100033],
        CHS[7100034]
      }
    },
    {
      name = "家具材料",
      icon = 7504,
      list = {
        "树漆",
        "石材",
        "黄金",
        "锦缎",
        "玉料"
      }
    },
    {name = "喇叭", icon = 9176},
    {
      name = "冥海神光",
      icon = 2135
    }
  },
  [CHS[3001300]] = {
    {
      name = CHS[3001222],
      list = {
        20,
        35,
        50,
        60,
        70
      },
      icon = 1309
    },
    {
      name = CHS[3001223],
      list = {
        20,
        35,
        50,
        60,
        70
      },
      icon = 1301
    },
    {
      name = CHS[3001224],
      list = {
        20,
        35,
        50,
        60,
        70
      },
      icon = 1317
    }
  },
  [CHS[4100000]] = {
    {
      name = CHS[4100087],
      list = {
        CHS[6200027],
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338]
      },
      icon = 8129
    },
    {
      name = CHS[4100088],
      list = {
        CHS[6200027],
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338]
      },
      icon = 8306
    },
    {
      name = CHS[4100089],
      list = {
        CHS[6200027],
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338]
      },
      icon = 8318
    },
    {
      name = "神兽变身卡",
      list = {
        CHS[6200027],
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338]
      },
      icon = 8302
    }
  },
  ["娃娃玩具"] = {
    {
      name = "竹马",
      list = {
        "蓝色",
        "紫色",
        "金色"
      },
      icon = 2126
    },
    {
      name = "毽子",
      list = {
        "蓝色",
        "紫色",
        "金色"
      },
      icon = 2127
    },
    {
      name = "蹴球",
      list = {
        "蓝色",
        "紫色",
        "金色"
      },
      icon = 2128
    },
    {
      name = "弹弓",
      list = {
        "蓝色",
        "紫色",
        "金色"
      },
      icon = 2129
    },
    {
      name = "陀螺",
      list = {
        "蓝色",
        "紫色",
        "金色"
      },
      icon = 2130
    },
    {
      name = "风筝",
      list = {
        "蓝色",
        "紫色",
        "金色"
      },
      icon = 2131
    }
  },
  [CHS[7000144]] = {
    {
      name = CHS[7000138],
      icon = 1410,
      list = {
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338],
        sellType = 1
      }
    },
    {
      name = CHS[7000143],
      icon = 1415,
      list = {
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338],
        sellType = 1
      }
    },
    {
      name = CHS[7000137],
      icon = 1409,
      list = {
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338],
        sellType = 1
      }
    },
    {
      name = CHS[7000139],
      icon = 1411,
      list = {
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338],
        sellType = 1
      }
    },
    {
      name = CHS[7000140],
      icon = 1412,
      list = {
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338],
        sellType = 1
      }
    },
    {
      name = CHS[7000141],
      icon = 1413,
      list = {
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338],
        sellType = 1
      }
    },
    {
      name = CHS[7000142],
      icon = 1414,
      list = {
        CHS[3000334],
        CHS[3000335],
        CHS[3000336],
        CHS[3000337],
        CHS[3000338],
        sellType = 1
      }
    }
  },
  [CHS[7190683]] = {
    {
      name = CHS[7190701],
      icon = 1420,
      sellType = 3
    },
    {
      name = CHS[7190649],
      icon = 1420
    },
    {
      name = CHS[7190650],
      icon = 1421
    },
    {
      name = CHS[7190651],
      icon = 1422
    },
    {
      name = CHS[7190652],
      icon = 1423
    },
    {
      name = CHS[7190653],
      icon = 1424
    },
    {
      name = CHS[7190654],
      icon = 1425
    },
    {
      name = CHS[7190655],
      icon = 1426
    },
    {
      name = CHS[7190656],
      icon = 1427
    },
    {
      name = CHS[7190657],
      icon = 1428
    }
  },
  [CHS[2000369]] = {
    {
      name = CHS[2000370],
      icon = 14001,
      list = {
        CHS[2000373],
        CHS[2000374],
        CHS[2000375]
      }
    },
    {
      name = CHS[2000376],
      icon = 14006,
      list = {
        CHS[2000373],
        CHS[2000374],
        CHS[2000375]
      }
    },
    {
      name = CHS[2000377],
      icon = 14011,
      list = {
        CHS[2000371],
        CHS[2000372]
      }
    },
    {
      name = CHS[2000378],
      icon = 14013,
      list = {
        CHS[2000371],
        CHS[2000372],
        CHS[2000373],
        CHS[2000374]
      }
    },
    {
      name = CHS[2000379],
      icon = 14017,
      list = {
        CHS[2000371],
        CHS[2000372],
        CHS[2000373],
        CHS[2000374]
      }
    }
  },
  ["金钱"] = {},
  ["太阴之气"] = {
    {
      name = "太阴之气",
      icon = 2137,
      list = {
        "蓝色品质",
        "粉色品质",
        "金色品质"
      }
    }
  },
  ["飞行法宝"] = {
    {
      name = "梦荷部件",
      icon = 1451,
      list = {
        "梦荷·震位",
        "梦荷·离位",
        "梦荷·兑位"
      }
    },
    {name = "梦荷", icon = 1454},
    {name = "御天梭", icon = 1455},
    {
      name = "魔炎飞甲",
      icon = 1456,
      list = {"已启灵", "未启灵"}
    },
    {
      name = "墨舞青云",
      icon = 1458,
      list = {"已启灵", "未启灵"}
    }
  }
}
