return {
  [1] = {
    icon = 10600,
    r = 1,
    c = 1,
    layer = 1
  },
  [2] = {
    icon = 10601,
    r = 1,
    c = 1,
    layer = 1
  },
  [3] = {
    icon = 10602,
    r = 1,
    c = 1,
    layer = 1
  },
  [4] = {
    icon = 10603,
    r = 1,
    c = 1,
    layer = 1
  },
  [5] = {
    icon = 10604,
    r = 1,
    c = 1,
    layer = 1
  },
  [6] = {
    icon = 10605,
    r = 2,
    c = 2,
    layer = 2
  },
  [7] = {
    icon = 10606,
    r = 1,
    c = 1,
    layer = 1
  },
  [8] = {
    icon = 10607,
    r = 1,
    c = 2,
    layer = 1
  },
  [9] = {
    icon = 10608,
    r = 1,
    c = 2,
    layer = 1
  },
  [10] = {
    icon = 10609,
    r = 3,
    c = 3,
    layer = 1
  },
  [11] = {
    icon = 10610,
    r = 1,
    c = 3,
    layer = 1
  },
  [12] = {
    icon = 10611,
    r = 1,
    c = 3,
    layer = 1
  },
  [13] = {
    icon = 10612,
    r = 2,
    c = 3,
    layer = 1
  },
  [14] = {
    icon = 10613,
    r = 1,
    c = 3,
    layer = 1
  },
  [15] = {
    icon = 10614,
    r = 1,
    c = 4,
    layer = 1
  },
  [16] = {
    icon = 10615,
    r = 2,
    c = 4,
    layer = 1
  },
  [17] = {
    icon = 10616,
    r = 1,
    c = 4,
    layer = 1
  },
  [18] = {
    icon = 10617,
    r = 1,
    c = 4,
    layer = 1
  },
  [19] = {
    icon = 10618,
    r = 1,
    c = 4,
    layer = 1
  },
  [20] = {
    icon = 10619,
    r = 2,
    c = 4,
    layer = 1
  },
  [21] = {
    icon = 10620,
    r = 2,
    c = 5,
    layer = 1
  },
  [22] = {
    icon = 10621,
    r = 5,
    c = 5,
    layer = 1
  },
  [23] = {
    icon = 10622,
    r = 4,
    c = 4,
    layer = 1
  },
  [24] = {
    icon = 10623,
    r = 3,
    c = 6,
    layer = 2
  },
  [25] = {
    icon = 10624,
    r = 3,
    c = 6,
    layer = 1
  },
  [26] = {
    icon = 10700,
    r = 1,
    c = 1,
    layer = 2
  },
  [27] = {
    icon = 10701,
    r = 1,
    c = 1,
    layer = 2
  },
  [28] = {
    icon = 10702,
    r = 1,
    c = 1,
    layer = 2
  },
  [29] = {
    icon = 10703,
    r = 1,
    c = 1,
    layer = 1
  },
  [30] = {
    icon = 10704,
    r = 1,
    c = 1,
    layer = 1
  },
  [31] = {
    icon = 10705,
    r = 1,
    c = 1,
    layer = 1
  },
  [32] = {
    icon = 10706,
    r = 1,
    c = 2,
    layer = 2
  },
  [33] = {
    icon = 10707,
    r = 1,
    c = 2,
    layer = 2
  },
  [34] = {
    icon = 10708,
    r = 1,
    c = 2,
    layer = 2
  },
  [35] = {
    icon = 10520,
    r = 2,
    c = 4,
    layer = 1
  },
  [36] = {
    icon = 10500,
    r = 1,
    c = 1,
    layer = 1
  },
  [37] = {
    icon = 10501,
    r = 1,
    c = 1,
    layer = 1
  },
  [38] = {
    icon = 10502,
    r = 1,
    c = 1,
    layer = 1
  },
  [39] = {
    icon = 10503,
    r = 1,
    c = 1,
    layer = 1
  },
  [40] = {
    icon = 10504,
    r = 1,
    c = 1,
    layer = 1
  },
  [41] = {
    icon = 10505,
    r = 1,
    c = 2,
    layer = 1
  },
  [42] = {
    icon = 10506,
    r = 1,
    c = 2,
    layer = 1
  },
  [43] = {
    icon = 10507,
    r = 1,
    c = 2,
    layer = 1
  },
  [44] = {
    icon = 10508,
    r = 1,
    c = 2,
    layer = 1
  },
  [45] = {
    icon = 10509,
    r = 1,
    c = 2,
    layer = 1
  },
  [46] = {
    icon = 10510,
    r = 1,
    c = 2,
    layer = 1
  },
  [47] = {
    icon = 10511,
    r = 2,
    c = 2,
    layer = 1
  },
  [48] = {
    icon = 10512,
    r = 2,
    c = 2,
    layer = 1
  },
  [49] = {
    icon = 10513,
    r = 2,
    c = 2,
    layer = 1
  },
  [50] = {
    icon = 10514,
    r = 2,
    c = 2,
    layer = 1
  },
  [51] = {
    icon = 10515,
    r = 2,
    c = 2,
    layer = 1
  },
  [52] = {
    icon = 10516,
    r = 2,
    c = 3,
    layer = 1
  },
  [53] = {
    icon = 10517,
    r = 2,
    c = 3,
    layer = 1
  },
  [54] = {
    icon = 10518,
    r = 2,
    c = 3,
    layer = 1
  },
  [55] = {
    icon = 10519,
    r = 2,
    c = 3,
    layer = 1
  },
  [56] = {
    icon = 10521,
    r = 2,
    c = 2,
    layer = 1
  },
  [57] = {
    icon = 10625,
    r = 3,
    c = 3,
    layer = 1
  }
}
