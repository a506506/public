return {
  ["白豆腐"] = {
    keyName = "白豆腐",
    showName = "白豆腐",
    icon = 14100,
    ui_icon = 2903,
    level = 1,
    shicai = {
      {
        ["黄豆"] = 1
      }
    },
    level_count = 1,
    cook_exp = 1,
    unlock_exp = 0,
    order = 0
  },
  ["白灼虾"] = {
    keyName = "白灼虾",
    showName = "白灼虾",
    icon = 14101,
    ui_icon = 2904,
    level = 2,
    shicai = {
      {
        ["虾"] = 1
      }
    },
    level_count = 2,
    cook_exp = 2,
    unlock_exp = 10,
    order = 1
  },
  ["豆皮卷"] = {
    keyName = "豆皮卷",
    showName = "豆皮卷",
    icon = 14102,
    ui_icon = 2928,
    level = 2,
    shicai = {
      {
        ["黄豆"] = 1
      },
      {
        ["葱"] = 1
      }
    },
    level_count = 3,
    cook_exp = 3,
    unlock_exp = 15,
    order = 2
  },
  ["上汤娃娃菜"] = {
    keyName = "上汤娃娃菜",
    showName = "上汤娃娃菜",
    icon = 14103,
    ui_icon = 2918,
    level = 3,
    shicai = {
      {
        ["姜"] = 1
      },
      {
        ["娃娃菜"] = 2
      }
    },
    level_count = 9,
    cook_exp = 13,
    unlock_exp = 65,
    order = 3
  },
  ["虾仁玉米"] = {
    keyName = "虾仁玉米",
    showName = "虾仁玉米",
    icon = 14104,
    ui_icon = 2905,
    level = 3,
    shicai = {
      {
        ["虾"] = 3
      },
      {
        ["玉米"] = 1
      }
    },
    level_count = 9,
    cook_exp = 13,
    unlock_exp = 65,
    order = 4
  },
  ["脆香黄豆面"] = {
    keyName = "脆香黄豆面",
    showName = "脆香黄豆面",
    icon = 14105,
    ui_icon = 2913,
    level = 4,
    shicai = {
      {
        ["黄豆"] = 3
      },
      {
        ["花生"] = 1
      }
    },
    level_count = 7,
    cook_exp = 14,
    unlock_exp = 70,
    order = 5
  },
  ["麻婆豆腐"] = {
    keyName = "麻婆豆腐",
    showName = "麻婆豆腐",
    icon = 14106,
    ui_icon = 2910,
    level = 4,
    shicai = {
      {
        ["辣椒"] = 1
      },
      {
        ["黄豆"] = 2
      },
      {
        ["花椒"] = 1
      }
    },
    level_count = 10,
    cook_exp = 20,
    unlock_exp = 100,
    order = 6
  },
  ["香菇油菜"] = {
    keyName = "香菇油菜",
    showName = "香菇油菜",
    icon = 14107,
    ui_icon = 2906,
    level = 5,
    shicai = {
      {
        ["香菇"] = 2
      },
      {
        ["青菜"] = 3
      }
    },
    level_count = 25,
    cook_exp = 62,
    unlock_exp = 310,
    order = 7
  },
  ["白切鸡"] = {
    keyName = "白切鸡",
    showName = "白切鸡",
    icon = 14108,
    ui_icon = 2916,
    level = 5,
    shicai = {
      {
        ["鸡肉"] = 3
      },
      {
        ["葱"] = 1
      },
      {
        ["姜"] = 1
      }
    },
    level_count = 20,
    cook_exp = 50,
    unlock_exp = 250,
    order = 8
  },
  ["葱姜烧鸽"] = {
    keyName = "葱姜烧鸽",
    showName = "葱姜烧鸽",
    icon = 14109,
    ui_icon = 2917,
    level = 5,
    shicai = {
      {
        ["乳鸽"] = 1
      },
      {
        ["葱"] = 3
      },
      {
        ["姜"] = 3
      }
    },
    level_count = 20,
    cook_exp = 50,
    unlock_exp = 250,
    order = 9
  },
  ["宫保鸡丁"] = {
    keyName = "宫保鸡丁",
    showName = "宫保鸡丁",
    icon = 14110,
    ui_icon = 2914,
    level = 6,
    shicai = {
      {
        ["鸡肉"] = 2
      },
      {
        ["花生"] = 1
      },
      {
        ["辣椒"] = 1
      }
    },
    level_count = 18,
    cook_exp = 54,
    unlock_exp = 270,
    order = 10
  },
  ["梅菜扣肉"] = {
    keyName = "梅菜扣肉",
    showName = "梅菜扣肉",
    icon = 14111,
    ui_icon = 2921,
    level = 6,
    shicai = {
      {
        ["猪肉"] = 3
      },
      {
        ["梅菜"] = 1
      }
    },
    level_count = 24,
    cook_exp = 72,
    unlock_exp = 360,
    order = 11
  },
  ["猪肉炖鸡"] = {
    keyName = "猪肉炖鸡",
    showName = "猪肉炖鸡",
    icon = 14112,
    ui_icon = 2907,
    level = 6,
    shicai = {
      {
        ["猪肉"] = 2
      },
      {
        ["鸡肉"] = 2
      }
    },
    level_count = 22,
    cook_exp = 66,
    unlock_exp = 330,
    order = 12
  },
  ["红烧狮子头"] = {
    keyName = "红烧狮子头",
    showName = "红烧狮子头",
    icon = 14113,
    ui_icon = 2926,
    level = 7,
    shicai = {
      {
        ["猪肉"] = 3
      },
      {
        ["香菇"] = 1
      },
      {
        ["青菜"] = 1
      }
    },
    level_count = 28,
    cook_exp = 98,
    unlock_exp = 490,
    order = 13
  },
  ["回锅肉"] = {
    keyName = "回锅肉",
    showName = "回锅肉",
    icon = 14114,
    ui_icon = 2911,
    level = 7,
    shicai = {
      {
        ["猪肉"] = 3
      },
      {
        ["青椒"] = 1
      },
      {
        ["蒜苗"] = 1
      }
    },
    level_count = 32,
    cook_exp = 112,
    unlock_exp = 560,
    order = 14
  },
  ["鱼香肉丝"] = {
    keyName = "鱼香肉丝",
    showName = "鱼香肉丝",
    icon = 14115,
    ui_icon = 2915,
    level = 7,
    shicai = {
      {
        ["猪肉"] = 2
      },
      {
        ["木耳"] = 2
      },
      {
        ["莴笋"] = 1
      }
    },
    level_count = 33,
    cook_exp = 115,
    unlock_exp = 575,
    order = 15
  },
  ["凉拌牛肉"] = {
    keyName = "凉拌牛肉",
    showName = "凉拌牛肉",
    icon = 14116,
    ui_icon = 2912,
    level = 8,
    shicai = {
      {
        ["牛肉"] = 3
      },
      {
        ["辣椒"] = 2
      }
    },
    level_count = 32,
    cook_exp = 128,
    unlock_exp = 640,
    order = 16
  },
  ["萝卜牛腩煲"] = {
    keyName = "萝卜牛腩煲",
    showName = "萝卜牛腩煲",
    icon = 14117,
    ui_icon = 2919,
    level = 8,
    shicai = {
      {
        ["牛肉"] = 2
      },
      {
        ["大白萝卜"] = 1
      },
      {
        ["八角"] = 1
      }
    },
    level_count = 32,
    cook_exp = 128,
    unlock_exp = 640,
    order = 17
  },
  ["青椒蒸鱼"] = {
    keyName = "青椒蒸鱼",
    showName = "青椒蒸鱼",
    icon = 14118,
    ui_icon = 2925,
    level = 8,
    shicai = {
      {
        ["鱼"] = 3
      },
      {
        ["青椒"] = 1
      }
    },
    level_count = 31,
    cook_exp = 124,
    unlock_exp = 620,
    order = 18
  },
  ["茄汁鱼丸"] = {
    keyName = "茄汁鱼丸",
    showName = "茄汁鱼丸",
    icon = 14016,
    ui_icon = 2929,
    level = 9,
    shicai = {
      {
        ["鱼"] = 2
      },
      {
        ["西红柿"] = 2
      }
    },
    level_count = 34,
    cook_exp = 153,
    unlock_exp = 765,
    order = 19
  },
  ["螃蟹粉丝煲"] = {
    keyName = "螃蟹粉丝煲",
    showName = "螃蟹粉丝煲",
    icon = 14119,
    ui_icon = 2908,
    level = 9,
    shicai = {
      {
        ["蟹"] = 2
      },
      {
        ["粉丝"] = 1
      },
      {
        ["姜"] = 1
      }
    },
    level_count = 30,
    cook_exp = 135,
    unlock_exp = 675,
    order = 20
  },
  ["金瓜螃蟹汤"] = {
    keyName = "金瓜螃蟹汤",
    showName = "金瓜螃蟹汤",
    icon = 14120,
    ui_icon = 2909,
    level = 9,
    shicai = {
      {
        ["蟹"] = 2
      },
      {
        ["南瓜"] = 1
      },
      {
        ["姜"] = 1
      }
    },
    level_count = 30,
    cook_exp = 135,
    unlock_exp = 675,
    order = 21
  },
  ["油焖小龙虾"] = {
    keyName = "油焖小龙虾",
    showName = "油焖小龙虾",
    icon = 14121,
    ui_icon = 2924,
    level = 10,
    shicai = {
      {
        ["小龙虾"] = 3
      },
      {
        ["葱"] = 1
      },
      {
        ["姜"] = 1
      }
    },
    level_count = 35,
    cook_exp = 175,
    unlock_exp = 875,
    order = 22
  },
  ["葱烧海参"] = {
    keyName = "葱烧海参",
    showName = "葱烧海参",
    icon = 14122,
    ui_icon = 2922,
    level = 10,
    shicai = {
      {
        ["海参"] = 3
      },
      {
        ["葱"] = 2
      }
    },
    level_count = 34,
    cook_exp = 170,
    unlock_exp = 850,
    order = 23
  },
  ["佛跳墙"] = {
    keyName = "佛跳墙",
    showName = "佛跳墙",
    icon = 14123,
    ui_icon = 2923,
    level = 10,
    shicai = {
      {
        ["鲍鱼"] = 1
      },
      {
        ["海参"] = 1
      },
      {
        ["鱼翅"] = 2
      }
    },
    level_count = 40,
    cook_exp = 200,
    unlock_exp = 1000,
    order = 24
  }
}
