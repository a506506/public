return {
  [1] = {
    shouling = {max_life = 800, phy_power = 80},
    xvcheng = {def = 400, mag_power = 80},
    weiming = {phy_power = 240, mag_power = 240},
    taiming = {speed = 120},
    hunting = {phy_power = 480},
    yvying = {mag_power = 480}
  },
  [2] = {
    shouling = {max_life = 1200, phy_power = 120},
    xvcheng = {def = 600, mag_power = 120},
    weiming = {phy_power = 360, mag_power = 360},
    taiming = {speed = 160},
    hunting = {phy_power = 720},
    yvying = {mag_power = 720}
  },
  [3] = {
    shouling = {max_life = 1600, phy_power = 160},
    xvcheng = {def = 800, mag_power = 160},
    weiming = {phy_power = 480, mag_power = 480},
    taiming = {speed = 200},
    hunting = {phy_power = 960},
    yvying = {mag_power = 960}
  },
  [4] = {
    shouling = {max_life = 2000, phy_power = 200},
    xvcheng = {def = 1000, mag_power = 200},
    weiming = {phy_power = 600, mag_power = 600},
    taiming = {speed = 240},
    hunting = {phy_power = 1200},
    yvying = {mag_power = 1200}
  },
  [5] = {
    shouling = {max_life = 2400, phy_power = 240},
    xvcheng = {def = 1200, mag_power = 240},
    weiming = {phy_power = 720, mag_power = 720},
    taiming = {speed = 280},
    hunting = {phy_power = 1440},
    yvying = {mag_power = 1440}
  },
  [6] = {
    shouling = {max_life = 2800, phy_power = 280},
    xvcheng = {def = 1400, mag_power = 280},
    weiming = {phy_power = 840, mag_power = 840},
    taiming = {speed = 320},
    hunting = {phy_power = 1680},
    yvying = {mag_power = 1680}
  },
  [7] = {
    shouling = {max_life = 3200, phy_power = 320},
    xvcheng = {def = 1600, mag_power = 320},
    weiming = {phy_power = 960, mag_power = 960},
    taiming = {speed = 360},
    hunting = {phy_power = 1920},
    yvying = {mag_power = 1920}
  },
  [8] = {
    shouling = {max_life = 3600, phy_power = 360},
    xvcheng = {def = 1800, mag_power = 360},
    weiming = {phy_power = 1080, mag_power = 1080},
    taiming = {speed = 400},
    hunting = {phy_power = 2160},
    yvying = {mag_power = 2160}
  },
  [9] = {
    shouling = {max_life = 4000, phy_power = 400},
    xvcheng = {def = 2000, mag_power = 400},
    weiming = {phy_power = 1200, mag_power = 1200},
    taiming = {speed = 440},
    hunting = {phy_power = 2400},
    yvying = {mag_power = 2400}
  },
  [10] = {
    shouling = {max_life = 4400, phy_power = 440},
    xvcheng = {def = 2200, mag_power = 440},
    weiming = {phy_power = 1320, mag_power = 1320},
    taiming = {speed = 480},
    hunting = {phy_power = 2640},
    yvying = {mag_power = 2640}
  },
  [11] = {
    shouling = {max_life = 4800, phy_power = 480},
    xvcheng = {def = 2400, mag_power = 480},
    weiming = {phy_power = 1440, mag_power = 1440},
    taiming = {speed = 520},
    hunting = {phy_power = 2880},
    yvying = {mag_power = 2880}
  },
  [12] = {
    shouling = {max_life = 5200, phy_power = 520},
    xvcheng = {def = 2600, mag_power = 520},
    weiming = {phy_power = 1560, mag_power = 1560},
    taiming = {speed = 560},
    hunting = {phy_power = 3120},
    yvying = {mag_power = 3120}
  },
  [13] = {
    shouling = {max_life = 5600, phy_power = 560},
    xvcheng = {def = 2800, mag_power = 560},
    weiming = {phy_power = 1680, mag_power = 1680},
    taiming = {speed = 600},
    hunting = {phy_power = 3360},
    yvying = {mag_power = 3360}
  },
  [14] = {
    shouling = {max_life = 6000, phy_power = 600},
    xvcheng = {def = 3000, mag_power = 600},
    weiming = {phy_power = 1800, mag_power = 1800},
    taiming = {speed = 640},
    hunting = {phy_power = 3600},
    yvying = {mag_power = 3600}
  },
  [15] = {
    shouling = {max_life = 6400, phy_power = 640},
    xvcheng = {def = 3200, mag_power = 640},
    weiming = {phy_power = 1920, mag_power = 1920},
    taiming = {speed = 680},
    hunting = {phy_power = 3840},
    yvying = {mag_power = 3840}
  },
  [16] = {
    shouling = {max_life = 6800, phy_power = 680},
    xvcheng = {def = 3400, mag_power = 680},
    weiming = {phy_power = 2040, mag_power = 2040},
    taiming = {speed = 720},
    hunting = {phy_power = 4080},
    yvying = {mag_power = 4080}
  },
  [17] = {
    shouling = {max_life = 7200, phy_power = 720},
    xvcheng = {def = 3600, mag_power = 720},
    weiming = {phy_power = 2160, mag_power = 2160},
    taiming = {speed = 760},
    hunting = {phy_power = 4320},
    yvying = {mag_power = 4320}
  },
  [18] = {
    shouling = {max_life = 7600, phy_power = 760},
    xvcheng = {def = 3800, mag_power = 760},
    weiming = {phy_power = 2280, mag_power = 2280},
    taiming = {speed = 800},
    hunting = {phy_power = 4560},
    yvying = {mag_power = 4560}
  },
  [19] = {
    shouling = {max_life = 8000, phy_power = 800},
    xvcheng = {def = 4000, mag_power = 800},
    weiming = {phy_power = 2400, mag_power = 2400},
    taiming = {speed = 840},
    hunting = {phy_power = 4800},
    yvying = {mag_power = 4800}
  },
  [20] = {
    shouling = {max_life = 8400, phy_power = 840},
    xvcheng = {def = 4200, mag_power = 840},
    weiming = {phy_power = 2520, mag_power = 2520},
    taiming = {speed = 880},
    hunting = {phy_power = 5040},
    yvying = {mag_power = 5040}
  },
  [21] = {
    shouling = {max_life = 8800, phy_power = 880},
    xvcheng = {def = 4400, mag_power = 880},
    weiming = {phy_power = 2640, mag_power = 2640},
    taiming = {speed = 920},
    hunting = {phy_power = 5280},
    yvying = {mag_power = 5280}
  },
  [22] = {
    shouling = {max_life = 9200, phy_power = 920},
    xvcheng = {def = 4600, mag_power = 920},
    weiming = {phy_power = 2760, mag_power = 2760},
    taiming = {speed = 960},
    hunting = {phy_power = 5520},
    yvying = {mag_power = 5520}
  },
  [23] = {
    shouling = {max_life = 9600, phy_power = 960},
    xvcheng = {def = 4800, mag_power = 960},
    weiming = {phy_power = 2880, mag_power = 2880},
    taiming = {speed = 1000},
    hunting = {phy_power = 5760},
    yvying = {mag_power = 5760}
  },
  [24] = {
    shouling = {max_life = 10000, phy_power = 1000},
    xvcheng = {def = 5000, mag_power = 1000},
    weiming = {phy_power = 3000, mag_power = 3000},
    taiming = {speed = 1040},
    hunting = {phy_power = 6000},
    yvying = {mag_power = 6000}
  },
  [25] = {
    shouling = {max_life = 10400, phy_power = 1040},
    xvcheng = {def = 5200, mag_power = 1040},
    weiming = {phy_power = 3120, mag_power = 3120},
    taiming = {speed = 1080},
    hunting = {phy_power = 6240},
    yvying = {mag_power = 6240}
  },
  [26] = {
    shouling = {max_life = 10800, phy_power = 1080},
    xvcheng = {def = 5400, mag_power = 1080},
    weiming = {phy_power = 3240, mag_power = 3240},
    taiming = {speed = 1120},
    hunting = {phy_power = 6480},
    yvying = {mag_power = 6480}
  },
  [27] = {
    shouling = {max_life = 11200, phy_power = 1120},
    xvcheng = {def = 5600, mag_power = 1120},
    weiming = {phy_power = 3360, mag_power = 3360},
    taiming = {speed = 1160},
    hunting = {phy_power = 6720},
    yvying = {mag_power = 6720}
  },
  [28] = {
    shouling = {max_life = 11600, phy_power = 1160},
    xvcheng = {def = 5800, mag_power = 1160},
    weiming = {phy_power = 3480, mag_power = 3480},
    taiming = {speed = 1200},
    hunting = {phy_power = 6960},
    yvying = {mag_power = 6960}
  },
  [29] = {
    shouling = {max_life = 12000, phy_power = 1200},
    xvcheng = {def = 6000, mag_power = 1200},
    weiming = {phy_power = 3600, mag_power = 3600},
    taiming = {speed = 1240},
    hunting = {phy_power = 7200},
    yvying = {mag_power = 7200}
  },
  [30] = {
    shouling = {max_life = 12400, phy_power = 1240},
    xvcheng = {def = 6200, mag_power = 1240},
    weiming = {phy_power = 3720, mag_power = 3720},
    taiming = {speed = 1280},
    hunting = {phy_power = 7440},
    yvying = {mag_power = 7440}
  },
  [31] = {
    shouling = {max_life = 12800, phy_power = 1280},
    xvcheng = {def = 6400, mag_power = 1280},
    weiming = {phy_power = 3840, mag_power = 3840},
    taiming = {speed = 1320},
    hunting = {phy_power = 7680},
    yvying = {mag_power = 7680}
  },
  [32] = {
    shouling = {max_life = 13200, phy_power = 1320},
    xvcheng = {def = 6600, mag_power = 1320},
    weiming = {phy_power = 3960, mag_power = 3960},
    taiming = {speed = 1360},
    hunting = {phy_power = 7920},
    yvying = {mag_power = 7920}
  },
  [33] = {
    shouling = {max_life = 13600, phy_power = 1360},
    xvcheng = {def = 6800, mag_power = 1360},
    weiming = {phy_power = 4080, mag_power = 4080},
    taiming = {speed = 1400},
    hunting = {phy_power = 8160},
    yvying = {mag_power = 8160}
  },
  [34] = {
    shouling = {max_life = 14000, phy_power = 1400},
    xvcheng = {def = 7000, mag_power = 1400},
    weiming = {phy_power = 4200, mag_power = 4200},
    taiming = {speed = 1440},
    hunting = {phy_power = 8400},
    yvying = {mag_power = 8400}
  },
  [35] = {
    shouling = {max_life = 14400, phy_power = 1440},
    xvcheng = {def = 7200, mag_power = 1440},
    weiming = {phy_power = 4320, mag_power = 4320},
    taiming = {speed = 1480},
    hunting = {phy_power = 8640},
    yvying = {mag_power = 8640}
  },
  [36] = {
    shouling = {max_life = 14800, phy_power = 1480},
    xvcheng = {def = 7400, mag_power = 1480},
    weiming = {phy_power = 4440, mag_power = 4440},
    taiming = {speed = 1520},
    hunting = {phy_power = 8880},
    yvying = {mag_power = 8880}
  },
  [37] = {
    shouling = {max_life = 15200, phy_power = 1520},
    xvcheng = {def = 7600, mag_power = 1520},
    weiming = {phy_power = 4560, mag_power = 4560},
    taiming = {speed = 1560},
    hunting = {phy_power = 9120},
    yvying = {mag_power = 9120}
  },
  [38] = {
    shouling = {max_life = 15600, phy_power = 1560},
    xvcheng = {def = 7800, mag_power = 1560},
    weiming = {phy_power = 4680, mag_power = 4680},
    taiming = {speed = 1600},
    hunting = {phy_power = 9360},
    yvying = {mag_power = 9360}
  },
  [39] = {
    shouling = {max_life = 16000, phy_power = 1600},
    xvcheng = {def = 8000, mag_power = 1600},
    weiming = {phy_power = 4800, mag_power = 4800},
    taiming = {speed = 1640},
    hunting = {phy_power = 9600},
    yvying = {mag_power = 9600}
  },
  [40] = {
    shouling = {max_life = 16400, phy_power = 1640},
    xvcheng = {def = 8200, mag_power = 1640},
    weiming = {phy_power = 4920, mag_power = 4920},
    taiming = {speed = 1680},
    hunting = {phy_power = 9840},
    yvying = {mag_power = 9840}
  },
  [41] = {
    shouling = {max_life = 16800, phy_power = 1680},
    xvcheng = {def = 8400, mag_power = 1680},
    weiming = {phy_power = 5040, mag_power = 5040},
    taiming = {speed = 1720},
    hunting = {phy_power = 10080},
    yvying = {mag_power = 10080}
  },
  [42] = {
    shouling = {max_life = 17200, phy_power = 1720},
    xvcheng = {def = 8600, mag_power = 1720},
    weiming = {phy_power = 5160, mag_power = 5160},
    taiming = {speed = 1760},
    hunting = {phy_power = 10320},
    yvying = {mag_power = 10320}
  },
  [43] = {
    shouling = {max_life = 17600, phy_power = 1760},
    xvcheng = {def = 8800, mag_power = 1760},
    weiming = {phy_power = 5280, mag_power = 5280},
    taiming = {speed = 1800},
    hunting = {phy_power = 10560},
    yvying = {mag_power = 10560}
  },
  [44] = {
    shouling = {max_life = 18000, phy_power = 1800},
    xvcheng = {def = 9000, mag_power = 1800},
    weiming = {phy_power = 5400, mag_power = 5400},
    taiming = {speed = 1840},
    hunting = {phy_power = 10800},
    yvying = {mag_power = 10800}
  },
  [45] = {
    shouling = {max_life = 18400, phy_power = 1840},
    xvcheng = {def = 9200, mag_power = 1840},
    weiming = {phy_power = 5520, mag_power = 5520},
    taiming = {speed = 1880},
    hunting = {phy_power = 11040},
    yvying = {mag_power = 11040}
  },
  [46] = {
    shouling = {max_life = 18800, phy_power = 1880},
    xvcheng = {def = 9400, mag_power = 1880},
    weiming = {phy_power = 5640, mag_power = 5640},
    taiming = {speed = 1920},
    hunting = {phy_power = 11280},
    yvying = {mag_power = 11280}
  },
  [47] = {
    shouling = {max_life = 19200, phy_power = 1920},
    xvcheng = {def = 9600, mag_power = 1920},
    weiming = {phy_power = 5760, mag_power = 5760},
    taiming = {speed = 1960},
    hunting = {phy_power = 11520},
    yvying = {mag_power = 11520}
  },
  [48] = {
    shouling = {max_life = 19600, phy_power = 1960},
    xvcheng = {def = 9800, mag_power = 1960},
    weiming = {phy_power = 5880, mag_power = 5880},
    taiming = {speed = 2000},
    hunting = {phy_power = 11760},
    yvying = {mag_power = 11760}
  },
  [49] = {
    shouling = {max_life = 20000, phy_power = 2000},
    xvcheng = {def = 10000, mag_power = 2000},
    weiming = {phy_power = 6000, mag_power = 6000},
    taiming = {speed = 2040},
    hunting = {phy_power = 12000},
    yvying = {mag_power = 12000}
  },
  [50] = {
    shouling = {max_life = 20400, phy_power = 2040},
    xvcheng = {def = 10200, mag_power = 2040},
    weiming = {phy_power = 6120, mag_power = 6120},
    taiming = {speed = 2080},
    hunting = {phy_power = 12240},
    yvying = {mag_power = 12240}
  },
  [51] = {
    shouling = {max_life = 20800, phy_power = 2080},
    xvcheng = {def = 10400, mag_power = 2080},
    weiming = {phy_power = 6240, mag_power = 6240},
    taiming = {speed = 2120},
    hunting = {phy_power = 12480},
    yvying = {mag_power = 12480}
  },
  [52] = {
    shouling = {max_life = 21200, phy_power = 2120},
    xvcheng = {def = 10600, mag_power = 2120},
    weiming = {phy_power = 6360, mag_power = 6360},
    taiming = {speed = 2160},
    hunting = {phy_power = 12720},
    yvying = {mag_power = 12720}
  },
  [53] = {
    shouling = {max_life = 21600, phy_power = 2160},
    xvcheng = {def = 10800, mag_power = 2160},
    weiming = {phy_power = 6480, mag_power = 6480},
    taiming = {speed = 2200},
    hunting = {phy_power = 12960},
    yvying = {mag_power = 12960}
  },
  [54] = {
    shouling = {max_life = 22000, phy_power = 2200},
    xvcheng = {def = 11000, mag_power = 2200},
    weiming = {phy_power = 6600, mag_power = 6600},
    taiming = {speed = 2240},
    hunting = {phy_power = 13200},
    yvying = {mag_power = 13200}
  },
  [55] = {
    shouling = {max_life = 22400, phy_power = 2240},
    xvcheng = {def = 11200, mag_power = 2240},
    weiming = {phy_power = 6720, mag_power = 6720},
    taiming = {speed = 2280},
    hunting = {phy_power = 13440},
    yvying = {mag_power = 13440}
  },
  [56] = {
    shouling = {max_life = 22800, phy_power = 2280},
    xvcheng = {def = 11400, mag_power = 2280},
    weiming = {phy_power = 6840, mag_power = 6840},
    taiming = {speed = 2320},
    hunting = {phy_power = 13680},
    yvying = {mag_power = 13680}
  },
  [57] = {
    shouling = {max_life = 23200, phy_power = 2320},
    xvcheng = {def = 11600, mag_power = 2320},
    weiming = {phy_power = 6960, mag_power = 6960},
    taiming = {speed = 2360},
    hunting = {phy_power = 13920},
    yvying = {mag_power = 13920}
  },
  [58] = {
    shouling = {max_life = 23600, phy_power = 2360},
    xvcheng = {def = 11800, mag_power = 2360},
    weiming = {phy_power = 7080, mag_power = 7080},
    taiming = {speed = 2400},
    hunting = {phy_power = 14160},
    yvying = {mag_power = 14160}
  },
  [59] = {
    shouling = {max_life = 24000, phy_power = 2400},
    xvcheng = {def = 12000, mag_power = 2400},
    weiming = {phy_power = 7200, mag_power = 7200},
    taiming = {speed = 2440},
    hunting = {phy_power = 14400},
    yvying = {mag_power = 14400}
  },
  [60] = {
    shouling = {max_life = 24400, phy_power = 2440},
    xvcheng = {def = 12200, mag_power = 2440},
    weiming = {phy_power = 7320, mag_power = 7320},
    taiming = {speed = 2480},
    hunting = {phy_power = 14640},
    yvying = {mag_power = 14640}
  },
  [61] = {
    shouling = {max_life = 24800, phy_power = 2480},
    xvcheng = {def = 12400, mag_power = 2480},
    weiming = {phy_power = 7440, mag_power = 7440},
    taiming = {speed = 2520},
    hunting = {phy_power = 14880},
    yvying = {mag_power = 14880}
  },
  [62] = {
    shouling = {max_life = 25200, phy_power = 2520},
    xvcheng = {def = 12600, mag_power = 2520},
    weiming = {phy_power = 7560, mag_power = 7560},
    taiming = {speed = 2560},
    hunting = {phy_power = 15120},
    yvying = {mag_power = 15120}
  },
  [63] = {
    shouling = {max_life = 25600, phy_power = 2560},
    xvcheng = {def = 12800, mag_power = 2560},
    weiming = {phy_power = 7680, mag_power = 7680},
    taiming = {speed = 2600},
    hunting = {phy_power = 15360},
    yvying = {mag_power = 15360}
  },
  [64] = {
    shouling = {max_life = 26000, phy_power = 2600},
    xvcheng = {def = 13000, mag_power = 2600},
    weiming = {phy_power = 7800, mag_power = 7800},
    taiming = {speed = 2640},
    hunting = {phy_power = 15600},
    yvying = {mag_power = 15600}
  },
  [65] = {
    shouling = {max_life = 26400, phy_power = 2640},
    xvcheng = {def = 13200, mag_power = 2640},
    weiming = {phy_power = 7920, mag_power = 7920},
    taiming = {speed = 2680},
    hunting = {phy_power = 15840},
    yvying = {mag_power = 15840}
  },
  [66] = {
    shouling = {max_life = 26800, phy_power = 2680},
    xvcheng = {def = 13400, mag_power = 2680},
    weiming = {phy_power = 8040, mag_power = 8040},
    taiming = {speed = 2720},
    hunting = {phy_power = 16080},
    yvying = {mag_power = 16080}
  },
  [67] = {
    shouling = {max_life = 27200, phy_power = 2720},
    xvcheng = {def = 13600, mag_power = 2720},
    weiming = {phy_power = 8160, mag_power = 8160},
    taiming = {speed = 2760},
    hunting = {phy_power = 16320},
    yvying = {mag_power = 16320}
  },
  [68] = {
    shouling = {max_life = 27600, phy_power = 2760},
    xvcheng = {def = 13800, mag_power = 2760},
    weiming = {phy_power = 8280, mag_power = 8280},
    taiming = {speed = 2800},
    hunting = {phy_power = 16560},
    yvying = {mag_power = 16560}
  },
  [69] = {
    shouling = {max_life = 28000, phy_power = 2800},
    xvcheng = {def = 14000, mag_power = 2800},
    weiming = {phy_power = 8400, mag_power = 8400},
    taiming = {speed = 2840},
    hunting = {phy_power = 16800},
    yvying = {mag_power = 16800}
  },
  [70] = {
    shouling = {max_life = 28400, phy_power = 2840},
    xvcheng = {def = 14200, mag_power = 2840},
    weiming = {phy_power = 8520, mag_power = 8520},
    taiming = {speed = 2880},
    hunting = {phy_power = 17040},
    yvying = {mag_power = 17040}
  },
  [71] = {
    shouling = {max_life = 28800, phy_power = 2880},
    xvcheng = {def = 14400, mag_power = 2880},
    weiming = {phy_power = 8640, mag_power = 8640},
    taiming = {speed = 2920},
    hunting = {phy_power = 17280},
    yvying = {mag_power = 17280}
  },
  [72] = {
    shouling = {max_life = 29200, phy_power = 2920},
    xvcheng = {def = 14600, mag_power = 2920},
    weiming = {phy_power = 8760, mag_power = 8760},
    taiming = {speed = 2960},
    hunting = {phy_power = 17520},
    yvying = {mag_power = 17520}
  },
  [73] = {
    shouling = {max_life = 29600, phy_power = 2960},
    xvcheng = {def = 14800, mag_power = 2960},
    weiming = {phy_power = 8880, mag_power = 8880},
    taiming = {speed = 3000},
    hunting = {phy_power = 17760},
    yvying = {mag_power = 17760}
  },
  [74] = {
    shouling = {max_life = 30000, phy_power = 3000},
    xvcheng = {def = 15000, mag_power = 3000},
    weiming = {phy_power = 9000, mag_power = 9000},
    taiming = {speed = 3040},
    hunting = {phy_power = 18000},
    yvying = {mag_power = 18000}
  },
  [75] = {
    shouling = {max_life = 30400, phy_power = 3040},
    xvcheng = {def = 15200, mag_power = 3040},
    weiming = {phy_power = 9120, mag_power = 9120},
    taiming = {speed = 3080},
    hunting = {phy_power = 18240},
    yvying = {mag_power = 18240}
  },
  [76] = {
    shouling = {max_life = 30800, phy_power = 3080},
    xvcheng = {def = 15400, mag_power = 3080},
    weiming = {phy_power = 9240, mag_power = 9240},
    taiming = {speed = 3120},
    hunting = {phy_power = 18480},
    yvying = {mag_power = 18480}
  },
  [77] = {
    shouling = {max_life = 31200, phy_power = 3120},
    xvcheng = {def = 15600, mag_power = 3120},
    weiming = {phy_power = 9360, mag_power = 9360},
    taiming = {speed = 3160},
    hunting = {phy_power = 18720},
    yvying = {mag_power = 18720}
  },
  [78] = {
    shouling = {max_life = 31600, phy_power = 3160},
    xvcheng = {def = 15800, mag_power = 3160},
    weiming = {phy_power = 9480, mag_power = 9480},
    taiming = {speed = 3200},
    hunting = {phy_power = 18960},
    yvying = {mag_power = 18960}
  },
  [79] = {
    shouling = {max_life = 32000, phy_power = 3200},
    xvcheng = {def = 16000, mag_power = 3200},
    weiming = {phy_power = 9600, mag_power = 9600},
    taiming = {speed = 3240},
    hunting = {phy_power = 19200},
    yvying = {mag_power = 19200}
  },
  [80] = {
    shouling = {max_life = 32400, phy_power = 3240},
    xvcheng = {def = 16200, mag_power = 3240},
    weiming = {phy_power = 9720, mag_power = 9720},
    taiming = {speed = 3280},
    hunting = {phy_power = 19440},
    yvying = {mag_power = 19440}
  },
  [81] = {
    shouling = {max_life = 32800, phy_power = 3280},
    xvcheng = {def = 16400, mag_power = 3280},
    weiming = {phy_power = 9840, mag_power = 9840},
    taiming = {speed = 3320},
    hunting = {phy_power = 19680},
    yvying = {mag_power = 19680}
  },
  [82] = {
    shouling = {max_life = 33200, phy_power = 3320},
    xvcheng = {def = 16600, mag_power = 3320},
    weiming = {phy_power = 9960, mag_power = 9960},
    taiming = {speed = 3360},
    hunting = {phy_power = 19920},
    yvying = {mag_power = 19920}
  },
  [83] = {
    shouling = {max_life = 33600, phy_power = 3360},
    xvcheng = {def = 16800, mag_power = 3360},
    weiming = {phy_power = 10080, mag_power = 10080},
    taiming = {speed = 3400},
    hunting = {phy_power = 20160},
    yvying = {mag_power = 20160}
  },
  [84] = {
    shouling = {max_life = 34000, phy_power = 3400},
    xvcheng = {def = 17000, mag_power = 3400},
    weiming = {phy_power = 10200, mag_power = 10200},
    taiming = {speed = 3440},
    hunting = {phy_power = 20400},
    yvying = {mag_power = 20400}
  },
  [85] = {
    shouling = {max_life = 34400, phy_power = 3440},
    xvcheng = {def = 17200, mag_power = 3440},
    weiming = {phy_power = 10320, mag_power = 10320},
    taiming = {speed = 3480},
    hunting = {phy_power = 20640},
    yvying = {mag_power = 20640}
  },
  [86] = {
    shouling = {max_life = 34800, phy_power = 3480},
    xvcheng = {def = 17400, mag_power = 3480},
    weiming = {phy_power = 10440, mag_power = 10440},
    taiming = {speed = 3520},
    hunting = {phy_power = 20880},
    yvying = {mag_power = 20880}
  },
  [87] = {
    shouling = {max_life = 35200, phy_power = 3520},
    xvcheng = {def = 17600, mag_power = 3520},
    weiming = {phy_power = 10560, mag_power = 10560},
    taiming = {speed = 3560},
    hunting = {phy_power = 21120},
    yvying = {mag_power = 21120}
  },
  [88] = {
    shouling = {max_life = 35600, phy_power = 3560},
    xvcheng = {def = 17800, mag_power = 3560},
    weiming = {phy_power = 10680, mag_power = 10680},
    taiming = {speed = 3600},
    hunting = {phy_power = 21360},
    yvying = {mag_power = 21360}
  },
  [89] = {
    shouling = {max_life = 36000, phy_power = 3600},
    xvcheng = {def = 18000, mag_power = 3600},
    weiming = {phy_power = 10800, mag_power = 10800},
    taiming = {speed = 3640},
    hunting = {phy_power = 21600},
    yvying = {mag_power = 21600}
  },
  [90] = {
    shouling = {max_life = 36400, phy_power = 3640},
    xvcheng = {def = 18200, mag_power = 3640},
    weiming = {phy_power = 10920, mag_power = 10920},
    taiming = {speed = 3680},
    hunting = {phy_power = 21840},
    yvying = {mag_power = 21840}
  },
  [91] = {
    shouling = {max_life = 36800, phy_power = 3680},
    xvcheng = {def = 18400, mag_power = 3680},
    weiming = {phy_power = 11040, mag_power = 11040},
    taiming = {speed = 3720},
    hunting = {phy_power = 22080},
    yvying = {mag_power = 22080}
  },
  [92] = {
    shouling = {max_life = 37200, phy_power = 3720},
    xvcheng = {def = 18600, mag_power = 3720},
    weiming = {phy_power = 11160, mag_power = 11160},
    taiming = {speed = 3760},
    hunting = {phy_power = 22320},
    yvying = {mag_power = 22320}
  },
  [93] = {
    shouling = {max_life = 37600, phy_power = 3760},
    xvcheng = {def = 18800, mag_power = 3760},
    weiming = {phy_power = 11280, mag_power = 11280},
    taiming = {speed = 3800},
    hunting = {phy_power = 22560},
    yvying = {mag_power = 22560}
  },
  [94] = {
    shouling = {max_life = 38000, phy_power = 3800},
    xvcheng = {def = 19000, mag_power = 3800},
    weiming = {phy_power = 11400, mag_power = 11400},
    taiming = {speed = 3840},
    hunting = {phy_power = 22800},
    yvying = {mag_power = 22800}
  },
  [95] = {
    shouling = {max_life = 38400, phy_power = 3840},
    xvcheng = {def = 19200, mag_power = 3840},
    weiming = {phy_power = 11520, mag_power = 11520},
    taiming = {speed = 3880},
    hunting = {phy_power = 23040},
    yvying = {mag_power = 23040}
  },
  [96] = {
    shouling = {max_life = 38800, phy_power = 3880},
    xvcheng = {def = 19400, mag_power = 3880},
    weiming = {phy_power = 11640, mag_power = 11640},
    taiming = {speed = 3920},
    hunting = {phy_power = 23280},
    yvying = {mag_power = 23280}
  },
  [97] = {
    shouling = {max_life = 39200, phy_power = 3920},
    xvcheng = {def = 19600, mag_power = 3920},
    weiming = {phy_power = 11760, mag_power = 11760},
    taiming = {speed = 3960},
    hunting = {phy_power = 23520},
    yvying = {mag_power = 23520}
  },
  [98] = {
    shouling = {max_life = 39600, phy_power = 3960},
    xvcheng = {def = 19800, mag_power = 3960},
    weiming = {phy_power = 11880, mag_power = 11880},
    taiming = {speed = 4000},
    hunting = {phy_power = 23760},
    yvying = {mag_power = 23760}
  },
  [99] = {
    shouling = {max_life = 40000, phy_power = 4000},
    xvcheng = {def = 20000, mag_power = 4000},
    weiming = {phy_power = 12000, mag_power = 12000},
    taiming = {speed = 4040},
    hunting = {phy_power = 24000},
    yvying = {mag_power = 24000}
  },
  [100] = {
    shouling = {max_life = 40400, phy_power = 4040},
    xvcheng = {def = 20200, mag_power = 4040},
    weiming = {phy_power = 12120, mag_power = 12120},
    taiming = {speed = 4080},
    hunting = {phy_power = 24240},
    yvying = {mag_power = 24240}
  }
}
