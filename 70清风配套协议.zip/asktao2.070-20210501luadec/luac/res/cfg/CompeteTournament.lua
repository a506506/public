return {
  ["20170101000000"] = {
    {
      reset_score = 2500,
      level = 9,
      name = "星宿1级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 7000,
      std_lost = 100
    },
    {
      reset_score = 2500,
      level = 8,
      name = "地煞3级",
      title = "擂台新星",
      std_get = 100,
      require_score = 6000,
      std_lost = 60
    },
    {
      reset_score = 2000,
      level = 7,
      name = "地煞2级",
      title = "擂台新星",
      std_get = 100,
      require_score = 5000,
      std_lost = 60
    },
    {
      reset_score = 1000,
      level = 6,
      name = "地煞1级",
      title = "擂台新星",
      std_get = 100,
      require_score = 4000,
      std_lost = 60
    },
    {
      reset_score = 1000,
      level = 5,
      name = "天罡3级",
      title = "战力初显",
      std_get = 100,
      require_score = 3000,
      std_lost = 60
    },
    {
      reset_score = 500,
      level = 4,
      name = "天罡2级",
      title = "战力初显",
      std_get = 100,
      require_score = 2500,
      std_lost = 60
    },
    {
      reset_score = 0,
      level = 3,
      name = "天罡1级",
      title = "战力初显",
      std_get = 100,
      require_score = 2000,
      std_lost = 60
    },
    {
      reset_score = 0,
      level = 2,
      name = "新手3级",
      title = "无",
      std_get = 100,
      require_score = 1000,
      std_lost = 40
    },
    {
      reset_score = 0,
      level = 1,
      name = "新手2级",
      title = "无",
      std_get = 100,
      require_score = 500,
      std_lost = 40
    },
    {
      reset_score = 0,
      level = 0,
      name = "新手1级",
      title = "无",
      std_get = 100,
      require_score = 0,
      std_lost = 40
    },
    {
      reset_score = 3000,
      level = 10,
      name = "星宿2级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 8500,
      std_lost = 100
    },
    {
      reset_score = 4000,
      level = 11,
      name = "星宿3级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 10500,
      std_lost = 100
    },
    {
      reset_score = 5000,
      level = 12,
      name = "紫微星",
      title = "战神无双",
      std_get = 100,
      require_score = 13000,
      std_lost = 120
    }
  },
  ["20160101000000"] = {
    {
      reset_score = 6000,
      level = 9,
      name = "星宿1级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 23250,
      std_lost = 100
    },
    {
      reset_score = 6000,
      level = 8,
      name = "地煞3级",
      title = "擂台新星",
      std_get = 100,
      require_score = 18250,
      std_lost = 80
    },
    {
      reset_score = 4500,
      level = 7,
      name = "地煞2级",
      title = "擂台新星",
      std_get = 100,
      require_score = 14500,
      std_lost = 80
    },
    {
      reset_score = 2500,
      level = 6,
      name = "地煞1级",
      title = "擂台新星",
      std_get = 100,
      require_score = 12000,
      std_lost = 80
    },
    {
      reset_score = 2500,
      level = 5,
      name = "天罡3级",
      title = "战力初显",
      std_get = 100,
      require_score = 9000,
      std_lost = 60
    },
    {
      reset_score = 1000,
      level = 4,
      name = "天罡2级",
      title = "战力初显",
      std_get = 100,
      require_score = 6000,
      std_lost = 60
    },
    {
      reset_score = 0,
      level = 3,
      name = "天罡1级",
      title = "战力初显",
      std_get = 100,
      require_score = 4000,
      std_lost = 60
    },
    {
      reset_score = 0,
      level = 2,
      name = "新手3级",
      title = "无",
      std_get = 100,
      require_score = 2500,
      std_lost = 40
    },
    {
      reset_score = 0,
      level = 1,
      name = "新手2级",
      title = "无",
      std_get = 100,
      require_score = 1000,
      std_lost = 40
    },
    {
      reset_score = 0,
      level = 0,
      name = "新手1级",
      title = "无",
      std_get = 100,
      require_score = 0,
      std_lost = 40
    },
    {
      reset_score = 9000,
      level = 10,
      name = "星宿2级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 26550,
      std_lost = 100
    },
    {
      reset_score = 12000,
      level = 11,
      name = "星宿3级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 29850,
      std_lost = 100
    },
    {
      reset_score = 14500,
      level = 12,
      name = "紫微星",
      title = "战神无双",
      std_get = 100,
      require_score = 33150,
      std_lost = 120
    }
  },
  ["20200815000000"] = {
    {
      reset_score = 1200,
      level = 9,
      name = "星宿1级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 4000,
      std_lost = 100
    },
    {
      reset_score = 900,
      level = 8,
      name = "地煞3级",
      title = "擂台新星",
      std_get = 100,
      require_score = 3500,
      std_lost = 60
    },
    {
      reset_score = 700,
      level = 7,
      name = "地煞2级",
      title = "擂台新星",
      std_get = 100,
      require_score = 3000,
      std_lost = 60
    },
    {
      reset_score = 500,
      level = 6,
      name = "地煞1级",
      title = "擂台新星",
      std_get = 100,
      require_score = 2500,
      std_lost = 60
    },
    {
      reset_score = 250,
      level = 5,
      name = "天罡3级",
      title = "战力初显",
      std_get = 100,
      require_score = 2000,
      std_lost = 60
    },
    {
      reset_score = 0,
      level = 4,
      name = "天罡2级",
      title = "战力初显",
      std_get = 100,
      require_score = 1500,
      std_lost = 60
    },
    {
      reset_score = 0,
      level = 3,
      name = "天罡1级",
      title = "战力初显",
      std_get = 100,
      require_score = 1000,
      std_lost = 60
    },
    {
      reset_score = 0,
      level = 2,
      name = "新手3级",
      title = "无",
      std_get = 100,
      require_score = 500,
      std_lost = 40
    },
    {
      reset_score = 0,
      level = 1,
      name = "新手2级",
      title = "无",
      std_get = 100,
      require_score = 250,
      std_lost = 40
    },
    {
      reset_score = 0,
      level = 0,
      name = "新手1级",
      title = "无",
      std_get = 100,
      require_score = 0,
      std_lost = 40
    },
    {
      reset_score = 1500,
      level = 10,
      name = "星宿2级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 4500,
      std_lost = 100
    },
    {
      reset_score = 2000,
      level = 11,
      name = "星宿3级",
      title = "战斗奇才",
      std_get = 100,
      require_score = 5000,
      std_lost = 100
    },
    {
      reset_score = 2500,
      level = 12,
      name = "紫微星",
      title = "战神无双",
      std_get = 100,
      require_score = 6000,
      std_lost = 120
    }
  }
}
