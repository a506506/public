return {
  [CHS[7100004]] = {
    icon = 1182,
    offsetX = 0,
    offsetY = 0,
    extraPara = {blendMode = "add"}
  },
  [CHS[7100011]] = {
    icon = 1183,
    offsetX = 0,
    offsetY = 0,
    extraPara = {blendMode = "add"}
  },
  [CHS[7120008]] = {
    icon = 1184,
    offsetX = 0,
    offsetY = 0,
    extraPara = {blendMode = "add"}
  },
  [CHS[7120009]] = {
    icon = 1185,
    offsetX = 0,
    offsetY = 46,
    extraPara = {blendMode = "add"}
  },
  [CHS[7120010]] = {
    icon = 1185,
    offsetX = 1,
    offsetY = 55,
    extraPara = {blendMode = "add"}
  },
  [CHS[7120011]] = {
    icon = 1187,
    offsetX = 0,
    offsetY = 0,
    extraPara = {blendMode = "add", loopInterval = 10000}
  },
  [CHS[7120012]] = {
    icon = 1188,
    offsetX = 0,
    offsetY = 0,
    extraPara = {blendMode = "add", loopInterval = 10000}
  },
  [CHS[2000386]] = {
    icon = 1189,
    offsetX = 0,
    offsetY = 0,
    extraPara = {blendMode = "add"}
  },
  [CHS[2000387]] = {
    icon = 1190,
    offsetX = 0,
    offsetY = 0,
    extraPara = {blendMode = "add"}
  },
  [CHS[5400255]] = {
    icon = 1255,
    offsetX = 0,
    offsetY = 0,
    hideFurntiue = true,
    place = "mid",
    extraPara = {frameInterval = 150}
  },
  [CHS[5400256]] = {
    icon = 1255,
    offsetX = 0,
    offsetY = 0,
    hideFurntiue = true,
    place = "mid",
    extraPara = {frameInterval = 150}
  }
}
