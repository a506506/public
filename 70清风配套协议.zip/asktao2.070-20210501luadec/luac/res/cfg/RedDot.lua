return {
  [1] = {
    "SystemFunctionDlg",
    "ArenaButton",
    "ArenaDlg"
  },
  [2] = {
    "SystemFunctionDlg",
    "ShuadaoButton",
    "GetTaoDlg"
  },
  [3] = {
    "GetTaoTabDlg",
    "OfflineGetTaoTabDlgCheckBox",
    "GetTaoOfflineDlg",
    "GetTaoPointDlg"
  },
  [4] = {
    "SystemFunctionDlg",
    "ActivityButton",
    "ActivitiesDlg"
  },
  [5] = {
    "ActivitiesDlg",
    "LimitedCheckBox",
    ""
  },
  [6] = {
    "SystemFunctionDlg",
    "MallButton",
    "OnlineMallDlg"
  },
  [7] = {
    "OnlineMallTabDlg",
    "VIPCheckBox",
    "OnlineMallVIPDlg"
  },
  [8] = {
    "SystemFunctionDlg",
    "GiftsButton",
    "WelfareDlg"
  },
  [9] = {
    "GameFunctionDlg",
    "",
    ""
  },
  [10] = {
    "GuardTabDlg",
    "GuardCallDlgCheckBox",
    "GuardCallDlg"
  },
  [11] = {
    "PartyInfoTabDlg",
    "ApplyCheckBox",
    "PartyRecruitDlg"
  },
  [12] = {
    "MissionDlg",
    "TeamCheckBox",
    "TeamDlg"
  },
  [13] = {
    "ChatDlg",
    "FriendButton",
    "FriendDlg"
  },
  [14] = {
    "FriendDlg",
    "TempCheckBox",
    ""
  },
  [15] = {
    "GameFunctionDlg",
    "",
    ""
  },
  [16] = {
    "GameFunctionDlg",
    "",
    ""
  },
  [17] = {
    "SystemFunctionDlg",
    "MarketButton",
    ""
  },
  [18] = {
    "MarketTabDlg",
    "MarketSellDlgCheckBox",
    "MarketSellDlg"
  },
  [19] = {
    "GameFunctionDlg",
    "",
    ""
  },
  [20] = {
    "GetTaoOfflineDlg",
    "RewardButton",
    "GetTaoRewardDlg"
  },
  [21] = {
    "OnlineMallTabDlg",
    "ItemCheckBox",
    "OnlineMallDlg"
  },
  [22] = {
    "SystemFunctionDlg",
    "TreasureButton",
    ""
  },
  [23] = {
    "MarketGoldTabDlg",
    "MarketSellDlgCheckBox",
    "MarketGoldSellDlg"
  },
  [24] = {
    "SystemFunctionDlg",
    "ShowTradeButton",
    ""
  },
  [25] = {
    "SystemFunctionDlg",
    "ShuadaoButton",
    "GetTaoOfflineDlg"
  },
  [26] = {
    "GameFunctionDlg",
    "SystemButton",
    "SystemAccManageDlg"
  },
  [27] = {
    "SystemConfigTabDlg",
    "SystemAccManageDlgCheckBox",
    "SystemAccManageDlg",
    true
  },
  [28] = {
    "SystemAccManageDlg",
    "RelatedPhoneButton",
    "SystemAccManageDlg",
    true
  },
  [29] = {
    "SystemAccManageDlg",
    "AuthenticateAgainButton",
    "SystemAccManageDlg",
    true
  },
  [30] = {
    "GameFunctionDlg",
    "SystemButton",
    "UpdateDescDlg"
  },
  [31] = {
    "SystemConfigDlg",
    "UpdateButton",
    "UpdateDescDlg"
  },
  [32] = {
    "UpdateDescDlg",
    "OffLineActiveDlgCheckBox",
    "UpdateDescDlg"
  },
  [33] = {
    "SystemFunctionDlg",
    "ShuadaoButton",
    "GetTaoPointDlg"
  },
  [34] = {
    "ChannelDlg",
    "FriendDlgButton",
    "FriendDlg"
  },
  [35] = {
    "SystemFunctionDlg",
    "AnniversaryButton",
    ""
  },
  [36] = {
    "AnniversaryTabDlg",
    "DLLBCheckBox",
    ""
  },
  [37] = {
    "AnniversaryTabDlg",
    "CWMXCheckBox",
    ""
  },
  [38] = {
    "SystemFunctionDlg",
    "JubaoButton",
    ""
  },
  [39] = {
    "SystemAccManageDlg",
    "AuthenticateRealNameButton",
    "SystemAccManageDlg",
    true
  },
  [40] = {
    "GameFunctionDlg",
    "HomeButton",
    "HomeTabDlg"
  },
  [41] = {
    "HomeTabDlg",
    "HomeDlgCheckBox",
    ""
  },
  [42] = {
    "HomeTabDlg",
    "XiulianDlgCheckBox",
    ""
  },
  [43] = {
    "HomeTabDlg",
    "PlantDlgCheckBox",
    ""
  },
  [44] = {
    "HomeCheckDlg",
    "CheckButton",
    "",
    "",
    "",
    "UserPanel"
  },
  [45] = {
    "HomeCheckDlg",
    "CheckButton",
    "",
    "",
    "",
    "ArtifactPanel"
  },
  [46] = {
    "HomeCheckDlg",
    "CheckButton",
    "",
    "",
    "",
    "PetPanel"
  },
  [47] = {
    "HomeTabDlg",
    "OtherDlgCheckBox",
    ""
  },
  [48] = {
    "GameFunctionDlg",
    "AchievementButton",
    ""
  },
  [49] = {
    "AchievementListDlg",
    "RewardButton",
    ""
  },
  [50] = {
    "FriendDlg",
    "BlogDlgButton",
    "BlogTabDlg"
  },
  [51] = {
    "BlogTabDlg",
    "BlogMessageCheckBox",
    ""
  },
  [52] = {
    "ChatDlg",
    "FriendButton",
    ""
  },
  [53] = {
    "BlogTabDlg",
    "BlogCircleCheckBox",
    ""
  },
  [54] = {
    "WelfareDlg",
    "WelfareButton5",
    ""
  },
  [55] = {
    "AnniversaryTabDlg",
    "XYLMCheckBox",
    ""
  },
  [56] = {
    "GameFunctionDlg",
    "WatchCenterButton",
    ""
  },
  [57] = {
    "GameFunctionDlg",
    "",
    ""
  },
  [58] = {
    "WelfareDlg",
    "WelfareButton26",
    ""
  },
  [59] = {
    "GameFunctionDlg",
    "SocialButton",
    ""
  },
  [60] = {
    "SystemFunctionDlg",
    "CommunityButton",
    ""
  },
  [61] = {
    "GameFunctionDlg",
    "MarryBookButton",
    ""
  },
  [62] = {
    "AnniversaryTabDlg",
    "CWMXCheckBox"
  },
  [63] = {
    "SystemFunctionDlg",
    "TradingSpotButton",
    ""
  },
  [64] = {
    "TradingSpotTabDlg",
    "TradingSpotProfitDlgCheckBox",
    ""
  },
  [65] = {
    "GameFunctionDlg",
    "HomeButton",
    ""
  },
  [66] = {
    "HomeTabDlg",
    "HomeKidDlgCheckBox",
    ""
  },
  [67] = {
    "GameFunctionDlg",
    "UndergroundEntourageButton",
    "UndergroundTeamDlg"
  },
  [68] = {
    "GameFunctionDlg",
    "UndergroundPowerButton",
    "UndergroundGrowthDlg"
  },
  [69] = {
    "SystemFunctionDlg",
    "GloryButton",
    ""
  },
  [70] = {
    "SystemFunctionDlg",
    "FamousButton",
    "FamousDlg"
  },
  [71] = {
    "WelfareDlg",
    "WelfareButton36",
    ""
  },
  [72] = {
    "SystemFunctionDlg",
    "LanternButton",
    "PetLanternDlg"
  },
  [73] = {
    "SystemFunctionDlg",
    "FireWorksButton",
    "FireworksCeremonyDlg"
  },
  [74] = {
    "GameFunctionDlg",
    "MiaoYRadioButton",
    "MiaoYRadioMyselfDlg"
  },
  [75] = {
    "MiaoYRadioMain2Dlg",
    CHS[5410582]
  },
  [76] = {
    "GameFunctionDlg",
    "SpiritButton",
    "SpiritSystemMagicCircleDlg"
  },
  [77] = {
    "SpiritSystemMagicCircleDlg",
    "RaiseButton"
  },
  [78] = {
    "PartyInfoTabDlg",
    "WelfareCheckBox",
    ""
  },
  [79] = {
    "PartyWelfareDlg",
    "SalQueryButton",
    ""
  },
  [80] = {
    "PartyWelfareDlg",
    "ConQueryButton",
    ""
  },
  [81] = {
    "GameFunctionDlg",
    "PartyButton",
    ""
  },
  [82] = {
    "GameFunctionDlg",
    "TianGongButton",
    ""
  },
  [83] = {
    "TianGMainInterfaceTabDlg",
    "ReceiveButton",
    ""
  },
  [84] = {},
  [2001] = {
    "RanfbpDlg",
    "ChangePanel"
  },
  [2002] = {
    "AnniversaryTabDlg",
    "RFBPCheckBox"
  },
  [2003] = {
    "GameFunctionDlg",
    "BattlePassButton",
    "BattlePassTabDlg"
  },
  [2004] = {
    "BattlePassTabDlg",
    "RewardPanel"
  },
  [2005] = {
    "BattlePassTabDlg",
    "TaskPanel"
  },
  [3001] = {
    "AnniversaryTabDlg",
    "WHNFCheckBox",
    ""
  },
  [3002] = {
    "FlowersBilssDlg",
    "BagButton",
    "",
    "",
    "",
    "MainPanel"
  },
  [3003] = {
    "FlowersBilssDlg",
    "HelpButton",
    "",
    "",
    "",
    "MainPanel"
  },
  [4000] = {
    "AnniversaryTabDlg",
    "QDJQCheckBox"
  },
  [4001] = {
    "CelebrationLuckyStickDlg",
    "StartButton",
    "",
    "",
    "",
    "StartPanel"
  }
}
