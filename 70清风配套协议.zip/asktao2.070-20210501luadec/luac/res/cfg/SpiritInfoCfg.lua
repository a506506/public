return {
  {
    cost = 0,
    maxExp = 0,
    att = {
      0.2,
      0.2,
      0.2,
      0.2
    }
  },
  {
    cost = 1,
    maxExp = 240,
    att = {
      0.4,
      0.4,
      0.4,
      0.4
    }
  },
  {
    cost = 1,
    maxExp = 280,
    att = {
      0.6,
      0.6,
      0.6,
      0.6
    }
  },
  {
    cost = 1,
    maxExp = 330,
    att = {
      0.8,
      0.8,
      0.8,
      0.8
    }
  },
  {
    cost = 1,
    maxExp = 380,
    att = {
      1,
      1,
      1,
      1
    }
  },
  {
    cost = 1,
    maxExp = 430,
    att = {
      1.2,
      1.2,
      1.2,
      1.2
    }
  },
  {
    cost = 1,
    maxExp = 480,
    att = {
      1.4,
      1.4,
      1.4,
      1.4
    }
  },
  {
    cost = 2,
    maxExp = 520,
    att = {
      1.6,
      1.6,
      1.6,
      1.6
    }
  },
  {
    cost = 2,
    maxExp = 570,
    att = {
      1.8,
      1.8,
      1.8,
      1.8
    }
  },
  {
    cost = 2,
    maxExp = 620,
    att = {
      2,
      2,
      2,
      2
    }
  },
  {
    cost = 2,
    maxExp = 670,
    att = {
      2.2,
      2.2,
      2.2,
      2.2
    }
  },
  {
    cost = 2,
    maxExp = 720,
    att = {
      2.4,
      2.4,
      2.4,
      2.4
    }
  },
  {
    cost = 2,
    maxExp = 760,
    att = {
      2.6,
      2.6,
      2.6,
      2.6
    }
  },
  {
    cost = 2,
    maxExp = 810,
    att = {
      2.8,
      2.8,
      2.8,
      2.8
    }
  },
  {
    cost = 3,
    maxExp = 860,
    att = {
      3,
      3,
      3,
      3
    }
  },
  {
    cost = 3,
    maxExp = 910,
    att = {
      3.2,
      3.2,
      3.2,
      3.2
    }
  },
  {
    cost = 3,
    maxExp = 960,
    att = {
      3.4,
      3.4,
      3.4,
      3.4
    }
  },
  {
    cost = 3,
    maxExp = 1000,
    att = {
      3.6,
      3.6,
      3.6,
      3.6
    }
  },
  {
    cost = 3,
    maxExp = 1050,
    att = {
      3.8,
      3.8,
      3.8,
      3.8
    }
  },
  {
    cost = 3,
    maxExp = 1100,
    att = {
      4,
      4,
      4,
      4
    }
  },
  {
    cost = 3,
    maxExp = 1150,
    att = {
      4.2,
      4.2,
      4.2,
      4.2
    }
  },
  {
    cost = 4,
    maxExp = 1210,
    att = {
      4.4,
      4.4,
      4.4,
      4.4
    }
  },
  {
    cost = 4,
    maxExp = 1270,
    att = {
      4.6,
      4.6,
      4.6,
      4.6
    }
  },
  {
    cost = 4,
    maxExp = 1340,
    att = {
      4.8,
      4.8,
      4.8,
      4.8
    }
  },
  {
    cost = 4,
    maxExp = 1410,
    att = {
      5,
      5,
      5,
      5
    }
  },
  {
    cost = 4,
    maxExp = 1480,
    att = {
      5.2,
      5.2,
      5.2,
      5.2
    }
  },
  {
    cost = 4,
    maxExp = 1560,
    att = {
      5.4,
      5.4,
      5.4,
      5.4
    }
  },
  {
    cost = 4,
    maxExp = 1630,
    att = {
      5.6,
      5.6,
      5.6,
      5.6
    }
  },
  {
    cost = 5,
    maxExp = 1710,
    att = {
      5.8,
      5.8,
      5.8,
      5.8
    }
  },
  {
    cost = 5,
    maxExp = 1800,
    att = {
      6,
      6,
      6,
      6
    }
  },
  {
    cost = 5,
    maxExp = 1890,
    att = {
      6.2,
      6.2,
      6.2,
      6.2
    }
  },
  {
    cost = 5,
    maxExp = 1980,
    att = {
      6.4,
      6.4,
      6.4,
      6.4
    }
  },
  {
    cost = 5,
    maxExp = 2070,
    att = {
      6.6,
      6.6,
      6.6,
      6.6
    }
  },
  {
    cost = 5,
    maxExp = 2170,
    att = {
      6.8,
      6.8,
      6.8,
      6.8
    }
  },
  {
    cost = 5,
    maxExp = 2270,
    att = {
      7,
      7,
      7,
      7
    }
  },
  {
    cost = 6,
    maxExp = 2380,
    att = {
      7.2,
      7.2,
      7.2,
      7.2
    }
  },
  {
    cost = 6,
    maxExp = 2480,
    att = {
      7.4,
      7.4,
      7.4,
      7.4
    }
  },
  {
    cost = 6,
    maxExp = 2590,
    att = {
      7.6,
      7.6,
      7.6,
      7.6
    }
  },
  {
    cost = 6,
    maxExp = 2710,
    att = {
      7.8,
      7.8,
      7.8,
      7.8
    }
  },
  {
    cost = 6,
    maxExp = 2820,
    att = {
      8,
      8,
      8,
      8
    }
  },
  {
    cost = 6,
    maxExp = 2940,
    att = {
      8.2,
      8.2,
      8.2,
      8.2
    }
  },
  {
    cost = 6,
    maxExp = 3070,
    att = {
      8.4,
      8.4,
      8.4,
      8.4
    }
  },
  {
    cost = 7,
    maxExp = 3190,
    att = {
      8.6,
      8.6,
      8.6,
      8.6
    }
  },
  {
    cost = 7,
    maxExp = 3320,
    att = {
      8.8,
      8.8,
      8.8,
      8.8
    }
  },
  {
    cost = 7,
    maxExp = 3460,
    att = {
      9,
      9,
      9,
      9
    }
  },
  {
    cost = 7,
    maxExp = 3590,
    att = {
      9.2,
      9.2,
      9.2,
      9.2
    }
  },
  {
    cost = 7,
    maxExp = 3730,
    att = {
      9.4,
      9.4,
      9.4,
      9.4
    }
  },
  {
    cost = 7,
    maxExp = 3870,
    att = {
      9.6,
      9.6,
      9.6,
      9.6
    }
  },
  {
    cost = 7,
    maxExp = 4020,
    att = {
      9.8,
      9.8,
      9.8,
      9.8
    }
  },
  {
    cost = 8,
    maxExp = 4170,
    att = {
      10,
      10,
      10,
      10
    }
  }
}
