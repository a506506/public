return {
  {
    class_id = 10088,
    x = 11,
    y = 36,
    dir = 0,
    cx = 5,
    cy = 9
  },
  {
    class_id = 10088,
    x = 17,
    y = 33,
    dir = 0,
    cx = -5,
    cy = 3
  },
  {
    class_id = 10104,
    x = 12,
    y = 29,
    dir = 0,
    cx = 8,
    cy = -11
  },
  {
    class_id = 10094,
    x = 31,
    y = 45,
    dir = 0,
    cx = -12,
    cy = -7
  },
  {
    class_id = 10094,
    x = 38,
    y = 49,
    dir = 0,
    cx = 7,
    cy = -5
  },
  {
    class_id = 10089,
    x = 54,
    y = 55,
    dir = 0,
    cx = 2,
    cy = 12
  },
  {
    class_id = 10068,
    x = 55,
    y = 46,
    dir = 1,
    cx = -7,
    cy = -10
  },
  {
    class_id = 10068,
    x = 80,
    y = 27,
    dir = 0,
    cx = 11,
    cy = 4
  },
  {
    class_id = 10094,
    x = 45,
    y = 33,
    dir = 0,
    cx = 10,
    cy = 7
  },
  {
    class_id = 10094,
    x = 57,
    y = 27,
    dir = 0,
    cx = 7,
    cy = 7
  },
  {
    class_id = 10068,
    x = 78,
    y = 45,
    dir = 1,
    cx = -10,
    cy = 1
  },
  {
    class_id = 10089,
    x = 77,
    y = 40,
    dir = 0,
    cx = 4,
    cy = 2
  },
  {
    class_id = 10099,
    x = 96,
    y = 25,
    dir = 1,
    cx = 3,
    cy = 11
  },
  {
    class_id = 10099,
    x = 22,
    y = 25,
    dir = 0,
    cx = 1,
    cy = 10
  },
  {
    class_id = 10099,
    x = 34,
    y = 19,
    dir = 0,
    cx = 6,
    cy = 11
  },
  {
    class_id = 10099,
    x = 46,
    y = 13,
    dir = 0,
    cx = 4,
    cy = 10
  },
  {
    class_id = 10099,
    x = 72,
    y = 12,
    dir = 1,
    cx = 8,
    cy = -11
  },
  {
    class_id = 10084,
    x = 27,
    y = 27,
    dir = 0,
    cx = 1,
    cy = 7
  },
  {
    class_id = 10102,
    x = 56,
    y = 8,
    dir = 0,
    cx = 0,
    cy = -1
  },
  {
    class_id = 10066,
    x = 67,
    y = 18,
    dir = 0,
    cx = 5,
    cy = 3
  },
  {
    class_id = 10066,
    x = 56,
    y = 16,
    dir = 1,
    cx = -11,
    cy = -3
  },
  {
    class_id = 10088,
    x = 64,
    y = 14,
    dir = 0,
    cx = -5,
    cy = 12
  },
  {
    class_id = 10088,
    x = 60,
    y = 12,
    dir = 0,
    cx = -1,
    cy = 11
  },
  {
    class_id = 10104,
    x = 63,
    y = 8,
    dir = 1,
    cx = 3,
    cy = 4
  },
  {
    class_id = 10085,
    x = 56,
    y = 32,
    dir = 1,
    cx = -7,
    cy = 12
  },
  {
    class_id = 10068,
    x = 68,
    y = 40,
    dir = 1,
    cx = -12,
    cy = 7
  },
  {
    class_id = 10076,
    x = 93,
    y = 43,
    dir = 0,
    cx = 11,
    cy = 9
  },
  {
    class_id = 10071,
    x = 50,
    y = 53,
    dir = 1,
    cx = -9,
    cy = 3
  },
  {
    class_id = 10068,
    x = 45,
    y = 46,
    dir = 0,
    cx = -2,
    cy = -10
  },
  {
    class_id = 10076,
    x = 46,
    y = 50,
    dir = 0,
    cx = 11,
    cy = 0
  },
  {
    class_id = 10068,
    x = 34,
    y = 38,
    dir = 1,
    cx = -11,
    cy = 7
  },
  {
    class_id = 10068,
    x = 44,
    y = 38,
    dir = 0,
    cx = -11,
    cy = 6
  },
  {
    class_id = 10068,
    x = 69,
    y = 25,
    dir = 0,
    cx = -6,
    cy = 0
  },
  {
    class_id = 10073,
    x = 82,
    y = 31,
    dir = 0,
    cx = -11,
    cy = 11
  },
  {
    class_id = 10073,
    x = 86,
    y = 28,
    dir = 0,
    cx = 10,
    cy = -4
  },
  {
    class_id = 10085,
    x = 51,
    y = 34,
    dir = 1,
    cx = 9,
    cy = 10
  },
  {
    class_id = 10094,
    x = 73,
    y = 17,
    dir = 0,
    cx = 2,
    cy = 1
  },
  {
    class_id = 10094,
    x = 46,
    y = 23,
    dir = 0,
    cx = -4,
    cy = 11
  },
  {
    class_id = 10094,
    x = 38,
    y = 27,
    dir = 0,
    cx = -6,
    cy = -11
  },
  {
    class_id = 10094,
    x = 103,
    y = 33,
    dir = 0,
    cx = 10,
    cy = 12
  },
  {
    class_id = 10068,
    x = 67,
    y = 34,
    dir = 0,
    cx = -5,
    cy = -4
  },
  {
    class_id = 10045,
    x = 39,
    y = 23,
    dir = 0,
    cx = 4,
    cy = 12
  },
  {
    class_id = 10048,
    x = 47,
    y = 18,
    dir = 0,
    cx = 6,
    cy = -6
  },
  {
    class_id = 10060,
    x = 94,
    y = 30,
    dir = 1,
    cx = 11,
    cy = 5
  },
  {
    class_id = 10061,
    x = 83,
    y = 37,
    dir = 1,
    cx = 9,
    cy = 6
  },
  {
    class_id = 10057,
    x = 97,
    y = 40,
    dir = 0,
    cx = 4,
    cy = -9
  },
  {
    class_id = 10054,
    x = 94,
    y = 39,
    dir = 15,
    cx = 10,
    cy = -11
  },
  {
    class_id = 10069,
    x = 51,
    y = 30,
    dir = 0,
    cx = 10,
    cy = 10
  },
  {
    class_id = 10068,
    x = 24,
    y = 33,
    dir = 1,
    cx = -8,
    cy = 10
  },
  {floor_index = 2},
  {wall_index = 0}
}
