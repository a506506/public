return {
  {
    class_id = 10068,
    x = 39,
    y = 25,
    dir = 1,
    cx = -8,
    cy = 4
  },
  {
    class_id = 10091,
    x = 85,
    y = 46,
    dir = 0,
    cx = 10,
    cy = -5
  },
  {
    class_id = 10097,
    x = 96,
    y = 26,
    dir = 1,
    cx = 11,
    cy = 4
  },
  {
    class_id = 10097,
    x = 72,
    y = 14,
    dir = 1,
    cx = 9,
    cy = 5
  },
  {
    class_id = 10099,
    x = 46,
    y = 14,
    dir = 0,
    cx = 5,
    cy = 5
  },
  {
    class_id = 10099,
    x = 34,
    y = 20,
    dir = 0,
    cx = 4,
    cy = 4
  },
  {
    class_id = 10099,
    x = 22,
    y = 26,
    dir = 0,
    cx = 8,
    cy = 6
  },
  {
    class_id = 10102,
    x = 12,
    y = 31,
    dir = 0,
    cx = -9,
    cy = -5
  },
  {
    class_id = 10102,
    x = 56,
    y = 9,
    dir = 0,
    cx = -2,
    cy = -5
  },
  {
    class_id = 10094,
    x = 98,
    y = 31,
    dir = 0,
    cx = -6,
    cy = -2
  },
  {
    class_id = 10094,
    x = 58,
    y = 29,
    dir = 0,
    cx = 6,
    cy = -5
  },
  {
    class_id = 10094,
    x = 42,
    y = 37,
    dir = 0,
    cx = 9,
    cy = -6
  },
  {
    class_id = 10072,
    x = 83,
    y = 43,
    dir = 0,
    cx = -6,
    cy = -5
  },
  {
    class_id = 10081,
    x = 90,
    y = 28,
    dir = 1,
    cx = 11,
    cy = 8
  },
  {
    class_id = 10091,
    x = 79,
    y = 49,
    dir = 0,
    cx = -10,
    cy = -11
  },
  {
    class_id = 10091,
    x = 71,
    y = 53,
    dir = 0,
    cx = 6,
    cy = 0
  },
  {
    class_id = 10091,
    x = 64,
    y = 56,
    dir = 0,
    cx = -2,
    cy = -11
  },
  {
    class_id = 10130,
    x = 66,
    y = 49,
    dir = 0,
    cx = -2,
    cy = -11
  },
  {
    class_id = 10054,
    x = 59,
    y = 51,
    dir = 15,
    cx = -9,
    cy = -9
  },
  {
    class_id = 10061,
    x = 75,
    y = 47,
    dir = 0,
    cx = -5,
    cy = 6
  },
  {
    class_id = 10057,
    x = 61,
    y = 53,
    dir = 0,
    cx = 1,
    cy = -6
  },
  {
    class_id = 10060,
    x = 50,
    y = 33,
    dir = 0,
    cx = 2,
    cy = 10
  },
  {
    class_id = 10064,
    x = 69,
    y = 51,
    dir = 0,
    cx = -9,
    cy = -6
  },
  {
    class_id = 10068,
    x = 28,
    y = 36,
    dir = 0,
    cx = -5,
    cy = 3
  },
  {
    class_id = 10068,
    x = 59,
    y = 21,
    dir = 0,
    cx = -10,
    cy = -3
  },
  {
    class_id = 10065,
    x = 61,
    y = 26,
    dir = 0,
    cx = -2,
    cy = -3
  },
  {
    class_id = 10065,
    x = 33,
    y = 41,
    dir = 0,
    cx = -9,
    cy = -5
  },
  {
    class_id = 10048,
    x = 16,
    y = 35,
    dir = 1,
    cx = -3,
    cy = 10
  },
  {
    class_id = 10048,
    x = 61,
    y = 12,
    dir = 1,
    cx = 4,
    cy = 11
  },
  {
    class_id = 10051,
    x = 44,
    y = 22,
    dir = 0,
    cx = 2,
    cy = 7
  },
  {
    class_id = 10051,
    x = 20,
    y = 34,
    dir = 0,
    cx = -4,
    cy = 7
  },
  {
    class_id = 10045,
    x = 27,
    y = 29,
    dir = 0,
    cx = -10,
    cy = 3
  },
  {
    class_id = 10045,
    x = 51,
    y = 17,
    dir = 0,
    cx = -7,
    cy = 3
  },
  {
    class_id = 10117,
    x = 94,
    y = 40,
    dir = 0,
    cx = -1,
    cy = -8
  },
  {
    class_id = 10134,
    x = 104,
    y = 36,
    dir = 1,
    cx = 7,
    cy = 7
  },
  {
    class_id = 10132,
    x = 70,
    y = 18,
    dir = 1,
    cx = 2,
    cy = 12
  }
}
