return {
  ["超级青蛙卡"] = {
    card_level = 1,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 1,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 3,
        chs = "抗冰冻"
      },
      [2] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [5] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      },
      [6] = {
        field = "mstunt_rate",
        value = 1,
        chs = "法术必杀率"
      },
      [7] = {
        field = "ignore_all_resist_polar",
        value = 2,
        chs = "忽视所有抗性"
      },
      [8] = {
        field = "max_life",
        value = 1,
        chs = "气血"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 2,
        chs = "法伤"
      }
    }
  },
  ["超级松鼠卡"] = {
    card_level = 1,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 2,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 3,
        chs = "抗遗忘"
      },
      [2] = {
        field = "phy_absorb",
        value = 3,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = 5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 2,
        chs = "抗木"
      },
      [5] = {
        field = "stunt_rate",
        value = 5,
        chs = "物理必杀率"
      },
      [6] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      },
      [7] = {
        field = "speed",
        value = 1,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 2,
        chs = "物伤"
      }
    }
  },
  ["超级蛇卡"] = {
    card_level = 2,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 3,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 3,
        chs = "抗混乱"
      },
      [2] = {
        field = "phy_absorb",
        value = 3,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_fire",
        value = 2,
        chs = "抗火"
      },
      [4] = {
        field = "resist_earth",
        value = 5,
        chs = "抗土"
      },
      [5] = {
        field = "stunt_rate",
        value = 5,
        chs = "物理必杀率"
      },
      [6] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      },
      [7] = {
        field = "def",
        value = 1,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 2,
        chs = "物伤"
      }
    }
  },
  ["超级兔子卡"] = {
    card_level = 2,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 4,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 3,
        chs = "抗中毒"
      },
      [2] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      },
      [6] = {
        field = "max_mana",
        value = 2,
        chs = "法力"
      },
      [7] = {
        field = "speed",
        value = 1,
        chs = "速度"
      },
      [8] = {
        field = "def",
        value = 2,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      }
    }
  },
  ["超级猴子卡"] = {
    card_level = 3,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 5,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 3,
        chs = "抗昏睡"
      },
      [2] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_fire",
        value = 5,
        chs = "抗火"
      },
      [4] = {
        field = "max_mana",
        value = 2,
        chs = "法力"
      },
      [5] = {
        field = "speed",
        value = 3,
        chs = "速度"
      },
      [6] = {
        field = "def",
        value = 1,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 2,
        chs = "速度"
      }
    }
  },
  ["超级山猫卡"] = {
    card_level = 3,
    polar = 5,
    card_type = CARD_TYPE.MONSTER,
    order = 6,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 3,
        chs = "抗混乱"
      },
      [2] = {
        field = "phy_absorb",
        value = 3,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_wood",
        value = -5,
        chs = "抗木"
      },
      [4] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [5] = {
        field = "ignore_all_resist_except",
        value = 2,
        chs = "忽视所有抗异常"
      },
      [6] = {
        field = "ignore_all_resist_polar",
        value = 2,
        chs = "忽视所有抗性"
      },
      [7] = {
        field = "max_life",
        value = 1,
        chs = "气血"
      },
      [8] = {
        field = "speed",
        value = 2,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 1,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级野狗卡"] = {
    card_level = 4,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 7,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 3,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 3,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = 5,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = 3,
        chs = "抗土"
      },
      [5] = {
        field = "stunt_rate",
        value = 6,
        chs = "物理必杀率"
      },
      [6] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      },
      [7] = {
        field = "speed",
        value = 1,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 2,
        chs = "物伤"
      }
    }
  },
  ["超级狐狸卡"] = {
    card_level = 4,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 8,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 3,
        chs = "抗中毒"
      },
      [2] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      },
      [6] = {
        field = "mstunt_rate",
        value = 1,
        chs = "法术必杀率"
      },
      [7] = {
        field = "max_mana",
        value = 3,
        chs = "法力"
      },
      [8] = {
        field = "speed",
        value = 1,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 2,
        chs = "法伤"
      }
    }
  },
  ["超级桃精卡"] = {
    card_level = 5,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 9,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 4,
        chs = "抗中毒"
      },
      [2] = {
        field = "phy_absorb",
        value = 4,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 10,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 10,
        chs = "反震度"
      },
      [7] = {
        field = "max_life",
        value = 2,
        chs = "气血"
      },
      [8] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 2,
        chs = "防御"
      }
    }
  },
  ["超级柳鬼卡"] = {
    card_level = 5,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 10,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 4,
        chs = "抗中毒"
      },
      [2] = {
        field = "phy_absorb",
        value = 4,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "ignore_all_resist_polar",
        value = 3,
        chs = "忽视所有抗性"
      },
      [6] = {
        field = "speed",
        value = 4,
        chs = "速度"
      },
      [7] = {
        field = "def",
        value = 1,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 2,
        chs = "速度"
      }
    }
  },
  ["超级白猿卡"] = {
    card_level = 6,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 11,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 4,
        chs = "抗昏睡"
      },
      [2] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_fire",
        value = 5,
        chs = "抗火"
      },
      [4] = {
        field = "double_hit_rate",
        value = 7,
        chs = "物理连击率"
      },
      [5] = {
        field = "counter_attack_rate",
        value = 11,
        chs = "反击率"
      },
      [6] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [7] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [8] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 2,
        chs = "物伤"
      }
    }
  },
  ["超级鹰卡"] = {
    card_level = 6,
    polar = 1,
    card_type = CARD_TYPE.MONSTER,
    order = 12,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 4,
        chs = "抗遗忘"
      },
      [2] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [4] = {
        field = "resist_fire",
        value = -5,
        chs = "抗火"
      },
      [5] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      },
      [6] = {
        field = "mstunt_rate",
        value = 2,
        chs = "法术必杀率"
      },
      [7] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [8] = {
        field = "speed",
        value = 2,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 2,
        chs = "法伤"
      }
    }
  },
  ["超级海龟卡"] = {
    card_level = 6,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 13,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 4,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 4,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 11,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 11,
        chs = "反震度"
      },
      [7] = {
        field = "max_life",
        value = 6,
        chs = "气血"
      },
      [8] = {
        field = "def",
        value = 2,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      }
    }
  },
  ["超级蝙蝠卡"] = {
    card_level = 7,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 14,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 4,
        chs = "抗冰冻"
      },
      [2] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 4,
        chs = "抗金"
      },
      [4] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [5] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [6] = {
        field = "ignore_all_resist_except",
        value = 2,
        chs = "忽视所有抗异常"
      },
      [7] = {
        field = "max_life",
        value = 2,
        chs = "气血"
      },
      [8] = {
        field = "speed",
        value = 2,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 2,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级蟒卡"] = {
    card_level = 7,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 15,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 4,
        chs = "抗昏睡"
      },
      [2] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      },
      [6] = {
        field = "mstunt_rate",
        value = 2,
        chs = "法术必杀率"
      },
      [7] = {
        field = "max_mana",
        value = 4,
        chs = "法力"
      },
      [8] = {
        field = "speed",
        value = 2,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 2,
        chs = "法伤"
      }
    }
  },
  ["超级狼卡"] = {
    card_level = 8,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 16,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 4,
        chs = "抗遗忘"
      },
      [2] = {
        field = "phy_absorb",
        value = 4,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = 5,
        chs = "抗金"
      },
      [4] = {
        field = "double_hit_rate",
        value = 8,
        chs = "物理连击率"
      },
      [5] = {
        field = "counter_attack_rate",
        value = 12,
        chs = "反击率"
      },
      [6] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [7] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [8] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 2,
        chs = "物伤"
      }
    }
  },
  ["超级老虎卡"] = {
    card_level = 8,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 17,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 4,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 4,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = 5,
        chs = "抗水"
      },
      [4] = {
        field = "stunt_rate",
        value = 8,
        chs = "物理必杀率"
      },
      [5] = {
        field = "max_life",
        value = 2,
        chs = "气血"
      },
      [6] = {
        field = "max_mana",
        value = 4,
        chs = "法力"
      },
      [7] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 2,
        chs = "物伤"
      }
    }
  },
  ["超级僵尸卡"] = {
    card_level = 9,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 18,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 5,
        chs = "抗昏睡"
      },
      [2] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_fire",
        value = 5,
        chs = "抗火"
      },
      [4] = {
        field = "counter_attack_rate",
        value = 13,
        chs = "反击率"
      },
      [5] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [6] = {
        field = "max_life",
        value = 2,
        chs = "气血"
      },
      [7] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    }
  },
  ["超级鬼火萤卡"] = {
    card_level = 10,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 19,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 5,
        chs = "抗中毒"
      },
      [2] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "resist_water",
        value = 5,
        chs = "抗水"
      },
      [6] = {
        field = "max_life",
        value = 7,
        chs = "气血"
      },
      [7] = {
        field = "max_mana",
        value = 3,
        chs = "法力"
      },
      [8] = {
        field = "def",
        value = 2,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      }
    }
  },
  ["超级乌龙卡"] = {
    card_level = 11,
    polar = 5,
    card_type = CARD_TYPE.MONSTER,
    order = 20,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 5,
        chs = "抗混乱"
      },
      [2] = {
        field = "phy_absorb",
        value = 5,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_wood",
        value = -5,
        chs = "抗木"
      },
      [4] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 13,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 13,
        chs = "反震度"
      },
      [7] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      },
      [8] = {
        field = "mstunt_rate",
        value = 3,
        chs = "法术必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      }
    }
  },
  ["超级花妖卡"] = {
    card_level = 11,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 21,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 5,
        chs = "抗中毒"
      },
      [2] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "ignore_all_resist_except",
        value = 3,
        chs = "忽视所有抗异常"
      },
      [6] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [7] = {
        field = "max_mana",
        value = 5,
        chs = "法力"
      },
      [8] = {
        field = "speed",
        value = 3,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 2,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级炎龙卡"] = {
    card_level = 12,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 22,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 5,
        chs = "抗昏睡"
      },
      [2] = {
        field = "phy_absorb",
        value = 5,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "counter_attack_rate",
        value = 13,
        chs = "反击率"
      },
      [6] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [7] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 3,
        chs = "速度"
      }
    }
  },
  ["超级鱼人卡"] = {
    card_level = 12,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 23,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 5,
        chs = "抗冰冻"
      },
      [2] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [5] = {
        field = "max_life",
        value = 2,
        chs = "气血"
      },
      [6] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      },
      [7] = {
        field = "speed",
        value = 3,
        chs = "速度"
      },
      [8] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    }
  },
  ["超级冰龙卡"] = {
    card_level = 13,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 24,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 6,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 6,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 14,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 14,
        chs = "反震度"
      },
      [7] = {
        field = "mag_power",
        value = 5,
        chs = "法伤"
      },
      [8] = {
        field = "mstunt_rate",
        value = 3,
        chs = "法术必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      }
    }
  },
  ["超级地裂兽卡"] = {
    card_level = 13,
    polar = 5,
    card_type = CARD_TYPE.MONSTER,
    order = 25,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 6,
        chs = "抗混乱"
      },
      [2] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_wood",
        value = -5,
        chs = "抗木"
      },
      [4] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [5] = {
        field = "ignore_all_resist_polar",
        value = 6,
        chs = "忽视所有抗性"
      },
      [6] = {
        field = "max_life",
        value = 8,
        chs = "气血"
      },
      [7] = {
        field = "speed",
        value = 3,
        chs = "速度"
      },
      [8] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      }
    }
  },
  ["超级青龙卡"] = {
    card_level = 14,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 26,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 6,
        chs = "抗中毒"
      },
      [2] = {
        field = "phy_absorb",
        value = 6,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "mag_power",
        value = 5,
        chs = "法伤"
      },
      [6] = {
        field = "mstunt_rate",
        value = 3,
        chs = "法术必杀率"
      },
      [7] = {
        field = "ignore_all_resist_polar",
        value = 4,
        chs = "忽视所有抗性"
      },
      [8] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      }
    }
  },
  ["超级金头陀卡"] = {
    card_level = 14,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 27,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 6,
        chs = "抗混乱"
      },
      [2] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_earth",
        value = 5,
        chs = "抗土"
      },
      [4] = {
        field = "double_hit_rate",
        value = 11,
        chs = "物理连击率"
      },
      [5] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [6] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      },
      [7] = {
        field = "phy_power",
        value = 5,
        chs = "物伤"
      },
      [8] = {
        field = "speed",
        value = 3,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      }
    }
  },
  ["超级巨蜥卡"] = {
    card_level = 15,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 28,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 6,
        chs = "抗昏睡"
      },
      [2] = {
        field = "phy_absorb",
        value = 6,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 14,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 14,
        chs = "反震度"
      },
      [7] = {
        field = "speed",
        value = 5,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 3,
        chs = "速度"
      }
    }
  },
  ["超级石魔卡"] = {
    card_level = 15,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 29,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 6,
        chs = "抗遗忘"
      },
      [2] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 5,
        chs = "抗金"
      },
      [4] = {
        field = "counter_attack_rate",
        value = 15,
        chs = "反击率"
      },
      [5] = {
        field = "stunt_rate",
        value = 12,
        chs = "物理必杀率"
      },
      [6] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [7] = {
        field = "phy_power",
        value = 5,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      }
    }
  },
  ["超级黄龙卡"] = {
    card_level = 16,
    polar = 1,
    card_type = CARD_TYPE.MONSTER,
    order = 30,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 6,
        chs = "抗遗忘"
      },
      [2] = {
        field = "phy_absorb",
        value = 6,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 5,
        chs = "抗木"
      },
      [5] = {
        field = "resist_fire",
        value = -5,
        chs = "抗火"
      },
      [6] = {
        field = "mag_power",
        value = 5,
        chs = "法伤"
      },
      [7] = {
        field = "mstunt_rate",
        value = 4,
        chs = "法术必杀率"
      },
      [8] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      }
    }
  },
  ["超级火鸦卡"] = {
    card_level = 16,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 31,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 6,
        chs = "抗昏睡"
      },
      [2] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [5] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [6] = {
        field = "ignore_all_resist_except",
        value = 4,
        chs = "忽视所有抗异常"
      },
      [7] = {
        field = "max_mana",
        value = 4,
        chs = "法力"
      },
      [8] = {
        field = "speed",
        value = 3,
        chs = "速度"
      },
      [9] = {
        field = "def",
        value = 2,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 2,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级屈魂卡"] = {
    card_level = 17,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 32,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 7,
        chs = "抗中毒"
      },
      [2] = {
        field = "phy_absorb",
        value = 7,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 15,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 15,
        chs = "反震度"
      },
      [7] = {
        field = "max_life",
        value = 9,
        chs = "气血"
      },
      [8] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      }
    }
  },
  ["超级怨鬼卡"] = {
    card_level = 17,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 33,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 7,
        chs = "抗冰冻"
      },
      [2] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [5] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [6] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [7] = {
        field = "max_mana",
        value = 2,
        chs = "法力"
      },
      [8] = {
        field = "speed",
        value = 4,
        chs = "速度"
      },
      [9] = {
        field = "def",
        value = 6,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    }
  },
  ["超级粉衣仙子卡"] = {
    card_level = 18,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 34,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 7,
        chs = "抗混乱"
      },
      [2] = {
        field = "phy_absorb",
        value = 7,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_earth",
        value = 5,
        chs = "抗土"
      },
      [4] = {
        field = "double_hit_rate",
        value = 13,
        chs = "物理连击率"
      },
      [5] = {
        field = "counter_attack_rate",
        value = 15,
        chs = "反击率"
      },
      [6] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [7] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [8] = {
        field = "max_mana",
        value = 2,
        chs = "法力"
      },
      [9] = {
        field = "phy_power",
        value = 6,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      }
    }
  },
  ["超级电精卡"] = {
    card_level = 18,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 35,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 7,
        chs = "抗昏睡"
      },
      [2] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [5] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [6] = {
        field = "mag_power",
        value = 6,
        chs = "法伤"
      },
      [7] = {
        field = "mstunt_rate",
        value = 4,
        chs = "法术必杀率"
      },
      [8] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [9] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      }
    }
  },
  ["超级青衣仙子卡"] = {
    card_level = 19,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 36,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 7,
        chs = "抗中毒"
      },
      [2] = {
        field = "phy_absorb",
        value = 7,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "ignore_all_resist_polar",
        value = 4,
        chs = "忽视所有抗性"
      },
      [6] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      },
      [7] = {
        field = "max_mana",
        value = 4,
        chs = "法力"
      },
      [8] = {
        field = "speed",
        value = 6,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 3,
        chs = "速度"
      }
    }
  },
  ["超级雨兽卡"] = {
    card_level = 19,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 37,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 7,
        chs = "抗冰冻"
      },
      [2] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_wood",
        value = 5,
        chs = "抗木"
      },
      [4] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [5] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [6] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [7] = {
        field = "max_mana",
        value = 3,
        chs = "法力"
      },
      [8] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      },
      [9] = {
        field = "def",
        value = 6,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    }
  },
  ["超级黄衣仙子卡"] = {
    card_level = 20,
    polar = 1,
    card_type = CARD_TYPE.MONSTER,
    order = 38,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 7,
        chs = "抗遗忘"
      },
      [2] = {
        field = "resist_confusion",
        value = 4,
        chs = "抗混乱"
      },
      [3] = {
        field = "phy_absorb",
        value = 7,
        chs = "抗物理"
      },
      [4] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [5] = {
        field = "resist_fire",
        value = -5,
        chs = "抗火"
      },
      [6] = {
        field = "mag_power",
        value = 6,
        chs = "法伤"
      },
      [7] = {
        field = "mstunt_rate",
        value = 4,
        chs = "法术必杀率"
      },
      [8] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      },
      [9] = {
        field = "max_mana",
        value = 4,
        chs = "法力"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      }
    }
  },
  ["超级风怪卡"] = {
    card_level = 20,
    polar = 5,
    card_type = CARD_TYPE.MONSTER,
    order = 39,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 7,
        chs = "抗混乱"
      },
      [2] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_wood",
        value = -5,
        chs = "抗木"
      },
      [4] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 16,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 16,
        chs = "反震度"
      },
      [7] = {
        field = "ignore_all_resist_except",
        value = 4,
        chs = "忽视所有抗异常"
      },
      [8] = {
        field = "max_mana",
        value = 4,
        chs = "法力"
      },
      [9] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 3,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级红衣仙子卡"] = {
    card_level = 21,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 40,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 5,
        chs = "抗中毒"
      },
      [2] = {
        field = "resist_sleep",
        value = 8,
        chs = "抗昏睡"
      },
      [3] = {
        field = "phy_absorb",
        value = 8,
        chs = "抗物理"
      },
      [4] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [5] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [6] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      },
      [7] = {
        field = "max_life",
        value = 2,
        chs = "气血"
      },
      [8] = {
        field = "max_mana",
        value = 2,
        chs = "法力"
      },
      [9] = {
        field = "speed",
        value = 7,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 3,
        chs = "速度"
      }
    }
  },
  ["超级虹妖卡"] = {
    card_level = 21,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 41,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 8,
        chs = "抗混乱"
      },
      [2] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_water",
        value = 4,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [5] = {
        field = "stunt_rate",
        value = 15,
        chs = "物理必杀率"
      },
      [6] = {
        field = "phy_power",
        value = 7,
        chs = "物伤"
      },
      [7] = {
        field = "def",
        value = 5,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      }
    }
  },
  ["超级紫衣仙子卡"] = {
    card_level = 22,
    polar = 5,
    card_type = CARD_TYPE.MONSTER,
    order = 42,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 8,
        chs = "抗混乱"
      },
      [2] = {
        field = "phy_absorb",
        value = 8,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_wood",
        value = -5,
        chs = "抗木"
      },
      [4] = {
        field = "resist_earth",
        value = 15,
        chs = "抗土"
      },
      [5] = {
        field = "mag_power",
        value = 5,
        chs = "法伤"
      },
      [6] = {
        field = "mstunt_rate",
        value = 2,
        chs = "法术必杀率"
      },
      [7] = {
        field = "max_life",
        value = 10,
        chs = "气血"
      },
      [8] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      }
    }
  },
  ["超级雪女卡"] = {
    card_level = 22,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 43,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 8,
        chs = "抗冰冻"
      },
      [2] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 4,
        chs = "抗火"
      },
      [5] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [6] = {
        field = "damage_sel_rate",
        value = 17,
        chs = "反震率"
      },
      [7] = {
        field = "damage_sel",
        value = 17,
        chs = "反震度"
      },
      [8] = {
        field = "mag_power",
        value = 7,
        chs = "法伤"
      },
      [9] = {
        field = "mstunt_rate",
        value = 5,
        chs = "法术必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      }
    }
  },
  ["超级蓝衣仙子卡"] = {
    card_level = 23,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 44,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 8,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 8,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = 15,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [5] = {
        field = "stunt_rate",
        value = 4,
        chs = "物理必杀率"
      },
      [6] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [7] = {
        field = "phy_power",
        value = 5,
        chs = "物伤"
      },
      [8] = {
        field = "def",
        value = 7,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    }
  },
  ["超级云兽卡"] = {
    card_level = 23,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 45,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 8,
        chs = "抗遗忘"
      },
      [2] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_wood",
        value = 5,
        chs = "抗木"
      },
      [4] = {
        field = "resist_water",
        value = 5,
        chs = "抗水"
      },
      [5] = {
        field = "resist_fire",
        value = 4,
        chs = "抗火"
      },
      [6] = {
        field = "double_hit_rate",
        value = 16,
        chs = "物理连击率"
      },
      [7] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [8] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      },
      [9] = {
        field = "phy_power",
        value = 7,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      }
    }
  },
  ["超级白衣仙子卡"] = {
    card_level = 24,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 46,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 8,
        chs = "抗昏睡"
      },
      [2] = {
        field = "phy_absorb",
        value = 8,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = 4,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "counter_attack_rate",
        value = 17,
        chs = "反击率"
      },
      [6] = {
        field = "stunt_rate",
        value = 16,
        chs = "物理必杀率"
      },
      [7] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [8] = {
        field = "phy_power",
        value = 7,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 3,
        chs = "物伤"
      }
    }
  },
  ["超级雷怪卡"] = {
    card_level = 24,
    polar = 1,
    card_type = CARD_TYPE.MONSTER,
    order = 47,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 8,
        chs = "抗遗忘"
      },
      [2] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 5,
        chs = "抗木"
      },
      [5] = {
        field = "resist_fire",
        value = -5,
        chs = "抗火"
      },
      [6] = {
        field = "mag_power",
        value = 7,
        chs = "法伤"
      },
      [7] = {
        field = "mstunt_rate",
        value = 5,
        chs = "法术必杀率"
      },
      [8] = {
        field = "speed",
        value = 5,
        chs = "速度"
      },
      [9] = {
        field = "def",
        value = 5,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 3,
        chs = "法伤"
      }
    }
  },
  ["超级火光鼠卡"] = {
    card_level = 25,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 68,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 9,
        chs = "抗昏睡"
      },
      [2] = {
        field = "phy_absorb",
        value = 9,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "stunt_rate",
        value = 5,
        chs = "物理必杀率"
      },
      [6] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      },
      [7] = {
        field = "phy_power",
        value = 5,
        chs = "物伤"
      },
      [8] = {
        field = "speed",
        value = 7,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    }
  },
  ["超级紫燕卡"] = {
    card_level = 25,
    polar = 5,
    card_type = CARD_TYPE.MONSTER,
    order = 69,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 9,
        chs = "抗混乱"
      },
      [2] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = -5,
        chs = "抗木"
      },
      [5] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [6] = {
        field = "damage_sel_rate",
        value = 18,
        chs = "反震率"
      },
      [7] = {
        field = "damage_sel",
        value = 18,
        chs = "反震度"
      },
      [8] = {
        field = "max_life",
        value = 11,
        chs = "气血"
      },
      [9] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      }
    }
  },
  ["超级石牛妖卡"] = {
    card_level = 25,
    polar = 5,
    card_type = CARD_TYPE.MONSTER,
    order = 70,
    attrib = {
      [1] = {
        field = "resist_confusion",
        value = 9,
        chs = "抗混乱"
      },
      [2] = {
        field = "phy_absorb",
        value = 9,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_wood",
        value = -5,
        chs = "抗木"
      },
      [4] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [5] = {
        field = "counter_attack_rate",
        value = 18,
        chs = "反击率"
      },
      [6] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [7] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [8] = {
        field = "phy_power",
        value = 5,
        chs = "物伤"
      },
      [9] = {
        field = "def",
        value = 7,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    }
  },
  ["超级不灭战将卡"] = {
    card_level = 25,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 71,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 9,
        chs = "抗中毒"
      },
      [2] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "mag_power",
        value = 7,
        chs = "法伤"
      },
      [6] = {
        field = "mstunt_rate",
        value = 5,
        chs = "法术必杀率"
      },
      [7] = {
        field = "ignore_all_resist_polar",
        value = 5,
        chs = "忽视所有抗性"
      },
      [8] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      },
      [9] = {
        field = "max_mana",
        value = 5,
        chs = "法力"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      }
    }
  },
  ["超级蓝毛巨兽卡"] = {
    card_level = 26,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 72,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 9,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 9,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [5] = {
        field = "stunt_rate",
        value = 5,
        chs = "物理必杀率"
      },
      [6] = {
        field = "ignore_all_resist_except",
        value = 6,
        chs = "忽视所有抗异常"
      },
      [7] = {
        field = "phy_power",
        value = 5,
        chs = "物伤"
      },
      [8] = {
        field = "speed",
        value = 5,
        chs = "速度"
      },
      [9] = {
        field = "def",
        value = 6,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 3,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级螳螂怪卡"] = {
    card_level = 26,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 73,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 9,
        chs = "抗遗忘"
      },
      [2] = {
        field = "resist_frozen",
        value = 6,
        chs = "抗冰冻"
      },
      [3] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [4] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [5] = {
        field = "double_hit_rate",
        value = 17,
        chs = "物理连击率"
      },
      [6] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [7] = {
        field = "max_mana",
        value = 5,
        chs = "法力"
      },
      [8] = {
        field = "phy_power",
        value = 7,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    }
  },
  ["超级三头巨犬卡"] = {
    card_level = 27,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 74,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 9,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 9,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [4] = {
        field = "resist_fire",
        value = 6,
        chs = "抗火"
      },
      [5] = {
        field = "stunt_rate",
        value = 18,
        chs = "物理必杀率"
      },
      [6] = {
        field = "phy_power",
        value = 7,
        chs = "物伤"
      },
      [7] = {
        field = "def",
        value = 5,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    }
  },
  ["超级凶蛮巨人卡"] = {
    card_level = 27,
    polar = 1,
    card_type = CARD_TYPE.MONSTER,
    order = 75,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 9,
        chs = "抗遗忘"
      },
      [2] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [4] = {
        field = "resist_water",
        value = 6,
        chs = "抗水"
      },
      [5] = {
        field = "resist_fire",
        value = -5,
        chs = "抗火"
      },
      [6] = {
        field = "resist_earth",
        value = 5,
        chs = "抗土"
      },
      [7] = {
        field = "mag_power",
        value = 7,
        chs = "法伤"
      },
      [8] = {
        field = "mstunt_rate",
        value = 6,
        chs = "法术必杀率"
      },
      [9] = {
        field = "max_life",
        value = 6,
        chs = "气血"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      }
    }
  },
  ["超级炼魔卡"] = {
    card_level = 28,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 76,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 9,
        chs = "抗昏睡"
      },
      [2] = {
        field = "phy_absorb",
        value = 9,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 19,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 19,
        chs = "反震度"
      },
      [7] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      },
      [8] = {
        field = "speed",
        value = 7,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    }
  },
  ["超级寒冰怪卡"] = {
    card_level = 28,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 77,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 6,
        chs = "抗中毒"
      },
      [2] = {
        field = "resist_frozen",
        value = 9,
        chs = "抗冰冻"
      },
      [3] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [4] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [5] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [6] = {
        field = "counter_attack_rate",
        value = 19,
        chs = "反击率"
      },
      [7] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [8] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [9] = {
        field = "def",
        value = 7,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    }
  },
  ["超级虾兵卡"] = {
    card_level = 29,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 78,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 10,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 10,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [5] = {
        field = "stunt_rate",
        value = 5,
        chs = "物理必杀率"
      },
      [6] = {
        field = "max_life",
        value = 11,
        chs = "气血"
      },
      [7] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      },
      [8] = {
        field = "phy_power",
        value = 6,
        chs = "物伤"
      },
      [9] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 6,
        chs = "气血"
      }
    }
  },
  ["超级蟹将卡"] = {
    card_level = 29,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 79,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 10,
        chs = "抗遗忘"
      },
      [2] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [4] = {
        field = "stunt_rate",
        value = 19,
        chs = "物理必杀率"
      },
      [5] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      },
      [6] = {
        field = "max_mana",
        value = 2,
        chs = "法力"
      },
      [7] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      },
      [8] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    }
  },
  ["超级冰晶龙鳞兽卡"] = {
    card_level = 30,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 80,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 5,
        chs = "抗中毒"
      },
      [2] = {
        field = "resist_frozen",
        value = 10,
        chs = "抗冰冻"
      },
      [3] = {
        field = "phy_absorb",
        value = 10,
        chs = "抗物理"
      },
      [4] = {
        field = "resist_wood",
        value = 6,
        chs = "抗木"
      },
      [5] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [6] = {
        field = "resist_fire",
        value = 6,
        chs = "抗火"
      },
      [7] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [8] = {
        field = "ignore_all_resist_except",
        value = 7,
        chs = "忽视所有抗异常"
      },
      [9] = {
        field = "speed",
        value = 6,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 3,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级金翅鸢卡"] = {
    card_level = 30,
    polar = 1,
    card_type = CARD_TYPE.MONSTER,
    order = 81,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 10,
        chs = "抗遗忘"
      },
      [2] = {
        field = "resist_confusion",
        value = 6,
        chs = "抗混乱"
      },
      [3] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [4] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [5] = {
        field = "resist_fire",
        value = -5,
        chs = "抗火"
      },
      [6] = {
        field = "mag_power",
        value = 8,
        chs = "法伤"
      },
      [7] = {
        field = "mstunt_rate",
        value = 6,
        chs = "法术必杀率"
      },
      [8] = {
        field = "max_life",
        value = 6,
        chs = "气血"
      },
      [9] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      }
    }
  },
  ["超级雪狐卡"] = {
    card_level = 31,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 84,
    attrib = {
      [1] = {
        field = "resist_poison",
        value = 10,
        chs = "抗中毒"
      },
      [2] = {
        field = "phy_absorb",
        value = 10,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [5] = {
        field = "resist_water",
        value = 6,
        chs = "抗水"
      },
      [6] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      },
      [7] = {
        field = "speed",
        value = 8,
        chs = "速度"
      },
      [8] = {
        field = "def",
        value = 6,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    }
  },
  ["超级剑魂卡"] = {
    card_level = 31,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 85,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 6,
        chs = "抗遗忘"
      },
      [2] = {
        field = "resist_confusion",
        value = 10,
        chs = "抗混乱"
      },
      [3] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [4] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [5] = {
        field = "double_hit_rate",
        value = 20,
        chs = "物理连击率"
      },
      [6] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [7] = {
        field = "max_life",
        value = 6,
        chs = "气血"
      },
      [8] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      },
      [9] = {
        field = "speed",
        value = 6,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    }
  },
  ["超级狰兽卡"] = {
    card_level = 32,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 87,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 6,
        chs = "抗冰冻"
      },
      [2] = {
        field = "resist_sleep",
        value = 10,
        chs = "抗昏睡"
      },
      [3] = {
        field = "phy_absorb",
        value = 10,
        chs = "抗物理"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "stunt_rate",
        value = 20,
        chs = "物理必杀率"
      },
      [6] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      },
      [7] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      },
      [8] = {
        field = "speed",
        value = 6,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    }
  },
  ["超级蝶仙卡"] = {
    card_level = 32,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 86,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 10,
        chs = "抗昏睡"
      },
      [2] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "damage_sel_rate",
        value = 20,
        chs = "反震率"
      },
      [6] = {
        field = "damage_sel",
        value = 20,
        chs = "反震度"
      },
      [7] = {
        field = "ignore_all_resist_except",
        value = 7,
        chs = "忽视所有抗异常"
      },
      [8] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      },
      [9] = {
        field = "speed",
        value = 6,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 3,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级蚌姬卡"] = {
    card_level = 33,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 89,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 11,
        chs = "抗冰冻"
      },
      [2] = {
        field = "phy_absorb",
        value = 11,
        chs = "抗物理"
      },
      [3] = {
        field = "resist_metal",
        value = 6,
        chs = "抗金"
      },
      [4] = {
        field = "resist_wood",
        value = 6,
        chs = "抗木"
      },
      [5] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [6] = {
        field = "resist_fire",
        value = 6,
        chs = "抗火"
      },
      [7] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [8] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      },
      [9] = {
        field = "def",
        value = 9,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    }
  },
  ["超级水魔神卡"] = {
    card_level = 33,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 88,
    attrib = {
      [1] = {
        field = "resist_frozen",
        value = 11,
        chs = "抗冰冻"
      },
      [2] = {
        field = "mag_absorb",
        value = 6,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 12,
        chs = "抗火"
      },
      [5] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [6] = {
        field = "mag_power",
        value = 9,
        chs = "法伤"
      },
      [7] = {
        field = "mstunt_rate",
        value = 7,
        chs = "法术必杀率"
      },
      [8] = {
        field = "max_mana",
        value = 3,
        chs = "法力"
      },
      [9] = {
        field = "speed",
        value = 3,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      }
    }
  },
  ["超级伶俐鼠卡"] = {
    card_level = 0,
    polar = 4,
    card_type = CARD_TYPE.ELITE,
    order = 48,
    attrib = {
      [1] = {
        field = "ignore_all_resist_polar",
        value = 8,
        chs = "忽视所有抗性"
      },
      [2] = {
        field = "speed",
        value = 10,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 5,
        chs = "速度"
      }
    }
  },
  ["超级笨笨牛卡"] = {
    card_level = 0,
    polar = 0,
    card_type = CARD_TYPE.ELITE,
    order = 49,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 5,
        chs = "抗遗忘"
      },
      [2] = {
        field = "resist_poison",
        value = 5,
        chs = "抗中毒"
      },
      [3] = {
        field = "resist_frozen",
        value = 5,
        chs = "抗冰冻"
      },
      [4] = {
        field = "resist_sleep",
        value = 5,
        chs = "抗昏睡"
      },
      [5] = {
        field = "resist_confusion",
        value = 5,
        chs = "抗混乱"
      },
      [6] = {
        field = "stunt_rate",
        value = 15,
        chs = "物理必杀率"
      },
      [7] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 6,
        chs = "物伤"
      }
    }
  },
  ["超级威威虎卡"] = {
    card_level = 0,
    polar = 0,
    card_type = CARD_TYPE.ELITE,
    order = 50,
    attrib = {
      [1] = {
        field = "double_hit_rate",
        value = 15,
        chs = "物理连击率"
      },
      [2] = {
        field = "double_hit",
        value = 3,
        chs = "物理连击数"
      },
      [3] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      },
      [4] = {
        field = "speed",
        value = 5,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 6,
        chs = "物伤"
      }
    }
  },
  ["超级跳跳兔卡"] = {
    card_level = 0,
    polar = 2,
    card_type = CARD_TYPE.ELITE,
    order = 51,
    attrib = {
      [1] = {
        field = "mag_power",
        value = 8,
        chs = "法伤"
      },
      [2] = {
        field = "mstunt_rate",
        value = 5,
        chs = "法术必杀率"
      },
      [3] = {
        field = "ignore_all_resist_polar",
        value = 5,
        chs = "忽视所有抗性"
      },
      [4] = {
        field = "max_life",
        value = 15,
        chs = "气血"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 6,
        chs = "法伤"
      }
    }
  },
  ["超级酷酷龙卡"] = {
    card_level = 0,
    polar = 1,
    card_type = CARD_TYPE.ELITE,
    order = 52,
    attrib = {
      [1] = {
        field = "mag_power",
        value = 8,
        chs = "法伤"
      },
      [2] = {
        field = "mstunt_rate",
        value = 10,
        chs = "法术必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 6,
        chs = "法伤"
      }
    }
  },
  ["超级花花蛇卡"] = {
    card_level = 0,
    polar = 3,
    card_type = CARD_TYPE.ELITE,
    order = 53,
    attrib = {
      [1] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [2] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [3] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [6] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      },
      [7] = {
        field = "def",
        value = 10,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 5,
        chs = "防御"
      }
    }
  },
  ["超级溜溜马卡"] = {
    card_level = 0,
    polar = 0,
    card_type = CARD_TYPE.ELITE,
    order = 54,
    attrib = {
      [1] = {
        field = "phy_absorb",
        value = 20,
        chs = "抗物理"
      },
      [2] = {
        field = "max_life",
        value = 15,
        chs = "气血"
      },
      [3] = {
        field = "def",
        value = 5,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 9,
        chs = "气血"
      }
    }
  },
  ["超级咩咩羊卡"] = {
    card_level = 0,
    polar = 3,
    card_type = CARD_TYPE.ELITE,
    order = 55,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 10,
        chs = "抗遗忘"
      },
      [2] = {
        field = "resist_poison",
        value = 10,
        chs = "抗中毒"
      },
      [3] = {
        field = "resist_frozen",
        value = 10,
        chs = "抗冰冻"
      },
      [4] = {
        field = "resist_sleep",
        value = 10,
        chs = "抗昏睡"
      },
      [5] = {
        field = "resist_confusion",
        value = 10,
        chs = "抗混乱"
      },
      [6] = {
        field = "def",
        value = 10,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "all_resist_except",
        value = 5,
        chs = "所有抗异常"
      }
    }
  },
  ["超级帅帅猴卡"] = {
    card_level = 0,
    polar = 0,
    card_type = CARD_TYPE.ELITE,
    order = 56,
    attrib = {
      [1] = {
        field = "double_hit_rate",
        value = 30,
        chs = "物理连击率"
      },
      [2] = {
        field = "double_hit",
        value = 3,
        chs = "物理连击数"
      },
      [3] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 6,
        chs = "物伤"
      }
    }
  },
  ["超级蛋蛋鸡卡"] = {
    card_level = 0,
    polar = 4,
    card_type = CARD_TYPE.ELITE,
    order = 57,
    attrib = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 8,
        chs = "忽视所有抗异常"
      },
      [2] = {
        field = "speed",
        value = 7,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 5,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级乖乖狗卡"] = {
    card_level = 0,
    polar = 0,
    card_type = CARD_TYPE.ELITE,
    order = 58,
    attrib = {
      [1] = {
        field = "stunt_rate",
        value = 30,
        chs = "物理必杀率"
      },
      [2] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 6,
        chs = "物伤"
      }
    }
  },
  ["超级招财猪卡"] = {
    card_level = 0,
    polar = 5,
    card_type = CARD_TYPE.ELITE,
    order = 59,
    attrib = {
      [1] = {
        field = "super_forgotten",
        value = 5,
        chs = "强力遗忘"
      },
      [2] = {
        field = "super_poison",
        value = 5,
        chs = "强力中毒"
      },
      [3] = {
        field = "super_frozen",
        value = 5,
        chs = "强力冰冻"
      },
      [4] = {
        field = "super_sleep",
        value = 5,
        chs = "强力昏睡"
      },
      [5] = {
        field = "super_confusion",
        value = 5,
        chs = "强力混乱"
      },
      [6] = {
        field = "max_life",
        value = 15,
        chs = "气血"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 9,
        chs = "气血"
      }
    }
  },
  ["超级羊头怪卡"] = {
    card_level = 5,
    polar = 4,
    card_type = CARD_TYPE.BOSS,
    portrait = 6215,
    order = 60,
    attrib = {
      [1] = {
        field = "phy_absorb",
        value = 4,
        chs = "抗物理"
      },
      [2] = {
        field = "speed",
        value = 7,
        chs = "速度"
      }
    },
    battle_arr = {}
  },
  ["超级牛头怪卡"] = {
    card_level = 8,
    polar = 1,
    card_type = CARD_TYPE.BOSS,
    portrait = 6214,
    order = 61,
    attrib = {
      [1] = {
        field = "mag_absorb",
        value = 2,
        chs = "抗法术"
      },
      [2] = {
        field = "max_life",
        value = 11,
        chs = "气血"
      },
      [3] = {
        field = "def",
        value = 3,
        chs = "防御"
      }
    },
    battle_arr = {}
  },
  ["超级黑熊精卡"] = {
    card_level = 11,
    polar = 0,
    card_type = CARD_TYPE.BOSS,
    portrait = 6203,
    order = 62,
    attrib = {
      [1] = {
        field = "stunt_rate",
        value = 10,
        chs = "物理必杀率"
      },
      [2] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      }
    },
    battle_arr = {}
  },
  ["超级狂狮怪卡"] = {
    card_level = 14,
    polar = 1,
    card_type = CARD_TYPE.BOSS,
    portrait = 6209,
    order = 63,
    attrib = {
      [1] = {
        field = "mag_absorb",
        value = 3,
        chs = "抗法术"
      },
      [2] = {
        field = "mag_power",
        value = 9,
        chs = "法伤"
      },
      [3] = {
        field = "mstunt_rate",
        value = 3,
        chs = "法术必杀率"
      }
    },
    battle_arr = {}
  },
  ["超级刺猬精卡"] = {
    card_level = 18,
    polar = 2,
    card_type = CARD_TYPE.BOSS,
    portrait = 6210,
    order = 64,
    attrib = {
      [1] = {
        field = "phy_absorb",
        value = 7,
        chs = "抗物理"
      },
      [2] = {
        field = "speed",
        value = 10,
        chs = "速度"
      }
    },
    battle_arr = {}
  },
  ["超级猪妖卡"] = {
    card_level = 21,
    polar = 5,
    card_type = CARD_TYPE.BOSS,
    portrait = 6208,
    order = 65,
    attrib = {
      [1] = {
        field = "mag_absorb",
        value = 4,
        chs = "抗法术"
      },
      [2] = {
        field = "max_life",
        value = 3,
        chs = "气血"
      },
      [3] = {
        field = "def",
        value = 11,
        chs = "防御"
      }
    },
    battle_arr = {}
  },
  ["超级象精卡"] = {
    card_level = 25,
    polar = 3,
    card_type = CARD_TYPE.BOSS,
    portrait = 6207,
    order = 66,
    attrib = {
      [1] = {
        field = "phy_absorb",
        value = 9,
        chs = "抗物理"
      },
      [2] = {
        field = "double_hit_rate",
        value = 17,
        chs = "物理连击率"
      },
      [3] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [4] = {
        field = "phy_power",
        value = 12,
        chs = "物伤"
      }
    },
    battle_arr = {}
  },
  ["超级百花羞卡"] = {
    card_level = 27,
    polar = 2,
    card_type = CARD_TYPE.BOSS,
    portrait = 6241,
    order = 67,
    attrib = {
      [1] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [2] = {
        field = "mag_power",
        value = 12,
        chs = "法伤"
      },
      [3] = {
        field = "mstunt_rate",
        value = 6,
        chs = "法术必杀率"
      }
    },
    battle_arr = {}
  },
  ["超级牛魔王卡"] = {
    card_level = 29,
    polar = 0,
    card_type = CARD_TYPE.BOSS,
    portrait = 6259,
    order = 82,
    attrib = {
      [1] = {
        field = "phy_absorb",
        value = 10,
        chs = "抗物理"
      },
      [2] = {
        field = "max_life",
        value = 18,
        chs = "气血"
      },
      [3] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    },
    battle_arr = {}
  },
  ["超级夜叉王卡"] = {
    card_level = 31,
    polar = 4,
    card_type = CARD_TYPE.BOSS,
    portrait = 6277,
    order = 83,
    attrib = {
      [1] = {
        field = "mag_absorb",
        value = 5,
        chs = "抗法术"
      },
      [2] = {
        field = "speed",
        value = 13,
        chs = "速度"
      }
    },
    battle_arr = {}
  },
  ["超级罗刹王卡"] = {
    card_level = 33,
    polar = 1,
    card_type = CARD_TYPE.BOSS,
    portrait = 6278,
    order = 90,
    attrib = {
      [1] = {
        field = "stunt_rate",
        value = 21,
        chs = "物理必杀率"
      },
      [2] = {
        field = "phy_power",
        value = 14,
        chs = "物伤"
      }
    },
    battle_arr = {}
  },
  ["超级疆良卡"] = {
    card_level = 0,
    polar = 0,
    card_type = CARD_TYPE.EPIC,
    portrait = 6189,
    order = 91,
    attrib = {
      [1] = {
        field = "stunt_rate",
        value = 30,
        chs = "物理必杀率"
      },
      [2] = {
        field = "phy_power",
        value = 9,
        chs = "物伤"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 7,
        chs = "物伤"
      }
    }
  },
  ["超级东山神灵卡"] = {
    card_level = 0,
    polar = 3,
    card_type = CARD_TYPE.EPIC,
    portrait = 6190,
    order = 92,
    attrib = {
      [1] = {
        field = "mag_power",
        value = 9,
        chs = "法伤"
      },
      [2] = {
        field = "mstunt_rate",
        value = 10,
        chs = "法术必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 7,
        chs = "法伤"
      }
    }
  },
  ["超级玄武卡"] = {
    card_level = 0,
    polar = 3,
    card_type = CARD_TYPE.EPIC,
    portrait = 6191,
    order = 93,
    attrib = {
      [1] = {
        field = "phy_absorb",
        value = 20,
        chs = "抗物理"
      },
      [2] = {
        field = "max_life",
        value = 16,
        chs = "气血"
      },
      [3] = {
        field = "def",
        value = 6,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 10,
        chs = "气血"
      }
    }
  },
  ["超级朱雀卡"] = {
    card_level = 0,
    polar = 4,
    card_type = CARD_TYPE.EPIC,
    portrait = 6192,
    order = 94,
    attrib = {
      [1] = {
        field = "ignore_all_resist_polar",
        value = 10,
        chs = "忽视所有抗性"
      },
      [2] = {
        field = "speed",
        value = 11,
        chs = "速度"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 6,
        chs = "速度"
      }
    }
  },
  ["超级金甲蝎卡"] = {
    card_level = 34,
    polar = 1,
    card_type = CARD_TYPE.MONSTER,
    order = 95,
    attrib = {
      [1] = {
        field = "resist_forgotten",
        value = 11,
        chs = "抗遗忘"
      },
      [2] = {
        field = "resist_frozen",
        value = 7,
        chs = "抗冰冻"
      },
      [3] = {
        field = "phy_absorb",
        value = 11,
        chs = "抗物理"
      },
      [4] = {
        field = "resist_metal",
        value = 10,
        chs = "抗金"
      },
      [5] = {
        field = "resist_fire",
        value = -5,
        chs = "抗火"
      },
      [6] = {
        field = "mag_power",
        value = 6,
        chs = "法伤"
      },
      [7] = {
        field = "speed",
        value = 9,
        chs = "速度"
      },
      [8] = {
        field = "def",
        value = 6,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    }
  },
  ["超级斗魔蜥卡"] = {
    card_level = 34,
    polar = 4,
    card_type = CARD_TYPE.MONSTER,
    order = 96,
    attrib = {
      [1] = {
        field = "resist_sleep",
        value = 10,
        chs = "抗昏睡"
      },
      [2] = {
        field = "mag_absorb",
        value = 6,
        chs = "抗法术"
      },
      [3] = {
        field = "resist_water",
        value = -5,
        chs = "抗水"
      },
      [4] = {
        field = "resist_fire",
        value = 10,
        chs = "抗火"
      },
      [5] = {
        field = "counter_attack_rate",
        value = 21,
        chs = "反击率"
      },
      [6] = {
        field = "counter_attack",
        value = 2,
        chs = "反击数"
      },
      [7] = {
        field = "max_life",
        value = 13,
        chs = "气血"
      },
      [8] = {
        field = "speed",
        value = 7,
        chs = "速度"
      },
      [9] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 6,
        chs = "气血"
      }
    }
  },
  ["超级白骨精卡"] = {
    card_level = 35,
    polar = 2,
    card_type = CARD_TYPE.BOSS,
    portrait = 6280,
    order = 97,
    attrib = {
      [1] = {
        field = "mag_absorb",
        value = 7,
        chs = "抗法术"
      },
      [2] = {
        field = "mag_power",
        value = 14,
        chs = "法伤"
      },
      [3] = {
        field = "mstunt_rate",
        value = 6,
        chs = "法术必杀率"
      }
    },
    battle_arr = {}
  },
  ["超级九尾狐卡"] = {
    card_level = 0,
    polar = 5,
    card_type = CARD_TYPE.EPIC,
    portrait = 6176,
    order = 98,
    attrib = {
      [1] = {
        field = "speed",
        value = 6,
        chs = "速度"
      },
      [2] = {
        field = "mag_absorb",
        value = 8,
        chs = "抗法术"
      },
      [3] = {
        field = "ignore_all_resist_except",
        value = 10,
        chs = "忽视所有抗异常"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 6,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级白矖卡"] = {
    card_level = 0,
    polar = 2,
    card_type = CARD_TYPE.EPIC,
    portrait = 6193,
    order = 99,
    attrib = {
      [1] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      },
      [2] = {
        field = "def",
        value = 11,
        chs = "防御"
      },
      [3] = {
        field = "phy_absorb",
        value = 20,
        chs = "抗物理"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 6,
        chs = "防御"
      }
    }
  },
  ["超级化蛇兽卡"] = {
    card_level = 35,
    polar = 0,
    card_type = CARD_TYPE.MONSTER,
    order = 100,
    attrib = {
      [1] = {
        field = "max_life",
        value = 6,
        chs = "气血"
      },
      [2] = {
        field = "phy_power",
        value = 9,
        chs = "物伤"
      },
      [3] = {
        field = "speed",
        value = 4,
        chs = "速度"
      },
      [4] = {
        field = "phy_absorb",
        value = 11,
        chs = "抗物理"
      },
      [5] = {
        field = "double_hit_rate",
        value = 22,
        chs = "物理连击率"
      },
      [6] = {
        field = "double_hit",
        value = 2,
        chs = "物理连击数"
      },
      [7] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [8] = {
        field = "resist_poison",
        value = 10,
        chs = "抗中毒"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 4,
        chs = "物伤"
      }
    }
  },
  ["超级狐灵卡"] = {
    card_level = 35,
    polar = 5,
    card_type = CARD_TYPE.MONSTER,
    order = 101,
    attrib = {
      [1] = {
        field = "speed",
        value = 6,
        chs = "速度"
      },
      [2] = {
        field = "def",
        value = 7,
        chs = "防御"
      },
      [3] = {
        field = "mag_power",
        value = 5,
        chs = "法伤"
      },
      [4] = {
        field = "mag_absorb",
        value = 6,
        chs = "抗法术"
      },
      [5] = {
        field = "resist_wood",
        value = -5,
        chs = "抗木"
      },
      [6] = {
        field = "resist_earth",
        value = 10,
        chs = "抗土"
      },
      [7] = {
        field = "resist_confusion",
        value = 11,
        chs = "抗混乱"
      },
      [8] = {
        field = "ignore_all_resist_except",
        value = 7,
        chs = "忽视所有抗异常"
      }
    },
    battle_arr = {
      [1] = {
        field = "ignore_all_resist_except",
        value = 4,
        chs = "忽视所有抗异常"
      }
    }
  },
  ["超级幽雪卡"] = {
    card_level = 0,
    polar = 1,
    card_type = CARD_TYPE.ELITE,
    order = 102,
    attrib = {
      [1] = {
        field = "speed",
        value = 5,
        chs = "速度"
      },
      [2] = {
        field = "mag_power",
        value = 8,
        chs = "法伤"
      },
      [3] = {
        field = "mstunt_rate",
        value = 5,
        chs = "法术必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 6,
        chs = "法伤"
      }
    }
  },
  ["超级馥汀卡"] = {
    card_level = 0,
    polar = 4,
    card_type = CARD_TYPE.ELITE,
    order = 103,
    attrib = {
      [1] = {
        field = "speed",
        value = 10,
        chs = "速度"
      },
      [2] = {
        field = "resist_forgotten",
        value = 10,
        chs = "抗遗忘"
      },
      [3] = {
        field = "resist_poison",
        value = 10,
        chs = "抗中毒"
      },
      [4] = {
        field = "resist_frozen",
        value = 10,
        chs = "抗冰冻"
      },
      [5] = {
        field = "resist_sleep",
        value = 10,
        chs = "抗昏睡"
      },
      [6] = {
        field = "resist_confusion",
        value = 10,
        chs = "抗混乱"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 5,
        chs = "速度"
      }
    }
  },
  ["超级陌玉卡"] = {
    card_level = 0,
    polar = 2,
    card_type = CARD_TYPE.ELITE,
    order = 104,
    attrib = {
      [1] = {
        field = "max_life",
        value = 5,
        chs = "气血"
      },
      [2] = {
        field = "def",
        value = 10,
        chs = "防御"
      },
      [3] = {
        field = "resist_forgotten",
        value = 5,
        chs = "抗遗忘"
      },
      [4] = {
        field = "resist_poison",
        value = 5,
        chs = "抗中毒"
      },
      [5] = {
        field = "resist_frozen",
        value = 5,
        chs = "抗冰冻"
      },
      [6] = {
        field = "resist_sleep",
        value = 5,
        chs = "抗昏睡"
      },
      [7] = {
        field = "resist_confusion",
        value = 5,
        chs = "抗混乱"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 5,
        chs = "防御"
      }
    }
  },
  ["超级九华卡"] = {
    card_level = 0,
    polar = 0,
    card_type = CARD_TYPE.ELITE,
    order = 105,
    attrib = {
      [1] = {
        field = "phy_power",
        value = 8,
        chs = "物伤"
      },
      [2] = {
        field = "speed",
        value = 5,
        chs = "速度"
      },
      [3] = {
        field = "stunt_rate",
        value = 15,
        chs = "物理必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 6,
        chs = "物伤"
      }
    }
  },
  ["超级镇水怪卡"] = {
    card_level = 36,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 106,
    attrib = {
      [1] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      },
      [2] = {
        field = "def",
        value = 9,
        chs = "防御"
      },
      [3] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      },
      [4] = {
        field = "mag_absorb",
        value = 6,
        chs = "抗法术"
      },
      [5] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [6] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [7] = {
        field = "resist_frozen",
        value = 11,
        chs = "抗冰冻"
      },
      [8] = {
        field = "damage_sel_rate",
        value = 21,
        chs = "反震率"
      },
      [9] = {
        field = "damage_sel",
        value = 7,
        chs = "反震度"
      }
    },
    battle_arr = {
      [1] = {
        field = "def",
        value = 4,
        chs = "防御"
      }
    }
  },
  ["超级秋棠仙子卡"] = {
    card_level = 36,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 107,
    attrib = {
      [1] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      },
      [2] = {
        field = "speed",
        value = 3,
        chs = "速度"
      },
      [3] = {
        field = "def",
        value = 4,
        chs = "防御"
      },
      [4] = {
        field = "mag_power",
        value = 9,
        chs = "法伤"
      },
      [5] = {
        field = "mag_absorb",
        value = 6,
        chs = "抗法术"
      },
      [6] = {
        field = "mstunt_rate",
        value = 8,
        chs = "法术必杀率"
      },
      [7] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [8] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [9] = {
        field = "resist_poison",
        value = 11,
        chs = "抗中毒"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 4,
        chs = "法伤"
      }
    }
  },
  ["超级壳妖卡"] = {
    card_level = 37,
    polar = 3,
    card_type = CARD_TYPE.MONSTER,
    order = 108,
    attrib = {
      [1] = {
        field = "max_mana",
        value = 6,
        chs = "法力"
      },
      [2] = {
        field = "phy_power",
        value = 6,
        chs = "物伤"
      },
      [3] = {
        field = "speed",
        value = 9,
        chs = "速度"
      },
      [4] = {
        field = "mag_absorb",
        value = 6,
        chs = "抗法术"
      },
      [5] = {
        field = "resist_water",
        value = 10,
        chs = "抗水"
      },
      [6] = {
        field = "resist_earth",
        value = -5,
        chs = "抗土"
      },
      [7] = {
        field = "resist_frozen",
        value = 11,
        chs = "抗冰冻"
      },
      [8] = {
        field = "resist_confusion",
        value = 8,
        chs = "抗混乱"
      }
    },
    battle_arr = {
      [1] = {
        field = "speed",
        value = 4,
        chs = "速度"
      }
    }
  },
  ["超级符灵卡"] = {
    card_level = 37,
    polar = 2,
    card_type = CARD_TYPE.MONSTER,
    order = 109,
    attrib = {
      [1] = {
        field = "max_life",
        value = 14,
        chs = "气血"
      },
      [2] = {
        field = "max_mana",
        value = 4,
        chs = "法力"
      },
      [3] = {
        field = "def",
        value = 6,
        chs = "防御"
      },
      [4] = {
        field = "phy_absorb",
        value = 12,
        chs = "抗物理"
      },
      [5] = {
        field = "resist_metal",
        value = -5,
        chs = "抗金"
      },
      [6] = {
        field = "resist_wood",
        value = 10,
        chs = "抗木"
      },
      [7] = {
        field = "resist_forgotten",
        value = 8,
        chs = "抗遗忘"
      },
      [8] = {
        field = "resist_poison",
        value = 11,
        chs = "抗中毒"
      }
    },
    battle_arr = {
      [1] = {
        field = "max_life",
        value = 6,
        chs = "气血"
      }
    }
  },
  ["超级孔雀妖姬卡"] = {
    card_level = 37,
    polar = 5,
    card_type = CARD_TYPE.BOSS,
    portrait = 6287,
    order = 110,
    attrib = {
      [1] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      },
      [2] = {
        field = "def",
        value = 14,
        chs = "防御"
      },
      [3] = {
        field = "phy_absorb",
        value = 12,
        chs = "抗物理"
      }
    },
    battle_arr = {}
  },
  ["超级勾陈卡"] = {
    card_level = 0,
    polar = 1,
    card_type = CARD_TYPE.EPIC,
    portrait = 31062,
    order = 111,
    attrib = {
      [1] = {
        field = "max_life",
        value = 4,
        chs = "气血"
      },
      [2] = {
        field = "mag_power",
        value = 9,
        chs = "法伤"
      },
      [3] = {
        field = "mstunt_rate",
        value = 10,
        chs = "法术必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "mag_power",
        value = 7,
        chs = "法伤"
      }
    }
  },
  ["超级精卫卡"] = {
    card_level = 0,
    polar = 0,
    card_type = CARD_TYPE.EPIC,
    portrait = 6194,
    order = 112,
    attrib = {
      [1] = {
        field = "phy_power",
        value = 9,
        chs = "物伤"
      },
      [2] = {
        field = "stunt_rate",
        value = 30,
        chs = "物理必杀率"
      }
    },
    battle_arr = {
      [1] = {
        field = "phy_power",
        value = 7,
        chs = "物伤"
      }
    }
  }
}
