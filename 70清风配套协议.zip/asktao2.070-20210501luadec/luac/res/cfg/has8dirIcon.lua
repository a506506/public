return {
  [6001] = true,
  [6002] = true,
  [6003] = true,
  [6004] = true,
  [6005] = true,
  [6223] = true,
  [7001] = true,
  [7002] = true,
  [7003] = true,
  [7004] = true,
  [7005] = true,
  [7006] = true,
  [7007] = true,
  [7008] = true,
  [7009] = true
}
