return {
  {
    name = CHS[3000265],
    level = 15,
    times = 10,
    activeValue = 2,
    activeLimit = 20,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        ""
      }
    },
    team = CHS[3000267],
    desc = CHS[3000268],
    reward = CHS[3000269],
    icon = "BigRewardIcon0004.png"
  },
  {
    name = CHS[3000270],
    level = 20,
    times = 10,
    activeValue = 2,
    activeLimit = 20,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000271]
      }
    },
    team = CHS[3000272],
    desc = CHS[3000273],
    reward = CHS[3000274],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[3000283],
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000284]
      }
    },
    team = CHS[3000267],
    desc = CHS[3000285],
    reward = CHS[3000286],
    icon = "BigRewardIcon0001.png"
  },
  {
    name = CHS[3000299],
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000300]
      }
    },
    team = CHS[3000288],
    desc = CHS[3000301],
    reward = CHS[3000302],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4100328],
    level = 30,
    times = 30,
    activeValue = 0.5,
    activeLimit = 15,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000292]
      }
    },
    team = CHS[3000288],
    desc = CHS[3000293],
    reward = CHS[3000294],
    icon = "BigRewardIcon0005.png"
  },
  {
    name = CHS[4100329],
    level = 100,
    times = 30,
    activeValue = 0.5,
    activeLimit = 15,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[4100321]
      }
    },
    team = CHS[3000288],
    desc = CHS[4100322],
    reward = CHS[3000294],
    icon = "BigRewardIcon0005.png"
  },
  {
    name = CHS[3000279],
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000280]
      }
    },
    team = CHS[3000267],
    desc = CHS[3000281],
    reward = CHS[3000282],
    icon = "BigRewardIcon0011.png"
  },
  {
    name = CHS[3000295],
    level = 35,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000296]
      }
    },
    team = CHS[3003139],
    desc = CHS[3000297],
    reward = CHS[3000298],
    icon = "BigRewardIcon0008.png"
  },
  {
    name = CHS[3000303],
    level = 40,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000284]
      }
    },
    team = CHS[3000272],
    desc = CHS[3000304],
    reward = CHS[3000305],
    icon = "BigRewardIcon0001.png"
  },
  {
    name = CHS[3000287],
    level = 45,
    times = -1,
    activeValue = 0.5,
    activeLimit = 50,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "dlg",
        "GetTaoDlg"
      }
    },
    team = CHS[3000288],
    desc = CHS[3000289],
    reward = CHS[3000290],
    icon = "BigRewardIcon0006.png"
  },
  {
    name = CHS[7002071],
    level = 45,
    times = 70,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[7002074]
      }
    },
    team = CHS[3000267],
    desc = CHS[7002072],
    changeCfgTime = {
      beta = {
        time = "20190916050000",
        times = 30,
        desc = CHS[7150223]
      },
      release = {
        time = "20190923050000",
        times = 30,
        desc = CHS[7150223]
      }
    },
    reward = CHS[7002073],
    icon = "BigRewardIcon0053.png"
  },
  {
    name = CHS[3000275],
    level = 50,
    times = 1,
    activeValue = 20,
    activeLimit = 20,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000276]
      }
    },
    team = CHS[3000272],
    desc = CHS[3000277],
    reward = CHS[3000278],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450031],
    level = 70,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[5450034]
      }
    },
    team = CHS[3000267],
    desc = CHS[5450032],
    reward = CHS[5450033],
    icon = "BigRewardIcon0053.png"
  },
  {
    name = CHS[3000314],
    level = 60,
    times = 7,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000311]
      }
    },
    team = CHS[3000267],
    desc = CHS[3000315],
    reward = CHS[3000316],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[5400835],
    task_name = CHS[5450543],
    level = 75,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[5400840]
      }
    },
    team = CHS[3000267],
    desc = CHS[5400836],
    reward = CHS[2100463],
    icon = "BigRewardIcon0064.png"
  },
  {
    name = CHS[7000278],
    level = 70,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[7000279]
      }
    },
    team = CHS[3000267],
    desc = CHS[7000280],
    reward = CHS[7000281],
    icon = "BigRewardIcon0040.png"
  },
  {
    name = CHS[7190752],
    level = 70,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[7100574]
      }
    },
    team = CHS[3000267],
    desc = CHS[7190753],
    reward = CHS[7100786],
    icon = "BigRewardIcon0064.png"
  },
  {
    name = CHS[7366788],
    level = 70,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[7366789]
      }
    },
    team = CHS[3000267],
    desc = CHS[7366790],
    reward = CHS[7366791],
    icon = "BigRewardIcon0052.png"
  }
}
