return {
  [50202] = {
    stand = {
      {
        "stand",
        {5, 25}
      },
      {"stand2", 1}
    }
  },
  [50209] = {
    stand = {
      {
        "stand",
        {5, 25}
      },
      {"stand2", 1}
    }
  },
  [50216] = {
    stand = {
      {
        "stand",
        {5, 25}
      },
      {"stand2", 1}
    }
  },
  [50218] = {
    stand = {
      {
        "stand",
        {5, 25}
      },
      {"stand2", 1}
    }
  }
}
