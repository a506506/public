return {
  {
    name = CHS[7190224],
    level = 50,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[7190228],
        "npc",
        CHS[7190225]
      }
    },
    team = CHS[3000267],
    desc = CHS[7190226],
    reward = CHS[7190227],
    goToBtnSameAsTaskPanel = true,
    itemName = CHS[7100219]
  },
  {
    name = CHS[7190182],
    level = 75,
    times = -1,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[7100255]
      }
    },
    team = CHS[3000267],
    desc = CHS[7100254],
    reward = CHS[7100256],
    icon = "BigRewardIcon0054.png"
  },
  {
    name = CHS[6400041],
    level = 70,
    times = 10,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[7200004]
      }
    },
    team = CHS[3000267],
    desc = CHS[7200005],
    reward = CHS[7200006],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[3000704],
    level = 25,
    times = 5,
    activeValue = 1,
    activeLimit = 5,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000705],
        "",
        ""
      }
    },
    team = CHS[3000698],
    desc = CHS[3000706] .. CHS[3000707],
    reward = CHS[3000708],
    icon = "BigRewardIcon0009.png"
  },
  {
    name = CHS[3000709],
    level = 55,
    times = 5,
    activeValue = 1,
    activeLimit = 5,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000705],
        "",
        ""
      }
    },
    team = CHS[3000698],
    desc = CHS[3000710] .. CHS[3000711],
    reward = CHS[3000712],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4010374],
    level = 35,
    times = 3,
    activeValue = 1,
    activeLimit = 3,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000705],
        "",
        ""
      }
    },
    team = CHS[3000267],
    desc = CHS[4010375],
    reward = CHS[4010376],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[6400005],
    level = 20,
    times = 5,
    activeValue = 1,
    activeLimit = 5,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000705],
        "",
        ""
      }
    },
    team = CHS[3000698],
    desc = CHS[6400006],
    reward = CHS[6400007],
    icon = "BigRewardIcon0009.png"
  },
  {
    name = CHS[4010596],
    level = 70,
    times = 35,
    testTimes = 70,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000705],
        "npc",
        CHS[4010597]
      }
    },
    team = CHS[3000267],
    desc = CHS[4010598],
    reward = CHS[4010599],
    icon = "BigRewardIcon0104.png"
  },
  {
    name = CHS[4100728],
    level = 75,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[4100732]
      }
    },
    team = CHS[3000267],
    desc = CHS[4100729],
    reward = CHS[4100730],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[2000927],
    level = 20,
    times = 0,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000705],
        "npc",
        CHS[2000928]
      }
    },
    team = CHS[3000730],
    desc = CHS[2000929],
    reward = CHS[2000930],
    icon = "BigRewardIcon0026.png"
  },
  {
    name = CHS[6000274],
    level = 25,
    times = 1,
    activeValue = 5,
    activeLimit = 5,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000705],
        "",
        ""
      }
    },
    team = CHS[3000698],
    desc = CHS[6000275],
    reward = CHS[6000276],
    icon = "BigRewardIcon0026.png"
  },
  {
    name = CHS[4010012],
    level = 40,
    times = 1,
    activeValue = 5,
    activeLimit = 5,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[4010013]
      }
    },
    team = CHS[3000288],
    desc = CHS[4010014],
    reward = CHS[4010015],
    icon = "BigRewardIcon0003.png",
    itemName = CHS[4010016]
  },
  {
    name = CHS[4200709],
    level = 40,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "",
        ""
      }
    },
    team = CHS[3003139],
    desc = CHS[4200710],
    reward = CHS[4200711],
    icon = "BigRewardIcon0062.png"
  },
  {
    name = CHS[3000306],
    level = 45,
    times = 1,
    activeValue = 1,
    activeLimit = 1,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[3000307]
      }
    },
    team = CHS[3000267],
    desc = CHS[3000308],
    reward = CHS[3000309],
    icon = "BigRewardIcon0016.png"
  },
  {
    name = CHS[4010027],
    level = 70,
    times = 1,
    activeValue = 1,
    activeLimit = 1,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "",
        ""
      }
    },
    team = CHS[3000267],
    desc = CHS[4010031],
    reward = CHS[4010032],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[4010082],
    level = 70,
    times = 1,
    activeValue = 1,
    activeLimit = 1,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "",
        ""
      }
    },
    team = CHS[3000267],
    desc = CHS[2000931],
    reward = CHS[2000932],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[3000310],
    level = 45,
    times = 1,
    activeValue = 1,
    activeLimit = 1,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "",
        ""
      }
    },
    team = CHS[3000288],
    desc = CHS[3000312],
    reward = CHS[3000313],
    icon = "BigRewardIcon0016.png"
  },
  {
    name = CHS[4100389],
    level = 1,
    times = -1,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000705],
        "npc",
        CHS[4200188]
      }
    },
    team = CHS[3000272],
    desc = CHS[4100390],
    reward = CHS[4100372],
    icon = "BigRewardIcon0016.png"
  },
  {
    name = CHS[5400000],
    level = 70,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[5400003]
      }
    },
    team = CHS[3000267],
    desc = CHS[5400001],
    reward = CHS[5400002],
    icon = "BigRewardIcon0038.png"
  },
  {
    name = CHS[3000720],
    level = 20,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "0",
    activityTime = {
      {
        CHS[3000721],
        "",
        ""
      },
      {
        CHS[3000722],
        "",
        ""
      },
      {
        CHS[3000723],
        "",
        ""
      }
    },
    team = CHS[3000698],
    desc = CHS[7150001] .. CHS[3000725],
    reward = CHS[3000726],
    icon = "BigRewardIcon0012.png",
    pushContent = CHS[3000724],
    pushTime = {
      "12:25",
      "17:55",
      "22:25"
    }
  },
  {
    name = CHS[7100229],
    level = 70,
    times = 9,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[7100230]
      }
    },
    team = CHS[3000267],
    desc = CHS[7100231],
    reward = CHS[7100232],
    icon = "BigRewardIcon0053.png"
  },
  {
    name = CHS[5400428],
    level = 70,
    times = 3,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "2,3,4,5,6,7",
    activityTime = {
      {
        CHS[5400432],
        "npc",
        CHS[5400429]
      }
    },
    team = CHS[3000288],
    desc = CHS[5400430],
    reward = CHS[5400431],
    pushTime = {"21:20"},
    pushContent = CHS[5420286],
    showFlagBit = 1,
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[6000483],
    level = 100,
    times = 3,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "2,3,4,5,6,7",
    activityTime = {
      {
        CHS[6000479],
        "npc",
        CHS[6000559]
      }
    },
    team = CHS[3000698],
    desc = CHS[4300695],
    reward = CHS[6000481],
    pushTime = {"20:50"},
    pushContent = CHS[6000484],
    showFlagBit = 2,
    icon = "BigRewardIcon0012.png",
    effectTime = 1575234000,
    effectTimeTest = 1574629200,
    newDesc = CHS[6000480],
    newTimes = 2
  },
  {
    name = CHS[4010151],
    level = 120,
    times = 9,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[4010152]
      }
    },
    team = CHS[3000288],
    desc = CHS[4010153],
    reward = CHS[4010154],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[2200018],
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "",
        ""
      }
    },
    team = CHS[3000267],
    desc = CHS[2200019],
    reward = CHS[2200020],
    icon = "BigRewardIcon0042.png"
  },
  {
    name = CHS[4010227],
    mainType = "bingjian_tongxing",
    level = 30,
    times = 1,
    isLimitActivity = true,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[4010185],
    desc = CHS[4101268],
    reward = CHS[5400616],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7190587],
    mainType = "pet_explore",
    level = 75,
    times = 2,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "npc",
        CHS[7190588]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7190591],
    desc = CHS[7190589],
    reward = CHS[7190590],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4101653],
    level = 75,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[5000250],
    desc = CHS[4101654],
    reward = CHS[2100462],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7260046],
    level = 75,
    times = 3,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "func",
        ""
      }
    },
    needLevelTip = true,
    canGotoInCombat = true,
    team = CHS[7190591],
    desc = CHS[7260047],
    testDistDesc = CHS[4200907],
    reward = CHS[7260048],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[2000933],
    level = 70,
    times = 5,
    isLimitActivity = true,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3000266],
        "cmd",
        "CMD_MOLONG_TUNTIAN_AUTO_WALK"
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000698],
    desc = CHS[2000934],
    reward = CHS[2000935],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5401181],
    level = 79,
    times = 18,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[5401188],
        "func",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7190591],
    desc = CHS[5401189],
    reward = CHS[5401190],
    icon = "BigRewardIcon0093.png"
  }
}
