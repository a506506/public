return {
  ["龙凤呈祥服·新郎"] = {icon = 42101},
  ["龙凤呈祥服·新娘"] = {icon = 42102},
  ["千秋梦"] = {icon = 21001},
  ["汉宫秋"] = {icon = 21002},
  ["龙吟水"] = {icon = 21003},
  ["凤鸣空"] = {icon = 21004},
  ["峥岚衣"] = {icon = 51526},
  ["水光衫"] = {icon = 51525},
  ["如意年"] = {icon = 21009},
  ["吉祥天"] = {icon = 21010},
  ["狐灵逸"] = {icon = 21007},
  ["狐灵娇"] = {icon = 21008},
  ["晓色红妆"] = {icon = 21005},
  ["云暮风华"] = {icon = 21006},
  ["星寒魄"] = {icon = 21011, hide_unofficial = 1},
  ["月孤影"] = {icon = 21012, hide_unofficial = 1},
  ["日耀辰辉"] = {icon = 21013, start_show_time = 1539810000},
  ["星垂月涌"] = {icon = 21014, start_show_time = 1539810000},
  ["星火昭"] = {icon = 21015, start_show_time = 1539810000},
  ["点红烛"] = {icon = 21016, start_show_time = 1539810000},
  ["剑魄琴心"] = {icon = 21017, start_show_time = 1547067600},
  ["引天长歌"] = {icon = 21018, start_show_time = 1547067600},
  ["踏雪寻梅"] = {
    icon = 21019,
    start_show_time = 1567630800,
    test_start_show_time = 1567717200
  },
  ["紫岚故梦"] = {
    icon = 21020,
    start_show_time = 1567630800,
    test_start_show_time = 1567717200
  },
  ["镇星辰"] = {
    icon = 21021,
    start_show_time = 1567630800,
    test_start_show_time = 1567717200
  },
  ["玄冥临"] = {
    icon = 21022,
    start_show_time = 1567630800,
    test_start_show_time = 1567717200
  },
  ["御九天"] = {icon = 21023},
  ["斩梦华"] = {icon = 21024},
  ["雀羽极"] = {icon = 21025},
  ["雀羽翎"] = {icon = 21026},
  ["望月白"] = {
    icon = 21027,
    start_show_time = 1587675600,
    test_start_show_time = 1587675600
  },
  ["霜夜雪"] = {
    icon = 21028,
    start_show_time = 1587675600,
    test_start_show_time = 1587675600
  },
  ["陆吾曦光"] = {icon = 22061, not_show_in_store = 1},
  ["陆吾晨星"] = {icon = 22062, not_show_in_store = 1},
  ["绛染容华服·新郎"] = {icon = 21029},
  ["绛染容华服·新娘"] = {icon = 21030},
  ["极道棋魂"] = {
    icon = 21033,
    start_show_time = 1609448400,
    test_start_show_time = 1609448400
  },
  ["仙道棋心"] = {
    icon = 21034,
    start_show_time = 1609448400,
    test_start_show_time = 1609448400
  },
  ["山藏海"] = {
    icon = 21031,
    start_show_time = 1619730000,
    test_start_show_time = 1619730000
  },
  ["水牧云"] = {
    icon = 21032,
    start_show_time = 1619730000,
    test_start_show_time = 1619730000
  }
}
