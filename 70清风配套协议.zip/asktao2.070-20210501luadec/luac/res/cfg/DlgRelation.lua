return {
  ArtifactRefineDlg = {
    "ArtifactTabDlg",
    "ArtifactListDlg",
    "Funny1Dlg"
  },
  ArtifactEnlightenDlg = {
    "ArtifactTabDlg",
    "ArtifactFlyListDlg",
    "Funny1Dlg"
  },
  ArtifactSkillUpDlg = {
    "ArtifactTabDlg",
    "ArtifactListDlg",
    "Funny1Dlg"
  },
  ChangeCardBagDlg = {"BagTabDlg", "Funny1Dlg"},
  UserDlg = {"UserTabDlg", "Funny1Dlg"},
  UserAddPointDlg = {
    "UserTabDlg",
    "UserAddPointTabDlg",
    "UserInfoChildDlg",
    "Funny1Dlg"
  },
  SkillDlg = {"UserTabDlg", "Funny1Dlg"},
  PetAttribDlg = {
    "PetTabDlg",
    "PetListChildDlg",
    "Funny1Dlg"
  },
  PetGetAttribDlg = {
    "PetTabDlg",
    "PetListChildDlg",
    "Funny1Dlg"
  },
  PetHandbookDlg = {"PetTabDlg", "Funny1Dlg"},
  PetHorseDlg = {
    "PetTabDlg",
    "PetListChildDlg",
    "Funny1Dlg"
  },
  PetSkillDlg = {
    "PetTabDlg",
    "PetListChildDlg",
    "Funny1Dlg"
  },
  PolarAddPointDlg = {
    "UserTabDlg",
    "UserAddPointTabDlg",
    "UserInfoChildDlg",
    "Funny1Dlg"
  },
  EquipmentRefiningDlg = {
    "EquipmentTabDlg",
    "EquipmentChildDlg",
    "Funny1Dlg"
  },
  EquipmentRefiningSuitDlg = {
    "EquipmentTabDlg",
    "EquipmentChildDlg",
    "Funny1Dlg"
  },
  EquipmentUpgradeDlg = {
    "EquipmentTabDlg",
    "EquipmentChildDlg",
    "Funny1Dlg"
  },
  EquipmentSplitDlg = {
    "EquipmentTabDlg",
    "EquipmentChildDlg",
    "Funny1Dlg"
  },
  EquipmentReformDlg = {
    "EquipmentTabDlg",
    "EquipmentChildDlg",
    "Funny1Dlg"
  },
  EquipmentEvolveDlg = {
    "EquipmentTabDlg",
    "EquipmentChildDlg",
    "Funny1Dlg"
  },
  GuardAttribDlg = {
    "GuardListChildDlg",
    "Funny2Dlg"
  },
  GuardEquipmentDlg = {
    "GuardTabDlg",
    "GuardListChildDlg"
  },
  GuardCallDlg = {
    "GuardTabDlg"
  },
  GuardStrengthDlg = {
    "GuardTabDlg",
    "GuardListChildDlg"
  },
  JewelryMakeDlg = {
    "EquipmentTabDlg",
    "EquipmentChildDlg"
  },
  PartyInfoDlg = {
    "PartyInfoTabDlg",
    "Funny1Dlg"
  },
  PartyRecruitDlg = {
    "PartyInfoTabDlg",
    "Funny1Dlg"
  },
  PartyMemberDlg = {
    "PartyInfoTabDlg",
    "Funny1Dlg"
  },
  PartyWelfareDlg = {
    "PartyInfoTabDlg",
    "Funny1Dlg"
  },
  PartyActiveDlg = {
    "PartyInfoTabDlg",
    "Funny1Dlg"
  },
  OnlineMallDlg = {
    "OnlineMallTabDlg",
    "Funny1Dlg"
  },
  OnlineMallVIPDlg = {
    "OnlineMallTabDlg",
    "Funny1Dlg"
  },
  OnlineMallUnVIPDlg = {
    "OnlineMallTabDlg",
    "Funny1Dlg"
  },
  OnlineMallExchangeMoneyDlg = {
    "OnlineMallTabDlg",
    "Funny1Dlg"
  },
  OnlineRechargeDlg = {
    "OnlineMallTabDlg",
    "Funny1Dlg"
  },
  PartyWarHistoryDlg = {
    "PartyWarTabDlg"
  },
  PartyWarInstructionDlg = {
    "PartyWarTabDlg"
  },
  PartyWarScheduleDlg = {
    "PartyWarTabDlg"
  },
  PartyWarSignUpDlg = {
    "PartyWarTabDlg"
  },
  AutoTalkDlg = {
    "SystemConfigTabDlg",
    "Funny1Dlg"
  },
  SystemConfigDlg = {
    "SystemConfigTabDlg",
    "Funny1Dlg"
  },
  SystemPushDlg = {
    "SystemConfigTabDlg",
    "Funny1Dlg"
  },
  SystemAccManageDlg = {
    "SystemConfigTabDlg",
    "Funny1Dlg"
  },
  SevenDaysRewardDlg = {"WelfareDlg", "Funny4Dlg"},
  GuDingDuiFuLiDlg = {"WelfareDlg", "Funny4Dlg"},
  YanLuoMiBaoDlg = {"WelfareDlg", "Funny4Dlg"},
  MergeLoginGiftDlg = {"WelfareDlg", "Funny4Dlg"},
  CombinedServiceTaskDlg = {"WelfareDlg", "Funny4Dlg"},
  OnlineGiftDlg = {"WelfareDlg", "Funny4Dlg"},
  XunDaoCiFuDlg = {"WelfareDlg", "Funny4Dlg"},
  MammonGiftDlg = {"WelfareDlg", "Funny4Dlg"},
  DailySignDlg = {"WelfareDlg", "Funny4Dlg"},
  YuanxzfDlg = {"WelfareDlg", "Funny4Dlg"},
  TangyyhDlg = {"WelfareDlg", "Funny4Dlg"},
  LingxKeepsakeDlg = {"WelfareDlg", "Funny4Dlg"},
  DoubleChargeDrawGiftDlg = {"WelfareDlg", "Funny4Dlg"},
  HolidayGiftDlg = {"WelfareDlg", "Funny4Dlg"},
  NoviceGiftDlg = {"WelfareDlg", "Funny4Dlg"},
  FirstChargeGiftDlg = {"WelfareDlg", "Funny4Dlg"},
  NewChargeDrawGiftDlg = {"WelfareDlg", "Funny4Dlg"},
  ReentryAsktaoDlg = {"WelfareDlg", "Funny4Dlg"},
  ActiveDrawDlg = {"WelfareDlg", "Funny4Dlg"},
  DiFuPointDlg = {"WelfareDlg", "Funny4Dlg"},
  BachelorDrawDlg = {"WelfareDlg", "Funny4Dlg"},
  ScratchRewardDlg = {"WelfareDlg", "Funny4Dlg"},
  ChunjieRedBagDlg = {"WelfareDlg", "Funny4Dlg"},
  ChargePointDlg = {"WelfareDlg", "Funny4Dlg"},
  ConsumePointDlg = {"WelfareDlg", "Funny4Dlg"},
  ZaixqyDlg = {"WelfareDlg", "Funny4Dlg"},
  ZaoHuaDlg = {"WelfareDlg", "Funny4Dlg"},
  CallBackDlg = {"WelfareDlg", "Funny4Dlg"},
  ActiveVIPDlg = {"WelfareDlg", "Funny4Dlg"},
  ChargeGiftPerMonthDlg = {"WelfareDlg", "Funny4Dlg"},
  RenameDiscountDlg = {"WelfareDlg", "Funny4Dlg"},
  SummerVacationDlg = {"WelfareDlg", "Funny4Dlg"},
  WelcomNewDlg = {"WelfareDlg", "Funny4Dlg"},
  ActiveLoginRewardDlg = {"WelfareDlg", "Funny4Dlg"},
  ExpStoreHouseDlg = {"WelfareDlg", "Funny4Dlg"},
  NewServiceExpDlg = {"WelfareDlg", "Funny4Dlg"},
  SeekFriendMemberDlg = {"WelfareDlg"},
  RegressionRechargeDlg = {"WelfareDlg", "Funny4Dlg"},
  NewServiceCelebrationDlg = {"WelfareDlg", "Funny4Dlg"},
  NewlyNewServiceCelebrationDlg = {"WelfareDlg", "Funny4Dlg"},
  AnniversaryMallDlg = {"WelfareDlg", "Funny4Dlg"},
  NeiCePointDlg = {"WelfareDlg", "Funny4Dlg"},
  QuanmpkDrawDlg = {"WelfareDlg", "Funny4Dlg"},
  XinnianqfDlg = {"WelfareDlg", "Funny4Dlg"},
  TreasureBagDlg = {"WelfareDlg", "Funny4Dlg"},
  TreasureBagNewDlg = {"WelfareDlg", "Funny4Dlg"},
  FixedTeamEffortDlg = {"WelfareDlg", "Funny4Dlg"},
  BagDlg = {"BagTabDlg", "Funny1Dlg"},
  StoreItemDlg = {"BagTabDlg", "Funny1Dlg"},
  AlchemyDlg = {"BagTabDlg", "Funny1Dlg"},
  EquipmentIdentifyDlg = {"BagTabDlg", "Funny1Dlg"},
  MarketBuyDlg = {
    "MarketTabDlg",
    "Funny1Dlg"
  },
  MarketSellDlg = {
    "MarketTabDlg",
    "Funny1Dlg"
  },
  MarketPublicityDlg = {
    "MarketTabDlg",
    "Funny1Dlg"
  },
  MarketCollectionDlg = {
    "MarketTabDlg",
    "Funny1Dlg"
  },
  MarketGoldCollectionDlg = {
    "MarketGoldTabDlg",
    "Funny1Dlg"
  },
  MarketGoldBuyDlg = {
    "MarketGoldTabDlg",
    "Funny1Dlg"
  },
  MarketGoldSellDlg = {
    "MarketGoldTabDlg",
    "Funny1Dlg"
  },
  MarketGlodPublicityDlg = {
    "MarketGoldTabDlg",
    "Funny1Dlg"
  },
  MarketGoldVendueDlg = {
    "MarketGoldTabDlg"
  },
  MasterDlg = {
    "MasterTabDlg"
  },
  MasterRelationDlg = {
    "MasterTabDlg"
  },
  MasterRuleDlg = {
    "MasterTabDlg"
  },
  GetTaoDlg = {
    "GetTaoTabDlg",
    "Funny5Dlg"
  },
  GetTaoOfflineDlg = {
    "GetTaoTabDlg",
    "Funny5Dlg"
  },
  GetTaoPointDlg = {
    "GetTaoTabDlg",
    "Funny5Dlg"
  },
  GetTaoTrusteeshipDlg = {
    "GetTaoTabDlg",
    "Funny5Dlg"
  },
  RevelryRedBagRecordDlg = {
    "RevelryRedBagTabDlg"
  },
  RevelryRedBagDlg = {
    "RevelryRedBagTabDlg"
  },
  LonghzbsjDlg = {
    "LonghzbTabDlg"
  },
  LonghzbscDlg = {
    "LonghzbTabDlg"
  },
  LonghzbycDlg = {
    "LonghzbTabDlg"
  },
  LonghzbgzDlg = {
    "LonghzbTabDlg"
  },
  SuperBossFirstKillDlg = {
    "SuperBossShowDlg",
    "SuperBossTabDlg"
  },
  SuperBossIntroduceDlg = {
    "SuperBossShowDlg",
    "SuperBossTabDlg"
  },
  JuBaoUserViewSelfDlg = {
    "JuBaoUserViewTabDlg"
  },
  JuBaoUserViewPetDlg = {
    "JuBaoUserViewTabDlg"
  },
  JuBaoUserViewBagDlg = {
    "JuBaoUserViewTabDlg"
  },
  JuBaoUserViewGuardDlg = {
    "JuBaoUserViewTabDlg"
  },
  JuBaoUserViewHomeDlg = {
    "JuBaoUserViewTabDlg"
  },
  UserSellDlg = {
    "JuBaoGoodSellTabDlg"
  },
  JuBaoPetSellDlg = {
    "JuBaoGoodSellTabDlg"
  },
  JuBaoEquipSellDlg = {
    "JuBaoGoodSellTabDlg"
  },
  JuBaoCashSellDlg = {
    "JuBaoGoodSellTabDlg"
  },
  JewelryUpgradeDlg = {
    "JewelryTabDlg",
    "Funny1Dlg"
  },
  JewelryNewRefineDlg = {
    "JewelryTabDlg",
    "Funny1Dlg"
  },
  JewelryDecomposeDlg = {
    "JewelryTabDlg",
    "Funny1Dlg"
  },
  JewelryChangeDlg = {
    "JewelryTabDlg",
    "Funny1Dlg"
  },
  JewelryDevelopDlg = {
    "JewelryTabDlg",
    "Funny1Dlg"
  },
  AnniversaryDrawDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryGiftDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryRewardDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryShopDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryOtherDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryTreeDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryCatCardDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryPetCardDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryPetAdventureDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryXianDanDlg = {
    "AnniversaryTabDlg"
  },
  CelebrationLuckyStickDlg = {
    "AnniversaryTabDlg"
  },
  FlowersBilssDlg = {
    "AnniversaryTabDlg"
  },
  RanfbpDlg = {
    "AnniversaryTabDlg"
  },
  AnniversaryLingMaoDlg = {
    "AnniversaryTabDlg"
  },
  PetGrowingDlg = {
    "PetGrowTabDlg"
  },
  PetDevelopDlg = {
    "PetGrowTabDlg"
  },
  PetDianhuaDlg = {
    "PetGrowTabDlg"
  },
  PetEvolveDlg = {
    "PetGrowTabDlg"
  },
  PetHuanHuaDlg = {
    "PetGrowTabDlg"
  },
  PetGrowPandectDlg = {
    "PetGrowTabDlg"
  },
  PetYuhuaDlg = {
    "PetGrowTabDlg"
  },
  GhostPetGongShengDlg = {
    "PetGrowTabDlg"
  },
  GhostGrowPandectDlg = {
    "GhostPetGrowTabDlg"
  },
  PetNingShenDlg = {
    "GhostPetGrowTabDlg"
  },
  GhostPetPeiYuanDlg = {
    "GhostPetGrowTabDlg"
  },
  GhostPetGrowingDlg = {
    "GhostPetGrowTabDlg"
  },
  GhostPetNingShenDlg = {
    "GhostPetGrowTabDlg"
  },
  GhostPetGongShengExDlg = {
    "GhostPetGrowTabDlg"
  },
  GhostPetYiHunDlg = {
    "GhostPetGrowTabDlg"
  },
  HomeInDlg = {"HomeTabDlg"},
  HomeCheckDlg = {"HomeTabDlg"},
  HomePlantCheckDlg = {"HomeTabDlg"},
  HomeOtherCheckDlg = {"HomeTabDlg"},
  HomeKidDlg = {"HomeTabDlg"},
  HomeMaterialGiveDlg = {
    "HomeMaterialTabDlg"
  },
  HomeMaterialAskDlg = {
    "HomeMaterialTabDlg"
  },
  KuafzcsjDlg = {
    "KuafzcTabDlg"
  },
  KuafzcscDlg = {
    "KuafzcTabDlg"
  },
  KuafzcjfDlg = {
    "KuafzcTabDlg"
  },
  KuafzcgzDlg = {
    "KuafzcTabDlg"
  },
  NewKuafzcsjDlg = {
    "NewKuafzcTabDlg"
  },
  NewKuafzcscDlg = {
    "NewKuafzcTabDlg"
  },
  NewKuafzcjfDlg = {
    "NewKuafzcTabDlg"
  },
  NewKuafzcgzDlg = {
    "NewKuafzcTabDlg"
  },
  KuafjjscDlg = {
    "KuafjjTabDlg"
  },
  KuafjjjfDlg = {
    "KuafjjTabDlg"
  },
  KuafjjljDlg = {
    "KuafjjTabDlg"
  },
  KuafjjgzDlg = {
    "KuafjjTabDlg"
  },
  BlogCircleDlg = {
    "BlogTabDlg",
    "BlogInfoDlg",
    "BlogMakeUpDlg"
  },
  BlogCircleEXDlg = {
    "BlogEXTabDlg",
    "BlogInfoEXDlg",
    "BlogMakeUpEXDlg"
  },
  BlogMessageDlg = {
    "BlogTabDlg",
    "BlogInfoDlg",
    "BlogMakeUpDlg"
  },
  BlogMessageEXDlg = {
    "BlogEXTabDlg",
    "BlogInfoEXDlg",
    "BlogMakeUpEXDlg"
  },
  HomeShowDlg = {
    "BlogTabDlg",
    "BlogMakeUpDlg"
  },
  HomeShowEXDlg = {
    "BlogEXTabDlg",
    "BlogMakeUpEXDlg"
  },
  InnerAlchemyDlg = {"UserTabDlg", "Funny1Dlg"},
  XianMoAddPointDlg = {"UserTabDlg", "Funny1Dlg"},
  AchievementListDlg = {
    "AchievementTabDlg",
    "Funny1Dlg"
  },
  ServiceAchievementDlg = {
    "AchievementTabDlg",
    "Funny1Dlg"
  },
  RankingListDlg = {"Funny2Dlg"},
  PracticeDlg = {"Funny2Dlg"},
  MarketAuctionDlg = {"Funny2Dlg"},
  ActivitiesDlg = {"Funny3Dlg"},
  UpdateDescDlg = {"Funny6Dlg"},
  WatchCentreDlg = {"Funny2Dlg"},
  CityFriendDlg = {
    "CityTabDlg",
    "CityInfoDlg"
  },
  CityRankingDlg = {
    "CityTabDlg",
    "CityInfoDlg"
  },
  CityNearbyDlg = {
    "CityTabDlg",
    "CityInfoDlg"
  },
  MingrzbjcDlg = {
    "MingrzbTabDlg"
  },
  MingrzbscDlg = {
    "MingrzbTabDlg"
  },
  MingrzbgrDlg = {
    "MingrzbTabDlg"
  },
  MingrzbgzDlg = {
    "MingrzbTabDlg"
  },
  MingrzbscExDlg = {
    "MingrzbMatchTabDlg"
  },
  MingrzbMatchRuleDlg = {
    "MingrzbMatchTabDlg"
  },
  JuBaoZhaiNoteDlg = {
    "JuBaoZhaiTabDlg"
  },
  JuBaoZhaiSellDlg = {
    "JuBaoZhaiTabDlg"
  },
  JuBaoZhaiVendueDlg = {
    "JuBaoZhaiTabDlg"
  },
  JuBaoZhaiStorageDlg = {
    "JuBaoZhaiTabDlg"
  },
  ShiJieBeiRuleDlg = {
    "ShiJieBeiTabDlg"
  },
  ShiJieBeiDlg = {
    "ShiJieBeiTabDlg"
  },
  ShengSiHistoryDlg = {
    "ShengSiTabDlg"
  },
  ShengSiRuleDlg = {
    "ShengSiTabDlg"
  },
  QuanmPK2020apDlg = {
    "QuanmPK2TabDlg"
  },
  QuanmPK2jfDlg = {
    "QuanmPK2TabDlg"
  },
  QuanmPK2scDlg = {
    "QuanmPK2TabDlg"
  },
  QuanmPK2fxDlg = {
    "QuanmPK2TabDlg"
  },
  TeamDlg = {"TeamTabDlg"},
  TeamFixedDlg = {"TeamTabDlg"},
  TeamEnlistDlg = {"TeamTabDlg"},
  PetChangeColorDlg = {
    "PetDressTabDlg"
  },
  PetChangeShapeDlg = {
    "PetDressTabDlg"
  },
  PetDressDlg = {
    "PetDressTabDlg"
  },
  PetDressRuleDlg = {
    "PetDressTabDlg"
  },
  KuafsdsqfpDlg = {
    "KuafsdTabDlg"
  },
  KuafsdwzDlg = {
    "KuafsdTabDlg"
  },
  KuafsdgzDlg = {
    "KuafsdTabDlg"
  },
  CreateCharDescExDlg = {
    "ReserveRechargeTabDlg"
  },
  BigServerTeamreserveExDlg = {
    "ReserveRechargeTabDlg"
  },
  TradingSpotItemDlg = {
    "TradingSpotTabDlg"
  },
  TradingSpotProfitDlg = {
    "TradingSpotTabDlg"
  },
  TradingSpotDiscussDlg = {
    "TradingSpotTabDlg"
  },
  TradingSpotInfoDlg = {
    "TradingSpotTabDlg"
  },
  PetExploreDlg = {
    "PetExploreTabDlg"
  },
  PetExploreSkillDlg = {
    "PetExploreTabDlg"
  },
  GoodVoiceExhibitionDlg = {
    "GoodVoiceTabDlg"
  },
  GoodVoiceCollectionDlg = {
    "GoodVoiceTabDlg"
  },
  GoodVoiceRuleDlg = {
    "GoodVoiceTabDlg"
  },
  GoodVoiceReviewDlg = {
    "GoodVoiceJudgesTabDlg"
  },
  GoodVoiceRankingDlg = {
    "GoodVoiceJudgesTabDlg"
  },
  GoodVoiceJudgesDlg = {
    "GoodVoiceJudgesTabDlg"
  },
  CrossRankingListDlg = {
    "RankingTabDlg"
  },
  GongceRankingListDlg = {
    "RankingTabDlg"
  },
  HorcruxAttriRefineDlg = {
    "HorcruxTabDlg",
    "HorcruxListDlg"
  },
  HorcruxSkillDlg = {
    "HorcruxTabDlg",
    "HorcruxListDlg"
  },
  HorcruxEvolveDlg = {
    "HorcruxTabDlg",
    "HorcruxListDlg"
  },
  UndergroundShopDlg = {
    "UndergroundBagDlg"
  },
  UndergroundMedicineShopDlg = {
    "UndergroundBagDlg"
  },
  ShiddhjfDlg = {
    "ShiddhTabDlg"
  },
  ShiddhwzDlg = {
    "ShiddhTabDlg"
  },
  SimulateUserDlg = {
    "WoodSoldierTabDlg"
  },
  SimulatePetDlg = {
    "WoodSoldierTabDlg"
  },
  WoodSoldierDlg = {
    "WoodSoldierTabDlg"
  },
  LotteryTicketSelectDlg = {
    "LotteryTabDlg"
  },
  LotteryTicketMySelfDlg = {
    "LotteryTabDlg"
  },
  LotteryTicketHistoryDlg = {
    "LotteryTabDlg"
  },
  LotteryTicketRuleDlg = {
    "LotteryTabDlg"
  },
  KuafbzsjDlg = {
    "KuafbzTabDlg"
  },
  KuafbzscDlg = {
    "KuafbzTabDlg"
  },
  KuafbzgzDlg = {
    "KuafbzTabDlg"
  },
  SpiritSystemMagicCircleDlg = {
    "SpiritSystemTabDlg",
    "SpiritSystemMoenyDlg"
  },
  SpiritSystemDlg = {
    "SpiritSystemTabDlg",
    "SpiritSystemMoenyDlg"
  },
  SpiritSystemPossessedDlg = {
    "SpiritSystemTabDlg",
    "SpiritSystemMoenyDlg"
  },
  PartyMedalShopDlg = {
    "PartyGongcTabDlg"
  },
  PartyActiveRankingListDlg = {
    "PartyGongcTabDlg"
  },
  GourmandQuarter02Dlg = {
    "GourmandQuarterTabDlg",
    "GourmandQuarterMoenyDlg"
  },
  GourmandQuarterBag02Dlg = {
    "GourmandQuarterTabDlg",
    "GourmandQuarterMoenyDlg"
  },
  GourmandQuarterStore02Dlg = {
    "GourmandQuarterTabDlg",
    "GourmandQuarterMoenyDlg"
  },
  TianGMainInterfaceDlg = {
    "TianGMainInterfaceTabDlg"
  },
  TianGGodGeneralDlg = {
    "TianGMainInterfaceTabDlg"
  },
  TianGFuYaoDlg = {
    "TianGMainInterfaceTabDlg"
  },
  TianGGodAttributeDlg = {
    "TianGGodAttributeTabDlg"
  },
  TianGGodPanoplyDlg = {
    "TianGGodAttributeTabDlg"
  },
  TianGShenGeDlg = {
    "TianGGodAttributeTabDlg"
  },
  ForerunnerDailyTaskDlg = {
    "ForerunnerTabDlg"
  },
  ForerunnerLongTaskDlg = {
    "ForerunnerTabDlg"
  },
  ForerunnerGiftDlg = {
    "ForerunnerTabDlg"
  },
  ForerunnerProposalDlg = {
    "ForerunnerTabDlg"
  },
  QuanmZBjfDlg = {
    "QuanmZBTabDlg"
  },
  QuanmZBscDlg = {
    "QuanmZBTabDlg"
  },
  RedBagRainRecordDlg = {
    "RedBagRainTabDlg"
  },
  RedBagShop = {
    "RedBagRainTabDlg"
  },
  LeiTaiBaWangRankDlg = {
    "LeiTaiBaWangTabDlg"
  },
  LeiTaiBaWangDlg = {
    "LeiTaiBaWangTabDlg"
  },
  LeiTaiBaWangPkListDlg = {
    "LeiTaiBaWangTabDlg"
  },
  Mingrzbsj2021Dlg = {
    "Mingrzb2021TabDlg"
  },
  Mingrzb2021scDlg = {
    "Mingrzb2021TabDlg"
  },
  Mingrzbjc2021Dlg = {
    "Mingrzb2021TabDlg"
  },
  Mingrzbgz2021Dlg = {
    "Mingrzb2021TabDlg"
  },
  SecretDoorWonderlandDlg = {
    "SecretDoorWonderlandTabDlg"
  },
  SecretDoorWonderlandRankDlg = {
    "SecretDoorWonderlandTabDlg"
  },
  SecretDoorWonderlandShopDlg = {
    "SecretDoorWonderlandTabDlg"
  },
  BattlePassTaskDlg = {
    "BattlePassTabDlg"
  },
  BattlePassRewardDlg = {
    "BattlePassTabDlg"
  }
}
