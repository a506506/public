return {
  [1] = {
    kind = CHS[3000653],
    name = CHS[3000654],
    level = 35,
    attrib = CHS[3000655],
    needItems = {
      {
        name = CHS[3000656],
        attrib = CHS[3000657],
        count = 3,
        level = 20
      }
    }
  },
  [2] = {
    kind = CHS[3000653],
    name = CHS[3000658],
    level = 50,
    attrib = CHS[3000659],
    needItems = {
      {
        name = CHS[3000654],
        attrib = CHS[3000655],
        count = 3,
        level = 35
      }
    }
  },
  [3] = {
    kind = CHS[3000653],
    name = CHS[3000660],
    level = 60,
    attrib = CHS[3000661],
    needItems = {
      {
        name = CHS[3000658],
        attrib = CHS[3000659],
        count = 3,
        level = 50
      }
    }
  },
  [4] = {
    kind = CHS[3000653],
    name = CHS[3000662],
    level = 70,
    attrib = CHS[3000663],
    needItems = {
      {
        name = CHS[3000660],
        attrib = CHS[3000661],
        count = 3,
        level = 60
      }
    }
  },
  [5] = {
    kind = CHS[3000653],
    name = CHS[3000664],
    level = 80,
    attrib = CHS[3000665],
    needItems = {
      {
        name = CHS[3000662],
        attrib = CHS[3000663],
        count = 1,
        level = 70
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [6] = {
    kind = CHS[3000653],
    name = CHS[4100175],
    level = 90,
    attrib = CHS[4100176],
    needItems = {
      {
        name = CHS[3000664],
        attrib = CHS[3000665],
        count = 1,
        level = 80,
        isNeedSelect = true
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [7] = {
    kind = CHS[3000653],
    name = CHS[4100177],
    level = 100,
    attrib = CHS[4100178],
    needItems = {
      {
        name = CHS[4100175],
        attrib = CHS[4100176],
        count = 1,
        level = 90,
        isNeedSelect = true
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [8] = {
    kind = CHS[3000667],
    name = CHS[3000668],
    level = 35,
    attrib = CHS[3000669],
    needItems = {
      {
        name = CHS[3000670],
        attrib = CHS[3000671],
        count = 3,
        level = 20
      }
    }
  },
  [9] = {
    kind = CHS[3000667],
    name = CHS[3000672],
    level = 50,
    attrib = CHS[3000673],
    needItems = {
      {
        name = CHS[3000668],
        attrib = CHS[3000669],
        count = 3,
        level = 35
      }
    }
  },
  [10] = {
    kind = CHS[3000667],
    name = CHS[3000674],
    level = 60,
    attrib = CHS[3000675],
    needItems = {
      {
        name = CHS[3000672],
        attrib = CHS[3000673],
        count = 3,
        level = 50
      }
    }
  },
  [11] = {
    kind = CHS[3000667],
    name = CHS[3000676],
    level = 70,
    attrib = CHS[3000677],
    needItems = {
      {
        name = CHS[3000674],
        attrib = CHS[3000675],
        count = 3,
        level = 60
      }
    }
  },
  [12] = {
    kind = CHS[3000667],
    name = CHS[3000678],
    level = 80,
    attrib = CHS[3000679],
    needItems = {
      {
        name = CHS[3000676],
        attrib = CHS[3000677],
        count = 1,
        level = 70
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [13] = {
    kind = CHS[3000667],
    name = CHS[4100179],
    level = 90,
    attrib = CHS[4100180],
    needItems = {
      {
        name = CHS[3000678],
        attrib = CHS[3000679],
        count = 1,
        level = 80,
        isNeedSelect = true
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [14] = {
    kind = CHS[3000667],
    name = CHS[4100181],
    level = 100,
    attrib = CHS[4100182],
    needItems = {
      {
        name = CHS[4100179],
        attrib = CHS[4100180],
        count = 1,
        level = 90,
        isNeedSelect = true
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [15] = {
    kind = CHS[3000680],
    name = CHS[3000681],
    level = 35,
    attrib = CHS[3000682],
    needItems = {
      {
        name = CHS[3000683],
        attrib = CHS[3000684],
        count = 3,
        level = 20
      }
    }
  },
  [16] = {
    kind = CHS[3000680],
    name = CHS[3000685],
    level = 50,
    attrib = CHS[3000686],
    needItems = {
      {
        name = CHS[3000681],
        attrib = CHS[3000682],
        count = 3,
        level = 35
      }
    }
  },
  [17] = {
    kind = CHS[3000680],
    name = CHS[3000687],
    level = 60,
    attrib = CHS[3000688],
    needItems = {
      {
        name = CHS[3000685],
        attrib = CHS[3000686],
        count = 3,
        level = 50
      }
    }
  },
  [18] = {
    kind = CHS[3000680],
    name = CHS[3000689],
    level = 70,
    attrib = CHS[3000690],
    needItems = {
      {
        name = CHS[3000687],
        attrib = CHS[3000688],
        count = 3,
        level = 60
      }
    }
  },
  [19] = {
    kind = CHS[3000680],
    name = CHS[3000691],
    level = 80,
    attrib = CHS[3000692],
    needItems = {
      {
        name = CHS[3000689],
        attrib = CHS[3000690],
        count = 1,
        level = 70
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [20] = {
    kind = CHS[3000680],
    name = CHS[4100183],
    level = 90,
    attrib = CHS[4100184],
    needItems = {
      {
        name = CHS[3000691],
        attrib = CHS[3000692],
        count = 1,
        level = 80,
        isNeedSelect = true
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [21] = {
    kind = CHS[3000680],
    name = CHS[4100185],
    level = 100,
    attrib = CHS[4100186],
    needItems = {
      {
        name = CHS[4100183],
        attrib = CHS[4100184],
        count = 1,
        level = 90,
        isNeedSelect = true
      },
      {
        name = CHS[3000666],
        attrib = "",
        count = 2,
        isItem = true
      }
    }
  },
  [22] = {
    kind = CHS[3000653],
    name = CHS[3000656],
    level = 20,
    attrib = CHS[3000657],
    needItems = {}
  },
  [23] = {
    kind = CHS[3000667],
    name = CHS[3000670],
    level = 20,
    attrib = CHS[3000671],
    needItems = {}
  },
  [24] = {
    kind = CHS[3000680],
    name = CHS[3000683],
    level = 20,
    attrib = CHS[3000684],
    needItems = {}
  },
  [25] = {
    kind = "手镯",
    name = "碎梦涵光",
    level = 110,
    attrib = "伤害：724",
    needItems = {
      {
        name = "天星奇光",
        attrib = "伤害：623",
        count = 1,
        level = 100,
        isNeedSelect = true
      },
      {
        name = "法文手轮",
        attrib = "伤害：364",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  },
  [26] = {
    kind = "玉佩",
    name = "寒玉龙勾",
    level = 110,
    attrib = "气血：4888",
    needItems = {
      {
        name = "通灵宝玉",
        attrib = "气血：4207",
        count = 1,
        level = 100,
        isNeedSelect = true
      },
      {
        name = "蟠螭结",
        attrib = "气血：1890",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  },
  [27] = {
    kind = "项链",
    name = "流光绝影",
    level = 110,
    attrib = "法力：3255",
    needItems = {
      {
        name = "金碧莲花",
        attrib = "法力：2801",
        count = 1,
        level = 100,
        isNeedSelect = true
      },
      {
        name = "雪魂丝链",
        attrib = "法力：1257",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  },
  [28] = {
    kind = "手镯",
    name = "九天霜华",
    level = 120,
    attrib = "伤害：832",
    needItems = {
      {
        name = "碎梦涵光",
        attrib = "伤害：724",
        count = 1,
        level = 110,
        isNeedSelect = true
      },
      {
        name = "法文手轮",
        attrib = "伤害：364",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  },
  [29] = {
    kind = "玉佩",
    name = "八宝如意",
    level = 120,
    attrib = "气血：5618",
    needItems = {
      {
        name = "寒玉龙勾",
        attrib = "气血：4888",
        count = 1,
        level = 110,
        isNeedSelect = true
      },
      {
        name = "蟠螭结",
        attrib = "气血：1890",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  },
  [30] = {
    kind = "项链",
    name = "五蕴悯光",
    level = 120,
    attrib = "法力：3742",
    needItems = {
      {
        name = "流光绝影",
        attrib = "法力：3255",
        count = 1,
        level = 110,
        isNeedSelect = true
      },
      {
        name = "雪魂丝链",
        attrib = "法力：1257",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  },
  [31] = {
    kind = "手镯",
    name = "岚金火链",
    level = 130,
    attrib = "伤害：947",
    needItems = {
      {
        name = "九天霜华",
        attrib = "伤害：932",
        count = 1,
        level = 120,
        isNeedSelect = true
      },
      {
        name = "法文手轮",
        attrib = "伤害：364",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  },
  [32] = {
    kind = "玉佩",
    name = "游火灵焰",
    level = 130,
    attrib = "气血：7872",
    needItems = {
      {
        name = "八宝如意",
        attrib = "气血：5618",
        count = 1,
        level = 120,
        isNeedSelect = true
      },
      {
        name = "蟠螭结",
        attrib = "气血：1890",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  },
  [33] = {
    kind = "项链",
    name = "千彩流光",
    level = 130,
    attrib = "法力：5245",
    needItems = {
      {
        name = "五蕴悯光",
        attrib = "法力：3742",
        count = 1,
        level = 120,
        isNeedSelect = true
      },
      {
        name = "雪魂丝链",
        attrib = "法力：1257",
        count = 2,
        level = 70,
        isRes = true
      }
    }
  }
}
