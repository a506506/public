return {
  [CHS[5450594]] = {
    name = CHS[5450594],
    icon = 22006,
    polar = 0,
    life_rate = 1,
    phy_rate = 0.5,
    mag_rate = 0,
    speed_rate = 1,
    def_rate = 1,
    skills = {
      CHS[5401085],
      CHS[5450566],
      CHS[5450567]
    },
    rank = 1,
    unlock = 0,
    god_class = CHS[2000812],
    attack_type = CHS[2000848]
  },
  [CHS[5450593]] = {
    name = CHS[5450593],
    icon = 22009,
    polar = 0,
    life_rate = 0.5,
    phy_rate = 1,
    mag_rate = 0,
    speed_rate = 1,
    def_rate = 0.5,
    skills = {
      CHS[5401085],
      CHS[5450564],
      CHS[5450565]
    },
    rank = 1,
    unlock = 1,
    god_class = CHS[2000813],
    attack_type = CHS[2000849]
  },
  [CHS[5450596]] = {
    name = CHS[5450596],
    icon = 22010,
    polar = 1,
    life_rate = 0.5,
    phy_rate = 0,
    mag_rate = 1,
    speed_rate = 1,
    def_rate = 0.5,
    skills = {
      CHS[3001507],
      CHS[5450570],
      CHS[5450571]
    },
    rank = 1,
    unlock = 9,
    god_class = CHS[2000814],
    attack_type = CHS[2000850]
  },
  [CHS[5450595]] = {
    name = CHS[5450595],
    icon = 22008,
    polar = 5,
    life_rate = 0.5,
    phy_rate = 0,
    mag_rate = 1,
    speed_rate = 1,
    def_rate = 0.5,
    skills = {
      CHS[3001572],
      CHS[5450568],
      CHS[5450569]
    },
    rank = 1,
    unlock = 14,
    god_class = CHS[2000814],
    attack_type = CHS[2000851]
  },
  [CHS[5450592]] = {
    name = CHS[5450592],
    icon = 22011,
    polar = 2,
    life_rate = 0.8,
    phy_rate = 0,
    mag_rate = 0.75,
    speed_rate = 1,
    def_rate = 0.7,
    skills = {
      CHS[3001898],
      CHS[5450562],
      CHS[5450563]
    },
    rank = 1,
    unlock = 17,
    god_class = CHS[2000815],
    attack_type = CHS[2000852]
  },
  [CHS[3001002]] = {
    name = CHS[3001002],
    icon = 22005,
    polar = 1,
    life_rate = 1,
    phy_rate = 0,
    mag_rate = 0.5,
    speed_rate = 1,
    def_rate = 1,
    skills = {
      CHS[3001837],
      CHS[5450580],
      CHS[4101954]
    },
    rank = 2,
    unlock = 34,
    god_class = CHS[2000812],
    attack_type = CHS[2000853]
  },
  [CHS[5450598]] = {
    name = CHS[5450598],
    icon = 22004,
    polar = 2,
    life_rate = 0.8,
    phy_rate = 0,
    mag_rate = 0.75,
    speed_rate = 1,
    def_rate = 0.7,
    skills = {
      CHS[3001534],
      CHS[5450574],
      CHS[5450575]
    },
    rank = 2,
    unlock = 49,
    god_class = CHS[2000815],
    attack_type = CHS[2000854]
  },
  [CHS[3000937]] = {
    name = CHS[3000937],
    icon = 6068,
    polar = 0,
    life_rate = 0.5,
    phy_rate = 1,
    mag_rate = 0,
    speed_rate = 1,
    def_rate = 0.5,
    skills = {
      CHS[3001620],
      CHS[5450576],
      CHS[5450577]
    },
    rank = 2,
    unlock = 71,
    god_class = CHS[2000813],
    attack_type = CHS[2000855]
  },
  [CHS[5450599]] = {
    name = CHS[5450599],
    icon = 22003,
    polar = 2,
    life_rate = 0.8,
    phy_rate = 0,
    mag_rate = 0.75,
    speed_rate = 1,
    def_rate = 0.7,
    skills = {
      CHS[3001898],
      CHS[5450578],
      CHS[5450579]
    },
    rank = 2,
    unlock = 94,
    god_class = CHS[2000815],
    attack_type = CHS[2000856]
  },
  [CHS[5450597]] = {
    name = CHS[5450597],
    icon = 6086,
    polar = 3,
    life_rate = 0.5,
    phy_rate = 0,
    mag_rate = 1,
    speed_rate = 1,
    def_rate = 0.5,
    skills = {
      CHS[3001539],
      CHS[5450572],
      CHS[5450573]
    },
    rank = 2,
    unlock = 114,
    god_class = CHS[2000814],
    attack_type = CHS[2000857]
  },
  [CHS[6000342]] = {
    name = CHS[6000342],
    icon = 6061,
    polar = 1,
    life_rate = 1,
    phy_rate = 0,
    mag_rate = 0.5,
    speed_rate = 1,
    def_rate = 1,
    skills = {
      CHS[3001837],
      CHS[5450582],
      CHS[5450583]
    },
    rank = 3,
    unlock = 159,
    god_class = CHS[2000812],
    attack_type = CHS[2000858]
  },
  [CHS[6000345]] = {
    name = CHS[6000345],
    icon = 6066,
    polar = 2,
    life_rate = 0.8,
    phy_rate = 0,
    mag_rate = 0.75,
    speed_rate = 1,
    def_rate = 0.7,
    skills = {
      CHS[3001534],
      CHS[5450588],
      CHS[5450589]
    },
    rank = 3,
    unlock = 179,
    god_class = CHS[2000815],
    attack_type = CHS[2000859]
  },
  [CHS[6000349]] = {
    name = CHS[6000349],
    icon = 6063,
    polar = 3,
    life_rate = 0.5,
    phy_rate = 1,
    mag_rate = 0,
    speed_rate = 1,
    def_rate = 0.5,
    skills = {
      CHS[5401085],
      CHS[5450584],
      CHS[5450585]
    },
    rank = 3,
    unlock = 219,
    god_class = CHS[2000813],
    attack_type = CHS[2000860]
  },
  [CHS[2000012]] = {
    name = CHS[2000012],
    icon = 6065,
    polar = 4,
    life_rate = 0.5,
    phy_rate = 0,
    mag_rate = 1,
    speed_rate = 1,
    def_rate = 0.5,
    skills = {
      CHS[3001556],
      CHS[5450586],
      CHS[5450587]
    },
    rank = 3,
    unlock = 249,
    god_class = CHS[2000814],
    attack_type = CHS[2000861]
  },
  [CHS[6000356]] = {
    name = CHS[6000356],
    icon = 6064,
    polar = 5,
    life_rate = 0.5,
    phy_rate = 1,
    mag_rate = 0,
    speed_rate = 1,
    def_rate = 0.5,
    skills = {
      CHS[3001620],
      CHS[5450590],
      CHS[5450591]
    },
    rank = 3,
    unlock = 279,
    god_class = CHS[2000813],
    attack_type = CHS[2000862]
  }
}
