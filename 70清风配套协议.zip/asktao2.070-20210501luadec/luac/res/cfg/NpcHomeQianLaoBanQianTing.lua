return {
  {
    class_id = 10150,
    x = 90,
    y = 62,
    dir = 0,
    cx = -12,
    cy = -4
  },
  {
    class_id = 10022,
    x = 89,
    y = 35,
    dir = 0,
    cx = -12,
    cy = 8
  },
  {
    class_id = 10022,
    x = 90,
    y = 42,
    dir = 0,
    cx = -12,
    cy = -5
  },
  {
    class_id = 10022,
    x = 82,
    y = 38,
    dir = 0,
    cx = -12,
    cy = -3
  },
  {
    class_id = 10136,
    x = 41,
    y = 32,
    dir = 0,
    cx = -11,
    cy = 6
  },
  {
    class_id = 10136,
    x = 46,
    y = 29,
    dir = 0,
    cx = 11,
    cy = 11
  },
  {
    class_id = 10136,
    x = 52,
    y = 25,
    dir = 0,
    cx = 10,
    cy = -9
  },
  {
    class_id = 10136,
    x = 58,
    y = 22,
    dir = 0,
    cx = 2,
    cy = -10
  },
  {
    class_id = 10137,
    x = 53,
    y = 38,
    dir = 0,
    cx = -9,
    cy = 12
  },
  {
    class_id = 10137,
    x = 58,
    y = 35,
    dir = 0,
    cx = 3,
    cy = 2
  },
  {
    class_id = 10137,
    x = 63,
    y = 32,
    dir = 0,
    cx = 7,
    cy = -5
  },
  {
    class_id = 10137,
    x = 68,
    y = 29,
    dir = 0,
    cx = 9,
    cy = -11
  },
  {
    class_id = 10012,
    x = 56,
    y = 31,
    dir = 0,
    cx = -10,
    cy = 8
  },
  {
    class_id = 10012,
    x = 63,
    y = 26,
    dir = 0,
    cx = 6,
    cy = -7
  },
  {
    class_id = 10031,
    x = 104,
    y = 47,
    dir = 0,
    cx = 11,
    cy = 10
  },
  {
    class_id = 10042,
    x = 107,
    y = 57,
    dir = 0,
    cx = -5,
    cy = 6
  },
  {
    class_id = 10042,
    x = 114,
    y = 53,
    dir = 0,
    cx = 10,
    cy = 4
  },
  {
    class_id = 10142,
    x = 78,
    y = 12,
    dir = 0,
    cx = -5,
    cy = -2
  },
  {
    class_id = 10142,
    x = 129,
    y = 38,
    dir = 0,
    cx = -9,
    cy = 12
  },
  {
    class_id = 10139,
    x = 77,
    y = 45,
    dir = 0,
    cx = -8,
    cy = -4
  },
  {
    class_id = 10023,
    x = 72,
    y = 56,
    dir = 0,
    cx = 5,
    cy = 10
  },
  {
    class_id = 10023,
    x = 62,
    y = 50,
    dir = 0,
    cx = 5,
    cy = -10
  },
  {
    class_id = 10012,
    x = 48,
    y = 35,
    dir = 0,
    cx = -3,
    cy = 4
  },
  {
    class_id = 10022,
    x = 96,
    y = 39,
    dir = 0,
    cx = 11,
    cy = 5
  },
  {wall_index = 3},
  {floor_index = 3}
}
