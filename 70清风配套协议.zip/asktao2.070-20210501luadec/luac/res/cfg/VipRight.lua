return {
  [CHS[3001798]] = {
    money = 100,
    vipExpression = 1,
    sweep = 1,
    extraChallengeTimes = 1,
    shuadaoLimitTime = 360,
    buyShuadaoTimes = 4,
    doublePoint = 0,
    relife = 0,
    precentAdd = 1,
    marketCount = 4,
    getTaoTru = 60
  },
  [CHS[3001799]] = {
    money = 120,
    vipExpression = 1,
    sweep = 1,
    extraChallengeTimes = 2,
    shuadaoLimitTime = 480,
    buyShuadaoTimes = 6,
    doublePoint = 1,
    relife = 0,
    precentAdd = 1,
    marketCount = 8,
    getTaoTru = 120
  },
  [CHS[3001800]] = {
    money = 150,
    vipExpression = 1,
    sweep = 1,
    extraChallengeTimes = 3,
    shuadaoLimitTime = 600,
    buyShuadaoTimes = 8,
    doublePoint = 2,
    relife = 1,
    precentAdd = 0,
    marketCount = 12,
    getTaoTru = 180
  }
}
