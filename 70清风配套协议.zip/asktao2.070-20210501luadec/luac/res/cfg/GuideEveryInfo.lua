return {
  [1] = {operType = "addIcon", oper = 1},
  [2] = {operType = "addIcon", oper = 9},
  [3] = {operType = "addIcon", oper = 6},
  [4] = {operType = "addIcon", oper = 2},
  [5] = {operType = "addIcon", oper = 11},
  [6] = {operType = "addIcon", oper = 4},
  [7] = {operType = "addIcon", oper = 15},
  [8] = {operType = "addIcon", oper = 18},
  [9] = {operType = "addIcon", oper = 5},
  [10] = {operType = "addIcon", oper = 10},
  [11] = {operType = "addIcon", oper = 11},
  [12] = {operType = "addIcon", oper = 16},
  [13] = {operType = "addIcon", oper = 17},
  [14] = {operType = "addIcon", oper = 14},
  [15] = {operType = "addIcon", oper = 3},
  [16] = {
    operType = "ClientNotify",
    oper = {identify = "iamok"},
    relationDlg = "SystemFunctionDlg",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "ActivitiesDlg",
        clickBtn = "ActivityButton"
      },
      relationDlg = "SystemFunctionDlg",
      effectPos = {x = 100, y = 100},
      tip = {
        content = CHS[3000539],
        pos = {x = 50, y = 50},
        posType = "down"
      }
    }
  },
  [17] = {
    operType = "ClientNotify",
    oper = {identify = "iamok"},
    relationDlg = "ActivitiesDlg",
    detail = {
      operType = "TouchBtnEx",
      oper = {clickItem = "gotoButton"},
      relationDlg = "ActivitiesDlg",
      effectPos = {x = 100, y = 100},
      tip = {
        content = CHS[3000540],
        pos = {x = 50, y = 50},
        posType = "right"
      }
    }
  },
  [18] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentTabDlg",
      clickBtn = "EquipButton"
    },
    relationDlg = "GameFunctionDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000541],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [19] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentUpgradeDlg",
      clickBtn = "EquipmentUpgradeDlgCheckBox"
    },
    relationDlg = "EquipmentTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000542],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [20] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UpgradeButton"
    },
    relationDlg = "EquipmentUpgradeDlg",
    tip = {
      content = CHS[3000543],
      posType = "leftUp"
    }
  },
  [21] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "HelmetPanel"
    },
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000544],
      posType = "rightUp"
    }
  },
  [22] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "EvolveButton"
    },
    relationDlg = "EquipmentEvolveDlg",
    tip = {
      content = CHS[3000545],
      posType = "leftUp"
    }
  },
  [23] = {
    operType = "TouchObjInFight",
    oper = {pos = 2},
    tip = {
      content = CHS[3000546],
      posType = "right"
    }
  },
  [24] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "DefenseButton"
    },
    relationDlg = "FightPlayerMenuDlg",
    tip = {
      content = CHS[3000547],
      posType = "up"
    }
  },
  [25] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "FightUseResDlg",
      clickBtn = "UseItemButton"
    },
    relationDlg = "FightPlayerMenuDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000548],
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [26] = {
    operType = "TouchBtn",
    oper = {clickBtn = "UseButton"},
    relationDlg = "FightUseResDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000549],
      posType = "right"
    }
  },
  [27] = {
    operType = "TouchObjInFight",
    oper = {pos = 17},
    tip = {
      content = CHS[3000550],
      posType = "left"
    }
  },
  [28] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "EscapeButton"
    },
    relationDlg = "FightPlayerMenuDlg",
    tip = {
      content = CHS[3000551],
      posType = "up"
    }
  },
  [29] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CatchButton"
    },
    relationDlg = "FightPlayerMenuDlg",
    tip = {
      content = CHS[3000552],
      posType = "up"
    }
  },
  [30] = {
    operType = "TouchObjInFight",
    oper = {pos = 2},
    tip = {
      content = CHS[3000553],
      posType = "right"
    }
  },
  [31] = {
    operType = "TouchObjInFight",
    oper = {pos = 2},
    tip = {
      content = CHS[3000554],
      posType = "right"
    }
  },
  [32] = {
    operType = "TouchObjInFight",
    oper = {pos = 2},
    tip = {
      content = CHS[3000555],
      posType = "right"
    }
  },
  [33] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "FightPlayerMenuDlg"
    },
    tip = {content = nil, posType = "up"}
  },
  [34] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GuardTabDlg",
      clickBtn = "GuardButton"
    },
    relationDlg = "GameFunctionDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000556],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [35] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GuardCallDlg",
      clickBtn = "GuardCallDlgCheckBox"
    },
    relationDlg = "GuardTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000557],
      pos = {x = 50, y = 50},
      posType = "leftDown"
    }
  },
  [36] = {
    operType = "OpenDlg",
    oper = {dlgName = "ConfirmDlg", clickBtn = "CallButton"},
    relationDlg = "GuardAttribDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000558],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [37] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GuardAttribDlg",
      clickBtn = "GuardAttribDlgCheckBox"
    },
    relationDlg = "GuardTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000559],
      pos = {x = 50, y = 50},
      posType = "leftDown"
    }
  },
  [38] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CombatButton"
    },
    relationDlg = "GuardAttribDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000560],
      posType = "leftDown"
    }
  },
  [39] = {
    operType = "OpenDlg",
    oper = {dlgName = "PetTabDlg", clickBtn = "PetImage"},
    relationDlg = "HeadDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000561],
      posType = "leftDown"
    }
  },
  [40] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "PetAttribDlg",
      clickBtn = "PetAttribDlgCheckBox"
    },
    relationDlg = "PetTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000562],
      pos = {x = 50, y = 50},
      posType = "left"
    }
  },
  [41] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "FightCheckBox"
    },
    relationDlg = "PetAttribDlg",
    tip = {
      content = CHS[3000563],
      posType = "down"
    }
  },
  [42] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GuardAttribDlg",
      clickBtn = "GuardAttribDlgCheckBox"
    },
    relationDlg = "GuardTabDlg",
    tip = {
      content = CHS[3000564],
      posType = "leftUp"
    }
  },
  [43] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "GuardCallDlg"
    },
    effectPos = {x = 100, y = 100},
    tip = {
      content = nil,
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [44] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentEvolveDlg",
      clickBtn = "EquipmentEvolveDlgCheckBox"
    },
    relationDlg = "EquipmentTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000565],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [45] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "UserTabDlg",
      clickBtn = "PlayerImage"
    },
    relationDlg = "HeadDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000566],
      pos = {x = 50, y = 50},
      posType = "leftDown"
    }
  },
  [46] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "SkillDlg",
      clickBtn = "SkillDlgCheckBox"
    },
    relationDlg = "UserTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000567],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [47] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "physicSkill"
    },
    relationDlg = "SkillDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000568],
      pos = {x = 50, y = 50},
      posType = "rightDown"
    }
  },
  [48] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RightButton"
    },
    relationDlg = "SkillDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000569],
      pos = {x = 50, y = 50},
      posType = "rightDown"
    }
  },
  [49] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "Learn5Button",
      subType = "TouchCallBack",
      subTypeIdentify = "Learn5Button"
    },
    relationDlg = "SkillDlg",
    tip = {
      content = CHS[3000570],
      posType = "leftUp"
    }
  },
  [50] = {
    operType = "OpenDlgEx",
    oper = {dlgName = "SkillDlg"},
    effectPos = {x = 100, y = 100},
    tip = {
      content = nil,
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [51] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentRefiningDlg",
      clickBtn = "EquipmentRefiningTabDlgCheckBox"
    },
    relationDlg = "EquipmentTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000571],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [52] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RecommendButton"
    },
    relationDlg = "EquipmentRefiningDlg",
    tip = {
      content = CHS[3000572],
      posType = "leftUp"
    }
  },
  [53] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "RefiningButton1"
    },
    relationDlg = "EquipmentRefiningDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000573],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [54] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RefiningButton"
    },
    relationDlg = "EquipmentRefiningAttributeDlg",
    tip = {
      content = CHS[3000574],
      posType = "leftUp"
    }
  },
  [55] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "EquipmentRefiningAttributeDlg"
    },
    effectPos = {x = 100, y = 100},
    tip = {
      content = nil,
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [56] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "UserAddPointDlg",
      clickBtn = "UserAddPointDlgCheckBox"
    },
    relationDlg = "UserAddPointTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000575],
      pos = {x = 50, y = 50},
      posType = "leftDown"
    }
  },
  [57] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "AutoAddPointButton"
    },
    relationDlg = "UserAddPointDlg",
    tip = {
      content = CHS[3000576],
      posType = "leftDown"
    }
  },
  [58] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "SchemeCheckBox2"
    },
    relationDlg = "UserAutoAddPointDlg",
    tip = {
      content = CHS[3000577],
      posType = "leftDown"
    }
  },
  [59] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "SchemeCheckBox1"
    },
    relationDlg = "UserAutoAddPointDlg",
    tip = {
      content = CHS[3000578],
      posType = "leftDown"
    }
  },
  [60] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfrimButton"
    },
    relationDlg = "UserAutoAddPointDlg",
    tip = {
      content = CHS[3000579],
      posType = "leftUp"
    }
  },
  [61] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "UserAutoAddPointDlg"
    },
    effectPos = {x = 100, y = 100},
    tip = {
      content = nil,
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [62] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "EvolveButton"
    },
    relationDlg = "EquipmentEvolveDlg",
    tip = {
      content = CHS[3000580],
      posType = "leftUp"
    }
  },
  [63] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "HelmetPanel"
    },
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000581],
      posType = "rightUp"
    }
  },
  [64] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "EvolveButton"
    },
    relationDlg = "EquipmentEvolveDlg",
    tip = {
      content = CHS[3000582],
      posType = "leftUp"
    }
  },
  [65] = {
    operType = "TouchBtn",
    oper = {clickBtn = "ArmorPanel"},
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000583],
      posType = "rightUp"
    }
  },
  [66] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "EvolveButton"
    },
    relationDlg = "EquipmentEvolveDlg",
    tip = {
      content = CHS[3000584],
      posType = "leftUp"
    }
  },
  [67] = {
    operType = "TouchBtn",
    oper = {clickBtn = "BootPanel"},
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000585],
      posType = "rightUp"
    }
  },
  [68] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "EvolveButton"
    },
    relationDlg = "EquipmentEvolveDlg",
    tip = {
      content = CHS[3000586],
      posType = "leftUp"
    }
  },
  [69] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentEvolveDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [70] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "AutoFightButton"
    },
    relationDlg = "FightPlayerMenuDlg",
    tip = {
      content = CHS[3000588],
      posType = "leftUp"
    }
  },
  [71] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "firstTask"},
    relationDlg = "MissionDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000589],
      pos = {x = 50, y = 50},
      posType = "left"
    }
  },
  [72] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "FastUseItemDlg"
    },
    effectPos = {x = 100, y = 100},
    tip = {
      content = nil,
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [73] = {
    operType = "TouchLongCtrl",
    oper = {clickBtn = "UseButton"},
    relationDlg = "FastUseItemDlg",
    tip = {
      content = CHS[3000590],
      posType = "left"
    }
  },
  [74] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "PetAttribDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [75] = {
    operType = "OpenDlgEx",
    oper = {dlgName = "MissionDlg"},
    effectPos = {x = 100, y = 100},
    tip = {
      content = nil,
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [76] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "ArenaDlg",
      clickBtn = "ArenaButton"
    },
    relationDlg = "SystemFunctionDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000591],
      pos = {x = 50, y = 50},
      posType = "leftDown"
    }
  },
  [77] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "challeng"},
    relationDlg = "ArenaDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000592],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [78] = {
    operType = "OpenDlgEx",
    oper = {dlgName = "ConfirmDlg"},
    effectPos = {x = 100, y = 100},
    tip = {
      content = nil,
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [79] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "ConfirmDlg",
    tip = {
      content = CHS[3000593],
      posType = "leftUp"
    }
  },
  [80] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "PartyInfoDlg",
      clickBtn = "PartyButton"
    },
    relationDlg = "GameFunctionDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000594],
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [81] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        dlgName = "PartyInfoDlg",
        clickBtn = "PartyButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[3000594],
        posType = "up"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [82] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RightButton"
    },
    relationDlg = "SkillDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000595],
      posType = "rightDown"
    }
  },
  [83] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtnEx",
      oper = {clickItem = "cSkill"},
      relationDlg = "SkillDlg",
      effectPos = {x = 100, y = 100},
      tip = {
        content = CHS[3000596],
        pos = {x = 50, y = 50},
        posType = "rightDown"
      }
    },
    oper = {
      identify = "learnCSkill"
    },
    relationDlg = "SkillDlg"
  },
  [84] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "Learn1Button"
    },
    relationDlg = "SkillDlg",
    tip = {
      content = CHS[3000570],
      posType = "up"
    }
  },
  [85] = {operType = "addIcon", oper = 34},
  [10001] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UseSkillButton",
      subType = "TouchCallBack",
      subTypeIdentify = "UseSkillButton"
    },
    relationDlg = "FightPlayerMenuDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000597],
      pos = {x = 50, y = 50},
      posType = "left"
    }
  },
  [10002] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "B5"},
    relationDlg = "FightPlayerSkillDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000598],
      pos = {x = 50, y = 50},
      posType = "left"
    }
  },
  [10003] = {
    operType = "TouchObjInFight",
    oper = {pos = 2},
    tip = {
      content = CHS[3000599],
      posType = "right"
    }
  },
  [10004] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = CHS[3000600]
    },
    relationDlg = "FightPlayerSkillDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000598],
      pos = {x = 50, y = 50},
      posType = "left"
    }
  },
  [10005] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "B4"},
    relationDlg = "FightPlayerSkillDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000598],
      pos = {x = 50, y = 50},
      posType = "left"
    }
  },
  [10006] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "FightPlayerSkillDlg"
    },
    effectPos = {x = 100, y = 100},
    tip = {
      content = nil,
      pos = {x = 50, y = 50},
      posType = "left"
    }
  },
  [10007] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtnEx",
      oper = {clickItem = "firstTask"},
      relationDlg = "MissionDlg",
      effectPos = {x = 100, y = 100},
      tip = {
        content = CHS[3000589],
        pos = {x = 50, y = 50},
        posType = "left"
      }
    },
    oper = {identify = "firstTask"},
    relationDlg = "MissionDlg"
  },
  [10008] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchLongCtrl",
      oper = {clickBtn = "UseButton"},
      relationDlg = "FastUseItemDlg",
      tip = {
        content = CHS[3000590],
        posType = "left"
      }
    },
    oper = {identify = "iamok"},
    relationDlg = "FastUseItemDlg"
  },
  [10009] = {operType = "addIcon", oper = 42},
  [10010] = {operType = "addIcon", oper = 34},
  [10011] = {operType = "addIcon", oper = 35},
  [10012] = {operType = "addIcon", oper = 36},
  [10013] = {operType = "addIcon", oper = 43},
  [10014] = {operType = "addIcon", oper = 21},
  [10015] = {operType = "addIcon", oper = 44},
  [10016] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "WeaponPanel"
      },
      relationDlg = "EquipmentChildDlg",
      tip = {
        content = CHS[3000601],
        posType = "rightDown"
      }
    },
    oper = {
      identify = "TouchWeaponPanel"
    },
    relationDlg = "EquipmentChildDlg"
  },
  [10017] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "EnableCheckBox"
      },
      relationDlg = "UserAutoAddPointDlg",
      tip = {
        content = CHS[3000602],
        posType = "leftUp"
      }
    },
    oper = {
      identify = "TouchAutoCheck"
    },
    relationDlg = "UserAutoAddPointDlg"
  },
  [10018] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "UserAddPointDlg",
    tip = {
      content = CHS[3000603],
      posType = "leftUp"
    }
  },
  [10019] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "UserAddPointDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10020] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "PolarAddPointDlg",
      clickBtn = "PolarAddPointDlgCheckBox"
    },
    relationDlg = "UserAddPointTabDlg",
    tip = {
      content = CHS[3000604],
      posType = "leftDown"
    }
  },
  [10021] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "PolarAutoAddPointDlg",
      clickBtn = "AutoAddPointButton"
    },
    relationDlg = "PolarAddPointDlg",
    tip = {
      content = CHS[3000576],
      posType = "leftDown"
    }
  },
  [10022] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "SchemeCheckBox2"
    },
    relationDlg = "PolarAutoAddPointDlg",
    tip = {
      content = CHS[3000605],
      posType = "leftDown"
    }
  },
  [10023] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "SchemeCheckBox1"
    },
    relationDlg = "PolarAutoAddPointDlg",
    tip = {
      content = CHS[3000606],
      posType = "leftDown"
    }
  },
  [10024] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "EnableCheckBox"
      },
      relationDlg = "PolarAutoAddPointDlg",
      tip = {
        content = CHS[3000602],
        posType = "leftUp"
      }
    },
    oper = {
      identify = "TouchAutoCheck"
    },
    relationDlg = "PolarAutoAddPointDlg"
  },
  [10025] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfrimButton"
    },
    relationDlg = "PolarAutoAddPointDlg",
    tip = {
      content = CHS[3000579],
      posType = "leftUp"
    }
  },
  [10026] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "PolarAddPointDlg",
    tip = {
      content = CHS[3000603],
      posType = "leftUp"
    }
  },
  [10027] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "PolarAddPointDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10028] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "Learn5Button",
      subType = "TouchCallBack",
      subTypeIdentify = "Learn5Button"
    },
    relationDlg = "SkillDlg",
    tip = {
      content = CHS[3000607],
      posType = "leftUp"
    }
  },
  [10029] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "CloseButton"
      },
      relationDlg = "SkillDlg",
      tip = {
        content = CHS[3000587],
        posType = "leftDown"
      }
    },
    oper = {
      identify = "setAutoFightDefaultParam"
    },
    relationDlg = "SkillDlg"
  },
  [10030] = {operType = "addIcon", oper = 38},
  [10031] = {operType = "addIcon", oper = 39},
  [10035] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "PracticeDlg",
      clickBtn = "LiangongButton"
    },
    relationDlg = "SystemFunctionDlg",
    tip = {
      content = CHS[3000608],
      posType = "leftDown"
    }
  },
  [10036] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UseOpenStatePanel"
    },
    relationDlg = "PracticeDlg",
    tip = {
      content = CHS[3000609],
      posType = "leftUp"
    }
  },
  [10037] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "PracticeDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10038] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "WeaponPanel"
      },
      relationDlg = "EquipmentChildDlg",
      tip = {
        content = CHS[3000601],
        posType = "rightDown"
      }
    },
    oper = {
      identify = "TouchWeaponPanel"
    },
    relationDlg = "EquipmentChildDlg"
  },
  [10039] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UpgradeButton"
    },
    relationDlg = "EquipmentUpgradeDlg",
    tip = {
      content = CHS[3000610],
      posType = "leftUp"
    }
  },
  [10040] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "HelmetPanel"
    },
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000581],
      posType = "rightUp"
    }
  },
  [10041] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UpgradeButton"
    },
    relationDlg = "EquipmentUpgradeDlg",
    tip = {
      content = CHS[3000611],
      posType = "rightUp"
    }
  },
  [10042] = {
    operType = "TouchBtn",
    oper = {clickBtn = "ArmorPanel"},
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000583],
      posType = "rightUp"
    }
  },
  [10043] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UpgradeButton"
    },
    relationDlg = "EquipmentUpgradeDlg",
    tip = {
      content = CHS[3000612],
      posType = "leftUp"
    }
  },
  [10044] = {
    operType = "TouchBtn",
    oper = {clickBtn = "BootPanel"},
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000585],
      posType = "rightUp"
    }
  },
  [10045] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UpgradeButton"
    },
    relationDlg = "EquipmentUpgradeDlg",
    tip = {
      content = CHS[3000613],
      posType = "leftUp"
    }
  },
  [10046] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentUpgradeDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10047] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "WeaponPanel"
      },
      relationDlg = "EquipmentChildDlg",
      tip = {
        content = CHS[3000601],
        posType = "rightDown"
      }
    },
    oper = {
      identify = "TouchWeaponPanel"
    },
    relationDlg = "EquipmentChildDlg"
  },
  [10048] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentRefiningAttributeDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10049] = {
    operType = "OpenDlg",
    oper = {dlgName = "BagDlg", clickBtn = "BagButton"},
    relationDlg = "GameFunctionDlg",
    tip = {
      content = CHS[3000614],
      posType = "leftDown"
    }
  },
  [10050] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "selectBag"},
    relationDlg = "BagDlg",
    tip = {
      content = CHS[3000615],
      posType = "leftDown"
    }
  },
  [10051] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtnEx",
      oper = {
        clickItem = "undefinedEquip"
      },
      relationDlg = "BagDlg",
      tip = {
        content = CHS[3000616],
        posType = "leftUp"
      }
    },
    oper = {
      identify = "undefinedEquip"
    },
    relationDlg = "BagDlg"
  },
  [10052] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "IdentifyDlg",
      clickBtn = "ApplyButton"
    },
    relationDlg = "ItemInfoDlg",
    tip = {
      content = CHS[3000617],
      posType = "leftUp"
    }
  },
  [10053] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "NormalButton"
    },
    relationDlg = "IdentifyDlg",
    tip = {
      content = CHS[3000618],
      posType = "leftUp"
    }
  },
  [10054] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "ItemInfoDlg"
    }
  },
  [10055] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "B1",
      subType = "TouchCallBack",
      subTypeIdentify = "B1"
    },
    relationDlg = "FightPlayerSkillDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000598],
      pos = {x = 50, y = 50},
      posType = "left"
    }
  },
  [10056] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "FightPlayerMenuDlg"
    },
    tip = {content = nil, posType = "left"}
  },
  [10057] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchObjInFight",
      oper = {pos = 2},
      tip = {
        content = CHS[3000599],
        posType = "right"
      }
    },
    oper = {identify = "hasPet"},
    relationDlg = "ChatDlg"
  },
  [10058] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "EquipmentTabDlg",
        clickBtn = "EquipButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[3000541],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [10059] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "GuardAttribDlg",
        clickBtn = "GuardButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[3000556],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [10060] = {operType = "addIcon", oper = 41},
  [10061] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchLongCtrl",
      oper = {clickBtn = "UseButton"},
      relationDlg = "FastUseItemDlg",
      tip = {
        content = CHS[3000619],
        posType = "left"
      }
    },
    oper = {identify = "iamok"},
    relationDlg = "FastUseItemDlg"
  },
  [10062] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentTabDlg",
      clickBtn = "EquipButton"
    },
    relationDlg = "GameFunctionDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000541],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [10063] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentRefiningSuitDlg",
      clickBtn = "EquipmentRefiningSuitDlgCheckBox"
    },
    relationDlg = "EquipmentTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000620],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [10064] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtnEx",
      oper = {clickBtn = ""},
      relationDlg = "EquipmentChildDlg",
      tip = {
        content = CHS[3000621],
        posType = "rightUp"
      }
    },
    oper = {identify = "first"},
    relationDlg = "EquipmentChildDlg"
  },
  [10065] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentChangePolarDlg",
      clickBtn = "AddButton"
    },
    relationDlg = "EquipmentRefiningSuitDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000622],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [10066] = {
    operType = "ClientNotify",
    oper = {identify = "first"},
    relationDlg = "EquipmentChangePolarDlg",
    detail = {
      operType = "TouchBtnEx",
      oper = {clickBtn = ""},
      relationDlg = "EquipmentChangePolarDlg",
      tip = {
        content = CHS[3000622],
        posType = "up"
      }
    }
  },
  [10067] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "BindCheckBox"
    },
    relationDlg = "EquipmentRefiningSuitDlg",
    tip = {
      content = CHS[3000623],
      posType = "leftUp"
    }
  },
  [10068] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentRefiningSuitDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10069] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RefiningButton"
    },
    relationDlg = "EquipmentRefiningSuitDlg",
    tip = {
      content = CHS[3000624],
      posType = "leftUp"
    }
  },
  [10070] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "EquipmentRefiningTabDlgCheckBox"
    },
    relationDlg = "EquipmentTabDlg",
    tip = {
      content = CHS[3000625],
      posType = "leftUp"
    }
  },
  [10071] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "AttributeButton5"
    },
    relationDlg = "EquipmentRefiningDlg",
    tip = {
      content = CHS[3000626],
      posType = "up"
    }
  },
  [10072] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentRefiningPinkDlg",
      clickBtn = "RefiningButton"
    },
    relationDlg = "EquipmentRefiningDlg",
    tip = {
      content = CHS[3000624],
      posType = "rightUp"
    }
  },
  [10125] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentRefiningYellowDlg",
      clickBtn = "RefiningButton"
    },
    relationDlg = "EquipmentRefiningDlg",
    tip = {
      content = CHS[3000624],
      posType = "rightUp"
    }
  },
  [10073] = {
    operType = "ClientNotify",
    oper = {identify = "iamok"},
    relationDlg = "EquipmentRefiningYellowDlg",
    detail = {
      operType = "TouchBtn",
      oper = {clickBtn = "MaxButton"},
      relationDlg = "EquipmentRefiningYellowDlg",
      tip = {
        content = CHS[3000627],
        posType = "leftUp"
      }
    }
  },
  [10074] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "BindCheckBox"
    },
    relationDlg = "EquipmentRefiningYellowDlg",
    tip = {
      content = CHS[3000623],
      posType = "rightUp"
    }
  },
  [10075] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RefiningButton"
    },
    relationDlg = "EquipmentRefiningYellowDlg",
    tip = {
      content = CHS[3000624],
      posType = "rightUp"
    }
  },
  [10076] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentRefiningYellowDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10077] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentRefiningDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10078] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "AttributeButton4"
    },
    relationDlg = "EquipmentRefiningDlg",
    tip = {
      content = CHS[3000628],
      posType = "up"
    }
  },
  [10079] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "BindCheckBox"
    },
    relationDlg = "EquipmentRefiningPinkDlg",
    tip = {
      content = CHS[3000623],
      posType = "rightUp"
    }
  },
  [10080] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RefiningButton"
    },
    relationDlg = "EquipmentRefiningPinkDlg",
    tip = {
      content = CHS[3000624],
      posType = "rightUp"
    }
  },
  [10081] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentRefiningPinkDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10082] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentSplitDlg",
      clickBtn = "EquipmentSplitTabDlgCheckBox"
    },
    relationDlg = "EquipmentTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000629],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [10083] = {
    operType = "TouchBtnEx",
    oper = {clickBtn = ""},
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000630],
      posType = "rightUp"
    }
  },
  [10084] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "BindCheckBox"
    },
    relationDlg = "EquipmentSplitDlg",
    tip = {
      content = CHS[3000623],
      posType = "rightUp"
    }
  },
  [10085] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "ChaosJadeCheckBox"
    },
    relationDlg = "EquipmentSplitDlg",
    tip = {
      content = CHS[3000631],
      posType = "leftUp"
    }
  },
  [10086] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "SplitButton"
    },
    relationDlg = "EquipmentSplitDlg",
    tip = {
      content = CHS[3000632],
      posType = "rightUp"
    }
  },
  [10087] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentSplitDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10088] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "EquipmentReformDlg",
        clickBtn = "EquipmentReformPanel"
      },
      relationDlg = "EquipmentChildDlg",
      tip = {
        content = CHS[3000633],
        posType = "up"
      }
    },
    oper = {identify = "refine"},
    relationDlg = "EquipmentChildDlg"
  },
  [10089] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentSelectDlg",
      clickBtn = "EquipmentImagePanel"
    },
    relationDlg = "EquipmentReformDlg",
    tip = {
      content = CHS[3000634],
      posType = "rightUp"
    }
  },
  [10090] = {
    operType = "TouchBtnEx",
    oper = {clickBtn = ""},
    relationDlg = "EquipmentSelectDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000635],
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [10091] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentSelectCrystalDlg",
      clickBtn = "ItemImagePanel1"
    },
    relationDlg = "EquipmentReformDlg",
    tip = {
      content = CHS[3000636],
      posType = "rightUp"
    }
  },
  [10092] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = CHS[3000637],
      subType = "closeDlg"
    },
    relationDlg = "EquipmentSelectCrystalDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000638],
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [10117] = {
    operType = "TouchBtn",
    oper = {
      dlgName = "EquipmentSelectCrystalDlg",
      clickBtn = "ItemImagePanel2"
    },
    relationDlg = "EquipmentReformDlg",
    tip = {
      content = CHS[3000636],
      posType = "rightUp"
    }
  },
  [10093] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentSelectCrystalDlg",
      clickBtn = "ItemImagePanel2"
    },
    relationDlg = "EquipmentReformDlg",
    tip = {
      content = CHS[3000636],
      posType = "rightUp"
    }
  },
  [10094] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = CHS[3000639],
      subType = "closeDlg"
    },
    relationDlg = "EquipmentSelectCrystalDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000638],
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [10118] = {
    operType = "TouchBtn",
    oper = {
      dlgName = "EquipmentSelectCrystalDlg",
      clickBtn = "ItemImagePanel3"
    },
    relationDlg = "EquipmentReformDlg",
    tip = {
      content = CHS[3000636],
      posType = "leftUp"
    }
  },
  [10095] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentSelectCrystalDlg",
      clickBtn = "ItemImagePanel3"
    },
    relationDlg = "EquipmentReformDlg",
    tip = {
      content = CHS[3000636],
      posType = "leftUp"
    }
  },
  [10096] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = CHS[3000640],
      subType = "closeDlg"
    },
    relationDlg = "EquipmentSelectCrystalDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000638],
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [10097] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ReformButton"
    },
    relationDlg = "EquipmentReformDlg",
    tip = {
      content = CHS[3000641],
      posType = "leftUp"
    }
  },
  [10098] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentReformDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10099] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "EquipmentUpgradeDlg",
      clickBtn = "EquipmentUpgradeDlgCheckBox"
    },
    relationDlg = "EquipmentTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000642],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [10100] = {
    operType = "TouchBtnEx",
    oper = {clickBtn = ""},
    relationDlg = "EquipmentChildDlg",
    tip = {
      content = CHS[3000643],
      posType = "rightUp"
    }
  },
  [10101] = {
    operType = "ClientNotify",
    oper = {identify = "iamok"},
    relationDlg = "EquipmentUpgradeDlg",
    detail = {
      operType = "TouchBtnEx",
      oper = {
        clickItem = "BindCheckBox"
      },
      relationDlg = "EquipmentUpgradeDlg",
      tip = {
        content = CHS[3000623],
        posType = "rightUp"
      }
    }
  },
  [10120] = {
    operType = "TouchBtn",
    oper = {
      dlgName = "ConfirmDlg",
      clickBtn = "UpgradeButton"
    },
    relationDlg = "EquipmentUpgradeDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000644],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [10121] = {
    operType = "ClientNotify",
    oper = {identify = "limitEquip"},
    relationDlg = "EquipmentUpgradeDlg",
    detail = {
      operType = "OpenDlgEx",
      oper = {
        dlgName = "ConfirmDlg",
        clickBtn = "ConfirmButton"
      },
      relationDlg = "ConfirmDlg",
      tip = {
        content = CHS[3000645],
        posType = "rightUp"
      }
    }
  },
  [10103] = {
    operType = "ClientNotify",
    oper = {identify = "limitEquip"},
    relationDlg = "EquipmentUpgradeDlg",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "UpgradeButton"
      },
      relationDlg = "EquipmentUpgradeDlg",
      tip = {
        content = CHS[3000644],
        posType = "leftUp"
      }
    }
  },
  [10122] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "ConfirmDlg",
    tip = {
      content = CHS[3000645],
      posType = "rightUp"
    }
  },
  [10124] = {
    operType = "ClientNotify",
    oper = {
      identify = "undifinedEquip"
    },
    relationDlg = "EquipmentReformDlg",
    detail = {
      operType = "OpenDlgEx",
      oper = {
        dlgName = "ConfirmDlg",
        clickBtn = "ConfirmButton"
      },
      relationDlg = "ConfirmDlg",
      tip = {
        content = CHS[3000645],
        posType = "rightUp"
      }
    }
  },
  [10102] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "ConfirmButton"
      },
      relationDlg = "ConfirmDlg",
      tip = {
        content = CHS[3000645],
        posType = "rightUp"
      }
    },
    oper = {identify = "iamok"},
    relationDlg = "ConfirmDlg"
  },
  [10119] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentRefiningDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10104] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "EquipmentUpgradeDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10105] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "JewelryUpgradeDlg",
      clickBtn = "JewelryMakeDlgCheckBox"
    },
    relationDlg = "EquipmentTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000646],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [10106] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = 300,
      subType = "TouchCallBack",
      subTypeIdentify = "touchBig"
    },
    relationDlg = "JewelryUpgradeDlg",
    tip = {
      content = CHS[3000647],
      posType = "rightUp"
    }
  },
  [10107] = {
    operType = "ClientNotify",
    oper = {identify = "iamok"},
    relationDlg = "JewelryUpgradeDlg",
    detail = {
      operType = "TouchBtnEx",
      oper = {
        clickItem = 301,
        subType = "TouchCallBack",
        subTypeIdentify = "touchBig"
      },
      relationDlg = "JewelryUpgradeDlg",
      tip = {
        content = CHS[3000647],
        posType = "rightUp"
      }
    }
  },
  [10108] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "CheckBox"},
    relationDlg = "JewelryUpgradeDlg",
    tip = {
      content = CHS[3000623],
      posType = "leftUp"
    }
  },
  [10109] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UpgradeButton"
    },
    relationDlg = "JewelryUpgradeDlg",
    tip = {
      content = CHS[3000648],
      posType = "leftUp"
    }
  },
  [10123] = {
    operType = "ClientNotify",
    oper = {identify = "limitEquip"},
    relationDlg = "JewelryUpgradeDlg",
    detail = {
      operType = "OpenDlgEx",
      oper = {
        dlgName = "ConfirmDlg",
        clickBtn = "ConfirmButton"
      },
      relationDlg = "ConfirmDlg",
      tip = {
        content = CHS[3000645],
        posType = "rightUp"
      }
    }
  },
  [79] = {
    operType = "ClientNotify",
    oper = {identify = "iamok"},
    relationDlg = "ConfirmDlg",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "ConfirmButton"
      },
      relationDlg = "ConfirmDlg",
      tip = {
        content = CHS[3000593],
        posType = "leftUp"
      }
    }
  },
  [10110] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "JewelryUpgradeDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10111] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "ConfirmDlg",
    tip = {
      content = CHS[3000645],
      posType = "rightUp"
    }
  },
  [10112] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchLongCtrl",
      oper = {clickBtn = "UseButton"},
      relationDlg = "FastUseItemDlg",
      tip = {
        content = CHS[3000649],
        posType = "leftUp"
      }
    },
    oper = {identify = "iamok"},
    relationDlg = "FastUseItemDlg"
  },
  [10113] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "NoviceGiftDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [10114] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "newGift"},
    relationDlg = "BagDlg",
    tip = {
      content = CHS[3000650],
      posType = "leftDown"
    }
  },
  [10115] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtnEx",
      oper = {clickItem = "getWeapon"},
      relationDlg = "BagDlg",
      tip = {
        content = CHS[3000651],
        posType = "leftDown"
      }
    },
    oper = {
      identify = "getNewWeapon"
    },
    relationDlg = "BagDlg"
  },
  [10116] = {
    operType = "ClientNotify",
    oper = {identify = "iamok"},
    relationDlg = "ConfirmDlg",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "ConfirmButton"
      },
      relationDlg = "ConfirmDlg",
      tip = {
        content = CHS[3000652],
        posType = "leftUp"
      }
    }
  },
  [10117] = {
    operType = "ClientNotify",
    oper = {identify = "limitEquip"},
    relationDlg = "EquipmentSplitDlg",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "ConfirmButton"
      },
      relationDlg = "ConfirmDlg",
      tip = {
        content = CHS[3000645],
        posType = "rightUp"
      }
    }
  },
  [118] = {
    operType = "OpenDlgEx",
    oper = {dlgName = "ConfirmDlg"},
    tip = {content = nil, posType = "up"}
  },
  [20000] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "JewelryUpgradeDlg",
        clickBtn = "JewelryButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[4100270],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [20001] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "ForgeButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[3000541],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [20002] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "ForgeButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[3000541],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [20003] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "EquipmentTabDlg",
        clickBtn = "EquipButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[4100269],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [20004] = {
    operType = "TouchBtn",
    oper = {clickBtn = "ChatButton"},
    relationDlg = "ChatDlg",
    tip = {
      content = "点击打开#R聊天#n界面",
      posType = "rightUp"
    }
  },
  [20005] = {
    operType = "OpenDlgEx",
    oper = {dlgName = "ChannelDlg"},
    tip = {content = nil, posType = "up"}
  },
  [20006] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        clickBtn = "PartyCheckBox"
      },
      relationDlg = "ChannelDlg",
      tip = {
        content = "点击进入#R聊天#n界面",
        posType = "rightUp"
      }
    },
    oper = {identify = "isShow63"},
    relationDlg = "ChannelDlg"
  },
  [20007] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "partyLink"},
    relationDlg = "ChannelDlg",
    tip = {
      content = "点击'添加'按钮",
      posType = "rightDown"
    }
  },
  [20008] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "0m"},
    relationDlg = "LinkAndExpressionDlg",
    tip = {
      content = "选择发言表情",
      posType = "rightUp"
    }
  },
  [20009] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "LinkAndExpressionDlg"
    },
    tip = {content = nil, posType = "up"}
  },
  [20010] = {
    operType = "TouchBtn",
    oper = {clickBtn = "SendButton"},
    relationDlg = "LinkAndExpressionDlg",
    tip = {
      content = "点击发送消息",
      posType = "leftUp"
    }
  },
  [20011] = {operType = "addIcon", oper = 22},
  [20012] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "UserTabDlg",
      clickBtn = "PlayerImage"
    },
    relationDlg = "HeadDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[3000566],
      pos = {x = 50, y = 50},
      posType = "leftDown"
    }
  },
  [20013] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "UserDlg",
      clickBtn = "UserDlgCheckBox"
    },
    relationDlg = "UserTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = "点击打开#R属性#n标签页",
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [20014] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "CharToBabyDlg",
      clickBtn = "BabyButton"
    },
    relationDlg = "UserDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = "点击切换#RbabyType%s#n状态",
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [20015] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ComfireButton"
    },
    relationDlg = "CharToBabyDlg",
    tip = {
      content = "点击切换#RbabyType%s#n状态",
      posType = "leftUp"
    }
  },
  [30001] = {operType = "addIcon", oper = 21},
  [30002] = {operType = "addIcon", oper = 23},
  [30003] = {operType = "addIcon", oper = 24},
  [30004] = {operType = "addIcon", oper = 45},
  [30005] = {operType = "addIcon", oper = 47},
  [30006] = {operType = "addIcon", oper = 48},
  [30007] = {operType = "addIcon", oper = 25},
  [20016] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "SystemConfigTabDlg",
        clickBtn = "SystemButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[7003088],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [20017] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "SystemAccManageDlg",
      clickBtn = "SystemAccManageDlgCheckBox"
    },
    relationDlg = "SystemConfigTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[7003089],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [20018] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "SafeLockMainDlg",
      getClickBtnFunc = "getClickBtn"
    },
    relationDlg = "SystemAccManageDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[7003090],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [20019] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {dlgName = "HomeInDlg", clickBtn = "HomeButton"},
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[7003104],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [20020] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "HomeInButton"
    },
    relationDlg = "HomeInDlg",
    tip = {
      content = CHS[7003105],
      posType = "leftUp"
    }
  },
  [20021] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "UserAddPointTabDlg",
      clickBtn = "UserAddPointDlgCheckBox"
    },
    relationDlg = "UserTabDlg",
    tip = {
      content = CHS[7100137],
      posType = "leftDown"
    }
  },
  [20022] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "petStone"},
    relationDlg = "PetListChildDlg",
    tip = {
      content = CHS[5400684],
      posType = "rightUp"
    }
  },
  [20023] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "PetStoneDlg",
      clickBtn = "PetStoneButton"
    },
    relationDlg = "PetAttribDlg",
    tip = {
      content = CHS[5400685],
      posType = "leftUp"
    }
  },
  [20024] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "chooseEmptyPanel",
      subType = "TouchCallBack",
      subTypeIdentify = "ChoseStonePanel"
    },
    relationDlg = "PetStoneDlg",
    tip = {
      content = CHS[5400686],
      posType = "rightUp"
    }
  },
  [20025] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "chooseStone"
    },
    relationDlg = "PetStoneDlg",
    tip = {
      content = CHS[5400687],
      posType = "rightUp"
    }
  },
  [20026] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "AddButton",
      subType = "TouchCallBack",
      subTypeIdentify = "ActiveButton"
    },
    relationDlg = "PetStoneDlg",
    tip = {
      content = CHS[5400688],
      posType = "rightUp"
    }
  },
  [20027] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "ConfirmDlg",
    tip = {
      content = CHS[5400683],
      posType = "rightUp"
    }
  },
  [20028] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "PetStoneDlg",
    tip = {
      content = CHS[5400689],
      posType = "leftDown"
    }
  },
  [20029] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "PetAttribDlg",
    tip = {
      content = CHS[5400689],
      posType = "leftDown"
    }
  },
  [20030] = {operType = "addIcon", oper = 35},
  [20031] = {
    operType = "addIcon",
    oper = 37,
    notTab = true
  },
  [20032] = {operType = "addIcon", oper = 50},
  [20033] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "InnerAlchemyDlg",
      clickBtn = "InnerAlchemyDlgCheckBox"
    },
    relationDlg = "UserTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[4010462],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [20034] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "BreakButton"
    },
    relationDlg = "InnerAlchemyDlg",
    tip = {
      content = CHS[4010463],
      posType = "leftUp"
    }
  },
  [20035] = {
    operType = "SmallTips",
    tips = CHS[4010464]
  },
  [20036] = {
    operType = "TouchBtn",
    oper = {clickBtn = "CallButton"},
    relationDlg = "GhostPetCallDlg",
    tip = {
      content = CHS[4010471],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20037] = {
    operType = "TouchBtn",
    oper = {clickBtn = "TouchPanel"},
    relationDlg = "GhostPetCallDlg",
    tip = {
      content = CHS[4010470],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20038] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "GetElitePetModifyDlg"
    },
    tip = {content = nil, posType = "up"}
  },
  [20039] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ContinueButton",
      root = "PetCallButtonPanel"
    },
    relationDlg = "GetElitePetModifyDlg",
    tip = {
      content = CHS[4010469],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20040] = {
    operType = "OpenDlg",
    oper = {dlgName = "PetTabDlg", clickBtn = "PetImage"},
    relationDlg = "HeadDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[4010468],
      pos = {x = 50, y = 50},
      posType = "leftDown"
    }
  },
  [20041] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GhostGrowPandectDlg",
      clickBtn = "PetGrowButton"
    },
    relationDlg = "PetAttribDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[4010467],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [20042] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GhostPetGongShengExDlg",
      clickBtn = "SymbiosisDlgCheckBox"
    },
    relationDlg = "GhostPetGrowTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[4010466],
      pos = {x = 50, y = 50},
      posType = "rightDown"
    }
  },
  [20043] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "GongShengPetPanel"
    },
    relationDlg = "GhostPetGongShengExDlg",
    tip = {
      content = CHS[4010465],
      posType = "leftDown"
    },
    notReturnMainView = true
  },
  [20044] = {
    operType = "SmallTips",
    tips = CHS[4010472]
  },
  [20045] = {
    operType = "openDlgRightNow",
    dlgName = "GhostPetCallDlg"
  },
  [20046] = {
    operType = "ClientNotify",
    oper = {
      identify = "action_down"
    },
    relationDlg = "GhostPetCallDlg"
  },
  [20047] = {
    operType = "openDlgRightNow",
    dlgName = "BagDlg"
  },
  [20048] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ReturnPanel"
    },
    relationDlg = "GhostPetCallDlg",
    tip = {
      content = CHS[4101701],
      posType = "rightDown"
    },
    notReturnMainView = true
  },
  [20049] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "YinHunButton"
    },
    relationDlg = "YinHunDlg",
    tip = {
      content = CHS[4101700],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20050] = {
    operType = "ClientNotify",
    oper = {
      identify = "action_down"
    },
    relationDlg = "YinHunDlg"
  },
  [20051] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "YinHunDlg",
    tip = {
      content = CHS[4101699],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20052] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "HunQiaoButton"
    },
    relationDlg = "YinHunDlg",
    tip = {
      content = CHS[4101698],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20053] = {
    operType = "OpenDlgEx",
    oper = {dlgName = "HunQiaoDlg"},
    tip = {content = nil, posType = "up"}
  },
  [20054] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "HunQiaoPanel1"
    },
    relationDlg = "HunQiaoDlg",
    tip = {
      content = CHS[4101697],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20055] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "HunQiaoFillDlg"
    },
    tip = {content = nil, posType = "up"}
  },
  [20056] = {
    operType = "TouchBtnEx",
    oper = {
      clickBtn = "ItemPanel_1"
    },
    relationDlg = "HunQiaoFillDlg",
    tip = {
      content = CHS[4101696],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20057] = {
    operType = "ClientNotify",
    oper = {
      identify = "action_down"
    },
    relationDlg = "HunQiaoFillDlg"
  },
  [20058] = {
    operType = "TouchBtn",
    oper = {clickBtn = "FillButton"},
    relationDlg = "HunQiaoFillDlg",
    tip = {
      content = CHS[4101695],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20059] = {
    operType = "SmallTips",
    tips = CHS[4101694]
  },
  [20060] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "HorcruxListDlg",
        clickBtn = "HorcruxButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[4101705],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [20061] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "HorcruxListDlg",
        clickBtn = "HorcruxButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[4101705],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [20062] = {
    operType = "TouchBtnEx",
    oper = {clickBtn = ""},
    relationDlg = "HorcruxListDlg",
    tip = {
      content = CHS[4101706],
      posType = "rightUp"
    },
    notReturnMainView = true
  },
  [20063] = {
    operType = "TouchBtnEx",
    oper = {clickBtn = ""},
    relationDlg = "HorcruxAttriRefineDlg",
    tip = {
      content = CHS[4101707],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20064] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "BindCheckBox",
      dlgName = "HorcruxRefiningDlg",
      getClickBtnFunc = "getClickCheckBox"
    },
    relationDlg = "HorcruxRefiningDlg",
    tip = {
      content = CHS[4101703],
      posType = "rightup"
    },
    notReturnMainView = true
  },
  [20065] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RefineChaosButton"
    },
    relationDlg = "HorcruxAttriRefineDlg",
    tip = {
      content = CHS[4101704],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20066] = {
    operType = "OpenDlgEx",
    oper = {dlgName = "ConfirmDlg"},
    effectPos = {x = 100, y = 100},
    tip = {
      content = "",
      pos = {x = 50, y = 50},
      posType = "up"
    }
  },
  [20067] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "ConfirmDlg",
    tip = {
      content = CHS[5400683],
      posType = "rightUp"
    },
    notReturnMainView = true
  },
  [20068] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "FenhuaButton"
    },
    relationDlg = "HorcruxAttriRefineDlg",
    tip = {
      content = CHS[4101708],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20069] = {
    operType = "ClientNotify",
    oper = {identify = "refresh"},
    relationDlg = "HorcruxAttriRefineDlg"
  },
  [20070] = {
    operType = "OpenDlg",
    oper = {dlgName = "PetTabDlg", clickBtn = "PetImage"},
    relationDlg = "HeadDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[7100787],
      posType = "leftDown"
    }
  },
  [20071] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "RightButton"
    },
    relationDlg = "PetListChildDlg",
    tip = {
      content = CHS[7100787],
      posType = "leftDown"
    }
  },
  [20072] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "GetPeiyuanPet"
    },
    relationDlg = "PetListChildDlg",
    tip = {
      content = CHS[7100788],
      posType = "rightUp"
    }
  },
  [20073] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GhostGrowPandectDlg",
      clickBtn = "PetGrowButton"
    },
    relationDlg = "PetAttribDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[7100789],
      pos = {x = 50, y = 50},
      posType = "leftUp"
    }
  },
  [20074] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GhostPetPeiYuanDlg",
      clickBtn = "PeiYuanDlgCheckBox"
    },
    relationDlg = "GhostPetGrowTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[7100790],
      posType = "rightUp"
    }
  },
  [20075] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "StartButton"
    },
    relationDlg = "GhostPetPeiYuanDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[7100791],
      posType = "leftUp"
    }
  },
  [20076] = {
    operType = "SmallTips",
    tips = CHS[7100792]
  },
  [20077] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "GetNingshenPet"
    },
    relationDlg = "PetListChildDlg",
    tip = {
      content = CHS[7100788],
      posType = "rightUp"
    }
  },
  [20078] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "GhostPetNingShenDlg",
      clickBtn = "NingShenDlgCheckBox"
    },
    relationDlg = "GhostPetGrowTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[7100793],
      posType = "rightUp"
    }
  },
  [20079] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "StartButton"
    },
    relationDlg = "GhostPetNingShenDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[7100794],
      posType = "leftUp"
    }
  },
  [20080] = {
    operType = "SmallTips",
    tips = CHS[7100795]
  },
  [20081] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "getNingshenLimit"
    },
    relationDlg = "GhostPetNingShenDlg",
    tip = {
      content = CHS[7100798],
      posType = "leftUp"
    }
  },
  [20082] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "ConfirmDlg",
    tip = {
      content = CHS[7100799],
      posType = "rightUp"
    }
  },
  [20083] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "YinHunPanel"
    },
    relationDlg = "YinhrdDlg",
    tip = {
      content = CHS[7120256],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20084] = {
    operType = "special_action",
    relationDlg = "HunQiaoFillDlg",
    action = "select_all_radio"
  },
  [20085] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RefiningButton"
    },
    relationDlg = "HorcruxRefiningDlg",
    tip = {
      content = CHS[4101704],
      posType = "leftUp"
    },
    notReturnMainView = true
  },
  [20086] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "HorcruxRefiningDlg"
    },
    tip = {content = nil, posType = "up"}
  },
  [40000] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "HorcruxAttriRefineDlg",
    tip = {
      content = CHS[4101709],
      posType = "leftDown"
    },
    notReturnMainView = true
  },
  [40001] = {
    operType = "delay",
    delayTime = 0.1,
    notReturnMainView = true
  },
  [40002] = {
    operType = "special_action",
    relationDlg = "BagDlg",
    action = "select_hunqi"
  },
  [40003] = {
    operType = "addIcon",
    oper = 43,
    notTab = true
  },
  [40004] = {
    operType = "addIcon",
    oper = 46,
    needPlayAddIcon = true,
    notTab = true
  },
  [40005] = {
    operType = "addIcon",
    oper = 47,
    notTab = true
  },
  [40006] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "SpiritSystemTabDlg",
        clickBtn = "SpiritButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[5401014],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [40007] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "SpiritSystemMagicCircleDlg",
      clickBtn = "MagicCirclePanel"
    },
    relationDlg = "SpiritSystemTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[5401015],
      posType = "leftUp"
    }
  },
  [40008] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ActivationButton"
    },
    relationDlg = "SpiritSystemMagicCircleDlg",
    tip = {
      content = CHS[5401016],
      posType = "leftUp"
    }
  },
  [40009] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {
        dlgName = "SpiritSystemMagicCircleDlg",
        clickBtn = "RaiseButton"
      },
      relationDlg = "SpiritSystemMagicCircleDlg",
      tip = {
        content = CHS[5401017],
        posType = "leftUp"
      }
    },
    notDelay = true,
    oper = {identify = "levelup"},
    relationDlg = "SpiritSystemMagicCircleDlg"
  },
  [40010] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "SpiritSystemMagicCircleDlg",
    tip = {
      content = CHS[3000587],
      posType = "leftDown"
    }
  },
  [40011] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "SpiritSystemDlg",
      clickBtn = "SpiritPanel"
    },
    relationDlg = "SpiritSystemTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[5401018],
      posType = "leftUp"
    }
  },
  [40012] = {
    operType = "TouchBtn",
    oper = {
      getClickBtnFunc = "getClickBtn"
    },
    relationDlg = "SpiritSystemDlg",
    tip = "getGuideTip"
  },
  [40013] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "RaiseButton"
    },
    relationDlg = "SpiritSystemDlg",
    tip = {
      content = CHS[2100371],
      posType = "up"
    }
  },
  [40014] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "SpiritSystemDlg",
    tip = {
      content = CHS[2100372],
      posType = "leftDown"
    }
  },
  [40015] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "SpiritSystemPossessedDlg",
      clickBtn = "PossessedPanel"
    },
    relationDlg = "SpiritSystemTabDlg",
    effectPos = {x = 100, y = 100},
    tip = {
      content = CHS[5401019],
      posType = "leftUp"
    }
  },
  [40016] = {
    operType = "TouchBtn",
    oper = {
      getClickBtnFunc = "getClickBtn"
    },
    relationDlg = "SpiritSystemPossessedDlg",
    tip = "getGuideTip"
  },
  [40017] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "SpiritSystemPossessedDlg",
    tip = {
      content = CHS[2100373],
      posType = "leftUp"
    }
  },
  [40018] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "SpiritSystemPossessedDlg",
    tip = {
      content = CHS[2100372],
      posType = "leftDown"
    }
  },
  [40019] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "EquipmentRefiningDlg"
    }
  },
  [40020] = {
    operType = "addIcon",
    oper = 49,
    notTab = true
  },
  [40021] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "TianGFuYaoDlg",
        clickBtn = "TianGongButton"
      },
      relationDlg = "GameFunctionDlg",
      tip = {
        content = CHS[5401039],
        posType = "leftUp"
      }
    },
    oper = {identify = "isListShow"},
    relationDlg = "GameFunctionDlg"
  },
  [40023] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtnEx",
      oper = {
        clickItem = "huagu",
        subType = "TouchCallBack",
        subTypeIdentify = "huagu"
      },
      relationDlg = "TianGFuYaoMapDlg",
      tip = {
        content = CHS[5401040],
        posType = "rightUp"
      }
    },
    notDelay = true,
    overTime = 15000,
    blackOpacity = 0,
    oper = {identify = "openCloud"},
    relationDlg = "TianGFuYaoMapDlg"
  },
  [40024] = {
    operType = "TouchBtnEx",
    oper = {clickItem = "DareButton"},
    relationDlg = "TianGMainInterfaceTabDlg",
    tip = {
      content = CHS[5401035],
      posType = "leftUp"
    }
  },
  [40025] = {
    operType = "OpenDlgEx",
    oper = {
      dlgName = "TianGFuYaoFightingDlg"
    },
    tip = {content = nil, posType = "up"}
  },
  [40026] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtn",
      oper = {clickBtn = "X1Button", root = "X1Panel"},
      blackOpacity = 0,
      relationDlg = "TianGMainInterfaceTabDlg",
      relationDlgs = {
        "TianGFuYaoSettlementDlg"
      },
      tip = {
        content = CHS[5401036],
        posType = "leftDown"
      }
    },
    notDelay = true,
    overTime = 15000,
    blackOpacity = 0,
    oper = {identify = "doDare"},
    relationDlg = "TianGMainInterfaceTabDlg"
  },
  [40022] = {
    operType = "TouchBtn",
    oper = {clickBtn = "OverButton", root = "OverPanel"},
    blackOpacity = 0,
    relationDlg = "TianGMainInterfaceTabDlg",
    tip = {
      content = CHS[5401063],
      posType = "leftDown"
    }
  },
  [40027] = {
    operType = "OpenDlgEx",
    overTime = 15000,
    oper = {
      dlgName = "TianGFuYaoSettlementDlg"
    },
    blackOpacity = 0,
    tip = {content = nil, posType = "up"}
  },
  [40028] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "EndPanel",
      changeBox = {
        x = 350,
        y = 35,
        width = -700,
        height = -60
      }
    },
    blackOpacity = 0,
    relationDlg = "TianGFuYaoSettlementDlg",
    tip = {
      content = CHS[5401037],
      posType = "rightUp"
    }
  },
  [40029] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CloseButton"
    },
    relationDlg = "TianGMainInterfaceTabDlg",
    tip = {
      content = CHS[5401038],
      offset = {x = -40},
      posType = "leftDown"
    }
  },
  [40030] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "TianGLSPromoteDlg",
        clickBtn = "PromoteButton"
      },
      relationDlg = "TianGMainInterfaceTabDlg",
      tip = {
        content = CHS[5401042],
        posType = "rightDown"
      }
    },
    oper = {identify = "waitOpen"},
    relationDlg = "TianGMainInterfaceTabDlg"
  },
  [40031] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ConfirmButton"
    },
    relationDlg = "TianGLSPromoteDlg",
    tip = {
      content = CHS[5401043],
      posType = "up"
    }
  },
  [40033] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "TianGMainInterfaceDlg",
        clickBtn = "TabPanel03"
      },
      relationDlg = "TianGMainInterfaceTabDlg",
      tip = {
        content = CHS[5401044],
        offset = {x = -40},
        posType = "leftDown"
      }
    },
    oper = {identify = "waitOpen"},
    relationDlg = "TianGMainInterfaceTabDlg"
  },
  [40034] = {
    operType = "OpenDlg",
    oper = {
      clickBtn = "GodPanel",
      changeBox = {
        x = 50,
        y = 50,
        width = -100,
        height = -100
      },
      dlgName = "TianGCallGodWillDlg"
    },
    relationDlg = "TianGMainInterfaceDlg",
    tip = {
      content = CHS[5401045],
      posType = "rightUp"
    }
  },
  [40035] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "nezha",
      changeBox = {
        x = 50,
        y = 20,
        width = -100,
        height = -40
      }
    },
    relationDlg = "TianGGodGeneralDlg",
    tip = {
      content = CHS[5401046],
      posType = "rightDown"
    }
  },
  [40036] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "UnlockButton"
    },
    relationDlg = "TianGGodGeneralDlg",
    tip = {
      content = CHS[5401047],
      posType = "up"
    }
  },
  [40037] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtnEx",
      oper = {clickItem = "getGod"},
      relationDlg = "MissionDlg",
      tip = {
        content = CHS[5401048],
        posType = "leftDown"
      }
    },
    oper = {identify = "getGod"},
    relationDlg = "MissionDlg"
  },
  [40038] = {
    operType = "ClientNotify",
    detail = {
      operType = "OpenDlg",
      oper = {
        dlgName = "TianGGodGeneralDlg",
        clickBtn = "TabPanel02"
      },
      relationDlg = "TianGMainInterfaceTabDlg",
      tip = {
        content = CHS[5401049],
        offset = {x = -40},
        posType = "leftDown"
      }
    },
    oper = {identify = "waitOpen"},
    relationDlg = "TianGMainInterfaceTabDlg"
  },
  [40039] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "EditLineupButton"
    },
    relationDlg = "TianGGodGeneralDlg",
    tip = {
      content = CHS[5401050],
      posType = "leftUp"
    }
  },
  [40040] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "nezha",
      changeBox = {
        x = 50,
        y = 20,
        width = -100,
        height = -40
      }
    },
    relationDlg = "TianGGodGeneralDlg",
    tip = {
      content = "点击选择#R哪吒#n",
      posType = "rightDown"
    }
  },
  [40041] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "FightButton"
    },
    relationDlg = "TianGGodGeneralDlg",
    tip = {
      content = "点击#R参战#n按钮使哪吒出战",
      posType = "up"
    }
  },
  [40042] = {
    operType = "ClientNotify",
    detail = {
      operType = "TouchBtnEx",
      oper = {clickItem = "tjym"},
      relationDlg = "MissionDlg",
      tip = {
        content = CHS[5401053],
        posType = "leftDown"
      }
    },
    oper = {identify = "tjym"},
    relationDlg = "MissionDlg"
  },
  [40043] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "yangjian",
      changeBox = {
        x = 50,
        y = 20,
        width = -100,
        height = -40
      }
    },
    relationDlg = "TianGGodGeneralDlg",
    tip = {
      content = "选择#R杨戬#n",
      posType = "rightDown"
    }
  },
  [40045] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "TianGGodBackpackDlg",
      clickBtn = "Panel01",
      root = "PanoplyPanel"
    },
    relationDlg = "TianGGodGeneralDlg",
    tip = {
      content = CHS[5401056],
      posType = "leftUp"
    }
  },
  [40046] = {
    operType = "TouchBtnEx",
    oper = {
      clickItem = "tiejian",
      subType = "TouchCallBack",
      subTypeIdentify = "showFloat"
    },
    relationDlg = "TianGGodBackpackDlg",
    tip = {
      content = CHS[5401057],
      posType = "rightDown"
    }
  },
  [40047] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = CHS[5450646]
    },
    relationDlg = "TianGEquipmentFloatingFrameDlg",
    tip = {
      content = CHS[5401055],
      posType = "rightUp"
    }
  },
  [40048] = {
    operType = "OpenDlg",
    oper = {
      clickBtn = "SoulPanel",
      changeBox = {
        x = 50,
        y = 50,
        width = -100,
        height = -100
      },
      dlgName = "TianGGodSoulDlg"
    },
    relationDlg = "TianGMainInterfaceDlg",
    tip = {
      content = CHS[5401092],
      posType = "right"
    }
  },
  [40049] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "Panel01",
      root = "PanoplyPanel"
    },
    relationDlg = "TianGGodSoulDlg",
    tip = {
      content = CHS[5401093],
      posType = "rightDown"
    }
  },
  [40050] = {
    operType = "TouchBtn",
    oper = {clickBtn = "Button"},
    blackOpacity = 0,
    relationDlg = "TianGGodSoulDlg",
    tip = {
      content = string.format(CHS[5401094], 3),
      posType = "up"
    }
  },
  [40051] = {
    operType = "TouchBtn",
    oper = {clickBtn = "Button"},
    blackOpacity = 0,
    relationDlg = "TianGGodSoulDlg",
    tip = {
      content = string.format(CHS[5401094], 2),
      posType = "up"
    }
  },
  [40052] = {
    operType = "TouchBtn",
    oper = {clickBtn = "Button"},
    blackOpacity = 0,
    relationDlg = "TianGGodSoulDlg",
    tip = {
      content = string.format(CHS[5401094], 1),
      posType = "up"
    }
  },
  [40053] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ObtainButton",
      subType = "TouchCallBack",
      subTypeIdentify = "notOpen"
    },
    blackOpacity = 0,
    relationDlg = "TianGGodSoulDlg",
    tip = {
      content = CHS[5401095],
      posType = "up"
    }
  },
  [40054] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "ReturnButton"
    },
    relationDlg = "TianGMainInterfaceTabDlg",
    tip = {
      content = CHS[5401097],
      offset = {x = -40},
      posType = "leftDown"
    }
  },
  [40055] = {
    operType = "TouchBtn",
    oper = {
      clickBtn = "CanvassButton"
    },
    relationDlg = "TianGGodGeneralDlg",
    tip = {
      content = "点击#R前往招揽#n按钮",
      posType = "up"
    }
  },
  [40056] = {
    operType = "OpenDlg",
    oper = {
      dlgName = "WelfareDlg",
      clickBtn = "GiftsButton"
    },
    relationDlg = "SystemFunctionDlg",
    tip = {
      content = CHS[7333384],
      posType = "right"
    }
  },
  [40057] = {
    operType = "addIcon",
    oper = 10001,
    notTab = true
  }
}
