return {
  time = {
    yuandan = {
      name = CHS[7150493],
      startTime = "20210101050000",
      endTime = "20210102045959"
    },
    chunjie = {
      name = CHS[7150494],
      startTime = "20210212050000",
      endTime = "20210219045959"
    },
    yuanxiao = {
      name = CHS[7150495],
      startTime = "20210226050000",
      endTime = "20210227045959"
    },
    zhounianqin = {
      name = CHS[7150496],
      startTime = "20210430050000",
      endTime = "20210514045959"
    },
    duanwu = {
      name = CHS[7150497],
      startTime = "20210614050000",
      endTime = "20210615045959"
    },
    zhongqiu = {
      name = CHS[7150498],
      startTime = "20210921050000",
      endTime = "20210922045959"
    }
  },
  map = {
    [CHS[7150394]] = {},
    [CHS[7150395]] = {},
    [CHS[7150396]] = {},
    [CHS[7150397]] = {}
  },
  propaganda = {
    general = {
      {
        text = CHS[7150323],
        type = 1,
        weight = 200,
        times = 2,
        playerName = true,
        festivalName = true
      },
      {
        text = CHS[7150324],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150325],
        type = 1,
        weight = 100,
        times = 1,
        festivalName = true
      }
    },
    yuandan = {
      {
        text = CHS[7150326],
        type = 1,
        weight = 400,
        times = 8,
        fourWords = true
      },
      {
        text = CHS[7150327],
        type = 1,
        weight = 200,
        times = 2,
        playerName = true
      },
      {
        text = CHS[7150328],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150329],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150330],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150331],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150332],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150333],
        type = 1,
        weight = 100,
        times = 1
      }
    },
    chunjie = {
      {
        text = CHS[7150334],
        type = 1,
        weight = 400,
        times = 8,
        fourWords = true
      },
      {
        text = CHS[7150335],
        type = 1,
        weight = 200,
        times = 2,
        playerName = true
      },
      {
        text = CHS[7150336],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150337],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150338],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150339],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150340],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150341],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150342],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150343],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150344],
        type = 2,
        weight = 50,
        times = 1
      }
    },
    yuanxiao = {
      {
        text = CHS[7150345],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150346],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150347],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150348],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150349],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150350],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150351],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150352],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150353],
        type = 2,
        weight = 50,
        times = 1
      }
    },
    zhounianqin = {
      {
        text = CHS[7150354],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150355],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150356],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150357],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150358],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150359],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150360],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150361],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150363],
        type = 1,
        weight = 100,
        times = 1
      }
    },
    duanwu = {
      {
        text = CHS[7150364],
        type = 1,
        weight = 200,
        times = 1
      },
      {
        text = CHS[7150365],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150366],
        type = 1,
        weight = 100,
        times = 3
      },
      {
        text = CHS[7150367],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150707],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150368],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150369],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150370],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150371],
        type = 2,
        weight = 50,
        times = 1
      }
    },
    zhongqiu = {
      {
        text = CHS[7150372],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150373],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150374],
        type = 1,
        weight = 100,
        times = 1
      },
      {
        text = CHS[7150375],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150376],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150377],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150378],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150379],
        type = 2,
        weight = 50,
        times = 1
      },
      {
        text = CHS[7150380],
        type = 2,
        weight = 50,
        times = 1
      }
    },
    fourWords = {
      CHS[7150381],
      CHS[7150382],
      CHS[7150383],
      CHS[7150384],
      CHS[7150385],
      CHS[7150386],
      CHS[7150387],
      CHS[7150388],
      CHS[7150389],
      CHS[7150390],
      CHS[7150391],
      CHS[7150392],
      CHS[7150393]
    }
  },
  drama = {
    yuandan = {
      [CHS[7150394]] = {
        ganji = cc.p(135, 89),
        kezhanmizong = cc.p(100, 125)
      },
      [CHS[7150395]] = {}
    },
    chunjie = {
      [CHS[7150394]] = {
        kanwangqinqi = cc.p(174, 110),
        xiechunlian = cc.p(14, 66),
        yasuiqian = cc.p(84, 53)
      },
      [CHS[7150395]] = {
        fangbianpao = cc.p(91, 88)
      }
    },
    yuanxiao = {
      [CHS[7150394]] = {
        maiyuanxiao = cc.p(72, 42),
        caidengmi = cc.p(37, 143),
        shanghuadeng = cc.p(159, 37),
        kuqingren = cc.p(54, 140)
      },
      [CHS[7150395]] = {}
    },
    zhounianqin = {
      [CHS[7150394]] = {
        chudaotianyong = cc.p(184, 116),
        jieriganji = cc.p(159, 37),
        ganxiebangmang = cc.p(130, 121),
        tianyongtanqin = cc.p(54, 39)
      },
      [CHS[7150395]] = {}
    },
    duanwu = {
      [CHS[7150394]] = {
        meiweizongzi = cc.p(122, 126)
      },
      [CHS[7150395]] = {
        sailongzhou = cc.p(98, 108)
      }
    },
    zhongqiu = {
      [CHS[7150394]] = {
        woyeyaochi = cc.p(154, 100),
        yinshizuole = cc.p(97, 127)
      },
      [CHS[7150395]] = {
        changerge = cc.p(83, 81)
      }
    }
  }
}
