return {
  buff = {
    {
      name = "妖皇战刃",
      icon = "BuffIcon0020.png",
      desc = "妖皇·刃天伤害提升50%"
    },
    {
      name = "妖皇战甲",
      icon = "BuffIcon0037.png",
      desc = "妖皇·刃天防御提升100%"
    },
    {
      name = "妖皇战翼",
      icon = "BuffIcon0036.png",
      desc = "妖皇·刃天速度提升50%"
    },
    {
      name = "群妖怒意",
      icon = "BuffIcon0029.png",
      desc = "妖皇·刃天伤害提升20%，小怪伤害提升30%"
    },
    {
      name = "群妖护法",
      icon = "BuffIcon0013.png",
      desc = "妖皇·刃天防御提升40%，小怪防御提升60%"
    },
    {
      name = "群妖奔袭",
      icon = "BuffIcon0038.png",
      desc = "妖皇·刃天速度提升20%，小怪速度提升30%"
    }
  },
  tactics_type = {
    "属性增强",
    "效果增强",
    "怪物削弱",
    "特殊策略"
  },
  tactics = {
    {
      type = "属性增强",
      quality = "优良",
      name = "全队气血增强",
      desc = "全体神将气血上限＋#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 50},
      lv1 = {num = 10, Num = 50},
      lv2 = {num = 20, Num = 50},
      lv3 = {num = 30, Num = 50},
      lv4 = {num = 40, Num = 50},
      lv5 = {num = 50, Num = 50}
    },
    {
      type = "属性增强",
      quality = "优良",
      name = "全队速度增强",
      desc = "全体神将速度＋#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 10},
      lv1 = {num = 2, Num = 10},
      lv2 = {num = 4, Num = 10},
      lv3 = {num = 6, Num = 10},
      lv4 = {num = 8, Num = 10},
      lv5 = {num = 10, Num = 10}
    },
    {
      type = "属性增强",
      quality = "普通",
      name = "全队双伤增强",
      desc = "全体神将物理伤害＋#Rnum1%#n/Num1%、法术伤害＋#Rnum2%#n/Num2%",
      lv0 = {
        num1 = 0,
        Num1 = 10,
        num2 = 0,
        Num2 = 10
      },
      lv1 = {
        num1 = 2,
        Num1 = 10,
        num2 = 2,
        Num2 = 10
      },
      lv2 = {
        num1 = 4,
        Num1 = 10,
        num2 = 4,
        Num2 = 10
      },
      lv3 = {
        num1 = 6,
        Num1 = 10,
        num2 = 6,
        Num2 = 10
      },
      lv4 = {
        num1 = 8,
        Num1 = 10,
        num2 = 8,
        Num2 = 10
      },
      lv5 = {
        num1 = 10,
        Num1 = 10,
        num2 = 10,
        Num2 = 10
      }
    },
    {
      type = "属性增强",
      quality = "普通",
      name = "物理神将物伤增强",
      desc = "物理型神将伤害＋#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 15},
      lv1 = {num = 3, Num = 15},
      lv2 = {num = 6, Num = 15},
      lv3 = {num = 9, Num = 15},
      lv4 = {num = 12, Num = 15},
      lv5 = {num = 15, Num = 15}
    },
    {
      type = "属性增强",
      quality = "普通",
      name = "法术神将法伤增强",
      desc = "法术型神将伤害＋#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 15},
      lv1 = {num = 3, Num = 15},
      lv2 = {num = 6, Num = 15},
      lv3 = {num = 9, Num = 15},
      lv4 = {num = 12, Num = 15},
      lv5 = {num = 15, Num = 15}
    },
    {
      type = "属性增强",
      quality = "普通",
      name = "全队双抗增强",
      desc = "全体神将物理减伤＋#Rnum1%#n/Num1%、法术减伤＋#Rnum2%#n/Num2%",
      lv0 = {
        num1 = 0,
        Num1 = 10,
        num2 = 0,
        Num2 = 10
      },
      lv1 = {
        num1 = 2,
        Num1 = 10,
        num2 = 2,
        Num2 = 10
      },
      lv2 = {
        num1 = 4,
        Num1 = 10,
        num2 = 4,
        Num2 = 10
      },
      lv3 = {
        num1 = 6,
        Num1 = 10,
        num2 = 6,
        Num2 = 10
      },
      lv4 = {
        num1 = 8,
        Num1 = 10,
        num2 = 8,
        Num2 = 10
      },
      lv5 = {
        num1 = 10,
        Num1 = 10,
        num2 = 10,
        Num2 = 10
      }
    },
    {
      type = "属性增强",
      quality = "优良",
      name = "防御神将双抗增强",
      desc = "防御型神将物理减伤＋#Rnum%#n/Num%、法术减伤＋#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 15},
      lv1 = {num = 3, Num = 15},
      lv2 = {num = 6, Num = 15},
      lv3 = {num = 9, Num = 15},
      lv4 = {num = 12, Num = 15},
      lv5 = {num = 15, Num = 15}
    },
    {
      type = "属性增强",
      quality = "普通",
      name = "物理神将反击增强",
      desc = "物理型神将反击率＋#Rnum1%#n/Num1%、反击次数＋#Rnum2#n/Num2",
      lv0 = {
        num1 = 0,
        Num1 = 20,
        num2 = 0,
        Num2 = 10
      },
      lv1 = {
        num1 = 4,
        Num1 = 20,
        num2 = 2,
        Num2 = 10
      },
      lv2 = {
        num1 = 8,
        Num1 = 20,
        num2 = 4,
        Num2 = 10
      },
      lv3 = {
        num1 = 12,
        Num1 = 20,
        num2 = 6,
        Num2 = 10
      },
      lv4 = {
        num1 = 16,
        Num1 = 20,
        num2 = 8,
        Num2 = 10
      },
      lv5 = {
        num1 = 20,
        Num1 = 20,
        num2 = 10,
        Num2 = 10
      }
    },
    {
      type = "属性增强",
      quality = "普通",
      name = "防御神将反震增强",
      desc = "防御型神将反震率＋#Rnum1%#n/Num1%、反震度＋#Rnum2%#n/Num2%",
      lv0 = {
        num1 = 0,
        Num1 = 20,
        num2 = 0,
        Num2 = 30
      },
      lv1 = {
        num1 = 4,
        Num1 = 20,
        num2 = 6,
        Num2 = 30
      },
      lv2 = {
        num1 = 8,
        Num1 = 20,
        num2 = 12,
        Num2 = 30
      },
      lv3 = {
        num1 = 12,
        Num1 = 20,
        num2 = 18,
        Num2 = 30
      },
      lv4 = {
        num1 = 16,
        Num1 = 20,
        num2 = 24,
        Num2 = 30
      },
      lv5 = {
        num1 = 20,
        Num1 = 20,
        num2 = 30,
        Num2 = 30
      }
    },
    {
      type = "效果增强",
      quality = "极品",
      name = "全队反杀小怪增强",
      desc = "小怪攻击神将触发反击或反震时，额外造成等同小怪#Rnum%#n/Num%气血上限的伤害",
      lv0 = {num = 0, Num = 100},
      lv1 = {num = 10, Num = 100},
      lv2 = {num = 20, Num = 100},
      lv3 = {num = 40, Num = 100},
      lv4 = {num = 65, Num = 100},
      lv5 = {num = 100, Num = 100}
    },
    {
      type = "效果增强",
      quality = "优良",
      name = "辅助神将治疗增强",
      desc = "辅助型神将气血回复效果＋#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 50},
      lv1 = {num = 5, Num = 50},
      lv2 = {num = 10, Num = 50},
      lv3 = {num = 20, Num = 50},
      lv4 = {num = 35, Num = 50},
      lv5 = {num = 50, Num = 50}
    },
    {
      type = "效果增强",
      quality = "优良",
      name = "物法神将吸血增强",
      desc = "物理型神将、法术型神将吸血效果＋#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 20},
      lv1 = {num = 2, Num = 20},
      lv2 = {num = 4, Num = 20},
      lv3 = {num = 8, Num = 20},
      lv4 = {num = 14, Num = 20},
      lv5 = {num = 20, Num = 20}
    },
    {
      type = "效果增强",
      quality = "优良",
      name = "防御神将嘲讽增强",
      desc = "怪物攻击防御型神将的几率＋#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 100},
      lv1 = {num = 10, Num = 100},
      lv2 = {num = 20, Num = 100},
      lv3 = {num = 40, Num = 100},
      lv4 = {num = 65, Num = 100},
      lv5 = {num = 100, Num = 100}
    },
    {
      type = "怪物削弱",
      quality = "普通",
      name = "怪物全体回血降低",
      desc = "所有怪物气血回复效果－#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 50},
      lv1 = {num = 5, Num = 50},
      lv2 = {num = 10, Num = 50},
      lv3 = {num = 20, Num = 50},
      lv4 = {num = 35, Num = 50},
      lv5 = {num = 50, Num = 50}
    },
    {
      type = "怪物削弱",
      quality = "优良",
      name = "怪物全体速度降低",
      desc = "所有怪物速度－#Rnum%#n/Num%",
      lv0 = {num = 0, Num = 10},
      lv1 = {num = 2, Num = 10},
      lv2 = {num = 4, Num = 10},
      lv3 = {num = 6, Num = 10},
      lv4 = {num = 8, Num = 10},
      lv5 = {num = 10, Num = 10}
    },
    {
      type = "怪物削弱",
      quality = "优良",
      name = "小怪伤害弱化",
      desc = "非妖皇类怪物物理伤害－#Rnum1%#n/Num1%、法术伤害－#Rnum2%#n/Num2%",
      lv0 = {
        num1 = 0,
        Num1 = 15,
        num2 = 0,
        Num2 = 15
      },
      lv1 = {
        num1 = 3,
        Num1 = 15,
        num2 = 3,
        Num2 = 15
      },
      lv2 = {
        num1 = 6,
        Num1 = 15,
        num2 = 6,
        Num2 = 15
      },
      lv3 = {
        num1 = 9,
        Num1 = 15,
        num2 = 9,
        Num2 = 15
      },
      lv4 = {
        num1 = 12,
        Num1 = 15,
        num2 = 12,
        Num2 = 15
      },
      lv5 = {
        num1 = 15,
        Num1 = 15,
        num2 = 15,
        Num2 = 15
      }
    },
    {
      type = "怪物削弱",
      quality = "普通",
      name = "小怪双抗降低",
      desc = "非妖皇类怪物物理减伤－#Rnum1%#n/Num1%、法术减伤－#Rnum1%#n/Num1%",
      lv0 = {
        num1 = 0,
        Num1 = 10,
        num2 = 0,
        Num2 = 10
      },
      lv1 = {
        num1 = 2,
        Num1 = 10,
        num2 = 2,
        Num2 = 10
      },
      lv2 = {
        num1 = 4,
        Num1 = 10,
        num2 = 4,
        Num2 = 10
      },
      lv3 = {
        num1 = 6,
        Num1 = 10,
        num2 = 6,
        Num2 = 10
      },
      lv4 = {
        num1 = 8,
        Num1 = 10,
        num2 = 8,
        Num2 = 10
      },
      lv5 = {
        num1 = 10,
        Num1 = 10,
        num2 = 10,
        Num2 = 10
      }
    },
    {
      type = "特殊策略",
      quality = "极品",
      name = "全队伤害吸收护盾",
      desc = "开局时全队获得伤害吸收护盾，总共可吸收等同自身#Rnum%#n/Num%血量上限的伤害（最多可抵挡#Rvalue#n/Value次伤害）",
      lv0 = {
        num = 0,
        Num = 500,
        value = 0,
        Value = 10
      },
      lv1 = {
        num = 60,
        Num = 500,
        value = 1,
        Value = 10
      },
      lv2 = {
        num = 140,
        Num = 500,
        value = 3,
        Value = 10
      },
      lv3 = {
        num = 240,
        Num = 500,
        value = 5,
        Value = 10
      },
      lv4 = {
        num = 360,
        Num = 500,
        value = 7,
        Value = 10
      },
      lv5 = {
        num = 500,
        Num = 500,
        value = 10,
        Value = 10
      }
    },
    {
      type = "特殊策略",
      quality = "优良",
      name = "妙手回春",
      desc = "前#Rn1#n/N1回合内，全队每次受到非致命伤害时有#Rnum1%#n/Num1%几率获得持续回血效果，每回合开始时回复等同自身#Rnum2%#n/Num2%血量上限的气血，持续#Rnum3#n/Num3回合",
      lv0 = {
        n1 = 0,
        N1 = 20,
        num1 = 0,
        Num1 = 20,
        num2 = 0,
        Num2 = 5,
        num3 = 0,
        Num3 = 2
      },
      lv1 = {
        n1 = 4,
        N1 = 20,
        num1 = 4,
        Num1 = 20,
        num2 = 1,
        Num2 = 5,
        num3 = 1,
        Num3 = 2
      },
      lv2 = {
        n1 = 8,
        N1 = 20,
        num1 = 8,
        Num1 = 20,
        num2 = 2,
        Num2 = 5,
        num3 = 1,
        Num3 = 2
      },
      lv3 = {
        n1 = 12,
        N1 = 20,
        num1 = 12,
        Num1 = 20,
        num2 = 3,
        Num2 = 5,
        num3 = 1,
        Num3 = 2
      },
      lv4 = {
        n1 = 16,
        N1 = 20,
        num1 = 16,
        Num1 = 20,
        num2 = 4,
        Num2 = 5,
        num3 = 2,
        Num3 = 2
      },
      lv5 = {
        n1 = 20,
        N1 = 20,
        num1 = 20,
        Num1 = 20,
        num2 = 5,
        Num2 = 5,
        num3 = 2,
        Num3 = 2
      }
    },
    {
      type = "特殊策略",
      quality = "优良",
      name = "九死一生",
      desc = "前#Rn1#n/N1回合内，全队每次受到致命伤害时有#Rnum1%#n/Num1%几率剩下1点气血，并立即恢复等同自身#Rnum2%#n/Num2%血量上限的气血，每回合每名神将最多触发1次",
      lv0 = {
        n1 = 0,
        N1 = 20,
        num1 = 0,
        Num1 = 10,
        num2 = 0,
        Num2 = 10
      },
      lv1 = {
        n1 = 4,
        N1 = 20,
        num1 = 2,
        Num1 = 10,
        num2 = 2,
        Num2 = 10
      },
      lv2 = {
        n1 = 8,
        N1 = 20,
        num1 = 4,
        Num1 = 10,
        num2 = 4,
        Num2 = 10
      },
      lv3 = {
        n1 = 12,
        N1 = 20,
        num1 = 6,
        Num1 = 10,
        num2 = 6,
        Num2 = 10
      },
      lv4 = {
        n1 = 16,
        N1 = 20,
        num1 = 8,
        Num1 = 10,
        num2 = 8,
        Num2 = 10
      },
      lv5 = {
        n1 = 20,
        N1 = 20,
        num1 = 10,
        Num1 = 10,
        num2 = 10,
        Num2 = 10
      }
    },
    {
      type = "特殊策略",
      quality = "极品",
      name = "行云流水",
      desc = "神将主动对小怪造成伤害时（不包括反击、反震），#Rnum%#n/Num%几率使小怪获得除水系以外的4系随机障碍（每回合最多障碍#Rvalue#n/Value个）",
      lv0 = {
        num = 0,
        Num = 30,
        value = 0,
        Value = 3
      },
      lv1 = {
        num = 5,
        Num = 30,
        value = 1,
        Value = 3
      },
      lv2 = {
        num = 10,
        Num = 30,
        value = 1,
        Value = 3
      },
      lv3 = {
        num = 15,
        Num = 30,
        value = 2,
        Value = 3
      },
      lv4 = {
        num = 20,
        Num = 30,
        value = 2,
        Value = 3
      },
      lv5 = {
        num = 30,
        Num = 30,
        value = 3,
        Value = 3
      }
    },
    {
      type = "特殊策略",
      quality = "极品",
      name = "有难同当",
      desc = "神将受致命伤害时，#Rnum1%#n/Num1%几率保留1点气血，并将剩余应受伤害的#Rnum2%#n/Num2%平摊给其余存活神将（本场战斗最多触发#Rvalue#n/Value次），每回合只能生效1次",
      lv0 = {
        num1 = 0,
        Num1 = 10,
        num2 = 0,
        Num2 = 20,
        value = 0,
        Value = 5
      },
      lv1 = {
        num1 = 1,
        Num1 = 10,
        num2 = 100,
        Num2 = 20,
        value = 1,
        Value = 5
      },
      lv2 = {
        num1 = 2,
        Num1 = 10,
        num2 = 80,
        Num2 = 20,
        value = 2,
        Value = 5
      },
      lv3 = {
        num1 = 4,
        Num1 = 10,
        num2 = 60,
        Num2 = 20,
        value = 3,
        Value = 5
      },
      lv4 = {
        num1 = 7,
        Num1 = 10,
        num2 = 40,
        Num2 = 20,
        value = 4,
        Value = 5
      },
      lv5 = {
        num1 = 10,
        Num1 = 10,
        num2 = 20,
        Num2 = 20,
        value = 5,
        Value = 5
      }
    }
  }
}
