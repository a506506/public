return {
  OSS_BUCKET = "atm-image",
  OSS_ENDPOINT = "leiting.com",
  OSS_UPLOAD_PAGE = "",
  OSS_VOICE_BUCKET = "atm-server-voice",
  OSS_VOICE_ENDPOINT = "oss-cn-shanghai.aliyuncs.com",
  OSS_VOICE_UPLOAD_PAGE = ""
}
