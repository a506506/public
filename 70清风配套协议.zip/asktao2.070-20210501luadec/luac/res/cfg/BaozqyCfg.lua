return {
  monster = {
    [1] = {
      name = CHS[7120389],
      icon = 6120,
      life = 50,
      speed = 190,
      score1 = 100,
      score2 = 10,
      reward = 0
    },
    [2] = {
      name = CHS[7120390],
      icon = 6113,
      life = 50,
      speed = 220,
      score1 = 100,
      score2 = 10,
      reward = 0
    },
    [3] = {
      name = CHS[7120391],
      icon = 6140,
      life = 50,
      speed = 240,
      score1 = 100,
      score2 = 10,
      reward = 0
    },
    [4] = {
      name = CHS[7120392],
      icon = 6141,
      life = 50,
      speed = 270,
      score1 = 100,
      score2 = 10,
      reward = 0
    },
    [5] = {
      name = CHS[7120393],
      icon = 6260,
      life = 50,
      speed = 230,
      score1 = 100,
      score2 = 10,
      reward = 2
    },
    [6] = {
      name = CHS[7120394],
      icon = 6153,
      life = 140,
      speed = 220,
      score1 = 300,
      score2 = 30,
      reward = 2
    },
    [7] = {
      name = CHS[7120395],
      icon = 6312,
      life = 140,
      speed = 255,
      score1 = 300,
      score2 = 30,
      reward = 2
    },
    [8] = {
      name = CHS[7120396],
      icon = 6147,
      life = 50,
      speed = 190,
      score1 = 200,
      score2 = 20,
      reward = 0
    },
    [9] = {
      name = CHS[7120397],
      icon = 6151,
      life = 50,
      speed = 230,
      score1 = 300,
      score2 = 30,
      reward = 0
    },
    [10] = {
      name = CHS[7120398],
      icon = 6172,
      life = 50,
      speed = 270,
      score1 = 400,
      score2 = 40,
      reward = 0
    },
    [11] = {
      name = CHS[7120399],
      icon = 6142,
      life = 200,
      speed = 210,
      score1 = 800,
      score2 = 80,
      reward = 0
    },
    [12] = {
      name = CHS[7120400],
      icon = 6149,
      life = 140,
      speed = 240,
      score1 = 700,
      score2 = 70,
      reward = 0
    },
    [13] = {
      name = CHS[7120401],
      icon = 6152,
      life = 320,
      speed = 190,
      score1 = 2500,
      score2 = 250,
      reward = 0
    },
    [14] = {
      name = CHS[7120402],
      icon = 6022,
      life = 160,
      speed = 160,
      score1 = -500,
      score2 = -50,
      reward = 0
    },
    [15] = {
      name = CHS[7120403],
      icon = 6020,
      life = 100,
      speed = 480,
      score1 = -500,
      score2 = -50,
      reward = 0
    }
  },
  round = {
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 1,
      timeDelay = 0.4,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.5,
      y = 260
    },
    {
      key = 1,
      timeDelay = 0.3,
      y = 230
    },
    {
      key = 1,
      timeDelay = 0.4,
      y = 180
    },
    {
      key = 9,
      timeDelay = 0,
      y = 320
    },
    {
      key = 1,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 1,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 1,
      timeDelay = 0.3,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 1,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 1,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 12,
      timeDelay = 0.5,
      y = 180
    },
    {
      key = 11,
      timeDelay = 0.2,
      y = 320
    },
    {
      key = 1,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 8,
      timeDelay = 0,
      y = 230
    },
    {
      key = 1,
      timeDelay = 0.3,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0.6,
      y = 320
    },
    {
      key = 13,
      timeDelay = 0.6,
      y = 300
    },
    {
      key = 15,
      timeDelay = 1,
      y = 260
    },
    {
      key = 6,
      timeDelay = 0,
      y = 220
    },
    {
      key = 8,
      timeDelay = 0.2,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 2,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 2,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 2,
      timeDelay = 0.3,
      y = 180
    },
    {
      key = 9,
      timeDelay = 0.6,
      y = 320
    },
    {
      key = 2,
      timeDelay = 0.1,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.2,
      y = 260
    },
    {
      key = 2,
      timeDelay = 0,
      y = 230
    },
    {
      key = 2,
      timeDelay = 0.1,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 2,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 2,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 12,
      timeDelay = 0.2,
      y = 180
    },
    {
      key = 11,
      timeDelay = 0,
      y = 320
    },
    {
      key = 2,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 10,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 2,
      timeDelay = 0.3,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 13,
      timeDelay = 0.6,
      y = 300
    },
    {
      key = 14,
      timeDelay = 1,
      y = 260
    },
    {
      key = 7,
      timeDelay = 0.4,
      y = 220
    },
    {
      key = 8,
      timeDelay = 0.2,
      y = 180
    },
    {
      key = 9,
      timeDelay = 0,
      y = 320
    },
    {
      key = 3,
      timeDelay = 0.4,
      y = 290
    },
    {
      key = 3,
      timeDelay = 0.6,
      y = 260
    },
    {
      key = 5,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 3,
      timeDelay = 0.4,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 3,
      timeDelay = 0.4,
      y = 290
    },
    {
      key = 3,
      timeDelay = 0.6,
      y = 260
    },
    {
      key = 5,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 3,
      timeDelay = 0.4,
      y = 180
    },
    {
      key = 9,
      timeDelay = 0,
      y = 320
    },
    {
      key = 3,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 3,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 12,
      timeDelay = 0.5,
      y = 180
    },
    {
      key = 11,
      timeDelay = 0.2,
      y = 320
    },
    {
      key = 3,
      timeDelay = 0.4,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.6,
      y = 260
    },
    {
      key = 9,
      timeDelay = 0,
      y = 230
    },
    {
      key = 3,
      timeDelay = 0.4,
      y = 180
    },
    {
      key = 9,
      timeDelay = 0.6,
      y = 320
    },
    {
      key = 13,
      timeDelay = 0.8,
      y = 300
    },
    {
      key = 15,
      timeDelay = 1,
      y = 260
    },
    {
      key = 7,
      timeDelay = 0.2,
      y = 220
    },
    {
      key = 9,
      timeDelay = 0.4,
      y = 180
    },
    {
      key = 11,
      timeDelay = 0,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 8,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 180
    },
    {
      key = 9,
      timeDelay = 0.6,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.2,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.3,
      y = 260
    },
    {
      key = 4,
      timeDelay = 0,
      y = 230
    },
    {
      key = 12,
      timeDelay = 0.2,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 4,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 12,
      timeDelay = 0.2,
      y = 180
    },
    {
      key = 11,
      timeDelay = 0,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 10,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 13,
      timeDelay = 0.6,
      y = 300
    },
    {
      key = 14,
      timeDelay = 1,
      y = 260
    },
    {
      key = 6,
      timeDelay = 0.4,
      y = 220
    },
    {
      key = 8,
      timeDelay = 0.2,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.4,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.2,
      y = 260
    },
    {
      key = 4,
      timeDelay = 0.6,
      y = 230
    },
    {
      key = 4,
      timeDelay = 0.4,
      y = 180
    },
    {
      key = 9,
      timeDelay = 0,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.4,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.2,
      y = 260
    },
    {
      key = 11,
      timeDelay = 0.5,
      y = 230
    },
    {
      key = 4,
      timeDelay = 0.4,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 4,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 12,
      timeDelay = 0.5,
      y = 180
    },
    {
      key = 11,
      timeDelay = 0.1,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.2,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.3,
      y = 260
    },
    {
      key = 10,
      timeDelay = 0,
      y = 230
    },
    {
      key = 4,
      timeDelay = 0.2,
      y = 180
    },
    {
      key = 10,
      timeDelay = 0.5,
      y = 320
    },
    {
      key = 13,
      timeDelay = 0.6,
      y = 300
    },
    {
      key = 15,
      timeDelay = 0.8,
      y = 260
    },
    {
      key = 6,
      timeDelay = 0,
      y = 220
    },
    {
      key = 8,
      timeDelay = 0.3,
      y = 180
    },
    {
      key = 10,
      timeDelay = 0.3,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 4,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 11,
      timeDelay = 0,
      y = 180
    },
    {
      key = 9,
      timeDelay = 0.6,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.1,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.2,
      y = 260
    },
    {
      key = 12,
      timeDelay = 0,
      y = 230
    },
    {
      key = 4,
      timeDelay = 0.1,
      y = 180
    },
    {
      key = 8,
      timeDelay = 0,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 4,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 12,
      timeDelay = 0.2,
      y = 180
    },
    {
      key = 12,
      timeDelay = 0,
      y = 320
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 290
    },
    {
      key = 5,
      timeDelay = 0.4,
      y = 260
    },
    {
      key = 10,
      timeDelay = 0.2,
      y = 230
    },
    {
      key = 4,
      timeDelay = 0.3,
      y = 180
    },
    {
      key = 10,
      timeDelay = 0,
      y = 320
    },
    {
      key = 13,
      timeDelay = 0.6,
      y = 300
    },
    {
      key = 14,
      timeDelay = 0,
      y = 260
    },
    {
      key = 7,
      timeDelay = 1,
      y = 220
    },
    {
      key = 10,
      timeDelay = 0,
      y = 180
    }
  },
  roundTimeLimit = {
    [1] = {min = 4, max = 7},
    [2] = {min = 3, max = 6},
    [3] = {min = 3, max = 4}
  },
  boomDemage = {
    [1] = {radius = 50, demage = 160},
    [2] = {radius = 145, demage = 100}
  },
  boomStartPos = {
    [1] = cc.p(110, 198),
    [2] = cc.p(78, 216)
  }
}
