return {
  {
    class_id = 10027,
    x = 49,
    y = 27,
    dir = 0,
    cx = -10,
    cy = -8
  },
  {
    class_id = 10150,
    x = 34,
    y = 26,
    dir = 1,
    cx = -4,
    cy = 11
  },
  {
    class_id = 10041,
    x = 74,
    y = 58,
    dir = 0,
    cx = -9,
    cy = 0
  },
  {
    class_id = 10041,
    x = 66,
    y = 53,
    dir = 0,
    cx = -7,
    cy = -6
  },
  {
    class_id = 10028,
    x = 106,
    y = 41,
    dir = 1,
    cx = 0,
    cy = -8
  },
  {
    class_id = 10136,
    x = 106,
    y = 34,
    dir = 1,
    cx = -10,
    cy = -11
  },
  {
    class_id = 10137,
    x = 91,
    y = 35,
    dir = 0,
    cx = -5,
    cy = -4
  },
  {
    class_id = 10030,
    x = 114,
    y = 39,
    dir = 0,
    cx = -9,
    cy = 0
  },
  {
    class_id = 10011,
    x = 99,
    y = 39,
    dir = 0,
    cx = 6,
    cy = -3
  },
  {
    class_id = 10020,
    x = 66,
    y = 38,
    dir = 0,
    cx = 5,
    cy = 8
  },
  {
    class_id = 10020,
    x = 60,
    y = 34,
    dir = 0,
    cx = -12,
    cy = -10
  },
  {
    class_id = 10020,
    x = 60,
    y = 45,
    dir = 0,
    cx = -8,
    cy = -1
  },
  {
    class_id = 10020,
    x = 53,
    y = 42,
    dir = 0,
    cx = -10,
    cy = 10
  },
  {
    class_id = 10140,
    x = 57,
    y = 17,
    dir = 0,
    cx = 11,
    cy = -4
  },
  {
    class_id = 10141,
    x = 81,
    y = 48,
    dir = 0,
    cx = 6,
    cy = 1
  },
  {
    class_id = 10020,
    x = 67,
    y = 30,
    dir = 0,
    cx = -4,
    cy = 3
  },
  {
    class_id = 10020,
    x = 75,
    y = 34,
    dir = 0,
    cx = 9,
    cy = 5
  },
  {wall_index = 2},
  {floor_index = 2}
}
