return {
  [31001] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10001,
    shadow_icon = 32001
  },
  [31003] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10001,
    shadow_icon = 32001
  },
  [31006] = {
    show_char_shadow = true,
    have_top_layer = false,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    },
    shadow_icon = 32002
  },
  [31007] = {
    show_char_shadow = true,
    have_top_layer = false,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    },
    shadow_icon = 32002
  },
  [31010] = {
    show_char_shadow = true,
    have_top_layer = false,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    },
    shadow_icon = 32002
  },
  [31011] = {
    show_char_shadow = false,
    have_top_layer = false,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    },
    shelter_offset2 = {x = 2, y = 0},
    shelter_offset6 = {x = 2, y = 0},
    shadow_icon = 32003
  },
  [31013] = {
    show_char_shadow = false,
    have_top_layer = false,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    },
    shelter_offset2 = {x = 2, y = 0},
    shelter_offset6 = {x = 2, y = 0},
    shadow_icon = 32003
  },
  [31019] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10002,
    stand_swing0 = {
      x = -1,
      y = -1,
      percent = 50
    },
    stand_swing1 = {
      x = -1,
      y = -1,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 1,
      percent = 50
    },
    stand_swing3 = {
      x = 1,
      y = 0,
      percent = 50
    },
    stand_swing4 = {
      x = 1,
      y = -1,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = -1,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = -1,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = -1,
      percent = 50
    },
    shadow_icon = 32004
  },
  [31020] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10002,
    stand_swing0 = {
      x = -1,
      y = -1,
      percent = 50
    },
    stand_swing1 = {
      x = -1,
      y = -1,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 1,
      percent = 50
    },
    stand_swing3 = {
      x = 1,
      y = 0,
      percent = 50
    },
    stand_swing4 = {
      x = 1,
      y = -1,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = -1,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = -1,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = -1,
      percent = 50
    },
    shadow_icon = 32004
  },
  [31021] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10003,
    shelter_offset2 = {x = 1, y = 0},
    shelter_offset6 = {x = 1, y = 0},
    shadow_icon = 32005
  },
  [31023] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10003,
    shelter_offset2 = {x = 1, y = 0},
    shelter_offset6 = {x = 1, y = 0},
    shadow_icon = 32005
  },
  [31025] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10003,
    shelter_offset2 = {x = 1, y = 0},
    shelter_offset6 = {x = 1, y = 0},
    shadow_icon = 32005
  },
  [31538] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10003,
    shelter_offset2 = {x = 1, y = 0},
    shelter_offset6 = {x = 1, y = 0},
    shadow_icon = 32005
  },
  [31501] = {
    show_char_shadow = false,
    have_top_layer = true,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    }
  },
  [31026] = {
    show_char_shadow = false,
    have_top_layer = true,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    },
    shadow_icon = 32006
  },
  [31027] = {
    show_char_shadow = false,
    have_top_layer = true,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    },
    shadow_icon = 32006
  },
  [31028] = {
    show_char_shadow = false,
    have_top_layer = true,
    stand_swing0 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing1 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing2 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing3 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing4 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing5 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing6 = {
      x = 0,
      y = 8,
      percent = 50
    },
    stand_swing7 = {
      x = 0,
      y = 8,
      percent = 50
    },
    shadow_icon = 32006
  },
  [31029] = {
    show_char_shadow = false,
    have_top_layer = true,
    walk_icon = 10004,
    shelter_offset2 = {x = 1, y = 0},
    shelter_offset6 = {x = 1, y = 0},
    shadow_icon = 32007
  }
}
