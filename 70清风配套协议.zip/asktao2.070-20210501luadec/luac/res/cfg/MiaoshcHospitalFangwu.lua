return {
  {
    class_id = 10043,
    x = 61,
    y = 34,
    dir = 0,
    cx = 10,
    cy = 8
  },
  {
    class_id = 10131,
    x = 69,
    y = 26,
    dir = 1,
    cx = 7,
    cy = 3
  },
  {
    class_id = 10043,
    x = 42,
    y = 16,
    dir = 0,
    cx = 4,
    cy = 4
  },
  {
    class_id = 10043,
    x = 24,
    y = 25,
    dir = 0,
    cx = -12,
    cy = 9
  },
  {
    class_id = 10066,
    x = 33,
    y = 19,
    dir = 0,
    cx = -7,
    cy = 8
  },
  {
    class_id = 10107,
    x = 35,
    y = 33,
    dir = 0,
    cx = -6,
    cy = 4
  },
  {
    class_id = 10095,
    x = 73,
    y = 21,
    dir = 1,
    cx = -8,
    cy = -2
  },
  {
    class_id = 10055,
    x = 49,
    y = 40,
    dir = 0,
    cx = -10,
    cy = 10
  },
  {
    class_id = 10052,
    x = 46,
    y = 38,
    dir = 15,
    cx = 8,
    cy = -2
  }
}
