return {
  [1] = {
    ["位列仙班·年卡"] = {
      rewardStr = "#I会员|位列仙班·年卡$Time=360#I",
      count = 1,
      value = 36000,
      sortIndex = 1
    },
    ["高级托管·年卡"] = {
      rewardStr = "#I高级托管|高级托管#r31104000#I",
      count = 1,
      value = 21600,
      sortIndex = 2
    },
    ["棋心魂永久时装"] = {
      rewardStr = {
        "#I时装|极道棋魂$Time=-2%bind#I",
        "#I时装|仙道棋心$Time=-2%bind#I"
      },
      count = 1,
      value = 26888,
      sortIndex = 3,
      items = {
        "极道棋魂",
        "仙道棋心"
      }
    },
    ["代言人永久时装"] = {
      rewardStr = {
        "#I时装|望月白$Time=-1%bind#I",
        "#I时装|霜夜雪$Time=-1%bind#I"
      },
      count = 1,
      value = 26888,
      sortIndex = 4,
      items = {"望月白", "霜夜雪"}
    },
    ["锦鲤时装礼盒·30天"] = {
      rewardStr = "#I物品|锦鲤时装礼盒$AttriTime=30%bind%deadline=69120000#I",
      sortIndex = 5,
      count = 5,
      value = 14440
    },
    ["锦鲤时装礼盒·90天"] = {
      rewardStr = "#I物品|锦鲤时装礼盒$AttriTime=90%bind%deadline=69120000#I",
      sortIndex = 6,
      count = 5,
      value = 34440
    },
    ["永久跟宠太小极"] = {
      rewardStr = "#I物品|太小极$AttriTime=-1%bind#I",
      count = 1,
      value = 28888,
      sortIndex = 7
    },
    ["永久队标吉祥结"] = {
      rewardStr = "#I物品|吉祥结$AttriTime=-1%bind#I",
      count = 1,
      value = 3000,
      sortIndex = 8
    },
    ["永久特效风花雪月"] = {
      rewardStr = "#I物品|风花雪月$AttriTime=-1%bind#I",
      count = 1,
      value = 10888,
      sortIndex = 9
    },
    ["超级晶石"] = {
      rewardStr = "#I物品|超级晶石%bind#I",
      count = 388,
      value = 41904,
      sortIndex = 10
    },
    ["超级灵石"] = {
      rewardStr = "#I物品|超级灵石%bind#I",
      count = 188,
      value = 74824,
      sortIndex = 11
    },
    ["超级仙风散"] = {
      rewardStr = "#I物品|超级仙风散%bind#I",
      count = 188,
      value = 20304,
      sortIndex = 12
    },
    ["宠风散"] = {
      rewardStr = "#I物品|宠风散%bind#I",
      count = 88,
      value = 19008,
      sortIndex = 13
    },
    ["点化丹"] = {
      rewardStr = "#I物品|点化丹%bind#I",
      count = 66,
      value = 21648,
      sortIndex = 14
    },
    ["羽化丹"] = {
      rewardStr = "#I物品|羽化丹%bind#I",
      count = 66,
      value = 34188,
      sortIndex = 15
    },
    ["宠物强化丹"] = {
      rewardStr = "#I物品|宠物强化丹%bind#I",
      count = 166,
      value = 35856,
      sortIndex = 16
    },
    ["宠物顿悟丹"] = {
      rewardStr = "#I物品|宠物顿悟丹%bind#I",
      count = 88,
      value = 28864,
      sortIndex = 17
    },
    ["高级驯兽诀"] = {
      rewardStr = "#I物品|高级驯兽诀%bind#I",
      count = 18,
      value = 14400,
      sortIndex = 18
    },
    ["超级神兽丹"] = {
      rewardStr = "#I物品|超级神兽丹%bind#I",
      count = 66,
      value = 7128,
      sortIndex = 19
    },
    ["紫气鸿蒙"] = {
      rewardStr = "#I物品|紫气鸿蒙%bind#I",
      count = 66,
      value = 27588,
      sortIndex = 20
    },
    ["急急如律令"] = {
      rewardStr = "#I物品|急急如律令%bind#I",
      count = 88,
      value = 28864,
      sortIndex = 21
    },
    ["超级归元露"] = {
      rewardStr = "#I物品|超级归元露%bind#I",
      count = 66,
      value = 14256,
      sortIndex = 22
    },
    ["天书"] = {
      rewardStr = "#I物品|天书%bind#I",
      count = 8,
      value = 2544,
      sortIndex = 23
    },
    ["中级血玲珑"] = {
      rewardStr = "#I物品|中级血玲珑%bind#I",
      count = 2,
      value = 836,
      sortIndex = 24
    },
    ["中级法玲珑"] = {
      rewardStr = "#I物品|中级法玲珑%bind#I",
      count = 2,
      value = 2800,
      sortIndex = 25
    },
    ["精怪诱饵"] = {
      rewardStr = "#I物品|精怪诱饵%bind#I",
      count = 20,
      value = 20000,
      sortIndex = 26
    },
    ["风灵丸"] = {
      rewardStr = "#I物品|风灵丸%bind#I",
      count = 10,
      value = 3280,
      sortIndex = 27
    },
    ["灵物囊"] = {
      rewardStr = "#I物品|灵物囊%bind#I",
      count = 5,
      value = 1990,
      sortIndex = 28
    },
    ["超级黑水晶"] = {
      rewardStr = "#I物品|超级黑水晶%bind#I",
      count = 30,
      value = 9840,
      sortIndex = 29
    },
    ["装备共鸣石"] = {
      rewardStr = "#I物品|装备共鸣石%bind#I",
      count = 188,
      value = 61664,
      sortIndex = 30
    },
    ["黄水晶"] = {
      rewardStr = "#I物品|黄水晶%bind#I",
      count = 188,
      value = 78584,
      sortIndex = 31
    },
    ["超级粉水晶"] = {
      rewardStr = "#I物品|超级粉水晶%bind#I",
      count = 36,
      value = 100800,
      sortIndex = 32
    },
    ["超级绿水晶"] = {
      rewardStr = "#I物品|超级绿水晶%bind#I",
      count = 36,
      value = 36000,
      sortIndex = 33
    },
    ["永久锦鲤称号"] = {
      rewardStr = "#I称谓|称谓#r中洲锦鲤·福运天成#I",
      count = 1,
      value = 0,
      sortIndex = 34
    }
  },
  [2] = {
    ["位列仙班·年卡"] = {
      rewardStr = "#I会员|位列仙班·年卡$Time=360#I",
      count = 1,
      value = 36000,
      sortIndex = 1
    },
    ["高级托管·年卡"] = {
      rewardStr = "#I高级托管|高级托管#r31104000#I",
      count = 1,
      value = 21600,
      sortIndex = 2
    },
    ["代言人永久时装"] = {
      rewardStr = {
        "#I时装|望月白$Time=-1%bind#I",
        "#I时装|霜夜雪$Time=-1%bind#I"
      },
      count = 1,
      value = 26888,
      sortIndex = 3,
      items = {"望月白", "霜夜雪"}
    },
    ["锦鲤时装礼盒·90天"] = {
      rewardStr = "#I物品|锦鲤时装礼盒$AttriTime=90%bind%deadline=69120000#I",
      count = 1,
      sortIndex = 4,
      value = 6888
    },
    ["永久跟宠太小极"] = {
      rewardStr = "#I物品|太小极$AttriTime=-1%bind#I",
      count = 1,
      value = 28888,
      sortIndex = 5
    },
    ["超级晶石"] = {
      rewardStr = "#I物品|超级晶石%bind#I",
      count = 88,
      value = 9504,
      sortIndex = 6
    },
    ["超级灵石"] = {
      rewardStr = "#I物品|超级灵石%bind#I",
      count = 36,
      value = 14328,
      sortIndex = 7
    },
    ["超级仙风散"] = {
      rewardStr = "#I物品|超级仙风散%bind#I",
      count = 36,
      value = 3888,
      sortIndex = 8
    },
    ["宠风散"] = {
      rewardStr = "#I物品|宠风散%bind#I",
      count = 36,
      value = 7776,
      sortIndex = 9
    },
    ["点化丹"] = {
      rewardStr = "#I物品|点化丹%bind#I",
      count = 18,
      value = 5904,
      sortIndex = 10
    },
    ["羽化丹"] = {
      rewardStr = "#I物品|羽化丹%bind#I",
      count = 18,
      value = 9324,
      sortIndex = 11
    },
    ["宠物强化丹"] = {
      rewardStr = "#I物品|宠物强化丹%bind#I",
      count = 36,
      value = 7776,
      sortIndex = 12
    },
    ["宠物顿悟丹"] = {
      rewardStr = "#I物品|宠物顿悟丹%bind#I",
      count = 18,
      value = 5904,
      sortIndex = 13
    },
    ["高级驯兽诀"] = {
      rewardStr = "#I物品|高级驯兽诀%bind#I",
      count = 8,
      value = 6400,
      sortIndex = 14
    },
    ["超级神兽丹"] = {
      rewardStr = "#I物品|超级神兽丹%bind#I",
      count = 16,
      value = 1728,
      sortIndex = 15
    },
    ["紫气鸿蒙"] = {
      rewardStr = "#I物品|紫气鸿蒙%bind#I",
      count = 18,
      value = 7524,
      sortIndex = 16
    },
    ["急急如律令"] = {
      rewardStr = "#I物品|急急如律令%bind#I",
      count = 18,
      value = 5904,
      sortIndex = 17
    },
    ["超级归元露"] = {
      rewardStr = "#I物品|超级归元露%bind#I",
      count = 18,
      value = 3888,
      sortIndex = 18
    },
    ["天书"] = {
      rewardStr = "#I物品|天书%bind#I",
      count = 6,
      value = 1908,
      sortIndex = 19
    },
    ["中级血玲珑"] = {
      rewardStr = "#I物品|中级血玲珑%bind#I",
      count = 1,
      value = 418,
      sortIndex = 20
    },
    ["中级法玲珑"] = {
      rewardStr = "#I物品|中级法玲珑%bind#I",
      count = 1,
      value = 1400,
      sortIndex = 21
    },
    ["精怪诱饵"] = {
      rewardStr = "#I物品|精怪诱饵%bind#I",
      count = 10,
      value = 10000,
      sortIndex = 22
    },
    ["风灵丸"] = {
      rewardStr = "#I物品|风灵丸%bind#I",
      count = 8,
      value = 2624,
      sortIndex = 23
    },
    ["灵物囊"] = {
      rewardStr = "#I物品|灵物囊%bind#I",
      count = 8,
      value = 3184,
      sortIndex = 24
    },
    ["超级黑水晶"] = {
      rewardStr = "#I物品|超级黑水晶%bind#I",
      count = 8,
      value = 2624,
      sortIndex = 25
    },
    ["装备共鸣石"] = {
      rewardStr = "#I物品|装备共鸣石%bind#I",
      count = 36,
      value = 11808,
      sortIndex = 26
    },
    ["黄水晶"] = {
      rewardStr = "#I物品|黄水晶%bind#I",
      count = 36,
      value = 15048,
      sortIndex = 27
    },
    ["超级粉水晶"] = {
      rewardStr = "#I物品|超级粉水晶%bind#I",
      count = 8,
      value = 22400,
      sortIndex = 28
    },
    ["超级绿水晶"] = {
      rewardStr = "#I物品|超级绿水晶%bind#I",
      count = 8,
      value = 8000,
      sortIndex = 29
    },
    ["永久锦鲤称号"] = {
      rewardStr = "#I称谓|称谓#r中洲锦鲤·福运天成#I",
      count = 1,
      value = 0,
      sortIndex = 30
    }
  }
}
