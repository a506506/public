return {
  {
    class_id = 10092,
    x = 43,
    y = 35,
    dir = 0,
    cx = 0,
    cy = -2
  },
  {
    class_id = 10106,
    x = 44,
    y = 43,
    dir = 1,
    cx = 11,
    cy = 10
  },
  {
    class_id = 10083,
    x = 17,
    y = 25,
    dir = 0,
    cx = -2,
    cy = 7
  },
  {
    class_id = 10129,
    x = 19,
    y = 28,
    dir = 0,
    cx = 8,
    cy = 12
  },
  {
    class_id = 10062,
    x = 58,
    y = 33,
    dir = 0,
    cx = 11,
    cy = -8
  },
  {
    class_id = 10052,
    x = 55,
    y = 30,
    dir = 15,
    cx = -12,
    cy = -9
  },
  {
    class_id = 10052,
    x = 61,
    y = 35,
    dir = 11,
    cx = 6,
    cy = 1
  },
  {
    class_id = 10131,
    x = 71,
    y = 27,
    dir = 1,
    cx = -6,
    cy = -6
  },
  {
    class_id = 10044,
    x = 41,
    y = 14,
    dir = 0,
    cx = -7,
    cy = 0
  },
  {
    class_id = 10095,
    x = 38,
    y = 10,
    dir = 0,
    cx = 8,
    cy = 2
  },
  {
    class_id = 10095,
    x = 27,
    y = 16,
    dir = 0,
    cx = -8,
    cy = 9
  },
  {
    class_id = 10095,
    x = 14,
    y = 22,
    dir = 0,
    cx = 11,
    cy = 3
  },
  {
    class_id = 10095,
    x = 49,
    y = 10,
    dir = 1,
    cx = -3,
    cy = 6
  },
  {
    class_id = 10095,
    x = 73,
    y = 22,
    dir = 1,
    cx = -5,
    cy = 3
  },
  {
    class_id = 10046,
    x = 50,
    y = 15,
    dir = 1,
    cx = 10,
    cy = 3
  },
  {
    class_id = 10066,
    x = 32,
    y = 20,
    dir = 1,
    cx = -12,
    cy = 9
  },
  {
    class_id = 10066,
    x = 52,
    y = 19,
    dir = 0,
    cx = -8,
    cy = 8
  },
  {
    class_id = 10066,
    x = 44,
    y = 23,
    dir = 0,
    cx = -3,
    cy = 6
  },
  {
    class_id = 10133,
    x = 39,
    y = 38,
    dir = 0,
    cx = -9,
    cy = 0
  }
}
