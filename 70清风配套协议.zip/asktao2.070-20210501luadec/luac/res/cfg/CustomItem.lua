return {
  ["云容丝·灰"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["云容丝·褐"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["云容丝·红"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["云容丝·紫"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["云容丝·蓝"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["云容丝·绿"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["烟笼丝·褐"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["烟笼丝·红"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["烟笼丝·紫"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["烟笼丝·蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["烟笼丝·天蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["烟笼丝·绿"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["青梅丝·灰"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 1
  },
  ["青梅丝·紫"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 2
  },
  ["青梅丝·红"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 3
  },
  ["青梅丝·绿"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 4
  },
  ["青梅丝·蓝"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 5
  },
  ["青梅丝·黑"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 6
  },
  ["相思丝·白"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 1
  },
  ["相思丝·黄"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 2
  },
  ["相思丝·红"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 3
  },
  ["相思丝·粉"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 4
  },
  ["相思丝·蓝"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 5
  },
  ["相思丝·黑"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 6
  },
  ["戏蝶丝·白"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 1
  },
  ["戏蝶丝·褐"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 2
  },
  ["戏蝶丝·红"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 3
  },
  ["戏蝶丝·蓝"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 4
  },
  ["戏蝶丝·紫"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 5
  },
  ["戏蝶丝·黑"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 6
  },
  ["倾舞丝·白"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 1
  },
  ["倾舞丝·褐"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 2
  },
  ["倾舞丝·红"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 3
  },
  ["倾舞丝·蓝"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 4
  },
  ["倾舞丝·紫"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 5
  },
  ["倾舞丝·黑"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 6
  },
  ["云容衣·白"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["云容衣·黄"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["云容衣·红"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["云容衣·紫"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["云容衣·天蓝"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["云容衣·绿"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["烟笼衣·白"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["烟笼衣·红"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["烟笼衣·粉"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["烟笼衣·蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["烟笼衣·天蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["烟笼衣·绿"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["青梅衣·白"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 1
  },
  ["青梅衣·粉"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 2
  },
  ["青梅衣·红"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 3
  },
  ["青梅衣·绿"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 4
  },
  ["青梅衣·蓝"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 5
  },
  ["青梅衣·黑"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 6
  },
  ["相思衣·白"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 1
  },
  ["相思衣·黄"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 2
  },
  ["相思衣·红"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 3
  },
  ["相思衣·粉"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 4
  },
  ["相思衣·蓝"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 5
  },
  ["相思衣·黑"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 6
  },
  ["戏蝶衣·白"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 1
  },
  ["戏蝶衣·黄"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 2
  },
  ["戏蝶衣·红"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 3
  },
  ["戏蝶衣·蓝"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 4
  },
  ["戏蝶衣·粉"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 5
  },
  ["戏蝶衣·黑"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 6
  },
  ["倾舞衣·白"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 1
  },
  ["倾舞衣·黄"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 2
  },
  ["倾舞衣·红"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 3
  },
  ["倾舞衣·蓝"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 4
  },
  ["倾舞衣·粉"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 5
  },
  ["倾舞衣·黑"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 6
  },
  ["云容裳·白"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["云容裳·黄"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["云容裳·红"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["云容裳·紫"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["云容裳·天蓝"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["云容裳·绿"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["烟笼裳·白"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["烟笼裳·红"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["烟笼裳·粉"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["烟笼裳·蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["烟笼裳·天蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["烟笼裳·绿"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["青梅裳·白"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 1
  },
  ["青梅裳·粉"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 2
  },
  ["青梅裳·红"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 3
  },
  ["青梅裳·绿"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 4
  },
  ["青梅裳·蓝"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 5
  },
  ["青梅裳·黑"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 6
  },
  ["相思裳·白"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 1
  },
  ["相思裳·黄"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 2
  },
  ["相思裳·红"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 3
  },
  ["相思裳·粉"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 4
  },
  ["相思裳·蓝"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 5
  },
  ["相思裳·黑"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 6
  },
  ["戏蝶裳·白"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 1
  },
  ["戏蝶裳·黄"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 2
  },
  ["戏蝶裳·红"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 3
  },
  ["戏蝶裳·蓝"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 4
  },
  ["戏蝶裳·粉"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 5
  },
  ["戏蝶裳·黑"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 6
  },
  ["倾舞裳·白"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 1
  },
  ["倾舞裳·黄"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 2
  },
  ["倾舞裳·红"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 3
  },
  ["倾舞裳·蓝"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 4
  },
  ["倾舞裳·粉"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 5
  },
  ["倾舞裳·黑"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 6
  },
  ["赤风剑·深蓝"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["赤风剑·黄"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["赤风剑·红"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["赤风剑·紫"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["赤风剑·白"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["赤风剑·绿"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["鱼泉杖·黄"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["鱼泉杖·红"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["鱼泉杖·粉"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["鱼泉杖·蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["鱼泉杖·天蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["鱼泉杖·绿"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["溅花刃·黄"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 1
  },
  ["溅花刃·紫"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 2
  },
  ["溅花刃·红"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 3
  },
  ["溅花刃·天蓝"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 4
  },
  ["溅花刃·黑"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 5
  },
  ["溅花刃·银"] = {
    fasion_role = 60001,
    fasion_part = 3,
    fasion_dye = 6
  },
  ["轻罗扇·白"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 1
  },
  ["轻罗扇·黄"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 2
  },
  ["轻罗扇·红"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 3
  },
  ["轻罗扇·粉"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 4
  },
  ["轻罗扇·蓝"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 5
  },
  ["轻罗扇·紫"] = {
    fasion_role = 60001,
    fasion_part = 4,
    fasion_dye = 6
  },
  ["花语环·白"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 1
  },
  ["花语环·黄"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 2
  },
  ["花语环·红"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 3
  },
  ["花语环·蓝"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 4
  },
  ["花语环·粉"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 5
  },
  ["花语环·黑"] = {
    fasion_role = 60001,
    fasion_part = 5,
    fasion_dye = 6
  },
  ["鸾凤杵·白"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 1
  },
  ["鸾凤杵·黄"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 2
  },
  ["鸾凤杵·红"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 3
  },
  ["鸾凤杵·蓝"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 4
  },
  ["鸾凤杵·粉"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 5
  },
  ["鸾凤杵·黑"] = {
    fasion_role = 60001,
    fasion_part = 6,
    fasion_dye = 6
  },
  ["莹雪翅·白"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["莹雪翅·黄"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["莹雪翅·红"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["莹雪翅·绿"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["莹雪翅·粉"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["莹雪翅·黑"] = {
    fasion_role = 60001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["琼华引·白"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["琼华引·黄"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["琼华引·红"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["琼华引·蓝"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["琼华引·粉"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["琼华引·绿"] = {
    fasion_role = 60001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["侠客冠·褐"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["侠客冠·红"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["侠客冠·紫"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["侠客冠·蓝"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["侠客冠·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["侠客冠·绿"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["凌云冠·灰"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["凌云冠·绿"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["凌云冠·紫"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["凌云冠·蓝"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["凌云冠·墨绿"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["凌云冠·黑"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["飞影冠·蓝"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 1
  },
  ["飞影冠·白"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 2
  },
  ["飞影冠·灰"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 3
  },
  ["飞影冠·红"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 4
  },
  ["飞影冠·绿"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 5
  },
  ["飞影冠·黄"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 6
  },
  ["踏歌冠·白"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 1
  },
  ["踏歌冠·红"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 2
  },
  ["踏歌冠·紫"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 3
  },
  ["踏歌冠·蓝"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 4
  },
  ["踏歌冠·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 5
  },
  ["踏歌冠·黑"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 6
  },
  ["龙骧冠·白"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 1
  },
  ["龙骧冠·红"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 2
  },
  ["龙骧冠·紫"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 3
  },
  ["龙骧冠·蓝"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 4
  },
  ["龙骧冠·黄"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 5
  },
  ["龙骧冠·黑"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 6
  },
  ["飞星冠·白"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 1
  },
  ["飞星冠·红"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 2
  },
  ["飞星冠·紫"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 3
  },
  ["飞星冠·蓝"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 4
  },
  ["飞星冠·褐"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 5
  },
  ["飞星冠·黑"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 6
  },
  ["了无尘"] = {
    fasion_role = 61001,
    fasion_part = 7,
    fasion_dye = 1
  },
  ["侠客衫·黄"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["侠客衫·红"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["侠客衫·紫"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["侠客衫·蓝"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["侠客衫·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["侠客衫·绿"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["凌云衫·灰"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["凌云衫·绿"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["凌云衫·紫"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["凌云衫·蓝"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["凌云衫·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["凌云衫·黑"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["飞影衫·蓝"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 1
  },
  ["飞影衫·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 2
  },
  ["飞影衫·紫"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 3
  },
  ["飞影衫·红"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 4
  },
  ["飞影衫·绿"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 5
  },
  ["飞影衫·黄"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 6
  },
  ["踏歌衫·黄"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 1
  },
  ["踏歌衫·红"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 2
  },
  ["踏歌衫·紫"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 3
  },
  ["踏歌衫·蓝"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 4
  },
  ["踏歌衫·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 5
  },
  ["踏歌衫·灰"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 6
  },
  ["龙骧衫·白"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 1
  },
  ["龙骧衫·红"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 2
  },
  ["龙骧衫·紫"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 3
  },
  ["龙骧衫·蓝"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 4
  },
  ["龙骧衫·黄"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 5
  },
  ["龙骧衫·黑"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 6
  },
  ["飞星衫·白"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 1
  },
  ["飞星衫·红"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 2
  },
  ["飞星衫·紫"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 3
  },
  ["飞星衫·蓝"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 4
  },
  ["飞星衫·黄"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 5
  },
  ["飞星衫·黑"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 6
  },
  ["侠客袴·黄"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["侠客袴·红"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["侠客袴·紫"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["侠客袴·蓝"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["侠客袴·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["侠客袴·绿"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["凌云袴·灰"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["凌云袴·绿"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["凌云袴·紫"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["凌云袴·蓝"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["凌云袴·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["凌云袴·黑"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["飞影袴·蓝"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 1
  },
  ["飞影袴·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 2
  },
  ["飞影袴·紫"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 3
  },
  ["飞影袴·红"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 4
  },
  ["飞影袴·绿"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 5
  },
  ["飞影袴·黄"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 6
  },
  ["踏歌袴·黄"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 1
  },
  ["踏歌袴·红"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 2
  },
  ["踏歌袴·紫"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 3
  },
  ["踏歌袴·蓝"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 4
  },
  ["踏歌袴·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 5
  },
  ["踏歌袴·灰"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 6
  },
  ["龙骧袴·白"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 1
  },
  ["龙骧袴·红"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 2
  },
  ["龙骧袴·紫"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 3
  },
  ["龙骧袴·蓝"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 4
  },
  ["龙骧袴·黄"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 5
  },
  ["龙骧袴·黑"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 6
  },
  ["飞星袴·白"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 1
  },
  ["飞星袴·红"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 2
  },
  ["飞星袴·紫"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 3
  },
  ["飞星袴·蓝"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 4
  },
  ["飞星袴·黄"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 5
  },
  ["飞星袴·黑"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 6
  },
  ["囚龙剑·黄"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["囚龙剑·红"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["囚龙剑·紫"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["囚龙剑·深蓝"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["囚龙剑·白"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["囚龙剑·绿"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["断魄刀·黄"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["断魄刀·红"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["断魄刀·紫"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["断魄刀·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["断魄刀·绿"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["断魄刀·黑"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 6
  },
  ["分云棍·蓝"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 1
  },
  ["分云棍·天蓝"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 2
  },
  ["分云棍·紫"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 3
  },
  ["分云棍·红"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 4
  },
  ["分云棍·绿"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 5
  },
  ["分云棍·黑"] = {
    fasion_role = 61001,
    fasion_part = 3,
    fasion_dye = 6
  },
  ["天地远·黄"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 1
  },
  ["天地远·红"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 2
  },
  ["天地远·紫"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 3
  },
  ["天地远·蓝"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 4
  },
  ["天地远·白"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 5
  },
  ["天地远·黑"] = {
    fasion_role = 61001,
    fasion_part = 4,
    fasion_dye = 6
  },
  ["山河弑·白"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 1
  },
  ["山河弑·红"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 2
  },
  ["山河弑·紫"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 3
  },
  ["山河弑·蓝"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 4
  },
  ["山河弑·黄"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 5
  },
  ["山河弑·黑"] = {
    fasion_role = 61001,
    fasion_part = 5,
    fasion_dye = 6
  },
  ["半月剑·白"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 1
  },
  ["半月剑·红"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 2
  },
  ["半月剑·紫"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 3
  },
  ["半月剑·蓝"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 4
  },
  ["半月剑·黄"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 5
  },
  ["半月剑·黑"] = {
    fasion_role = 61001,
    fasion_part = 6,
    fasion_dye = 6
  },
  ["莹霜翅·白"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 1
  },
  ["莹霜翅·红"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 2
  },
  ["莹霜翅·紫"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 3
  },
  ["莹霜翅·绿"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 4
  },
  ["莹霜翅·黄"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 5
  },
  ["莹霜翅·黑"] = {
    fasion_role = 61001,
    fasion_part = 1,
    fasion_dye = 6
  },
  ["业火劫·白"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 1
  },
  ["业火劫·红"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 2
  },
  ["业火劫·紫"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 3
  },
  ["业火劫·蓝"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 4
  },
  ["业火劫·黄"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 5
  },
  ["业火劫·黑"] = {
    fasion_role = 61001,
    fasion_part = 2,
    fasion_dye = 6
  }
}
