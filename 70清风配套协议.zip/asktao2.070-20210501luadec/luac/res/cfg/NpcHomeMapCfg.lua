return {
  [28203] = "NpcHomeZhaoLaoBanQianTing.lua",
  [28204] = "NpcHomeZhaoLaoBanFangWu.lua",
  [28303] = "NpcHomeQianLaoBanQianTing.lua",
  [28304] = "NpcHomeQianLaoBanFangWu.lua",
  [28107] = "NpcHomeLeShanShiQianTing.lua",
  [28108] = "NpcHomeLeShanShiFangWu.lua"
}
