return {
  [CHS[3001021]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 50
  },
  [CHS[3001024]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 60
  },
  [CHS[3001025]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 70
  },
  [CHS[3001026]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 80
  },
  [CHS[4100187]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 90
  },
  [CHS[4100188]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 100
  },
  ["九转金刚刃"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 110
  },
  ["混元斩龙戟"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 120
  },
  ["赤眼神龙枪"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001023],
    level = 130
  },
  [CHS[3001027]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 50
  },
  [CHS[3001029]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 60
  },
  [CHS[3001030]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 70
  },
  [CHS[3001031]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 80
  },
  [CHS[4100189]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 90
  },
  [CHS[4100190]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 100
  },
  ["七巧玲珑爪"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 110
  },
  ["镇魂摄天刺"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 120
  },
  ["红绫火毒爪"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001028],
    level = 130
  },
  [CHS[3001032]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 50
  },
  [CHS[3001034]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 60
  },
  [CHS[3001035]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 70
  },
  [CHS[3001036]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 80
  },
  [CHS[4100191]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 90
  },
  [CHS[4100192]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 100
  },
  ["紫青玄魔剑"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 110
  },
  ["封神诛仙剑"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 120
  },
  ["九天玄冥剑"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001033],
    level = 130
  },
  [CHS[3001037]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 50
  },
  [CHS[3001039]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 60
  },
  [CHS[3001040]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 70
  },
  [CHS[3001041]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 80
  },
  [CHS[4100193]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 90
  },
  [CHS[4100194]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 100
  },
  ["离火七翎扇"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 110
  },
  ["赤霄烈焰扇"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 120
  },
  ["红云火霞扇"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001038],
    level = 130
  },
  [CHS[3001042]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 50
  },
  [CHS[3001044]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 60
  },
  [CHS[3001045]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 70
  },
  [CHS[3001046]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 80
  },
  [CHS[4100195]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 90
  },
  [CHS[4100196]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 100
  },
  ["炼狱麒麟杵"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 110
  },
  ["风雷如意杵"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 120
  },
  ["玄黄破坚锤"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001043],
    level = 130
  },
  [CHS[3001047]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 50
  },
  [CHS[3001049]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 60
  },
  [CHS[3001050]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 70
  },
  [CHS[3001051]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 80
  },
  [CHS[4100197]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 90
  },
  [CHS[4100198]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 100
  },
  ["星耀冠"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 110
  },
  ["七星宝冠"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 120
  },
  ["白玉星冠"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001048],
    level = 130
  },
  [CHS[3001052]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 50
  },
  [CHS[3001054]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 60
  },
  [CHS[3001055]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 70
  },
  [CHS[3001056]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 80
  },
  [CHS[4100199]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 90
  },
  [CHS[4100200]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 100
  },
  ["瀚宇法袍"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 110
  },
  ["诸天法袍"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 120
  },
  ["天玄真神甲"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001053],
    level = 130
  },
  [CHS[3001057]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 50
  },
  [CHS[3001059]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 60
  },
  [CHS[3001060]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 70
  },
  [CHS[3001061]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 80
  },
  [CHS[4100203]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 90
  },
  [CHS[4100204]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 100
  },
  ["凌波霞冠"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 110
  },
  ["天灵宝冠"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 120
  },
  ["九彩玲珠冠"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001058],
    level = 130
  },
  [CHS[3001062]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 50
  },
  [CHS[3001064]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 60
  },
  [CHS[3001065]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 70
  },
  [CHS[3001066]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 80
  },
  [CHS[4100201]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 90
  },
  [CHS[4100202]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 100
  },
  ["星晶法衣"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 110
  },
  ["神鸢凤裘"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 120
  },
  ["万霞霓罗裳"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001063],
    level = 130
  },
  [CHS[3001067]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 50
  },
  [CHS[3001069]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 60
  },
  [CHS[3001070]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 70
  },
  [CHS[3001071]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 80
  },
  [CHS[4100205]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 90
  },
  [CHS[4100206]] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 100
  },
  ["御风履"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 110
  },
  ["钧天履"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 120
  },
  ["雷弧闪"] = {
    subClass = CHS[3001022],
    secondClass = CHS[3001068],
    level = 130
  },
  [CHS[3001072]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001074],
    level = 80
  },
  [CHS[3001075]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001076],
    level = 80
  },
  [CHS[3001077]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001078],
    level = 80
  },
  [CHS[4100183]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001078],
    level = 90
  },
  [CHS[4100175]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001074],
    level = 90
  },
  [CHS[4100179]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001076],
    level = 90
  },
  [CHS[4100185]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001078],
    level = 100
  },
  [CHS[4100177]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001074],
    level = 100
  },
  [CHS[4100181]] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001076],
    level = 100
  },
  ["碎梦涵光"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001078],
    level = 110
  },
  ["寒玉龙勾"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001074],
    level = 110
  },
  ["流光绝影"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001076],
    level = 110
  },
  ["九天霜华"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001078],
    level = 120
  },
  ["八宝如意"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001074],
    level = 120
  },
  ["五蕴悯光"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001076],
    level = 120
  },
  ["岚金火链"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001078],
    level = 130
  },
  ["游火灵焰"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001074],
    level = 130
  },
  ["千彩流光"] = {
    subClass = CHS[3001073],
    secondClass = CHS[3001076],
    level = 130
  },
  [CHS[3001079]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001081]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001082]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001083]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001084]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001085]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001086]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001087]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001088]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001089]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001090]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001091]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001092]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001093]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001094]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001095]] = {
    subClass = CHS[3001080],
    level = 0
  },
  [CHS[3001096]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001098]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001099]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001100]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001101]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001102]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001103]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001104]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001105]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[6200048]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[7190126]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[7190658]] = {
    subClass = CHS[3001097],
    level = 0
  },
  [CHS[3001106]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[3001108]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[3001109]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[3001110]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[3001111]] = {
    subClass = CHS[3001107],
    secondClass = CHS[3001111],
    level = 0
  },
  ["高级宠物经验丹"] = {
    subClass = CHS[3001107],
    secondClass = CHS[3001111],
    level = 0
  },
  [CHS[3001112]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[7000210]] = {
    subClass = CHS[3001107],
    level = 0
  },
  ["召唤令·梅兰竹菊"] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[3001113]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[7190029]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[4000383]] = {
    subClass = CHS[3001107],
    level = 0
  },
  ["羽化丹"] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[6000505]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[6000507]] = {
    subClass = CHS[3001107],
    secondClass = CHS[6000506],
    level = 0
  },
  [CHS[6000508]] = {
    subClass = CHS[3001107],
    secondClass = CHS[6000506],
    level = 0
  },
  [CHS[6000509]] = {
    subClass = CHS[3001107],
    secondClass = CHS[6000506],
    level = 0
  },
  [CHS[6000510]] = {
    subClass = CHS[3001107],
    secondClass = CHS[6000506],
    level = 0
  },
  [CHS[6000511]] = {
    subClass = CHS[3001107],
    secondClass = CHS[6000506],
    level = 0
  },
  [CHS[6000512]] = {
    subClass = CHS[3001107],
    secondClass = CHS[6000506],
    level = 0
  },
  [CHS[6000522]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[2000128]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[2100020]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[2100023]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[2100026]] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[5400067]] = {
    subClass = CHS[3001107],
    secondClass = CHS[5400066],
    level = 0
  },
  ["元神碎片·白灵"] = {
    subClass = CHS[3001107],
    secondClass = "纪念宠元神",
    level = 0
  },
  ["元神碎片·迅影"] = {
    subClass = CHS[3001107],
    secondClass = "纪念宠元神",
    level = 0
  },
  ["元神碎片·餐风"] = {
    subClass = CHS[3001107],
    secondClass = "纪念宠元神",
    level = 0
  },
  ["元神碎片·饮露"] = {
    subClass = CHS[3001107],
    secondClass = "纪念宠元神",
    level = 0
  },
  ["元神碎片·回雪"] = {
    subClass = CHS[3001107],
    secondClass = "纪念宠元神",
    level = 0
  },
  ["元神碎片·流风"] = {
    subClass = CHS[3001107],
    secondClass = "纪念宠元神",
    level = 0
  },
  ["元神碎片·寒霄"] = {
    subClass = CHS[3001107],
    secondClass = "纪念宠元神",
    level = 0
  },
  ["元神碎片·武极"] = {
    subClass = CHS[3001107],
    secondClass = "纪念宠元神",
    level = 0
  },
  ["凝神草"] = {
    subClass = CHS[3001107],
    level = 0
  },
  ["鬼宠亲密丹"] = {
    subClass = CHS[3001107],
    level = 0
  },
  ["鬼卒灵魄"] = {
    subClass = CHS[3001107],
    level = 0
  },
  [CHS[3001114]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001115]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001116]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001117]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001118]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001119]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001120]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001121]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001122]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001123]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001124]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001125]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001126]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001127]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001128]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001129]] = {
    subClass = CHS[3001114],
    level = 0
  },
  [CHS[3001130]] = {
    subClass = CHS[3001131],
    level = "5,6,7,8,9,10,11,12,13",
    needLevelCheck = true
  },
  [CHS[3001132]] = {
    subClass = CHS[3001131],
    level = "5,6,7,8,9,10,11,12,13",
    needLevelCheck = true
  },
  [CHS[3001133]] = {
    subClass = CHS[3001131],
    level = "5,6,7,8,9,10,11,12,13",
    needLevelCheck = true
  },
  [CHS[3001134]] = {
    subClass = CHS[3001131],
    level = "5,6,7,8,9,10,11,12,13",
    needLevelCheck = true
  },
  [CHS[3001135]] = {
    subClass = CHS[3001131],
    level = "5,6,7,8,9,10,11,12,13",
    needLevelCheck = true
  },
  [CHS[3004454]] = {
    subClass = CHS[3001131],
    level = "5,6,7,8,9,10,11,12,13",
    needLevelCheck = true
  },
  [CHS[3001136]] = {
    subClass = CHS[3001137],
    secondClass = CHS[3001138],
    level = 0
  },
  [CHS[3001139]] = {
    subClass = CHS[3001137],
    secondClass = CHS[3001138],
    level = 0
  },
  [CHS[3001140]] = {
    subClass = CHS[3001137],
    secondClass = CHS[3001138],
    level = 0
  },
  [CHS[3001141]] = {
    subClass = CHS[3001137],
    secondClass = CHS[3001138],
    level = 0
  },
  [CHS[3001144]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[3001145]] = {
    subClass = CHS[3001137],
    secondClass = "各类藏宝图",
    level = 0
  },
  [CHS[8000000]] = {
    subClass = CHS[3001137],
    secondClass = "各类藏宝图",
    level = 0
  },
  ["特级藏宝图"] = {
    subClass = CHS[3001137],
    secondClass = "各类藏宝图",
    level = 0
  },
  [CHS[3001146]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[3001147]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[3001148]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[6000252]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[6200026]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[7000277]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[4100323]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[2000095]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[6000265]] = {
    subClass = CHS[3001137],
    secondClass = CHS[7000206],
    level = 0
  },
  [CHS[6000263]] = {
    subClass = CHS[3001137],
    secondClass = CHS[7000206],
    level = 0
  },
  [CHS[6000264]] = {
    subClass = CHS[3001137],
    secondClass = CHS[7000206],
    level = 0
  },
  [CHS[6000262]] = {
    subClass = CHS[3001137],
    secondClass = CHS[7000206],
    level = 0
  },
  [CHS[7000043]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[7000044]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[7000045]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[7000081]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[7000120]] = {
    subClass = CHS[3001137],
    level = 0
  },
  [CHS[7000121]] = {
    subClass = CHS[3001137],
    secondClass = CHS[7000207],
    level = 0
  },
  [CHS[7000122]] = {
    subClass = CHS[3001137],
    secondClass = CHS[7000207],
    level = 0
  },
  [CHS[7000123]] = {
    subClass = CHS[3001137],
    secondClass = CHS[7000207],
    level = 0
  },
  [CHS[7000124]] = {
    subClass = CHS[3001137],
    secondClass = CHS[7000207],
    level = 0
  },
  [CHS[4100421]] = {
    subClass = CHS[3001137],
    secondClass = CHS[4100425],
    level = 0
  },
  [CHS[4100422]] = {
    subClass = CHS[3001137],
    secondClass = CHS[4100425],
    level = 0
  },
  [CHS[4100423]] = {
    subClass = CHS[3001137],
    secondClass = CHS[4100425],
    level = 0
  },
  [CHS[4100424]] = {
    subClass = CHS[3001137],
    secondClass = CHS[4100425],
    level = 0
  },
  ["冥海神光"] = {
    subClass = CHS[3001137],
    level = 0
  },
  ["竹马（蓝色）"] = {
    subClass = "娃娃玩具",
    secondClass = "竹马",
    level = "蓝色"
  },
  ["竹马（紫色）"] = {
    subClass = "娃娃玩具",
    secondClass = "竹马",
    level = "紫色"
  },
  ["竹马（金色）"] = {
    subClass = "娃娃玩具",
    secondClass = "竹马",
    level = "金色"
  },
  ["毽子（蓝色）"] = {
    subClass = "娃娃玩具",
    secondClass = "毽子",
    level = "蓝色"
  },
  ["毽子（紫色）"] = {
    subClass = "娃娃玩具",
    secondClass = "毽子",
    level = "紫色"
  },
  ["毽子（金色）"] = {
    subClass = "娃娃玩具",
    secondClass = "毽子",
    level = "金色"
  },
  ["蹴球（蓝色）"] = {
    subClass = "娃娃玩具",
    secondClass = "蹴球",
    level = "蓝色"
  },
  ["蹴球（紫色）"] = {
    subClass = "娃娃玩具",
    secondClass = "蹴球",
    level = "紫色"
  },
  ["蹴球（金色）"] = {
    subClass = "娃娃玩具",
    secondClass = "蹴球",
    level = "金色"
  },
  ["弹弓（蓝色）"] = {
    subClass = "娃娃玩具",
    secondClass = "弹弓",
    level = "蓝色"
  },
  ["弹弓（紫色）"] = {
    subClass = "娃娃玩具",
    secondClass = "弹弓",
    level = "紫色"
  },
  ["弹弓（金色）"] = {
    subClass = "娃娃玩具",
    secondClass = "弹弓",
    level = "金色"
  },
  ["陀螺（蓝色）"] = {
    subClass = "娃娃玩具",
    secondClass = "陀螺",
    level = "蓝色"
  },
  ["陀螺（紫色）"] = {
    subClass = "娃娃玩具",
    secondClass = "陀螺",
    level = "紫色"
  },
  ["陀螺（金色）"] = {
    subClass = "娃娃玩具",
    secondClass = "陀螺",
    level = "金色"
  },
  ["风筝（蓝色）"] = {
    subClass = "娃娃玩具",
    secondClass = "风筝",
    level = "蓝色"
  },
  ["风筝（紫色）"] = {
    subClass = "娃娃玩具",
    secondClass = "风筝",
    level = "紫色"
  },
  ["风筝（金色）"] = {
    subClass = "娃娃玩具",
    secondClass = "风筝",
    level = "金色"
  },
  [CHS[4100002]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100003]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100004]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100005]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100006]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100007]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100008]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100009]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100010]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100011]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100012]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100013]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100014]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100015]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100016]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100017]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100018]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100019]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100020]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100021]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100022]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100023]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100024]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100025]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100026]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100027]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100028]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100029]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100030]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100031]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100032]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100033]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100034]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100035]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100036]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100037]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100038]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100039]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100040]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100041]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100042]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100043]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100044]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100045]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100046]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100047]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100048]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100227]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100228]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100229]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[5440003]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100231]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100232]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100233]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[5440004]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100235]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100236]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100237]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100238]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100239]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100240]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100546]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100547]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100548]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100549]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100550]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100551]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[7190104]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[7190105]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[7100447]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[7100448]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[2500148]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[2500149]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[2500150]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[2500151]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100087],
    level = 0
  },
  [CHS[4100049]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100050]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100051]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100052]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100053]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100054]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100055]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100056]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100057]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100058]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100059]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100060]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  ["超级幽雪卡"] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  ["超级馥汀卡"] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  ["超级陌玉卡"] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  ["超级九华卡"] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100088],
    level = 0
  },
  [CHS[4100061]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100062]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100063]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100064]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100065]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100066]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100067]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100068]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100241]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100242]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[4100552]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[7190106]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  [CHS[2500152]] = {
    subClass = CHS[4100000],
    secondClass = CHS[4100089],
    level = 0
  },
  ["超级疆良卡"] = {
    subClass = CHS[4100000],
    secondClass = "神兽变身卡",
    level = 0
  },
  ["超级东山神灵卡"] = {
    subClass = CHS[4100000],
    secondClass = "神兽变身卡",
    level = 0
  },
  ["超级玄武卡"] = {
    subClass = CHS[4100000],
    secondClass = "神兽变身卡",
    level = 0
  },
  ["超级朱雀卡"] = {
    subClass = CHS[4100000],
    secondClass = "神兽变身卡",
    level = 0
  },
  ["超级九尾狐卡"] = {
    subClass = CHS[4100000],
    secondClass = "神兽变身卡",
    level = 0
  },
  ["超级白矖卡"] = {
    subClass = CHS[4100000],
    secondClass = "神兽变身卡",
    level = 0
  },
  ["超级勾陈卡"] = {
    subClass = CHS[4100000],
    secondClass = "神兽变身卡",
    level = 0
  },
  ["超级精卫卡"] = {
    subClass = CHS[4100000],
    secondClass = "神兽变身卡",
    level = 0
  },
  [CHS[3001149]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001074],
    level = 20
  },
  [CHS[3001151]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001074],
    level = 35
  },
  [CHS[3001152]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001074],
    level = 50
  },
  [CHS[3001153]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001074],
    level = 60
  },
  [CHS[3001154]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001074],
    level = 70
  },
  [CHS[3001155]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001076],
    level = 20
  },
  [CHS[3001156]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001076],
    level = 35
  },
  [CHS[3001157]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001076],
    level = 50
  },
  [CHS[3001158]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001076],
    level = 60
  },
  [CHS[3001159]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001076],
    level = 70
  },
  [CHS[3001160]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001078],
    level = 20
  },
  [CHS[3001161]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001078],
    level = 35
  },
  [CHS[3001162]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001078],
    level = 50
  },
  [CHS[3001163]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001078],
    level = 60
  },
  [CHS[3001164]] = {
    subClass = CHS[3001150],
    secondClass = CHS[3001078],
    level = 70
  },
  [CHS[3001165]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 50
  },
  [CHS[3001167]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 60
  },
  [CHS[3001168]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 70
  },
  [CHS[3001169]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 80
  },
  [CHS[4100207]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 90
  },
  [CHS[4100208]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 100
  },
  ["九转金刚刃(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 110
  },
  ["混元斩龙戟(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 120
  },
  ["赤眼神龙枪(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001023],
    level = 130
  },
  [CHS[3001170]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 50
  },
  [CHS[3001171]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 60
  },
  [CHS[3001172]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 70
  },
  [CHS[3001173]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 80
  },
  [CHS[4100209]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 90
  },
  [CHS[4100210]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 100
  },
  ["七巧玲珑爪(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 110
  },
  ["镇魂摄天刺(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 120
  },
  ["红绫火毒爪(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001028],
    level = 130
  },
  [CHS[3001174]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 50
  },
  [CHS[3001175]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 60
  },
  [CHS[3001176]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 70
  },
  [CHS[3001177]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 80
  },
  [CHS[4100211]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 90
  },
  [CHS[4100212]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 100
  },
  ["紫青玄魔剑(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 110
  },
  ["封神诛仙剑(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 120
  },
  ["九天玄冥剑(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001033],
    level = 130
  },
  [CHS[3001178]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 50
  },
  [CHS[3001179]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 60
  },
  [CHS[3001180]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 70
  },
  [CHS[3001181]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 80
  },
  [CHS[4100213]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 90
  },
  [CHS[4100214]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 100
  },
  ["离火七翎扇(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 110
  },
  ["赤霄烈焰扇(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 120
  },
  ["红云火霞扇(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001038],
    level = 130
  },
  [CHS[3001182]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 50
  },
  [CHS[3001183]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 60
  },
  [CHS[3001184]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 70
  },
  [CHS[3001185]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 80
  },
  [CHS[4100215]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 90
  },
  [CHS[4100216]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 100
  },
  ["炼狱麒麟杵(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 110
  },
  ["风雷如意杵(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 120
  },
  ["玄黄破坚锤(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001043],
    level = 130
  },
  [CHS[3001186]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 50
  },
  [CHS[3001187]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 60
  },
  [CHS[3001188]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 70
  },
  [CHS[3001189]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 80
  },
  [CHS[4100217]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 90
  },
  [CHS[4100218]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 100
  },
  ["星耀冠(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 110
  },
  ["七星宝冠(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 120
  },
  ["白玉星冠(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001048],
    level = 130
  },
  [CHS[3001190]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 50
  },
  [CHS[3001191]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 60
  },
  [CHS[3001192]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 70
  },
  [CHS[3001193]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 80
  },
  [CHS[4100219]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 90
  },
  [CHS[4100220]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 100
  },
  ["瀚宇法袍(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 110
  },
  ["诸天法袍(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 120
  },
  ["天玄真神甲(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001053],
    level = 130
  },
  [CHS[3001194]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 50
  },
  [CHS[3001195]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 60
  },
  [CHS[3001196]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 70
  },
  [CHS[3001197]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 80
  },
  [CHS[4100223]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 90
  },
  [CHS[4100224]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 100
  },
  ["凌波霞冠(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 110
  },
  ["天灵宝冠(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 120
  },
  ["九彩玲珠冠(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001058],
    level = 130
  },
  [CHS[3001198]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 50
  },
  [CHS[3001199]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 60
  },
  [CHS[3001200]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 70
  },
  [CHS[3001201]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 80
  },
  [CHS[4100221]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 90
  },
  [CHS[4100222]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 100
  },
  ["星晶法衣(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 110
  },
  ["神鸢凤裘(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 120
  },
  ["万霞霓罗裳(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001063],
    level = 130
  },
  [CHS[3001202]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 50
  },
  [CHS[3001203]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 60
  },
  [CHS[3001204]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 70
  },
  [CHS[3001205]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 80
  },
  [CHS[4100225]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 90
  },
  [CHS[4100226]] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 100
  },
  ["御风履(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 110
  },
  ["钧天履(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 120
  },
  ["雷弧闪(未鉴定)"] = {
    subClass = CHS[3001166],
    secondClass = CHS[3001068],
    level = 130
  },
  [CHS[7000137]] = {
    subClass = CHS[7000144],
    level = 0
  },
  [CHS[7000138]] = {
    subClass = CHS[7000144],
    level = 0
  },
  [CHS[7000139]] = {
    subClass = CHS[7000144],
    level = 0
  },
  [CHS[7000140]] = {
    subClass = CHS[7000144],
    level = 0
  },
  [CHS[7000141]] = {
    subClass = CHS[7000144],
    level = 0
  },
  [CHS[7000142]] = {
    subClass = CHS[7000144],
    level = 0
  },
  [CHS[7000143]] = {
    subClass = CHS[7000144],
    level = 0
  },
  [CHS[7190649]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[7190650]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[7190651]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[7190652]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[7190653]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[7190654]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[7190655]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[7190656]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[7190657]] = {
    subClass = CHS[7190683],
    level = 0
  },
  [CHS[5400255]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[5400256]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[2500061]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100003]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100004]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100005]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100006]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100007]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100008]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100009]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100010]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  ["大理石方桌"] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  ["马踏飞燕"] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  ["平安结"] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100011]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100012]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100013]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100014]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100015]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100016]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7190000]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7190001]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7190002]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100017]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  ["鎏金双宫灯"] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  ["玉石抚琴台"] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100018]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100019]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100020]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100021]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  [CHS[7100022]] = {
    subClass = CHS[3001137],
    secondClass = CHS[5420176],
    level = 0
  },
  ["千秋梦"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "千秋梦"
  },
  ["汉宫秋"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "汉宫秋"
  },
  ["龙吟水"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "龙吟水"
  },
  ["凤鸣空"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "凤鸣空"
  },
  ["如意年"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "如意年"
  },
  ["吉祥天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "吉祥天"
  },
  ["狐灵逸"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "狐灵逸"
  },
  ["狐灵娇"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "狐灵娇"
  },
  ["千秋梦·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "千秋梦"
  },
  ["汉宫秋·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "汉宫秋"
  },
  ["龙吟水·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "龙吟水"
  },
  ["凤鸣空·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "凤鸣空"
  },
  ["峥岚衣·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "峥岚衣"
  },
  ["水光衫·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "水光衫"
  },
  ["如意年·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "如意年"
  },
  ["吉祥天·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "吉祥天"
  },
  ["狐灵逸·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "狐灵逸"
  },
  ["狐灵娇·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "狐灵娇"
  },
  ["日耀辰辉·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "日耀辰辉"
  },
  ["星垂月涌·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "星垂月涌"
  },
  ["星火昭·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "星火昭"
  },
  ["点红烛·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "点红烛"
  },
  ["千秋梦·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "千秋梦"
  },
  ["汉宫秋·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "汉宫秋"
  },
  ["龙吟水·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "龙吟水"
  },
  ["凤鸣空·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "凤鸣空"
  },
  ["峥岚衣·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "峥岚衣"
  },
  ["水光衫·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "水光衫"
  },
  ["如意年·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "如意年"
  },
  ["吉祥天·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "吉祥天"
  },
  ["狐灵逸·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "狐灵逸"
  },
  ["狐灵娇·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "狐灵娇"
  },
  ["日耀辰辉·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "日耀辰辉"
  },
  ["星垂月涌·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "星垂月涌"
  },
  ["星火昭·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "星火昭"
  },
  ["点红烛·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "点红烛"
  },
  ["剑魄琴心·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "剑魄琴心"
  },
  ["引天长歌·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "引天长歌"
  },
  ["剑魄琴心·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "剑魄琴心"
  },
  ["引天长歌·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "引天长歌"
  },
  ["踏雪寻梅·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "踏雪寻梅"
  },
  ["踏雪寻梅·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "踏雪寻梅"
  },
  ["紫岚故梦·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "紫岚故梦"
  },
  ["紫岚故梦·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "紫岚故梦"
  },
  ["剑魄琴心·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "剑魄琴心"
  },
  ["引天长歌·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "引天长歌"
  },
  ["镇星辰·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "镇星辰"
  },
  ["镇星辰·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "镇星辰"
  },
  ["玄冥临·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "玄冥临"
  },
  ["玄冥临·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "玄冥临"
  },
  ["望月白·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "望月白"
  },
  ["望月白·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "望月白"
  },
  ["望月白·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "望月白"
  },
  ["霜夜雪·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "霜夜雪"
  },
  ["霜夜雪·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "霜夜雪"
  },
  ["霜夜雪·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "霜夜雪"
  },
  ["极道棋魂·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "极道棋魂"
  },
  ["极道棋魂·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "极道棋魂"
  },
  ["极道棋魂·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "极道棋魂"
  },
  ["仙道棋心·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "仙道棋心"
  },
  ["仙道棋心·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "仙道棋心"
  },
  ["仙道棋心·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "仙道棋心"
  },
  ["山藏海·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "山藏海"
  },
  ["山藏海·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "山藏海"
  },
  ["山藏海·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "山藏海"
  },
  ["水牧云·30天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "水牧云"
  },
  ["水牧云·90天"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "水牧云"
  },
  ["水牧云·永久"] = {
    subClass = "其他道具",
    secondClass = "时装",
    level = 0,
    keyName = "水牧云"
  },
  ["树漆"] = {
    subClass = "其他道具",
    secondClass = "家具材料",
    level = 0
  },
  ["石材"] = {
    subClass = "其他道具",
    secondClass = "家具材料",
    level = 0
  },
  ["黄金"] = {
    subClass = "其他道具",
    secondClass = "家具材料",
    level = 0
  },
  ["锦缎"] = {
    subClass = "其他道具",
    secondClass = "家具材料",
    level = 0
  },
  ["玉料"] = {
    subClass = "其他道具",
    secondClass = "家具材料",
    level = 0
  },
  ["喇叭"] = {
    subClass = "其他道具",
    level = 0
  },
  ["真灵精粹"] = {
    subClass = "其他道具",
    level = 0
  },
  ["健体羹(3品)"] = {
    subClass = "菜肴",
    secondClass = "健体羹",
    level = 0
  },
  ["健体羹(4品)"] = {
    subClass = "菜肴",
    secondClass = "健体羹",
    level = 0
  },
  ["健体羹(5品)"] = {
    subClass = "菜肴",
    secondClass = "健体羹",
    level = 0
  },
  ["安神羹(3品)"] = {
    subClass = "菜肴",
    secondClass = "安神羹",
    level = 0
  },
  ["安神羹(4品)"] = {
    subClass = "菜肴",
    secondClass = "安神羹",
    level = 0
  },
  ["安神羹(5品)"] = {
    subClass = "菜肴",
    secondClass = "安神羹",
    level = 0
  },
  ["秘制鱼汤(1品)"] = {
    subClass = "菜肴",
    secondClass = "秘制鱼汤",
    level = 0
  },
  ["秘制鱼汤(2品)"] = {
    subClass = "菜肴",
    secondClass = "秘制鱼汤",
    level = 0
  },
  ["灵芝鱼丸(1品)"] = {
    subClass = "菜肴",
    secondClass = "灵芝鱼丸",
    level = 0
  },
  ["灵芝鱼丸(2品)"] = {
    subClass = "菜肴",
    secondClass = "灵芝鱼丸",
    level = 0
  },
  ["灵芝鱼丸(3品)"] = {
    subClass = "菜肴",
    secondClass = "灵芝鱼丸",
    level = 0
  },
  ["灵芝鱼丸(4品)"] = {
    subClass = "菜肴",
    secondClass = "灵芝鱼丸",
    level = 0
  },
  ["人参鱼丸(1品)"] = {
    subClass = "菜肴",
    secondClass = "人参鱼丸",
    level = 0
  },
  ["人参鱼丸(2品)"] = {
    subClass = "菜肴",
    secondClass = "人参鱼丸",
    level = 0
  },
  ["人参鱼丸(3品)"] = {
    subClass = "菜肴",
    secondClass = "人参鱼丸",
    level = 0
  },
  ["人参鱼丸(4品)"] = {
    subClass = "菜肴",
    secondClass = "人参鱼丸",
    level = 0
  },
  ["易经洗髓丹"] = {
    subClass = "其他道具",
    secondClass = "洗点道具",
    level = 0
  },
  ["五行合缘露"] = {
    subClass = "其他道具",
    secondClass = "洗点道具",
    level = 0
  },
  ["仙魔散"] = {
    subClass = "其他道具",
    secondClass = "洗点道具",
    level = 0
  },
  ["太阴之气"] = {
    subClass = "太阴之气",
    level = 0
  },
  ["梦荷·震位"] = {
    subClass = "飞行法宝",
    secondClass = "梦荷部件",
    level = 0,
    searchKey = "梦荷·震位"
  },
  ["梦荷·离位"] = {
    subClass = "飞行法宝",
    secondClass = "梦荷部件",
    level = 0,
    searchKey = "梦荷·离位"
  },
  ["梦荷·兑位"] = {
    subClass = "飞行法宝",
    secondClass = "梦荷部件",
    level = 0,
    searchKey = "梦荷·兑位"
  },
  ["梦荷·30天"] = {
    subClass = "飞行法宝",
    secondClass = "梦荷",
    level = 0
  },
  ["梦荷·30天(启灵)"] = {
    subClass = "飞行法宝",
    secondClass = "梦荷",
    level = 0
  },
  ["御天梭·30天"] = {
    subClass = "飞行法宝",
    secondClass = "御天梭",
    level = 0
  },
  ["御天梭·30天(启灵)"] = {
    subClass = "飞行法宝",
    secondClass = "御天梭",
    level = 0
  },
  ["墨舞青云·30天"] = {
    subClass = "飞行法宝",
    secondClass = "墨舞青云",
    level = 0,
    searchKey = "未启灵"
  },
  ["墨舞青云·30天(启灵)"] = {
    subClass = "飞行法宝",
    secondClass = "墨舞青云",
    level = 0,
    searchKey = "已启灵"
  },
  ["魔炎飞甲·30天"] = {
    subClass = "飞行法宝",
    secondClass = "魔炎飞甲",
    level = 0,
    searchKey = "未启灵"
  },
  ["魔炎飞甲·30天(启灵)"] = {
    subClass = "飞行法宝",
    secondClass = "魔炎飞甲",
    level = 0,
    searchKey = "已启灵"
  }
}
