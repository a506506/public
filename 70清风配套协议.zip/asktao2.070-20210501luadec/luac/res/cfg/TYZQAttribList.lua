return {
  phy_power = {
    propDesc = "物伤x",
    propName = "物伤",
    propMinValue = 224,
    propMaxValue = 1124,
    classType = 1,
    affectByLevel = 1,
    showOrder = 1
  },
  mag_power = {
    propDesc = "法伤x",
    propName = "法伤",
    propMinValue = 207,
    propMaxValue = 1036,
    classType = 1,
    affectByLevel = 1,
    showOrder = 2
  },
  max_life = {
    propDesc = "气血x",
    propName = "气血",
    propMinValue = 986,
    propMaxValue = 4934,
    classType = 1,
    affectByLevel = 1,
    showOrder = 3
  },
  def = {
    propDesc = "防御x",
    propName = "防御",
    propMinValue = 657,
    propMaxValue = 3289,
    classType = 1,
    affectByLevel = 1,
    showOrder = 4
  },
  speed = {
    propDesc = "速度x",
    propName = "速度",
    propMinValue = 56,
    propMaxValue = 282,
    classType = 1,
    affectByLevel = 1,
    showOrder = 5
  },
  str = {
    propDesc = "力量x",
    propName = "力量",
    propMinValue = 6,
    propMaxValue = 31,
    classType = 1,
    affectByLevel = 1,
    showOrder = 6
  },
  wiz = {
    propDesc = "灵力x",
    propName = "灵力",
    propMinValue = 6,
    propMaxValue = 31,
    classType = 1,
    affectByLevel = 1,
    showOrder = 7
  },
  dex = {
    propDesc = "敏捷x",
    propName = "敏捷",
    propMinValue = 6,
    propMaxValue = 31,
    classType = 1,
    affectByLevel = 1,
    showOrder = 8
  },
  con = {
    propDesc = "体质x",
    propName = "体质",
    propMinValue = 6,
    propMaxValue = 31,
    classType = 1,
    affectByLevel = 1,
    showOrder = 9
  },
  all_attrib = {
    propDesc = "所有属性x",
    propName = "所有属性",
    propMinValue = 3,
    propMaxValue = 18,
    classType = 1,
    affectByLevel = 1,
    showOrder = 10
  },
  stunt_rate = {
    propDesc = "物理必杀率x%",
    propName = "物理必杀率",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 11
  },
  mstunt_rate = {
    propDesc = "法术必杀率x%",
    propName = "法术必杀率",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 1,
    affectByLevel = 0,
    showOrder = 12
  },
  resist_stunt_rate = {
    propDesc = "抗物理必杀x%",
    propName = "抗物理必杀",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 13
  },
  resist_mstunt_rate = {
    propDesc = "抗法术必杀x%",
    propName = "抗法术必杀",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 1,
    affectByLevel = 0,
    showOrder = 14
  },
  damage_sel = {
    propDesc = "反震度x",
    propName = "反震度",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 15
  },
  damage_sel_rate = {
    propDesc = "反震率x%",
    propName = "反震率",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 16
  },
  counter_attack = {
    propDesc = "反击次数x",
    propName = "反击次数",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 1,
    affectByLevel = 0,
    showOrder = 17
  },
  counter_attack_rate = {
    propDesc = "反击率x%",
    propName = "反击率",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 18
  },
  penetrate = {
    propDesc = "破防x%",
    propName = "破防",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 19
  },
  penetrate_rate = {
    propDesc = "破防率x%",
    propName = "破防率",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 20
  },
  double_hit = {
    propDesc = "物理连击次数x",
    propName = "物理连击次数",
    propMinValue = 2,
    propMaxValue = 12,
    classType = 1,
    affectByLevel = 0,
    showOrder = 21
  },
  double_hit_rate = {
    propDesc = "物理连击率x%",
    propName = "物理连击率",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 22
  },
  resist_double_hit_rate = {
    propDesc = "抗物理连击x%",
    propName = "抗物理连击",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 23
  },
  ignore_resist_metal = {
    propDesc = "忽视目标抗金x%",
    propName = "忽视目标抗金",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 24
  },
  ignore_resist_wood = {
    propDesc = "忽视目标抗木x%",
    propName = "忽视目标抗木",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 25
  },
  ignore_resist_water = {
    propDesc = "忽视目标抗水x%",
    propName = "忽视目标抗水",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 26
  },
  ignore_resist_fire = {
    propDesc = "忽视目标抗火x%",
    propName = "忽视目标抗火",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 27
  },
  ignore_resist_earth = {
    propDesc = "忽视目标抗土x%",
    propName = "忽视目标抗土",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 28
  },
  ignore_all_resist_polar = {
    propDesc = "忽视所有抗性x%",
    propName = "忽视所有抗性",
    propMinValue = 4,
    propMaxValue = 20,
    classType = 1,
    affectByLevel = 0,
    showOrder = 29
  },
  ignore_all_resist_except = {
    propDesc = "忽视所有抗异常x%",
    propName = "忽视所有抗异常",
    propMinValue = 4,
    propMaxValue = 20,
    classType = 1,
    affectByLevel = 0,
    showOrder = 30
  },
  ignore_resist_forgotten = {
    propDesc = "忽视目标抗遗忘x%",
    propName = "忽视目标抗遗忘",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 31
  },
  ignore_resist_poison = {
    propDesc = "忽视目标抗中毒x%",
    propName = "忽视目标抗中毒",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 32
  },
  ignore_resist_frozen = {
    propDesc = "忽视目标抗冰冻x%",
    propName = "忽视目标抗冰冻",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 33
  },
  ignore_resist_sleep = {
    propDesc = "忽视目标抗昏睡x%",
    propName = "忽视目标抗昏睡",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 34
  },
  ignore_resist_confusion = {
    propDesc = "忽视目标抗混乱x%",
    propName = "忽视目标抗混乱",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 35
  },
  resist_metal = {
    propDesc = "金抗性x%",
    propName = "金抗性",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 36
  },
  resist_wood = {
    propDesc = "木抗性x%",
    propName = "木抗性",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 37
  },
  resist_water = {
    propDesc = "水抗性x%",
    propName = "水抗性",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 38
  },
  resist_fire = {
    propDesc = "火抗性x%",
    propName = "火抗性",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 39
  },
  resist_earth = {
    propDesc = "土抗性x%",
    propName = "土抗性",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 40
  },
  all_resist_polar = {
    propDesc = "所有抗性x%",
    propName = "所有抗性",
    propMinValue = 4,
    propMaxValue = 20,
    classType = 1,
    affectByLevel = 0,
    showOrder = 41
  },
  all_resist_except = {
    propDesc = "所有抗异常x%",
    propName = "所有抗异常",
    propMinValue = 4,
    propMaxValue = 20,
    classType = 1,
    affectByLevel = 0,
    showOrder = 42
  },
  resist_forgotten = {
    propDesc = "抗遗忘x%",
    propName = "抗遗忘",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 43
  },
  resist_poison = {
    propDesc = "抗中毒x%",
    propName = "抗中毒",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 44
  },
  resist_frozen = {
    propDesc = "抗冰冻x%",
    propName = "抗冰冻",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 45
  },
  resist_sleep = {
    propDesc = "抗昏睡x%",
    propName = "抗昏睡",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 46
  },
  resist_confusion = {
    propDesc = "抗混乱x%",
    propName = "抗混乱",
    propMinValue = 6,
    propMaxValue = 30,
    classType = 1,
    affectByLevel = 0,
    showOrder = 47
  },
  release_forgotten = {
    propDesc = "几率解除遗忘状态x%",
    propName = "几率解除遗忘状态",
    propMinValue = 3,
    propMaxValue = 15,
    classType = 1,
    affectByLevel = 0,
    showOrder = 48
  },
  release_poison = {
    propDesc = "几率解除中毒状态x%",
    propName = "几率解除中毒状态",
    propMinValue = 3,
    propMaxValue = 15,
    classType = 1,
    affectByLevel = 0,
    showOrder = 49
  },
  release_frozen = {
    propDesc = "几率解除冰冻状态x%",
    propName = "几率解除冰冻状态",
    propMinValue = 3,
    propMaxValue = 15,
    classType = 1,
    affectByLevel = 0,
    showOrder = 50
  },
  release_sleep = {
    propDesc = "几率解除昏睡状态x%",
    propName = "几率解除昏睡状态",
    propMinValue = 3,
    propMaxValue = 15,
    classType = 1,
    affectByLevel = 0,
    showOrder = 51
  },
  release_confusion = {
    propDesc = "几率解除混乱状态x%",
    propName = "几率解除混乱状态",
    propMinValue = 3,
    propMaxValue = 15,
    classType = 1,
    affectByLevel = 0,
    showOrder = 52
  },
  C_skill_dodge = {
    propDesc = "几率躲避障碍x%",
    propName = "几率躲避障碍",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 53
  },
  ignore_C_skill_dodge = {
    propDesc = "忽视目标躲避障碍x%",
    propName = "忽视目标躲避障碍",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 54
  },
  steal_buff_rate = {
    propDesc = "几率偷取辅助状态x%",
    propName = "几率偷取辅助状态",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 55
  },
  ignore_steal_buff_rate = {
    propDesc = "抗辅助状态偷取x%",
    propName = "抗辅助状态偷取",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 56
  },
  relive_rate = {
    propDesc = "复活率x%",
    propName = "复活率",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 57
  },
  ignore_relive_rate = {
    propDesc = "忽视目标复活x%",
    propName = "忽视目标复活",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 58
  },
  suck_blood_rate = {
    propDesc = "吸血率x%",
    propName = "吸血率",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 59
  },
  ignore_suck_blood_rate = {
    propDesc = "抗吸血x%",
    propName = "抗吸血",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 60
  },
  cripple_rate = {
    propDesc = "致残率x%",
    propName = "致残率",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 61
  },
  ignore_cripple_rate = {
    propDesc = "抗致残x%",
    propName = "抗致残",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 62
  },
  defence_to_attack = {
    propDesc = "以守为攻x%",
    propName = "以守为攻",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 63
  },
  phy_attack_by_surprise = {
    propDesc = "攻其不备x%",
    propName = "攻其不备",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 64
  },
  mag_attack_by_surprise = {
    propDesc = "出其不意x%",
    propName = "出其不意",
    propMinValue = 2,
    propMaxValue = 10,
    classType = 2,
    affectByLevel = 0,
    showOrder = 65
  }
}
