return {
  {
    class_id = 10017,
    x = 17,
    y = 30,
    dir = 1,
    cx = -3,
    cy = -6
  },
  {
    class_id = 10017,
    x = 50,
    y = 13,
    dir = 1,
    cx = 9,
    cy = -7
  },
  {
    class_id = 10016,
    x = 67,
    y = 55,
    dir = 0,
    cx = 1,
    cy = -7
  },
  {
    class_id = 10029,
    x = 52,
    y = 27,
    dir = 0,
    cx = -5,
    cy = 8
  },
  {
    class_id = 10019,
    x = 104,
    y = 37,
    dir = 0,
    cx = -9,
    cy = -2
  },
  {
    class_id = 10040,
    x = 69,
    y = 45,
    dir = 0,
    cx = -3,
    cy = -2
  },
  {
    class_id = 10027,
    x = 68,
    y = 34,
    dir = 0,
    cx = 11,
    cy = 2
  }
}
