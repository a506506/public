return {
  ["铁剑"] = {
    req_level = 1,
    icon = 1123,
    name = "铁剑",
    unit = "把",
    equipType = "武器"
  },
  ["钢枪"] = {
    req_level = 5,
    icon = 1134,
    name = "钢枪",
    unit = "把",
    equipType = "武器"
  },
  ["秘银剑"] = {
    req_level = 10,
    icon = 1124,
    name = "秘银剑",
    unit = "把",
    equipType = "武器"
  },
  ["红缨枪"] = {
    req_level = 15,
    icon = 1135,
    name = "红缨枪",
    unit = "把",
    equipType = "武器"
  },
  ["阔剑"] = {
    req_level = 20,
    icon = 1125,
    name = "阔剑",
    unit = "把",
    equipType = "武器"
  },
  ["极刑枪"] = {
    req_level = 25,
    icon = 1136,
    name = "极刑枪",
    unit = "把",
    equipType = "武器"
  },
  ["长虹剑"] = {
    req_level = 30,
    icon = 1126,
    name = "长虹剑",
    unit = "把",
    equipType = "武器"
  },
  ["乌钢枪"] = {
    req_level = 35,
    icon = 1137,
    name = "乌钢枪",
    unit = "把",
    equipType = "武器"
  },
  ["绿茗剑"] = {
    req_level = 40,
    icon = 1127,
    name = "绿茗剑",
    unit = "把",
    equipType = "武器"
  },
  ["烈焰枪"] = {
    req_level = 45,
    icon = 1138,
    name = "烈焰枪",
    unit = "把",
    equipType = "武器"
  },
  ["寒冰剑"] = {
    req_level = 50,
    icon = 1128,
    name = "寒冰枪",
    unit = "把",
    equipType = "武器"
  },
  ["破魔枪"] = {
    req_level = 55,
    icon = 1139,
    name = "破魔枪",
    unit = "把",
    equipType = "武器"
  },
  ["贯日剑"] = {
    req_level = 60,
    icon = 1129,
    name = "贯日剑",
    unit = "把",
    equipType = "武器"
  },
  ["斩妖枪"] = {
    req_level = 65,
    icon = 1140,
    name = "斩妖枪",
    unit = "把",
    equipType = "武器"
  },
  ["灭魄剑"] = {
    req_level = 70,
    icon = 1130,
    name = "灭魄剑",
    unit = "把",
    equipType = "武器"
  },
  ["冥音枪"] = {
    req_level = 75,
    icon = 1141,
    name = "冥音枪",
    unit = "把",
    equipType = "武器"
  },
  ["追魂剑"] = {
    req_level = 80,
    icon = 1131,
    name = "追魂剑",
    unit = "把",
    equipType = "武器"
  },
  ["闇龙枪"] = {
    req_level = 85,
    icon = 1142,
    name = "闇龙枪",
    unit = "把",
    equipType = "武器"
  },
  ["纯钧剑"] = {
    req_level = 90,
    icon = 1132,
    name = "纯钧剑",
    unit = "把",
    equipType = "武器"
  },
  ["雷影枪"] = {
    req_level = 95,
    icon = 1143,
    name = "雷影枪",
    unit = "把",
    equipType = "武器"
  },
  ["湛泸剑"] = {
    req_level = 100,
    icon = 1133,
    name = "湛泸剑",
    unit = "把",
    equipType = "武器"
  },
  ["木簪"] = {
    req_level = 1,
    icon = 1212,
    name = "木簪",
    unit = "支",
    equipType = "帽子"
  },
  ["头巾"] = {
    req_level = 5,
    icon = 1201,
    name = "头巾",
    unit = "顶",
    equipType = "帽子"
  },
  ["布帽"] = {
    req_level = 10,
    icon = 1202,
    name = "布帽",
    unit = "顶",
    equipType = "帽子"
  },
  ["铜盔"] = {
    req_level = 15,
    icon = 1203,
    name = "铜盔",
    unit = "顶",
    equipType = "帽子"
  },
  ["百战盔"] = {
    req_level = 20,
    icon = 1204,
    name = "百战盔",
    unit = "顶",
    equipType = "帽子"
  },
  ["猛虎盔"] = {
    req_level = 25,
    icon = 1205,
    name = "猛虎盔",
    unit = "顶",
    equipType = "帽子"
  },
  ["龙头盔"] = {
    req_level = 30,
    icon = 1206,
    name = "龙头盔",
    unit = "顶",
    equipType = "帽子"
  },
  ["灵玉冠"] = {
    req_level = 35,
    icon = 1207,
    name = "灵玉冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["白云簪"] = {
    req_level = 40,
    icon = 1219,
    name = "白云簪",
    unit = "支",
    equipType = "帽子"
  },
  ["赤霄冠"] = {
    req_level = 45,
    icon = 1208,
    name = "赤霄冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["龙头冠"] = {
    req_level = 50,
    icon = 1209,
    name = "龙头冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["龙灵冠"] = {
    req_level = 55,
    icon = 1210,
    name = "龙灵冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["辉日冠"] = {
    req_level = 60,
    icon = 1221,
    name = "辉日冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["紫雷冠"] = {
    req_level = 65,
    icon = 1211,
    name = "紫雷冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["凤影冠"] = {
    req_level = 70,
    icon = 1615,
    name = "凤影冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["耀星冠"] = {
    req_level = 75,
    icon = 1255,
    name = "耀星冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["凌霞冠"] = {
    req_level = 80,
    icon = 1257,
    name = "凌霞冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["风灵冠"] = {
    req_level = 85,
    icon = 1258,
    name = "风灵冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["七星冠"] = {
    req_level = 90,
    icon = 1256,
    name = "七星冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["升仙冠"] = {
    req_level = 95,
    icon = 1265,
    name = "升仙冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["幻星冠"] = {
    req_level = 100,
    icon = 1266,
    name = "幻星冠",
    unit = "顶",
    equipType = "帽子"
  },
  ["布衣"] = {
    req_level = 1,
    icon = 1222,
    name = "布衣",
    unit = "件",
    equipType = "衣服"
  },
  ["强化布衣"] = {
    req_level = 5,
    icon = 1222,
    name = "强化布衣",
    unit = "件",
    equipType = "衣服"
  },
  ["皮衣"] = {
    req_level = 10,
    icon = 1223,
    name = "皮衣",
    unit = "件",
    equipType = "衣服"
  },
  ["强化皮衣"] = {
    req_level = 15,
    icon = 1223,
    name = "强化皮衣",
    unit = "件",
    equipType = "衣服"
  },
  ["百战铠"] = {
    req_level = 20,
    icon = 1224,
    name = "百战铠",
    unit = "件",
    equipType = "衣服"
  },
  ["强化百战铠"] = {
    req_level = 25,
    icon = 1224,
    name = "强化百战铠",
    unit = "件",
    equipType = "衣服"
  },
  ["道袍"] = {
    req_level = 30,
    icon = 1225,
    name = "道袍",
    unit = "件",
    equipType = "衣服"
  },
  ["强化道袍"] = {
    req_level = 35,
    icon = 1225,
    name = "强化道袍",
    unit = "件",
    equipType = "衣服"
  },
  ["秘金甲"] = {
    req_level = 40,
    icon = 1226,
    name = "秘金甲",
    unit = "件",
    equipType = "衣服"
  },
  ["强化秘金甲"] = {
    req_level = 45,
    icon = 1226,
    name = "强化秘金甲",
    unit = "件",
    equipType = "衣服"
  },
  ["金丝袍"] = {
    req_level = 50,
    icon = 1227,
    name = "金丝袍",
    unit = "件",
    equipType = "衣服"
  },
  ["强化金丝袍"] = {
    req_level = 55,
    icon = 1227,
    name = "强化金丝袍",
    unit = "件",
    equipType = "衣服"
  },
  ["紫金甲"] = {
    req_level = 60,
    icon = 1228,
    name = "紫金甲",
    unit = "件",
    equipType = "衣服"
  },
  ["强化紫金甲"] = {
    req_level = 65,
    icon = 1228,
    name = "强化紫金甲",
    unit = "件",
    equipType = "衣服"
  },
  ["布道服"] = {
    req_level = 70,
    icon = 1229,
    name = "布道服",
    unit = "件",
    equipType = "衣服"
  },
  ["秘银甲"] = {
    req_level = 75,
    icon = 1230,
    name = "秘银甲",
    unit = "件",
    equipType = "衣服"
  },
  ["玉金甲"] = {
    req_level = 80,
    icon = 1231,
    name = "玉金甲",
    unit = "件",
    equipType = "衣服"
  },
  ["瀚海衣"] = {
    req_level = 85,
    icon = 1232,
    name = "瀚海衣",
    unit = "件",
    equipType = "衣服"
  },
  ["太阴衣"] = {
    req_level = 90,
    icon = 1259,
    name = "太阴衣",
    unit = "件",
    equipType = "衣服"
  },
  ["玄天袍"] = {
    req_level = 95,
    icon = 1260,
    name = "玄天袍",
    unit = "件",
    equipType = "衣服"
  },
  ["曜日甲"] = {
    req_level = 100,
    icon = 1267,
    name = "曜日甲",
    unit = "件",
    equipType = "衣服"
  },
  ["麻线鞋"] = {
    req_level = 1,
    icon = 1244,
    name = "麻线鞋",
    unit = "双",
    equipType = "鞋子"
  },
  ["强化麻线鞋"] = {
    req_level = 5,
    icon = 1244,
    name = "强化麻线鞋",
    unit = "双",
    equipType = "鞋子"
  },
  ["布锦鞋"] = {
    req_level = 10,
    icon = 1245,
    name = "布锦鞋",
    unit = "双",
    equipType = "鞋子"
  },
  ["强化布锦鞋"] = {
    req_level = 15,
    icon = 1245,
    name = "强化布锦鞋",
    unit = "双",
    equipType = "鞋子"
  },
  ["百战鞋"] = {
    req_level = 20,
    icon = 1246,
    name = "百战鞋",
    unit = "双",
    equipType = "鞋子"
  },
  ["强化百战鞋"] = {
    req_level = 25,
    icon = 1246,
    name = "强化百战鞋",
    unit = "双",
    equipType = "鞋子"
  },
  ["革靴"] = {
    req_level = 30,
    icon = 1247,
    name = "革靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["强化革靴"] = {
    req_level = 35,
    icon = 1247,
    name = "强化革靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["赤炎靴"] = {
    req_level = 40,
    icon = 1248,
    name = "赤炎靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["强化赤炎靴"] = {
    req_level = 45,
    icon = 1248,
    name = "强化赤炎靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["追风履"] = {
    req_level = 50,
    icon = 1249,
    name = "追风履",
    unit = "双",
    equipType = "鞋子"
  },
  ["强化追风履"] = {
    req_level = 55,
    icon = 1249,
    name = "强化追风履",
    unit = "双",
    equipType = "鞋子"
  },
  ["秘银靴"] = {
    req_level = 60,
    icon = 1250,
    name = "秘银靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["强化秘银靴"] = {
    req_level = 65,
    icon = 1250,
    name = "强化秘银靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["木灵履"] = {
    req_level = 70,
    icon = 1251,
    name = "木灵履",
    unit = "双",
    equipType = "鞋子"
  },
  ["紫金靴"] = {
    req_level = 75,
    icon = 1252,
    name = "紫金靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["御天靴"] = {
    req_level = 80,
    icon = 1253,
    name = "御天靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["瀚海履"] = {
    req_level = 85,
    icon = 1254,
    name = "瀚海履",
    unit = "双",
    equipType = "鞋子"
  },
  ["追日靴"] = {
    req_level = 90,
    icon = 1263,
    name = "追日靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["摘星履"] = {
    req_level = 95,
    icon = 1264,
    name = "摘星履",
    unit = "双",
    equipType = "鞋子"
  },
  ["雷影靴"] = {
    req_level = 100,
    icon = 1269,
    name = "雷影靴",
    unit = "双",
    equipType = "鞋子"
  },
  ["长命镯"] = {
    req_level = 1,
    icon = 1317,
    name = "长命镯",
    unit = "个",
    equipType = "手镯"
  },
  ["星月链"] = {
    req_level = 10,
    icon = 1318,
    name = "星月链",
    unit = "条",
    equipType = "手镯"
  },
  ["朝凤环"] = {
    req_level = 20,
    icon = 1319,
    name = "朝凤环",
    unit = "个",
    equipType = "手镯"
  },
  ["乌金镯"] = {
    req_level = 30,
    icon = 1320,
    name = "乌金镯",
    unit = "个",
    equipType = "手镯"
  },
  ["玄金镯"] = {
    req_level = 40,
    icon = 1321,
    name = "玄金镯",
    unit = "个",
    equipType = "手镯"
  },
  ["天道环"] = {
    req_level = 50,
    icon = 1322,
    name = "天道环",
    unit = "个",
    equipType = "手镯"
  },
  ["三才镯"] = {
    req_level = 60,
    icon = 1323,
    name = "三才镯",
    unit = "个",
    equipType = "手镯"
  },
  ["天星链"] = {
    req_level = 70,
    icon = 1324,
    name = "天星链",
    unit = "条",
    equipType = "手镯"
  },
  ["涵星镯"] = {
    req_level = 80,
    icon = 1329,
    name = "涵星镯",
    unit = "个",
    equipType = "手镯"
  },
  ["明月链"] = {
    req_level = 90,
    icon = 1330,
    name = "明月链",
    unit = "条",
    equipType = "手镯"
  },
  ["天道链"] = {
    req_level = 100,
    icon = 1333,
    name = "天道链",
    unit = "条",
    equipType = "手镯"
  },
  ["双龙佩"] = {
    req_level = 1,
    icon = 1309,
    name = "双龙佩",
    unit = "块",
    equipType = "玉佩"
  },
  ["护心玦"] = {
    req_level = 10,
    icon = 1310,
    name = "护心玦",
    unit = "块",
    equipType = "玉佩"
  },
  ["血玉佩"] = {
    req_level = 20,
    icon = 1311,
    name = "血玉佩",
    unit = "块",
    equipType = "玉佩"
  },
  ["八卦牌"] = {
    req_level = 30,
    icon = 1312,
    name = "八卦牌",
    unit = "面",
    equipType = "玉佩"
  },
  ["翔龙佩"] = {
    req_level = 40,
    icon = 1313,
    name = "翔龙佩",
    unit = "块",
    equipType = "玉佩"
  },
  ["七星佩"] = {
    req_level = 50,
    icon = 1314,
    name = "七星佩",
    unit = "块",
    equipType = "玉佩"
  },
  ["众星囊"] = {
    req_level = 60,
    icon = 1315,
    name = "众星囊",
    unit = "个",
    equipType = "玉佩"
  },
  ["和氏璧"] = {
    req_level = 70,
    icon = 1316,
    name = "和氏璧",
    unit = "块",
    equipType = "玉佩"
  },
  ["龙戏珠"] = {
    req_level = 80,
    icon = 1327,
    name = "龙戏珠",
    unit = "块",
    equipType = "玉佩"
  },
  ["金如意"] = {
    req_level = 90,
    icon = 1328,
    name = "金如意",
    unit = "块",
    equipType = "玉佩"
  },
  ["玄火佩"] = {
    req_level = 100,
    icon = 1331,
    name = "玄火佩",
    unit = "块",
    equipType = "玉佩"
  }
}
