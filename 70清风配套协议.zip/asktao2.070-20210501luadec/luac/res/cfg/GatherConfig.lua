return {
  [6201] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = ""
  },
  [6213] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = ""
  },
  [6230] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = ""
  },
  [6250] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = ""
  },
  [20019] = {
    anchor_x = 0.58,
    anchor_y = 0.3,
    normal_effect_behind_char = false,
    normal_effect = 1122
  },
  [50117] = {
    isCharAction = true,
    effect_behind_char = false,
    shadow_icon = ""
  },
  [51002] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    isCharAction = true,
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [51503] = {
    flipX_by_map = true,
    is_always_show_name = true,
    normal_effect = {
      icon = 1215,
      armatureName = "qizi",
      actionName = "7",
      flipActionName = "5",
      y = -20
    },
    normal_effect_behind_char = false,
    normal_effect_type = "DBMagic",
    anchor_y = 0.06,
    effect_behind_char = false
  },
  [51504] = {
    anchor_x = 0.6,
    anchor_y = 0.46,
    shadow_icon = "",
    normal_effect_behind_char = false,
    effect_behind_char = false
  },
  [51505] = {
    anchor_y = 0.46,
    shadow_icon = "",
    normal_effect_behind_char = false,
    effect_behind_char = false
  },
  [51507] = {
    anchor_y = 0.46,
    shadow_icon = "",
    normal_effect_behind_char = false,
    effect_behind_char = false
  },
  [51526] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    isCharAction = true
  },
  [51542] = {
    anchor_x = 0.5,
    anchor_y = 0.5,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true},
    need_obstacle = true,
    effect_behind_char = false
  },
  [51543] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [51544] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {gather_magic = 0},
    no_show_name = true,
    charLyaerType = "carpet"
  },
  [51545] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    normal_effect_extra_para = {loopInterval = 0, notShowDuringDelay = true}
  },
  [51546] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [51547] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [51548] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    effect_behind_char = false
  },
  [52034] = {
    anchor_x = 0.5,
    anchor_y = 0.3,
    effect_behind_char = false
  },
  [52035] = {
    anchor_x = 0.5,
    anchor_y = 0.3,
    effect_behind_char = false,
    confirm_before_gather = true
  },
  [52037] = {anchor_x = 0.5, anchor_y = 0.2},
  [52038] = {shadow_icon = ""},
  [52039] = {shadow_icon = ""},
  [52040] = {anchor_x = 0.5, anchor_y = 0.2},
  [52041] = {anchor_x = 0.5, anchor_y = 0.2},
  [52042] = {anchor_x = 0.5, anchor_y = 0.2},
  [52045] = {anchor_x = 0.5, anchor_y = 0.5},
  [52046] = {anchor_x = 0.5, anchor_y = 0.2},
  [52047] = {anchor_x = 0.5, anchor_y = 0.2},
  [52048] = {anchor_x = 0.5, anchor_y = 0.2},
  [52049] = {anchor_x = 0.5, anchor_y = 0.3},
  [52050] = {anchor_x = 0.5, anchor_y = 0.2},
  [52051] = {anchor_x = 0.5, anchor_y = 0.2},
  [52054] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52055] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52056] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52057] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52058] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52060] = {shadow_icon = ""},
  [52067] = {
    flipX_by_map = true,
    is_always_show_name = true,
    normal_effect = {
      icon = 2060,
      armatureName = "qizi",
      actionName = "7",
      flipActionName = "5",
      y = -14
    },
    normal_effect_behind_char = false,
    normal_effect_type = "DBMagic",
    anchor_y = 0.06,
    effect_behind_char = false
  },
  [52068] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52069] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52070] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52071] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52077] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = "",
    normal_effect_extra_para = {loopInterval = 15000, notShowDuringDelay = true}
  },
  [52073] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = ""
  },
  [52074] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = ""
  },
  [52075] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = ""
  },
  [52076] = {
    anchor_x = 0.5,
    anchor_y = 0.2,
    shadow_icon = ""
  },
  [52095] = {
    anchor_x = 0.5,
    anchor_y = 0.5,
    effect_behind_char = false,
    shadow_icon = ""
  },
  [52103] = {no_show_name = true, shadow_icon = ""},
  [51549] = {confirm_before_gather = true, shadow_icon = ""}
}
