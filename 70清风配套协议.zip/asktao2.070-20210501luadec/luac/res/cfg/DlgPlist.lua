return {
  ["2020NewlyServerReservePrechargeDlg"] = {
    "ServerReserve.plist",
    "TianggkwImage.plist"
  },
  ["2020NewlyServerReserveRewardDlg"] = {
    "ServerReserve.plist",
    "TreasureBag.plist"
  },
  ["2020NewlyServerReserveShareDlg"] = {
    "ZiDYFX.plist",
    "WelfareDlg.plist"
  },
  ["2021NewlyServerReserveDlg"] = {
    "ServerReserve.plist",
    "TreasureBag.plist"
  },
  ["2021NewServerRechargeRuleDlg"] = {},
  ["AccountInputDlg"] = {
    "LoginDlg.plist"
  },
  ["AccountVerifyFailedDlg"] = {
    "MainIcon.plist"
  },
  ["AchievementCompleteDlg"] = {
    "MainIcon.plist",
    "AchievementDlg.plist"
  },
  ["AchievementListDlg"] = {
    "AchievementDlg.plist",
    "MainIcon.plist"
  },
  ["AchievementRewardDlg"] = {
    "MainIcon.plist",
    "AchievementDlg.plist"
  },
  ["AchievementShareDlg"] = {
    "MainIcon.plist",
    "AchievementDlg.plist"
  },
  ["AchievementTabDlg"] = {},
  ["ActiveLoginRewardDlg"] = {
    "MainIcon.plist",
    "WelfareDlg.plist"
  },
  ["ActiveVIPDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["ActivitiesDlg"] = {
    "MainIcon.plist",
    "ActivitiesDlg.plist"
  },
  ["ActivitiesInfoFFDlg"] = {
    "MainIcon.plist"
  },
  ["ActivitiesSeeDlg"] = {},
  ["ActivitiesWeekCalendarDlg"] = {
    "MainIcon.plist"
  },
  ["AddFriendVerifyDlg"] = {
    "MainIcon.plist"
  },
  ["AddOfflineTimeDlg"] = {},
  ["AddPartyNotifyDlg"] = {
    "MainIcon.plist"
  },
  ["AddPetBookDlg"] = {},
  ["AdministratorsDlg"] = {},
  ["AdvancedDlg"] = {
    "MainIcon.plist"
  },
  ["AdventureLogDlg"] = {
    "MainIcon.plist"
  },
  ["AdventureRuleDlg"] = {
    "MainIcon.plist"
  },
  ["AlchemyDlg"] = {
    "MainIcon.plist",
    "BagDlg.plist"
  },
  ["AllDrawGiftDlg"] = {},
  ["AllFollowRuleDlg"] = {
    "MainIcon.plist"
  },
  ["AltarCeremonyDlg"] = {
    "MainIcon.plist"
  },
  ["AngpaoAddDlg"] = {
    "MainIcon.plist"
  },
  ["AngpaoDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryBuyFlowersDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryCatCardDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryDrawDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryFriendDanLuDlg"] = {
    "MainIcon.plist",
    "AnniversaryXianDanDlg.plist"
  },
  ["AnniversaryFriendTreeDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryGiftDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryLingMaoCombatDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryLingMaoDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryLingMaoRuleDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryLingMaoSkillDlg"] = {},
  ["AnniversaryMallDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryOtherDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryPetAdventureDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryPetCardDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryPetCardrewDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryRewardDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryShareDlg"] = {},
  ["AnniversaryShopDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryTabDlg"] = {},
  ["AnniversaryTreeDlg"] = {
    "MainIcon.plist"
  },
  ["AnniversaryXianDanDlg"] = {
    "AnniversaryXianDanDlg.plist",
    "MainIcon.plist"
  },
  ["AnnouncementDlg"] = {
    "MainIcon.plist"
  },
  ["AppTreasureAcconutDlg"] = {
    "MainIcon.plist"
  },
  ["AppTreasureLoginDlg"] = {},
  ["ArenaDekaronListDlg"] = {
    "MainIcon.plist"
  },
  ["ArenaDlg"] = {
    "MainIcon.plist"
  },
  ["ArenajlDlg"] = {
    "MainIcon.plist"
  },
  ["ArenaRuleDlg"] = {},
  ["ArenaStoreDlg"] = {
    "MainIcon.plist"
  },
  ["ArenaTopTenDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactAddDlg"] = {
    "MainIcon.plist",
    "ArtifactDlg.plist"
  },
  ["ArtifactBuyDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactInfoCampareDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactInfoDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactIntimacyRuleDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactIntimacyUpgradeDlg"] = {
    "MainIcon.plist",
    "ArtifactDlg.plist"
  },
  ["ArtifactListDlg"] = {
    "ArtifactDlg.plist"
  },
  ["ArtifactPracticeDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactPracticeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactRefineDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactRuleDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactRuleNewDlg"] = {},
  ["ArtifactRulePolarDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactRuleSkillDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactSkillUpDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactSubmitDlg"] = {
    "MainIcon.plist"
  },
  ["ArtifactTabDlg"] = {},
  ["AuthenticatePhoneDlg"] = {
    "MainIcon.plist"
  },
  ["AutoFightDlg"] = {
    "skilltext.plist",
    "FightDlg.plist",
    "MainIcon.plist"
  },
  ["AutoFightSettingDlg"] = {
    "FightDlg.plist",
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["AutoFightTalkDlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["AutoTalkDlg"] = {
    "MainIcon.plist"
  },
  ["AutoTalkRuleDlg"] = {
    "MainIcon.plist"
  },
  ["BagDlg"] = {
    "MainIcon.plist",
    "BagDlg.plist"
  },
  ["BagTabDlg"] = {},
  ["BaiCPDlg"] = {
    "MainIcon.plist"
  },
  ["BangpyhDlg"] = {
    "MainIcon.plist"
  },
  ["BangpyhgzDlg"] = {
    "MainIcon.plist"
  },
  ["BangpyhjlDlg"] = {
    "MainIcon.plist"
  },
  ["BangpyhtjDlg"] = {
    "MainIcon.plist"
  },
  ["BanyxhDlg"] = {
    "lingyzmword.plist",
    "MainIcon.plist"
  },
  ["BaoscclDlg"] = {
    "Baosccl.plist",
    "NPCDlg.plist",
    "MainIcon.plist"
  },
  ["BaoscclgmDlg"] = {
    "Baosccl.plist",
    "MainIcon.plist"
  },
  ["BaosjcDlg"] = {
    "MainIcon.plist"
  },
  ["BaosjcRuleDlg"] = {
    "MainIcon.plist"
  },
  ["BaozqyDlg"] = {
    "FightDlg.plist"
  },
  ["BaozqyRuleDlg"] = {},
  ["BarrageSwitchDlg"] = {},
  ["BiggerConfirmDlg"] = {},
  ["BigServerTeamreserveDlg"] = {
    "LoginDlg.plist"
  },
  ["BinghkyDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["BirthdayWishesDlg"] = {
    "MainIcon.plist"
  },
  ["BlankDlg"] = {},
  ["BlogAddressDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["BlogAgreementDlg"] = {
    "MainIcon.plist"
  },
  ["BlogButtonListDlg"] = {
    "MainIcon.plist"
  },
  ["BlogCircleDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["BlogCommentDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["BlogFlowersDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["BlogInfoDlg"] = {
    "FriendChannelDlg.plist",
    "polaricon.plist",
    "MainIcon.plist"
  },
  ["BlogLabelDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["BlogMakeUpDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["BlogMessageDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["BlogMoreInfoDlg"] = {
    "MainIcon.plist",
    "polaricon.plist"
  },
  ["BlogPhotoConfirmDlg"] = {
    "FriendChannelDlg.plist",
    "polaricon.plist"
  },
  ["BlogPhotoDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["BlogRecordDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["BlogSignDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["BlogStateDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["BlogTabDlg"] = {},
  ["BoBingDlg"] = {
    "bobing.plist",
    "MainIcon.plist"
  },
  ["BoBingInfoDlg"] = {
    "MainIcon.plist",
    "bobing.plist"
  },
  ["BonusInfo2Dlg"] = {
    "MainIcon.plist"
  },
  ["BonusInfo3Dlg"] = {
    "MainIcon.plist"
  },
  ["BonusInfoDlg"] = {
    "MainIcon.plist"
  },
  ["BookCommentDlg"] = {
    "MainIcon.plist"
  },
  ["BridgeMailDlg"] = {},
  ["BridgeTaskDlg"] = {
    "MainIcon.plist"
  },
  ["CalcMasterDlg"] = {},
  ["CallBackDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["CallMemberDlg"] = {
    "MainIcon.plist"
  },
  ["CaseBYEFJadeDlg"] = {
    "CaseBYEF.plist"
  },
  ["CaseCipherDlg"] = {
    "MainIcon.plist"
  },
  ["CaseEvidenceDlg"] = {
    "MainIcon.plist"
  },
  ["CaseMailDlg"] = {},
  ["CaseQZKZCupboardDlg"] = {
    "CaseQZKZ.plist",
    "DramaDlg.plist"
  },
  ["CaseQZKZGameDlg"] = {
    "CaseQZKZ.plist",
    "DramaDlg.plist"
  },
  ["CaseQZKZNoticeDlg"] = {
    "CaseQZKZ.plist",
    "DramaDlg.plist"
  },
  ["CaseQZKZPaint1Dlg"] = {
    "PictureScrollImage.plist",
    "DramaDlg.plist",
    "CaseSMFJ.plist"
  },
  ["CaseQZKZPaint2Dlg"] = {
    "PictureScrollImage.plist",
    "DramaDlg.plist",
    "CaseSMFJ.plist"
  },
  ["CaseQZKZPaint3Dlg"] = {
    "DramaDlg.plist",
    "CaseSMFJ.plist"
  },
  ["CaseQZKZPaint4Dlg"] = {
    "PictureScrollImage.plist",
    "DramaDlg.plist",
    "CaseSMFJ.plist"
  },
  ["CaseQZKZPaperDlg"] = {
    "DramaDlg.plist"
  },
  ["CaseQZKZPillarDlg"] = {
    "CaseQZKZ.plist",
    "DramaDlg.plist"
  },
  ["CaseQZKZRosterDlg"] = {
    "CaseCSST.plist",
    "DramaDlg.plist"
  },
  ["CaseQZKZWinePutDlg"] = {
    "CaseQZKZ.plist",
    "DramaDlg.plist"
  },
  ["CaseQZKZWorkDlg"] = {
    "CaseQZKZ.plist",
    "DramaDlg.plist"
  },
  ["CaseQZKZZitherDlg"] = {
    "FriendChannelDlg.plist",
    "CaseQZKZ.plist",
    "DramaDlg.plist"
  },
  ["CaseRankingListDlg"] = {
    "MainIcon.plist"
  },
  ["CaseRunGameDlg"] = {
    "MainIcon.plist"
  },
  ["CaseSMFJBoxKeyDlg"] = {
    "DramaDlg.plist",
    "CaseSMFJ.plist"
  },
  ["CaseSMFJFlowerPictureDlg"] = {
    "DramaDlg.plist",
    "PictureScrollImage.plist",
    "CaseSMFJ.plist"
  },
  ["CaseSMFJItemDlg"] = {
    "MainIcon.plist"
  },
  ["CaseSMFJMagicCircleDlg"] = {
    "DramaDlg.plist",
    "CaseSMFJ.plist"
  },
  ["CaseSMFJVoiceKeyDlg"] = {
    "DramaDlg.plist",
    "PictureScrollImage.plist",
    "CaseSMFJ.plist"
  },
  ["CaseSMFJWomanPictureDlg"] = {
    "DramaDlg.plist",
    "PictureScrollImage.plist",
    "CaseSMFJ.plist"
  },
  ["CaseTWArrayDlg"] = {},
  ["CaseTWBoxDlg"] = {},
  ["CaseTWMailDlg"] = {},
  ["CaseTWPaperDlg"] = {},
  ["CaseTWPiecingDlg"] = {},
  ["CaseTWSpellDlg"] = {
    "MainIcon.plist"
  },
  ["CaseWDGameDlg"] = {
    "MainIcon.plist"
  },
  ["CaseWDTalkDlg"] = {
    "DramaDlg.plist"
  },
  ["ChallengingLeaderDlg"] = {
    "MainIcon.plist"
  },
  ["ChangeCardBagDlg"] = {
    "MainIcon.plist",
    "BagDlg.plist"
  },
  ["ChangeCardIllustrationDlg"] = {
    "MainIcon.plist"
  },
  ["ChangeCardInfoDlg"] = {
    "MainIcon.plist"
  },
  ["ChangeCardRuleDlg"] = {},
  ["ChangeColorDlg"] = {},
  ["ChangePolarDlg"] = {
    "MainIcon.plist",
    "LoginDlg.plist"
  },
  ["ChangePolarDoneDlg"] = {
    "MainIcon.plist"
  },
  ["ChangyjjDlg"] = {},
  ["ChannelDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["ChannelSetDlg"] = {
    "MainIcon.plist"
  },
  ["CharDelDlg"] = {
    "MainIcon.plist"
  },
  ["ChargeDrawGiftRuleDlg"] = {
    "MainIcon.plist"
  },
  ["ChargeGiftPerMonthDlg"] = {
    "MainIcon.plist"
  },
  ["ChargePointBuyItemDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["ChargePointDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["ChargeStoneBuyItemDlg"] = {
    "MainIcon.plist"
  },
  ["CharMenuContentDlg"] = {
    "MainIcon.plist"
  },
  ["CharPortraitDlg"] = {
    "MainIcon.plist"
  },
  ["CharToBabyDlg"] = {},
  ["ChaseInTownDlg"] = {},
  ["ChatDecorateDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["ChatDlg"] = {
    "MainIcon.plist"
  },
  ["ChatHornDlg"] = {
    "MainIcon.plist"
  },
  ["CheckChangeChildDlg"] = {},
  ["CheckChangeXianMoDlg"] = {},
  ["CheekFarmDlg"] = {},
  ["ChengweiXuanzeDlg"] = {
    "MainIcon.plist"
  },
  ["ChildAllRuleDlg"] = {},
  ["ChildAutoAddPointDlg"] = {
    "MainIcon.plist"
  },
  ["ChildBirthDlg"] = {
    "MainIcon.plist"
  },
  ["ChildBirthResultDlg"] = {
    "MainIcon.plist"
  },
  ["ChildBuyStrengthDlg"] = {
    "MainIcon.plist"
  },
  ["ChildCardDlg"] = {
    "MainIcon.plist"
  },
  ["ChildDailyMission1Dlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["ChildDailyMission2Dlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["ChildDailyMission3Dlg"] = {
    "MainIcon.plist"
  },
  ["ChildDailyMission5Dlg"] = {
    "MainIcon.plist"
  },
  ["ChildFlyDoneDlg"] = {
    "MainIcon.plist"
  },
  ["ChildFlyItemDlg"] = {
    "MainIcon.plist"
  },
  ["ChildIntimacyInfoDlg"] = {
    "MainIcon.plist"
  },
  ["ChildIntimacyRuleDlg"] = {
    "MainIcon.plist"
  },
  ["ChildrenDayDlg"] = {
    "MainIcon.plist"
  },
  ["ChildRuleDlg"] = {
    "MainIcon.plist"
  },
  ["ChildSkillDlg"] = {
    "MainIcon.plist"
  },
  ["ChildStoreMoneyDlg"] = {
    "mall_cash.plist",
    "MainIcon.plist"
  },
  ["ChongyangdgqxDlg"] = {
    "MainIcon.plist"
  },
  ["ChongYangFoodDlg"] = {
    "MainIcon.plist"
  },
  ["ChongyangfzlrDlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["ChooseFishToolDlg"] = {
    "MainIcon.plist"
  },
  ["ChooseItemDlg"] = {
    "MainIcon.plist"
  },
  ["ChoseAtkDlg"] = {},
  ["ChoseDressDlg"] = {
    "MainIcon.plist"
  },
  ["ChunjieNianyefanDlg"] = {
    "MainIcon.plist"
  },
  ["ChunjieRedBagDlg"] = {
    "MainIcon.plist"
  },
  ["ChunjieRedBagDlgRuleDlg"] = {
    "MainIcon.plist"
  },
  ["CityFriendDlg"] = {
    "FriendChannelDlg.plist",
    "polaricon.plist",
    "MainIcon.plist"
  },
  ["CityFriendOperationDlg"] = {
    "FriendChannelDlg.plist",
    "polaricon.plist",
    "MainIcon.plist"
  },
  ["CityFriendVerificationDlg"] = {
    "MainIcon.plist"
  },
  ["CityFriendVerifyOperateDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist",
    "polaricon.plist"
  },
  ["CityInfoDlg"] = {
    "FriendChannelDlg.plist",
    "polaricon.plist",
    "MainIcon.plist"
  },
  ["CityNearbyDlg"] = {
    "FriendChannelDlg.plist",
    "polaricon.plist",
    "MainIcon.plist"
  },
  ["CityRankingDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["CityTabDlg"] = {},
  ["CoagulationChildDlg"] = {
    "MainIcon.plist"
  },
  ["CockFightingDlg"] = {
    "CockFightImage.plist"
  },
  ["CockFightingResultDlg"] = {},
  ["CockFightingRuleDlg"] = {},
  ["CombatResultDlg"] = {
    "MainIcon.plist"
  },
  ["CombatStatusDlg"] = {
    "MainIcon.plist",
    "polaricon.plist"
  },
  ["CombatViewDlg"] = {
    "MainIcon.plist"
  },
  ["CombatView_TestDlg"] = {
    "MainIcon.plist"
  },
  ["CombinedServiceTaskDlg"] = {
    "MainIcon.plist",
    "WelfareDlg.plist"
  },
  ["CommunityDlg"] = {},
  ["CommunitySmallVideoDlg"] = {},
  ["Confirm2Dlg"] = {
    "MainIcon.plist"
  },
  ["Confirm3Dlg"] = {},
  ["ConfirmDlg"] = {
    "MainIcon.plist"
  },
  ["ControlDlg"] = {},
  ["ConvenientBuyDlg"] = {
    "MainIcon.plist"
  },
  ["ConvenientCallGuardDlg"] = {},
  ["ConvenientEquipmentDlg"] = {},
  ["ConversionCodeDlg"] = {
    "MainIcon.plist"
  },
  ["CountDownDlg"] = {
    "FightDlg.plist"
  },
  ["CreateCharDlg"] = {
    "polaricon.plist"
  },
  ["CreatePartyDlg"] = {
    "MainIcon.plist"
  },
  ["CrossRankingListDlg"] = {
    "MainIcon.plist"
  },
  ["CustomDressCollectDlg"] = {
    "BagDlg.plist",
    "MainIcon.plist"
  },
  ["CustomDressDlg"] = {
    "MainIcon.plist",
    "BagDlg.plist"
  },
  ["CustomDressShowDlg"] = {
    "MainIcon.plist"
  },
  ["DailySignDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["DaluandoudzlsDlg"] = {
    "MainIcon.plist"
  },
  ["DaluandouppDlg"] = {
    "MainIcon.plist"
  },
  ["DaluandouRuleDlg"] = {},
  ["DaluandouScCardDlg"] = {
    "MainIcon.plist"
  },
  ["DaluandouscDlg"] = {
    "MainIcon.plist"
  },
  ["DaluandouScRuleDlg"] = {
    "MainIcon.plist"
  },
  ["DaluandouscxqDlg"] = {},
  ["DaluandousxqhDlg"] = {
    "MainIcon.plist"
  },
  ["DaluandoutjDlg"] = {
    "MainIcon.plist"
  },
  ["DaluandouzjmDlg"] = {
    "MainIcon.plist"
  },
  ["DaluandouzmscDlg"] = {},
  ["DeadRemindDlg"] = {
    "MainIcon.plist"
  },
  ["DeathRecordDlg"] = {
    "MainIcon.plist"
  },
  ["DebugDlg"] = {
    "MainIcon.plist"
  },
  ["DebugNPCCreateDlg"] = {},
  ["DebugNPCPosMangeDlg"] = {},
  ["DefendSnowfieldCardDlg"] = {
    "TeamDlg.plist"
  },
  ["DemonOrderDlg"] = {},
  ["DesignatedUserDlg"] = {
    "MainIcon.plist"
  },
  ["DiFuJingJiRuleDlg"] = {},
  ["DiFuPointDlg"] = {
    "MainIcon.plist"
  },
  ["DijFinishDlg"] = {
    "MainIcon.plist"
  },
  ["DiscountDlg"] = {
    "MainIcon.plist"
  },
  ["DivorceDlg"] = {
    "MainIcon.plist"
  },
  ["DiYuShenYuanDlg"] = {
    "lingyzmword.plist",
    "MainIcon.plist"
  },
  ["DonateDlgDlg"] = {
    "MainIcon.plist"
  },
  ["DossierDlg"] = {
    "MainIcon.plist"
  },
  ["DossierTipsDlg"] = {
    "MainIcon.plist"
  },
  ["DoubleChargeDrawGiftDlg"] = {},
  ["DramaDlg"] = {
    "DramaDlg.plist"
  },
  ["DrawCharmDlg"] = {},
  ["DropDoubleDlg"] = {
    "MainIcon.plist"
  },
  ["DugeonCreateDlg"] = {
    "MainIcon.plist"
  },
  ["DugeonRuleDlg"] = {
    "MainIcon.plist"
  },
  ["DugeonVoteDlg"] = {
    "MainIcon.plist"
  },
  ["EatFruitDlg"] = {
    "TianGFingerGame.plist"
  },
  ["EditPartyCommonNotifyDlg"] = {},
  ["EffectFurnitureDlg"] = {
    "MainIcon.plist"
  },
  ["EffectFurnitureRuleDlg"] = {
    "MainIcon.plist"
  },
  ["EightImmortalsDlg"] = {
    "EightImmortalsDlg.plist",
    "MainIcon.plist"
  },
  ["ElitePetShopDlg"] = {
    "MainIcon.plist"
  },
  ["EquipArtificeGuideDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipEvolutionGuideDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipmentChangePolarDlg"] = {
    "MainIcon.plist",
    "polaricon.plist"
  },
  ["EquipmentChildDlg"] = {
    "EquipDlg.plist",
    "MainIcon.plist"
  },
  ["EquipmentDegenerationDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentEvolveDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipmentFloatingFrameDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentIdentifyDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentIdentifyShowDlg"] = {},
  ["EquipmentInfoCampareDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentInheritDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentOneClickUpgradeDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentRefiningAttributeDlg"] = {},
  ["EquipmentRefiningDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipmentRefiningGongmingDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentRefiningPinkDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentRefiningSuitDlg"] = {
    "MainIcon.plist",
    "polaricon.plist",
    "EquipDlg.plist"
  },
  ["EquipmentRefiningYellowDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentReformDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipmentRuleAttributeDlg"] = {},
  ["EquipmentRuleDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentRuleNewDegenerationDlg"] = {},
  ["EquipmentRuleNewDlg"] = {},
  ["EquipmentRuleNewEvovleDlg"] = {},
  ["EquipmentRuleNewFirstPageDlg"] = {
    "EquipDlg.plist"
  },
  ["EquipmentRuleNewGongmingDlg"] = {
    "EquipDlg.plist"
  },
  ["EquipmentRuleNewInheritDlg"] = {},
  ["EquipmentRuleNewRefiningDlg"] = {
    "EquipDlg.plist"
  },
  ["EquipmentRuleNewRefiningPinkDlg"] = {},
  ["EquipmentRuleNewRefiningYellowDlg"] = {},
  ["EquipmentRuleNewReformDlg"] = {},
  ["EquipmentRuleNewSplitDlg"] = {},
  ["EquipmentRuleNewStrengthenDlg"] = {},
  ["EquipmentRuleNewSuitDlg"] = {
    "EquipDlg.plist"
  },
  ["EquipmentRuleNewUpgradeDlg"] = {},
  ["EquipmentRuleRecommendDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentSelectCrystalDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentSelectDlg"] = {
    "EquipDlg.plist"
  },
  ["EquipmentSplitDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipmentStrengthenDlg"] = {
    "MainIcon.plist"
  },
  ["EquipmentTabDlg"] = {},
  ["EquipmentUpgradeDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipmentUpgradeResultDlg"] = {},
  ["EquipRecombinationGuideDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipReformGuideDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipSplitGuideDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipStrengthenGuideDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipSuitGuideDlg"] = {
    "MainIcon.plist",
    "EquipDlg.plist"
  },
  ["EquipXiangXingGuideDlg"] = {
    "MainIcon.plist",
    "polaricon.plist"
  },
  ["ExchangeByDlg"] = {
    "MainIcon.plist"
  },
  ["ExchangeMementoDlg"] = {
    "MainIcon.plist"
  },
  ["ExplockDlg"] = {},
  ["ExplockExDlg"] = {},
  ["ExpStoreHouseDlg"] = {
    "MainIcon.plist"
  },
  ["ExpStoreHouseRuleDlg"] = {
    "MainIcon.plist"
  },
  ["FaBaoChangeDlg"] = {
    "MainIcon.plist"
  },
  ["FamousAccountDlg"] = {},
  ["FamousDlg"] = {},
  ["FamousRedBagDlg"] = {
    "MainIcon.plist"
  },
  ["FamousRedBagRewardDlg"] = {
    "MainIcon.plist"
  },
  ["FamousStoreDlg"] = {},
  ["FashionDressInfoDlg"] = {
    "MainIcon.plist"
  },
  ["FastUseItemDlg"] = {},
  ["FestivalGameResultDlg"] = {
    "MainIcon.plist"
  },
  ["FightCallPetMenuDlg"] = {
    "FightDlg.plist"
  },
  ["FightChildSkillDlg"] = {
    "FightDlg.plist",
    "skilltext.plist"
  },
  ["FightCommanderCmdEditDlg"] = {
    "MainIcon.plist"
  },
  ["FightCommanderCmdInputDlg"] = {
    "MainIcon.plist"
  },
  ["FightCommanderSetDlg"] = {
    "MainIcon.plist"
  },
  ["FightInfDlg"] = {
    "FightLookDlg.plist",
    "skilltext.plist",
    "polaricon.plist"
  },
  ["FightLookOnDlg"] = {
    "FightLookDlg.plist",
    "FightDlg.plist"
  },
  ["FightPetMenuDlg"] = {
    "FightDlg.plist",
    "MainIcon.plist"
  },
  ["FightPetSkillDlg"] = {
    "FightDlg.plist",
    "skilltext.plist"
  },
  ["FightPlayerMenuDlg"] = {
    "FightDlg.plist",
    "MainIcon.plist"
  },
  ["FightPlayerSkillDlg"] = {
    "FightDlg.plist",
    "skilltext.plist"
  },
  ["FightRecordDlg"] = {
    "FightDlg.plist",
    "MainIcon.plist"
  },
  ["FightRoundDlg"] = {
    "MainIcon.plist",
    "FightDlg.plist"
  },
  ["FightTargetChoseDlg"] = {
    "FightDlg.plist",
    "MainIcon.plist"
  },
  ["FightUseResDlg"] = {
    "MainIcon.plist",
    "FightDlg.plist"
  },
  ["FireworksCeremonyDlg"] = {
    "FireworksCeremonyDlg.plist"
  },
  ["FireworksCeremonyRuleDlg"] = {},
  ["FireworksCountdownDlg"] = {
    "FightDlg.plist",
    "MainIcon.plist"
  },
  ["FireworksFunctionDlg"] = {
    "MainIcon.plist"
  },
  ["FireworksMainDlg"] = {},
  ["FireworksRewardDlg"] = {},
  ["FireworksStatisticsDlg"] = {},
  ["FirstChargeGiftDlg"] = {},
  ["FixedTeamEffortDlg"] = {
    "FixedTeamReward.plist"
  },
  ["FloatingFrameDlg"] = {
    "MainIcon.plist"
  },
  ["FloatingMenuDlg"] = {
    "MainIcon.plist"
  },
  ["FlockMoveDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["FlockTagsDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["FlowerBuyDlg"] = {},
  ["ForerunnerGiftDlg"] = {
    "WelfareDlg.plist"
  },
  ["ForerunnerProposalDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["ForerunnerTabDlg"] = {},
  ["ForerunnerTaskDlg"] = {},
  ["ForeverCustomTitleDlg"] = {
    "MainIcon.plist"
  },
  ["FriendBoxDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["FriendDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist",
    "LoginDlg.plist"
  },
  ["FriendInstallDlg"] = {
    "MainIcon.plist"
  },
  ["FriendOperationDlg"] = {
    "MainIcon.plist"
  },
  ["FriendVerifyOperateDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["FrozenGoldDlg"] = {
    "MainIcon.plist"
  },
  ["FrozenMoneyDlg"] = {
    "MainIcon.plist"
  },
  ["FubenMissionDlg"] = {
    "MainIcon.plist"
  },
  ["FubenMissionForBaWangDlg"] = {
    "MainIcon.plist"
  },
  ["FubenMissionForDFJJDlg"] = {
    "MainIcon.plist"
  },
  ["FubenMissionForFestivalDlg"] = {
    "MainIcon.plist"
  },
  ["FubenMissionForHulylDlg"] = {
    "MainIcon.plist"
  },
  ["FubenMissionForTongtiantaDlg"] = {
    "MainIcon.plist"
  },
  ["Funny1Dlg"] = {},
  ["Funny2Dlg"] = {},
  ["Funny3Dlg"] = {},
  ["Funny4Dlg"] = {},
  ["Funny5Dlg"] = {},
  ["Funny6Dlg"] = {},
  ["FurnitureBuyDlg"] = {
    "MainIcon.plist"
  },
  ["FurnitureInfoDlg"] = {
    "MainIcon.plist"
  },
  ["FurnitureListDlg"] = {
    "MainIcon.plist"
  },
  ["FurnitureMakeDlg"] = {},
  ["FurniturePuttingDlg"] = {},
  ["Game21PointDlg"] = {
    "MainIcon.plist",
    "bobing.plist"
  },
  ["Game21PointRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GameFunctionDlg"] = {
    "MainIcon.plist"
  },
  ["GameResultDlg"] = {
    "MainIcon.plist",
    "lingyzmword.plist"
  },
  ["GatherBankDlg"] = {
    "MainIcon.plist"
  },
  ["GatherChannelDlg"] = {},
  ["GatherInfoDlg"] = {},
  ["GatherPhoneDlg"] = {},
  ["GatherPrivilegeDlg"] = {},
  ["GatherRewardDlg"] = {},
  ["GeneralGuideDlg"] = {},
  ["GeneralNoTitleRuleDlg"] = {},
  ["GeneralRuleDlg"] = {},
  ["GetCelestialDlg"] = {
    "MainIcon.plist"
  },
  ["GetElitePetDlg"] = {
    "MainIcon.plist"
  },
  ["GetElitePetModifyDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["GetItemDlg"] = {},
  ["GetKidsDlg"] = {
    "MainIcon.plist"
  },
  ["GetMoreKeysDlg"] = {
    "MainIcon.plist"
  },
  ["GetPartyRedBagRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GetPetDlg"] = {
    "MainIcon.plist"
  },
  ["GetRewardDlg"] = {},
  ["GetTaoBuyDlg"] = {
    "MainIcon.plist"
  },
  ["GetTaoCashBuyDlg"] = {
    "MainIcon.plist"
  },
  ["GetTaoDlg"] = {
    "GetTaoDlg.plist",
    "MainIcon.plist"
  },
  ["GetTaoOfflineDlg"] = {
    "MainIcon.plist"
  },
  ["GetTaoPointDlg"] = {
    "MainIcon.plist",
    "GetTaoDlg.plist"
  },
  ["GetTaoPointRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GetTaoRewardDlg"] = {
    "MainIcon.plist",
    "GetTaoDlg.plist"
  },
  ["GetTaoRuleDlg"] = {},
  ["GetTaoTabDlg"] = {},
  ["GetTaoTrusteeshipDlg"] = {
    "MainIcon.plist",
    "GetTaoDlg.plist"
  },
  ["GetTaoTrusteeshipResultDlg"] = {
    "MainIcon.plist",
    "GetTaoDlg.plist"
  },
  ["GetTaoTrusteeshipRuleDlg"] = {},
  ["GetTaoTrusteeshipSupplyTimeDlg"] = {
    "MainIcon.plist"
  },
  ["GetTogetherDlg"] = {
    "ChongYImage.plist"
  },
  ["GhostGrowPandectDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetCallDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetGongShengDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetGongShengRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetGrowingDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetGrowingRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetGrowTabDlg"] = {},
  ["GhostPetNingShenDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetNingShenRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetPeiYuanDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetPeiYuanRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetYiHunDlg"] = {
    "MainIcon.plist"
  },
  ["GhostPetYiHunRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GiftHandOutDlg"] = {
    "GiftHandOut.plist"
  },
  ["GiftPreviewDlg"] = {
    "MainIcon.plist"
  },
  ["GiveApplyDlg"] = {
    "MainIcon.plist"
  },
  ["GiveDlg"] = {
    "MainIcon.plist"
  },
  ["GiveRecordDlg"] = {
    "MainIcon.plist"
  },
  ["GiveRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GMAccountListDlg"] = {},
  ["GMAccountManageDlg"] = {},
  ["GMBlockAccountDlg"] = {},
  ["GMBlockMacDlg"] = {},
  ["GMBlockUserDlg"] = {},
  ["GMCombatlogDlg"] = {},
  ["GMConfirmDlg"] = {},
  ["GMCrossServiceFightDlg"] = {},
  ["GMDebugTipsDlg"] = {
    "MainIcon.plist"
  },
  ["GMEquipmentCreatDlg"] = {},
  ["GMForbidSpeakingDlg"] = {},
  ["GMItemCreatDlg"] = {},
  ["GMManageDlg"] = {},
  ["GMNPCListDlg"] = {},
  ["GMPetCreatDlg"] = {},
  ["GMPosFileListDlg"] = {},
  ["GMPosListDlg"] = {},
  ["GMProcessListDlg"] = {},
  ["GMQuanmPKFightDlg"] = {},
  ["GMRestrictUserDlg"] = {},
  ["GMRolePropertiesDlg"] = {},
  ["GMStopMonitoringDlg"] = {},
  ["GMTaiyzqDlg"] = {},
  ["GMUserListDlg"] = {},
  ["GMUserManageDlg"] = {},
  ["GMWarningDlg"] = {},
  ["GongcDlg"] = {
    "MainIcon.plist"
  },
  ["GoodDlg"] = {
    "MainIcon.plist"
  },
  ["GoodValueDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceCollectionDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceCommentDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceDetailsDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceExhibitionDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceFlowersDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceJudgesDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceJudgesReviewDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceJudgesScoringDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceJudgesTabDlg"] = {},
  ["GoodVoiceJudgesUploadDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceMineDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoicePastRankingDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceRankingDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceReportDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceReviewDlg"] = {
    "MainIcon.plist"
  },
  ["GoodVoiceRuleDlg"] = {},
  ["GoodVoiceTabDlg"] = {},
  ["GourmandQuarter02Dlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandQuarterBag02Dlg"] = {},
  ["GourmandQuarterBatchDlg"] = {},
  ["GourmandQuarterBKDlg"] = {},
  ["GourmandQuarterFoodTips02Dlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandQuarterGainDlg"] = {},
  ["GourmandQuarterGiftTipsDlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandQuarterMenu02Dlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandQuarterMoenyDlg"] = {},
  ["GourmandQuarterResult01Dlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandQuarterResult02Dlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandQuarterRuleDlg"] = {},
  ["GourmandQuarterRuleInfoDlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandQuarterSearchDlg"] = {},
  ["GourmandQuarterSellDlg"] = {},
  ["GourmandQuarterStore02Dlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandQuarterTabDlg"] = {},
  ["GourmandQuarterTryAction02Dlg"] = {
    "GourmandQuarterImage.plist"
  },
  ["GourmandStrengthRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GrantGiftDlg"] = {
    "MainIcon.plist"
  },
  ["GroceryStoreDlg"] = {
    "MainIcon.plist"
  },
  ["GroupCreateDlg"] = {},
  ["GroupInformationDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["GroupInformationMemberDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["GroupInviteDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist",
    "LoginDlg.plist"
  },
  ["GroupMessageDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["GroupRenameDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["GuanggdbDlg"] = {
    "MainIcon.plist"
  },
  ["GuardAdvanceDlg"] = {
    "MainIcon.plist"
  },
  ["GuardAttribDlg"] = {
    "MainIcon.plist"
  },
  ["GuardDevelop"] = {},
  ["GuardDevelopDlg"] = {
    "MainIcon.plist"
  },
  ["GuardIntimacyInfoDlg"] = {
    "MainIcon.plist"
  },
  ["GuardIntimacyRuleDlg"] = {
    "MainIcon.plist"
  },
  ["GuardListChildDlg"] = {},
  ["GuardSkillDlg"] = {
    "MainIcon.plist"
  },
  ["GuardStrengthDlg"] = {},
  ["GuardTabDlg"] = {},
  ["GuDingDuiFuLiDlg"] = {
    "MainIcon.plist"
  },
  ["GuDingDuiFuLiDuiYDlg"] = {},
  ["HeadChildRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HeadDlg"] = {
    "MainIcon.plist"
  },
  ["HeadPetRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HeadPlayerRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HeadTipsDlg"] = {
    "MainIcon.plist"
  },
  ["HealthAdviceDlg"] = {},
  ["HolidayGiftDlg"] = {
    "MainIcon.plist",
    "WelfareDlg.plist"
  },
  ["HomeBedroomDlg"] = {},
  ["HomeBedroomRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HomeBuyFeedDlg"] = {
    "MainIcon.plist"
  },
  ["HomeCheckDlg"] = {
    "MainIcon.plist"
  },
  ["HomeChooseItemDlg"] = {
    "MainIcon.plist"
  },
  ["HomeCleanDlg"] = {
    "MainIcon.plist"
  },
  ["HomeCookingDlg"] = {
    "MainIcon.plist"
  },
  ["HomeEntrustDlg"] = {},
  ["HomeFishingDlg"] = {
    "MainIcon.plist"
  },
  ["HomeFishingRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HomeInDlg"] = {},
  ["HomeKidDlg"] = {},
  ["HomeMaidsSelectDlg"] = {
    "MainIcon.plist"
  },
  ["HomeManagerDlg"] = {},
  ["HomeMaterialAskDlg"] = {
    "MainIcon.plist"
  },
  ["HomeMaterialGiveDlg"] = {
    "MainIcon.plist"
  },
  ["HomeMaterialTabDlg"] = {},
  ["HomeOtherCheckDlg"] = {
    "MainIcon.plist"
  },
  ["HomePetBubbleDlg"] = {},
  ["HomePetFeedDlg"] = {
    "MainIcon.plist"
  },
  ["HomePetFeedRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HomePlantCheckDlg"] = {},
  ["HomePlantDlg"] = {},
  ["HomePlantHelpDlg"] = {
    "MainIcon.plist"
  },
  ["HomePlantRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HomePlayerPracticeDlg"] = {
    "MainIcon.plist"
  },
  ["HomePracticeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HomePreviewDlg"] = {
    "MainIcon.plist"
  },
  ["HomePuttingDlg"] = {
    "MainIcon.plist"
  },
  ["HomeShowDlg"] = {},
  ["HomeSpaceDlg"] = {
    "MainIcon.plist"
  },
  ["HomeStoreDlg"] = {},
  ["HomeTabDlg"] = {},
  ["HomeTakeCareDlg"] = {
    "MainIcon.plist"
  },
  ["HomeworkDlg"] = {
    "MainIcon.plist"
  },
  ["HomeworkInfoDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxAttriRefineDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxAttriRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxConsumeSubmitDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxEvolveDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxEvovlePropRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxEvovleRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxFloatingFrameCampareDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxFloatingFrameDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxListDlg"] = {},
  ["HorcruxRefiningDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxSkillDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxSkillRuleDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxSubmitDlg"] = {
    "MainIcon.plist"
  },
  ["HorcruxTabDlg"] = {},
  ["HornAprilFoolsDayDlg"] = {
    "MainIcon.plist"
  },
  ["HornDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["HornRecordDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["HotWaveEditorDlg"] = {
    "GraphEditor.plist"
  },
  ["HUDBulletScreenDlg"] = {
    "MainIcon.plist"
  },
  ["HulylDlg"] = {
    "TZHJChildrenDayImage.plist",
    "FightDlg.plist"
  },
  ["HulylRewardDlg"] = {},
  ["HulylRuleDlg"] = {},
  ["HunQiaoDlg"] = {
    "MainIcon.plist"
  },
  ["HunQiaoFillDlg"] = {
    "MainIcon.plist"
  },
  ["HuoyxzDlg"] = {
    "HuoyxzDlg.plist"
  },
  ["HuoyxzResultDlg"] = {
    "MainIcon.plist"
  },
  ["HuoyxzRuleDlg"] = {
    "HuoyxzDlg.plist"
  },
  ["IdentifyPriceDlg"] = {},
  ["InnElevateDlg"] = {
    "InnMainDlg.plist",
    "MainIcon.plist"
  },
  ["InnerAlchemyDlg"] = {
    "CharDlg.plist",
    "MainIcon.plist"
  },
  ["InnEventDlg"] = {
    "InnMainDlg.plist"
  },
  ["InnMainDlg"] = {
    "InnMainDlg.plist",
    "MainIcon.plist"
  },
  ["InnMainRuleDlg"] = {
    "MainIcon.plist"
  },
  ["InnManualDlg"] = {
    "MainIcon.plist",
    "InnMainDlg.plist"
  },
  ["InnRenameDlg"] = {
    "InnMainDlg.plist"
  },
  ["InnRuleDlg"] = {
    "InnMainDlg.plist"
  },
  ["InnTongbaoExchangeDlg"] = {},
  ["InsteadCommonWordDlg"] = {
    "MainIcon.plist"
  },
  ["InvadeBuyDlg"] = {
    "MainIcon.plist"
  },
  ["InvadeDlg"] = {
    "MainIcon.plist"
  },
  ["InvadeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["InviteJoinPartyDlg"] = {
    "MainIcon.plist"
  },
  ["ItemDecomposeDlg"] = {
    "MainIcon.plist"
  },
  ["ItemDelDlg"] = {
    "MainIcon.plist"
  },
  ["ItemInfoDlg"] = {
    "MainIcon.plist"
  },
  ["ItemPuttingDlg"] = {},
  ["ItemRecourseDlg"] = {
    "MainIcon.plist"
  },
  ["JewelryChangeDlg"] = {
    "JewelryDlg.plist",
    "MainIcon.plist"
  },
  ["JewelryChangeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["JewelryConfirmDlg"] = {
    "MainIcon.plist"
  },
  ["JewelryDecomposeDlg"] = {
    "JewelryDlg.plist",
    "MainIcon.plist"
  },
  ["JewelryDevelopDlg"] = {
    "JewelryDlg.plist",
    "MainIcon.plist"
  },
  ["JewelryDevelopRuleDlg"] = {
    "MainIcon.plist"
  },
  ["JewelryInfoCampareDlg"] = {
    "MainIcon.plist"
  },
  ["JewelryInfoDlg"] = {
    "MainIcon.plist"
  },
  ["JewelryNewRefineDlg"] = {
    "JewelryDlg.plist",
    "MainIcon.plist"
  },
  ["JewelryNewRefineRuleDlg"] = {
    "MainIcon.plist"
  },
  ["JewelryRefineDlg"] = {
    "JewelryDlg.plist",
    "MainIcon.plist"
  },
  ["JewelryRefineRuleDlg"] = {
    "MainIcon.plist"
  },
  ["JewelryShowDlg"] = {
    "MainIcon.plist",
    "JewelryDlg.plist"
  },
  ["JewelryTabDlg"] = {},
  ["JewelryUpgradeDlg"] = {
    "JewelryDlg.plist",
    "MainIcon.plist"
  },
  ["JewelryUpgradeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["JewerlyRuleNewDlg"] = {
    "JewelryDlg.plist"
  },
  ["JiaoSx1Dlg"] = {},
  ["JiaoSx2Dlg"] = {},
  ["JiaoSxDlg"] = {
    "MainIcon.plist"
  },
  ["JiarpmDlg"] = {
    "MainIcon.plist"
  },
  ["JiebSetTitleDlg"] = {
    "MainIcon.plist"
  },
  ["JiebSortOrderDlg"] = {
    "MainIcon.plist"
  },
  ["JiebVoteDlg"] = {},
  ["JiehkmhDlg"] = {
    "MainIcon.plist"
  },
  ["JigsawPuzzleDlg"] = {},
  ["JinszJigsawPuzzleDlg"] = {
    "CaseJNSZ.plist",
    "DramaDlg.plist"
  },
  ["JinszmcDlg"] = {
    "DramaDlg.plist"
  },
  ["JinszsxDlg"] = {
    "DramaDlg.plist",
    "CaseJNSZ.plist"
  },
  ["JinszxsDlg"] = {
    "MainIcon.plist"
  },
  ["JinszysDlg"] = {},
  ["JiucDlg"] = {},
  ["JiuTianBuffDlg"] = {},
  ["JiuTianDlg"] = {
    "MainIcon.plist"
  },
  ["JoinPartyDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["JuBaoCashOperateDlg"] = {
    "MainIcon.plist"
  },
  ["JuBaoCashSellDlg"] = {
    "MainIcon.plist",
    "JuBaoDlg.plist"
  },
  ["JuBaoEquipOperateDlg"] = {
    "MainIcon.plist",
    "JuBaoDlg.plist"
  },
  ["JuBaoEquipSellDlg"] = {
    "MainIcon.plist",
    "JuBaoDlg.plist"
  },
  ["JuBaoGoodSellTabDlg"] = {
    "JuBaoDlg.plist"
  },
  ["JuBaoPetOperateDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["JuBaoPetSellDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["JuBaoSellConfirmDlg"] = {},
  ["JubaoTradeRecordDlg"] = {
    "MainIcon.plist"
  },
  ["JuBaoUserChangeDeviceDlg"] = {
    "MainIcon.plist"
  },
  ["JuBaoUserViewBagDlg"] = {
    "MainIcon.plist",
    "JuBaoDlg.plist"
  },
  ["JuBaoUserViewGuardDlg"] = {
    "MainIcon.plist"
  },
  ["JuBaoUserViewHomeDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["JuBaoUserViewPetDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["JuBaoUserViewSelfDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["JuBaoUserViewTabDlg"] = {
    "JuBaoDlg.plist"
  },
  ["JuBaoViewCashDlg"] = {
    "MainIcon.plist"
  },
  ["JuBaoViewDesignatedEquipDlg"] = {
    "MainIcon.plist"
  },
  ["JuBaoViewEquipDlg"] = {
    "MainIcon.plist"
  },
  ["JuBaoViewPetDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["JuBaoZhaiNoteDlg"] = {
    "JuBaoDlg.plist"
  },
  ["JuBaoZhaiSellDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["JuBaoZhaiStorageDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["JuBaoZhaiTabDlg"] = {},
  ["JuBaoZhaiVendueDlg"] = {
    "JuBaoDlg.plist",
    "MainIcon.plist"
  },
  ["KidApprenticeDlg"] = {
    "MainIcon.plist"
  },
  ["KidApprenticeDoneDlg"] = {
    "MainIcon.plist"
  },
  ["KidCultureDlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["KidInfoDlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["KidProgressDlg"] = {},
  ["KidRearingDlg"] = {
    "MainIcon.plist"
  },
  ["KidScheduleRecordDlg"] = {
    "MainIcon.plist"
  },
  ["KidsCreateDlg"] = {
    "MainIcon.plist"
  },
  ["KidToysDurableDlg"] = {},
  ["KuafbzgzDlg"] = {},
  ["KuafbzscDlg"] = {
    "MainIcon.plist"
  },
  ["KuafbzsjDlg"] = {},
  ["KuafbzTabDlg"] = {},
  ["KuafbzzkDlg"] = {
    "MainIcon.plist"
  },
  ["KuafjjdwDlg"] = {},
  ["KuafjjgnDlg"] = {
    "MainIcon.plist"
  },
  ["KuafjjgzDlg"] = {},
  ["KuafjjInfoDlg"] = {},
  ["KuafjjjfDlg"] = {
    "MainIcon.plist"
  },
  ["KuafjjjlDlg"] = {
    "MainIcon.plist"
  },
  ["KuafjjjsDlg"] = {
    "MainIcon.plist"
  },
  ["KuafjjljDlg"] = {
    "MainIcon.plist"
  },
  ["KuafjjscDlg"] = {
    "MainIcon.plist"
  },
  ["KuafjjsxDlg"] = {
    "polaricon.plist"
  },
  ["KuafjjTabDlg"] = {},
  ["KuafsdgzDlg"] = {},
  ["KuafsdInfoDlg"] = {
    "MainIcon.plist"
  },
  ["KuafsdsqfpDlg"] = {
    "MainIcon.plist"
  },
  ["KuafsdTabDlg"] = {},
  ["KuafsdwzDlg"] = {
    "MainIcon.plist"
  },
  ["KuaFuShiDaoRuleDlg"] = {
    "MainIcon.plist"
  },
  ["KuafzcgzDlg"] = {},
  ["KuafzcInfoDlg"] = {
    "MainIcon.plist"
  },
  ["KuafzcjfDlg"] = {
    "MainIcon.plist"
  },
  ["KuafzcjlDlg"] = {
    "MainIcon.plist"
  },
  ["KuafzcscDlg"] = {
    "MainIcon.plist"
  },
  ["KuafzcsjDlg"] = {},
  ["KuafzcTabDlg"] = {},
  ["KuafzczkDlg"] = {
    "MainIcon.plist"
  },
  ["KuanianDlg"] = {
    "FightDlg.plist",
    "MainIcon.plist"
  },
  ["LangmqgDlg"] = {
    "MainIcon.plist"
  },
  ["LangmqgMakeDlg"] = {},
  ["LanternFestivalChessDlg"] = {
    "MainIcon.plist",
    "WatchCentreDlg.plist"
  },
  ["LanternGuessDlg"] = {},
  ["LayGiftDlg"] = {
    "MainIcon.plist"
  },
  ["LeiTaiBaWangDlg"] = {},
  ["LeiTaiBaWangPkListDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["LeiTaiBaWangRankDlg"] = {
    "MainIcon.plist",
    "FriendChannelDlg.plist"
  },
  ["LeiTaiBaWangSetDlg"] = {
    "MainIcon.plist"
  },
  ["LeiTaiBaWangTabDlg"] = {},
  ["LineUpChangeChannelDlg"] = {
    "TianggkwImage.plist",
    "VIPImage.plist"
  },
  ["LineUpDlg"] = {
    "LoginDlg.plist"
  },
  ["LineUpSowVIPRuleDlg"] = {
    "LoginDlg.plist"
  },
  ["LingchenShopDlg"] = {
    "MainIcon.plist"
  },
  ["LingChongDlg"] = {
    "LingChongDlg.plist",
    "MainIcon.plist"
  },
  ["LingChongOrderDlg"] = {
    "LingChongDlg.plist",
    "skilltext.plist",
    "MainIcon.plist"
  },
  ["LingyzmDlg"] = {
    "MainIcon.plist",
    "lingyzmword.plist"
  },
  ["LingzkyDlg"] = {},
  ["LinkAndExpressionDlg"] = {
    "MainIcon.plist"
  },
  ["LittleNumInputDlg"] = {
    "MainIcon.plist"
  },
  ["LoadingDlg"] = {},
  ["LoadingFailedDlg"] = {
    "MainIcon.plist"
  },
  ["LockScreenDlg"] = {},
  ["LoginAnnouncementDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginChangeDistDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginConnectDlg"] = {},
  ["LoginForbidRedHandDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginForbidSimulatorDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginForceUpdateDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginJubzSaleInfoDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginNewDistActiveDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginOperateDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginPreviewDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginSilenceDlg"] = {
    "LoginDlg.plist",
    "SilenceLoginDlg.plist"
  },
  ["LoginUnSilenceDlg"] = {
    "LoginDlg.plist"
  },
  ["LoginUserRenameDlg"] = {
    "MainIcon.plist"
  },
  ["LoginWaitDlg"] = {
    "MainIcon.plist",
    "LoginWaitDlg.plist"
  },
  ["LonghzbgzDlg"] = {},
  ["LonghzbInfoDlg"] = {
    "MainIcon.plist"
  },
  ["LonghzbscDlg"] = {
    "MainIcon.plist"
  },
  ["LonghzbsjDlg"] = {
    "MainIcon.plist"
  },
  ["LonghzbTabDlg"] = {},
  ["LonghzbTeamInfoDlg"] = {
    "MainIcon.plist"
  },
  ["LonghzbycczDlg"] = {
    "MainIcon.plist"
  },
  ["LonghzbycDlg"] = {
    "MainIcon.plist"
  },
  ["LookonManageDlg"] = {
    "MainIcon.plist"
  },
  ["LordLaoZiDlg"] = {
    "MainIcon.plist"
  },
  ["LordLaoZiMemberDlg"] = {
    "MainIcon.plist"
  },
  ["LordLaoZiRuleDlg"] = {
    "MainIcon.plist"
  },
  ["LotteryTabDlg"] = {},
  ["LotteryTicketBonusRankDlg"] = {},
  ["LotteryTicketBuyDlg"] = {
    "MainIcon.plist"
  },
  ["LotteryTicketDataDlg"] = {
    "tiandqf.plist"
  },
  ["LotteryTicketHistoryDlg"] = {
    "tiandqf.plist"
  },
  ["LotteryTicketMySelfDlg"] = {
    "tiandqf.plist"
  },
  ["LotteryTicketRuleDlg"] = {},
  ["LotteryTicketSelectDlg"] = {
    "tiandqf.plist"
  },
  ["LoverTogetherDlg"] = {
    "LoverTogether.plist",
    "MainIcon.plist"
  },
  ["LuckIdentifyDlg"] = {
    "MainIcon.plist"
  },
  ["LuckyStoreItemDlg"] = {
    "BagDlg.plist",
    "MainIcon.plist"
  },
  ["MammonGiftDlg"] = {
    "MainIcon.plist"
  },
  ["MapGuardianDlg"] = {
    "MainIcon.plist"
  },
  ["MarketAuctionDlg"] = {
    "MainIcon.plist"
  },
  ["MarketAuctionItemDlg"] = {
    "MainIcon.plist"
  },
  ["MarketBatchSellItemDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["MarketBuyDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["MarketBuyItemDlg"] = {
    "MainIcon.plist"
  },
  ["MarketChangePriceDlg"] = {
    "MainIcon.plist"
  },
  ["MarketCollectionDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["MarketGoldArtifactInfoDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldBidDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldEquipmentInfoDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldHorcruxInfoDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldJewerlyInfoDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldOperateGoodsDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldPayDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldPetInfoAttribDlg"] = {},
  ["MarketGoldPetInfoBasicDlg"] = {},
  ["MarketGoldPetInfoDlg"] = {
    "MarketDlg.plist",
    "MainIcon.plist"
  },
  ["MarketGoldPetInfoSkillDlg"] = {},
  ["MarketGoldReSellGoodsDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldSellGoodsDlg"] = {
    "MainIcon.plist"
  },
  ["MarketGoldVendueDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["MarketGoldViewGoodsDlg"] = {
    "MainIcon.plist"
  },
  ["MarketPanicBuyDlg"] = {
    "MainIcon.plist"
  },
  ["MarketPublicityDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["MarketRecordDlg"] = {
    "MarketDlg.plist",
    "MainIcon.plist"
  },
  ["MarketRuleDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSearchDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSearchEquipmentDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSearchHorcruxDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSearchJewelryDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSearchNewEquipmentDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSearchPetDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSearchPlayerDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSearchTaiyzqDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSellDlg"] = {
    "MarketDlg.plist",
    "MainIcon.plist"
  },
  ["MarketSellEquipmentDlg"] = {
    "MainIcon.plist"
  },
  ["MarketSellItemDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["MarketSellMoneyDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["MarketSellPetDlg"] = {
    "MainIcon.plist"
  },
  ["MarketTabDlg"] = {},
  ["MarriageChaseLoveDlg"] = {
    "Qianlxh.plist"
  },
  ["MarriageCordDlg"] = {},
  ["MarriageCordResultDlg"] = {},
  ["MarriageCordRuleDlg"] = {},
  ["MarriageSignDlg"] = {},
  ["MarriageSignWriteDlg"] = {
    "MainIcon.plist"
  },
  ["MarriageTreeDlg"] = {
    "MainIcon.plist"
  },
  ["MarryFlowerDlg"] = {},
  ["MartinIntroduceDlg"] = {
    "MainIcon.plist"
  },
  ["MasterDlg"] = {
    "MainIcon.plist"
  },
  ["MasterRelationDlg"] = {
    "MainIcon.plist"
  },
  ["MasterRuleDlg"] = {},
  ["MasterTabDlg"] = {},
  ["MatchmakingDlg"] = {
    "MainIcon.plist"
  },
  ["MatchmakingInfoDlg"] = {},
  ["MatchmakingSignDlg"] = {
    "MainIcon.plist"
  },
  ["MeiGuiTimeDlg"] = {},
  ["MemberOperateMenuDlg"] = {
    "MainIcon.plist"
  },
  ["MenpmzDlg"] = {
    "MainIcon.plist"
  },
  ["MenpmzRuleDlg"] = {
    "MainIcon.plist"
  },
  ["MentorTaskInfoDlg"] = {
    "MainIcon.plist"
  },
  ["MenuDlg"] = {
    "MainIcon.plist"
  },
  ["MessageDlg"] = {
    "MainIcon.plist"
  },
  ["MiaoYGuideDlg"] = {
    "MiaoYGuidelines.plist"
  },
  ["MiaoYRadioAddPictureDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioAddProjectDlg"] = {
    "MiaoYRadioImage.plist",
    "WelfareDlg.plist"
  },
  ["MiaoYRadioAddProjectRuleDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioAlbumDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioAlbumRecordDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioApplicationDlg"] = {
    "MiaoYRadioImage.plist",
    "WelfareDlg.plist"
  },
  ["MiaoYRadioAppRuleDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioCreateFavoritesDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["MiaoYRadioFavoritesDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioFavoritesListDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioFlowerTipsDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioHomePageDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioInfoSettingDlg"] = {},
  ["MiaoYRadioMain2Dlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioMiniPlayerDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioMyselfDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioOfficialDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioOfficialProjectDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioPictureDlg"] = {
    "MiaoYRadioImage.plist",
    "WelfareDlg.plist"
  },
  ["MiaoYRadioPlayRecordDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioProjectDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioRankingDlg"] = {
    "FriendChannelDlg.plist",
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioRecentlyRecordDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MiaoYRadioSelfRuleDlg"] = {
    "MiaoYRadioImage.plist"
  },
  ["MidAutumnCakeDlg"] = {
    "MainIcon.plist"
  },
  ["MidAutumnDlg"] = {
    "MainIcon.plist",
    "bobing.plist"
  },
  ["MidAutumnEatDlg"] = {
    "MainIcon.plist"
  },
  ["MiJingShiLianDlg"] = {
    "MainIcon.plist"
  },
  ["MiJingShiLianOverDlg"] = {
    "MainIcon.plist"
  },
  ["MijslEquipDlg"] = {
    "MainIcon.plist"
  },
  ["MijslEquipInfoDlg"] = {
    "MainIcon.plist"
  },
  ["MijslLog"] = {
    "MainIcon.plist"
  },
  ["MijslRewardDlg"] = {
    "MainIcon.plist"
  },
  ["MijslRewardRuleDlg"] = {
    "BagImage.plist"
  },
  ["MingcqhDlg"] = {
    "MainIcon.plist"
  },
  ["MingcqhRuleDlg"] = {
    "MainIcon.plist"
  },
  ["Mingrzb2021dzDlg"] = {
    "WatchCentreDlg.plist"
  },
  ["Mingrzb2021GuessRankDlg"] = {
    "MainIcon.plist"
  },
  ["Mingrzb2021scDlg"] = {
    "MainIcon.plist",
    "WatchCentreDlg.plist"
  },
  ["Mingrzb2021TabDlg"] = {},
  ["MingrzbgrDlg"] = {
    "MainIcon.plist"
  },
  ["Mingrzbgz2021Dlg"] = {},
  ["MingrzbgzDlg"] = {},
  ["MingrzbInfoDlg"] = {
    "MainIcon.plist"
  },
  ["Mingrzbjc2021Dlg"] = {
    "MainIcon.plist",
    "AllplayerpkImage.plist"
  },
  ["MingrzbjcDlg"] = {
    "MainIcon.plist"
  },
  ["MingrzbMatchRuleDlg"] = {},
  ["MingrzbMatchTabDlg"] = {},
  ["MingrzbRuleDlg"] = {
    "MainIcon.plist"
  },
  ["MingrzbscDlg"] = {
    "MainIcon.plist"
  },
  ["Mingrzbsj2021Dlg"] = {},
  ["MingrzbTabDlg"] = {},
  ["MingrzbTeamInfoDlg"] = {
    "MainIcon.plist"
  },
  ["MingrzbtpDlg"] = {
    "MainIcon.plist"
  },
  ["MissionDlg"] = {
    "MainIcon.plist"
  },
  ["MoneyTreeDlg"] = {
    "MainIcon.plist"
  },
  ["MoneyTreeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["MoreCharMenuDlg"] = {
    "MainIcon.plist"
  },
  ["NeiCePointDlg"] = {
    "MainIcon.plist"
  },
  ["NewChargeDrawGiftDlg"] = {
    "MainIcon.plist"
  },
  ["NewChargeDrawGiftResult2Dlg"] = {
    "MainIcon.plist"
  },
  ["NewChargeDrawGiftResultDlg"] = {},
  ["NewChargeDrawGiftRuleDlg"] = {
    "MainIcon.plist"
  },
  ["NewGeneralRuleDlg"] = {},
  ["NewKuafzcgzDlg"] = {},
  ["NewKuafzcInfoDlg"] = {},
  ["NewKuafzcjfDlg"] = {
    "MainIcon.plist"
  },
  ["NewKuafzcjlDlg"] = {
    "MainIcon.plist"
  },
  ["NewKuafzcscDlg"] = {
    "MainIcon.plist"
  },
  ["NewKuafzcsjDlg"] = {},
  ["NewKuafzcTabDlg"] = {},
  ["NewKuafzcWarInfoDlg"] = {
    "MainIcon.plist"
  },
  ["NewListNameDlg"] = {
    "MainIcon.plist"
  },
  ["NewlyNewServiceCelebrationDlg"] = {
    "MainIcon.plist",
    "ServiceCelebration.plist",
    "PetStruggleDlg.plist"
  },
  ["NewlyNewServiceCelebrationTwiceListDlg"] = {},
  ["NewlyServerReserveDlg"] = {},
  ["NewlyServerReserveReward2Dlg"] = {
    "MainIcon.plist"
  },
  ["NewlyServerReserveRewardDlg"] = {
    "MainIcon.plist"
  },
  ["NewNpcDlg"] = {
    "NPCDlg.plist"
  },
  ["NewPartyWarInstructionDlg"] = {},
  ["NewServerGiftDlg"] = {
    "MainIcon.plist",
    "AllplayerpkImage.plist",
    "NewServerGiftDlg.plist"
  },
  ["NewServerLuckyCharmDlg"] = {},
  ["NewServerLuckyCharmResultDlg"] = {
    "DramaDlg.plist",
    "MainIcon.plist"
  },
  ["NewServerLuckyCharmRewardDlg"] = {},
  ["NewServerReserveDlg"] = {
    "MainIcon.plist"
  },
  ["NewServiceCelebrationDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["NewServiceCelebrationRuleDlg"] = {
    "MainIcon.plist"
  },
  ["NewServiceExpDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["NewServiceExpRuleDlg"] = {
    "MainIcon.plist"
  },
  ["NewYearGuardDlg"] = {
    "MainIcon.plist"
  },
  ["NianyefanRuleDlg"] = {
    "MainIcon.plist"
  },
  ["NoneDlg"] = {},
  ["NoviceGiftDlg"] = {
    "MainIcon.plist"
  },
  ["NpcCardDlg"] = {
    "MainIcon.plist"
  },
  ["NPCRecruitDlg"] = {
    "MainIcon.plist"
  },
  ["NPCSupplyDlg"] = {
    "MainIcon.plist"
  },
  ["NumerologyDlg"] = {
    "MainIcon.plist"
  },
  ["NumInputDlg"] = {
    "MainIcon.plist"
  },
  ["OfflineRuleDlg"] = {
    "MainIcon.plist"
  },
  ["OnlineGiftDlg"] = {
    "WelfareDlg.plist"
  },
  ["OnlineMallDlg"] = {
    "MainIcon.plist",
    "OnlineMallDlg.plist"
  },
  ["OnlineMallExchangeMoneyDlg"] = {
    "mall_cash.plist",
    "MainIcon.plist"
  },
  ["OnlineMallRuleDlg"] = {
    "MainIcon.plist"
  },
  ["OnlineMallTabDlg"] = {
    "OnlineMallDlg.plist"
  },
  ["OnlineMallUnVIPDlg"] = {
    "OnlineMallDlg.plist",
    "MainIcon.plist",
    "VIPImage.plist",
    "TianggkwImage.plist"
  },
  ["OnlineMallVIPDlg"] = {
    "MainIcon.plist",
    "mall_vip.plist",
    "OnlineMallDlg.plist"
  },
  ["OnlineRechargeDlg"] = {
    "OnlineMallDlg.plist",
    "MainIcon.plist"
  },
  ["OnlineRechargeGiftDlg"] = {
    "MainIcon.plist"
  },
  ["OnlyConfirmDlg"] = {
    "MainIcon.plist"
  },
  ["OpenBoxDlg"] = {
    "MainIcon.plist"
  },
  ["OreFunctionDlg"] = {
    "MainIcon.plist"
  },
  ["OutAutoFightDlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["PartyActBoardDlg"] = {},
  ["PartyActiveDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyActiveNoteDlg"] = {
    "MainIcon.plist"
  },
  ["PartyActiveRankingListDlg"] = {
    "MainIcon.plist"
  },
  ["PartyActiveSetDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyAppointDlg"] = {
    "PartyDlg.plist"
  },
  ["PartyBeatMonsterDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyBeatMonsterMainInfoDlg"] = {
    "PartyDlg.plist",
    "MainIcon.plist"
  },
  ["PartyBeatMonsterResultDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyBeatMonsterResultRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PartyBeatMonsterRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PartyCJTabDlg"] = {},
  ["PartyDonateMoneyDlg"] = {
    "MainIcon.plist"
  },
  ["PartyFeedMonsterDlg"] = {
    "PartyDlg.plist",
    "MainIcon.plist"
  },
  ["PartyFeedMonsterRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PartyFireworksDlg"] = {
    "DramaDlg.plist",
    "PartyFireworks.plist"
  },
  ["PartyGongcTabDlg"] = {},
  ["PartyHunyxsDlg"] = {
    "PartyFireworks.plist"
  },
  ["PartyInfoDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyInfoTabDlg"] = {},
  ["PartyManageDlg"] = {
    "MainIcon.plist"
  },
  ["PartyManageIconDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyMedalShopDlg"] = {
    "MainIcon.plist"
  },
  ["PartyMemberDidNotParticipateDlg"] = {
    "MainIcon.plist"
  },
  ["PartyMemberDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist",
    "BagDlg.plist"
  },
  ["PartyOutRedBagDlg"] = {
    "MainIcon.plist"
  },
  ["PartyQqlModifyDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyRedBagDlg"] = {
    "MainIcon.plist"
  },
  ["PartyRedBagMoneyInfo02Dlg"] = {
    "PartyDlg.plist",
    "RevelryRedBagImage.plist"
  },
  ["PartyRedBagMoneyInfoDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyRedBagMoneyRecordDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyRedBagRankDlg"] = {},
  ["PartyRedBagRewardDlg"] = {
    "PartyDlg.plist"
  },
  ["PartyRenameDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyShopDlg"] = {
    "MainIcon.plist"
  },
  ["PartySkillBatchDevelopDlg"] = {
    "MainIcon.plist"
  },
  ["PartySkillDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PartyViewSkillDlg"] = {
    "MainIcon.plist"
  },
  ["PartyWarEnemyMenuDlg"] = {
    "MainIcon.plist"
  },
  ["PartyWarHistoryDlg"] = {
    "MainIcon.plist"
  },
  ["PartyWarInfoDlg"] = {
    "MainIcon.plist"
  },
  ["PartyWarInstructionDlg"] = {},
  ["PartyWarMissionDlg"] = {},
  ["PartyWarScheduleDlg"] = {
    "MainIcon.plist"
  },
  ["PartyWarSignUpDlg"] = {
    "MainIcon.plist"
  },
  ["PartyWarTabDlg"] = {},
  ["PartyWelfareDlg"] = {
    "MainIcon.plist",
    "PartyDlg.plist"
  },
  ["PeachSignDlg"] = {},
  ["PeachSignWriteDlg"] = {
    "MainIcon.plist"
  },
  ["PeachTreeDlg"] = {
    "MainIcon.plist"
  },
  ["PedometerDlg"] = {},
  ["PetAttribDlg"] = {
    "MainIcon.plist",
    "PetDlg.plist"
  },
  ["PetAttribExpRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PetAutoAttribDlg"] = {
    "MainIcon.plist"
  },
  ["PetCallDlg"] = {
    "MainIcon.plist"
  },
  ["PetCallRuleDlg"] = {},
  ["PetCardDlg"] = {
    "MainIcon.plist"
  },
  ["PetChangeColorDlg"] = {
    "MainIcon.plist",
    "PetDlg.plist"
  },
  ["PetChangeDlg"] = {
    "MainIcon.plist"
  },
  ["PetDevelopDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetDianhuaDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetDressDlg"] = {
    "MainIcon.plist",
    "PetDlg.plist"
  },
  ["PetDressRuleDlg"] = {},
  ["PetDressTabDlg"] = {},
  ["PetDunWuBuyDlg"] = {},
  ["PetDunWuDlg"] = {
    "MainIcon.plist"
  },
  ["PetDunWuRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PetEvolveDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetEvolveRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PetEvolveSubmitPetDlg"] = {
    "MainIcon.plist"
  },
  ["PetExploreChoseDlg"] = {
    "MainIcon.plist",
    "PetExploreDlg.plist"
  },
  ["PetExploreDlg"] = {
    "MainIcon.plist",
    "PetExploreDlg.plist"
  },
  ["PetExploreRewardDlg"] = {
    "MainIcon.plist",
    "PetExploreDlg.plist"
  },
  ["PetExploreSkillDlg"] = {
    "MainIcon.plist",
    "PetExploreDlg.plist"
  },
  ["PetExploreSkillLearnDlg"] = {
    "MainIcon.plist",
    "PetExploreDlg.plist"
  },
  ["PetExploreTabDlg"] = {},
  ["PetExploreTeamDlg"] = {
    "MainIcon.plist",
    "PetExploreDlg.plist"
  },
  ["PetFengsBuyDlg"] = {},
  ["PetFlyDoneDlg"] = {
    "MainIcon.plist"
  },
  ["PetFlyItemDlg"] = {
    "MainIcon.plist"
  },
  ["PetFuseDlg"] = {
    "MainIcon.plist",
    "PetDlg.plist"
  },
  ["PetFuseRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PetFuseSubmitPetDlg"] = {
    "MainIcon.plist"
  },
  ["PetGetAttribDlg"] = {
    "MainIcon.plist"
  },
  ["PetGetResisDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetghostOneClickEatDlg"] = {
    "MainIcon.plist"
  },
  ["PetGhostSoulSubmitDlg"] = {
    "MainIcon.plist"
  },
  ["PetGrowingDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetGrowPandectDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetGrowTabDlg"] = {
    "PetDlg.plist"
  },
  ["PetHandbookDlg"] = {
    "MainIcon.plist",
    "PetDlg.plist"
  },
  ["PetHorseBuyFenglingDlg"] = {},
  ["PetHorseDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetHorseTameDlg"] = {
    "MainIcon.plist"
  },
  ["PetHorseTipsDlg"] = {
    "MainIcon.plist"
  },
  ["PetHouseBuyDlg"] = {
    "MainIcon.plist"
  },
  ["PetHouseDlg"] = {
    "MainIcon.plist"
  },
  ["PetHuanHuaDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetHuanHuaRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PetIdentificationDlg"] = {
    "MainIcon.plist"
  },
  ["PetInheritDlg"] = {
    "PetDlg.plist"
  },
  ["PetIntimacyInfoDlg"] = {
    "MainIcon.plist"
  },
  ["PetIntimacyRule1Dlg"] = {
    "MainIcon.plist"
  },
  ["PetIntimacyRule2Dlg"] = {
    "MainIcon.plist"
  },
  ["PetIntimacyRule3Dlg"] = {
    "MainIcon.plist"
  },
  ["PetIntimacyRuleDlg"] = {},
  ["PetLanternDlg"] = {
    "polaricon.plist",
    "PetLanternImage.plist"
  },
  ["PetListChildDlg"] = {
    "PetDlg.plist"
  },
  ["PetOneClickDevelopDlg"] = {
    "MainIcon.plist"
  },
  ["PetOneClickEatDlg"] = {
    "MainIcon.plist"
  },
  ["PetOneClickYuhuaDlg"] = {
    "MainIcon.plist"
  },
  ["PetRebirthDlg"] = {
    "MainIcon.plist",
    "PetDlg.plist"
  },
  ["PetShopDlg"] = {
    "MainIcon.plist"
  },
  ["PetSkillDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PetStoneDlg"] = {
    "MainIcon.plist"
  },
  ["PetStruggleBonusDlg"] = {
    "PetStruggleDlg.plist",
    "MainIcon.plist"
  },
  ["PetStruggleCombatResultDlg"] = {},
  ["PetStruggleDlg"] = {
    "PetStruggleDlg.plist",
    "MainIcon.plist"
  },
  ["PetStruggleOrderDlg"] = {},
  ["PetStruggleRuleDlg"] = {
    "MainIcon.plist",
    "PetStruggleDlg.plist"
  },
  ["PetTabDlg"] = {},
  ["PetYuhuaDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["PharmacyDlg"] = {
    "MainIcon.plist"
  },
  ["PolarAddPointDlg"] = {
    "MainIcon.plist"
  },
  ["PolarAutoAddPointDlg"] = {
    "MainIcon.plist"
  },
  ["PolarDuelDlg"] = {
    "polaricon.plist",
    "CockFightImage.plist"
  },
  ["PolarMatrixDlg"] = {
    "polaricon.plist"
  },
  ["PracticeBuyDoubleDlg"] = {
    "MainIcon.plist"
  },
  ["PracticeBuyShenMuDlg"] = {
    "MainIcon.plist"
  },
  ["PracticeDlg"] = {
    "MainIcon.plist",
    "PracticeDlg.plist"
  },
  ["PracticeMonsterDlg"] = {
    "MainIcon.plist"
  },
  ["PracticeRuleDlg"] = {},
  ["PreventFatigueRuleDlg"] = {
    "MainIcon.plist"
  },
  ["PrisonDlg"] = {
    "MainIcon.plist"
  },
  ["PromiseDlg"] = {
    "MainIcon.plist"
  },
  ["PromoteDlg"] = {
    "MainIcon.plist"
  },
  ["ProposeDlg"] = {
    "MainIcon.plist"
  },
  ["PushPullDlg"] = {
    "PushPullDlg.plist",
    "MainIcon.plist"
  },
  ["QianktDlg"] = {
    "MainIcon.plist"
  },
  ["QingYuanDlg"] = {
    "MainIcon.plist"
  },
  ["QiShaDlg"] = {
    "MainIcon.plist"
  },
  ["QixYfsgMainDlg"] = {
    "MainIcon.plist"
  },
  ["QixYfsgTitleDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPK2019SignUpDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPK2019TeamEnlistDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPK2019TeamEnlistInfoDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPK2020apDlg"] = {
    "AllplayerpkImage.plist",
    "MainIcon.plist"
  },
  ["QuanmPK2020apRuleDlg"] = {},
  ["QuanmPK2020SignDlg"] = {},
  ["QuanmPK2020SignRSSDlg"] = {},
  ["QuanmPK2020TeamRecordDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPK2fxDlg"] = {},
  ["QuanmPK2InfoDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPK2jfDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPK2scDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPK2sjDlg"] = {},
  ["QuanmPK2TabDlg"] = {},
  ["QuanmPKBonusFrameDlg"] = {},
  ["QuanmPKLookonManageDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPKPrepareCheckDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPKPrepareDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPKPrepareEquipDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPKPrepareItemDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPKPreparePetDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPKPrepareReclaimDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPKPrepareSpiritSystemDlg"] = {
    "SpiritSystemDlg.plist"
  },
  ["QuanmPKPrepareUserDlg"] = {
    "PetDlg.plist",
    "MainIcon.plist"
  },
  ["QuanmPKRuleDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmPKTeamInfoDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmZBjfDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmZBscDlg"] = {
    "MainIcon.plist"
  },
  ["QuanmZBTabDlg"] = {},
  ["QuestionnaireDlg"] = {
    "MainIcon.plist"
  },
  ["QugcxDlg"] = {
    "MainIcon.plist",
    "Baosccl.plist"
  },
  ["QuickUseBaoTuDlg"] = {
    "BaoTuImage.plist"
  },
  ["QuickUseOneDlg"] = {},
  ["QuickUseTwoDlg"] = {
    "MainIcon.plist"
  },
  ["RankingListDlg"] = {
    "MainIcon.plist"
  },
  ["RankingTabDlg"] = {},
  ["ReadyDlg"] = {
    "FightDlg.plist"
  },
  ["RealNameVerifyDlg"] = {},
  ["RebuyDlg"] = {
    "MainIcon.plist"
  },
  ["RecommendDeclarationDlg"] = {
    "MainIcon.plist"
  },
  ["RecommendFriendDlg"] = {
    "MainIcon.plist"
  },
  ["RecordDlg"] = {
    "MainIcon.plist",
    "SendVoice.plist"
  },
  ["RedBagRainBonusDetailDlg"] = {
    "WelfareDlg.plist"
  },
  ["RedBagRainBonusDlg"] = {
    "WelfareDlg.plist"
  },
  ["RedBagRainDlg"] = {
    "FightDlg.plist",
    "WelfareDlg.plist"
  },
  ["RedBagRainRecordDlg"] = {},
  ["RedBagRainTabDlg"] = {},
  ["ReentryAsktaoDlg"] = {
    "MainIcon.plist"
  },
  ["RegressionRechargeDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["RemarksDlg"] = {
    "MainIcon.plist"
  },
  ["RemindDlg"] = {},
  ["RenameDiscountDlg"] = {
    "MainIcon.plist"
  },
  ["RenameHomeDlg"] = {},
  ["RenameHomeGardenerDlg"] = {},
  ["RenameHomeMaidDlg"] = {},
  ["RenameHomeManagerDlg"] = {},
  ["RenameKidDlg"] = {},
  ["RenamePetDlg"] = {
    "MainIcon.plist"
  },
  ["RenameRadioDlg"] = {
    "MainIcon.plist"
  },
  ["RenLSBDlg"] = {},
  ["ReporterLookOnDlg"] = {
    "MainIcon.plist"
  },
  ["ReserveRechargeTabDlg"] = {},
  ["ResetRuleDlg"] = {
    "MainIcon.plist"
  },
  ["RevelryRedBagDlg"] = {
    "RevelryRedBagImage.plist"
  },
  ["RevelryRedBagNameDlg"] = {},
  ["RevelryRedBagRecordDlg"] = {
    "RevelryRedBagImage.plist"
  },
  ["RevelryRedBagTabDlg"] = {},
  ["RewardInquireDlg"] = {
    "MainIcon.plist"
  },
  ["RingHegemonyDlg"] = {
    "MainIcon.plist"
  },
  ["RookieGiftDlg"] = {},
  ["RowSkillShopDlg"] = {
    "MainIcon.plist"
  },
  ["RuixscFightDlg"] = {
    "skilltext.plist",
    "MainIcon.plist"
  },
  ["SafeLockForceReleaseDlg"] = {},
  ["SafeLockLimitDlg"] = {},
  ["SafeLockMainDlg"] = {
    "MainIcon.plist"
  },
  ["SafeLockModifyDlg"] = {
    "MainIcon.plist"
  },
  ["SafeLockReleaseDlg"] = {
    "MainIcon.plist"
  },
  ["SafeLockSetDlg"] = {
    "MainIcon.plist"
  },
  ["ScratchRewardDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["ScratchRewardInfoDlg"] = {
    "MainIcon.plist"
  },
  ["ScreenRecordingDlg"] = {},
  ["ScriptTestDlg"] = {},
  ["SearchUserDlg"] = {
    "MainIcon.plist"
  },
  ["SeeEquipmentDlg"] = {
    "MainIcon.plist",
    "BagDlg.plist"
  },
  ["SeekFriendDlg"] = {
    "polaricon.plist"
  },
  ["SeekFriendMapDlg"] = {
    "MainIcon.plist"
  },
  ["SeekFriendMemberDlg"] = {
    "MainIcon.plist"
  },
  ["SeekFriendWelfareDlg"] = {
    "MainIcon.plist",
    "WelfareDlg.plist"
  },
  ["SelectDlg"] = {
    "MainIcon.plist"
  },
  ["SendMailDlg"] = {
    "MainIcon.plist"
  },
  ["SendPartyNotifyDlg"] = {
    "MainIcon.plist"
  },
  ["SendPartyNotifyPanel"] = {},
  ["SeniorTrusteeshipBuyDlg"] = {
    "MainIcon.plist"
  },
  ["SeniorTrusteeshipRuleDlg"] = {},
  ["SeniorTrusteeshipSetDlg"] = {
    "MainIcon.plist"
  },
  ["SeniorTrusteeshipShowDlg"] = {},
  ["SeniorTrusteeshipWeChatRuleDlg"] = {
    "MainIcon.plist"
  },
  ["ServiceAchievementDlg"] = {
    "MainIcon.plist"
  },
  ["ServiceGiftDlg"] = {
    "MainIcon.plist"
  },
  ["SevenDaysRewardDlg"] = {
    "MainIcon.plist"
  },
  ["ShangxysDlg"] = {},
  ["ShapePenDlg"] = {
    "MainIcon.plist"
  },
  ["ShareChannelListDlg"] = {
    "MainIcon.plist"
  },
  ["ShareDlg"] = {},
  ["ShareLineDlg"] = {},
  ["ShelqxMainDlg"] = {
    "SheliuImage.plist"
  },
  ["ShelqxResultDlg"] = {
    "MainIcon.plist",
    "lingyzmword.plist"
  },
  ["ShengSiDetailsDlg"] = {
    "MainIcon.plist"
  },
  ["ShengSiHistoryDlg"] = {
    "MainIcon.plist"
  },
  ["ShengSiMySelfHistoryDlg"] = {
    "MainIcon.plist"
  },
  ["ShengSiRuleDlg"] = {},
  ["ShengSiSetDlg"] = {
    "MainIcon.plist"
  },
  ["ShengSiTabDlg"] = {},
  ["ShengxdjDlg"] = {
    "skilltext.plist",
    "MainIcon.plist"
  },
  ["ShengxdjgzDlg"] = {
    "MainIcon.plist"
  },
  ["ShenmbhDlg"] = {},
  ["ShenMBXDlg"] = {
    "MainIcon.plist"
  },
  ["ShenmdgDlg"] = {
    "lingyzmword.plist",
    "MainIcon.plist"
  },
  ["ShenmszDlg"] = {},
  ["ShidaoInfoDlg"] = {
    "MainIcon.plist"
  },
  ["Shidaowzjl2Dlg"] = {},
  ["ShidaowzjlDlg"] = {
    "MainIcon.plist"
  },
  ["ShiddhDlg"] = {
    "MainIcon.plist"
  },
  ["ShiddhjfDlg"] = {
    "MainIcon.plist"
  },
  ["ShiddhTabDlg"] = {},
  ["ShiddhwzDlg"] = {
    "MainIcon.plist"
  },
  ["ShidwzDlg"] = {
    "MainIcon.plist"
  },
  ["ShiJieBeiDlg"] = {
    "MainIcon.plist"
  },
  ["ShiJieBeiRewardDlg"] = {
    "MainIcon.plist"
  },
  ["ShiJieBeiRuleDlg"] = {},
  ["ShiJieBeiSupportDlg"] = {
    "MainIcon.plist"
  },
  ["ShiJieBeiTabDlg"] = {},
  ["ShiJieBeiTimeDlg"] = {
    "MainIcon.plist"
  },
  ["ShiswgDlg"] = {
    "MainIcon.plist",
    "shuiswg.plist"
  },
  ["ShuitcsDeathNoteDlg"] = {
    "CaseCSST.plist",
    "DramaDlg.plist"
  },
  ["ShuitcslwDlg"] = {
    "DramaDlg.plist",
    "CaseCSST.plist"
  },
  ["ShuitcssxDlg"] = {
    "DramaDlg.plist",
    "LoginDlg.plist"
  },
  ["SifqjDlg"] = {
    "MainIcon.plist"
  },
  ["SifqjRuleDlg"] = {},
  ["SignFriendDlg"] = {
    "MainIcon.plist"
  },
  ["SilenceLineUpChangeChannelDiscountDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLineUpChangeChannelDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLineUpDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLineUpSowVIPRuleDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLoginChangeDistDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLoginForbidRedHandDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLoginForbidSimulatorDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLoginForceUpdateDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLoginJubzSaleInfoDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLoginNewDistActiveDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLoginOperateDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceLoginPreviewDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceUpdateDescDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceUserAgreementDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SilenceUserLoginDlg"] = {
    "SilenceLoginDlg.plist"
  },
  ["SimulatePetDlg"] = {
    "MainIcon.plist"
  },
  ["SimulateUserDlg"] = {
    "MainIcon.plist"
  },
  ["SingleChatDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["SingleCreatGroupDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["SingleFlockDlg"] = {
    "MainIcon.plist"
  },
  ["SingleFlockMoveDlg"] = {
    "MainIcon.plist"
  },
  ["SingleFriendDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["SingleGroupDlg"] = {
    "FriendChannelDlg.plist",
    "MainIcon.plist"
  },
  ["SingleGroupSubmenuDlg"] = {
    "MainIcon.plist"
  },
  ["SkillDlg"] = {
    "MainIcon.plist"
  },
  ["SkillFloatingFrameDlg"] = {
    "MainIcon.plist"
  },
  ["SkillRuleDlg"] = {
    "MainIcon.plist"
  },
  ["SkillStatusDlg"] = {},
  ["SmallMapDlg"] = {
    "MainIcon.plist"
  },
  ["SmallNumInputDlg"] = {
    "MainIcon.plist"
  },
  ["SouxlpDlg"] = {},
  ["SouxlpRuleDlg"] = {
    "MainIcon.plist"
  },
  ["SouxlpSmallDlg"] = {
    "MainIcon.plist"
  },
  ["SpecialLoadingDlg"] = {},
  ["SpecialRoomShowDlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["SpeclalRoomConvertDlg"] = {},
  ["SpeclalRoomDanceDlg"] = {},
  ["SpeclalRoomEatDlg"] = {
    "MainIcon.plist"
  },
  ["SpeclalRoomStrollDlg"] = {},
  ["SpeclalRoomVoteDlg"] = {
    "MainIcon.plist"
  },
  ["SpiritSystemArrayDlg"] = {
    "MainIcon.plist"
  },
  ["SpiritSystemCardDlg"] = {
    "SpiritSystemDlg.plist",
    "PetDlg.plist"
  },
  ["SpiritSystemDlg"] = {
    "SpiritSystemDlg.plist",
    "MainIcon.plist",
    "SpiritBackground.plist"
  },
  ["SpiritSystemMagicCircleDlg"] = {
    "MainIcon.plist",
    "SpiritSystemDlg.plist"
  },
  ["SpiritSystemMoenyDlg"] = {},
  ["SpiritSystemPossessedDlg"] = {
    "SpiritSystemDlg.plist"
  },
  ["SpiritSystemTabDlg"] = {},
  ["SpouseDlg"] = {
    "MainIcon.plist"
  },
  ["StatisticsDlg"] = {
    "MainIcon.plist"
  },
  ["StepOnCubeDlg"] = {},
  ["StoreItemDlg"] = {
    "BagDlg.plist"
  },
  ["StoreMoneyDlg"] = {
    "mall_cash.plist"
  },
  ["StoreMoneyImportDlg"] = {},
  ["StorePetDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitChangeCardDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitEquipDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitFDIDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitGodBookDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitGongShengPetDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitJewelryDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitMultiItemDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitPetDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitRefineJewelryDlg"] = {
    "MainIcon.plist"
  },
  ["SubmitXinDeDlg"] = {
    "MainIcon.plist"
  },
  ["SubstituteTeacherDlg"] = {
    "MainIcon.plist",
    "polaricon.plist",
    "SJHDTeacher.plist"
  },
  ["SubstituteTeacherRuleDlg"] = {
    "SubstituteTeacherDlg.plist"
  },
  ["SummerVacationDlg"] = {
    "MainIcon.plist"
  },
  ["SummerVacationRuleDlg"] = {
    "MainIcon.plist"
  },
  ["SuperBossIntroduceDlg"] = {},
  ["SuperBossShowDlg"] = {},
  ["SuperBossTabDlg"] = {},
  ["SystemAccManageDlg"] = {
    "MainIcon.plist",
    "SystemConfigDlg.plist"
  },
  ["SystemConfigDlg"] = {
    "MainIcon.plist",
    "SystemConfigDlg.plist"
  },
  ["SystemConfigTabDlg"] = {},
  ["SystemFunctionDlg"] = {
    "MainIcon.plist"
  },
  ["SystemMessageDlg"] = {},
  ["SystemMessageListDlg"] = {
    "MainIcon.plist"
  },
  ["SystemMessageShowDlg"] = {
    "MainIcon.plist"
  },
  ["SystemPushDlg"] = {
    "MainIcon.plist"
  },
  ["SystemRedbagRecordDlg"] = {
    "MainIcon.plist"
  },
  ["SystemSwitchLineDlg"] = {},
  ["TaiYinInfoDlg"] = {
    "MainIcon.plist"
  },
  ["TaiYinStoreHouseDlg"] = {
    "MainIcon.plist"
  },
  ["TaoIntroduceDlg"] = {
    "MainIcon.plist"
  },
  ["TaskCardDlg"] = {
    "MainIcon.plist"
  },
  ["TaskDlg"] = {},
  ["TeamAdjustmentDlg"] = {
    "MainIcon.plist",
    "TeamDlg.plist"
  },
  ["TeamAssessDlg"] = {},
  ["TeamChangeCardMenuDlg"] = {
    "MainIcon.plist"
  },
  ["TeamDlg"] = {
    "TeamDlg.plist",
    "MainIcon.plist"
  },
  ["TeamEnlistDlg"] = {
    "MainIcon.plist",
    "TeamDlg.plist"
  },
  ["TeamEnlistInfoDlg"] = {
    "TeamDlg.plist",
    "MainIcon.plist"
  },
  ["TeamFixedDlg"] = {
    "MainIcon.plist",
    "TeamDlg.plist"
  },
  ["TeamGuardMenuDlg"] = {
    "MainIcon.plist",
    "TeamDlg.plist"
  },
  ["TeamOPMenuDlg"] = {
    "MainIcon.plist"
  },
  ["TeamQuickDlg"] = {
    "MainIcon.plist"
  },
  ["TeamQuickUseDlg"] = {
    "MainIcon.plist"
  },
  ["TeamReserveDlg"] = {
    "MainIcon.plist"
  },
  ["TeamSetTitleDlg"] = {
    "TeamDlg.plist",
    "MainIcon.plist"
  },
  ["TeamSortOrderDlg"] = {
    "TeamDlg.plist",
    "MainIcon.plist"
  },
  ["TeamTabDlg"] = {},
  ["TeamVoteDlg"] = {
    "TeamDlg.plist"
  },
  ["TempChatCmdDlg"] = {
    "FriendChannelDlg.plist"
  },
  ["TestSkillDlg"] = {},
  ["TianGBackpackDlg"] = {
    "MainIcon.plist",
    "TianGMainInterface.plist"
  },
  ["TianGCallGodWillDlg"] = {
    "TianGGodWill.plist",
    "TianGMainInterface.plist"
  },
  ["TianGCreationCelectGodDlg"] = {
    "TianGGodWill.plist",
    "TianGMainInterface.plist",
    "TianggkwImage.plist"
  },
  ["TianGCreationDlg"] = {
    "MainIcon.plist",
    "TianGMainInterface.plist",
    "TianggkwImage.plist"
  },
  ["TianGCreationResultDlg"] = {
    "TianGMainInterface.plist",
    "FightDlg.plist"
  },
  ["TianGEquipmentFloatingFrameDlg"] = {},
  ["TianGFuYaoDlg"] = {},
  ["TianGFuYaoFightingDlg"] = {},
  ["TianGFuYaoMapDlg"] = {
    "TianGMainInterface.plist",
    "TianGFuYao.plist"
  },
  ["TianGFuYaoMapInfoDlg"] = {},
  ["TianGFuYaoSettlementDlg"] = {
    "MainIcon.plist",
    "TianGMainInterface.plist",
    "FightDlg.plist"
  },
  ["TianGGeneralDlg"] = {
    "TianGMainInterface.plist",
    "TianGGodWill.plist"
  },
  ["TianGGodAttributeDlg"] = {
    "MainIcon.plist",
    "TianGMainInterface.plist"
  },
  ["TianGGodAttributeTabDlg"] = {
    "TianGMainInterface.plist"
  },
  ["TianGGodBackpackDlg"] = {
    "MainIcon.plist"
  },
  ["TianGGodBreakDlg"] = {},
  ["TianGGodFinalEffectDlg"] = {
    "TianGMainInterface.plist"
  },
  ["TianGGodGeneralDlg"] = {
    "MainIcon.plist",
    "TianGMainInterface.plist"
  },
  ["TianGGodMenuDlg"] = {
    "MainIcon.plist",
    "TeamDlg.plist"
  },
  ["TianGGodPanoplyDlg"] = {
    "TianGMainInterface.plist"
  },
  ["TianGGodRealmDlg"] = {
    "TianGMainInterface.plist"
  },
  ["TianGGodSoulDlg"] = {
    "TianGGod.plist",
    "TianGMainInterface.plist",
    "MainIcon.plist",
    "TianggkwImage.plist",
    "PetDlg.plist"
  },
  ["TianGJuShenLouDlg"] = {
    "TianGMainInterface.plist",
    "TianGGodhead.plist"
  },
  ["TianGJuShenRewardDlg"] = {
    "MainIcon.plist"
  },
  ["TianGJuShenRuleDlg"] = {},
  ["TianGLSPromoteDlg"] = {
    "MainIcon.plist",
    "TianGMainInterface.plist"
  },
  ["TianGMainInterfaceDlg"] = {
    "TianGMainInterface.plist",
    "MiaoYRadioImage.plist"
  },
  ["TianGMainInterfaceTabDlg"] = {
    "TianGFuYao.plist",
    "TianGMainInterface.plist",
    "MainIcon.plist",
    "FightDlg.plist"
  },
  ["TianGProvingGroundsDlg"] = {
    "TianGTrial.plist",
    "TianGMainInterface.plist",
    "TianggkwImage.plist"
  },
  ["TianGRankingDlg"] = {
    "MainIcon.plist",
    "TianGMainInterface.plist"
  },
  ["TianGRankingRuleDlg"] = {},
  ["TianGShenGeDlg"] = {
    "TianGMainInterface.plist",
    "PetDlg.plist"
  },
  ["TianGShenGeFloatingFrameDlg"] = {},
  ["TianGSkillDlg"] = {},
  ["TianJieNewFuncitionDlg"] = {
    "MainIcon.plist",
    "TianGNewFunction.plist"
  },
  ["TipOffUserDlg"] = {
    "MainIcon.plist"
  },
  ["TitleCardDlg"] = {
    "MainIcon.plist"
  },
  ["TitleShowDlg"] = {
    "MainIcon.plist",
    "ChengWDB.plist"
  },
  ["TongTianConfirmDlg"] = {},
  ["TongTianDlg"] = {
    "MainIcon.plist"
  },
  ["TongtiantaFlyDlg"] = {
    "MainIcon.plist"
  },
  ["TongtiantaRuleDlg"] = {
    "MainIcon.plist"
  },
  ["TongTianTopTargetDlg"] = {
    "MainIcon.plist"
  },
  ["TongTianTopVoteDlg"] = {
    "MainIcon.plist"
  },
  ["TongzhjDlg"] = {
    "TZHJChildrenDayImage.plist",
    "MainIcon.plist"
  },
  ["TongzhjRuleDlg"] = {
    "TZHJChildrenDayImage.plist"
  },
  ["TouZiBuyDlg"] = {},
  ["TradingSpotDiscussDlg"] = {
    "MainIcon.plist",
    "TradingSpotDlg.plist"
  },
  ["TradingSpotInfoDlg"] = {
    "MainIcon.plist"
  },
  ["TradingSpotItemDlg"] = {
    "MainIcon.plist"
  },
  ["TradingSpotItemInfoDlg"] = {
    "MainIcon.plist",
    "TradingSpotDlg.plist"
  },
  ["TradingSpotProfitDlg"] = {
    "MainIcon.plist"
  },
  ["TradingSpotRankDlg"] = {
    "MainIcon.plist"
  },
  ["TradingSpotRuleDlg"] = {},
  ["TradingSpotShareBuyPlanDlg"] = {
    "MainIcon.plist"
  },
  ["TradingSpotShareItemDlg"] = {
    "MainIcon.plist",
    "TradingSpotDlg.plist"
  },
  ["TradingSpotSharePlanDlg"] = {
    "MainIcon.plist"
  },
  ["TradingSpotTabDlg"] = {},
  ["TreasureBagDlg"] = {
    "TreasureBag.plist"
  },
  ["TreasureBagNewDlg"] = {
    "TreasureBag.plist"
  },
  ["TreasureBagTipsDlg"] = {},
  ["TreasureBuyCashDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["TreasureChangeMoneyPriceDlg"] = {
    "MainIcon.plist"
  },
  ["TreasureOfficialBuyCashDlg"] = {
    "MainIcon.plist",
    "MarketDlg.plist"
  },
  ["TreasureRuleDlg"] = {
    "MainIcon.plist"
  },
  ["TreasureTreeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["TwoBirdFlyDlg"] = {
    "MainIcon.plist",
    "TwoBirdFly.plist"
  },
  ["UndergroundBagDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundBuffDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundBuyDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundCardDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundCommanderDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundEntranceDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundGameResultDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundGrowthDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundMainDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundRecruitDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundRewardDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundRuleDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundShopDlg"] = {
    "MainIcon.plist"
  },
  ["UndergroundSmallMapDlg"] = {},
  ["UndergroundTeamDlg"] = {
    "MainIcon.plist"
  },
  ["UnderPlayerCardDlg"] = {
    "MainIcon.plist"
  },
  ["UnknownErrorDlg"] = {},
  ["UpdateDescDlg"] = {
    "LoginDlg.plist",
    "MainIcon.plist"
  },
  ["UseBarDlg"] = {
    "MainIcon.plist"
  },
  ["UsefulPhraseEditorDlg"] = {
    "MainIcon.plist"
  },
  ["UserAddPointDlg"] = {
    "CharDlg.plist",
    "MainIcon.plist"
  },
  ["UserAddPointTabDlg"] = {},
  ["UserAgreementDlg"] = {
    "MainIcon.plist"
  },
  ["UserAutoAddPointDlg"] = {
    "MainIcon.plist"
  },
  ["UserCardDlg"] = {
    "MainIcon.plist"
  },
  ["UserChangeUpgradeDlg"] = {
    "MainIcon.plist"
  },
  ["UserDlg"] = {
    "CharDlg.plist",
    "MainIcon.plist"
  },
  ["UserInfoChildDlg"] = {
    "MainIcon.plist"
  },
  ["UserListDlg"] = {
    "MainIcon.plist"
  },
  ["UserLoginDlg"] = {
    "LoginDlg.plist"
  },
  ["UserRenameDlg"] = {
    "MainIcon.plist",
    "LoginDlg.plist"
  },
  ["UserRenameRuleDlg"] = {
    "MainIcon.plist"
  },
  ["UserSellDlg"] = {
    "MainIcon.plist"
  },
  ["UserTabDlg"] = {},
  ["UserUpgradeChangeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["UserUpgradeDlg"] = {
    "MainIcon.plist"
  },
  ["UserUpgradeRuleDlg"] = {
    "MainIcon.plist"
  },
  ["Vacation21Dlg"] = {
    "MainIcon.plist"
  },
  ["VacationHomeworkDlg"] = {},
  ["VacationPersimmonDlg"] = {
    "MainIcon.plist"
  },
  ["VacationSnowBowlingDlg"] = {
    "MainIcon.plist",
    "polaricon.plist"
  },
  ["VacationSnowBowlingInfoDlg"] = {
    "SnowBowling.plist"
  },
  ["VacationSnowDlg"] = {
    "MainIcon.plist"
  },
  ["VacationSnowSkillDlg"] = {
    "MainIcon.plist"
  },
  ["VacationTempDlg"] = {
    "MainIcon.plist",
    "skilltext.plist"
  },
  ["VacationWhiteDlg"] = {
    "MainIcon.plist"
  },
  ["ValueShopDlg"] = {
    "MainIcon.plist"
  },
  ["VisitingCardDlg"] = {
    "MainIcon.plist"
  },
  ["WaitDlg"] = {},
  ["WatchCentreBattleInterfaceDlg"] = {
    "WatchCentreDlg.plist",
    "MainIcon.plist"
  },
  ["WatchCentreDetailsDlg"] = {
    "MainIcon.plist",
    "WatchCentreDlg.plist"
  },
  ["WatchCentreDlg"] = {
    "MainIcon.plist",
    "WatchCentreDlg.plist"
  },
  ["WatchCentreTeamDlg"] = {
    "MainIcon.plist"
  },
  ["WatermelonDlg"] = {
    "MainIcon.plist"
  },
  ["WatermelonRaceDlg"] = {},
  ["WeddingAnniversaryDlg"] = {
    "MainIcon.plist"
  },
  ["WeddingBarrageDlg"] = {
    "MainIcon.plist"
  },
  ["WeddingBookDlg"] = {
    "MainIcon.plist"
  },
  ["WeddingDetailsTipsDlg"] = {},
  ["WeddingDiaryDlg"] = {},
  ["WeddingListChoseDlg"] = {
    "MainIcon.plist"
  },
  ["WeddinglistDlg"] = {
    "MainIcon.plist"
  },
  ["WeddingPhotoDlg"] = {},
  ["WeddingReserveDlg"] = {
    "MainIcon.plist"
  },
  ["WeiLBDPDlg"] = {
    "MainIcon.plist",
    "PetDlg.plist"
  },
  ["WelcomNewDlg"] = {
    "WelfareDlg.plist"
  },
  ["WelfareDlg"] = {
    "WelfareDlg.plist"
  },
  ["WenquanDlg"] = {
    "MainIcon.plist"
  },
  ["WenquangzDlg"] = {
    "MainIcon.plist"
  },
  ["WenquanjhDlg"] = {
    "MainIcon.plist"
  },
  ["WenquanRecordDlg"] = {
    "MainIcon.plist"
  },
  ["WenqxDlg"] = {
    "MainIcon.plist"
  },
  ["WenqxQuestionInfoDlg"] = {
    "MainIcon.plist"
  },
  ["WenqxRuleDlg"] = {
    "MainIcon.plist"
  },
  ["WenqxVerifyDlg"] = {
    "MainIcon.plist"
  },
  ["WineKingGameDlg"] = {
    "ChongYImage.plist"
  },
  ["WoodSoldierDlg"] = {
    "MainIcon.plist"
  },
  ["WoodSoldierRuleDlg"] = {
    "MainIcon.plist"
  },
  ["WoodSoldierTabDlg"] = {},
  ["WorldBossLifeDlg"] = {
    "MainIcon.plist"
  },
  ["WorldBossRankDlg"] = {
    "MainIcon.plist"
  },
  ["WorldBossResultDlg"] = {},
  ["WorldMapDlg"] = {
    "worldmap.plist"
  },
  ["WugfdDlg"] = {
    "MainIcon.plist"
  },
  ["WugfdRuleDlg"] = {
    "MainIcon.plist"
  },
  ["WulxjApplyDlg"] = {},
  ["WuXingGuessingDlg"] = {
    "MainIcon.plist",
    "wuxingguessing.plist",
    "polaricon.plist"
  },
  ["WuXingGuessingRewardDlg"] = {
    "MainIcon.plist"
  },
  ["WuxingStoreMoneyDlg"] = {
    "mall_cash.plist"
  },
  ["WuxingZodiacPlateExchangeDlg"] = {
    "MainIcon.plist"
  },
  ["WuxingZodiacPlateSubmitDlg"] = {
    "MainIcon.plist"
  },
  ["WuxtDlg"] = {
    "MainIcon.plist"
  },
  ["WuxtMartinIntroduceDlg"] = {},
  ["XiangXinDlg"] = {
    "MainIcon.plist"
  },
  ["XianMoAddPointDlg"] = {
    "CharDlg.plist",
    "MainIcon.plist"
  },
  ["XianMoAutoAddPointDlg"] = {
    "MainIcon.plist"
  },
  ["XianzdzzDlg"] = {
    "MainIcon.plist"
  },
  ["XianzdzzRuleDlg"] = {
    "MainIcon.plist"
  },
  ["XiaozjsDlg"] = {
    "MainIcon.plist"
  },
  ["XiaozjsgzDlg"] = {
    "MainIcon.plist"
  },
  ["XiaozjsjlDlg"] = {
    "MainIcon.plist"
  },
  ["XinnianqfDlg"] = {
    "MainIcon.plist",
    "LoginDlg.plist"
  },
  ["XinnianqfOpenDlg"] = {
    "MainIcon.plist"
  },
  ["XitclDlg"] = {},
  ["XiulmzDlg"] = {
    "MainIcon.plist"
  },
  ["XiulmzRuleDlg"] = {
    "MainIcon.plist"
  },
  ["XueqdzDlg"] = {
    "MainIcon.plist"
  },
  ["XueqdzTPDlg"] = {
    "MainIcon.plist"
  },
  ["XunBao2020Dlg"] = {
    "DramaDlg.plist"
  },
  ["XunBao2020TipsDlg"] = {
    "MainIcon.plist"
  },
  ["XunBaoBagDlg"] = {
    "MainIcon.plist"
  },
  ["XunBaoBuyDlg"] = {
    "MainIcon.plist"
  },
  ["XunBaoDlg"] = {
    "MainIcon.plist"
  },
  ["XunBaoTipsDlg"] = {
    "MainIcon.plist"
  },
  ["XunDaoCiFuDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["YanLuoMiBaoDlg"] = {
    "MainIcon.plist"
  },
  ["YGYSAprilFoolsDayHUDDlg"] = {
    "MainIcon.plist",
    "YGYSAprilFoolsDayImage.plist",
    "polaricon.plist"
  },
  ["YGYSAprilFoolsDayRuleDlg"] = {
    "YGYSAprilFoolsDayImage.plist"
  },
  ["YijxbDlg"] = {
    "PartyFireworks.plist"
  },
  ["YinhrdDlg"] = {
    "MainIcon.plist"
  },
  ["YinHunDlg"] = {
    "MainIcon.plist"
  },
  ["YinHunRuleDlg"] = {},
  ["YinHunShopDlg"] = {
    "MainIcon.plist"
  },
  ["YuanXiaoAppointmentDlg"] = {},
  ["YuanXiaoGuideDlg"] = {
    "MainIcon.plist"
  },
  ["ZaixqyDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["ZaixqyLetterDlg"] = {
    "ZaixqyLetter.plist",
    "DramaDlg.plist"
  },
  ["ZaoHuaDlg"] = {
    "WelfareDlg.plist",
    "MainIcon.plist"
  },
  ["ZhenMoluChangeBackDlg"] = {},
  ["ZhenMoluChangeDlg"] = {},
  ["ZhenMoLuHUDDlg"] = {
    "ZhenmoluImage.plist",
    "DramaDlg.plist"
  },
  ["ZhenMoLuResultDlg"] = {},
  ["ZhidbcDlg"] = {
    "MainIcon.plist"
  },
  ["ZhiDuoXingDlg"] = {
    "MainIcon.plist"
  },
  ["ZhiDuoXingInfoDlg"] = {
    "MainIcon.plist"
  },
  ["ZhiDuoXingRuleDlg"] = {
    "MainIcon.plist"
  },
  ["ZhidwdDlg"] = {},
  ["ZhidwdItemGetAndUseDlg"] = {},
  ["ZhidwdItemInfoDlg"] = {},
  ["ZhidwdRuleDlg"] = {},
  ["ZhisbpDlg"] = {
    "TZHJChildrenDayImage.plist",
    "PartyFireworks.plist",
    "TwoBirdFly.plist",
    "MainIcon.plist",
    "ZhisbpImg.plist",
    "FightDlg.plist"
  },
  ["ZhisbpGameDlg"] = {
    "ZhisbpImg.plist",
    "DramaDlg.plist"
  },
  ["ZhisbpRuleDlg"] = {
    "TwoBirdFly.plist"
  },
  ["ZhiShuDlg"] = {},
  ["ZhongqtyDlg"] = {
    "MainIcon.plist"
  },
  ["ZhongrscDlg"] = {
    "MainIcon.plist"
  },
  ["ZhongsqfDlg"] = {
    "MainIcon.plist"
  }
}
