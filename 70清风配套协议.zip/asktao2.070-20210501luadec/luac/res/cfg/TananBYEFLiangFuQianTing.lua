return {
  {
    class_id = 10019,
    x = 30,
    y = 41,
    dir = 0,
    cx = 10,
    cy = -11
  },
  {
    class_id = 10020,
    x = 50,
    y = 44,
    dir = 0,
    cx = -11,
    cy = 12
  },
  {
    class_id = 10020,
    x = 62,
    y = 60,
    dir = 0,
    cx = -10,
    cy = 10
  },
  {
    class_id = 10020,
    x = 86,
    y = 68,
    dir = 0,
    cx = -10,
    cy = 11
  },
  {
    class_id = 10020,
    x = 105,
    y = 61,
    dir = 0,
    cx = 1,
    cy = -7
  },
  {
    class_id = 10020,
    x = 125,
    y = 52,
    dir = 0,
    cx = 4,
    cy = 3
  },
  {
    class_id = 10020,
    x = 114,
    y = 42,
    dir = 0,
    cx = -12,
    cy = 11
  },
  {
    class_id = 10020,
    x = 137,
    y = 45,
    dir = 0,
    cx = 2,
    cy = -5
  },
  {
    class_id = 10020,
    x = 82,
    y = 20,
    dir = 0,
    cx = -11,
    cy = 10
  },
  {
    class_id = 10020,
    x = 74,
    y = 24,
    dir = 0,
    cx = -12,
    cy = 10
  },
  {
    class_id = 10020,
    x = 88,
    y = 23,
    dir = 0,
    cx = -10,
    cy = 11
  },
  {
    class_id = 10020,
    x = 72,
    y = 35,
    dir = 0,
    cx = -11,
    cy = 12
  },
  {
    class_id = 10137,
    x = 63,
    y = 45,
    dir = 0,
    cx = -2,
    cy = -1
  },
  {
    class_id = 10137,
    x = 76,
    y = 41,
    dir = 1,
    cx = 9,
    cy = 6
  },
  {
    class_id = 10137,
    x = 86,
    y = 45,
    dir = 1,
    cx = -10,
    cy = -10
  },
  {
    class_id = 10137,
    x = 89,
    y = 50,
    dir = 0,
    cx = -8,
    cy = 5
  },
  {
    class_id = 10018,
    x = 59,
    y = 41,
    dir = 1,
    cx = -8,
    cy = 11
  },
  {
    class_id = 10019,
    x = 35,
    y = 34,
    dir = 0,
    cx = 8,
    cy = 11
  },
  {
    class_id = 10020,
    x = 36,
    y = 31,
    dir = 0,
    cx = -12,
    cy = 12
  },
  {
    class_id = 10019,
    x = 41,
    y = 30,
    dir = 0,
    cx = -4,
    cy = 8
  },
  {
    class_id = 10019,
    x = 33,
    y = 34,
    dir = 0,
    cx = -12,
    cy = 8
  },
  {
    class_id = 10019,
    x = 39,
    y = 31,
    dir = 0,
    cx = 8,
    cy = -3
  },
  {
    class_id = 10020,
    x = 30,
    y = 44,
    dir = 0,
    cx = -12,
    cy = 10
  },
  {
    class_id = 10020,
    x = 30,
    y = 38,
    dir = 0,
    cx = -10,
    cy = 10
  },
  {
    class_id = 10016,
    x = 74,
    y = 32,
    dir = 1,
    cx = -10,
    cy = -1
  },
  {
    class_id = 10016,
    x = 73,
    y = 34,
    dir = 0,
    cx = 5,
    cy = 9
  },
  {
    class_id = 10016,
    x = 69,
    y = 30,
    dir = 0,
    cx = 9,
    cy = -5
  },
  {
    class_id = 10020,
    x = 100,
    y = 39,
    dir = 0,
    cx = -11,
    cy = 10
  },
  {
    class_id = 10020,
    x = 86,
    y = 32,
    dir = 0,
    cx = -10,
    cy = 10
  },
  {
    class_id = 10020,
    x = 104,
    y = 41,
    dir = 0,
    cx = -12,
    cy = 9
  },
  {
    class_id = 10019,
    x = 125,
    y = 59,
    dir = 0,
    cx = -6,
    cy = 5
  },
  {
    class_id = 10019,
    x = 107,
    y = 53,
    dir = 0,
    cx = 1,
    cy = 6
  },
  {
    class_id = 10031,
    x = 105,
    y = 64,
    dir = 0,
    cx = 9,
    cy = -3
  },
  {
    class_id = 10031,
    x = 113,
    y = 61,
    dir = 1,
    cx = 6,
    cy = -8
  },
  {
    class_id = 10031,
    x = 87,
    y = 56,
    dir = 0,
    cx = 11,
    cy = 8
  },
  {
    class_id = 10031,
    x = 80,
    y = 65,
    dir = 0,
    cx = 2,
    cy = -4
  },
  {
    class_id = 10031,
    x = 97,
    y = 67,
    dir = 0,
    cx = -7,
    cy = -2
  },
  {
    class_id = 10031,
    x = 92,
    y = 71,
    dir = 0,
    cx = -8,
    cy = -9
  },
  {
    class_id = 10014,
    x = 124,
    y = 41,
    dir = 0,
    cx = -8,
    cy = 9
  },
  {
    class_id = 10019,
    x = 115,
    y = 51,
    dir = 0,
    cx = 0,
    cy = 11
  },
  {
    class_id = 10019,
    x = 118,
    y = 38,
    dir = 0,
    cx = -4,
    cy = 12
  },
  {
    class_id = 10019,
    x = 112,
    y = 40,
    dir = 0,
    cx = 9,
    cy = -11
  },
  {
    class_id = 10019,
    x = 142,
    y = 44,
    dir = 0,
    cx = 3,
    cy = 2
  },
  {
    class_id = 10019,
    x = 147,
    y = 47,
    dir = 0,
    cx = -6,
    cy = -7
  },
  {
    class_id = 10019,
    x = 135,
    y = 49,
    dir = 0,
    cx = 8,
    cy = -1
  },
  {
    class_id = 10019,
    x = 136,
    y = 54,
    dir = 0,
    cx = -6,
    cy = 11
  },
  {
    class_id = 10019,
    x = 131,
    y = 55,
    dir = 0,
    cx = -5,
    cy = 3
  },
  {
    class_id = 10011,
    x = 126,
    y = 47,
    dir = 0,
    cx = -5,
    cy = 3
  },
  {
    class_id = 10031,
    x = 113,
    y = 52,
    dir = 0,
    cx = 2,
    cy = 9
  },
  {
    class_id = 10031,
    x = 110,
    y = 47,
    dir = 0,
    cx = -9,
    cy = -8
  },
  {
    class_id = 10031,
    x = 125,
    y = 54,
    dir = 1,
    cx = -4,
    cy = -6
  },
  {
    class_id = 10031,
    x = 131,
    y = 50,
    dir = 0,
    cx = -9,
    cy = -1
  },
  {
    class_id = 10031,
    x = 141,
    y = 47,
    dir = 0,
    cx = 11,
    cy = 12
  },
  {
    class_id = 10031,
    x = 118,
    y = 39,
    dir = 1,
    cx = -12,
    cy = 8
  },
  {
    class_id = 10031,
    x = 124,
    y = 35,
    dir = 0,
    cx = 7,
    cy = 2
  },
  {
    class_id = 10016,
    x = 76,
    y = 16,
    dir = 0,
    cx = -10,
    cy = -3
  },
  {
    class_id = 10016,
    x = 66,
    y = 16,
    dir = 0,
    cx = -2,
    cy = 1
  },
  {
    class_id = 10016,
    x = 74,
    y = 15,
    dir = 0,
    cx = 1,
    cy = 2
  },
  {
    class_id = 10016,
    x = 68,
    y = 15,
    dir = 0,
    cx = 1,
    cy = -9
  },
  {
    class_id = 10016,
    x = 72,
    y = 31,
    dir = 0,
    cx = -10,
    cy = 6
  },
  {
    class_id = 10016,
    x = 62,
    y = 25,
    dir = 0,
    cx = -3,
    cy = 8
  },
  {
    class_id = 10016,
    x = 86,
    y = 23,
    dir = 0,
    cx = 4,
    cy = 10
  },
  {
    class_id = 10016,
    x = 64,
    y = 24,
    dir = 0,
    cx = 10,
    cy = 9
  },
  {
    class_id = 10016,
    x = 67,
    y = 24,
    dir = 0,
    cx = -10,
    cy = 12
  },
  {
    class_id = 10016,
    x = 86,
    y = 21,
    dir = 0,
    cx = 9,
    cy = 12
  },
  {
    class_id = 10016,
    x = 88,
    y = 22,
    dir = 0,
    cx = 0,
    cy = 12
  },
  {
    class_id = 10016,
    x = 89,
    y = 23,
    dir = 0,
    cx = 2,
    cy = 3
  },
  {
    class_id = 10016,
    x = 85,
    y = 26,
    dir = 0,
    cx = 1,
    cy = -6
  },
  {
    class_id = 10016,
    x = 85,
    y = 28,
    dir = 0,
    cx = -11,
    cy = -2
  },
  {
    class_id = 10016,
    x = 87,
    y = 26,
    dir = 0,
    cx = 10,
    cy = 1
  },
  {
    class_id = 10016,
    x = 89,
    y = 25,
    dir = 0,
    cx = 5,
    cy = -9
  },
  {
    class_id = 10016,
    x = 80,
    y = 17,
    dir = 0,
    cx = -4,
    cy = 10
  },
  {
    class_id = 10016,
    x = 84,
    y = 19,
    dir = 0,
    cx = 0,
    cy = 3
  },
  {
    class_id = 10016,
    x = 83,
    y = 18,
    dir = 0,
    cx = 9,
    cy = 5
  },
  {
    class_id = 10016,
    x = 79,
    y = 16,
    dir = 0,
    cx = -9,
    cy = 7
  },
  {
    class_id = 10016,
    x = 77,
    y = 14,
    dir = 0,
    cx = -5,
    cy = -9
  },
  {
    class_id = 10016,
    x = 86,
    y = 19,
    dir = 0,
    cx = -6,
    cy = 1
  },
  {
    class_id = 10016,
    x = 88,
    y = 20,
    dir = 0,
    cx = 10,
    cy = 12
  },
  {
    class_id = 10016,
    x = 90,
    y = 18,
    dir = 0,
    cx = -4,
    cy = 3
  },
  {
    class_id = 10016,
    x = 81,
    y = 16,
    dir = 0,
    cx = 7,
    cy = -9
  },
  {
    class_id = 10016,
    x = 66,
    y = 22,
    dir = 1,
    cx = -1,
    cy = 0
  },
  {
    class_id = 10016,
    x = 62,
    y = 23,
    dir = 0,
    cx = 7,
    cy = 1
  },
  {
    class_id = 10016,
    x = 62,
    y = 22,
    dir = 1,
    cx = -12,
    cy = -10
  },
  {
    class_id = 10016,
    x = 65,
    y = 17,
    dir = 1,
    cx = 9,
    cy = -1
  },
  {
    class_id = 10016,
    x = 64,
    y = 18,
    dir = 1,
    cx = 4,
    cy = -3
  },
  {
    class_id = 10016,
    x = 63,
    y = 22,
    dir = 0,
    cx = -12,
    cy = 9
  },
  {
    class_id = 10016,
    x = 52,
    y = 23,
    dir = 0,
    cx = -1,
    cy = -2
  },
  {
    class_id = 10016,
    x = 50,
    y = 24,
    dir = 0,
    cx = 5,
    cy = -2
  },
  {
    class_id = 10016,
    x = 53,
    y = 24,
    dir = 0,
    cx = -1,
    cy = -6
  },
  {
    class_id = 10016,
    x = 54,
    y = 23,
    dir = 0,
    cx = 11,
    cy = -2
  },
  {
    class_id = 10016,
    x = 61,
    y = 19,
    dir = 0,
    cx = 8,
    cy = -6
  },
  {
    class_id = 10136,
    x = 59,
    y = 21,
    dir = 0,
    cx = -12,
    cy = -8
  },
  {
    class_id = 10136,
    x = 80,
    y = 13,
    dir = 1,
    cx = 11,
    cy = -11
  },
  {
    class_id = 10136,
    x = 86,
    y = 16,
    dir = 1,
    cx = 10,
    cy = -7
  },
  {
    class_id = 10140,
    x = 72,
    y = 16,
    dir = 1,
    cx = -5,
    cy = 6
  },
  {
    class_id = 10017,
    x = 45,
    y = 32,
    dir = 1,
    cx = -12,
    cy = 2
  },
  {
    class_id = 10017,
    x = 46,
    y = 33,
    dir = 1,
    cx = 1,
    cy = 9
  },
  {
    class_id = 10017,
    x = 48,
    y = 33,
    dir = 1,
    cx = -8,
    cy = -9
  },
  {
    class_id = 10019,
    x = 30,
    y = 36,
    dir = 0,
    cx = 2,
    cy = -3
  },
  {
    class_id = 10019,
    x = 27,
    y = 40,
    dir = 0,
    cx = 5,
    cy = 12
  },
  {
    class_id = 10019,
    x = 26,
    y = 43,
    dir = 0,
    cx = -5,
    cy = 11
  },
  {
    class_id = 10019,
    x = 26,
    y = 38,
    dir = 0,
    cx = 4,
    cy = 10
  },
  {
    class_id = 10019,
    x = 24,
    y = 40,
    dir = 0,
    cx = -7,
    cy = -11
  },
  {
    class_id = 10019,
    x = 21,
    y = 40,
    dir = 0,
    cx = -9,
    cy = 10
  },
  {
    class_id = 10141,
    x = 59,
    y = 32,
    dir = 0,
    cx = -12,
    cy = 8
  },
  {
    class_id = 10028,
    x = 44,
    y = 28,
    dir = 0,
    cx = -1,
    cy = 4
  },
  {
    class_id = 10025,
    x = 47,
    y = 43,
    dir = 1,
    cx = -6,
    cy = 11
  },
  {
    class_id = 10025,
    x = 53,
    y = 39,
    dir = 1,
    cx = 8,
    cy = -4
  },
  {
    class_id = 10025,
    x = 38,
    y = 47,
    dir = 1,
    cx = -12,
    cy = -3
  },
  {
    class_id = 10011,
    x = 40,
    y = 36,
    dir = 0,
    cx = -12,
    cy = 0
  },
  {
    class_id = 10137,
    x = 75,
    y = 53,
    dir = 1,
    cx = 11,
    cy = -11
  },
  {
    class_id = 10137,
    x = 67,
    y = 49,
    dir = 1,
    cx = 9,
    cy = -9
  },
  {
    class_id = 10020,
    x = 66,
    y = 52,
    dir = 0,
    cx = -10,
    cy = 11
  },
  {
    class_id = 10020,
    x = 72,
    y = 55,
    dir = 0,
    cx = -11,
    cy = 10
  },
  {
    class_id = 10139,
    x = 75,
    y = 46,
    dir = 0,
    cx = -3,
    cy = 8
  },
  {
    class_id = 10020,
    x = 90,
    y = 34,
    dir = 0,
    cx = -11,
    cy = 12
  },
  {floor_index = 2},
  {wall_index = 2}
}
