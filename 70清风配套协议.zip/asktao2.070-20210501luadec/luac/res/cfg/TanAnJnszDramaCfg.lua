return {
  EnterXuanYuanMiao = {
    {
      player = "",
      content = CHS[7120440]
    },
    {
      player = CHS[7120433],
      icon = 6213,
      content = CHS[7120441]
    },
    {
      player = "",
      content = CHS[7120442]
    },
    {
      player = "me",
      content = CHS[7120443],
      formatTag = "failNpc"
    }
  },
  XiangJiu = {
    {
      player = "me",
      content = CHS[7120424]
    },
    {
      player = CHS[7120433],
      icon = 6213,
      content = CHS[7120425]
    },
    {
      player = "me",
      content = CHS[7120426]
    },
    {
      player = "me",
      content = CHS[7120427]
    },
    {
      player = CHS[7120433],
      icon = 6213,
      content = CHS[7120428]
    },
    {
      player = "me",
      content = CHS[7120429],
      formatTag = "failNpc"
    },
    {
      player = "",
      content = CHS[7120430],
      formatTag = "me"
    },
    {
      player = "me",
      content = CHS[7120431]
    },
    {
      player = "",
      content = CHS[7120432]
    },
    {
      player = "me",
      content = CHS[7120557]
    }
  },
  YinRen = {
    {
      player = "me",
      content = CHS[7120434]
    },
    {
      player = "",
      content = CHS[7120435]
    },
    {
      player = "me",
      content = CHS[7120436],
      formatTag = "failNpc"
    },
    {
      player = CHS[7120433],
      icon = 6213,
      content = CHS[7120437]
    },
    {
      player = "",
      content = CHS[7120438]
    },
    {
      player = "me",
      content = CHS[7120439],
      formatTag = "failNpc"
    }
  },
  JianCha1 = {
    {
      player = CHS[7120448],
      icon = 6043,
      content = CHS[7120449],
      formatTag = "me"
    }
  },
  JianCha2 = {
    {
      player = CHS[7120447],
      icon = 6213,
      content = CHS[7120450]
    },
    {
      player = CHS[7120447],
      icon = 6213,
      content = CHS[7120451]
    },
    {
      player = "me",
      content = CHS[7120452]
    }
  },
  JianCha3 = {
    {
      player = "me",
      content = CHS[7120453]
    },
    {
      player = "me",
      content = CHS[7120454]
    }
  },
  JiNa1 = {
    {
      player = "me",
      content = CHS[7120455]
    },
    {
      player = CHS[7120448],
      icon = 6043,
      content = CHS[7120456]
    }
  },
  JiNa2 = {
    {
      player = CHS[7120447],
      icon = 6213,
      content = CHS[7120457]
    },
    {
      player = CHS[7120447],
      icon = 6213,
      content = CHS[7120458]
    },
    {
      player = "me",
      content = CHS[7120459]
    }
  },
  JiNa3 = {
    {
      player = "me",
      content = CHS[7120460]
    },
    {
      player = "me",
      content = CHS[7120461]
    }
  }
}
