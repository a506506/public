return {
  [CHS[3000180]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000182]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000183]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000184]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000185]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000186]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000187]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000188]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000189]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000190]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000181]
  },
  [CHS[3000191]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300038]
  },
  [CHS[3000193]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300039]
  },
  [CHS[3000194]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300040]
  },
  [CHS[3000195]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300041]
  },
  [CHS[3000196]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300042]
  },
  [CHS[3000197]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300043]
  },
  [CHS[3000198]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300044]
  },
  [CHS[3000199]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300045]
  },
  [CHS[3000200]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300046]
  },
  [CHS[3000201]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300047]
  },
  [CHS[3000202]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300048]
  },
  [CHS[3000203]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300049]
  },
  [CHS[3000204]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300050]
  },
  [CHS[3000205]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300051]
  },
  [CHS[3000206]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300052]
  },
  [CHS[3000207]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300053]
  },
  [CHS[3000208]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300054]
  },
  [CHS[3000209]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300055]
  },
  [CHS[3000210]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300056]
  },
  [CHS[3000211]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300057]
  },
  [CHS[3000212]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300058]
  },
  [CHS[3000213]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000192],
    canReport = true,
    rule = CHS[2300059]
  },
  [CHS[7190869]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[3000192],
    rule = "(.*) 帮派大功臣"
  },
  [CHS[7190870]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[3000192],
    rule = "(.*) 帮派元老"
  },
  [CHS[3000214]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000215]
  },
  [CHS[3000216]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[3000217]
  },
  ["试道强者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[3000217]
  },
  ["试道勇者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[3000217]
  },
  [CHS[3000218]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[3000220]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[3000221]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[3000222]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[3000223]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[3000224]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[3000225]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[4100243]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[4100266]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[4100267]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000219]
  },
  [CHS[3000226]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000227]
  },
  [CHS[3000228]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000227]
  },
  [CHS[3000229]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000227]
  },
  [CHS[3000230]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000227]
  },
  [CHS[3000231]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000227]
  },
  [CHS[3000232]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000234]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000235]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000236]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000237]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000238]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000239]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000240]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000241]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000242]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000243]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[4100251]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[4100252]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[4100253]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[4100254]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[4100255]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[4100256]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[4100257]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[7002272]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[7002273]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[7002274]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[7190103]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[7100446]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[2500146]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[2500147]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[3000233]
  },
  [CHS[3000244]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[3000245],
    reviewRes = CHS[3000246]
  },
  [CHS[3000247]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[3000248],
    reviewRes = CHS[3000249]
  },
  [CHS[3000250]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[3000251],
    reviewRes = CHS[3000252]
  },
  [CHS[4000363]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4000364]
  },
  [CHS[4000365]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4000366]
  },
  [CHS[4000367]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4000368]
  },
  [CHS[4000369]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4000370]
  },
  [CHS[4300019]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4300020]
  },
  [CHS[4300021]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4300022]
  },
  [CHS[4300023]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4300022]
  },
  [CHS[4300024]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4300026]
  },
  [CHS[4300025]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4300026]
  },
  [CHS[4000371]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4000372]
  },
  [CHS[4000373]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4000374]
  },
  [CHS[4000375]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4000376]
  },
  [CHS[4400000]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4400001]
  },
  [CHS[6000292]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[6000294],
    rule = CHS[2300062]
  },
  [CHS[6000293]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[6000294],
    rule = CHS[2300063]
  },
  [CHS[4300101]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4300053],
    rule = CHS[2300064]
  },
  [CHS[4100288]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100293]
  },
  [CHS[4100289]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100294]
  },
  [CHS[4100290]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100295]
  },
  [CHS[4100291]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100296]
  },
  [CHS[4100292]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100297]
  },
  [CHS[7000006]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7000009]
  },
  [CHS[7000007]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7000010]
  },
  [CHS[7000008]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7000011]
  },
  [CHS[7000024]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[7000027]
  },
  [CHS[7000025]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7000027]
  },
  [CHS[7000026]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7000027]
  },
  [CHS[4100333]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100334]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100335]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100336]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4100339]
  },
  [CHS[4100337]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4100339]
  },
  [CHS[4100338]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4100339]
  },
  [CHS[4100373]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100374]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100375]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100376]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100377]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100378]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100379]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100380]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100381]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100382]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100383]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100384]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[4100385]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4100339]
  },
  [CHS[6600003]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[6600004]
  },
  [CHS[6600005]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[6600004]
  },
  [CHS[6600006]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[6600004]
  },
  [CHS[6600007]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[6600004]
  },
  [CHS[6600008]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[6600004]
  },
  [CHS[6600009]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[6600004]
  },
  [CHS[4300100]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[3000217]
  },
  [CHS[6200074]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[6200075]
  },
  [CHS[5420001]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[5420002]
  },
  [CHS[4300161]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4300162]
  },
  [CHS[4300163]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4300164]
  },
  [CHS[7002092]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7002093]
  },
  [CHS[7002304]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7002305]
  },
  [CHS[4100949]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4100950]
  },
  [CHS[4300165]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4300166]
  },
  [CHS[7000166]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7000168]
  },
  [CHS[7000167]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7000168]
  },
  [CHS[5420004]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[5420005]
  },
  [CHS[7000269]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7000271]
  },
  [CHS[7000270]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[7000271]
  },
  [CHS[5420077]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5420079]
  },
  [CHS[5420078]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[5420079]
  },
  [CHS[5420080]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[5420082]
  },
  [CHS[5420081]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[5420082]
  },
  [CHS[5430001]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5430004]
  },
  [CHS[5430002]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5430004]
  },
  [CHS[5430003]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5430004]
  },
  [CHS[5420128]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5420129]
  },
  [CHS[5400024]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[5400023]
  },
  [CHS[5400025]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[5400023]
  },
  [CHS[5400026]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[5400023]
  },
  ["跨服试道·天下道君"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[5400023]
  },
  [CHS[4100495]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4100496]
  },
  [CHS[6000567]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[6000572]
  },
  [CHS[6000568]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[6000573]
  },
  [CHS[6000569]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[6000574]
  },
  [CHS[6000570]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[6000575]
  },
  [CHS[6000571]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[6000576]
  },
  [CHS[7002187]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7002193]
  },
  [CHS[7002188]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7002193]
  },
  [CHS[7002189]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7002193]
  },
  [CHS[7100283]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7002193]
  },
  [CHS[7002190]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7002193]
  },
  [CHS[7002191]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7002193]
  },
  [CHS[7001043]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7002193]
  },
  [CHS[7002192]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7002193]
  },
  [CHS[7100284]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7002193]
  },
  [CHS[7003035]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7002193]
  },
  [CHS[7100285]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7100286]
  },
  [CHS[4200269]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400001]
  },
  [CHS[7002211]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[7002211],
    canReport = true,
    rule = "getJiBaiChengWeiRule"
  },
  [CHS[2300061]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "固定队结交",
    canReport = true,
    rule = CHS[2300060]
  },
  [CHS[7002222]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[7002226]
  },
  [CHS[7002223]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[7002226]
  },
  [CHS[7002224]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7002226]
  },
  [CHS[7002225]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7002226]
  },
  [CHS[2200042]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[2200044]
  },
  [CHS[2200043]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[2200044]
  },
  [CHS[4400022]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[4400024]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[4400025]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[4400026]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[4400027]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[4400028]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[4400029]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[4400030]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[4400031]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4400023]
  },
  [CHS[7004002]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4400023]
  },
  [CHS[7004003]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4400023]
  },
  [CHS[7004004]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4400023]
  },
  [CHS[2000350]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[2000349]
  },
  [CHS[2000351]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[2000349]
  },
  [CHS[2000352]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[2000349]
  },
  [CHS[2000353]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[2000349]
  },
  [CHS[2200047]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[2200048]
  },
  [CHS[8000012]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[8000013]
  },
  ["中洲世界·古道热肠"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年国庆节活动"
  },
  [CHS[7150002]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7150004]
  },
  [CHS[7150003]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7150004]
  },
  [CHS[7150005]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7150004]
  },
  [CHS[7150006]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7150004]
  },
  [CHS[5400126]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[5400128]
  },
  [CHS[5400127]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5400128]
  },
  [CHS[4100703]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4100704]
  },
  [CHS[4100705]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4100704]
  },
  [CHS[4100706]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4100704]
  },
  [CHS[4100707]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4100704]
  },
  [CHS[4100708]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4100704]
  },
  [CHS[5400212]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = string.format(CHS[5400217], 2)
  },
  [CHS[5400213]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = string.format(CHS[5400217], 3)
  },
  [CHS[5400214]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = string.format(CHS[5400217], 4)
  },
  [CHS[5400215]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = string.format(CHS[5400217], 5)
  },
  [CHS[5400216]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = string.format(CHS[5400217], 6)
  },
  [CHS[5450028]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[5450031]
  },
  [CHS[5450029]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[5450031]
  },
  [CHS[5450030]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5450031]
  },
  [CHS[4300269]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4300270]
  },
  [CHS[4100835]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = string.format(CHS[4100836], 1000)
  },
  [CHS[4100837]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = string.format(CHS[4100836], 2000)
  },
  [CHS[4100838]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = string.format(CHS[4100836], 3000)
  },
  [CHS[4100839]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = string.format(CHS[4100836], 4000)
  },
  [CHS[4100840]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = string.format(CHS[4100836], 5000)
  },
  [CHS[4100841]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = string.format(CHS[4100836], 6000)
  },
  [CHS[4100842]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = string.format(CHS[4100836], 7000)
  },
  [CHS[4100843]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4100844]
  },
  [CHS[4100845]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4100846]
  },
  [CHS[5420230]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5420231]
  },
  [CHS[5410194]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[5410198]
  },
  [CHS[5410195]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[5410199]
  },
  [CHS[5410196]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[5410200]
  },
  [CHS[5410197]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5410201]
  },
  [CHS[5000281]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5000283]
  },
  [CHS[5000282]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5000284]
  },
  [CHS[7190109]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7190111]
  },
  [CHS[7190110]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7190111]
  },
  [CHS[2200071]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[2200072]
  },
  [CHS[5400406]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[5400341]
  },
  [CHS[5400335]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5400341]
  },
  [CHS[5400336]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[5400341]
  },
  [CHS[5400337]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[5400341]
  },
  [CHS[5400338]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[5400341]
  },
  [CHS[5400339]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[5400341]
  },
  [CHS[5400340]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[5400341]
  },
  [CHS[5400342]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[5400341]
  },
  [CHS[5450095]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = string.format(CHS[5450105], CHS[6000055])
  },
  [CHS[5450096]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = string.format(CHS[5450105], CHS[6000056])
  },
  [CHS[5450097]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = string.format(CHS[5450105], CHS[6000057])
  },
  [CHS[5450098]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = string.format(CHS[5450105], CHS[6000058])
  },
  [CHS[5450099]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = string.format(CHS[5450105], CHS[6000059])
  },
  [CHS[5450100]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = string.format(CHS[5450105], CHS[6000060])
  },
  [CHS[5450101]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = string.format(CHS[5450105], CHS[6000061])
  },
  [CHS[5450102]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = string.format(CHS[5450105], CHS[6000062])
  },
  [CHS[5450103]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = string.format(CHS[5450105], CHS[6000063])
  },
  [CHS[5450104]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = string.format(CHS[5450105], CHS[6000064])
  },
  [CHS[4101014]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4101015]
  },
  [CHS[4101016]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4101015]
  },
  [CHS[4101017]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4101015]
  },
  [CHS[4101018]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[4101015]
  },
  [CHS[4101019]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4101015]
  },
  [CHS[4101020]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4101015]
  },
  [CHS[4101021]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4101015]
  },
  [CHS[5000288]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4101015]
  },
  [CHS[4101022]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4101015]
  },
  [CHS[4010028]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4010027]
  },
  [CHS[4010029]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4010027]
  },
  [CHS[4010030]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4010027]
  },
  [CHS[7333469]] = {
    color = cc.c3b(255, 102, 0),
    rescourse = CHS[7333470]
  },
  ["新入道途"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "证道殿"
  },
  ["初领妙道"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "证道殿"
  },
  ["渐入佳境"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "证道殿"
  },
  ["道心稳固"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "证道殿"
  },
  ["妙领天机"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "证道殿"
  },
  ["脱胎换骨"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "证道殿"
  },
  ["霞举飞升"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "证道殿"
  },
  ["道满根归"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "证道殿"
  },
  ["不堕轮回"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "证道殿"
  },
  ["已证大道"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "证道殿"
  },
  ["返璞归真"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "证道殿"
  },
  ["言出法随"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "证道殿"
  },
  ["黑市人品王"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "客栈经营随机触发事件"
  },
  ["明耀界人品王"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书随机事件"
  },
  [CHS[4300410]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4300411]
  },
  ["中洲记者团"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "官方认证"
  },
  ["初出江湖"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4010027]
  },
  ["初显锋芒"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4010027]
  },
  ["声名鹊起"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[4010027]
  },
  ["锋芒毕露"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4010027]
  },
  ["声名显赫"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[4010027]
  },
  ["如雷贯耳"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4010027]
  },
  ["威风八面"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4010027]
  },
  ["德高望重"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4010027]
  },
  ["威震九洲"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4010027]
  },
  ["常胜将军"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4010027]
  },
  ["战无不胜"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4010027]
  },
  ["中洲战神"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[4010027]
  },
  ["初出茅庐"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "英雄会"
  },
  ["盖世英雄"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "英雄会"
  },
  ["威震中洲"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "英雄会"
  },
  ["仙风道骨"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "南天门试炼"
  },
  [CHS[7190218]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[7190223]
  },
  [CHS[7190219]] = {
    color = cc.c3b(25, 177, 255),
    rescourse = CHS[7190223]
  },
  [CHS[7190220]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7190223]
  },
  [CHS[7190221]] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7190223]
  },
  [CHS[7190222]] = {
    color = cc.c3b(255, 255, 0),
    rescourse = CHS[7190223]
  },
  ["整蛊王"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = CHS[7190223]
  },
  ["中洲世界·四方棋圣"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2018年国庆节活动"
  },
  ["中秋大胃王"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2018年中秋节活动"
  },
  ["全民PK赛事管理员"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "全民PK赛"
  },
  ["名人争霸赛事管理员"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "名人争霸赛"
  },
  ["镇魔天师·道法无边"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2018年万圣节活动"
  },
  ["九天真君·朱天君"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜九天真君·朱天君"
  },
  ["九天真君·成天君"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜九天真君·成天君"
  },
  ["九天真君·幽天君"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜九天真君·幽天君"
  },
  ["九天真君·玄天君"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜九天真君·玄天君"
  },
  ["九天真君·变天君"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜九天真君·变天君"
  },
  ["九天真君·钧天君"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜九天真君·钧天君"
  },
  ["楼兰宝物守卫者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年元旦活动"
  },
  ["踩雪块高手"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "2019年寒假活动"
  },
  ["踏雪无痕"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年寒假活动"
  },
  ["悍土孤城·绝密卧底"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "活跃抽大奖"
  },
  ["悍土孤城·天才智囊"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "活跃抽大奖"
  },
  ["悍土孤城·冷酷杀手"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "活跃抽大奖"
  },
  ["悍土孤城·最佳拍档"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "活跃抽大奖"
  },
  ["悍土孤城·团队领袖"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "活跃抽大奖"
  },
  ["寻宝专家"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年新春寻宝活动"
  },
  ["甜粽爱好者"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "2019年端午节活动"
  },
  ["咸粽爱好者"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "2019年端午节活动"
  },
  ["地宫勘探大师"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年清明节活动"
  },
  ["翻牌高手"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年周年庆活动之萌宠翻牌"
  },
  ["冰火行者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年暑假活动之冰火考验"
  },
  ["红方代表"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "2019年暑假活动之生肖对决"
  },
  ["蓝方代表"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "2019年暑假活动之生肖对决"
  },
  ["文曲星"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = ""
  },
  ["扶摇直上九重天"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2020年周年纪念商城兑换"
  },
  ["声乐新星"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "问道好声音活动"
  },
  ["歌唱高手"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "问道好声音活动"
  },
  ["实力唱将"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "问道好声音活动"
  },
  ["震惊四座"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "问道好声音活动"
  },
  ["醉人之语"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "问道好声音活动"
  },
  ["苍穹之声"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "问道好声音活动"
  },
  ["天籁之音"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "问道好声音活动"
  },
  ["此声为君而起"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "问道好声音活动"
  },
  ["生肖对决高手"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "在2019年暑假活动之生肖对决中获得胜利"
  },
  ["生肖对决王者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "在2019年暑假活动之生肖对决中连续战胜7个对手"
  },
  ["划船小能手"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "在2019年暑假活动之小舟竞赛中获得第一名"
  },
  ["划船我最快"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "在2019年暑假活动之小舟竞赛中连续7次游戏获得第一名"
  },
  ["青城论道记者"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "青城论道"
  },
  ["青城论道"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "参与青城论道活动"
  },
  ["月饼小能手"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "2019年中秋节活动"
  },
  ["中秋月饼王"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年中秋节活动"
  },
  ["迷阵大师"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2019年教师节活动之门派迷阵"
  },
  ["守护者"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "合服"
  },
  ["炼狱冥炎·怒气冲天"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首杀六层怒意下的炼狱冥炎"
  },
  ["炼狱冥炎·怒发冲冠"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首杀七层怒意下的炼狱冥炎"
  },
  ["炼狱冥炎·金刚怒目"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首杀八层怒意下的炼狱冥炎"
  },
  ["炼狱冥炎·雷霆之怒"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首杀九层怒意下的炼狱冥炎"
  },
  ["全民PK·龙争虎斗"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "全民PK赛"
  },
  ["好运来"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "周华健好运礼包"
  },
  ["以爆制暴"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2020年春节活动之爆竹驱妖"
  },
  ["中洲世界·我是锦鲤"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "天灯祈福"
  },
  ["保龄球高手"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "2020年寒假活动"
  },
  ["雪中送烫"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2020年寒假活动"
  },
  ["金牌拍卖师"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2020年寒假活动"
  },
  ["同心连理"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "2020年同心节活动"
  },
  ["花开并蒂共此时"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2020年同心节活动"
  },
  ["跨服帮战·天下第一帮"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "跨服帮战"
  },
  ["跨服帮战·权倾天下"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "跨服帮战"
  },
  ["跨服帮战·雄霸一方"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "跨服帮战"
  },
  ["跨服帮战记者"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "跨服帮战"
  },
  ["斗鸡王者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2020年清明节活动之清明斗鸡"
  },
  ["我有一只墨麒麟"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "完成成就“竟然是墨麒麟！”"
  },
  ["四周年"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "周年纪念商城",
    canReport = true,
    rule = "四周年·(.*)"
  },
  ["神魔辟易·九幽冥雀"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首杀九幽冥雀"
  },
  ["神魔辟易·真武魔帝"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首杀真武魔帝"
  },
  ["神魔辟易·东山邪灵"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首杀东山邪灵"
  },
  ["神魔辟易·杀戮魔皇"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首杀杀戮魔皇"
  },
  ["520·偏偏喜欢你"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2020年520表白活动"
  },
  ["七夕·"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "2020年七夕活动",
    canReport = true,
    rule = "七夕·(.*)"
  },
  ["有情人终成眷属"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "问道陪你过大年活动"
  },
  ["与问道一起过春节"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "问道陪你过大年活动"
  },
  ["红方"] = {
    color = cc.c3b(221, 24, 23),
    rescourse = "2020年七夕活动"
  },
  ["蓝方"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "2020年七夕活动"
  },
  ["食神"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "食神季活动"
  },
  ["鹭岛论道"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "参与鹭岛论道活动"
  },
  ["天界先行者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "天界专属测试活动"
  },
  ["五行对决王者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2020年教师节活动之五行对决"
  },
  ["情比金坚"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "完成成就“情比金坚”"
  },
  ["至死不渝"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "完成成就“至死不渝”"
  },
  ["洛书·花谷榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·伏龙穴榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·葬神冢榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·幽冥城榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·桃花源榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·北冥榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·梦荷境榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·东海乡榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·诛仙阵榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·世外荒漠榜首"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "洛书榜"
  },
  ["洛书·花谷十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·伏龙穴十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·葬神冢十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·幽冥城十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·桃花源十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·北冥十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·梦荷境十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·东海乡十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·诛仙阵十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["洛书·世外荒漠十强"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "洛书榜"
  },
  ["天庭征讨先锋"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "天界扬名任务"
  },
  ["擂台霸王"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "擂台霸王玩法"
  },
  ["擂台小霸王"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "擂台霸王玩法"
  },
  ["横扫乾坤·魔龙之首"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜魔龙之首"
  },
  ["横扫乾坤·魔龙吞天"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜魔龙吞天"
  },
  ["横扫乾坤·魔龙吞天·怒"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "首先战胜魔龙吞天·怒"
  },
  ["阴魂"] = {
    color = cc.c3b(255, 102, 0)
  },
  ["中洲最强预言家"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "名人争霸赛"
  },
  ["中洲竞猜达人"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "名人争霸赛"
  },
  ["中洲竞猜高手"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "名人争霸赛"
  },
  ["罗刹寨喽啰"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "探案任务"
  },
  ["黑风寨喽啰"] = {
    color = cc.c3b(25, 177, 255),
    rescourse = "探案任务"
  },
  ["鞭炮毁灭者"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "2021年周年庆活动之燃放鞭炮"
  },
  ["我爱放鞭炮"] = {
    color = cc.c3b(232, 115, 255),
    rescourse = "2021年周年庆活动之燃放鞭炮"
  },
  ["九亿少女的梦"] = {
    color = cc.c3b(255, 255, 0),
    rescourse = "代言人林更新分享活动"
  },
  ["5周年·与道为伍"] = {
    color = cc.c3b(255, 102, 0),
    rescourse = "五周年专属礼包"
  }
}
