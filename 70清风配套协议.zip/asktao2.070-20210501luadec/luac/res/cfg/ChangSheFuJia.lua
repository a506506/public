return {
  {
    class_id = 10088,
    x = 24,
    y = 23,
    dir = 0,
    cx = -6,
    cy = 4
  },
  {
    class_id = 10066,
    x = 51,
    y = 34,
    dir = 1,
    cx = -2,
    cy = -5
  },
  {
    class_id = 10066,
    x = 36,
    y = 35,
    dir = 0,
    cx = -9,
    cy = 0
  },
  {
    class_id = 10108,
    x = 18,
    y = 28,
    dir = 0,
    cx = -3,
    cy = -4
  },
  {
    class_id = 10058,
    x = 42,
    y = 39,
    dir = 0,
    cx = -3,
    cy = -8
  },
  {
    class_id = 10052,
    x = 62,
    y = 34,
    dir = 11,
    cx = 7,
    cy = -7
  },
  {
    class_id = 10062,
    x = 59,
    y = 32,
    dir = 0,
    cx = 8,
    cy = -7
  },
  {
    class_id = 10131,
    x = 70,
    y = 27,
    dir = 1,
    cx = 10,
    cy = 8
  },
  {
    class_id = 10129,
    x = 19,
    y = 28,
    dir = 0,
    cx = 5,
    cy = 3
  },
  {
    class_id = 10083,
    x = 17,
    y = 25,
    dir = 0,
    cx = -10,
    cy = 8
  },
  {
    class_id = 10066,
    x = 32,
    y = 20,
    dir = 1,
    cx = -5,
    cy = -7
  },
  {
    class_id = 10066,
    x = 50,
    y = 18,
    dir = 0,
    cx = -9,
    cy = 6
  },
  {
    class_id = 10044,
    x = 41,
    y = 14,
    dir = 0,
    cx = -10,
    cy = 1
  },
  {
    class_id = 10103,
    x = 30,
    y = 14,
    dir = 0,
    cx = 7,
    cy = 3
  },
  {
    class_id = 10095,
    x = 73,
    y = 22,
    dir = 1,
    cx = -5,
    cy = 3
  },
  {
    class_id = 10095,
    x = 49,
    y = 10,
    dir = 1,
    cx = -2,
    cy = 3
  },
  {
    class_id = 10095,
    x = 38,
    y = 10,
    dir = 0,
    cx = 7,
    cy = 3
  },
  {
    class_id = 10095,
    x = 27,
    y = 16,
    dir = 0,
    cx = -12,
    cy = 6
  },
  {
    class_id = 10095,
    x = 14,
    y = 22,
    dir = 0,
    cx = 10,
    cy = 4
  }
}
