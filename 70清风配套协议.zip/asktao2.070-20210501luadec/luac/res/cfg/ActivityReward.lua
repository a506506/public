return {
  {
    activity = 20,
    icon = 9012,
    reward = CHS[3000165]
  },
  {
    activity = 40,
    icon = 9013,
    reward = CHS[3000166]
  },
  {
    activity = 60,
    icon = 9002,
    reward = CHS[3000167]
  },
  {
    activity = 80,
    reward = CHS[7000013]
  },
  {
    activity = 100,
    icon = CHS[3000169],
    reward = CHS[3000170],
    testDistReward = CHS[4200003]
  }
}
