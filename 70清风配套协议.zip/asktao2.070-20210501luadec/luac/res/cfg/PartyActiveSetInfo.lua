return {
  [CHS[4010491]] = {
    setupFuncName = "setBPYHOpenType",
    setupDataName = "partyBpyhSetInfo",
    actServerName = "party_bpyh",
    destFmtStr = CHS[7100838],
    msgName = "MSG_PARTY_BPYH_SETUP",
    cmdName = "CMD_PARTY_BPYH_SETUP"
  },
  [CHS[2500181]] = {
    setupFuncName = "setHyxsOpenType",
    setupDataName = "hyxsSetupData",
    actServerName = "party_hyxs",
    destFmtStr = CHS[2500186],
    msgName = "MSG_PARTY_HYXS_SETUP",
    cmdName = "CMD_PARTY_HYXS_SETUP"
  },
  [CHS[2500182]] = {
    setupFuncName = "setBpcfkOpenType",
    setupDataName = "bpcfkSetupData",
    actServerName = "party_bpcfk",
    destFmtStr = CHS[2500187],
    msgName = "MSG_PARTY_BPCFK_SETUP",
    cmdName = "CMD_PARTY_BPCFK_SETUP"
  },
  [CHS[4010492]] = {
    setupFuncName = "setBPWQOpenType",
    setupDataName = "partyBpwqSetInfo",
    actServerName = "party_bpwq",
    destFmtStr = CHS[7100839],
    msgName = "MSG_PARTY_BPWQ_SETUP",
    cmdName = "CMD_PARTY_BPWQ_SETUP"
  },
  [CHS[7366676]] = {
    setupFuncName = "setBpyhuoOpenType",
    setupDataName = "partyBpyhuoSetInfo",
    actServerName = "party_bpyhuo",
    destFmtStr = CHS[7366678],
    msgName = "MSG_PARTY_BPYHUO_SETUP",
    cmdName = "CMD_PARTY_BPYHUO_SETUP"
  }
}
