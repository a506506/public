return {
  {
    class_id = 10093,
    x = 37,
    y = 15,
    dir = 0,
    cx = 10,
    cy = 0
  },
  {
    class_id = 10059,
    x = 68,
    y = 26,
    dir = 1,
    cx = -9,
    cy = -6
  },
  {
    class_id = 10080,
    x = 58,
    y = 35,
    dir = 0,
    cx = 2,
    cy = -4
  },
  {
    class_id = 10083,
    x = 32,
    y = 18,
    dir = 0,
    cx = 6,
    cy = -6
  },
  {
    class_id = 10067,
    x = 36,
    y = 30,
    dir = 1,
    cx = -9,
    cy = 7
  },
  {
    class_id = 10047,
    x = 25,
    y = 21,
    dir = 0,
    cx = -4,
    cy = 5
  },
  {
    class_id = 10107,
    x = 30,
    y = 36,
    dir = 1,
    cx = -5,
    cy = 8
  },
  {
    class_id = 10044,
    x = 46,
    y = 15,
    dir = 1,
    cx = -12,
    cy = 8
  }
}
