local FILT_TYPE = {
  PLAYER_NAME = 1,
  PARTY_NAME = 2,
  NONE = 0
}
local MATCH_CFG = {
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛小组赛的一场比赛中战胜对手#Y(.*)#n，获得了3点小组积分，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛小组赛的一场比赛中轮空，比赛胜利，获得了3点小组积分。",
    filtTypeList = {}
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛小组赛的一场比赛中负于对手#Y(.*)#n，未获得小组积分，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛小组赛的一场比赛中与对手#Y(.*)#n战平，获得了1点小组积分，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛半决赛中战胜对手#Y(.*)#n，顺利进入决赛，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛半决赛中轮空，比赛胜利，顺利进入决赛。",
    filtTypeList = {}
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛半决赛中负于对手#Y(.*)#n，未能进入决赛，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛决赛中战胜对手#Y(.*)#n，得到了本届帮战联赛(.*)的冠军，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛决赛中轮空，比赛胜利，得到了本届帮战联赛(.*)的冠军。",
    filtTypeList = {
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛决赛中负于对手#Y(.*)#n，得到了本届帮战联赛(.*)的亚军，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛三四名决赛中战胜对手#Y(.*)#n，得到了本届帮战联赛(.*)的季军，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛三四名决赛中轮空，比赛胜利，得到了本届帮战联赛(.*)的季军。",
    filtTypeList = {
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150715],
    text = "本帮在帮战联赛淘汰赛三四名决赛中负于对手#Y(.*)#n，得到了本届帮战联赛(.*)的第四名，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    text = "【人事】(.*)招收了新成员#Y#<(.*)#>#n进入帮派。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【人事】(.*)将#Y#<(.*)#>#n逐出了帮派。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【人事】很遗憾，#Y#<(.*)#>#n离开了帮派，独自闯荡中洲了。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【管理】本帮#R帮主#n#Y#<(.*)#>#n将职位传给了#Y#<(.*)#>#n，(.*)天后#Y#<(.*)#>#n将成为新帮主。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【管理】本帮#R帮主#n#Y#<(.*)#>#n将职位传给了#Y#<(.*)#>#n，#Y#<(.*)#>#n成为了新帮主。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【管理】#n#Y#<(.*)#>#n取消了对#n#Y#<(.*)#>#n的帮主传位。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【管理】#Y#<(.*)#>#n进行了自荐帮主的操作。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【管理】#R(.*)#n#Y#<(.*)#>#n将#Y#<(.*)#>#n的职位由#R(.*)#n变更为#R(.*)#n。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    text = "【管理】#Y#<(.*)#>#n离开了帮派，#Y(.*)#n的职位自动空缺。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【管理】#Y#<(.*)#>#n、#Y#<(.*)#>#n、#Y#<(.*)#>#n、#Y#<(.*)#>#n、#Y#<(.*)#>#n分别成为了本周帮派的#R(.*)#n、#R(.*)#n、#R(.*)#n、#R(.*)#n、#R(.*)#n。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150719],
    text = "由于本帮资金短缺，故暂停发放俸禄一周。",
    filtTypeList = {}
  },
  {
    type = CHS[7150718],
    text = "通过大家的努力，本帮升级为#R(.*)#n。",
    filtTypeList = {
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150718],
    text = "由于经营不善，本帮降级为#R(.*)#n。",
    filtTypeList = {
      FILT_TYPE.NONE
    }
  },
  {
    text = "【活动】本帮进行了帮派庆典活动，在此次帮派庆典中帮派纪念塔建设到了#R(.*)#n阶段，庆典气氛程度达到了#R(.*)#n。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    text = "【帮派改名】本帮#R(.*)#n#Y(.*)#n将原帮派名称#Y(.*)#n更改为#Y(.*)#n。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.PARTY_NAME
    }
  },
  {
    text = "【人事】#R(.*)#n#Y#<(.*)#>#n辞职成为帮众。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R帮派智多星#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R帮派智多星#n活动结束了，欢迎下次大家积极踊跃参加。",
    filtTypeList = {}
  },
  {
    text = "【活动】(.*)",
    filtTypeList = {
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150718],
    text = "本帮#R帮主#n#Y(.*)#n花费了(.*)点帮派建设度和(.*)文帮派资金，将#R(.*)#n研发至#R(.*)#n级。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150718],
    text = "本帮#R帮主#n#Y(.*)#n更换了帮派图标。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    type = CHS[7150718],
    text = "本帮#R帮主#n#Y(.*)#n清除了帮派图标。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    type = CHS[7150718],
    text = "本帮#R帮主#n#Y(.*)#n上传了帮派图标，请等待客服人员审核。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    type = CHS[7150718],
    text = "本帮#R帮主#n#Y(.*)#n上传的帮派图标已被客服审核通过，帮派图标已成功更换。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    type = CHS[7150718],
    text = "本帮#R帮主#n#Y(.*)#n上传的帮派图标已被客服审核拒绝，帮派图标更换失败。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    type = CHS[7150718],
    text = "本帮#R帮主#n#Y(.*)#n上传的帮派图标，客服未能按时审核，帮派图标更换失败。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    type = CHS[7150718],
    text = "由于帮派图标系统调整，本帮在自带列表中挑选的图标已被回收。",
    filtTypeList = {}
  },
  {
    type = CHS[7150720],
    text = "本帮#Y(.*)#n为帮派捐献了(.*)，帮派活力值提升了#R(.*)点#n！",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150718],
    text = "#R帮派智多星#n活动开启，求助设置为#R(.*)#n，扣除(.*)。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R培育巨兽#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R培育巨兽#n活动已经结束，经过本帮成员的共同努力，巨兽最终成长度为#R(.*)#n。",
    filtTypeList = {
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R挑战巨兽#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R挑战巨兽#n活动挑战阶段已经结束，经过大家的共同努力，帮派巨兽已被击败，本帮真是实力超群啊！",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R挑战巨兽#n活动挑战阶段已经结束，经过大家的共同努力，帮派巨兽血量剩余#R(.*)%%#n，请大家下次活动再接再厉！",
    filtTypeList = {
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150718],
    text = "#Y(.*)#n将申请入帮自动接受条件调整为最低(.*)级、(.*)年道行。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150718],
    text = "#Y(.*)#n开启了申请入帮自动接受功能，接受条件为最低(.*)级、(.*)年道行。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150718],
    text = "#Y(.*)#n关闭了申请入帮自动接受功能。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R帮派宴会#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R帮派宴会#n活动结束了，欢迎下次大家积极踊跃参加。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R混元仙树#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R混元仙树#n活动结束了，欢迎下次大家积极踊跃参加。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R帮派踩方块#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R帮派踩方块#n活动结束了，欢迎下次大家积极踊跃参加。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R帮派温泉#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R帮派温泉#n活动结束了，欢迎下次大家积极踊跃参加。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R帮派圈圈乐#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R帮派圈圈乐#n活动结束了，欢迎下次大家积极踊跃参加。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "本帮开启了#R帮派焰火#n活动。",
    filtTypeList = {}
  },
  {
    type = CHS[7150717],
    text = "#R帮派焰火#n活动结束了，欢迎下次大家积极踊跃参加。",
    filtTypeList = {}
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛小组赛的一场比赛中战胜来自#R(.*)#n的对手#Y(.*)#n，获得了3点小组积分，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛小组赛的一场比赛中负于来自#R(.*)#n的对手#Y(.*)#n，未获得小组积分，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛小组赛的一场比赛中与来自#R(.*)#n的对手#Y(.*)#n战平，获得了1点小组积分，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛小组赛中脱颖而出，顺利晋级8强。",
    filtTypeList = {}
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛小组赛中脱颖而出，顺利晋级16强。",
    filtTypeList = {}
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛小组赛中未能出线。",
    filtTypeList = {}
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛淘汰赛8进4比赛中战胜来自#R(.*)#n的对手#Y(.*)#n，顺利进入半决赛，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛淘汰赛8进4比赛中负于来自#R(.*)#n的对手#Y(.*)#n，未能进入半决赛，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛淘汰赛16进8比赛中战胜来自#R(.*)#n的对手#Y(.*)#n，顺利进入下一轮比赛，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛淘汰赛16进8比赛中负于来自#R(.*)#n的对手#Y(.*)#n，未能进入下一轮比赛，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛淘汰赛半决赛中战胜来自#R(.*)#n的对手#Y(.*)#n，顺利进入决赛，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛淘汰赛半决赛中负于来自#R(.*)#n的对手#Y(.*)#n，未能进入决赛，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛淘汰赛决赛中战胜来自#R(.*)#n的对手#Y(.*)#n，得到了本届帮战联赛第(.*)赛区的冠军，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    type = CHS[7150716],
    text = "本帮在跨服帮战联赛淘汰赛决赛中负于来自#R(.*)#n的对手#Y(.*)#n，得到了本届帮战联赛第(.*)赛区的亚军，有#R(.*)#n位成员参加本次帮战。",
    filtTypeList = {
      FILT_TYPE.NONE,
      FILT_TYPE.PARTY_NAME,
      FILT_TYPE.NONE,
      FILT_TYPE.NONE
    }
  },
  {
    text = "【人事】(.*)将#Y(.*)#n拉入本帮黑名单。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME
    }
  },
  {
    text = "【人事】(.*)将#Y#<(.*)#>#n逐出了帮派，并拉入本帮黑名单。",
    filtTypeList = {
      FILT_TYPE.PLAYER_NAME,
      FILT_TYPE.PLAYER_NAME
    }
  }
}
local RET_TEXT = {
  {
    text = "本帮在帮战联赛小组赛的一场比赛中战胜对手#Y%s#n，获得了3点小组积分，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在帮战联赛小组赛的一场比赛中轮空，比赛胜利，获得了3点小组积分。"
  },
  {
    text = "本帮在帮战联赛小组赛的一场比赛中负于对手#Y%s#n，未获得小组积分，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在帮战联赛小组赛的一场比赛中与对手#Y%s#n战平，获得了1点小组积分，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在帮战联赛淘汰赛半决赛中战胜对手#Y%s#n，顺利进入决赛，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在帮战联赛淘汰赛半决赛中轮空，比赛胜利，顺利进入决赛。"
  },
  {
    text = "本帮在帮战联赛淘汰赛半决赛中负于对手#Y%s#n，未能进入决赛，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在帮战联赛淘汰赛决赛中战胜对手#Y%s#n，得到了本届帮战联赛%s的冠军，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在帮战联赛淘汰赛决赛中轮空，比赛胜利，得到了本届帮战联赛%s的冠军。"
  },
  {
    text = "本帮在帮战联赛淘汰赛决赛中负于对手#Y%s#n，得到了本届帮战联赛%s的亚军，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在帮战联赛淘汰赛三四名决赛中战胜对手#Y%s#n，得到了本届帮战联赛%s的季军，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在帮战联赛淘汰赛三四名决赛中轮空，比赛胜利，得到了本届帮战联赛%s的季军。"
  },
  {
    text = "本帮在帮战联赛淘汰赛三四名决赛中负于对手#Y%s#n，得到了本届帮战联赛%s的第四名，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "【人事】%s招收了新成员#Y#<%s#>#n进入帮派。"
  },
  {
    text = "【人事】%s将#Y#<%s#>#n逐出了帮派。"
  },
  {
    text = "【人事】很遗憾，#Y#<%s#>#n离开了帮派，独自闯荡中洲了。"
  },
  {
    text = "【管理】本帮#R帮主#n#Y#<%s#>#n将职位传给了#Y#<%s#>#n，%s天后#Y#<%s#>#n将成为新帮主。"
  },
  {
    text = "【管理】本帮#R帮主#n#Y#<%s#>#n将职位传给了#Y#<%s#>#n，#Y#<%s#>#n成为了新帮主。"
  },
  {
    text = "【管理】#n#Y#<%s#>#n取消了对#n#Y#<%s#>#n的帮主传位。"
  },
  {
    text = "【管理】#Y#<%s#>#n进行了自荐帮主的操作。"
  },
  {
    text = "【管理】#R%s#n#Y#<%s#>#n将#Y#<%s#>#n的职位由#R%s#n变更为#R%s#n。"
  },
  {
    text = "【管理】#Y#<%s#>#n离开了帮派，#Y%s#n的职位自动空缺。"
  },
  {
    text = "【管理】#Y#<%s#>#n、#Y#<%s#>#n、#Y#<%s#>#n、#Y#<%s#>#n、#Y#<%s#>#n分别成为了本周帮派的#R%s#n、#R%s#n、#R%s#n、#R%s#n、#R%s#n。"
  },
  {
    text = "由于本帮资金短缺，故暂停发放俸禄一周。"
  },
  {
    text = "通过大家的努力，本帮升级为#R%s#n。"
  },
  {
    text = "由于经营不善，本帮降级为#R%s#n。"
  },
  {
    text = "【活动】本帮进行了帮派庆典活动，在此次帮派庆典中帮派纪念塔建设到了#R%s#n阶段，庆典气氛程度达到了#R%s#n。"
  },
  {
    text = "【帮派改名】本帮#R%s#n#Y%s#n将原帮派名称#Y%s#n更改为#Y%s#n。"
  },
  {
    text = "【人事】#R%s#n#Y#<%s#>#n辞职成为帮众。"
  },
  {
    text = "本帮开启了#R帮派智多星#n活动。"
  },
  {
    text = "#R帮派智多星#n活动结束了，欢迎下次大家积极踊跃参加。"
  },
  {
    text = "【活动】%s"
  },
  {
    text = "本帮#R帮主#n#Y%s#n花费了%s点帮派建设度和%s文帮派资金，将#R%s#n研发至#R%s#n级。"
  },
  {
    text = "本帮#R帮主#n#Y%s#n更换了帮派图标。"
  },
  {
    text = "本帮#R帮主#n#Y%s#n清除了帮派图标。"
  },
  {
    text = "本帮#R帮主#n#Y%s#n上传了帮派图标，请等待客服人员审核。"
  },
  {
    text = "本帮#R帮主#n#Y%s#n上传的帮派图标已被客服审核通过，帮派图标已成功更换。"
  },
  {
    text = "本帮#R帮主#n#Y%s#n上传的帮派图标已被客服审核拒绝，帮派图标更换失败。"
  },
  {
    text = "本帮#R帮主#n#Y%s#n上传的帮派图标，客服未能按时审核，帮派图标更换失败。"
  },
  {
    text = "由于帮派图标系统调整，本帮在自带列表中挑选的图标已被回收。"
  },
  {
    text = "本帮#Y%s#n为帮派捐献了%s，帮派活力值提升了#R%s点#n！"
  },
  {
    text = "#R帮派智多星#n活动开启，求助设置为#R%s#n，扣除%s。"
  },
  {
    text = "本帮开启了#R培育巨兽#n活动。"
  },
  {
    text = "#R培育巨兽#n活动已经结束，经过本帮成员的共同努力，巨兽最终成长度为#R%s#n。"
  },
  {
    text = "本帮开启了#R挑战巨兽#n活动。"
  },
  {
    text = "#R挑战巨兽#n活动挑战阶段已经结束，经过大家的共同努力，帮派巨兽已被击败，本帮真是实力超群啊！"
  },
  {
    text = "#R挑战巨兽#n活动挑战阶段已经结束，经过大家的共同努力，帮派巨兽血量剩余#R%s%%#n，请大家下次活动再接再厉！"
  },
  {
    text = "#Y%s#n将申请入帮自动接受条件调整为最低%s级、%s年道行。"
  },
  {
    text = "#Y%s#n开启了申请入帮自动接受功能，接受条件为最低%s级、%s年道行。"
  },
  {
    text = "#Y%s#n关闭了申请入帮自动接受功能。"
  },
  {
    text = "本帮开启了#R帮派宴会#n活动。"
  },
  {
    text = "#R帮派宴会#n活动结束了，欢迎下次大家积极踊跃参加。"
  },
  {
    text = "本帮开启了#R混元仙树#n活动。"
  },
  {
    text = "#R混元仙树#n活动结束了，欢迎下次大家积极踊跃参加。"
  },
  {
    text = "本帮开启了#R帮派踩方块#n活动。"
  },
  {
    text = "#R帮派踩方块#n活动结束了，欢迎下次大家积极踊跃参加。"
  },
  {
    text = "本帮开启了#R帮派温泉#n活动。"
  },
  {
    text = "#R帮派温泉#n活动结束了，欢迎下次大家积极踊跃参加。"
  },
  {
    text = "本帮开启了#R帮派圈圈乐#n活动。"
  },
  {
    text = "#R帮派圈圈乐#n活动结束了，欢迎下次大家积极踊跃参加。"
  },
  {
    text = "本帮开启了#R帮派焰火#n活动。"
  },
  {
    text = "#R帮派焰火#n活动结束了，欢迎下次大家积极踊跃参加。"
  },
  {
    text = "本帮在跨服帮战联赛小组赛的一场比赛中战胜来自#R%s#n的对手#Y%s#n，获得了3点小组积分，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛小组赛的一场比赛中负于来自#R%s#n的对手#Y%s#n，未获得小组积分，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛小组赛的一场比赛中与来自#R%s#n的对手#Y%s#n战平，获得了1点小组积分，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛小组赛中脱颖而出，顺利晋级8强。"
  },
  {
    text = "本帮在跨服帮战联赛小组赛中脱颖而出，顺利晋级16强。"
  },
  {
    text = "本帮在跨服帮战联赛小组赛中未能出线。"
  },
  {
    text = "本帮在跨服帮战联赛淘汰赛8进4比赛中战胜来自#R%s#n的对手#Y%s#n，顺利进入半决赛，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛淘汰赛8进4比赛中负于来自#R%s#n的对手#Y%s#n，未能进入半决赛，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛淘汰赛16进8比赛中战胜来自#R%s#n的对手#Y%s#n，顺利进入下一轮比赛，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛淘汰赛16进8比赛中负于来自#R%s#n的对手#Y%s#n，未能进入下一轮比赛，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛淘汰赛半决赛中战胜来自#R%s#n的对手#Y%s#n，顺利进入决赛，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛淘汰赛半决赛中负于来自#R%s#n的对手#Y%s#n，未能进入决赛，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛淘汰赛决赛中战胜来自#R%s#n的对手#Y%s#n，得到了本届帮战联赛第%s赛区的冠军，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "本帮在跨服帮战联赛淘汰赛决赛中负于来自#R%s#n的对手#Y%s#n，得到了本届帮战联赛第%s赛区的亚军，有#R%s#n位成员参加本次帮战。"
  },
  {
    text = "【人事】%s将#Y%s#n拉入本帮黑名单。"
  },
  {
    text = "【人事】%s将#Y#<%s#>#n逐出了帮派，并拉入本帮黑名单。"
  }
}
for i = 1, #MATCH_CFG do
  MATCH_CFG[i].retText = RET_TEXT[i].text
end
return MATCH_CFG
