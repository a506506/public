return {
  {
    class_id = 10142,
    x = 91,
    y = 63,
    dir = 0,
    cx = 10,
    cy = 0
  },
  {
    class_id = 10015,
    x = 121,
    y = 59,
    dir = 1,
    cx = -4,
    cy = -1
  },
  {
    class_id = 10139,
    x = 118,
    y = 52,
    dir = 1,
    cx = 11,
    cy = -2
  },
  {
    class_id = 10022,
    x = 83,
    y = 38,
    dir = 0,
    cx = 11,
    cy = -8
  },
  {
    class_id = 10022,
    x = 90,
    y = 41,
    dir = 0,
    cx = -12,
    cy = -7
  },
  {
    class_id = 10022,
    x = 76,
    y = 42,
    dir = 0,
    cx = -10,
    cy = -6
  },
  {
    class_id = 10030,
    x = 139,
    y = 47,
    dir = 0,
    cx = -1,
    cy = 0
  },
  {
    class_id = 10030,
    x = 131,
    y = 43,
    dir = 0,
    cx = 6,
    cy = 0
  },
  {
    class_id = 10033,
    x = 84,
    y = 16,
    dir = 0,
    cx = 10,
    cy = 9
  },
  {
    class_id = 10033,
    x = 78,
    y = 12,
    dir = 0,
    cx = 5,
    cy = -8
  },
  {
    class_id = 10023,
    x = 113,
    y = 40,
    dir = 0,
    cx = -4,
    cy = -6
  },
  {
    class_id = 10023,
    x = 85,
    y = 26,
    dir = 0,
    cx = -5,
    cy = -5
  },
  {
    class_id = 10022,
    x = 78,
    y = 51,
    dir = 0,
    cx = -11,
    cy = -8
  },
  {
    class_id = 10022,
    x = 71,
    y = 48,
    dir = 0,
    cx = 8,
    cy = -7
  },
  {
    class_id = 10022,
    x = 82,
    y = 45,
    dir = 0,
    cx = -11,
    cy = -7
  },
  {
    class_id = 10022,
    x = 64,
    y = 52,
    dir = 0,
    cx = -11,
    cy = -8
  },
  {
    class_id = 10022,
    x = 70,
    y = 55,
    dir = 0,
    cx = -12,
    cy = -7
  },
  {
    class_id = 10030,
    x = 124,
    y = 39,
    dir = 0,
    cx = -4,
    cy = -1
  },
  {
    class_id = 10015,
    x = 102,
    y = 41,
    dir = 0,
    cx = 0,
    cy = 8
  },
  {
    class_id = 10012,
    x = 73,
    y = 37,
    dir = 0,
    cx = 3,
    cy = 2
  },
  {
    class_id = 10012,
    x = 96,
    y = 49,
    dir = 0,
    cx = 1,
    cy = 4
  },
  {
    class_id = 10031,
    x = 30,
    y = 38,
    dir = 0,
    cx = 0,
    cy = -4
  },
  {
    class_id = 10042,
    x = 41,
    y = 33,
    dir = 0,
    cx = -4,
    cy = -1
  },
  {
    class_id = 10027,
    x = 107,
    y = 45,
    dir = 0,
    cx = 6,
    cy = -6
  },
  {
    class_id = 10150,
    x = 50,
    y = 27,
    dir = 0,
    cx = 9,
    cy = -9
  },
  {
    class_id = 10135,
    x = 73,
    y = 20,
    dir = 0,
    cx = 7,
    cy = 12
  },
  {floor_index = 2},
  {wall_index = 2}
}
