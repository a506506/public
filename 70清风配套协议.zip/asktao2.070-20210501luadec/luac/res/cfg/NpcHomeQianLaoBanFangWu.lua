return {
  {
    class_id = 10061,
    x = 83,
    y = 41,
    dir = 1,
    cx = -8,
    cy = 12
  },
  {
    class_id = 10073,
    x = 80,
    y = 48,
    dir = 0,
    cx = 2,
    cy = 11
  },
  {
    class_id = 10117,
    x = 52,
    y = 51,
    dir = 0,
    cx = -3,
    cy = 6
  },
  {
    class_id = 10115,
    x = 61,
    y = 57,
    dir = 0,
    cx = -2,
    cy = -3
  },
  {
    class_id = 10109,
    x = 52,
    y = 53,
    dir = 1,
    cx = 3,
    cy = 0
  },
  {
    class_id = 10068,
    x = 42,
    y = 33,
    dir = 0,
    cx = -4,
    cy = 9
  },
  {
    class_id = 10085,
    x = 52,
    y = 36,
    dir = 0,
    cx = 8,
    cy = 8
  },
  {
    class_id = 10089,
    x = 25,
    y = 35,
    dir = 0,
    cx = -7,
    cy = 2
  },
  {
    class_id = 10090,
    x = 63,
    y = 49,
    dir = 0,
    cx = -4,
    cy = -11
  },
  {
    class_id = 10091,
    x = 64,
    y = 37,
    dir = 0,
    cx = 3,
    cy = -9
  },
  {
    class_id = 10068,
    x = 31,
    y = 39,
    dir = 0,
    cx = -5,
    cy = 11
  },
  {
    class_id = 10068,
    x = 46,
    y = 47,
    dir = 0,
    cx = 8,
    cy = 10
  },
  {
    class_id = 10057,
    x = 30,
    y = 31,
    dir = 0,
    cx = -3,
    cy = -10
  },
  {
    class_id = 10130,
    x = 28,
    y = 30,
    dir = 0,
    cx = -3,
    cy = 7
  },
  {
    class_id = 10076,
    x = 24,
    y = 31,
    dir = 0,
    cx = 0,
    cy = -6
  },
  {
    class_id = 10094,
    x = 34,
    y = 27,
    dir = 0,
    cx = 1,
    cy = 9
  },
  {
    class_id = 10060,
    x = 93,
    y = 31,
    dir = 1,
    cx = 5,
    cy = 2
  },
  {
    class_id = 10068,
    x = 82,
    y = 28,
    dir = 0,
    cx = 4,
    cy = 8
  },
  {
    class_id = 10068,
    x = 72,
    y = 33,
    dir = 0,
    cx = -4,
    cy = 3
  },
  {
    class_id = 10068,
    x = 71,
    y = 48,
    dir = 1,
    cx = -10,
    cy = -4
  },
  {
    class_id = 10068,
    x = 61,
    y = 43,
    dir = 1,
    cx = -11,
    cy = -1
  },
  {
    class_id = 10099,
    x = 46,
    y = 13,
    dir = 0,
    cx = 3,
    cy = 11
  },
  {
    class_id = 10099,
    x = 34,
    y = 19,
    dir = 0,
    cx = 4,
    cy = 12
  },
  {
    class_id = 10099,
    x = 22,
    y = 25,
    dir = 0,
    cx = 2,
    cy = 12
  },
  {
    class_id = 10099,
    x = 72,
    y = 13,
    dir = 1,
    cx = 10,
    cy = 9
  },
  {
    class_id = 10099,
    x = 97,
    y = 25,
    dir = 1,
    cx = -9,
    cy = 4
  },
  {
    class_id = 10102,
    x = 63,
    y = 8,
    dir = 1,
    cx = 5,
    cy = 2
  },
  {
    class_id = 10045,
    x = 59,
    y = 15,
    dir = 0,
    cx = -7,
    cy = 11
  },
  {
    class_id = 10048,
    x = 48,
    y = 17,
    dir = 0,
    cx = -6,
    cy = -1
  },
  {
    class_id = 10051,
    x = 70,
    y = 19,
    dir = 1,
    cx = 1,
    cy = 11
  },
  {
    class_id = 10081,
    x = 16,
    y = 34,
    dir = 0,
    cx = -7,
    cy = 9
  },
  {
    class_id = 10068,
    x = 42,
    y = 24,
    dir = 1,
    cx = -5,
    cy = -8
  },
  {
    class_id = 10068,
    x = 71,
    y = 22,
    dir = 0,
    cx = 10,
    cy = -4
  },
  {
    class_id = 10068,
    x = 61,
    y = 27,
    dir = 0,
    cx = 2,
    cy = -11
  },
  {
    class_id = 10073,
    x = 44,
    y = 21,
    dir = 0,
    cx = 5,
    cy = -1
  },
  {floor_index = 3}
}
