return {
  ["竹木茶桌"] = {
    icon = 10010,
    unit = "张",
    descript = "竹木制成的茶桌，结实耐用",
    double_type = 0,
    rescourse = {
      "居所前庭购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    furniture_type = "前庭-桌凳",
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["大理石方桌"] = {
    icon = 10011,
    unit = "张",
    descript = "大理石制成的方桌，端庄大气",
    double_type = 0,
    rescourse = {
      "居所前庭购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    furniture_type = "前庭-桌凳",
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["满月玉石桌"] = {
    icon = 10012,
    unit = "张",
    descript = "精雕玉镯的高级石桌，造价昂贵",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    furniture_type = "前庭-桌凳",
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["竹木圆凳"] = {
    icon = 10013,
    unit = "张",
    descript = "竹木材质的小圆凳，算不上精巧但相当实用",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    furniture_type = "前庭-桌凳",
    purchase_type = 1,
    purchase_cost = 400,
    level = 1,
    comfort = 4,
    sell_price = 1333300
  },
  ["大理石圆凳"] = {
    icon = 10014,
    unit = "张",
    descript = "大理石材质的小圆凳，常见于园林之中",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    furniture_type = "前庭-桌凳",
    purchase_type = 1,
    purchase_cost = 800,
    level = 2,
    comfort = 8,
    sell_price = 2666600
  },
  ["金镶玉长椅"] = {
    icon = 10015,
    unit = "张",
    descript = "精致而华丽的玉质长椅，富贵之家的最爱",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    furniture_type = "前庭-桌凳",
    purchase_type = 1,
    purchase_cost = 2000,
    level = 3,
    comfort = 20,
    sell_price = 6666600
  },
  ["月季（花盆）"] = {
    icon = 10016,
    unit = "盆",
    furniture_type = "前庭-摆设",
    descript = "月季只应天上物，四时荣谢色常同",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 300,
    level = 1,
    comfort = 3,
    sell_price = 1000000,
    clickRect = {
      height = 44,
      width = 36,
      x = -9,
      y = -34
    }
  },
  ["君子兰（花盆）"] = {
    icon = 10017,
    unit = "盆",
    furniture_type = "前庭-摆设",
    descript = "兰生幽谷无人识，客种东轩遗我香",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 300,
    level = 1,
    comfort = 3,
    sell_price = 1000000
  },
  ["山水盆景"] = {
    icon = 10018,
    unit = "盆",
    furniture_type = "前庭-摆设",
    descript = "胜日寻芳泗水滨，无边光景一时新",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300,
    clickRect = {
      height = 92,
      width = 86,
      x = -20,
      y = -45
    }
  },
  ["金桔花盆"] = {
    icon = 10019,
    unit = "盆",
    furniture_type = "前庭-摆设",
    descript = "个个和枝叶捧鲜，彩凝犹带洞庭烟",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 800,
    level = 2,
    comfort = 8,
    sell_price = 2666600
  },
  ["石质宫灯"] = {
    icon = 10020,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "矮小的石灯，适合放在庭院的小路旁边",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 800,
    level = 2,
    comfort = 8,
    sell_price = 2666600
  },
  ["金砖玲珑塔"] = {
    icon = 10021,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "华丽而精致装饰塔，适合放在庭院中装饰",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["金顶宫灯"] = {
    icon = 10022,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "小而精致的灯，适合放在庭院的小路旁边",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["鎏金双宫灯"] = {
    icon = 10023,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "造型独特，材质高级的矮灯，常见于富贵之家的庭院",
    double_type = 0,
    rescourse = {
      "居所前庭购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:三级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 2000,
    level = 3,
    comfort = 20,
    sell_price = 6666600
  },
  ["矮木屏风"] = {
    icon = 10024,
    unit = "扇",
    furniture_type = "前庭-摆设",
    descript = "矮矮的木质屏风，常见于寻常人家庭院中",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["大理石屏风"] = {
    icon = 10025,
    unit = "扇",
    furniture_type = "前庭-摆设",
    descript = "大理石雕花屏风，可放在庭院中做隔断之用",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["白玉屏风"] = {
    icon = 10026,
    unit = "扇",
    furniture_type = "前庭-摆设",
    descript = "昂贵的汉白玉所制屏风，常见于富贵之家的庭院",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["金丝鸟笼"] = {
    icon = 10027,
    unit = "座",
    furniture_type = "前庭-功能",
    descript = "黄金制成的鸟笼，华丽而精致",
    special_func = "使用后提升宠物饲养获得数值",
    double_type = 2,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 2,
    comfort = 0,
    max_dur = 1000,
    sell_price = 100
  },
  ["龙龟鹤"] = {
    icon = 10028,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "黄金制成的雕像，寓意长寿",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["青铜鼎"] = {
    icon = 10029,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "古朴的青铜材质鼎，古时的煮器，如今可作为庭院中的装饰",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["金鼎"] = {
    icon = 10030,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "只有富贵之家才可用得起的昂贵金鼎",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["木质武器架"] = {
    icon = 10032,
    unit = "个",
    furniture_type = "前庭-摆设",
    descript = "木头制的武器架，架子上有一些较为简朴的武器",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 400,
    level = 1,
    comfort = 4,
    sell_price = 1333300
  },
  ["金属武器架"] = {
    icon = 10033,
    unit = "个",
    furniture_type = "前庭-摆设",
    descript = "金属制的武器架，架子上有各种高级的武器",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 800,
    level = 2,
    comfort = 8,
    sell_price = 2666600
  },
  ["玫瑰花圃"] = {
    icon = 10136,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "红色鲜艳的玫瑰花圃，放在前庭里让氛围变得格外热情",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 800,
    level = 2,
    comfort = 8,
    sell_price = 2666600
  },
  ["兰花花圃"] = {
    icon = 10137,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "白色素雅的兰花花圃，放在前庭里让氛围变得格外诗意",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 800,
    level = 2,
    comfort = 8,
    sell_price = 2666600
  },
  ["石质照壁"] = {
    icon = 10138,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "普通石材制成的照壁，可放于前庭门口附近，具有一定观赏性",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300,
    clickRect = {
      height = 236,
      width = 359,
      x = -180,
      y = -147
    }
  },
  ["精致照壁"] = {
    icon = 10139,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "高级石材制成的精致照壁，可放于前庭门口附近，具有一定观赏性",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300,
    clickRect = {
      height = 291,
      width = 380,
      x = -193,
      y = -190
    }
  },
  ["优雅石亭"] = {
    icon = 10140,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "石质的乘凉亭子，可放于前庭中，在炎炎的夏日也不担心被晒了",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 2,
    purchase_cost = 240,
    level = 2,
    comfort = 12,
    sell_price = 1200000,
    clickRect = {
      height = 367,
      width = 364,
      x = -185,
      y = -220
    }
  },
  ["小桥流水"] = {
    icon = 10141,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "人造中型院景，放在前庭中，让整个环境都清雅了很多",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 2,
    purchase_cost = 240,
    level = 2,
    comfort = 12,
    sell_price = 1200000,
    clickRect = {
      height = 325,
      width = 600,
      x = -305,
      y = -138
    }
  },
  ["金顶镇宅塔"] = {
    icon = 10142,
    unit = "座",
    furniture_type = "前庭-摆设",
    descript = "人造中型塔，放在前庭中，威严而不失霸气",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 3000,
    level = 3,
    comfort = 30,
    sell_price = 10000000
  },
  ["竹围栏"] = {
    icon = 10034,
    unit = "个",
    furniture_type = "前庭-围墙",
    descript = "竹质围栏，简单实用",
    double_type = 0,
    rescourse = {
      "居所初始家具"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 1,
    comfort = 0,
    wall_index = 0,
    sell_price = 0
  },
  ["石围墙"] = {
    icon = 10035,
    unit = "个",
    furniture_type = "前庭-围墙",
    descript = "石质围墙，端庄大气",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 1200,
    level = 2,
    comfort = 12,
    wall_index = 1,
    sell_price = 4000000
  },
  ["精致围墙"] = {
    icon = 10036,
    unit = "个",
    furniture_type = "前庭-围墙",
    descript = "高级石材制成的精致围墙，墙上带有精致雕工的装饰",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 3000,
    level = 3,
    comfort = 30,
    wall_index = 2,
    sell_price = 10000000
  },
  ["绿草地面"] = {
    icon = 10037,
    unit = "片",
    furniture_type = "前庭-地面",
    descript = "青青绿草地，自然简朴",
    double_type = 0,
    rescourse = {
      "居所初始家具"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 1,
    comfort = 0,
    tile_index = 0,
    sell_price = 0
  },
  ["石砖地面"] = {
    icon = 10038,
    unit = "片",
    furniture_type = "前庭-地面",
    descript = "石质地砖，端庄大气",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 1400,
    level = 2,
    comfort = 14,
    tile_index = 1,
    sell_price = 4666600
  },
  ["大理石地面"] = {
    icon = 10039,
    unit = "片",
    furniture_type = "前庭-地面",
    descript = "米白色精致石砖，高贵精致",
    double_type = 0,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 3500,
    level = 3,
    comfort = 35,
    tile_index = 2,
    sell_price = 11666600
  },
  ["招财树"] = {
    icon = 10031,
    unit = "棵",
    furniture_type = "前庭-功能",
    descript = "各种珍宝组成的宝树，摇动此树会有意想不到的收获 ",
    special_func = "招财纳福所需家具，#R需本人购买才可使用#n ",
    double_type = 2,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 2,
    purchase_cost = 1220,
    level = 2,
    comfort = 50,
    max_dur = 200,
    sell_price = 5000000,
    clickRect = {
      height = 200,
      width = 180,
      x = -90,
      y = -120
    }
  },
  ["浅碟食盆"] = {
    icon = 10040,
    unit = "个",
    furniture_type = "前庭-功能",
    descript = "浅浅的宠物食盆，看起来能装的食物并不多",
    special_func = "宠物饲养所需家具，1个食盆可饲养1只宠物，单人同时最多可饲养3只，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 830,
    level = 1,
    comfort = 5,
    sell_price = 1666600,
    max_capacity = 60
  },
  ["阔口食盆"] = {
    icon = 10041,
    unit = "个",
    furniture_type = "前庭-功能",
    descript = "较大的宠物食盆，看起来能装不少的食物",
    special_func = "宠物饲养所需家具，1个食盆可饲养1只宠物，单人同时最多可饲养3只，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 1660,
    level = 2,
    comfort = 10,
    sell_price = 3333300,
    max_capacity = 120
  },
  ["鎏金食盆"] = {
    icon = 10042,
    unit = "个",
    furniture_type = "前庭-功能",
    descript = "华丽而精致的宠物食盆，容量看起来也不小",
    special_func = "宠物饲养所需家具，1个食盆可饲养1只宠物，单人同时最多可饲养3只，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 1,
    purchase_cost = 3600,
    level = 3,
    comfort = 25,
    sell_price = 8333300,
    max_capacity = 200
  },
  ["演武木桩"] = {
    icon = 10135,
    unit = "座",
    furniture_type = "前庭-功能",
    descript = "以上等木料注入天地三清之气制成的木桩，能通灵识",
    special_func = "演武试炼所需家具，使用后可召唤出木头人陪练，检测自身实力",
    double_type = 2,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@",
      "居所前庭购买"
    },
    purchase_type = 2,
    purchase_cost = 500,
    max_dur = 50,
    level = 1,
    comfort = 0,
    sell_price = 2500000
  },
  ["西域飞毯·前庭"] = {
    icon = 10146,
    unit = "张",
    furniture_type = "前庭-功能",
    descript = "由西域传入中洲的神奇的飞毯，可驭空飞行",
    special_func = "可直接穿梭于前庭与后院之中",
    double_type = 2,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 1,
    comfort = 0,
    sell_price = 466660,
    otherCanClick = true,
    clickRect = {
      height = 92,
      width = 185,
      x = -93,
      y = -31
    }
  },
  ["宠物小屋"] = {
    icon = 10150,
    unit = "座",
    furniture_type = "前庭-功能",
    descript = "豪华的宠物小屋，能够存放许多宠物",
    special_func = "可将宠物存放于小屋中，若有多个宠物小屋时，宠物栏数量也只算1个宠物小屋所拥有的数量",
    double_type = 2,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 2,
    purchase_cost = 5000,
    level = 1,
    comfort = 0,
    sell_price = 25000000,
    touchFloatText = "宠物小屋",
    clickRect = {
      height = 150,
      width = 150,
      x = -106,
      y = -75
    }
  },
  ["天地灵石"] = {
    icon = 10151,
    unit = "块",
    furniture_type = "前庭-功能",
    descript = "送子娘娘所赐，孕育天地灵气的石头",
    special_func = "孕育天地灵气的石头，在自家的#R居所-前庭#n中使用可进行摆放，摆放后可进行培育，到达一定程度时娃娃将破石而出！",
    double_type = 2,
    rescourse = {
      "#P送子娘娘#P所赐"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 1,
    comfort = 0,
    sell_price = 0
  },
  ["竹木床"] = {
    icon = 10043,
    unit = "张",
    furniture_type = "房屋-床柜",
    descript = "木质装饰简洁的床铺，结实耐用",
    special_func = "小憩功能所需家具",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1050,
    max_dur = 100,
    level = 1,
    comfort = 5,
    sell_price = 1666600,
    clickRect = {
      height = 96,
      width = 216,
      x = -158,
      y = -48
    }
  },
  ["流苏檀木床"] = {
    icon = 10044,
    unit = "张",
    furniture_type = "房屋-床柜",
    descript = "主体为檀木所制，顶为流苏帐",
    special_func = "小憩功能所需家具",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    max_dur = 200,
    level = 2,
    comfort = 14,
    sell_price = 4666600,
    clickRect = {
      height = 124,
      width = 246,
      x = -129,
      y = -110
    }
  },
  ["逍遥神仙榻"] = {
    icon = 10045,
    unit = "张",
    furniture_type = "房屋-床柜",
    descript = "玉质带有金色雕花的床榻，纱帐晶莹剔透，高贵而华丽",
    special_func = "小憩功能所需家具",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 5150,
    max_dur = 300,
    level = 3,
    comfort = 35,
    sell_price = 11666600,
    clickRect = {
      x = -130,
      y = -100,
      height = 120,
      width = 246
    }
  },
  ["实用木柜"] = {
    icon = 10046,
    unit = "个",
    furniture_type = "房屋-床柜",
    descript = "木质储物柜，造型简单，结实耐用",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["雕花檀木柜"] = {
    icon = 10047,
    unit = "个",
    furniture_type = "房屋-床柜",
    descript = "带有雕花，结构精致的储物柜",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["如意象牙柜"] = {
    icon = 10048,
    unit = "个",
    furniture_type = "房屋-床柜",
    descript = "象牙材质的高级储物柜，花纹和造型都比较别致",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:三级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["木质矮柜"] = {
    icon = 10049,
    unit = "个",
    furniture_type = "房屋-床柜",
    descript = "造型简单，较矮的储物柜。",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 400,
    level = 1,
    comfort = 4,
    sell_price = 1333300
  },
  ["雕花矮柜"] = {
    icon = 10050,
    unit = "个",
    furniture_type = "房屋-床柜",
    descript = "高级红木制成，带有雕花的柜子，看起来很是高级",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["七彩琉璃柜"] = {
    icon = 10051,
    unit = "个",
    furniture_type = "房屋-床柜",
    descript = "金属和玻璃制品的柜子，带有精致的花纹和琉璃的色彩，古朴又高贵，似乎是从西域传来的柜子",
    double_type = 0,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:三级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 3,
    comfort = 30,
    sell_price = 3000000
  },
  ["竹木靠椅"] = {
    icon = 10052,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "简单的竹木制成的靠椅，结实耐用",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600,
    dirs = 4,
    defaultDir = 5
  },
  ["雕花檀木靠椅"] = {
    icon = 10053,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "檀木制成且带有雕花，结构精致的靠椅",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300,
    dirs = 4,
    defaultDir = 5,
    clickRect = {
      x = -43,
      y = -64,
      height = 122,
      width = 90
    }
  },
  ["玉石神仙靠椅"] = {
    icon = 10054,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "带有精致花纹和装饰的靠椅，华丽而端庄",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300,
    dirs = 4,
    defaultDir = 5
  },
  ["竹木长条案"] = {
    icon = 10055,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "万般皆下品惟有读书高，竹木制成的读书桌案",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["胡桃木条案"] = {
    icon = 10056,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "万般皆下品惟有读书高，胡桃木制成的读书桌案",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["玉质条案"] = {
    icon = 10057,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "万般皆下品惟有读书高，华丽玉石制成的读书桌案",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["竹木茶案"] = {
    icon = 10058,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "竹木制成的茶案，结实耐用，适合休闲时饮茶聊天",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["雕花茶案"] = {
    icon = 10059,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "檀木质且带有雕花的茶案，看起来十分考究，用于品茶",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["金玉茶案"] = {
    icon = 10060,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "花纹精致，材质高级，高端大气的茶案，贵族饮茶时最喜欢用的茶案",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["博弈桌"] = {
    icon = 10061,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "适合热爱下棋之人对弈时使用的桌子",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2000,
    level = 3,
    comfort = 20,
    sell_price = 6666600
  },
  ["竹木方桌"] = {
    icon = 10062,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "竹木制成的简单方桌",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["雕花檀木方桌"] = {
    icon = 10063,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "檀木制成且带有雕花的方桌，端庄大气",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["玉石方桌"] = {
    icon = 10064,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "白玉制带有鎏金花边的方桌，华丽而精致",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["八宝呈祥圆桌"] = {
    icon = 10065,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "造型独特的圆桌，无论是花纹还是雕刻上都彰显着桌子的不凡",
    double_type = 0,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:三级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 3,
    comfort = 30,
    sell_price = 3000000
  },
  ["檀木方椅"] = {
    icon = 10129,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "檀木制成的小方椅，小巧实用",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 800,
    level = 2,
    comfort = 8,
    sell_price = 2666600
  },
  ["玉石方椅"] = {
    icon = 10130,
    unit = "张",
    furniture_type = "房屋-桌椅",
    descript = "白玉制成的小方椅，华丽精致",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2000,
    level = 3,
    comfort = 20,
    sell_price = 6666600
  },
  ["竹木屏风"] = {
    icon = 10066,
    unit = "扇",
    furniture_type = "房屋-摆设",
    descript = "竹木制成的屏风，造型简约，结实耐用",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["雕花屏风"] = {
    icon = 10067,
    unit = "扇",
    furniture_type = "房屋-摆设",
    descript = "香檀木打造的屏风，散发出淡淡的香味，助人入眠",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["蟠桃木四扇围屏"] = {
    icon = 10068,
    unit = "扇",
    furniture_type = "房屋-摆设",
    descript = "蟠桃木制成的四扇屏风，摆放于室内即实用又具观赏性",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 3000,
    level = 3,
    comfort = 30,
    sell_price = 10000000
  },
  ["黄粱梦"] = {
    icon = 10069,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "黄粱一梦，三生浮屠绘有黄粱梦典故的屏风",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["木质抚琴台"] = {
    icon = 10070,
    unit = "张",
    furniture_type = "房屋-摆设",
    descript = "简单朴实的抚琴台，不知可否与知音相遇",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["檀香抚琴台"] = {
    icon = 10071,
    unit = "张",
    furniture_type = "房屋-摆设",
    descript = "奏遍高山与流水，寻我知音人世间",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["玉石抚琴台"] = {
    icon = 10072,
    unit = "张",
    furniture_type = "房屋-摆设",
    descript = "玉无愁，人有痴，为觅一人识我音",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:三级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["奇珍树"] = {
    icon = 10073,
    unit = "棵",
    furniture_type = "房屋-摆设",
    descript = "用料奢侈的装饰树，是大富人家彰显身份必备之选",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:三级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 3000,
    level = 3,
    comfort = 30,
    sell_price = 10000000
  },
  ["芙蓉净花瓶"] = {
    icon = 10074,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "冰明玉润天然色，露染胭脂色未浓",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 300,
    level = 1,
    comfort = 3,
    sell_price = 1000000
  },
  ["桃花玉净瓶"] = {
    icon = 10075,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "桃花春色暖先开，明媚谁人不看来",
    double_type = 0,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 2,
    comfort = 10,
    sell_price = 2000000
  },
  ["青瓷画卷瓶"] = {
    icon = 10076,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "腹有诗书气自华，最是书香能致远",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["镶铜玉瓶"] = {
    icon = 10077,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "镶嵌有铜片装饰的粗玉制装饰瓶，圆润小巧",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["青玉花纹瓶"] = {
    icon = 10078,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "青玉制成的花瓶，带有独特雕花，极具收藏价值",
    double_type = 0,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["竹木橱架"] = {
    icon = 10079,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "竹木制成的橱架，简单耐用",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["檀木橱架"] = {
    icon = 10080,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "檀木制成的橱架，摆放了不少装饰品",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["鎏金圆顶橱架"] = {
    icon = 10081,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "白玉制成，带有鎏金花纹且造型独特的橱架，摆满了装饰品，极具观赏价值",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["铜镜"] = {
    icon = 10082,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "平常人家女子常用的铜镜，可正衣冠",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["檀木梳妆台"] = {
    icon = 10083,
    unit = "张",
    furniture_type = "房屋-摆设",
    descript = "檀木制成带有雕花的梳妆台，上方有梳妆所需的各种道具，很受大户人家女子欢迎",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["青玉梳妆台"] = {
    icon = 10084,
    unit = "张",
    furniture_type = "房屋-摆设",
    descript = "镶嵌有青玉，并带有雕花和鎏金的梳妆台，上方有梳妆所需的各种道具，很受富贵之家女子欢迎",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["青玉貔貅"] = {
    icon = 10085,
    unit = "座",
    furniture_type = "房屋-摆设",
    descript = "青玉制成的貔貅雕像，传闻摆于家中可招财",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 2,
    purchase_cost = 240,
    level = 2,
    comfort = 12,
    sell_price = 1200000
  },
  ["白玉观音像"] = {
    icon = 10086,
    unit = "座",
    furniture_type = "房屋-功能",
    descript = "精雕玉琢的观音像",
    special_func = "使用后提升人物修炼获得数值 ",
    double_type = 2,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 2,
    comfort = 0,
    max_dur = 1000,
    sell_price = 100
  },
  ["马踏飞燕"] = {
    icon = 10087,
    unit = "座",
    furniture_type = "房屋-摆设",
    descript = "五彩釉马踏飞燕造型的雕像",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["简易铜香炉"] = {
    icon = 10088,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "造型简单的铜香炉，看起来很实用",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["雕花描金香炉"] = {
    icon = 10089,
    unit = "个",
    furniture_type = "房屋-摆设",
    descript = "带有雕花和鎏金的金属材质香炉，常见于大户人家",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["七宝如意"] = {
    icon = 10090,
    unit = "座",
    furniture_type = "房屋-功能",
    descript = "精雕的玉质如意，内有流光四溢",
    special_func = "使用后提升法宝修炼获得数值",
    double_type = 2,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 2,
    comfort = 0,
    max_dur = 300,
    sell_price = 100
  },
  ["摇篮"] = {
    icon = 10152,
    unit = "个",
    furniture_type = "房屋-功能",
    descript = "宝宝的温床",
    special_func = "娃娃刚出生后需安置在摇篮中",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 0,
    sell_price = 1666600
  },
  ["聚财箱"] = {
    icon = 10153,
    unit = "个",
    furniture_type = "房屋-功能",
    descript = "精致结实的聚财箱，将钱存在这里谁也偷不走",
    special_func = "可用于存储金钱，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 2,
    purchase_cost = 2000,
    level = 2,
    comfort = 0,
    sell_price = 10000000
  },
  ["武学台"] = {
    icon = 10154,
    unit = "座",
    furniture_type = "前庭-功能",
    descript = "宠物习武之处，可快速提升宠物武学",
    special_func = "宠物修炼所需家具，单人最多拥有1座武学台，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所前庭购买"
    },
    purchase_type = 2,
    purchase_cost = 2910,
    level = 3,
    comfort = 30,
    sell_price = 3000000,
    max_dur = 2100,
    dur_fix_use_type = 1,
    dirs = 1,
    polygon_pts = {
      cc.p(-336, -20),
      cc.p(-336, -66),
      cc.p(-3, -230),
      cc.p(336, -66),
      cc.p(336, -20),
      cc.p(-3, 148),
      cc.p(-336, -20)
    }
  },
  ["五彩孔雀摆饰"] = {
    icon = 10091,
    unit = "座",
    furniture_type = "房屋-摆设",
    descript = "用材考究的孔雀造型摆饰，镶嵌着各种名贵宝石",
    double_type = 0,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:三级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 3,
    comfort = 30,
    sell_price = 3000000
  },
  ["纸质木脚灯"] = {
    icon = 10092,
    unit = "盏",
    furniture_type = "房屋-摆设",
    descript = "简朴而实用的高脚纸灯",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["雕花檀木灯"] = {
    icon = 10093,
    unit = "盏",
    furniture_type = "房屋-摆设",
    descript = "檀木高脚灯，带有精致雕花",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["鎏金青玉灯"] = {
    icon = 10094,
    unit = "盏",
    furniture_type = "房屋-摆设",
    descript = "黄金和青玉打造的高脚灯，带有雕花和鎏金，十分精致",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2000,
    level = 3,
    comfort = 20,
    sell_price = 6666600
  },
  ["竹帘"] = {
    icon = 10095,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "竹席状的卷帘",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["粉绸帘"] = {
    icon = 10096,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "粉色绸缎制成的窗帘，精致而不失优雅",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["荣华摇光帘"] = {
    icon = 10097,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "一揽芳华云帘中，点点摇光透窗现",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["赤云帘"] = {
    icon = 10098,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "由红色云锦制成的窗帘，端庄大气",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 2,
    purchase_cost = 240,
    level = 2,
    comfort = 12,
    sell_price = 1200000
  },
  ["流苏金丝帘"] = {
    icon = 10099,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "由流苏搭配金丝制成的窗帘，精致高贵",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["仕女图"] = {
    icon = 10100,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "关关雎鸠，在河之洲，窈窕淑女，君子好逑",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600,
    canTouch = true
  },
  ["蝶恋花"] = {
    icon = 10101,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "翻阶蛱蝶恋花情，花知蝶意花亦喜，散香引蝶去",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["春树秋香图"] = {
    icon = 10102,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "出自名师之手，看此画犹如来到实景，仿佛可以闻到香味",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["平安结"] = {
    icon = 10103,
    unit = "个",
    furniture_type = "房屋-墙饰",
    descript = "红红喜喜平安结，挂在墙上可营造喜庆气氛",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["佛雕墙饰"] = {
    icon = 10104,
    unit = "个",
    furniture_type = "房屋-墙饰",
    descript = "佛祖形象的雕饰，庄严与神圣，令人肃然敬畏",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["百花争艳图"] = {
    icon = 10105,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "百花开遍园林，又春归也谁为主",
    double_type = 0,
    rescourse = {
      "居所屋内购买",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:二级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["星芒墙饰"] = {
    icon = 10148,
    unit = "个",
    furniture_type = "房屋-墙饰",
    descript = "特殊白玉做成，带有鎏金装饰的墙饰",
    double_type = 0,
    rescourse = {
      "道心特权活动"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 3,
    comfort = 35,
    sell_price = 100
  },
  ["生死状"] = {
    icon = 10149,
    unit = "张",
    furniture_type = "房屋-墙饰",
    descript = "透露出肃杀之气的状纸，是凭借忘死之心和卓绝实力赢得的无上象征",
    double_type = 0,
    rescourse = {
      "#P生死对决获胜|夏总兵|E=我想发起生死状#P"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 3,
    comfort = 35,
    sell_price = 0,
    dirs = 2,
    defaultDir = 5,
    canTouch = true,
    otherCanClick = true,
    touchFloatText = "生死状"
  },
  ["兽皮地毯"] = {
    icon = 10106,
    unit = "张",
    furniture_type = "房屋-地毯",
    descript = "野兽毛皮制作的地毯，看起来很不一般",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300,
    clickRect = {
      height = 52,
      width = 99,
      x = -62,
      y = -27
    }
  },
  ["毛布毯"] = {
    icon = 10107,
    unit = "张",
    furniture_type = "房屋-地毯",
    descript = "厚厚的毛布制成的毯子，上方绘有部分花纹",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300,
    clickRect = {
      height = 90,
      width = 175,
      x = -88,
      y = -45
    }
  },
  ["七色云彩毯"] = {
    icon = 10108,
    unit = "张",
    furniture_type = "房屋-地毯",
    descript = "做工精美，让人仿佛有脚踏七色云彩的感觉",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300,
    clickRect = {
      height = 90,
      width = 175,
      x = -88,
      y = -45
    }
  },
  ["龙凤丝绒地毯"] = {
    icon = 10109,
    unit = "张",
    furniture_type = "房屋-地毯",
    descript = "丝绒材质，上方绘有有游龙戏凤图案的地毯，十分大气",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300,
    clickRect = {
      height = 103,
      width = 198,
      x = -100,
      y = -52
    }
  },
  ["木地砖"] = {
    icon = 10110,
    unit = "片",
    furniture_type = "房屋-地砖",
    descript = "木质地板，结实耐用",
    double_type = 0,
    rescourse = {
      "居所初始家具"
    },
    purchase_type = 0,
    purchase_cost = 0,
    tile_index = 0,
    level = 1,
    comfort = 0,
    sell_price = 0
  },
  ["粗石地砖"] = {
    icon = 10111,
    unit = "片",
    furniture_type = "房屋-地砖",
    descript = "石质地砖，大气端庄",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    tile_index = 1,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["大理石地砖"] = {
    icon = 10112,
    unit = "片",
    furniture_type = "房屋-地砖",
    descript = "大理石地砖，高贵精致",
    double_type = 0,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    tile_index = 2,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["阴阳修炼阵"] = {
    icon = 10114,
    unit = "个",
    furniture_type = "房屋-功能",
    descript = "阴阳之力乃平衡之力，修炼之人必须参悟",
    special_func = "人物修炼所需家具，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 1840,
    max_dur = 160,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["八卦太极阵"] = {
    icon = 10115,
    unit = "个",
    furniture_type = "房屋-功能",
    descript = "太极之意蕴含其中，让修炼之人保持心平气静",
    special_func = "人物修炼所需家具，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 3760,
    max_dur = 240,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["炼器台"] = {
    icon = 10116,
    unit = "张",
    furniture_type = "房屋-功能",
    descript = "简朴的炼器台，可摆上法宝",
    special_func = "法宝修炼所需家具，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2050,
    max_dur = 200,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["上古炼器台"] = {
    icon = 10117,
    unit = "张",
    furniture_type = "房屋-功能",
    descript = "上古流传下来的炼器台，修炼法宝事半功倍",
    special_func = "法宝修炼所需家具，#R需本人购买才可使用#n",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 4600,
    max_dur = 400,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["实用灶台"] = {
    icon = 10131,
    unit = "座",
    furniture_type = "房屋-功能",
    descript = "简朴实用的灶台，可以做出各种美味佳肴",
    special_func = "烹饪功能所需家具",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2100,
    max_dur = 200,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["如意灶台"] = {
    icon = 10132,
    unit = "座",
    furniture_type = "房屋-功能",
    descript = "造型精美、工具齐全的灶台，可以做出各种美味佳肴  ",
    special_func = "烹饪功能所需家具",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 4150,
    max_dur = 300,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["竹木摇椅"] = {
    icon = 10118,
    unit = "张",
    furniture_type = "后院-椅凳",
    descript = "木制的摇椅，结实耐用",
    double_type = 0,
    rescourse = {
      "居所后院购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["石制逍遥椅"] = {
    icon = 10119,
    unit = "张",
    furniture_type = "后院-椅凳",
    descript = "石制的摇椅，比较厚重规整，带有部分精致花纹",
    double_type = 0,
    rescourse = {
      "居所后院购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["精致月牙椅"] = {
    icon = 10120,
    unit = "张",
    furniture_type = "后院-椅凳",
    descript = "宛如月牙般的摇椅，带有特别的造型和花纹",
    double_type = 0,
    rescourse = {
      "居所后院购买"
    },
    purchase_type = 1,
    purchase_cost = 2500,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["竹木小凳"] = {
    icon = 10121,
    unit = "张",
    furniture_type = "后院-椅凳",
    descript = "木质的小凳子，可以蹲坐在上面",
    double_type = 0,
    rescourse = {
      "居所后院购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["石制小凳"] = {
    icon = 10122,
    unit = "张",
    furniture_type = "后院-椅凳",
    descript = "简单石制的小凳子，可以蹲坐在上面",
    double_type = 0,
    rescourse = {
      "居所后院购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["稻草人"] = {
    icon = 10123,
    unit = "个",
    furniture_type = "后院-摆设",
    descript = "稻草扎成的人型摆设，可摆放在农田旁边",
    double_type = 0,
    rescourse = {
      "居所后院购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["公鸡雕像"] = {
    icon = 10124,
    unit = "座",
    furniture_type = "后院-摆设",
    descript = "一只公鸡造型的雕塑，生机勃勃",
    double_type = 0,
    rescourse = {
      "居所后院购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["年年有鱼雕像"] = {
    icon = 10125,
    unit = "座",
    furniture_type = "后院-摆设",
    descript = "双鱼雕像，寓意年年有余",
    double_type = 0,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:三级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 3,
    comfort = 27,
    sell_price = 2700000
  },
  ["葫芦摆饰"] = {
    icon = 10126,
    unit = "座",
    furniture_type = "后院-摆设",
    descript = "葫芦造型的风水摆饰，可摆在后院之中，寓意福禄",
    double_type = 0,
    rescourse = {
      "居所后院购买",
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    purchase_type = 1,
    purchase_cost = 600,
    level = 1,
    comfort = 6,
    sell_price = 2000000
  },
  ["泥质水缸"] = {
    icon = 10127,
    unit = "个",
    furniture_type = "后院-摆设",
    descript = "泥土烧成的水缸，做蓄水之用，可以摆放在田旁边",
    double_type = 0,
    rescourse = {
      "居所后院购买"
    },
    purchase_type = 1,
    purchase_cost = 500,
    level = 1,
    comfort = 5,
    sell_price = 1666600
  },
  ["瓷质水缸"] = {
    icon = 10128,
    unit = "个",
    furniture_type = "后院-摆设",
    descript = "精致的陶瓷水缸，可做蓄水之用，也具有观赏价值",
    double_type = 0,
    rescourse = {
      "居所后院购买"
    },
    purchase_type = 1,
    purchase_cost = 1000,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["西域飞毯·后院"] = {
    icon = 10147,
    unit = "张",
    furniture_type = "后院-功能",
    descript = "由西域传入中洲的神奇的飞毯，可驭空飞行",
    special_func = "可直接穿梭于前庭与后院之中",
    double_type = 2,
    rescourse = {
      "居所鲁班打造",
      "#@集市逛摊|MarketBuyDlg=其他道具:家具:一级家具#@"
    },
    purchase_type = 0,
    purchase_cost = 0,
    level = 1,
    comfort = 0,
    sell_price = 466660,
    otherCanClick = true,
    clickRect = {
      height = 92,
      width = 185,
      x = -93,
      y = -31
    }
  },
  ["大白菜种子"] = {
    icon = 7100,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把白菜的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 1,
    harvest_icon = 7300,
    purchase_type = 1,
    purchase_cost = 0.8,
    harvest_name = "大白菜",
    harvest_exp = 40,
    harvest_time = 4,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["胡萝卜种子"] = {
    icon = 7101,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把胡萝卜的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 1,
    harvest_icon = 7301,
    purchase_type = 1,
    purchase_cost = 0.8,
    harvest_name = "胡萝卜",
    harvest_exp = 40,
    harvest_time = 4,
    harvest_value = "3-7"
  },
  ["西红柿种子"] = {
    icon = 7116,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把西红柿的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 2,
    harvest_icon = 7302,
    purchase_type = 1,
    purchase_cost = 1.8,
    harvest_name = "西红柿",
    harvest_exp = 60,
    harvest_time = 6,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["辣椒种子"] = {
    icon = 7117,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把辣椒的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 2,
    harvest_icon = 7303,
    purchase_type = 1,
    purchase_cost = 1.8,
    harvest_name = "辣椒",
    harvest_exp = 60,
    harvest_time = 6,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["竹苗"] = {
    icon = 7104,
    unit = "株",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "竹子的幼苗，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 2,
    harvest_icon = 7304,
    purchase_type = 1,
    purchase_cost = 36,
    harvest_name = "竹子",
    harvest_exp = 240,
    harvest_time = 24,
    harvest_value = "3-7",
    sell_price = 100,
    statusOffsetY = -15
  },
  ["玉米种子"] = {
    icon = 7105,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把玉米的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 3,
    harvest_icon = 7305,
    purchase_type = 1,
    purchase_cost = 3.6,
    harvest_name = "玉米",
    harvest_exp = 80,
    harvest_time = 8,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["西瓜种子"] = {
    icon = 7106,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把西瓜的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 3,
    harvest_icon = 7306,
    purchase_type = 1,
    purchase_cost = 3.6,
    harvest_name = "西瓜",
    harvest_exp = 80,
    harvest_time = 8,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["香樟树苗"] = {
    icon = 7107,
    unit = "株",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一株香樟树的树苗，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 3,
    harvest_icon = 7307,
    purchase_type = 1,
    purchase_cost = 68,
    harvest_name = "香樟木",
    harvest_exp = 300,
    harvest_time = 30,
    harvest_value = "3-7",
    sell_price = 100,
    statusOffsetY = -15
  },
  ["豌豆种子"] = {
    icon = 7108,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把豌豆的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 4,
    harvest_icon = 7308,
    purchase_type = 1,
    purchase_cost = 6.8,
    harvest_name = "豌豆",
    harvest_exp = 100,
    harvest_time = 10,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["草莓种子"] = {
    icon = 7109,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把草莓的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 4,
    harvest_icon = 7309,
    purchase_type = 1,
    purchase_cost = 6.8,
    harvest_name = "草莓",
    harvest_exp = 100,
    harvest_time = 10,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["灵芝种子"] = {
    icon = 7110,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把灵芝的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 4,
    harvest_icon = 7310,
    purchase_type = 1,
    purchase_cost = 12,
    harvest_name = "灵芝",
    harvest_exp = 120,
    harvest_time = 12,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["白蜡树苗"] = {
    icon = 7111,
    unit = "株",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一株白蜡树的树苗，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 4,
    harvest_icon = 7311,
    purchase_type = 1,
    purchase_cost = 120,
    harvest_name = "白蜡木",
    harvest_exp = 360,
    harvest_time = 36,
    harvest_value = "3-7",
    sell_price = 100,
    statusOffsetY = -15
  },
  ["南瓜种子"] = {
    icon = 7112,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把南瓜的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 5,
    harvest_icon = 7312,
    purchase_type = 1,
    purchase_cost = 12,
    harvest_name = "南瓜",
    harvest_exp = 120,
    harvest_time = 12,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["葡萄种子"] = {
    icon = 7113,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把葡萄的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 5,
    harvest_icon = 7313,
    purchase_type = 1,
    purchase_cost = 12,
    harvest_name = "葡萄",
    harvest_exp = 120,
    harvest_time = 12,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["移山参种子"] = {
    icon = 7114,
    unit = "把",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一把移山参的种子，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 5,
    harvest_icon = 7314,
    purchase_type = 1,
    purchase_cost = 21,
    harvest_name = "移山参",
    harvest_exp = 140,
    harvest_time = 14,
    harvest_value = "3-7",
    sell_price = 100
  },
  ["紫檀树苗"] = {
    icon = 7115,
    unit = "株",
    furniture_type = "后院-种植",
    rescourse = {
      "居所购买"
    },
    descript = "一株紫檀树的树苗，可在居所后院的农田中进行种植",
    item_class = ITEM_CLASS.HOME_PLANT_SEED,
    level = 5,
    harvest_icon = 7315,
    purchase_type = 1,
    purchase_cost = 210,
    harvest_name = "紫檀木",
    harvest_exp = 420,
    harvest_time = 42,
    harvest_value = "3-7",
    sell_price = 100,
    statusOffsetY = -15
  },
  ["大白菜"] = {
    icon = 7200,
    unit = "颗",
    level = 1,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的大白菜，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["胡萝卜"] = {
    icon = 7201,
    unit = "个",
    level = 1,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的胡萝卜，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["西红柿"] = {
    icon = 7202,
    unit = "个",
    level = 2,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的西红柿，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["辣椒"] = {
    icon = 7203,
    unit = "个",
    level = 2,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的辣椒，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["竹子"] = {
    icon = 7204,
    unit = "块",
    level = 2,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成年竹子制成的板材，是用于打造家具的上等材料",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  },
  ["玉米"] = {
    icon = 7205,
    unit = "个",
    level = 3,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的玉米，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["西瓜"] = {
    icon = 7206,
    unit = "个",
    level = 3,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的西瓜，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["香樟木"] = {
    icon = 7207,
    unit = "块",
    level = 3,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成年香樟树制成的板材，是用于打造家具的上等材料",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  },
  ["豌豆"] = {
    icon = 7208,
    unit = "个",
    level = 4,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的豌豆，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["草莓"] = {
    icon = 7209,
    unit = "个",
    level = 4,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的草莓，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["灵芝"] = {
    icon = 7210,
    unit = "个",
    level = 4,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的灵芝，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["白蜡木"] = {
    icon = 7211,
    unit = "块",
    level = 4,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成年白蜡树制成的板材，是用于打造家具的上等材料",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  },
  ["南瓜"] = {
    icon = 7212,
    unit = "个",
    level = 5,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的南瓜，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["葡萄"] = {
    icon = 7213,
    unit = "串",
    level = 5,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的葡萄，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["移山参"] = {
    icon = 7214,
    unit = "颗",
    level = 5,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成熟的移山参，可用于烹饪制作食物",
    item_class = ITEM_CLASS.HOME_COOK_MATERIAL
  },
  ["紫檀木"] = {
    icon = 7215,
    unit = "块",
    level = 5,
    furniture_type = "材料",
    rescourse = {
      "居所种植"
    },
    descript = "成年紫檀树制成的板材，是用于打造家具的上等材料",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  },
  ["实用鲁班台"] = {
    icon = 10133,
    unit = "座",
    furniture_type = "房屋-功能",
    descript = "简朴实用的鲁班台，可以用于打造精美的家具",
    special_func = "鲁班功能所需家具",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 2100,
    max_dur = 200,
    level = 2,
    comfort = 10,
    sell_price = 3333300
  },
  ["精致鲁班台"] = {
    icon = 10134,
    unit = "座",
    furniture_type = "房屋-功能",
    descript = "造型精美的鲁班台，可以用于打造精美的家具",
    special_func = "鲁班功能所需家具",
    double_type = 2,
    rescourse = {
      "居所屋内购买"
    },
    purchase_type = 1,
    purchase_cost = 4150,
    max_dur = 300,
    level = 3,
    comfort = 25,
    sell_price = 8333300
  },
  ["树漆"] = {
    icon = 7500,
    unit = "罐",
    furniture_type = "材料",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:家具材料:树漆#@",
      "居所委托任务"
    },
    descript = "由漆树炼制而成的漆油，是制作家具的上好涂料",
    special_func = "制作家具的原材料之一",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  },
  ["石材"] = {
    icon = 7501,
    unit = "块",
    furniture_type = "材料",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:家具材料:石材#@",
      "居所委托任务"
    },
    descript = "从深山采出的石材，是制作家具的上好材料",
    special_func = "制作家具的原材料之一",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  },
  ["黄金"] = {
    icon = 7502,
    unit = "块",
    furniture_type = "材料",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:家具材料:黄金#@",
      "居所委托任务"
    },
    descript = "毫无杂质的金矿，是制作家具的上好材料",
    special_func = "制作家具的原材料之一",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  },
  ["锦缎"] = {
    icon = 7503,
    unit = "匹",
    furniture_type = "材料",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:家具材料:锦缎#@",
      "居所委托任务"
    },
    descript = "产自蜀地的锦缎，是制作家具的上好材料",
    special_func = "制作家具的原材料之一",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  },
  ["玉料"] = {
    icon = 7504,
    unit = "块",
    furniture_type = "材料",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:家具材料:玉料#@",
      "居所委托任务"
    },
    descript = "玉石的原料，是制作家具的上好材料",
    special_func = "制作家具的原材料之一",
    item_class = ITEM_CLASS.HOME_LUBAN_MATERIAL
  }
}
