return {
  [CHS[7190611]] = {
    {
      x = 32,
      y = 35,
      npc = {
        bornX = 32,
        bornY = 35,
        icon = 6035,
        name = CHS[7100628],
        opacity = 122,
        dir = 3
      },
      mapNpc = {
        CHS[7100636],
        CHS[7100637],
        CHS[7100638]
      },
      event = {
        {
          type = "talk",
          name = CHS[7100636],
          str = CHS[7100629],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100628],
          str = CHS[7100630]
        },
        {
          type = "talk",
          name = CHS[7100636],
          str = CHS[7100631],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100628],
          str = CHS[7100632]
        },
        {
          type = "move",
          name = CHS[7100628],
          targetPos = cc.p(51, 28),
          dir = 3
        },
        {
          type = "talk",
          name = CHS[7100637],
          str = CHS[7100633],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100628],
          str = CHS[7100634]
        },
        {
          type = "move",
          name = CHS[7100628],
          targetPos = cc.p(70, 11),
          deleteNpc = true
        },
        {
          type = "talk",
          name = CHS[7100638],
          str = CHS[7100635],
          dir = 7
        }
      }
    },
    {
      x = 32,
      y = 35,
      npc = {
        bornX = 32,
        bornY = 35,
        icon = 6014,
        name = CHS[7100643],
        opacity = 122,
        dir = 3
      },
      mapNpc = {
        CHS[7100636],
        CHS[7100638]
      },
      event = {
        {
          type = "talk",
          name = CHS[7100643],
          str = CHS[7100644]
        },
        {
          type = "talk",
          name = CHS[7100636],
          str = CHS[7100645],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100643],
          str = CHS[7100646]
        },
        {
          type = "move",
          name = CHS[7100643],
          targetPos = cc.p(60, 29),
          dir = 3
        },
        {
          type = "talk",
          name = CHS[7100638],
          str = CHS[7100647],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100643],
          str = CHS[7100648]
        },
        {
          type = "move",
          name = CHS[7100643],
          targetPos = cc.p(70, 11),
          deleteNpc = true
        }
      }
    },
    {
      x = 32,
      y = 35,
      npc = {
        bornX = 32,
        bornY = 35,
        icon = 51513,
        name = CHS[7100649],
        opacity = 122,
        dir = 3
      },
      mapNpc = {
        CHS[7100636]
      },
      event = {
        {
          type = "talk",
          name = CHS[7100649],
          str = CHS[7100650]
        },
        {
          type = "talk",
          name = CHS[7100649],
          str = CHS[7100651]
        },
        {
          type = "talk",
          name = CHS[7100636],
          str = CHS[7100652],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100649],
          str = CHS[7100653]
        },
        {
          type = "talk",
          name = CHS[7100636],
          str = CHS[7100654],
          dir = 5
        },
        {
          type = "action",
          name = CHS[7100649],
          act = 13,
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100649],
          str = CHS[7100655]
        },
        {
          type = "effect",
          name = CHS[7100649],
          effectIcon = 6007
        }
      }
    }
  },
  [CHS[7190617]] = {
    {
      x = 122,
      y = 45,
      npc = {
        bornX = 122,
        bornY = 45,
        icon = 6231,
        name = CHS[7100656],
        opacity = 122,
        dir = 3
      },
      mapNpc = {
        CHS[7100667],
        CHS[7100668]
      },
      event = {
        {
          type = "talk",
          name = CHS[7100667],
          str = CHS[7100657],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100656],
          str = CHS[7100658]
        },
        {
          type = "talk",
          name = CHS[7100667],
          str = CHS[7100659],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100668],
          str = CHS[7100660],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100668],
          str = CHS[7100661],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100656],
          str = CHS[7100662]
        },
        {
          type = "talk",
          name = CHS[7100668],
          str = CHS[7100663],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100667],
          str = CHS[7100664],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100667],
          str = CHS[7100665],
          dir = 7
        },
        {
          type = "talk",
          name = CHS[7100656],
          str = CHS[7100666]
        }
      }
    },
    {
      x = 29,
      y = 26,
      npc = {
        bornX = 29,
        bornY = 26,
        icon = 6020,
        name = CHS[7100669],
        opacity = 122,
        dir = 1
      },
      mapNpc = {
        CHS[7100670]
      },
      event = {
        {
          type = "talk",
          name = CHS[7100669],
          str = CHS[7100671]
        },
        {
          type = "talk",
          name = CHS[7100670],
          str = CHS[7100672],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100670],
          str = CHS[7100673],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100670],
          str = CHS[7100674],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100669],
          str = CHS[7100675]
        },
        {
          type = "talk",
          name = CHS[7100670],
          str = CHS[7100676],
          callBackTime = 0.5,
          dir = 5
        },
        {
          type = "move",
          name = CHS[7100669],
          targetPos = cc.p(5, 45)
        }
      }
    },
    {
      x = 134,
      y = 121,
      npc = {
        bornX = 134,
        bornY = 121,
        icon = 20037,
        name = CHS[7100677],
        opacity = 122,
        dir = 3
      },
      npc2 = {
        bornX = 139,
        bornY = 116,
        icon = 6045,
        name = CHS[7100678],
        opacity = 122,
        dir = 7
      },
      mapNpc = {},
      event = {
        {
          type = "talk",
          name = CHS[7100678],
          str = CHS[7100679]
        },
        {
          type = "talk",
          name = CHS[7100677],
          str = CHS[7100680]
        },
        {
          type = "talk",
          name = CHS[7100678],
          str = CHS[7100681]
        },
        {
          type = "talk",
          name = CHS[7100677],
          str = CHS[7100682]
        },
        {
          type = "talk",
          name = CHS[7100678],
          str = CHS[7100683]
        },
        {
          type = "talk",
          name = CHS[7100677],
          str = CHS[7100684]
        },
        {
          type = "talk",
          name = CHS[7100678],
          str = CHS[7100685]
        }
      }
    }
  },
  [CHS[7190612]] = {
    {
      x = 57,
      y = 32,
      npc = {
        bornX = 57,
        bornY = 32,
        icon = 6035,
        name = CHS[7100686],
        opacity = 122,
        dir = 3
      },
      mapNpc = {
        CHS[7100687]
      },
      event = {
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100688],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100686],
          str = CHS[7100689]
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100690],
          dir = 5
        },
        {
          type = "move",
          name = CHS[7100686],
          targetPos = cc.p(63, 13),
          dir = 1
        },
        {
          type = "talk",
          name = CHS[7100686],
          str = CHS[7100691]
        },
        {
          type = "talk",
          name = CHS[7100686],
          str = CHS[7100692]
        },
        {
          type = "move",
          name = CHS[7100686],
          targetPos = cc.p(57, 32),
          dir = 3
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100693],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100686],
          str = CHS[7100694]
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100695],
          callBackTime = 0.5,
          dir = 5
        },
        {
          type = "move",
          name = CHS[7100686],
          targetPos = cc.p(12, 10),
          dir = 1,
          obastacleWalkPath = {
            cc.p(11, 9),
            cc.p(10, 8),
            cc.p(9, 7),
            cc.p(8, 6),
            cc.p(7, 6)
          }
        },
        {
          type = "effect",
          name = CHS[7100686],
          effectIcon = 1482,
          effectCallBack = true
        }
      }
    },
    {
      x = 57,
      y = 32,
      npc = {
        bornX = 57,
        bornY = 32,
        icon = 6018,
        name = CHS[7100696],
        opacity = 122,
        dir = 3
      },
      mapNpc = {
        CHS[7100687]
      },
      event = {
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100697],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100696],
          str = CHS[7100698]
        },
        {
          type = "talk",
          name = CHS[7100696],
          str = CHS[7100699]
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100700],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100701],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100696],
          str = CHS[7100702]
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100703],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100696],
          str = CHS[7100704]
        },
        {
          type = "talk",
          name = CHS[7100696],
          str = CHS[7100705]
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100706],
          callBackTime = 0.5,
          dir = 5
        },
        {
          type = "move",
          name = CHS[7100696],
          targetPos = cc.p(12, 10),
          dir = 1,
          obastacleWalkPath = {
            cc.p(11, 9),
            cc.p(10, 8),
            cc.p(9, 7),
            cc.p(8, 6),
            cc.p(7, 6)
          }
        },
        {
          type = "effect",
          name = CHS[7100696],
          effectIcon = 1482,
          effectCallBack = true
        }
      }
    },
    {
      x = 63,
      y = 33,
      npc = {
        bornX = 63,
        bornY = 33,
        icon = 6087,
        name = CHS[7100707],
        opacity = 122,
        dir = 3
      },
      mapNpc = {
        CHS[7100687]
      },
      event = {
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100708],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100707],
          str = CHS[7100709]
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100710],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100707],
          str = CHS[7100711]
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100712],
          dir = 5
        },
        {
          type = "talk",
          name = CHS[7100707],
          str = CHS[7100713]
        },
        {
          type = "talk",
          name = CHS[7100687],
          str = CHS[7100714],
          dir = 5
        }
      }
    }
  },
  ["ChatShowTime"] = 3,
  ["EventProbability"] = 20,
  ["EventDistance"] = 10
}
