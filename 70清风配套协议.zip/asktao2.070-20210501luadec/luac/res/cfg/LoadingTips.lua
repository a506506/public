return {
  {
    tips = CHSUP[3000744],
    level = 1
  },
  {
    tips = CHSUP[3000745],
    level = 1
  },
  {
    tips = CHSUP[3000746],
    level = 1
  },
  {
    tips = CHSUP[3000747],
    level = 1
  },
  {
    tips = CHSUP[3000748],
    level = 1
  },
  {
    tips = CHSUP[3000749],
    level = 1
  },
  {
    tips = CHSUP[3000750],
    level = 1
  },
  {
    tips = CHSUP[3000751],
    level = 1
  },
  {
    tips = CHSUP[3000752],
    level = 1
  },
  {
    tips = CHSUP[3000753],
    level = 1
  },
  {
    tips = CHSUP[3000754],
    level = 1
  },
  {
    tips = CHSUP[3000755],
    level = 1
  },
  {
    tips = CHSUP[3000756],
    level = 1
  },
  {
    tips = CHSUP[3000757],
    level = 1
  },
  {
    tips = CHSUP[3000758],
    level = 1
  },
  {
    tips = CHSUP[3000759],
    level = 1
  },
  {
    tips = CHSUP[3000760],
    level = 1
  },
  {
    tips = CHSUP[3000761],
    level = 1
  },
  {
    tips = CHSUP[3000762],
    level = 1
  },
  {
    tips = CHSUP[3000763],
    level = 1
  },
  {
    tips = CHSUP[3000764],
    level = 1
  },
  {
    tips = CHSUP[7100000],
    level = 1
  },
  {
    tips = CHSUP[4000005],
    level = 1
  },
  {
    tips = CHSUP[4000006],
    level = 1
  },
  {
    tips = CHSUP[5000218],
    level = 1
  },
  {
    tips = CHSUP[5000219],
    level = 1
  },
  {
    tips = CHSUP[2200019],
    level = 1,
    forbid_redhand = true
  },
  {
    tips = CHSUP[4000039],
    level = 1
  },
  {
    tips = CHSUP[4000040],
    level = 1
  },
  {
    tips = CHSUP[4000041],
    level = 1,
    distType = 1
  },
  {
    tips = CHSUP[7270000],
    level = 20
  },
  {
    tips = CHSUP[3000765],
    level = 20
  },
  {
    tips = CHSUP[3000766],
    level = 20
  },
  {
    tips = CHSUP[3000767],
    level = 20
  },
  {
    tips = CHSUP[3000768],
    level = 20
  },
  {
    tips = CHSUP[4000035],
    level = 20
  },
  {
    tips = CHSUP[3000769],
    level = 20
  },
  {
    tips = CHSUP[4000007],
    level = 30
  },
  {
    tips = CHSUP[4000008],
    level = 30
  },
  {
    tips = CHSUP[4000009],
    level = 30
  },
  {
    tips = CHSUP[4000010],
    level = 30
  },
  {
    tips = CHSUP[7270001],
    level = 30
  },
  {
    tips = CHSUP[3000770],
    level = 35
  },
  {
    tips = CHSUP[4000000],
    level = 35
  },
  {
    tips = CHSUP[4000001],
    level = 35
  },
  {
    tips = CHSUP[3000771],
    level = 50,
    distType = 2
  },
  {
    tips = CHSUP[4000036],
    level = 50,
    distType = 1
  },
  {
    tips = CHSUP[3000772],
    level = 50
  },
  {
    tips = CHSUP[3000773],
    level = 50
  },
  {
    tips = CHSUP[3000774],
    level = 50
  },
  {
    tips = CHSUP[3000775],
    level = 50
  },
  {
    tips = CHSUP[3000776],
    level = 50
  },
  {
    tips = CHSUP[4000002],
    level = 50
  },
  {
    tips = CHSUP[4000003],
    level = 50
  },
  {
    tips = CHSUP[4000004],
    level = 50
  },
  {
    tips = CHSUP[2200014],
    level = 50
  },
  {
    tips = CHSUP[5420000],
    level = 50
  },
  {
    tips = CHSUP[4000011],
    level = 70
  },
  {
    tips = CHSUP[4000012],
    level = 70
  },
  {
    tips = CHSUP[4000013],
    level = 70
  },
  {
    tips = CHSUP[4000014],
    level = 70
  },
  {
    tips = CHSUP[4000015],
    level = 70
  },
  {
    tips = CHSUP[4000016],
    level = 70
  },
  {
    tips = CHSUP[4000017],
    level = 70
  },
  {
    tips = CHSUP[4000018],
    level = 70
  },
  {
    tips = CHSUP[4000019],
    level = 70
  },
  {
    tips = CHSUP[4000020],
    level = 70
  },
  {
    tips = CHSUP[4000021],
    level = 70
  },
  {
    tips = CHSUP[4000022],
    level = 70
  },
  {
    tips = CHSUP[4000037],
    level = 70
  },
  {
    tips = CHSUP[4000038],
    level = 70
  },
  {
    tips = CHSUP[4000042],
    level = 70
  },
  {
    tips = CHSUP[4000023],
    level = 75
  },
  {
    tips = CHSUP[4000024],
    level = 75
  },
  {
    tips = CHSUP[4000025],
    level = 75
  },
  {
    tips = CHSUP[4000026],
    level = 75
  },
  {
    tips = CHSUP[4000027],
    level = 75
  },
  {
    tips = CHSUP[4000028],
    level = 75
  },
  {
    tips = CHSUP[4000029],
    level = 75
  },
  {
    tips = CHSUP[4000030],
    level = 75
  },
  {
    tips = CHSUP[2200021],
    level = 75
  },
  {
    tips = CHSUP[4000031],
    level = 100
  },
  {
    tips = CHSUP[4000032],
    level = 110
  },
  {
    tips = CHSUP[4000033],
    level = 110
  },
  {
    tips = CHSUP[4000034],
    level = 120
  }
}
