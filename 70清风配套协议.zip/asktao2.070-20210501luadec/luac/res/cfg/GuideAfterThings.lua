return {
  [69] = {
    dlg = "SafeLockMainDlg",
    func = "attachLightEffect"
  }
}
