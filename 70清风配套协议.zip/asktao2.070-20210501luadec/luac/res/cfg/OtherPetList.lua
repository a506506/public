return {
  [CHS[4100344]] = {
    name = CHS[4100344],
    icon = 6660,
    zoon = {},
    polar = CHS[3001385],
    level_req = 60,
    life = 40,
    mana = 0,
    speed = 15,
    phy_attack = 50,
    mag_attack = -40,
    skills = {
      CHS[3000076],
      CHS[3000072],
      CHS[3000078]
    },
    price = 100,
    order = 1
  },
  [CHS[7000136]] = {
    name = CHS[7000136],
    icon = 6663,
    zoon = {},
    polar = CHS[3001385],
    level_req = 60,
    life = 40,
    mana = 0,
    speed = 15,
    phy_attack = 50,
    mag_attack = -40,
    skills = {
      CHS[3000075],
      CHS[3000073],
      CHS[3000078]
    },
    price = 100,
    order = 2
  },
  [CHS[7002095]] = {
    name = CHS[7002095],
    icon = 6664,
    zoon = {},
    polar = CHS[3001385],
    level_req = 60,
    life = 40,
    mana = 0,
    speed = 15,
    phy_attack = 50,
    mag_attack = -40,
    skills = {
      CHS[3000075],
      CHS[3000072],
      CHS[3000077]
    },
    price = 100,
    order = 3
  },
  [CHS[7002303]] = {
    name = CHS[7002303],
    icon = 6665,
    zoon = {},
    polar = CHS[3001385],
    level_req = 60,
    life = 40,
    mana = 0,
    speed = 15,
    phy_attack = 50,
    mag_attack = -40,
    skills = {
      CHS[3000073],
      CHS[3000074],
      CHS[3000079]
    },
    price = 100,
    order = 4
  },
  [CHS[7190018]] = {
    name = CHS[7190018],
    icon = 6320,
    zoon = {},
    polar = CHS[3001409],
    level_req = 15,
    life = 40,
    mana = 15,
    speed = 25,
    phy_attack = -40,
    mag_attack = 25,
    skills = {
      CHS[3000081],
      CHS[3000074],
      CHS[3000079]
    },
    price = 100,
    order = 0
  }
}
