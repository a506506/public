return {
  ["普通"] = {
    [0] = {
      revivification_rate = 0,
      revivification_time = 0,
      double_hit_rate = 10,
      double_hit_time = 2,
      stunt_rate = 8,
      pow = 3,
      def = 5
    },
    [100000] = {
      revivification_rate = 5,
      revivification_time = 1,
      double_hit_rate = 18,
      double_hit_time = 3,
      stunt_rate = 16,
      pow = 6,
      def = 10
    },
    [300000] = {
      revivification_rate = 15,
      revivification_time = 2,
      double_hit_rate = 26,
      double_hit_time = 4,
      stunt_rate = 24,
      pow = 10,
      def = 15
    },
    [500000] = {
      revivification_rate = 20,
      revivification_time = 3,
      double_hit_rate = 34,
      double_hit_time = 5,
      stunt_rate = 32,
      pow = 15,
      def = 20
    }
  },
  ["变异"] = {
    [0] = {
      revivification_rate = 0,
      revivification_time = 0,
      double_hit_rate = 10,
      double_hit_time = 2,
      stunt_rate = 10,
      pow = 3,
      def = 5
    },
    [100000] = {
      revivification_rate = 10,
      revivification_time = 1,
      double_hit_rate = 20,
      double_hit_time = 3,
      stunt_rate = 20,
      pow = 6,
      def = 10
    },
    [300000] = {
      revivification_rate = 20,
      revivification_time = 2,
      double_hit_rate = 30,
      double_hit_time = 4,
      stunt_rate = 30,
      pow = 10,
      def = 15
    },
    [500000] = {
      revivification_rate = 30,
      revivification_time = 3,
      double_hit_rate = 40,
      double_hit_time = 5,
      stunt_rate = 40,
      pow = 15,
      def = 20
    },
    [1000000] = {
      revivification_rate = 40,
      revivification_time = 3,
      double_hit_rate = 50,
      double_hit_time = 6,
      stunt_rate = 50,
      pow = 20,
      def = 25
    },
    [2000000] = {
      revivification_rate = 50,
      revivification_time = 3,
      double_hit_rate = 50,
      double_hit_time = 7,
      stunt_rate = 50,
      pow = 25,
      def = 30
    },
    [5000000] = {
      revivification_rate = 50,
      revivification_time = 4,
      double_hit_rate = 50,
      double_hit_time = 8,
      stunt_rate = 50,
      pow = 30,
      def = 35
    }
  },
  ["神兽"] = {
    [0] = {
      revivification_rate = 0,
      revivification_time = 0,
      double_hit_rate = 10,
      double_hit_time = 2,
      stunt_rate = 10,
      pow = 3,
      def = 5
    },
    [100000] = {
      revivification_rate = 11,
      revivification_time = 1,
      double_hit_rate = 20,
      double_hit_time = 3,
      stunt_rate = 20,
      pow = 6,
      def = 10
    },
    [300000] = {
      revivification_rate = 22,
      revivification_time = 2,
      double_hit_rate = 30,
      double_hit_time = 4,
      stunt_rate = 30,
      pow = 10,
      def = 15
    },
    [500000] = {
      revivification_rate = 33,
      revivification_time = 3,
      double_hit_rate = 40,
      double_hit_time = 5,
      stunt_rate = 40,
      pow = 15,
      def = 20
    },
    [1000000] = {
      revivification_rate = 44,
      revivification_time = 4,
      double_hit_rate = 50,
      double_hit_time = 6,
      stunt_rate = 50,
      pow = 20,
      def = 25
    },
    [2000000] = {
      revivification_rate = 55,
      revivification_time = 5,
      double_hit_rate = 50,
      double_hit_time = 7,
      stunt_rate = 50,
      pow = 25,
      def = 30
    },
    [5000000] = {
      revivification_rate = 60,
      revivification_time = 5,
      double_hit_rate = 50,
      double_hit_time = 8,
      stunt_rate = 50,
      pow = 30,
      def = 35
    }
  }
}
