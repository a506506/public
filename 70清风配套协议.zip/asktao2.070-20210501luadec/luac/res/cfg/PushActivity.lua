return {
  {
    name = "周活动",
    level = 30,
    actitiveDate = "3,5,7",
    pushContent = "周活动将在30分钟后开始，想要参加的道友请提前做好准备。",
    pushTime = {"21:00"}
  }
}
