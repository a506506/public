return {
  {
    name = CHS[3004408],
    mainType = "labor_day_2016_qczc",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3004409],
        "npc",
        CHS[3004410]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3004412],
    desc = CHS[3004413],
    reward = CHS[3004414],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[3004415],
    mainType = "labor_day_2016_jxlg",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3004409],
        "npc",
        CHS[3004410]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3004416],
    desc = CHS[3004417],
    reward = CHS[3004414],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[3004418],
    mainType = "labor_day_2016_jxlg",
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[3004409],
        "npc",
        CHS[3004419]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3004416],
    desc = CHS[3004420],
    reward = CHS[3004421],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000244],
    mainType = "child_day_2016",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[6000246],
        "npc",
        CHS[6000245]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3004412],
    desc = CHS[6000247],
    reward = CHS[6000248],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000249],
    mainType = "child_day_2016",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[6000246],
        "npc",
        CHS[6000245]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3004416],
    desc = CHS[6000250],
    reward = CHS[6000251],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6400018],
    mainType = "duanwu_day_2016",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[6400019],
        "npc",
        CHS[6000245]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[6400020],
    reward = CHS[6400021],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6400022],
    mainType = "duanwu_day_2016",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        CHS[6400019],
        "npc",
        CHS[6000245]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000698],
    desc = CHS[6400023],
    reward = CHS[6400024],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4200134],
    mainType = "qixi_day_2016",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[4200131]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[4200132],
    reward = CHS[4200133],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4200136],
    mainType = "qixi_day_2016",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[4200131]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[2000104],
    desc = CHS[4200137],
    reward = CHS[4200138],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4200124],
    mainType = "summer_day_2016_05",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[4200125]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6400026],
    desc = CHS[4200127],
    reward = CHS[4200128],
    testDistDesc = CHS[4200129],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[6000304],
    mainType = "summer_day_2016_01",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[6000305]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[6000306],
    reward = CHS[6000307],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[2000102],
    mainType = "summer_day_2016_01",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[2000103]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[2000104],
    desc = CHS[2000105],
    reward = CHS[2000106],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000296],
    mainType = "summer_day_2016_02",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[6000297]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[6000298],
    reward = CHS[6000299],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000300],
    mainType = "summer_day_2016_02",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[6000297]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000698],
    desc = CHS[6000301],
    reward = CHS[6000302],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000284],
    mainType = "summer_day_2016_03",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[6000285]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[6000286],
    reward = CHS[6000287],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000288],
    mainType = "summer_day_2016_03",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[6000285]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000698],
    desc = CHS[6000289],
    reward = CHS[6000290],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000403],
    mainType = "teacher_day_2016",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[6000404],
    reward = CHS[6000405],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000409],
    mainType = "teacher_day_2016",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000288],
    desc = CHS[6000410],
    reward = CHS[6000411],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000387],
    mainType = "ghost_day_2016",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[2000104],
    desc = CHS[6000388],
    reward = CHS[6000402],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6000394],
    mainType = "ghost_day_2016",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[6000390],
    reward = CHS[6000391],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4200175],
    mainType = "autumn_day_2016",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[4200176],
    reward = CHS[4200177],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4200178],
    mainType = "autumn_day_2016",
    level = 30,
    times = 8,
    activeValue = 1,
    activeLimit = 8,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000288],
    desc = CHS[4200179],
    reward = CHS[4400007],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[6200058],
    mainType = "national_day_2016",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        CHS[3004410]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000288],
    desc = CHS[6200059],
    reward = CHS[6200060],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6200061],
    mainType = "national_day_2016",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        CHS[3004410]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3004412],
    desc = CHS[6200062],
    reward = CHS[6200063],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6200064],
    mainType = "national_day_2016",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        CHS[3004410]
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3004412],
    desc = CHS[6200065],
    reward = CHS[6200066],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6200067],
    mainType = "chongyang_day_2016",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[6200068],
    reward = CHS[6200069],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[6200071],
    mainType = "chongyang_day_2016",
    level = 30,
    times = 6,
    activeValue = 2,
    activeLimit = 12,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000288],
    desc = CHS[6200072],
    reward = CHS[6200073],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4300118],
    mainType = "singles_day_2016",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[4300119],
    testDistDesc = CHS[4300119],
    reward = CHS[4300120],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4300121],
    mainType = "singles_day_2016",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000288],
    desc = CHS[4300122],
    testDistDesc = CHS[4300122],
    reward = CHS[4300123],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4300136],
    mainType = "singles_day_2016",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "BachelorDrawDlg"
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[4300137],
    testDistDesc = CHS[4300137],
    reward = CHS[4300138],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5000249],
    mainType = "newyear_day_2017",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[5000250],
    desc = CHS[5000251],
    testDistDesc = CHS[5000252],
    reward = CHS[5000253],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5000254],
    mainType = "newyear_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[5000255],
    desc = CHS[5000256],
    testDistDesc = CHS[5000257],
    reward = CHS[5000258],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7000163],
    mainType = "christmas_day_2016",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[3000288],
    desc = CHS[7000164],
    testDistDesc = CHS[7000164],
    reward = CHS[7000165],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7000169],
    mainType = "christmas_day_2016",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "24:00",
    team = CHS[6000218],
    desc = CHS[7000170],
    testDistDesc = CHS[7000170],
    reward = CHS[7000171],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5410001],
    mainType = "winter_day_2017_01",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5410002],
    testDistDesc = CHS[5410002],
    reward = CHS[5410003],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5410004],
    mainType = "winter_day_2017_01",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[5410005],
    testDistDesc = CHS[5410005],
    reward = CHS[5410006],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7000264],
    mainType = "winter_day_2017_03",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[7000267],
    testDistDesc = CHS[7000267],
    reward = CHS[7000268],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7000272],
    mainType = "winter_day_2017_04",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000288],
    desc = CHS[7000273],
    testDistDesc = CHS[7000273],
    reward = CHS[7000274],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5410016],
    mainType = "winter_day_2017",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "ScratchRewardDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5410017],
    testDistDesc = CHS[5410017],
    reward = CHS[5410018],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7000259],
    mainType = "lantern_festival_2017",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[7000260],
    testDistDesc = CHS[7000260],
    reward = CHS[6200063],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7000262],
    mainType = "lantern_festival_2017",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000288],
    desc = CHS[7000263],
    testDistDesc = CHS[7000263],
    reward = CHS[6200073],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5420026],
    mainType = "spring_day_2017_ssnyf",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5420027],
    testDistDesc = CHS[5420027],
    reward = CHS[5420028],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5420014],
    mainType = "spring_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "ChunjieRedBagDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5420015],
    testDistDesc = CHS[5420015],
    reward = CHS[5420016],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7001001],
    mainType = "spring_day_2017",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000288],
    desc = CHS[7001002],
    testDistDesc = CHS[7001002],
    reward = CHS[7001003],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5420065],
    mainType = "valentine_day_2017",
    level = 30,
    times = 2,
    activeValue = 5,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[5420066],
    testDistDesc = CHS[5420066],
    reward = CHS[5420067],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5420068],
    mainType = "valentine_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5000245],
    desc = CHS[5420104],
    testDistDesc = CHS[5420069],
    reward = CHS[5420105],
    testDistReward = CHS[5420070],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5420071],
    showName = CHS[5420261],
    mainType = "valentine_2018_adyq",
    level = 40,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000730],
    desc = CHS[5420072],
    testDistDesc = CHS[5420072],
    reward = CHS[5420073],
    icon = "09206"
  },
  {
    name = CHS[7003006],
    mainType = "arbor_day_2017",
    level = 30,
    times = 1,
    activeValue = 1,
    activeLimit = 20,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5000245],
    desc = CHS[7003007],
    testDistDesc = CHS[7003007],
    reward = CHS[6000402],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7002041],
    mainType = "april_fool_day_2017",
    level = 30,
    times = 1,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[7002043],
    testDistDesc = CHS[7002043],
    reward = CHS[3004414],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7002044],
    mainType = "april_fool_day_2017",
    level = 30,
    times = 1,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5000245],
    desc = CHS[7002045],
    testDistDesc = CHS[7002045],
    reward = CHS[4200138],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7002037],
    mainType = "qingming_day_2017",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5000245],
    desc = CHS[7002038],
    testDistDesc = CHS[7002038],
    reward = CHS[7002039],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7002033],
    mainType = "qingming_day_2017",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[7002035],
    testDistDesc = CHS[7002035],
    reward = CHS[7002036],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7002097],
    mainType = "zhounianqing_2017_scxt",
    level = 30,
    times = 5,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[7002098],
    testDistDesc = CHS[7002099],
    reward = CHS[7002100],
    icon = "BigRewardIcon0022.png",
    goingTime = {
      {
        "08:00-08:05"
      },
      {
        "09:00-09:05"
      },
      {
        "10:00-10:05"
      },
      {
        "11:00-11:05"
      },
      {
        "12:00-12:05"
      },
      {
        "13:00-13:05"
      },
      {
        "14:00-14:05"
      },
      {
        "15:00-15:05"
      },
      {
        "16:00-16:05"
      },
      {
        "17:00-17:05"
      },
      {
        "18:00-18:05"
      },
      {
        "19:00-19:05"
      },
      {
        "20:00-20:05"
      },
      {
        "21:00-21:05"
      },
      {
        "22:00-22:05"
      },
      {
        "23:00-23:05"
      },
      {
        "00:00-00:05"
      }
    }
  },
  {
    name = CHS[5400043],
    mainType = "labor_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5000245],
    desc = CHS[5400042],
    testDistDesc = CHS[5400042],
    reward = CHS[5400044],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400063],
    mainType = "zhounianqing_2017_wxsf",
    level = 30,
    times = 20,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5000245],
    desc = CHS[5400060],
    testDistDesc = CHS[5400060],
    reward = CHS[5400061],
    icon = "01661"
  },
  {
    name = CHS[7002194],
    mainType = "zhounianqing_2017_xmmj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[7002195],
    reward = CHS[7002196],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5410037],
    mainType = "zhounianqing_2017_zfbs",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "AnniversaryTreeDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5410038],
    reward = CHS[5410039],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7003052],
    mainType = "duanwu_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[7003053],
    reward = CHS[7003054],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[2000873],
    mainType = "child_day_2017",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[2000874],
    reward = CHS[2000875],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4100609],
    mainType = "summer_day_2017_zcng",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[4100610],
    reward = CHS[4100621],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4100606],
    mainType = "summer_day_2017_bwyc",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[4100607],
    reward = CHS[4100608],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4100624],
    mainType = "summer_day_2017_lottery",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "SummerVacationDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[4100622],
    reward = CHS[4100623],
    testDistReward = CHS[4200370],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4100625],
    mainType = "summer_day_2017_ybqy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[4100626],
    reward = CHS[4100627],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4100630],
    mainType = "summer_day_2017_zynl",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[4100628],
    reward = CHS[4100629],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400073],
    showName = CHS[5410108],
    mainType = "qixi_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[5400074],
    reward = CHS[5400075],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[2000360],
    showName = CHS[5410112],
    mainType = "ghost_day_2017_jgsz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[2000361],
    reward = CHS[2000362],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400087],
    showName = CHS[5410109],
    mainType = "ghost_day_2017_dhyh",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[5400088],
    reward = CHS[5400089],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[2000354],
    showName = CHS[5410110],
    mainType = "teacher_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[2000355],
    reward = CHS[2000356],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[2000357],
    showName = CHS[5410111],
    mainType = "teacher_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6400026],
    desc = CHS[2000358],
    reward = CHS[2000359],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400104],
    showName = CHS[5400118],
    mainType = "autumn_day_2017_cdm",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5400105],
    reward = CHS[5400106],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400095],
    showName = CHS[5400125],
    mainType = "national_2017_lbmm",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000698],
    desc = CHS[5400096],
    reward = CHS[5400097],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400098],
    showName = CHS[5400119],
    mainType = "national_2017_tycyb",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[6200085]
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5400099],
    reward = CHS[5400100],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7100036],
    showName = CHS[7100037],
    mainType = "chongyang_day_2017",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[7100038],
    reward = CHS[7100039],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450024],
    showName = CHS[5450025],
    mainType = "act_singles_2017_yxyy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[5450026],
    reward = CHS[5450027],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4000438],
    showName = CHS[4000439],
    mainType = "act_singles_2017_ggdb",
    level = 30,
    times = 10,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[2000876]
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4000440],
    reward = CHS[4000441],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5450021],
    showName = CHS[5450016],
    mainType = "hallowmas_2017_wsjtg",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[5450019]
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5450017],
    reward = CHS[5450018],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5450022],
    showName = CHS[5450015],
    mainType = "hallowmas_2017_xddg",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6400026],
    desc = CHS[5450013],
    reward = CHS[5450014],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7100051],
    showName = CHS[7100052],
    mainType = "newyear_day_2018_lpxz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[7100053],
    reward = CHS[7100054],
    icon = "BigRewardIcon0017.png"
  },
  {
    name = CHS[4100871],
    showName = CHS[7120018],
    mainType = "newyear_day_2018_hyjb",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[4100872]
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[4100873],
    reward = CHS[4100874],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5450064],
    showName = CHS[5450065],
    mainType = "christmas_2017_sds",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5450066],
    reward = CHS[5450067],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450074],
    showName = CHS[5450073],
    mainType = "valentine_2018_adyq",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6400026],
    desc = CHS[5450075],
    reward = CHS[5450076],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400315],
    showName = CHS[5400314],
    mainType = "lantern_day_2018_mwyx",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[2200028],
    desc = CHS[5400316],
    reward = CHS[5400317],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450080],
    showName = CHS[5450077],
    mainType = "arbor_2018_xdjy",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5450078],
    reward = CHS[5450079],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450082],
    showName = CHS[5450081],
    mainType = "arbor_2018_qchc",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[5450083],
    reward = CHS[5450084],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450072],
    showName = CHS[5450069],
    mainType = "winter_day_2018_bxqy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[5450070],
    reward = CHS[5450071],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4100895],
    showName = CHS[4100896],
    mainType = "winter_day_2018_dxz",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[4200126],
    desc = CHS[4100897],
    reward = CHS[4100898],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7100096],
    showName = CHS[7100097],
    mainType = "winter_day_2020_dsz",
    level = 30,
    times = 1,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[7100098],
    reward = CHS[7100099],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7100092],
    showName = CHS[7100093],
    mainType = "winter_day_2018_hjzy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7100094],
    reward = CHS[7100095],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5400311],
    showName = CHS[5400310],
    mainType = "lantern_day_2018_lwxl",
    level = 30,
    times = 4,
    activeValue = 2.5,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[2200028],
    desc = CHS[5400312],
    reward = CHS[5400313],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400306],
    showName = CHS[5400307],
    mainType = "spring_day_2018_xnhb",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[2200028],
    desc = CHS[5400309],
    reward = CHS[5400308],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5000243],
    showName = CHS[5400318],
    mainType = "spring_day_2018_nhsr",
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[2200028],
    desc = CHS[5400321],
    reward = CHS[5400320],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5400329],
    showName = CHS[5400328],
    mainType = "spring_day_2018_ssnyf",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5400330],
    testDistDesc = CHS[5400330],
    reward = CHS[5400331],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7190116],
    showName = CHS[7190117],
    mainType = "qingming_2018_cytq",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7190118],
    reward = CHS[7190119],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7190121],
    showName = CHS[7190122],
    mainType = "qingming_2018_xlqg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7190123],
    reward = CHS[7190124],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5410177],
    showName = CHS[5410174],
    mainType = "wozhanzai_qiaoshan_kfj",
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5410175],
    reward = CHS[5410176],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5410206],
    showName = CHS[5410183],
    mainType = "shuilan_zhiyuan",
    level = 20,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5410182],
    reward = CHS[5410184],
    icon = "BigRewardIcon0008.png"
  },
  {
    name = CHS[5450090],
    showName = CHS[5450086],
    mainType = "fools_2018_zhrm",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5450087],
    reward = CHS[5450088],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450089],
    showName = CHS[5450091],
    mainType = "fools_2018_zcmj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[5450092],
    reward = CHS[5450093],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7190144],
    showName = CHS[7190145],
    mainType = "labor_day_2018",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[7190146],
    reward = CHS[7190147],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400448],
    showName = CHS[5400449],
    mainType = "zhounianqing_2018_xylm",
    level = 30,
    needLevelTip = true,
    canGotoInCombat = true,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "AnniversaryTreeDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5400446],
    reward = CHS[5400447],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7190158],
    showName = CHS[7190159],
    mainType = "zhounianqing_2018_fanpai",
    level = 30,
    times = 1,
    activeValue = 5,
    activeLimit = 5,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "AnniversaryCatCardDlg"
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    canGotoInCombat = true,
    team = CHS[3004412],
    desc = CHS[7190160],
    reward = CHS[7190161],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450110],
    showName = CHS[5450109],
    mainType = "child_day_2018_bscq",
    level = 30,
    needLevelTip = true,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[5450111],
    reward = CHS[5450112],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450113],
    showName = CHS[5450116],
    mainType = "child_day_2018_prms",
    level = 30,
    needLevelTip = true,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5450114],
    reward = CHS[5450115],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4101010],
    showName = CHS[4101010],
    mainType = "zhounianqing_2018_double",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4101011],
    reward = CHS[4101012],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[2000877],
    showName = CHS[2000878],
    mainType = "zhounianqing_2018_hongbao",
    level = 30,
    times = 10,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[4101026]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000272],
    desc = CHS[4101027],
    reward = CHS[4101028],
    itemName = CHS[4101029]
  },
  {
    name = CHS[7100170],
    showName = CHS[7100171],
    mainType = "zhounianqing_jishi",
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[7100174]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3004412],
    desc = CHS[7100172],
    reward = CHS[7100173],
    icon = "BigRewardIcon0052.png"
  },
  {
    name = CHS[7100202],
    showName = CHS[7100201],
    mainType = "zhounianqing_2018_fenxiang",
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000267],
    desc = CHS[7100203],
    reward = CHS[7100204],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7100264],
    showName = CHS[7190169],
    mainType = "summer_day_2018_lgey",
    level = 30,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[7190170],
    reward = CHS[7190171],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7190172],
    showName = CHS[7190173],
    mainType = "summer_day_2018_xyby",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7190174],
    reward = CHS[7190175],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5450125],
    showName = CHS[5450126],
    mainType = "summer_day_2018_hqzm",
    level = 30,
    times = 2,
    activeValue = 5,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000267],
    desc = CHS[5450127],
    reward = CHS[5450128],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450129],
    showName = CHS[5450130],
    mainType = "summer_day_2020_ysgw",
    level = 30,
    needLevelTip = true,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5450137],
    desc = CHS[5450131],
    reward = CHS[5450132],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450134],
    showName = CHS[5450133],
    mainType = "summer_day_2018_sncg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3004416],
    desc = CHS[5450135],
    reward = CHS[5450136],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450122],
    showName = CHS[5450121],
    mainType = "summer_day_2018_zdlm",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3004416],
    desc = CHS[5450123],
    reward = CHS[5450124],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4010021],
    showName = CHS[4101083],
    mainType = "duanwu_day_2018_zlsj",
    level = 30,
    times = 1,
    activeValue = 20,
    activeLimit = 20,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000267],
    desc = CHS[4010022],
    reward = CHS[4010023],
    icon = "BigRewardIcon0002.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7190207],
    showName = CHS[7190206],
    mainType = "ghost_2018_ccyh",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5450137],
    desc = CHS[7190208],
    reward = CHS[7190209],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5450239],
    showName = CHS[5450238],
    mainType = "ghost_2018_xgqy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[5450240],
    reward = CHS[5450241],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5450187],
    showName = CHS[5450186],
    mainType = "qixi_2018_mbhc",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5450137],
    desc = CHS[5450188],
    reward = CHS[5450189],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5450285],
    showName = CHS[5450284],
    mainType = "autumn_day_2018_zjyb",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[6000218],
    desc = CHS[5450286],
    reward = CHS[5450287],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7190302],
    showName = CHS[7190303],
    mainType = "autumn_day_2018_dww",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[5000250],
    desc = CHS[7190304],
    reward = CHS[7190305],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4010142],
    showName = CHS[4010143],
    mainType = "national_2018_sfqj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[4010144],
    reward = CHS[4010145],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010130],
    showName = CHS[4101105],
    mainType = "teacher_2018_lxes",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[2200028],
    desc = CHS[4010131],
    reward = CHS[4010132],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4010122],
    showName = CHS[5000293],
    mainType = "teacher_2018_xzse",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004416],
    desc = CHS[4010123],
    reward = CHS[4010124],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5450257],
    showName = CHS[5450256],
    mainType = "national_2018_ymlx",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004416],
    desc = CHS[5450258],
    reward = CHS[5450259],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4300449],
    showName = CHS[4300412],
    mainType = "world_cup_2018",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000267],
    desc = CHS[4300413],
    reward = CHS[4300414],
    icon = "BigRewardIcon0016.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010168],
    showName = CHS[4010169],
    mainType = "singles_2018_xjyy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[3000267],
    desc = CHS[4010170],
    reward = CHS[4010171],
    icon = "BigRewardIcon0002.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5450296],
    showName = CHS[5450295],
    mainType = "chongyang_2018_cyjj",
    level = 30,
    times = 1,
    activeValue = 20,
    activeLimit = 20,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[5450297],
    reward = CHS[5450298],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4010183],
    showName = CHS[4010184],
    mainType = "singles_2018_qygd",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[4010185],
    desc = CHS[4010186],
    reward = CHS[4010187],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5450314],
    showName = CHS[5450315],
    mainType = "hallowmas_2018_lyzm",
    level = 30,
    times = 1,
    activeValue = 20,
    activeLimit = 20,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[5450316],
    reward = CHS[5450317],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4101168],
    showName = CHS[4101169],
    mainType = "winter_day_2019_sxys",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[4101170],
    reward = CHS[4101171],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4101192],
    showName = CHS[4101193],
    mainType = "winter_day_2019_bx21d",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[5000250],
    desc = CHS[4101194],
    reward = CHS[4101195],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4101158],
    showName = CHS[4101159],
    mainType = "winter_day_2019_cyjl",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[5000250],
    desc = CHS[4101160],
    reward = CHS[4101161],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4101201],
    showName = CHS[4101202],
    mainType = "winter_day_2019_cxk",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[4101203],
    reward = CHS[4101204],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5400613],
    showName = CHS[5400614],
    mainType = "christmas_2018_sdlw",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[6000218],
    desc = CHS[5400615],
    reward = CHS[5400616],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5450059],
    showName = CHS[5450060],
    mainType = "christmas_2018_qsxj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[6000218],
    desc = CHS[5450058],
    reward = CHS[5450061],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400637],
    showName = CHS[5400638],
    mainType = "newyear_day_2019_bwswz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[5400639],
    reward = CHS[5400640],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4101153],
    showName = CHS[4101154],
    mainType = "newyear_day_2019_hyjb",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[4101155],
    reward = CHS[4101156],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5400714],
    showName = CHS[5400715],
    mainType = "lantern_day_2019_xyyx",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[5400716],
    reward = CHS[5400717],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400698],
    showName = CHS[5400699],
    mainType = "spring_day_2020_zsqf",
    level = 30,
    times = 6,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5400700],
    reward = CHS[5400701],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4300469],
    showName = CHS[4300470],
    mainType = "spring_day_2019_xtcl",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[3004412],
    desc = CHS[4300471],
    reward = CHS[4300472],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[2500081],
    showName = CHS[2500082],
    mainType = "arbor_day_2019_zsxc",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[2500083],
    reward = CHS[2500084],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    index = 161,
    name = CHS[7150104],
    showName = CHS[7150105],
    mainType = "spring_day_2019_xcbn",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[7150108]
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7150106],
    reward = CHS[7150107],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true
  },
  {
    name = CHS[2500076],
    showName = CHS[2500078],
    mainType = "arbor_day_2019_jmcl",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[2500079],
    reward = CHS[2500080],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101237],
    showName = CHS[4101238],
    mainType = "valentine_2019_cjmg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[4101239],
    reward = CHS[4101240],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5450341],
    showName = CHS[5450340],
    mainType = "fools_2019_qmjh",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5450342],
    reward = CHS[5450343],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5450361],
    showName = CHS[5450360],
    mainType = "qingming_2019_smdg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5450362],
    reward = CHS[5450363],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010233],
    showName = CHS[4010234],
    mainType = "labor_day_2019_zsjs",
    level = 30,
    times = 1,
    activeValue = 1,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4010235],
    reward = CHS[5400616],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7190366],
    showName = CHS[7190367],
    mainType = "zhounianqing_2019_dangao",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7190368],
    reward = CHS[7190369],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101310],
    showName = CHS[4101311],
    mainType = "zhounianqing_2019_fanpai",
    level = 30,
    times = 1,
    activeValue = 5,
    activeLimit = 5,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "AnniversaryPetCardDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4101312],
    reward = CHS[4101313],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010253],
    showName = CHS[4010254],
    mainType = "zhounianqing_2019_cwtx",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "AnniversaryPetAdventureDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4010255],
    reward = CHS[4010256],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    BigRewardIcon0022 = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010247],
    showName = CHS[4010248],
    mainType = "duanwu_2019_kwdz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4010249],
    reward = CHS[4010250],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7190374],
    showName = CHS[7190375],
    mainType = "child_day_2019_hsxg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7190376],
    reward = CHS[7190377],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5450425],
    showName = CHS[5450423],
    mainType = "duanwu_2019_zdbc",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5450426],
    reward = CHS[5450427],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5450442],
    showName = CHS[5450443],
    mainType = "summer_day_2019_smsz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5450444],
    reward = CHS[5450445],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010352],
    showName = CHS[4010353],
    mainType = "summer_day_2019_sxdj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5450137],
    desc = CHS[4010354],
    reward = CHS[4010355],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7190500],
    showName = CHS[7190501],
    mainType = "summer_day_2019_bhky",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7190502],
    reward = CHS[7190503],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5400804],
    showName = CHS[5400803],
    mainType = "summer_day_2019_xzjs",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[4010349],
    desc = CHS[5400805],
    reward = CHS[5400806],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010347],
    showName = CHS[4010348],
    mainType = "summer_day_2019_sswg",
    level = 30,
    times = 3,
    activeValue = 3,
    activeLimit = 9,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[4010349],
    desc = CHS[4010350],
    reward = CHS[4010351],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101473],
    showName = CHS[4101474],
    mainType = "qixi_2019_lmqg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5450137],
    desc = CHS[4101475],
    reward = CHS[4101476],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7100347],
    showName = CHS[7100348],
    mainType = "qixi_2019_qqzy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7100349],
    reward = CHS[7100350],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101575],
    showName = CHS[4101576],
    mainType = "teacher_2019_mpmz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4101577],
    reward = CHS[4101578],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7100457],
    showName = CHS[7100456],
    mainType = "autumn_day_2019_tyyh",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100460],
    desc = CHS[7100458],
    reward = CHS[7100459],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7100450],
    showName = CHS[7100449],
    mainType = "ghost_day_2019_bgyx",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100453],
    desc = CHS[7100451],
    reward = CHS[7100452],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5400120],
    showName = CHS[5400121],
    mainType = "autumn_day_2019_jyb",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    needLevelTip = true,
    beforeStartTime = "72:00",
    team = CHS[6000218],
    desc = CHS[5400122],
    reward = CHS[4101564],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4101606],
    showName = CHS[4101607],
    mainType = "national_2019_byxh",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100460],
    desc = CHS[4101608],
    reward = CHS[4101609],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101623],
    showName = CHS[4101624],
    mainType = "national_2019_bsjc",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5450137],
    desc = CHS[4101625],
    reward = CHS[4101626],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101602],
    showName = CHS[4101603],
    mainType = "xiayuan_day_2019_jbsg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100460],
    desc = CHS[4101604],
    reward = CHS[4101605],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5400846],
    showName = CHS[5400845],
    mainType = "xiayuan_day_2019_xlmz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[4010349],
    desc = CHS[5400847],
    reward = CHS[5400848],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7190604],
    showName = CHS[7190603],
    mainType = "chongyang_2019_dgqx",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100453],
    desc = CHS[7190605],
    reward = CHS[7190606],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010435],
    showName = CHS[4010436],
    mainType = "chongyang_2019_fzlr",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100460],
    desc = CHS[4010437],
    reward = CHS[4010438],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101677],
    showName = CHS[4101678],
    mainType = "fengshou_2019_wgfd",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100453],
    desc = CHS[4101679],
    reward = CHS[4101680],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4010475],
    showName = CHS[4010476],
    mainType = "ruixue_2019_rxlw",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100460],
    desc = CHS[4010477],
    reward = CHS[4101171],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7190853],
    showName = CHS[7190854],
    mainType = "ruixue_2019_xqdz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100453],
    desc = CHS[7190855],
    reward = CHS[7190856],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[2000714],
    showName = CHS[2000715],
    mainType = "newyear_day_2020_mcqh",
    level = 30,
    times = 2,
    activeValue = 5,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5450137],
    desc = CHS[2000716],
    reward = CHS[2000717],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[2000710],
    showName = CHS[2000711],
    mainType = "winter_day_2020_jrpm",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[2000712],
    reward = CHS[2000713],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5200052],
    showName = CHS[5200053],
    mainType = "winter_day_2020_xrblq",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5200056],
    desc = CHS[5200054],
    reward = CHS[5200055],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101773],
    showName = CHS[4101774],
    mainType = "lantern_day_2020_cdm",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[4200126],
    desc = CHS[4101778],
    reward = CHS[4101779],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7120374],
    showName = CHS[7120375],
    mainType = "lantern_day_2020_yxqj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7120376],
    desc = CHS[7120377],
    reward = CHS[7120378],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5000328],
    showName = CHS[5000329],
    mainType = "winter_day_2020_xzdzz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5000330],
    desc = CHS[5000331],
    reward = CHS[5000332],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7120382],
    showName = CHS[7120383],
    mainType = "spring_day_2020_bzqy",
    level = 30,
    times = 2,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7150088],
    desc = CHS[7120384],
    reward = CHS[7120385],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5400781],
    showName = CHS[5400780],
    mainType = "spring_day_2020_xcxb",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[5400787]
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5400782],
    reward = CHS[5400783],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true
  },
  {
    name = CHS[4101799],
    showName = CHS[4101800],
    mainType = "tongxin_day_2020_txjy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[4101801],
    desc = CHS[4101802],
    reward = CHS[5410412],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true
  },
  {
    name = CHS[7100886],
    showName = CHS[7100885],
    mainType = "tongxin_day_2020_qlxh",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7150088],
    desc = CHS[7100887],
    reward = CHS[7100888],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[2000740],
    showName = CHS[2000741],
    mainType = "qingming_day_2020_slqx",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7150088],
    desc = CHS[2000742],
    reward = CHS[2000743],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[2000879],
    showName = CHS[2000880],
    mainType = "qingming_day_2020_qmdj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[4010185],
    desc = CHS[4200986],
    reward = CHS[4200987],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4200928],
    showName = CHS[4200927],
    mainType = "arbor_day_2020_zjgs",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100460],
    desc = CHS[4200925],
    reward = CHS[4200926],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4200933],
    showName = CHS[4200934],
    mainType = "arbor_day_2020_shgs",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[6400026],
    desc = CHS[4200936],
    reward = CHS[4200937],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[7120525],
    showName = CHS[7120526],
    mainType = "zhizhe_2020_ygys",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7120529],
    desc = CHS[7120527],
    reward = CHS[7120528],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[2200208],
    showName = CHS[2200209],
    mainType = "labor_day_2020_zrsc",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100460],
    desc = CHS[2200210],
    reward = CHS[2200211],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5410461],
    showName = CHS[5410461],
    mainType = "mijing_shilian",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100460],
    desc = CHS[5410462],
    reward = CHS[5410470],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    canGotoInCombat = true
  },
  {
    name = CHS[2000749],
    showName = CHS[2000749],
    mainType = "shishenji",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[7100460],
    desc = CHS[2000750],
    reward = CHS[2000751],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    canGotoInCombat = true
  },
  {
    name = CHS[4201056],
    showName = CHS[4201057],
    mainType = "duanwu_day_2020_zdwd",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100460],
    desc = CHS[4201058],
    reward = CHS[4201059],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5410496],
    showName = CHS[5410495],
    mainType = "zhounianqing_hualan",
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[7383507],
    reward = CHS[5410498],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5000348],
    showName = CHS[5000349],
    mainType = "tongxin_2020_discount",
    level = 40,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[5000350]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[6400026],
    desc = CHS[5000351],
    reward = CHS[5000352],
    itemName = CHS[7100168]
  },
  {
    name = CHS[2100357],
    showName = CHS[2100358],
    mainType = "zhounianqing_2020_xdhx",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100460],
    desc = CHS[2100359],
    reward = CHS[2100360],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[2100361],
    showName = CHS[2100362],
    mainType = "zhounianqing_2020_cglh",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100460],
    desc = CHS[2100363],
    reward = CHS[2100364],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4201022],
    showName = CHS[4201023],
    mainType = "child_day_2020_tzhj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100453],
    desc = CHS[4201024],
    reward = CHS[4201025],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4300753],
    showName = CHS[4300754],
    mainType = "zhounianqing_2020_tzzry",
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[4300757]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100460],
    desc = CHS[4300755],
    reward = CHS[4300756],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true
  },
  {
    name = CHS[4101902],
    showName = CHS[4101903],
    mainType = "teacher_day_2020_hyxz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100460],
    desc = CHS[4101904],
    reward = CHS[4101905],
    icon = "BigRewardIcon0022.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4201121],
    showName = CHS[4201122],
    mainType = "teacher_day_2020_wxdj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[5000330],
    desc = CHS[4201123],
    reward = CHS[4201124],
    icon = "BigRewardIcon0002.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5000353],
    showName = CHS[5000354],
    mainType = "summer_day_2020_sjll",
    level = 30,
    needLevelTip = true,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3000267],
    desc = CHS[5000355],
    reward = CHS[5000356],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7100962],
    showName = CHS[7100961],
    mainType = "summer_day_2020_hmsy",
    level = 30,
    times = 1,
    activeValue = 20,
    activeLimit = 20,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100965],
    desc = CHS[7100963],
    reward = CHS[7100964],
    icon = "BigRewardIcon0022.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101859],
    showName = CHS[4101860],
    mainType = "summer_day_2020_dkfx",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4101861],
    reward = CHS[4101862],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101863],
    showName = CHS[4101867],
    mainType = "summer_day_2020_bssz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004416],
    desc = CHS[4101868],
    reward = CHS[4101869],
    icon = "BigRewardIcon0002.png",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4101876],
    showName = CHS[4101877],
    mainType = "qixi_2020_yfsg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[5000330],
    desc = CHS[4101878],
    reward = CHS[4101879],
    icon = "BigRewardIcon0022.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[5410660],
    showName = CHS[5410659],
    mainType = "ghost_day_2020_bsccl",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[5401031]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100460],
    desc = CHS[5410661],
    reward = CHS[5400783],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5410671],
    showName = CHS[5410672],
    mainType = "ghost_day_2020_qgcx",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100453],
    desc = CHS[5410673],
    reward = CHS[5410674],
    icon = "BigRewardIcon0002.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[4201125],
    showName = CHS[4201126],
    mainType = "chongyang_2020_gjyt",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[6000218],
    desc = CHS[4201127],
    reward = CHS[4201128],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7350023],
    showName = CHS[7350024],
    mainType = "chongyang_2020_jddh",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100453],
    desc = CHS[7350025],
    reward = CHS[4101883],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5400092],
    showName = CHS[5400113],
    mainType = "guoqingjie_2020_gift",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "HolidayGiftDlg"
      }
    },
    beforeStartTime = "72:00",
    canGotoInCombat = true,
    team = CHS[6000218],
    desc = CHS[4101947],
    reward = CHS[4101948],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4101943],
    showName = CHS[4101944],
    mainType = "national_day_2020_wxfz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[5200056],
    desc = CHS[4101945],
    reward = CHS[4101946],
    icon = "BigRewardIcon0022.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[2000881],
    showName = CHS[2000882],
    mainType = "autumn_day_2020_zqys",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[6000218],
    desc = CHS[5110024],
    reward = CHS[5110025],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5400101],
    showName = CHS[5400114],
    mainType = "autumn_day_2020_bb",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "npc",
        CHS[2000885]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[6000218],
    desc = CHS[5400102],
    reward = CHS[2000886],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4101880],
    showName = CHS[4101881],
    mainType = "national_day_2020_rzwj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[7100453],
    desc = CHS[4101882],
    reward = CHS[4201205],
    icon = "BigRewardIcon0002.png",
    goToBtnSameAsTaskPanel = true
  },
  {
    name = CHS[2000887],
    showName = CHS[2000888],
    mainType = "xiayuan_2020_xywd",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[6000218],
    desc = CHS[2000889],
    reward = CHS[2000890],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7366703],
    showName = CHS[7366704],
    mainType = "xiayuan_2020_strz",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100453],
    desc = CHS[7366705],
    reward = CHS[7366706],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5401142],
    showName = CHS[5401141],
    mainType = "fengshou_2020_hlyl",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[6000218],
    desc = CHS[5401143],
    reward = CHS[5401144],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4010566],
    showName = CHS[4010567],
    mainType = "ruixue_2020_sxzl",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[4010568],
    reward = CHS[4010569],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4101962],
    showName = CHS[4101963],
    mainType = "ruixue_2020_scds",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100453],
    desc = CHS[4101964],
    reward = CHS[4101965],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5430012],
    showName = CHS[5430011],
    mainType = "qixi_2018_discount",
    level = 40,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "tips",
        CHS[5430015]
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    team = CHS[6400026],
    desc = CHS[5430013],
    reward = CHS[5430014],
    itemName = CHS[7100168]
  },
  {
    name = CHS[7366714],
    showName = CHS[7366715],
    mainType = "winter_day_2021_ssgs",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[7366716],
    reward = CHS[2100364],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4101984],
    showName = CHS[4101985],
    mainType = "winter_day_2021_lzky",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100453],
    desc = CHS[4101986],
    reward = CHS[4101987],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5401162],
    showName = CHS[5401161],
    mainType = "newyear_2021_yjxb",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100453],
    desc = CHS[5401163],
    reward = CHS[5401164],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5401173],
    showName = CHS[5401172],
    mainType = "spring_day_2021_xcgh",
    level = 30,
    times = 6,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[5401174],
    reward = CHS[5401175],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7366718],
    showName = CHS[7366719],
    mainType = "winter_day_2021_bwxy",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[7366720],
    reward = CHS[5401164],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5120007],
    showName = CHS[5120008],
    mainType = "chunjie_2021_gift",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "giftDlg",
        "HolidayGiftDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[5120009],
    reward = CHS[5120010],
    icon = "BigRewardIcon0022.png",
    needLevelTip = true
  },
  {
    name = CHS[5401169],
    showName = CHS[5401168],
    mainType = "spring_day_2021_zqhb",
    level = 30,
    times = 2,
    activeValue = 5,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[5401170],
    reward = CHS[5401171],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7333442],
    showName = CHS[7333385],
    mainType = "spring_day_2021_xcwl",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100453],
    desc = CHS[7333386],
    reward = CHS[5410412],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4102028],
    showName = CHS[4102029],
    mainType = "tongxin_day_2021_xczd",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[4102030],
    reward = CHS[4201128],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4102066],
    showName = CHS[5200071],
    mainType = "tongxin_day_2021_bysf",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7120376],
    desc = CHS[4102068],
    reward = CHS[4101987],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7366755],
    showName = CHS[7366756],
    mainType = "lantern_day_2021_hlff",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[5000330],
    desc = CHS[7366757],
    reward = CHS[5410412],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[4102025],
    showName = CHS[4102026],
    mainType = "lantern_day_2021_cnrj",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[4102027],
    reward = CHS[5200055],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5110026],
    showName = CHS[5110027],
    mainType = "arbor_day_2021_zsbp",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[4101801],
    desc = CHS[5110029],
    reward = CHS[5110030],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[7383389],
    showName = CHS[7383390],
    mainType = "qingming_day_2021_jhhs",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[7100460],
    desc = CHS[7383391],
    reward = CHS[5200055],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4102174],
    showName = CHS[4102175],
    mainType = "qingming_day_2021_qgbs",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[5000330],
    desc = CHS[4102176],
    reward = CHS[4102177],
    icon = "BigRewardIcon0002.png"
  },
  {
    name = CHS[5200066],
    showName = CHS[5200067],
    mainType = "zhizhe_day_2021_zzbt",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[2100456],
    desc = CHS[5200068],
    reward = CHS[5200069],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7383492],
    showName = CHS[7383493],
    mainType = "zhounianqing_2021_qdjq",
    level = 30,
    needLevelTip = true,
    canGotoInCombat = true,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[7383491],
    reward = CHS[4200514],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7190370],
    showName = CHS[7190371],
    mainType = "zhounq_2021_gift",
    level = 30,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    canGotoInCombat = true,
    activityTime = {
      {
        "",
        "dlg",
        "AnniversaryGiftDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4101844],
    reward = CHS[4102191],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4102194],
    showName = CHS[4102195],
    mainType = "zhounianqing_2021_rfbp_new",
    level = 30,
    needLevelTip = true,
    times = 1,
    canGotoInCombat = true,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "dlg",
        "RanfbpDlg"
      }
    },
    beforeStartTime = "72:00",
    team = CHS[3004412],
    desc = CHS[4102192],
    reward = CHS[4102193],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[5200072],
    showName = CHS[5200073],
    mainType = "zhounianqing_2021_whnf",
    level = 30,
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5200074],
    desc = CHS[5200075],
    reward = CHS[5200076],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7350101],
    showName = CHS[7350102],
    mainType = "labor_day_2021_hxlp",
    level = 30,
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5200074],
    desc = CHS[7350099],
    reward = CHS[7350100],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[7350115],
    showName = CHS[7350116],
    mainType = "child_day_2021_ymsk",
    level = 30,
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    team = CHS[5200074],
    desc = CHS[7350117],
    reward = CHS[7350118],
    icon = "BigRewardIcon0022.png"
  },
  {
    name = CHS[4201311],
    showName = CHS[4201312],
    mainType = "child_day_2021_nzwg",
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "8",
    activityTime = {
      {
        "",
        "",
        ""
      }
    },
    beforeStartTime = "72:00",
    needLevelTip = true,
    goToBtnSameAsTaskPanel = true,
    team = CHS[4010349],
    desc = CHS[4201313],
    reward = CHS[5410412],
    icon = "BigRewardIcon0002.png"
  }
}
