return {
  [CHS[2500061]] = {
    material = {
      [CHS[2500062]] = 8,
      [CHS[2500063]] = 10,
      [CHS[2500064]] = 8,
      [CHS[2500065]] = 4
    },
    isFunc = 1,
    funcDes = CHS[7100045]
  },
  [CHS[7100003]] = {
    material = {
      [CHS[7100023]] = 45,
      [CHS[7100024]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100004]] = {
    material = {
      [CHS[7100023]] = 45,
      [CHS[7100024]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100005]] = {
    material = {
      [CHS[7100023]] = 45,
      [CHS[7100024]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100006]] = {
    material = {
      [CHS[7100025]] = 20,
      [CHS[7100023]] = 5,
      [CHS[7100024]] = 2
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100007]] = {
    material = {
      [CHS[7100026]] = 12,
      [CHS[7100024]] = 3
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100008]] = {
    material = {
      [CHS[7100026]] = 10,
      [CHS[7100023]] = 5,
      [CHS[7100027]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100009]] = {
    material = {
      [CHS[7100028]] = 8,
      [CHS[7100029]] = 3,
      [CHS[7100024]] = 2
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100010]] = {
    material = {
      [CHS[7100030]] = 5,
      [CHS[7100029]] = 7
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[4300677]] = {
    material = {
      [CHS[7100029]] = 30,
      [CHS[7100030]] = 2
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[4300679]] = {
    material = {
      [CHS[7100030]] = 4,
      [CHS[7100025]] = 15,
      [CHS[7100024]] = 2
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[4300680]] = {
    material = {
      [CHS[7100031]] = 7,
      [CHS[7100030]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100011]] = {
    material = {
      [CHS[7100025]] = 15,
      [CHS[7100027]] = 2,
      [CHS[7100031]] = 5
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100012]] = {
    material = {
      [CHS[7100031]] = 5,
      [CHS[7100030]] = 1,
      [CHS[7100026]] = 6,
      [CHS[7100027]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100013]] = {
    material = {
      [CHS[7100028]] = 10,
      [CHS[7100027]] = 3,
      [CHS[7100030]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100014]] = {
    material = {
      [CHS[7100028]] = 10,
      [CHS[7100027]] = 4,
      [CHS[7100024]] = 5
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100015]] = {
    material = {
      [CHS[7100028]] = 10,
      [CHS[7100027]] = 1,
      [CHS[7100031]] = 3
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100016]] = {
    material = {
      [CHS[7100030]] = 5,
      [CHS[7100027]] = 2
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[4300678]] = {
    material = {
      [CHS[7100029]] = 5,
      [CHS[7100027]] = 12,
      [CHS[7100030]] = 6
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100017]] = {
    material = {
      [CHS[7100026]] = 50,
      [CHS[7100030]] = 5,
      [CHS[7100027]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[4300681]] = {
    material = {
      [CHS[7100030]] = 10,
      [CHS[7100028]] = 15,
      [CHS[7100027]] = 1
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100018]] = {
    material = {
      [CHS[7100030]] = 15,
      [CHS[7100029]] = 15
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100019]] = {
    material = {
      [CHS[7100028]] = 20,
      [CHS[7100027]] = 25
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100020]] = {
    material = {
      [CHS[7100028]] = 15,
      [CHS[7100027]] = 5,
      [CHS[7100030]] = 11
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100021]] = {
    material = {
      [CHS[7100028]] = 18,
      [CHS[7100027]] = 15,
      [CHS[7100030]] = 5
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7100022]] = {
    material = {
      [CHS[7100028]] = 4,
      [CHS[7100029]] = 15,
      [CHS[7100030]] = 15
    },
    isFunc = 0,
    funcDes = CHS[7100047]
  },
  [CHS[7190000]] = {
    material = {
      [CHS[7100027]] = 5,
      [CHS[7100025]] = 5
    },
    isFunc = 1,
    funcDes = CHS[7100046]
  },
  [CHS[7190001]] = {
    material = {
      [CHS[7100030]] = 5,
      [CHS[7100028]] = 2,
      [CHS[7100024]] = 2
    },
    isFunc = 1,
    funcDes = CHS[7100048]
  },
  [CHS[7190002]] = {
    material = {
      [CHS[7100030]] = 15,
      [CHS[7100028]] = 10
    },
    isFunc = 1,
    funcDes = CHS[7100049]
  },
  [CHS[5400255]] = {
    material = {
      [CHS[7100031]] = 1,
      [CHS[7100027]] = 1
    },
    isFunc = 1,
    funcDes = CHS[7100050]
  },
  [CHS[5400256]] = {
    material = {
      [CHS[7100031]] = 1,
      [CHS[7100027]] = 1
    },
    isFunc = 1,
    funcDes = CHS[7100050]
  }
}
