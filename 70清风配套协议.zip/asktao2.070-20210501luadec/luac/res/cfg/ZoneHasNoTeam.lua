return {
  [CHS[3002131]] = CHS[3002132]
}
