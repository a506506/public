return {
  ["超级绿水晶"] = {lingchen_point = 1000},
  ["黄水晶"] = {lingchen_point = 418},
  ["超级圣水晶"] = {lingchen_point = 1000},
  ["超级粉水晶"] = {lingchen_point = 2800},
  ["超级灵石"] = {lingchen_point = 398},
  ["超级晶石"] = {lingchen_point = 108},
  ["超级黑水晶"] = {lingchen_point = 328},
  ["混沌玉"] = {lingchen_point = 518},
  ["装备共鸣石"] = {lingchen_point = 328},
  ["风灵丸"] = {lingchen_point = 328},
  ["聚灵石"] = {lingchen_point = 1000},
  ["宠物强化丹"] = {lingchen_point = 216},
  ["点化丹"] = {lingchen_point = 328},
  ["羽化丹"] = {lingchen_point = 518},
  ["超级归元露"] = {lingchen_point = 216},
  ["超级神兽丹"] = {lingchen_point = 108},
  ["宠物顿悟丹"] = {lingchen_point = 328}
}
