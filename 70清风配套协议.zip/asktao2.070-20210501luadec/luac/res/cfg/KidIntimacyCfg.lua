return {
  [0] = {
    revivification_rate = 0,
    revivification_time = 0,
    double_hit_rate = 10,
    double_hit_time = 2,
    stunt_rate = 10,
    pow = 3,
    def = 5
  },
  [20000] = {
    revivification_rate = 10,
    revivification_time = 1,
    double_hit_rate = 20,
    double_hit_time = 3,
    stunt_rate = 20,
    pow = 6,
    def = 10
  },
  [60000] = {
    revivification_rate = 20,
    revivification_time = 2,
    double_hit_rate = 30,
    double_hit_time = 4,
    stunt_rate = 30,
    pow = 10,
    def = 15
  },
  [100000] = {
    revivification_rate = 30,
    revivification_time = 2,
    double_hit_rate = 40,
    double_hit_time = 5,
    stunt_rate = 40,
    pow = 15,
    def = 20
  },
  [200000] = {
    revivification_rate = 40,
    revivification_time = 2,
    double_hit_rate = 50,
    double_hit_time = 6,
    stunt_rate = 50,
    pow = 20,
    def = 25
  },
  [400000] = {
    revivification_rate = 50,
    revivification_time = 3,
    double_hit_rate = 50,
    double_hit_time = 7,
    stunt_rate = 50,
    pow = 25,
    def = 30
  },
  [1000000] = {
    revivification_rate = 50,
    revivification_time = 3,
    double_hit_rate = 50,
    double_hit_time = 8,
    stunt_rate = 50,
    pow = 30,
    def = 35
  }
}
