return {
  [20020] = {type = 1},
  [1155] = {
    type = 0,
    extraPara = {blendMode = "add"}
  }
}
