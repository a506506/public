return {
  ["多闻道人"] = {
    talkEffectList = {
      "Talk01001",
      "Talk01002",
      "Talk01003"
    }
  },
  ["黄仨儿"] = {
    talkEffectList = {
      "Talk01004",
      "Talk01005",
      "Talk01006"
    }
  },
  ["王老板"] = {
    talkEffectList = {"Talk01007", "Talk01008"}
  },
  ["莲花姑娘"] = {
    talkEffectList = {
      "Talk01009",
      "Talk01010",
      "Talk01011"
    }
  },
  ["赵老板"] = {
    talkEffectList = {"Talk01012", "Talk01099"}
  },
  ["张老板"] = {
    talkEffectList = {"Talk01013", "Talk01014"}
  },
  ["卜老板"] = {
    talkEffectList = {"Talk01015"}
  },
  ["贾老板"] = {
    talkEffectList = {"Talk01016"}
  },
  ["钱老板"] = {
    talkEffectList = {"Talk01017", "Talk01018"}
  },
  ["乐善施"] = {
    talkEffectList = {"Talk01019"}
  },
  ["清净散人"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["一叶知秋"] = {
    talkEffectList = {"Talk01023", "Talk01024"}
  },
  ["活动大使"] = {
    talkEffectList = {
      "Talk02001",
      "Talk02002",
      "Talk02003",
      "Talk02004"
    }
  },
  ["天机老人"] = {
    talkEffectList = {"Talk02005", "Talk02006"}
  },
  ["李总兵"] = {
    talkEffectList = {"Talk02007", "Talk02099"}
  },
  ["通灵道人"] = {
    talkEffectList = {
      "Talk02008",
      "Talk02009",
      "Talk02010"
    }
  },
  ["白邦芒"] = {
    talkEffectList = {"Talk02011", "Talk02012"}
  },
  ["赤灵尊神"] = {
    talkEffectList = {"Talk02013", "Talk02014"}
  },
  ["杨镖头"] = {
    talkEffectList = {"Talk02015", "Talk02016"}
  },
  ["试道申请人"] = {
    talkEffectList = {"Talk02017"}
  },
  ["管神工"] = {
    talkEffectList = {"Talk02018"}
  },
  ["厉巧手"] = {
    talkEffectList = {"Talk02019"}
  },
  ["晶晶儿"] = {
    talkEffectList = {"Talk02020"}
  },
  ["百晓通"] = {
    talkEffectList = {"Talk02021"}
  },
  ["夜行人"] = {
    talkEffectList = {"Talk02022"}
  },
  ["灵兽异人"] = {
    talkEffectList = {"Talk02023"}
  },
  ["无名剑客"] = {
    talkEffectList = {"Talk02024"}
  },
  ["船夫"] = {
    talkEffectList = {"Talk02025"}
  },
  ["千面怪"] = {
    talkEffectList = {"Talk02026"}
  },
  ["衙门口的乞丐"] = {
    talkEffectList = {"Talk02027"}
  },
  ["城北的乞丐"] = {
    talkEffectList = {"Talk02027"}
  },
  ["药铺旁的乞丐"] = {
    talkEffectList = {"Talk02027"}
  },
  ["守城士兵"] = {
    talkEffectList = {"Talk02028"}
  },
  ["竞技使者"] = {
    talkEffectList = {"Talk02029"}
  },
  ["帮派总管"] = {
    talkEffectList = {"Talk02030"}
  },
  ["帮派军师"] = {
    talkEffectList = {"Talk02031"}
  },
  ["北斗星使"] = {
    talkEffectList = {"Talk02032"}
  },
  ["蒙面"] = {
    talkEffectList = {"Talk02033"}
  },
  ["车夫"] = {
    talkEffectList = {"Talk03001"}
  },
  ["无想僧"] = {
    talkEffectList = {"Talk03002"}
  },
  ["苏苏"] = {
    talkEffectList = {"Talk03003"}
  },
  ["朱雀"] = {
    talkEffectList = {"Talk03004", "Talk03005"}
  },
  ["文殊天尊"] = {
    talkEffectList = {"Talk03006", "Talk03007"}
  },
  ["云霄童子"] = {
    talkEffectList = {"Talk03008", "Talk03009"}
  },
  ["碧玉童子"] = {
    talkEffectList = {"Talk03010", "Talk03011"}
  },
  ["龙吉公主"] = {
    talkEffectList = {"Talk03012", "Talk03013"}
  },
  ["水灵童子"] = {
    talkEffectList = {"Talk03014", "Talk03015"}
  },
  ["赤霞童子"] = {
    talkEffectList = {"Talk03016", "Talk03017"}
  },
  ["彩云童子"] = {
    talkEffectList = {"Talk03018", "Talk03019"}
  },
  ["神龙真人"] = {
    talkEffectList = {"Talk03020"}
  },
  ["憾地魔"] = {
    talkEffectList = {"Talk03021"}
  },
  ["蓬莱使者"] = {
    talkEffectList = {"Talk03022"}
  },
  ["柳如尘"] = {
    talkEffectList = {
      "Talk02008",
      "Talk02009",
      "Talk02010"
    }
  },
  ["钱庄老板"] = {
    talkEffectList = {"Talk01017", "Talk01018"}
  },
  ["药店老板"] = {
    talkEffectList = {"Talk01007", "Talk01008"}
  },
  ["客栈老板"] = {
    talkEffectList = {"Talk01012", "Talk01099"}
  },
  ["宋辛哲"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["玉真子"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["钱大富"] = {
    talkEffectList = {"Talk01017", "Talk01018"}
  },
  ["杂货店老板"] = {
    talkEffectList = {"Talk01016"}
  },
  ["账房先生"] = {
    talkEffectList = {"Talk01024"}
  },
  ["帮派侍女"] = {
    talkEffectList = {"Talk01010"}
  },
  ["帮派书童"] = {
    talkEffectList = {"Talk02020"}
  },
  ["杜卜思"] = {
    talkEffectList = {"Talk01007", "Talk01008"}
  },
  ["段铁心"] = {
    talkEffectList = {"Talk01013", "Talk01014"}
  },
  ["贾仁和"] = {
    talkEffectList = {"Talk01015"}
  },
  ["冯喜来"] = {
    talkEffectList = {"Talk01012", "Talk01099"}
  },
  ["厉北七"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["帮派使者"] = {
    talkEffectList = {"Talk02031"}
  },
  ["集市管理员"] = {
    talkEffectList = {"Talk01017", "Talk01018"}
  },
  ["屠娇娇"] = {
    talkEffectList = {"Talk01009", "Talk01010"}
  },
  ["董老头"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["贾师爷"] = {
    talkEffectList = {"Talk01024"}
  },
  ["逍遥仙"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["夏总兵"] = {
    talkEffectList = {"Talk02007", "Talk02099"}
  },
  ["辛仁皑"] = {
    talkEffectList = {"Talk01019"}
  },
  ["妙手道人"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["逍遥仙"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["神算子"] = {
    talkEffectList = {"Talk02005", "Talk02006"}
  },
  ["大胡子"] = {
    talkEffectList = {"Talk02003", "Talk02004"}
  },
  ["茅山道士"] = {
    talkEffectList = {
      "Talk02008",
      "Talk02009",
      "Talk02010"
    }
  },
  ["月老"] = {
    talkEffectList = {"Talk02006"}
  },
  ["云霄长老"] = {
    talkEffectList = {"Talk01002"}
  },
  ["雷神"] = {
    talkEffectList = {
      "Talk02002",
      "Talk02003",
      "Talk02004"
    }
  },
  ["云中子"] = {
    talkEffectList = {"Talk03006", "Talk03007"}
  },
  ["玉柱长老"] = {
    talkEffectList = {"Talk01002"}
  },
  ["花神"] = {
    talkEffectList = {"Talk03004", "Talk03005"}
  },
  ["斗阙长老"] = {
    talkEffectList = {"Talk03005"}
  },
  ["龙神"] = {
    talkEffectList = {"Talk03004", "Talk03005"}
  },
  ["太乙真人"] = {
    talkEffectList = {"Talk03006", "Talk03007"}
  },
  ["金光长老"] = {
    talkEffectList = {"Talk01002"}
  },
  ["炎神"] = {
    talkEffectList = {
      "Talk02002",
      "Talk02003",
      "Talk02004"
    }
  },
  ["石矶娘娘"] = {
    talkEffectList = {"Talk03012", "Talk03013"}
  },
  ["白骨长老"] = {
    talkEffectList = {"Talk01002"}
  },
  ["白虎"] = {
    talkEffectList = {"Talk02009"}
  },
  ["玄武"] = {
    talkEffectList = {"Talk02009"}
  },
  ["青龙"] = {
    talkEffectList = {"Talk02009"}
  },
  ["白素"] = {
    talkEffectList = {"Talk01010"}
  },
  ["云游大仙"] = {
    talkEffectList = {"Talk02014"}
  },
  ["无念僧"] = {
    talkEffectList = {"Talk03002"}
  },
  ["多宝道人"] = {
    talkEffectList = {
      "Talk02008",
      "Talk02009",
      "Talk02010"
    }
  },
  ["陆压真人"] = {
    talkEffectList = {
      "Talk02008",
      "Talk02009",
      "Talk02010"
    }
  },
  ["玉泉真人"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["清微真人"] = {
    talkEffectList = {
      "Talk01020",
      "Talk01021",
      "Talk01022"
    }
  },
  ["无名药铺老板"] = {
    talkEffectList = {"Talk01007", "Talk01008"}
  },
  ["无名武器店老板"] = {
    talkEffectList = {"Talk01013", "Talk01014"}
  },
  ["无名布庄老板"] = {
    talkEffectList = {"Talk01015"}
  },
  ["无名客栈老板"] = {
    talkEffectList = {"Talk01012", "Talk01099"}
  },
  ["无名杂货店老板"] = {
    talkEffectList = {"Talk01016"}
  },
  ["善财童子"] = {
    talkEffectList = {"Talk02020"}
  },
  ["张真人"] = {
    talkEffectList = {
      "Talk02008",
      "Talk02009",
      "Talk02010"
    }
  }
}
