return {
  [1] = {
    [CHS[3001625]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001626]] = {
      openLevel = 19,
      maxRange = 2,
      minRange = 1
    },
    [CHS[3001627]] = {
      openLevel = 32,
      maxRange = 5,
      minRange = 2
    },
    [CHS[3001628]] = {
      openLevel = 50,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001629]] = {
      openLevel = 100,
      maxRange = 5,
      minRange = 3
    },
    [CHS[3001630]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001631]] = {
      openLevel = 1,
      maxRange = 2,
      minRange = 1
    },
    [CHS[3001632]] = {
      openLevel = 1,
      maxRange = 5,
      minRange = 2
    },
    [CHS[3001633]] = {
      openLevel = 50,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001634]] = {
      openLevel = 100,
      maxRange = 7,
      minRange = 3
    }
  },
  [2] = {
    [CHS[3001635]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001636]] = {
      openLevel = 19,
      maxRange = 2,
      minRange = 1
    },
    [CHS[3001637]] = {
      openLevel = 32,
      maxRange = 5,
      minRange = 2
    },
    [CHS[3001638]] = {
      openLevel = 50,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001639]] = {
      openLevel = 100,
      maxRange = 5,
      minRange = 3
    },
    [CHS[3001640]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001641]] = {
      openLevel = 1,
      maxRange = 2,
      minRange = 1
    },
    [CHS[3001642]] = {
      openLevel = 1,
      maxRange = 5,
      minRange = 2
    },
    [CHS[3001643]] = {
      openLevel = 50,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001644]] = {
      openLevel = 100,
      maxRange = 7,
      minRange = 3
    }
  },
  [3] = {
    [CHS[3001645]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001646]] = {
      openLevel = 19,
      maxRange = 2,
      minRange = 1
    },
    [CHS[3001647]] = {
      openLevel = 32,
      maxRange = 5,
      minRange = 2
    },
    [CHS[3001648]] = {
      openLevel = 50,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001649]] = {
      openLevel = 100,
      maxRange = 5,
      minRange = 3
    },
    [CHS[3001650]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001651]] = {
      openLevel = 1,
      maxRange = 2,
      minRange = 1
    },
    [CHS[3001652]] = {
      openLevel = 1,
      maxRange = 5,
      minRange = 3
    },
    [CHS[3001653]] = {
      openLevel = 50,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001654]] = {
      openLevel = 100,
      maxRange = 7,
      minRange = 3
    }
  },
  [4] = {
    [CHS[3001655]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001656]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001657]] = {
      openLevel = 1,
      maxRange = 2,
      minRange = 1
    },
    [CHS[3001658]] = {
      openLevel = 1,
      maxRange = 5,
      minRange = 2
    },
    [CHS[3001659]] = {
      openLevel = 50,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001660]] = {
      openLevel = 100,
      maxRange = 7,
      minRange = 3
    }
  },
  [5] = {
    [CHS[3001655]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001661]] = {
      openLevel = 1,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001662]] = {
      openLevel = 1,
      maxRange = 2,
      minRange = 1
    },
    [CHS[3001663]] = {
      openLevel = 1,
      maxRange = 5,
      minRange = 2
    },
    [CHS[3001664]] = {
      openLevel = 50,
      maxRange = 1,
      minRange = 1
    },
    [CHS[3001665]] = {
      openLevel = 100,
      maxRange = 7,
      minRange = 3
    }
  }
}
