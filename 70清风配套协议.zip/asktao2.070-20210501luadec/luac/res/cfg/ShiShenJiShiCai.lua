return {
  ["黄豆"] = {
    keyName = "黄豆",
    showName = "黄豆",
    icon = 9221,
    level = 1,
    unit = "份",
    type = "蔬菜",
    order = 0
  },
  ["虾"] = {
    keyName = "虾",
    showName = "虾",
    icon = 14131,
    level = 2,
    unit = "份",
    type = "肉类",
    order = 1
  },
  ["葱"] = {
    keyName = "葱",
    showName = "葱",
    icon = 9226,
    level = 2,
    unit = "份",
    type = "其他",
    order = 2
  },
  ["娃娃菜"] = {
    keyName = "娃娃菜",
    showName = "娃娃菜",
    icon = 14130,
    level = 3,
    unit = "份",
    type = "蔬菜",
    order = 3
  },
  ["姜"] = {
    keyName = "姜",
    showName = "姜",
    icon = 9229,
    level = 3,
    unit = "份",
    type = "其他",
    order = 4
  },
  ["玉米"] = {
    keyName = "玉米",
    showName = "玉米",
    icon = 7205,
    level = 3,
    unit = "份",
    type = "蔬菜",
    order = 5
  },
  ["花生"] = {
    keyName = "花生",
    showName = "花生",
    icon = 9225,
    level = 4,
    unit = "份",
    type = "其他",
    order = 6
  },
  ["花椒"] = {
    keyName = "花椒",
    showName = "花椒",
    icon = 9222,
    level = 4,
    unit = "份",
    type = "其他",
    order = 7
  },
  ["辣椒"] = {
    keyName = "辣椒",
    showName = "辣椒",
    icon = 7203,
    level = 4,
    unit = "份",
    type = "其他",
    order = 8
  },
  ["香菇"] = {
    keyName = "香菇",
    showName = "香菇",
    icon = 7216,
    level = 5,
    unit = "份",
    type = "蔬菜",
    order = 9
  },
  ["青菜"] = {
    keyName = "青菜",
    showName = "青菜",
    icon = 7217,
    level = 5,
    unit = "份",
    type = "蔬菜",
    order = 10
  },
  ["鸡肉"] = {
    keyName = "鸡肉",
    showName = "鸡肉",
    icon = 9235,
    level = 5,
    unit = "份",
    type = "肉类",
    order = 11
  },
  ["乳鸽"] = {
    keyName = "乳鸽",
    showName = "乳鸽",
    icon = 9236,
    level = 5,
    unit = "份",
    type = "肉类",
    order = 12
  },
  ["猪肉"] = {
    keyName = "猪肉",
    showName = "猪肉",
    icon = 9234,
    level = 6,
    unit = "份",
    type = "肉类",
    order = 13
  },
  ["梅菜"] = {
    keyName = "梅菜",
    showName = "梅菜",
    icon = 9231,
    level = 6,
    unit = "份",
    type = "蔬菜",
    order = 14
  },
  ["青椒"] = {
    keyName = "青椒",
    showName = "青椒",
    icon = 9223,
    level = 7,
    unit = "份",
    type = "其他",
    order = 15
  },
  ["蒜苗"] = {
    keyName = "蒜苗",
    showName = "蒜苗",
    icon = 9224,
    level = 7,
    unit = "份",
    type = "其他",
    order = 16
  },
  ["木耳"] = {
    keyName = "木耳",
    showName = "木耳",
    icon = 9227,
    level = 7,
    unit = "份",
    type = "蔬菜",
    order = 17
  },
  ["莴笋"] = {
    keyName = "莴笋",
    showName = "莴笋",
    icon = 9228,
    level = 7,
    unit = "份",
    type = "蔬菜",
    order = 18
  },
  ["牛肉"] = {
    keyName = "牛肉",
    showName = "牛肉",
    icon = 9237,
    level = 8,
    unit = "份",
    type = "肉类",
    order = 19
  },
  ["大白萝卜"] = {
    keyName = "大白萝卜",
    showName = "大白萝卜",
    icon = 9233,
    level = 8,
    unit = "份",
    type = "蔬菜",
    order = 20
  },
  ["八角"] = {
    keyName = "八角",
    showName = "八角",
    icon = 9230,
    level = 8,
    unit = "份",
    type = "其他",
    order = 21
  },
  ["鱼"] = {
    keyName = "鱼",
    showName = "鱼",
    icon = 9241,
    level = 8,
    unit = "份",
    type = "肉类",
    order = 22
  },
  ["西红柿"] = {
    keyName = "西红柿",
    showName = "西红柿",
    icon = 7202,
    level = 9,
    unit = "份",
    type = "蔬菜",
    order = 23
  },
  ["蟹"] = {
    keyName = "蟹",
    showName = "蟹",
    icon = 13202,
    level = 9,
    unit = "份",
    type = "肉类",
    order = 24
  },
  ["粉丝"] = {
    keyName = "粉丝",
    showName = "粉丝",
    icon = 7218,
    level = 9,
    unit = "份",
    type = "其他",
    order = 25
  },
  ["南瓜"] = {
    keyName = "南瓜",
    showName = "南瓜",
    icon = 7212,
    level = 9,
    unit = "份",
    type = "蔬菜",
    order = 26
  },
  ["小龙虾"] = {
    keyName = "小龙虾",
    showName = "小龙虾",
    icon = 9239,
    level = 10,
    unit = "份",
    type = "肉类",
    order = 27
  },
  ["海参"] = {
    keyName = "海参",
    showName = "海参",
    icon = 9238,
    level = 10,
    unit = "份",
    type = "肉类",
    order = 28
  },
  ["鲍鱼"] = {
    keyName = "鲍鱼",
    showName = "鲍鱼",
    icon = 9242,
    level = 10,
    unit = "份",
    type = "肉类",
    order = 29
  },
  ["鱼翅"] = {
    keyName = "鱼翅",
    showName = "鱼翅",
    icon = 9240,
    level = 10,
    unit = "份",
    type = "肉类",
    order = 30
  }
}
