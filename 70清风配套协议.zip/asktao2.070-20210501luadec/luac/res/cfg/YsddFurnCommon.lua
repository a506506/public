return {
  {
    class_id = 10088,
    x = 53,
    y = 39,
    dir = 0,
    cx = -11,
    cy = -3
  },
  {
    class_id = 10092,
    x = 38,
    y = 15,
    dir = 0,
    cx = 6,
    cy = 11
  },
  {
    class_id = 10055,
    x = 57,
    y = 36,
    dir = 0,
    cx = 6,
    cy = -3
  },
  {
    class_id = 10058,
    x = 67,
    y = 26,
    dir = 1,
    cx = 5,
    cy = 8
  },
  {
    class_id = 10066,
    x = 34,
    y = 31,
    dir = 1,
    cx = 5,
    cy = 3
  },
  {
    class_id = 10106,
    x = 30,
    y = 36,
    dir = 0,
    cx = -6,
    cy = 5
  },
  {
    class_id = 10046,
    x = 26,
    y = 21,
    dir = 0,
    cx = -12,
    cy = -8
  },
  {
    class_id = 10043,
    x = 47,
    y = 15,
    dir = 1,
    cx = 6,
    cy = -11
  }
}
