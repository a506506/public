return {
  {
    mapName = CHS[3001301],
    minLevel = 1,
    maxLevel = 5,
    monsterName = CHS[3001302],
    icon = 6101
  },
  {
    mapName = CHS[3001303],
    minLevel = 5,
    maxLevel = 10,
    monsterName = CHS[3001304],
    icon = 6165
  },
  {
    mapName = CHS[3001305],
    minLevel = 10,
    maxLevel = 12,
    monsterName = CHS[3001306],
    icon = 6103
  },
  {
    mapName = CHS[3001307],
    minLevel = 13,
    maxLevel = 15,
    monsterName = CHS[3001308],
    icon = 6168
  },
  {
    mapName = CHS[3001309],
    minLevel = 16,
    maxLevel = 20,
    monsterName = CHS[3001310],
    icon = 6106
  },
  {
    mapName = CHS[3001311],
    minLevel = 21,
    maxLevel = 25,
    monsterName = CHS[3001312],
    icon = 6108
  },
  {
    mapName = CHS[3001313],
    minLevel = 26,
    maxLevel = 30,
    monsterName = CHS[3001314],
    icon = 6116
  },
  {
    mapName = CHS[3001315],
    minLevel = 31,
    maxLevel = 35,
    monsterName = CHS[3001316],
    icon = 6113
  },
  {
    mapName = CHS[3001317],
    minLevel = 36,
    maxLevel = 40,
    monsterName = CHS[3001318],
    icon = 6110
  },
  {
    mapName = CHS[3001319],
    minLevel = 23,
    maxLevel = 27,
    monsterName = CHS[3001320],
    icon = 6126
  },
  {
    mapName = CHS[3001321],
    minLevel = 30,
    maxLevel = 35,
    monsterName = CHS[3001322],
    icon = 6120
  },
  {
    mapName = CHS[3001323],
    minLevel = 41,
    maxLevel = 43,
    monsterName = CHS[3001324],
    icon = 6117
  },
  {
    mapName = CHS[3001325],
    minLevel = 44,
    maxLevel = 46,
    monsterName = CHS[3001326],
    icon = 6118
  },
  {
    mapName = CHS[3001327],
    minLevel = 47,
    maxLevel = 49,
    monsterName = CHS[3001328],
    icon = 6119
  },
  {
    mapName = CHS[3001329],
    minLevel = 50,
    maxLevel = 52,
    monsterName = CHS[3001330],
    icon = 6124
  },
  {
    mapName = CHS[3001331],
    minLevel = 53,
    maxLevel = 55,
    monsterName = CHS[3001332],
    icon = 6127
  },
  {
    mapName = CHS[3001333],
    minLevel = 56,
    maxLevel = 60,
    monsterName = CHS[3001334],
    icon = 6140
  },
  {
    mapName = CHS[3001335],
    minLevel = 50,
    maxLevel = 55,
    monsterName = CHS[3001336],
    icon = 6132
  },
  {
    mapName = CHS[3001337],
    minLevel = 61,
    maxLevel = 63,
    monsterName = CHS[3001338],
    icon = 6139
  },
  {
    mapName = CHS[3001339],
    minLevel = 64,
    maxLevel = 66,
    monsterName = CHS[3001340],
    icon = 6134
  },
  {
    mapName = CHS[3001341],
    minLevel = 67,
    maxLevel = 69,
    monsterName = CHS[3001342],
    icon = 6133
  },
  {
    mapName = CHS[3001343],
    minLevel = 70,
    maxLevel = 72,
    monsterName = CHS[3001344],
    icon = 6136
  },
  {
    mapName = CHS[3001345],
    minLevel = 73,
    maxLevel = 75,
    monsterName = CHS[3001346],
    icon = 6137
  },
  {
    mapName = CHS[3001347],
    minLevel = 76,
    maxLevel = 78,
    monsterName = CHS[3001348],
    icon = 6138
  },
  {
    mapName = CHS[3001349],
    minLevel = 79,
    maxLevel = 81,
    monsterName = CHS[3001350],
    icon = 6135
  },
  {
    mapName = CHS[6000317],
    minLevel = 80,
    maxLevel = 83,
    monsterName = CHS[6000318],
    icon = 6144
  },
  {
    mapName = CHS[6000309],
    minLevel = 82,
    maxLevel = 85,
    monsterName = CHS[5440001],
    icon = 6148
  },
  {
    mapName = CHS[6000320],
    minLevel = 86,
    maxLevel = 90,
    monsterName = CHS[6000321],
    icon = 6150
  },
  {
    mapName = CHS[6000323],
    minLevel = 91,
    maxLevel = 95,
    monsterName = CHS[6000322],
    icon = 6151
  },
  {
    mapName = CHS[6000326],
    minLevel = 96,
    maxLevel = 100,
    monsterName = CHS[6000322],
    icon = 6154
  },
  {
    mapName = CHS[6000329],
    minLevel = 101,
    maxLevel = 105,
    monsterName = CHS[6000330],
    icon = 6164
  },
  {
    mapName = CHS[6000332],
    minLevel = 106,
    maxLevel = 110,
    monsterName = CHS[6000333],
    icon = 6146
  },
  {
    mapName = CHS[7002263],
    minLevel = 111,
    maxLevel = 115,
    monsterName = CHS[7002257],
    icon = 6271
  },
  {
    mapName = CHS[7002264],
    minLevel = 116,
    maxLevel = 120,
    monsterName = CHS[7002260],
    icon = 6276
  },
  {
    mapName = CHS[7002265],
    minLevel = 121,
    maxLevel = 125,
    monsterName = CHS[7002262],
    icon = 6282
  },
  {
    mapName = CHS[7190107],
    minLevel = 126,
    maxLevel = 130,
    monsterName = CHS[7190099],
    icon = 6283
  },
  {
    mapName = CHS[4101560],
    minLevel = 131,
    maxLevel = 135,
    monsterName = CHS[4101561],
    icon = 6285
  },
  {
    mapName = CHS[7190864],
    minLevel = 136,
    maxLevel = 140,
    monsterName = CHS[7190860],
    icon = 6289
  },
  {
    mapName = CHS[7190865],
    minLevel = 141,
    maxLevel = 145,
    monsterName = CHS[7190862],
    icon = 6161
  }
}
