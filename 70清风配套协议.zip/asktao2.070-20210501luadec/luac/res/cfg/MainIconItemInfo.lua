return {
  [1] = {
    name = CHS[3000777],
    dlgName = "GameFunctionDlg",
    ctrlName = "BagButton"
  },
  [2] = {
    name = CHS[3000780],
    dlgName = "GameFunctionDlg",
    ctrlName = "HideButton"
  },
  [3] = {
    name = CHS[3000791],
    dlgName = "GameFunctionDlg",
    ctrlName = "PartyButton"
  },
  [4] = {
    name = CHS[3000782],
    dlgName = "GameFunctionDlg",
    ctrlName = "ForgeButton"
  },
  [5] = {
    name = CHS[3000785],
    dlgName = "GameFunctionDlg",
    ctrlName = "GuardButton"
  },
  [6] = {
    name = CHS[3000779],
    dlgName = "GameFunctionDlg",
    ctrlName = "SystemButton"
  },
  [7] = {
    name = CHS[7002308],
    dlgName = "ChatDlg",
    ctrlName = "FriendButton"
  },
  [8] = {
    name = CHS[7002309],
    dlgName = "SystemFunctionDlg",
    ctrlName = "WorldMapButton"
  },
  [9] = {
    name = CHS[3000778],
    dlgName = "SystemFunctionDlg",
    ctrlName = "SmallMapButton"
  },
  [10] = {
    name = CHS[3000786],
    dlgName = "SystemFunctionDlg",
    ctrlName = "RankingListButton"
  },
  [11] = {
    name = CHS[3000781],
    dlgName = "SystemFunctionDlg",
    ctrlName = "MallButton"
  },
  [12] = {
    name = CHS[7002310],
    dlgName = "SystemFunctionDlg",
    ctrlName = "TradeButton"
  },
  [13] = {
    name = CHS[7002311],
    dlgName = "SystemFunctionDlg",
    ctrlName = "MarketButton"
  },
  [14] = {
    name = CHS[7002312],
    dlgName = "SystemFunctionDlg",
    ctrlName = "TreasureButton"
  },
  [15] = {
    name = CHS[3000783],
    dlgName = "SystemFunctionDlg",
    ctrlName = "GiftsButton"
  },
  [16] = {
    name = CHS[3000788],
    dlgName = "SystemFunctionDlg",
    ctrlName = "LiangongButton"
  },
  [17] = {
    name = CHS[3000789],
    dlgName = "SystemFunctionDlg",
    ctrlName = "ShuadaoButton"
  },
  [18] = {
    name = CHS[3000784],
    dlgName = "SystemFunctionDlg",
    ctrlName = "ActivityButton"
  },
  [19] = {
    name = CHS[7002313],
    dlgName = "GameFunctionDlg",
    ctrlName = "JewelryButton"
  },
  [20] = {
    name = CHS[7002314],
    dlgName = "GameFunctionDlg",
    ctrlName = "EquipButton"
  },
  [21] = {
    name = CHS[7000144],
    dlgName = "GameFunctionDlg",
    ctrlName = "ArtifactButton",
    func = "showOrHideArtifact"
  },
  [22] = {
    name = CHS[4100442],
    dlgName = "GameFunctionDlg",
    ctrlName = "WatchCenterButton"
  },
  [23] = {
    name = CHS[5400071],
    dlgName = "SystemFunctionDlg",
    ctrlName = "AnniversaryButton"
  },
  [24] = {
    name = CHS[5420154],
    dlgName = "SystemFunctionDlg",
    ctrlName = "QQButton"
  },
  [25] = {
    name = CHS[7002315],
    dlgName = "GameFunctionDlg",
    ctrlName = "HomeButton"
  },
  [26] = {
    name = CHS[3000793],
    dlgName = "SystemFunctionDlg",
    ctrlName = "PromoteButton"
  },
  [27] = {
    name = "成就",
    dlgName = "GameFunctionDlg",
    ctrlName = "AchievementButton"
  },
  [29] = {
    name = "社交",
    dlgName = "GameFunctionDlg",
    ctrlName = "SocialButton"
  },
  [30] = {
    name = "社交-微社区",
    dlgName = "SystemFunctionDlg",
    ctrlName = "CommunityButton"
  },
  [31] = {
    name = "社交-寻缘",
    dlgName = "GameFunctionDlg",
    ctrlName = "FindLoveButton"
  },
  [32] = {
    name = "社交-结婚纪念册",
    dlgName = "GameFunctionDlg",
    ctrlName = "MarryBookButton"
  },
  [33] = {
    name = "社交-师徒",
    dlgName = "GameFunctionDlg",
    ctrlName = "TeachButton"
  },
  [34] = {
    name = CHS[7190483],
    dlgName = "SystemFunctionDlg",
    ctrlName = "TradingSpotButton"
  },
  [35] = {
    name = "好声音",
    dlgName = "SystemFunctionDlg",
    ctrlName = "GoodVoiceButton"
  },
  [37] = {
    name = CHS[7190683],
    dlgName = "GameFunctionDlg",
    ctrlName = "HorcruxButton",
    func = "showOrHideHorcrux"
  },
  [36] = {
    name = "h5下载",
    dlgName = "SystemFunctionDlg",
    ctrlName = "H5DownloadButton"
  },
  [38] = {
    name = "行囊",
    dlgName = "GameFunctionDlg",
    ctrlName = "UndergroundBagButton"
  },
  [39] = {
    name = "随从",
    dlgName = "GameFunctionDlg",
    ctrlName = "UndergroundEntourageButton"
  },
  [40] = {
    name = "属性",
    dlgName = "GameFunctionDlg",
    ctrlName = "UndergroundPowerButton"
  },
  [41] = {
    name = CHS[7260042],
    dlgName = "SystemFunctionDlg",
    ctrlName = "GloryButton"
  },
  [42] = {
    name = "领取",
    dlgName = "SystemFunctionDlg",
    ctrlName = "RightButton"
  },
  [43] = {
    name = "花灯",
    dlgName = "SystemFunctionDlg",
    ctrlName = "LanternButton"
  },
  [44] = {
    name = "秘境",
    dlgName = "SystemFunctionDlg",
    ctrlName = "MiJingButton"
  },
  [45] = {
    name = "烟花",
    dlgName = "SystemFunctionDlg",
    ctrlName = "FireWorksButton"
  },
  [46] = {
    name = "妙音电台",
    dlgName = "GameFunctionDlg",
    ctrlName = "MiaoYRadioButton",
    func = "showOrHideMiaoY"
  },
  [47] = {
    name = "附灵",
    dlgName = "GameFunctionDlg",
    ctrlName = "SpiritButton"
  },
  [48] = {
    name = "食神季",
    dlgName = "SystemFunctionDlg",
    ctrlName = "CookButton"
  },
  [49] = {
    name = "天宫",
    dlgName = "GameFunctionDlg",
    ctrlName = "TianGongButton"
  },
  [50] = {
    name = "锦鲤",
    dlgName = "SystemFunctionDlg",
    ctrlName = "LuckyFishButton"
  },
  [10001] = {
    name = "成长秘籍",
    dlgName = "GameFunctionDlg",
    ctrlName = "BattlePassButton"
  }
}
