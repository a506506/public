return {
  [21000] = {
    type = "armature",
    icon = 1144,
    x = 0,
    y = 0,
    action = "Top"
  }
}
