return {
  {
    class_id = 10052,
    x = 17,
    y = 29,
    dir = 11,
    cx = 5,
    cy = 12
  },
  {
    class_id = 10088,
    x = 38,
    y = 39,
    dir = 0,
    cx = -8,
    cy = 6
  },
  {
    class_id = 10058,
    x = 68,
    y = 27,
    dir = 1,
    cx = 8,
    cy = 11
  },
  {
    class_id = 10066,
    x = 48,
    y = 36,
    dir = 1,
    cx = -9,
    cy = -8
  },
  {
    class_id = 10062,
    x = 58,
    y = 34,
    dir = 0,
    cx = 5,
    cy = 1
  },
  {
    class_id = 10052,
    x = 55,
    y = 31,
    dir = 15,
    cx = -3,
    cy = 1
  },
  {
    class_id = 10052,
    x = 62,
    y = 35,
    dir = 11,
    cx = -9,
    cy = -10
  },
  {
    class_id = 10049,
    x = 49,
    y = 16,
    dir = 1,
    cx = 10,
    cy = 8
  },
  {
    class_id = 10076,
    x = 21,
    y = 25,
    dir = 0,
    cx = -10,
    cy = 0
  },
  {
    class_id = 10043,
    x = 41,
    y = 16,
    dir = 0,
    cx = -6,
    cy = 12
  },
  {
    class_id = 10066,
    x = 50,
    y = 19,
    dir = 0,
    cx = 11,
    cy = 2
  },
  {
    class_id = 10079,
    x = 28,
    y = 23,
    dir = 1,
    cx = -6,
    cy = -1
  },
  {
    class_id = 10066,
    x = 35,
    y = 19,
    dir = 1,
    cx = 0,
    cy = -3
  },
  {
    class_id = 10066,
    x = 35,
    y = 36,
    dir = 0,
    cx = 9,
    cy = 10
  },
  {
    class_id = 10070,
    x = 42,
    y = 41,
    dir = 0,
    cx = -9,
    cy = 1
  },
  {
    class_id = 10107,
    x = 42,
    y = 41,
    dir = 0,
    cx = -1,
    cy = -11
  },
  {
    class_id = 10095,
    x = 15,
    y = 22,
    dir = 0,
    cx = -12,
    cy = 6
  },
  {
    class_id = 10095,
    x = 27,
    y = 16,
    dir = 0,
    cx = -10,
    cy = 10
  },
  {
    class_id = 10095,
    x = 38,
    y = 10,
    dir = 0,
    cx = 3,
    cy = 3
  },
  {
    class_id = 10095,
    x = 49,
    y = 10,
    dir = 1,
    cx = -2,
    cy = 3
  },
  {
    class_id = 10095,
    x = 73,
    y = 22,
    dir = 1,
    cx = -7,
    cy = 7
  },
  {
    class_id = 10105,
    x = 69,
    y = 20,
    dir = 1,
    cx = -2,
    cy = 1
  },
  {
    class_id = 10100,
    x = 23,
    y = 18,
    dir = 0,
    cx = -6,
    cy = 1
  },
  {
    class_id = 10055,
    x = 15,
    y = 26,
    dir = 0,
    cx = 6,
    cy = 6
  }
}
