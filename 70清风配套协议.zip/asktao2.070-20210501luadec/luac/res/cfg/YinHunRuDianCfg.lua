return {
  Ghost = {
    {
      name = CHS[7190755],
      icon = 6049,
      desc = CHS[7190761],
      tips = CHS[7190783]
    },
    {
      name = CHS[7190756],
      icon = 6035,
      desc = CHS[7190762],
      tips = CHS[7190784]
    },
    {
      name = CHS[7190757],
      icon = 6229,
      desc = CHS[7190763],
      tips = CHS[7190785]
    },
    {
      name = CHS[7190758],
      icon = 6017,
      desc = CHS[7190764],
      tips = CHS[7190786]
    },
    {
      name = CHS[7190759],
      icon = 6012,
      desc = CHS[7190765],
      tips = CHS[7190787]
    },
    {
      name = CHS[7190760],
      icon = 6202,
      desc = CHS[7190766],
      tips = CHS[7190788]
    }
  },
  CardInfo = {
    {
      name = CHS[7190793],
      desc = CHS[7190798]
    },
    {
      name = CHS[7190794],
      desc = CHS[7190799]
    },
    {
      name = CHS[7190795],
      desc = CHS[7190800]
    },
    {
      name = CHS[7190796],
      desc = CHS[7190801]
    },
    {
      name = CHS[7190797],
      desc = CHS[7190802]
    }
  },
  MapItem = {
    {
      name = CHS[7190819],
      desc = CHS[7190835],
      tips = CHS[7190803],
      getItem = true
    },
    {
      name = CHS[7190820],
      desc = CHS[7190836],
      tips = CHS[7190804],
      getItem = true
    },
    {
      name = CHS[7190821],
      desc = CHS[7190837],
      tips = CHS[7190805],
      getItem = true
    },
    {
      name = CHS[7190822],
      desc = CHS[7190838],
      tips = CHS[7190806],
      getItem = true
    },
    {
      name = CHS[7190823],
      desc = CHS[7190839],
      tips = CHS[7190807]
    },
    {
      name = CHS[7190824],
      desc = CHS[7190840],
      tips = CHS[7190808]
    },
    {
      name = CHS[7190825],
      desc = CHS[7190841],
      tips = CHS[7190809]
    },
    {
      name = CHS[7190826],
      desc = CHS[7190842],
      tips = CHS[7190810]
    },
    {
      name = CHS[7190827],
      desc = CHS[7190843],
      tips = CHS[7190811]
    },
    {
      name = CHS[7190828],
      desc = CHS[7190844],
      tips = CHS[7190812]
    },
    {
      name = CHS[7190829],
      desc = CHS[7190845],
      tips = CHS[7190813]
    },
    {
      name = CHS[7190830],
      desc = CHS[7190846],
      tips = CHS[7190814]
    },
    {
      name = CHS[7190831],
      desc = CHS[7190847],
      tips = CHS[7190815]
    },
    {
      name = CHS[7190832],
      desc = CHS[7190848],
      tips = CHS[7190816]
    },
    {
      name = CHS[7190833],
      desc = CHS[7190849],
      tips = CHS[7190817]
    },
    {
      name = CHS[7190834],
      desc = CHS[7190850],
      tips = CHS[7190818],
      getItem = true
    }
  },
  RewardPos = {
    20,
    40,
    60,
    80
  },
  MapPos = {
    {
      x = 2106,
      y = 1174,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2040,
      y = 1142,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1969,
      y = 1108,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1900,
      y = 1074,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1832,
      y = 1040,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1898,
      y = 1006,
      dir = 3,
      fixDir = 7
    },
    {
      x = 1968,
      y = 972,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2038,
      y = 935,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2109,
      y = 902,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2178,
      y = 865,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2247,
      y = 829,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2177,
      y = 793,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2106,
      y = 759,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2176,
      y = 725,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2246,
      y = 689,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2314,
      y = 722,
      dir = 5,
      fixDir = 1
    },
    {
      x = 2384,
      y = 755,
      dir = 5,
      fixDir = 1
    },
    {
      x = 2459,
      y = 794,
      dir = 5,
      fixDir = 1
    },
    {
      x = 2528,
      y = 828,
      dir = 5,
      fixDir = 1
    },
    {
      x = 2597,
      y = 795,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2664,
      y = 759,
      dir = 3,
      fixDir = 7
    },
    {
      x = 2593,
      y = 724,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2521,
      y = 686,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2449,
      y = 654,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2382,
      y = 618,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2312,
      y = 583,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2242,
      y = 550,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2176,
      y = 517,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2111,
      y = 484,
      dir = 1,
      fixDir = 5
    },
    {
      x = 2039,
      y = 446,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1971,
      y = 412,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1901,
      y = 376,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1830,
      y = 340,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1758,
      y = 304,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1688,
      y = 269,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1620,
      y = 233,
      dir = 1,
      fixDir = 5
    },
    {
      x = 1369,
      y = 366,
      dir = 7,
      fixDir = 3
    },
    {
      x = 1299,
      y = 400,
      dir = 7,
      fixDir = 3
    },
    {
      x = 1228,
      y = 436,
      dir = 7,
      fixDir = 3
    },
    {
      x = 1155,
      y = 472,
      dir = 7,
      fixDir = 3
    },
    {
      x = 1225,
      y = 508,
      dir = 5,
      fixDir = 1
    },
    {
      x = 1294,
      y = 543,
      dir = 5,
      fixDir = 1
    },
    {
      x = 1224,
      y = 578,
      dir = 7,
      fixDir = 3
    },
    {
      x = 1152,
      y = 612,
      dir = 7,
      fixDir = 3
    },
    {
      x = 1082,
      y = 648,
      dir = 7,
      fixDir = 3
    },
    {
      x = 1014,
      y = 613,
      dir = 1,
      fixDir = 5
    },
    {
      x = 946,
      y = 580,
      dir = 1,
      fixDir = 5
    },
    {
      x = 878,
      y = 546,
      dir = 1,
      fixDir = 5
    },
    {
      x = 810,
      y = 512,
      dir = 1,
      fixDir = 5
    },
    {
      x = 738,
      y = 476,
      dir = 1,
      fixDir = 5
    },
    {
      x = 666,
      y = 440,
      dir = 1,
      fixDir = 5
    },
    {
      x = 596,
      y = 404,
      dir = 1,
      fixDir = 5
    },
    {
      x = 524,
      y = 440,
      dir = 7,
      fixDir = 3
    },
    {
      x = 453,
      y = 477,
      dir = 7,
      fixDir = 3
    },
    {
      x = 381,
      y = 512,
      dir = 7,
      fixDir = 3
    },
    {
      x = 312,
      y = 549,
      dir = 7,
      fixDir = 3
    },
    {
      x = 245,
      y = 580,
      dir = 7,
      fixDir = 3
    },
    {
      x = 177,
      y = 615,
      dir = 7,
      fixDir = 3
    },
    {
      x = 250,
      y = 652,
      dir = 5,
      fixDir = 1
    },
    {
      x = 324,
      y = 688,
      dir = 5,
      fixDir = 1
    },
    {
      x = 391,
      y = 721,
      dir = 5,
      fixDir = 1
    },
    {
      x = 458,
      y = 754,
      dir = 5,
      fixDir = 1
    },
    {
      x = 527,
      y = 719,
      dir = 3,
      fixDir = 7
    },
    {
      x = 594,
      y = 686,
      dir = 3,
      fixDir = 7
    },
    {
      x = 665,
      y = 719,
      dir = 5,
      fixDir = 1
    },
    {
      x = 732,
      y = 754,
      dir = 5,
      fixDir = 1
    },
    {
      x = 804,
      y = 788,
      dir = 5,
      fixDir = 1
    },
    {
      x = 875,
      y = 824,
      dir = 5,
      fixDir = 1
    },
    {
      x = 945,
      y = 859,
      dir = 5,
      fixDir = 1
    },
    {
      x = 875,
      y = 894,
      dir = 7,
      fixDir = 3
    },
    {
      x = 804,
      y = 931,
      dir = 7,
      fixDir = 3
    },
    {
      x = 736,
      y = 965,
      dir = 7,
      fixDir = 3
    },
    {
      x = 663,
      y = 1002,
      dir = 7,
      fixDir = 3
    },
    {
      x = 736,
      y = 1036,
      dir = 5,
      fixDir = 1
    },
    {
      x = 806,
      y = 1072,
      dir = 5,
      fixDir = 1
    },
    {
      x = 878,
      y = 1104,
      dir = 5,
      fixDir = 1
    },
    {
      x = 947,
      y = 1141,
      dir = 5,
      fixDir = 1
    },
    {
      x = 1016,
      y = 1104,
      dir = 3,
      fixDir = 7
    },
    {
      x = 1085,
      y = 1070,
      dir = 3,
      fixDir = 7
    },
    {
      x = 1154,
      y = 1036,
      dir = 3,
      fixDir = 7
    }
  }
}
