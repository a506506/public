return {
  [1000] = {
    map_name = CHS[3000794],
    map_id = 1000,
    teleport_x = 86,
    teleport_y = 85,
    npc = {
      {
        name = CHS[3000795],
        x = 38,
        y = 108,
        icon = 6010,
        isYell = true
      },
      {
        name = CHS[3000796],
        x = 92,
        y = 116,
        icon = 6018,
        isYell = true
      },
      {
        name = CHS[3000797],
        x = 123,
        y = 114,
        icon = 6019,
        isYell = true
      },
      {
        name = CHS[3000798],
        x = 100,
        y = 97,
        icon = 6016,
        isYell = true
      },
      {
        name = CHS[3000799],
        x = 54,
        y = 69,
        icon = 6012,
        isYell = true
      },
      {
        name = CHS[3000800],
        x = 71,
        y = 117,
        icon = 6011,
        isYell = true,
        funcLogo = CHS[7270000]
      },
      {
        name = CHS[3000801],
        x = 97,
        y = 51,
        icon = 6015,
        isYell = true,
        funcLogo = CHS[7270003]
      },
      {
        name = CHS[3000802],
        x = 123,
        y = 68,
        icon = 6014,
        isYell = true
      },
      {
        name = CHS[3000803],
        x = 14,
        y = 57,
        icon = 6013,
        isYell = true
      },
      {
        name = CHS[3000804],
        x = 116,
        y = 21,
        icon = 6059,
        isYell = true,
        funcLogo = CHS[7270013]
      },
      {
        name = CHS[3000805],
        x = 37,
        y = 26,
        icon = 6058,
        isYell = true
      },
      {
        name = CHS[3000806],
        x = 140,
        y = 9,
        icon = 6047,
        isYell = true,
        funcLogo = CHS[7270014]
      },
      {
        name = "小岚",
        x = 14,
        y = 100,
        icon = 51526,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "小水",
        x = 10,
        y = 102,
        icon = 51525,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[5420029],
        x = 86,
        y = 84,
        icon = 51501,
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    exit_level = {
      [CHS[3000807]] = "15~20",
      [CHS[3000808]] = "30~50"
    },
    monster_level = 0
  },
  [1001] = {
    map_name = CHS[7190282],
    map_id = 1000,
    teleport_x = 86,
    teleport_y = 85,
    npc = {
      {
        name = CHS[7100365],
        x = 92,
        y = 116,
        icon = 6018,
        offsetPos = {x = 25, y = 7}
      },
      {
        name = CHS[7100364],
        x = 89,
        y = 119,
        icon = 6043,
        offsetPos = {x = 15, y = 0}
      },
      {
        name = CHS[7100366],
        x = 75,
        y = 120,
        icon = 6013
      },
      {
        name = CHS[7100367],
        x = 54,
        y = 69,
        icon = 6012
      },
      {
        name = CHS[7100368],
        x = 96,
        y = 99,
        icon = 51513
      },
      {
        name = CHS[7100369],
        x = 8,
        y = 60,
        icon = 6087
      },
      {
        name = CHS[7100370],
        x = 91,
        y = 51,
        icon = 6035
      },
      {
        name = CHS[7100371] .. "2",
        x = 121,
        y = 69,
        icon = 6011,
        alias = CHS[7100371]
      },
      {
        name = CHS[7100372],
        x = 37,
        y = 26,
        icon = 20062
      },
      {
        name = CHS[7100373],
        x = 38,
        y = 108,
        icon = 6042
      }
    },
    monster_level = 0,
    unmatch_team = true,
    unswitch_line = true,
    notShowExitInSmallMap = true,
    notDrawTeam = true
  },
  [1003] = {
    map_name = "童真幻境",
    map_id = 1000,
    teleport_x = 86,
    teleport_y = 85,
    npc = {
      {
        name = "",
        x = 86,
        y = 84,
        icon = 6035,
        offsetPos = {x = 0, y = -20}
      }
    },
    monster_level = 0,
    unmatch_team = true,
    unswitch_line = true,
    notShowExitInSmallMap = true,
    sendMoveInterval = 0.3
  },
  [1002] = {
    map_name = "聚仙镇",
    map_id = 1000,
    teleport_x = 86,
    teleport_y = 85,
    npc = {
      {
        name = "村长",
        x = 37,
        y = 26,
        icon = 6035
      },
      {
        name = "朱家伙计",
        x = 97,
        y = 51,
        icon = 6017
      },
      {
        name = "赵家伙计",
        x = 71,
        y = 117,
        icon = 6017
      }
    },
    monster_level = 0,
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true
  },
  [1004] = {
    map_name = "青竹镇",
    map_id = 1000,
    teleport_x = 86,
    teleport_y = 85,
    npc = {
      {
        name = "王掌柜",
        x = 123,
        y = 68,
        icon = 6015
      },
      {
        name = "客栈旁的乞丐",
        x = 95,
        y = 89,
        icon = 6048
      },
      {
        name = "张屠夫",
        x = 71,
        y = 117,
        icon = 6012
      },
      {
        name = "员外的邻居",
        x = 93,
        y = 16,
        icon = 6035,
        serverShow = true
      },
      {
        name = "陈父",
        x = 21,
        y = 100,
        icon = 6016
      }
    },
    monster_level = 0,
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true
  },
  [2000] = {
    map_name = CHS[3000808],
    map_id = 2000,
    teleport_x = 34,
    teleport_y = 28,
    npc = {},
    monster_level = 2
  },
  [3000] = {
    map_name = CHS[3000809],
    map_id = 3000,
    teleport_x = 19,
    teleport_y = 31,
    npc = {
      {
        name = CHS[3000810],
        x = 14,
        y = 20,
        icon = 6191
      },
      {
        name = CHS[3000811],
        x = 51,
        y = 8,
        icon = 6042
      },
      {
        name = CHS[3000812],
        x = 51,
        y = 22,
        icon = 6041
      }
    },
    monster_level = 7
  },
  [3001] = {
    map_name = CHS[4100427],
    map_id = 3000,
    teleport_x = 19,
    teleport_y = 31,
    npc = {
      {
        name = CHS[4100428],
        x = 42,
        y = 11,
        icon = 6065
      }
    },
    monster_level = 0
  },
  [4000] = {
    map_name = CHS[3000807],
    map_id = 4000,
    teleport_x = 42,
    teleport_y = 37,
    npc = {},
    monster_level = 10
  },
  [24000] = {
    map_name = CHS[3000813],
    map_id = 24000,
    teleport_x = 35,
    teleport_y = 24,
    npc = {},
    monster_level = 13
  },
  [24001] = {
    map_name = CHS[4200140],
    map_id = 24000,
    teleport_x = 35,
    teleport_y = 24,
    npc = {
      {
        name = "吕洞宾2",
        x = 23,
        y = 13,
        icon = 20006,
        alias = "吕洞宾"
      },
      {
        name = CHS[4200141],
        x = 14,
        y = 37,
        icon = 6260
      }
    },
    monster_level = 13
  },
  [24002] = {
    map_name = CHS[4100430],
    map_id = 24000,
    teleport_x = 35,
    teleport_y = 24,
    npc = {
      {
        name = CHS[4100431],
        x = 49,
        y = 18,
        icon = 6230
      }
    },
    monster_level = 13
  },
  [5000] = {
    map_name = CHS[3000814],
    map_id = 5000,
    teleport_x = 95,
    teleport_y = 64,
    npc = {
      {
        name = CHS[3000815],
        x = 194,
        y = 52,
        icon = 6058,
        isYell = true
      },
      {
        name = CHS[3000816],
        x = 165,
        y = 60,
        icon = 6031,
        offsetPos = {x = 0, y = 33},
        isYell = true
      },
      {
        name = CHS[3000817],
        x = 22,
        y = 136,
        icon = 6042,
        isYell = true
      },
      {
        name = CHS[3000818],
        x = 127,
        y = 119,
        icon = 6010,
        isYell = true
      },
      {
        name = CHS[3000819],
        x = 138,
        y = 13,
        icon = 6223,
        isYell = true
      },
      {
        name = CHS[3000820],
        x = 114,
        y = 16,
        icon = 6047,
        isYell = true
      },
      {
        name = CHS[3000821],
        x = 20,
        y = 46,
        icon = 6033,
        isYell = true
      },
      {
        name = CHS[3000822],
        x = 132,
        y = 48,
        icon = 6043,
        isYell = true
      },
      {
        name = CHS[3000823],
        x = 109,
        y = 75,
        icon = 6236,
        isYell = true
      },
      {
        name = CHS[3000824],
        x = 89,
        y = 94,
        icon = 6014,
        isYell = true
      },
      {
        name = CHS[3000825],
        x = 139,
        y = 39,
        icon = 6011,
        isYell = true,
        funcLogo = CHS[7270000]
      },
      {
        name = CHS[3000826],
        x = 146,
        y = 74,
        icon = 6012,
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2522.png"
        },
        isYell = true,
        funcLogo = CHS[7270001]
      },
      {
        name = CHS[3000827],
        x = 119,
        y = 50,
        icon = 6013,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = CHS[3000828],
        x = 107,
        y = 113,
        icon = 6016,
        offsetPos = {x = -15, y = 0},
        isYell = true,
        funcLogo = CHS[7270002]
      },
      {
        name = "杂货店老板1",
        x = 76,
        y = 26,
        icon = 6015,
        offsetPos = {x = 0, y = -2},
        alias = "杂货店老板",
        isYell = true,
        funcLogo = CHS[7270003]
      },
      {
        name = CHS[3000830],
        x = 41,
        y = 72,
        icon = 6039,
        isYell = true
      },
      {
        name = CHS[3000831],
        x = 43,
        y = 81,
        icon = 6040,
        offsetPos = {x = -15, y = 0},
        isYell = true
      },
      {
        name = CHS[3000832],
        x = 9,
        y = 66,
        icon = 6240,
        isYell = true
      },
      {
        name = CHS[3000833],
        x = 57,
        y = 79,
        icon = 6058,
        isYell = true
      },
      {
        name = "妙音仙子",
        x = 91,
        y = 50,
        icon = 20072,
        offsetPos = {x = 0, y = -3},
        inTestDist = true,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = CHS[3000835],
        x = 55,
        y = 27,
        icon = 6175,
        offsetPos = {x = -10, y = 0},
        headTitle = {
          classIcon = "ui/Icon2180.png",
          wordIcon = "ui/Icon2185.png"
        },
        isYell = true,
        funcLogo = CHS[7270004]
      },
      {
        name = CHS[3000836],
        x = 83,
        y = 46,
        icon = 6035,
        offsetPos = {x = 0, y = 3},
        headTitle = {
          classIcon = "ui/Icon2180.png",
          wordIcon = "ui/Icon2184.png"
        },
        isYell = true,
        funcLogo = CHS[7270004]
      },
      {
        name = CHS[3000838],
        x = 70,
        y = 97,
        icon = 6057,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = CHS[3000840],
        x = 135,
        y = 81,
        icon = 6043,
        isYell = true
      },
      {
        name = CHS[3000842],
        x = 44,
        y = 136,
        icon = 6032,
        isYell = true
      },
      {
        name = CHS[3000843],
        x = 55,
        y = 10,
        icon = 6213,
        notInSmallMap = true
      },
      {
        name = CHS[3000845],
        x = 90,
        y = 22,
        icon = 6059,
        offsetPos = {x = 5, y = 2},
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2186.png"
        },
        isYell = true,
        funcLogo = CHS[7270005]
      },
      {
        name = "妙手道人",
        x = 23,
        y = 116,
        icon = 6058,
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2192.png"
        },
        isYell = true,
        funcLogo = CHS[7270007]
      },
      {
        name = "灵兽异人2",
        x = 113,
        y = 120,
        icon = 6041,
        offsetPos = {x = -15, y = -3},
        alias = "灵兽异人",
        isYell = true
      },
      {
        name = CHS[3000848],
        x = 46,
        y = 28,
        icon = 6042,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = CHS[3000849],
        x = 15,
        y = 54,
        icon = 6231,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = CHS[3000850],
        x = 152,
        y = 20,
        icon = 6012,
        isYell = true
      },
      {
        name = "船夫8",
        x = 88,
        y = 134,
        icon = 6044,
        notInSmallMap = true,
        alias = "船夫",
        isYell = true
      },
      {
        name = "神算子",
        x = 138,
        y = 111,
        icon = 6091,
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2193.png"
        },
        isYell = true,
        funcLogo = CHS[7270008]
      },
      {
        name = CHS[3000853],
        x = 6,
        y = 80,
        icon = 6049,
        offsetPos = {x = 8, y = 0},
        isYell = true
      },
      {
        name = CHS[3000854],
        x = 93,
        y = 10,
        icon = 6057,
        isYell = true,
        funcLogo = CHS[7270009]
      },
      {
        name = CHS[8000002],
        x = 188,
        y = 37,
        icon = 6048,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = CHS[8000003],
        x = 67,
        y = 35,
        icon = 6048,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = CHS[8000004],
        x = 148,
        y = 38,
        icon = 6048,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = "守城士兵2",
        x = 199,
        y = 119,
        icon = 6050,
        notInSmallMap = true,
        alias = "守城士兵"
      },
      {
        name = "守城士兵1",
        x = 31,
        y = 22,
        icon = 6050,
        notInSmallMap = true,
        alias = "守城士兵"
      },
      {
        name = "竞技使者",
        x = 176,
        y = 105,
        icon = 6036,
        isYell = true
      },
      {
        name = CHS[5100015],
        x = 159,
        y = 96,
        icon = 6059,
        isYell = true
      },
      {
        name = "镇魔道人",
        x = 159,
        y = 96,
        icon = 6042,
        isYell = true
      },
      {
        name = "红娘",
        x = 161,
        y = 121,
        icon = 6087,
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2189.png"
        },
        isYell = true,
        funcLogo = CHS[7270006]
      },
      {
        name = CHS[4100400],
        x = 168,
        y = 86,
        icon = 6036,
        isYell = true
      },
      {
        name = CHS[4200206],
        x = 78,
        y = 101,
        icon = 6038,
        inTestDist = true
      },
      {
        name = "物资管理员",
        x = 182,
        y = 93,
        icon = 6014,
        npcShowFunc = "showInNSZB"
      },
      {
        name = "郝艾佳",
        x = 185,
        y = 133,
        icon = 6013,
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2188.png"
        },
        isYell = true
      },
      {
        name = "问卷调查专员",
        x = 100,
        y = 88,
        icon = 6020,
        notInSmallMap = true,
        isYell = true
      },
      {
        name = "跨服赛事接引人",
        x = 176,
        y = 60,
        icon = 6236,
        isYell = true
      },
      {
        name = "林更新",
        x = 100,
        y = 55,
        icon = 21031,
        npcShowFunc = "showTimeLimit",
        beginShowTime = "20210430050000",
        isYell = true
      },
      {
        name = CHS[6000291],
        x = 107,
        y = 58,
        icon = 6108,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[6000295],
        x = 107,
        y = 58,
        icon = 6103,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[6000303],
        x = 107,
        y = 58,
        icon = 6187,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[6000393],
        x = 79,
        y = 58,
        icon = 6227,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[4200172],
        x = 107,
        y = 58,
        icon = 6135,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[4200173],
        x = 112,
        y = 58,
        icon = 6182,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[7000172],
        x = 111,
        y = 63,
        icon = 20122,
        shadow = "christmas_tree_shadow",
        shadow_x = -42,
        shadow_y = -21,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[7000173],
        x = 80,
        y = 64,
        icon = 20122,
        shadow = "christmas_tree_shadow",
        shadow_x = -42,
        shadow_y = -21,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[5450068],
        x = 84,
        y = 55,
        icon = 20122,
        shadow = "christmas_tree_shadow",
        shadow_x = -42,
        shadow_y = -21,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = CHS[7000174],
        x = 91,
        y = 57,
        icon = 30001,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "粽仙",
        x = 106,
        y = 58,
        icon = 20010,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "周年蛋糕",
        x = 84,
        y = 58,
        icon = 20122,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "周年花篮",
        x = 88,
        y = 55,
        icon = 20124,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "楼兰特使",
        x = 100,
        y = 55,
        icon = 6031,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "四海升平钟",
        x = 84,
        y = 58,
        icon = 20123,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "甜粽党代表",
        x = 188,
        y = 105,
        icon = 861202,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "咸粽党代表",
        x = 194,
        y = 102,
        icon = 861202,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "仙池姐姐",
        x = 96,
        y = 53,
        icon = 20071,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "俏皮鬼",
        x = 107,
        y = 59,
        icon = 6240,
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 0
  },
  [5006] = {
    map_name = "决斗场",
    map_id = 5000,
    map_obstacle_id = 5006,
    teleport_x = 169,
    teleport_y = 95,
    range = {
      x1 = 3768,
      x2 = 80,
      y1 = 1752,
      y2 = 1064
    },
    npc = {
      {
        name = "夏总兵2",
        x = 195,
        y = 80,
        icon = 6031,
        alias = "夏总兵"
      }
    },
    monster_level = 0
  },
  [5015] = {
    map_name = CHS[7000063],
    map_id = 5015,
    teleport_x = 19,
    teleport_y = 30,
    npc = {
      {
        name = CHS[7000064],
        x = 39,
        y = 27,
        icon = 6050
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [6000] = {
    map_name = CHS[3000860],
    map_id = 6000,
    teleport_x = 41,
    teleport_y = 31,
    npc = {},
    monster_level = 17
  },
  [7000] = {
    map_name = CHS[3000861],
    map_id = 7000,
    teleport_x = 28,
    teleport_y = 25,
    npc = {
      {
        name = "送子娘娘",
        x = 12,
        y = 35,
        icon = 6193,
        funcLogo = CHS[7270010]
      },
      {
        name = CHS[3000862],
        x = 38,
        y = 16,
        icon = 6205
      },
      {
        name = CHS[3000863],
        x = 6,
        y = 45,
        icon = 6019
      },
      {
        name = CHS[3000864],
        x = 25,
        y = 15,
        icon = 6192
      },
      {
        name = "月老",
        x = 50,
        y = 15,
        icon = 6060,
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2190.png"
        }
      },
      {
        name = "云游大仙1",
        x = 17,
        y = 8,
        icon = 6043,
        alias = "云游大仙"
      },
      {
        name = "云游大仙2",
        x = 6,
        y = 8,
        icon = 6043,
        alias = "云游大仙"
      },
      {
        name = "云游大仙3",
        x = 10,
        y = 15,
        icon = 6043,
        alias = "云游大仙"
      },
      {
        name = "童童",
        x = 25,
        y = 16,
        icon = 51502,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "薛之谦1",
        x = 26,
        y = 16,
        icon = 51502,
        notInSmallMap = true,
        isActiveNPC = true,
        alias = "薛之谦"
      }
    },
    monster_level = 0
  },
  [17001] = {
    map_name = "无名仙境",
    map_id = 17000,
    teleport_x = 31,
    teleport_y = 52,
    npc = {
      {
        name = "活动大使1",
        x = 78,
        y = 52,
        icon = 6236,
        alias = "活动大使"
      }
    },
    monster_level = 51
  },
  [8000] = {
    map_name = CHS[3000867],
    map_id = 8000,
    teleport_x = 24,
    teleport_y = 30,
    npc = {
      {
        name = CHS[3000868],
        x = 62,
        y = 44,
        icon = 6086
      },
      {
        name = "无想僧",
        x = 51,
        y = 45,
        icon = 6089,
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2187.png"
        }
      },
      {
        name = "无意僧",
        x = 65,
        y = 38,
        icon = 6089,
        headTitle = {
          classIcon = "ui/Icon2182.png",
          wordIcon = "ui/Icon2289.png"
        }
      },
      {
        name = CHS[3000870],
        x = 68,
        y = 16,
        icon = 6089
      },
      {
        name = "车夫2",
        x = 34,
        y = 46,
        icon = 6045,
        alias = "车夫"
      },
      {
        name = CHS[7003025],
        x = 23,
        y = 21,
        icon = 6042,
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 22
  },
  [8100] = {
    map_name = CHS[3000872],
    map_id = 8100,
    teleport_x = 41,
    teleport_y = 41,
    npc = {},
    monster_level = 27,
    hide_fly_fog = true
  },
  [8200] = {
    map_name = CHS[3000873],
    map_id = 8200,
    teleport_x = 59,
    teleport_y = 38,
    npc = {},
    monster_level = 32,
    hide_fly_fog = true
  },
  [8300] = {
    map_name = CHS[3000874],
    map_id = 8300,
    teleport_x = 25,
    teleport_y = 37,
    npc = {},
    monster_level = 37,
    hide_fly_fog = true
  },
  [9000] = {
    map_name = CHS[3000875],
    map_id = 9000,
    teleport_x = 25,
    teleport_y = 29,
    npc = {},
    monster_level = 25
  },
  [9001] = {
    map_name = CHS[4000381],
    map_id = 9000,
    teleport_x = 25,
    teleport_y = 29,
    npc = {
      {
        name = "韩湘子1",
        x = 24,
        y = 11,
        icon = 20008,
        alias = "韩湘子"
      },
      {
        name = CHS[4000393],
        x = 59,
        y = 31,
        icon = 6066
      },
      {
        name = CHS[4000394],
        x = 47,
        y = 6,
        icon = 20062
      }
    },
    monster_level = 25
  },
  [9003] = {
    map_name = CHS[7002022],
    map_id = 9000,
    teleport_x = 25,
    teleport_y = 29,
    npc = {
      {
        name = CHS[7002025],
        x = 58,
        y = 27,
        icon = 6047
      },
      {
        name = "何仙姑2",
        x = 32,
        y = 29,
        icon = 20010,
        alias = "何仙姑"
      },
      {
        name = "曹国舅2",
        x = 30,
        y = 32,
        icon = 20011,
        alias = "曹国舅"
      }
    },
    monster_level = 0
  },
  [10000] = {
    map_name = "五龙山",
    map_id = 10000,
    teleport_x = 43,
    teleport_y = 22,
    npc = {
      {
        name = CHS[3000877],
        x = 51,
        y = 18,
        icon = 6232
      },
      {
        name = CHS[3000878],
        x = 30,
        y = 28,
        icon = 6190
      },
      {
        name = CHS[3000879],
        x = 51,
        y = 37,
        icon = 6001
      },
      {
        name = "接引道童1",
        x = 43,
        y = 15,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "接引道童"
      }
    },
    monster_level = 35
  },
  [10001] = {
    map_name = CHS[3000880],
    map_id = 10001,
    teleport_x = 24,
    teleport_y = 25,
    npc = {
      {
        name = CHS[3000881],
        x = 18,
        y = 12,
        icon = 6052
      },
      {
        name = CHS[3000882],
        x = 19,
        y = 27,
        icon = 6020
      },
      {
        name = CHS[3000883],
        x = 40,
        y = 14,
        icon = 20033
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [10100] = {
    map_name = CHS[3000884],
    map_id = 10100,
    teleport_x = 64,
    teleport_y = 34,
    npc = {},
    monster_level = 42,
    hide_fly_fog = true
  },
  [10101] = {
    map_name = CHS[7003008],
    map_id = 10100,
    teleport_x = 64,
    teleport_y = 34,
    npc = {
      {
        name = CHS[7003012],
        x = 59,
        y = 7,
        icon = 6128
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [10200] = {
    map_name = CHS[3000885],
    map_id = 10200,
    teleport_x = 21,
    teleport_y = 34,
    npc = {},
    monster_level = 45,
    hide_fly_fog = true
  },
  [10300] = {
    map_name = CHS[3000886],
    map_id = 10300,
    teleport_x = 36,
    teleport_y = 39,
    npc = {},
    monster_level = 48,
    hide_fly_fog = true
  },
  [10400] = {
    map_name = CHS[3000887],
    map_id = 10400,
    teleport_x = 8,
    teleport_y = 23,
    npc = {},
    monster_level = 51,
    npc = {
      {
        name = CHS[3000888],
        x = 65,
        y = 55,
        icon = 6003
      }
    },
    hide_fly_fog = true
  },
  [10500] = {
    map_name = CHS[3000889],
    map_id = 10500,
    teleport_x = 25,
    teleport_y = 26,
    npc = {},
    monster_level = 54,
    npc = {
      {
        name = CHS[3000890],
        x = 22,
        y = 20,
        icon = 6003
      }
    },
    hide_fly_fog = true
  },
  [11000] = {
    map_name = CHS[3000891],
    map_id = 11000,
    teleport_x = 64,
    teleport_y = 77,
    npc = {
      {
        name = "船夫1",
        x = 88,
        y = 97,
        icon = 6044,
        alias = "船夫",
        isYell = true
      },
      {
        name = CHS[3000892],
        x = 13,
        y = 40,
        icon = 6042,
        isYell = true
      },
      {
        name = CHS[3000893],
        x = 88,
        y = 15,
        icon = 6014,
        isYell = true
      },
      {
        name = CHS[3000894],
        x = 17,
        y = 28,
        icon = 6011,
        isYell = true,
        funcLogo = CHS[7270000]
      },
      {
        name = CHS[3000895],
        x = 62,
        y = 51,
        icon = 6016,
        isYell = true
      },
      {
        name = "杂货店老板2",
        x = 46,
        y = 15,
        icon = 6015,
        alias = "杂货店老板",
        isYell = true,
        funcLogo = CHS[7270003]
      },
      {
        name = CHS[3000896],
        x = 89,
        y = 51,
        icon = 6032,
        isYell = true
      },
      {
        name = "玉真子",
        x = 34,
        y = 77,
        icon = 6053,
        headTitle = {
          classIcon = "ui/Icon2180.png",
          wordIcon = "ui/Icon2191.png"
        },
        isYell = true,
        funcLogo = CHS[7270011]
      },
      {
        name = "灵兽异人1",
        x = 16,
        y = 94,
        icon = 6041,
        alias = "灵兽异人",
        isYell = true
      },
      {
        name = "车夫1",
        x = 70,
        y = 67,
        icon = 6045,
        alias = "车夫",
        isYell = true
      }
    },
    monster_level = 0
  },
  [11001] = {
    map_name = CHS[4100432],
    map_id = 11000,
    teleport_x = 64,
    teleport_y = 77,
    npc = {
      {
        name = CHS[4100433],
        x = 33,
        y = 77,
        icon = 6004
      }
    },
    monster_level = 0
  },
  [11002] = {
    map_name = CHS[7100911],
    map_id = 11000,
    teleport_x = 86,
    teleport_y = 52,
    npc = {
      {
        name = CHS[7100905],
        x = 13,
        y = 66,
        icon = 6044
      },
      {
        name = CHS[7100906],
        x = 20,
        y = 45,
        icon = 6016
      },
      {
        name = CHS[7100907],
        x = 63,
        y = 26,
        icon = 6012
      },
      {
        name = CHS[7100908],
        x = 82,
        y = 20,
        icon = 6014
      },
      {
        name = CHS[7100909],
        x = 60,
        y = 75,
        icon = 6045
      },
      {
        name = CHS[7100916],
        x = 56,
        y = 60,
        icon = 6042,
        alias = CHS[7100910]
      }
    },
    monster_level = 0,
    unmatch_team = true,
    unswitch_line = true,
    notShowExitInSmallMap = true,
    notDrawTeam = true
  },
  [11003] = {
    map_name = CHS[7100912],
    map_id = 11000,
    teleport_x = 86,
    teleport_y = 52,
    npc = {
      {
        name = CHS[7100913],
        x = 37,
        y = 26,
        icon = 6042
      },
      {
        name = CHS[7100922],
        x = 75,
        y = 90,
        icon = 6044
      },
      {
        name = CHS[7100923],
        x = 29,
        y = 38,
        icon = 6040
      },
      {
        name = CHS[7100924],
        x = 81,
        y = 46,
        icon = 6017
      }
    },
    monster_level = 0,
    unmatch_team = true,
    unswitch_line = true,
    notShowExitInSmallMap = true,
    notDrawTeam = true
  },
  [12000] = {
    map_name = CHS[3000898],
    map_id = 12000,
    teleport_x = 52,
    teleport_y = 35,
    npc = {
      {
        name = CHS[3000899],
        x = 43,
        y = 57,
        icon = 6189
      }
    },
    monster_level = 31
  },
  [13000] = {
    map_name = "乾元山",
    map_id = 13000,
    teleport_x = 32,
    teleport_y = 41,
    npc = {
      {
        name = CHS[3000901],
        x = 13,
        y = 16,
        icon = 6235
      },
      {
        name = CHS[3000902],
        x = 22,
        y = 35,
        icon = 6004
      },
      {
        name = "接引道童2",
        x = 36,
        y = 33,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "接引道童"
      }
    },
    exit_level = {},
    monster_level = 35
  },
  [13001] = {
    map_name = CHS[3000903],
    map_id = 13001,
    teleport_x = 11,
    teleport_y = 23,
    npc = {
      {
        name = CHS[3000904],
        x = 52,
        y = 15,
        icon = 6055
      },
      {
        name = CHS[3000905],
        x = 31,
        y = 13,
        icon = 6023
      },
      {
        name = CHS[3000906],
        x = 18,
        y = 13,
        icon = 20036
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [14000] = {
    map_name = "终南山",
    map_id = 14000,
    teleport_x = 36,
    teleport_y = 20,
    npc = {
      {
        name = CHS[3000908],
        x = 6,
        y = 26,
        icon = 6233
      },
      {
        name = CHS[3000909],
        x = 46,
        y = 12,
        icon = 6002
      },
      {
        name = "接引道童3",
        x = 28,
        y = 12,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "接引道童"
      }
    },
    exit_level = {},
    monster_level = 35
  },
  [14001] = {
    map_name = CHS[3000910],
    map_id = 14001,
    teleport_x = 36,
    teleport_y = 22,
    npc = {
      {
        name = CHS[3000911],
        x = 17,
        y = 10,
        icon = 6053
      },
      {
        name = CHS[3000912],
        x = 43,
        y = 15,
        icon = 6021
      },
      {
        name = CHS[3000913],
        x = 14,
        y = 26,
        icon = 20034
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [15000] = {
    map_name = CHS[3000914],
    map_id = 15000,
    teleport_x = 46,
    teleport_y = 26,
    npc = {
      {
        name = CHS[3000915],
        x = 20,
        y = 17,
        icon = 6234
      },
      {
        name = CHS[3000916],
        x = 64,
        y = 21,
        icon = 6003
      },
      {
        name = "接引道童4",
        x = 57,
        y = 16,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "接引道童"
      }
    },
    exit_level = {},
    monster_level = 35
  },
  [15001] = {
    map_name = CHS[3000917],
    map_id = 15001,
    teleport_x = 43,
    teleport_y = 25,
    npc = {
      {
        name = CHS[3000918],
        x = 10,
        y = 9,
        icon = 6054
      },
      {
        name = CHS[3000919],
        x = 43,
        y = 7,
        icon = 6022
      },
      {
        name = CHS[3000920],
        x = 26,
        y = 7,
        icon = 20035
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [15005] = {
    map_name = "王母寝宫",
    map_id = 15001,
    teleport_x = 43,
    teleport_y = 25,
    npc = {
      {
        name = "瑶池天兵1",
        x = 12,
        y = 14,
        icon = 6223,
        alias = "瑶池天兵"
      },
      {
        name = "瑶池天兵2",
        x = 12,
        y = 22,
        icon = 6223,
        alias = "瑶池天兵"
      },
      {
        name = "瑶池天兵3",
        x = 23,
        y = 27,
        icon = 6223,
        alias = "瑶池天兵"
      },
      {
        name = "瑶池天兵4",
        x = 38,
        y = 27,
        icon = 6223,
        alias = "瑶池天兵"
      },
      {
        name = "瑶池天兵5",
        x = 24,
        y = 20,
        icon = 6223,
        alias = "瑶池天兵"
      },
      {
        name = "侍女青梅",
        x = 23,
        y = 9,
        icon = 6134
      },
      {
        name = "侍女红羽",
        x = 38,
        y = 9,
        icon = 6136
      },
      {
        name = "侍女黄秀",
        x = 49,
        y = 14,
        icon = 6133
      },
      {
        name = "侍女蓝欣",
        x = 49,
        y = 22,
        icon = 6138
      },
      {
        name = "侍女白依",
        x = 34,
        y = 15,
        icon = 6135
      }
    },
    monster_level = 0,
    unswitch_line = true,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [16000] = {
    map_name = "骷髅山",
    map_id = 16000,
    teleport_x = 39,
    teleport_y = 44,
    npc = {
      {
        name = CHS[3000922],
        x = 37,
        y = 9,
        icon = 6236
      },
      {
        name = CHS[3000923],
        x = 51,
        y = 18,
        icon = 6226
      },
      {
        name = CHS[3000924],
        x = 9,
        y = 36,
        icon = 6005
      },
      {
        name = "接引道童5",
        x = 19,
        y = 36,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "接引道童"
      }
    },
    exit_level = {},
    monster_level = 35
  },
  [16005] = {
    map_name = CHS[7190148],
    map_id = 16000,
    monster_level = 0,
    unmatch_team = true,
    unswitch_line = true
  },
  [8101] = {
    map_name = CHS[7190149],
    map_id = 8100,
    monster_level = 0,
    unmatch_team = true,
    unswitch_line = true,
    hide_fly_fog = true
  },
  [16001] = {
    map_name = CHS[3000925],
    map_id = 16001,
    teleport_x = 23,
    teleport_y = 22,
    npc = {
      {
        name = CHS[3000926],
        x = 44,
        y = 9,
        icon = 6056
      },
      {
        name = CHS[3000927],
        x = 24,
        y = 16,
        icon = 6024
      },
      {
        name = CHS[3000928],
        x = 45,
        y = 22,
        icon = 20037
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [16100] = {
    map_name = CHS[3000929],
    map_id = 16100,
    teleport_x = 37,
    teleport_y = 33,
    npc = {
      {
        name = CHS[3000930],
        x = 49,
        y = 19,
        icon = 6147
      },
      {
        name = CHS[3000931],
        x = 14,
        y = 33,
        icon = 6228
      },
      {
        name = CHS[3000932],
        x = 13,
        y = 21,
        icon = 6227
      },
      {
        name = CHS[3000933],
        x = 32,
        y = 19,
        icon = 6003
      }
    },
    monster_level = 57
  },
  [16101] = {
    map_name = CHS[3000934],
    map_id = 16100,
    teleport_x = 49,
    teleport_y = 38,
    monster_level = 1,
    hide_fly_fog = true
  },
  [17000] = {
    map_name = CHS[3000935],
    map_id = 17000,
    teleport_x = 31,
    teleport_y = 52,
    npc = {
      {
        name = CHS[3000936],
        x = 50,
        y = 49,
        icon = 6047
      },
      {
        name = CHS[3000937],
        x = 61,
        y = 9,
        icon = 6068
      },
      {
        name = CHS[3000938],
        x = 37,
        y = 51,
        icon = 6003
      },
      {
        name = "龙宫使者2",
        x = 7,
        y = 76,
        icon = 6163,
        defalut_talk = CHS[6000375],
        alias = "龙宫使者"
      },
      {
        name = "米兰仙子",
        x = 7,
        y = 19,
        icon = 6002,
        offsetPos = {x = 10, y = 0}
      }
    },
    monster_level = 51
  },
  [17100] = {
    map_name = CHS[3000939],
    map_id = 17100,
    teleport_x = 26,
    teleport_y = 36,
    npc = {},
    monster_level = 62,
    npc = {
      {
        name = CHS[3000940],
        x = 34,
        y = 35,
        icon = 6003
      }
    }
  },
  [17200] = {
    map_name = CHS[3000941],
    map_id = 17200,
    teleport_x = 36,
    teleport_y = 43,
    npc = {},
    monster_level = 65,
    npc = {
      {
        name = CHS[3000942],
        x = 51,
        y = 31,
        icon = 6003
      }
    }
  },
  [17201] = {
    map_name = "百花丛中",
    map_id = 17200,
    teleport_x = 36,
    teleport_y = 43,
    npc = {
      {
        name = "百花使者",
        x = 19,
        y = 50,
        icon = 6128
      }
    },
    monster_level = 0,
    unmatch_team = true,
    sendMoveInterval = 0.3
  },
  [17203] = {
    map_name = "缘分山谷",
    map_id = 17200,
    teleport_x = 36,
    teleport_y = 43,
    npc = {},
    monster_level = 0,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [17300] = {
    map_name = CHS[3000943],
    map_id = 17300,
    teleport_x = 50,
    teleport_y = 49,
    npc = {},
    monster_level = 68,
    npc = {
      {
        name = CHS[3000944],
        x = 51,
        y = 31,
        icon = 6003
      }
    }
  },
  [17400] = {
    map_name = CHS[3000945],
    map_id = 17400,
    teleport_x = 52,
    teleport_y = 25,
    npc = {},
    monster_level = 71,
    npc = {
      {
        name = CHS[3000946],
        x = 34,
        y = 35,
        icon = 6003
      }
    }
  },
  [17500] = {
    map_name = CHS[3000947],
    map_id = 17500,
    teleport_x = 33,
    teleport_y = 23,
    npc = {
      {
        name = CHS[3000948],
        x = 69,
        y = 22,
        icon = 6173
      },
      {
        name = CHS[3000949],
        x = 51,
        y = 31,
        icon = 6003
      }
    },
    monster_level = 74
  },
  [17600] = {
    map_name = CHS[3000950],
    map_id = 17600,
    teleport_x = 53,
    teleport_y = 34,
    npc = {},
    monster_level = 77,
    npc = {
      {
        name = CHS[3000951],
        x = 51,
        y = 31,
        icon = 6003
      }
    }
  },
  [17700] = {
    map_name = CHS[3000952],
    map_id = 17700,
    teleport_x = 46,
    teleport_y = 45,
    npc = {
      {
        name = CHS[3000953],
        x = 14,
        y = 24,
        icon = 6022
      },
      {
        name = CHS[3000954],
        x = 34,
        y = 35,
        icon = 6003
      }
    },
    monster_level = 80
  },
  [23000] = {
    map_name = CHS[3000955],
    map_id = 23000,
    teleport_x = 64,
    teleport_y = 58,
    npc = {
      {
        name = CHS[3000956],
        x = 80,
        y = 35,
        icon = 6032,
        isYell = true
      },
      {
        name = CHS[3000957],
        x = 88,
        y = 74,
        icon = 6032,
        isYell = true
      },
      {
        name = CHS[3000958],
        x = 47,
        y = 47,
        icon = 6011,
        isYell = true,
        funcLogo = CHS[7270000]
      },
      {
        name = CHS[3000959],
        x = 86,
        y = 63,
        icon = 6012,
        isYell = true
      },
      {
        name = CHS[3000960],
        x = 78,
        y = 18,
        icon = 6013,
        isYell = true
      },
      {
        name = CHS[3000961],
        x = 42,
        y = 19,
        icon = 6016,
        isYell = true
      },
      {
        name = CHS[3000962],
        x = 16,
        y = 44,
        icon = 6015,
        isYell = true,
        funcLogo = CHS[7270003]
      },
      {
        name = "善财童子",
        x = 51,
        y = 78,
        icon = 6240,
        headTitle = {
          classIcon = "ui/Icon2181.png",
          wordIcon = "ui/Icon2194.png"
        },
        isYell = true,
        funcLogo = CHS[7270012]
      },
      {
        name = "灵兽异人3",
        x = 21,
        y = 29,
        icon = 6041,
        alias = "灵兽异人",
        isYell = true
      },
      {
        name = "船夫5",
        x = 15,
        y = 85,
        icon = 6044,
        alias = "船夫",
        isYell = true
      },
      {
        name = "车夫3",
        x = 16,
        y = 15,
        icon = 6045,
        alias = "车夫",
        isYell = true
      },
      {
        name = CHS[3000964],
        x = 76,
        y = 54,
        icon = 20006,
        isYell = true
      },
      {
        name = "南华真人",
        x = 9,
        y = 21,
        icon = 6063,
        isYell = true
      }
    },
    monster_level = 0
  },
  [23001] = {
    map_name = CHS[7100935],
    map_id = 23000,
    teleport_x = 64,
    teleport_y = 58,
    npc = {
      {
        name = CHS[7100942],
        x = 41,
        y = 44,
        icon = 6010
      },
      {
        name = CHS[7100943],
        x = 79,
        y = 62,
        icon = 6035
      },
      {
        name = CHS[7100944],
        x = 22,
        y = 45,
        icon = 6013
      },
      {
        name = CHS[7100945],
        x = 35,
        y = 24,
        icon = 6016
      },
      {
        name = CHS[7100946],
        x = 50,
        y = 16,
        icon = 6231
      },
      {
        name = CHS[7100947],
        x = 98,
        y = 15,
        icon = 6240
      },
      {
        name = CHS[7100948],
        x = 60,
        y = 55,
        icon = 6043
      },
      {
        name = CHS[7100949],
        x = 62,
        y = 22,
        icon = 6012
      }
    },
    monster_level = 0
  },
  [26000] = {
    map_name = CHS[3000965],
    map_id = 26000,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = CHS[3000966],
        x = 31,
        y = 8,
        icon = 6240
      },
      {
        name = CHS[3000967],
        x = 31,
        y = 40,
        icon = 6033
      },
      {
        name = CHS[3000968],
        x = 38,
        y = 12,
        icon = 6036
      },
      {
        name = CHS[3000969],
        x = 64,
        y = 15,
        icon = 6043
      },
      {
        name = CHS[3000970],
        x = 70,
        y = 48,
        icon = 6014
      },
      {
        name = CHS[3000971],
        x = 11,
        y = 14,
        icon = 6135
      }
    },
    monster_level = 0
  },
  [26001] = {
    map_name = CHS[3000972],
    map_id = 26000,
    teleport_x = 17,
    teleport_y = 44,
    npc = {},
    monster_level = 0
  },
  [31100] = {
    map_name = CHS[3000973],
    map_id = 8100,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = CHS[3000974],
        icon = 6050,
        x = 60,
        y = 41
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [31200] = {
    map_name = CHS[3000975],
    map_id = 8200,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [31300] = {
    map_name = CHS[3000976],
    map_id = 8300,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = CHS[3000977],
        icon = 6257,
        x = 13,
        y = 23
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [31101] = {
    map_name = "幻·黑风一层",
    map_id = 8100,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "二当家",
        icon = 6202,
        x = 69,
        y = 18,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "僵尸王",
        icon = 6149,
        x = 17,
        y = 19,
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [31201] = {
    map_name = "幻·黑风二层",
    map_id = 8200,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [31301] = {
    map_name = "幻·黑风三层",
    map_id = 8300,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "受伤的妖狼王",
        icon = 6257,
        x = 73,
        y = 24,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "影狼",
        icon = 6257,
        x = 67,
        y = 24,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "幻境-蒙面人",
        icon = 6057,
        x = 49,
        y = 43,
        alias = "蒙面人",
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [32000] = {
    map_name = CHS[3000978],
    map_id = 8000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = CHS[5300008],
        icon = 6086,
        x = 68,
        y = 16
      }
    },
    monster_level = 0
  },
  [32100] = {
    map_name = CHS[3000979],
    map_id = 6000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0
  },
  [32200] = {
    map_name = CHS[3000980],
    map_id = 16100,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0
  },
  [32001] = {
    map_name = "幻·兰若寺",
    map_id = 8000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "黑山小妖",
        icon = 6229,
        x = 67,
        y = 55,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "黑山小队长",
        icon = 6226,
        x = 73,
        y = 51,
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 0
  },
  [32101] = {
    map_name = "幻·后山",
    map_id = 6000,
    teleport_x = 7,
    teleport_y = 8,
    npc = {
      {
        name = "小倩",
        icon = 6002,
        x = 31,
        y = 23,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "幻·赤霞真人",
        icon = 6086,
        x = 53,
        y = 14,
        alias = "赤霞真人",
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "姥姥",
        icon = 6241,
        x = 30,
        y = 26,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "黑山老妖2",
        icon = 6258,
        x = 35,
        y = 27,
        alias = "黑山老妖",
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 0
  },
  [32201] = {
    map_name = "幻·洞穴",
    map_id = 16100,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "采臣",
        icon = 6004,
        x = 19,
        y = 19,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "黑山老妖1",
        icon = 6258,
        x = 38,
        y = 31,
        alias = "黑山老妖",
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 0
  },
  [33000] = {
    map_name = CHS[3000981],
    map_id = 16000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = CHS[3000982],
        icon = 6047,
        x = 24,
        y = 40
      }
    },
    monster_level = 0
  },
  [33100] = {
    map_name = CHS[3000983],
    map_id = 16001,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [33300] = {
    map_name = CHS[3000984],
    map_id = 16001,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [33200] = {
    map_name = CHS[3000985],
    map_id = 16001,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [37000] = {
    map_name = CHS[3000986],
    map_id = 37000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = CHS[3000987],
        icon = 6223,
        x = 35,
        y = 20,
        defalut_talk = "传送出塔"
      },
      {
        name = CHS[3000988],
        icon = 6223,
        x = 43,
        y = 11
      },
      {
        name = CHS[3000989],
        icon = 6223,
        x = 31,
        y = 9
      },
      {
        name = CHS[3000990],
        icon = 6223,
        x = 19,
        y = 11
      },
      {
        name = CHS[3000991],
        icon = 6223,
        x = 8,
        y = 16
      },
      {
        name = CHS[3000992],
        icon = 6223,
        x = 4,
        y = 23
      },
      {
        name = CHS[3000993],
        icon = 6223,
        x = 58,
        y = 23
      },
      {
        name = CHS[3000994],
        icon = 6223,
        x = 54,
        y = 16
      }
    },
    monster_level = 0
  },
  [38000] = {
    map_name = CHS[5400030],
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = CHS[5400038],
        x = 62,
        y = 36,
        icon = 6236
      },
      {
        name = "战场物资员1",
        x = 101,
        y = 33,
        icon = 6014,
        alias = "战场物资员"
      }
    }
  },
  [38004] = {
    map_name = CHS[3000995],
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = CHS[3000996],
        x = 38,
        y = 48,
        icon = 6012
      }
    }
  },
  [38005] = {
    map_name = CHS[3000997],
    map_id = 38001,
    teleport_x = 17,
    teleport_y = 44,
    npc = {},
    monster_level = 0
  },
  [38003] = {
    map_name = CHS[3000998],
    map_id = 38001,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = CHS[3000999],
        x = 52,
        y = 49,
        icon = 6043
      }
    },
    monster_level = 0,
    exit_level = {
      [CHS[3000814]] = ""
    },
    hide_fly_fog = true
  },
  [38006] = {
    map_name = CHS[5400028],
    map_id = 38001,
    teleport_x = 17,
    teleport_y = 44,
    monster_level = 0,
    npc = {
      {
        name = CHS[5400029],
        x = 38,
        y = 48,
        icon = 6223
      },
      {
        name = "战场物资员2",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      }
    }
  },
  [16003] = {
    map_name = CHS[3001000],
    map_id = 16000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "吕洞宾1",
        x = 38,
        y = 9,
        icon = 20006,
        alias = "吕洞宾"
      },
      {
        name = CHS[3001002],
        x = 7,
        y = 18,
        icon = 22005
      },
      {
        name = CHS[3001003],
        x = 23,
        y = 39,
        icon = 6260
      }
    }
  },
  [12001] = {
    map_name = CHS[4100105],
    map_id = 12000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "张果老1",
        x = 48,
        y = 57,
        icon = 20009,
        alias = "张果老"
      }
    }
  },
  [16102] = {
    map_name = CHS[4100107],
    map_id = 16100,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = CHS[4100108],
        x = 14,
        y = 20,
        icon = 6127
      },
      {
        name = CHS[4100109],
        x = 43,
        y = 18,
        icon = 6124
      },
      {
        name = CHS[4100110],
        x = 54,
        y = 30,
        icon = 6119
      },
      {
        name = CHS[4100111],
        x = 44,
        y = 42,
        icon = 6118
      },
      {
        name = CHS[4100112],
        x = 17,
        y = 34,
        icon = 6117
      },
      {
        name = CHS[4100113],
        x = 35,
        y = 32,
        icon = 6227
      }
    }
  },
  [17301] = {
    map_name = CHS[4200143],
    map_id = 17300,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "何仙姑1",
        x = 21,
        y = 42,
        icon = 20010,
        alias = "何仙姑"
      },
      {
        name = CHS[4200145],
        x = 55,
        y = 36,
        icon = 6249
      },
      {
        name = CHS[4200146],
        x = 51,
        y = 34,
        icon = 6202
      }
    }
  },
  [28007] = {
    map_name = CHS[4100277],
    map_id = 28007,
    monster_level = 0,
    teleport_x = 24,
    teleport_y = 23,
    npc = {},
    hide_fly_fog = true
  },
  [5011] = {
    map_name = "青竹客栈",
    map_id = 5005,
    teleport_x = 5,
    teleport_y = 5,
    monster_level = 0,
    npc = {},
    unmatch_team = true,
    hide_fly_fog = true
  },
  [28116] = {
    map_name = "客栈-甲字客房",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    monster_level = 0,
    mapType = 4,
    hide_fly_fog = true
  },
  [28117] = {
    map_name = "客栈-乙字客房",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    monster_level = 0,
    mapType = 4,
    hide_fly_fog = true
  },
  [28118] = {
    map_name = "客栈-丙字客房",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    monster_level = 0,
    mapType = 4,
    hide_fly_fog = true
  },
  [28119] = {
    map_name = "客栈-丁字客房",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    monster_level = 0,
    mapType = 4,
    hide_fly_fog = true
  },
  [28120] = {
    map_name = "客栈-戊字客房",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    monster_level = 0,
    mapType = 4,
    hide_fly_fog = true
  },
  [28121] = {
    map_name = "客栈-神秘客房",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    npc = {},
    monster_level = 0,
    mapType = 4,
    hide_fly_fog = true
  },
  [19000] = {
    map_name = CHS[6000334],
    map_id = 19000,
    monster_level = 0,
    teleport_x = 30,
    teleport_y = 35,
    npc = {
      {
        name = CHS[6000356],
        x = 13,
        y = 22,
        icon = 6064
      },
      {
        name = CHS[6000357],
        x = 43,
        y = 25,
        icon = 6243
      },
      {
        name = CHS[6000358],
        x = 10,
        y = 42,
        icon = 6252
      },
      {
        name = "传送童子1",
        x = 30,
        y = 30,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "传送童子"
      }
    }
  },
  [20000] = {
    map_name = CHS[6000335],
    map_id = 20000,
    monster_level = 0,
    teleport_x = 39,
    teleport_y = 35,
    npc = {
      {
        name = CHS[6000353],
        x = 12,
        y = 18,
        icon = 6065
      },
      {
        name = CHS[6000354],
        x = 15,
        y = 38,
        icon = 6244
      },
      {
        name = CHS[6000355],
        x = 46,
        y = 22,
        icon = 6249
      },
      {
        name = "传送童子2",
        x = 23,
        y = 22,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "传送童子"
      }
    }
  },
  [21001] = {
    map_name = CHS[6000336],
    map_id = 21001,
    monster_level = 0,
    teleport_x = 27,
    teleport_y = 16,
    npc = {
      {
        name = CHS[6000345],
        x = 50,
        y = 7,
        icon = 6066
      },
      {
        name = CHS[6000346],
        x = 30,
        y = 7,
        icon = 6250
      },
      {
        name = CHS[6000347],
        x = 54,
        y = 23,
        icon = 6248
      },
      {
        name = CHS[6000348],
        x = 4,
        y = 21,
        icon = 6235
      },
      {
        name = "传送童子3",
        x = 45,
        y = 18,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "传送童子"
      }
    }
  },
  [22001] = {
    map_name = CHS[6000337],
    map_id = 22001,
    monster_level = 0,
    teleport_x = 34,
    teleport_y = 17,
    npc = {
      {
        name = CHS[6000349],
        x = 19,
        y = 6,
        icon = 6063
      },
      {
        name = CHS[6000350],
        x = 14,
        y = 43,
        icon = 6251
      },
      {
        name = CHS[6000351],
        x = 50,
        y = 25,
        icon = 6246
      },
      {
        name = CHS[6000352],
        x = 18,
        y = 20,
        icon = 6232
      },
      {
        name = "传送童子4",
        x = 33,
        y = 8,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "传送童子"
      }
    }
  },
  [15002] = {
    map_name = "八仙瑶池",
    map_id = 50004,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = CHS[3001005],
        x = 35,
        y = 23,
        icon = 6139
      },
      {
        name = CHS[3001006],
        x = 14,
        y = 12,
        icon = 22002
      },
      {
        name = CHS[3001007],
        x = 66,
        y = 37,
        icon = 6223
      }
    }
  },
  [25000] = {
    map_name = CHS[6000338],
    map_id = 25000,
    monster_level = 0,
    teleport_x = 31,
    teleport_y = 27,
    npc = {
      {
        name = CHS[6000342],
        x = 14,
        y = 16,
        icon = 6061
      },
      {
        name = CHS[6000343],
        x = 8,
        y = 26,
        icon = 6247
      },
      {
        name = CHS[6000344],
        x = 30,
        y = 8,
        icon = 6245
      },
      {
        name = "传送童子5",
        x = 27,
        y = 19,
        icon = 6069,
        defalut_talk = CHS[6000379],
        alias = "传送童子"
      }
    }
  },
  [25010] = {
    map_name = CHS[4100361],
    map_id = 25002,
    monster_level = 0,
    npc = {
      {
        name = "蓝采和1",
        x = 46,
        y = 4,
        icon = 20007,
        alias = "蓝采和"
      },
      {
        name = CHS[4100363],
        x = 46,
        y = 6,
        icon = 7009
      },
      {
        name = CHS[4100364],
        x = 8,
        y = 28,
        icon = 6228
      }
    }
  },
  [14003] = {
    map_name = CHS[6000309],
    map_id = 14003,
    monster_level = 0,
    teleport_x = 33,
    teleport_y = 39,
    npc = {
      {
        name = CHS[6000366],
        x = 7,
        y = 35,
        icon = 6258
      },
      {
        name = CHS[4200147],
        x = 36,
        y = 16,
        icon = 6003
      }
    }
  },
  [14004] = {
    map_name = CHS[6000320],
    map_id = 14004,
    monster_level = 0,
    teleport_x = 35,
    teleport_y = 33,
    npc = {
      {
        name = CHS[6000368],
        x = 50,
        y = 16,
        icon = 6244
      },
      {
        name = CHS[6000369],
        x = 38,
        y = 5,
        icon = 6143
      },
      {
        name = CHS[4100253],
        x = 53,
        y = 40,
        icon = 6003
      }
    }
  },
  [14005] = {
    map_name = CHS[6000323],
    map_id = 14005,
    monster_level = 0,
    teleport_x = 31,
    teleport_y = 25,
    npc = {
      {
        name = CHS[6000370],
        x = 55,
        y = 16,
        icon = 6214
      },
      {
        name = CHS[4200149],
        x = 56,
        y = 44,
        icon = 6003
      }
    }
  },
  [14006] = {
    map_name = CHS[6000326],
    map_id = 14006,
    monster_level = 0,
    teleport_x = 50,
    teleport_y = 44,
    npc = {
      {
        name = CHS[6000371],
        x = 31,
        y = 7,
        icon = 6223
      },
      {
        name = CHS[4200150],
        x = 40,
        y = 27,
        icon = 6003
      }
    }
  },
  [14008] = {
    map_name = CHS[7100160],
    map_id = 14003,
    monster_level = 0,
    unswitch_line = true,
    npc = {}
  },
  [14009] = {
    map_name = CHS[7100157],
    map_id = 14004,
    monster_level = 0,
    unswitch_line = true,
    npc = {}
  },
  [14010] = {
    map_name = CHS[7100158],
    map_id = 14005,
    monster_level = 0,
    unswitch_line = true,
    npc = {}
  },
  [16004] = {
    map_name = CHS[4100365],
    map_id = 16001,
    monster_level = 0,
    npc = {
      {
        name = CHS[4100366],
        x = 32,
        y = 17,
        icon = 20056
      },
      {
        name = CHS[4100367],
        x = 38,
        y = 20,
        icon = 20057
      },
      {
        name = CHS[4100368],
        x = 44,
        y = 9,
        icon = 20051
      }
    },
    hide_fly_fog = true
  },
  [27000] = {
    map_name = CHS[6000329],
    map_id = 27000,
    monster_level = 0,
    teleport_x = 28,
    teleport_y = 20,
    npc = {
      {
        name = CHS[4200151],
        x = 43,
        y = 15,
        icon = 6003
      }
    },
    hide_fly_fog = true
  },
  [27005] = {
    map_name = CHS[7002023],
    map_id = 27000,
    monster_level = 0,
    teleport_x = 28,
    teleport_y = 20,
    npc = {
      {
        name = "铁拐李2",
        x = 36,
        y = 11,
        icon = 20004,
        alias = "铁拐李"
      },
      {
        name = "张果老2",
        x = 40,
        y = 8,
        icon = 20009,
        alias = "张果老"
      },
      {
        name = "汉钟离2",
        x = 18,
        y = 14,
        icon = 20005,
        alias = "汉钟离"
      },
      {
        name = "蓝采和2",
        x = 16,
        y = 16,
        icon = 20007,
        alias = "蓝采和"
      }
    },
    hide_fly_fog = true
  },
  [27006] = {
    map_name = CHS[7002024],
    map_id = 27002,
    monster_level = 0,
    teleport_x = 43,
    teleport_y = 25,
    npc = {
      {
        name = "韩湘子2",
        x = 37,
        y = 12,
        icon = 20008,
        alias = "韩湘子"
      },
      {
        name = "吕洞宾3",
        x = 39,
        y = 10,
        icon = 20006,
        alias = "吕洞宾"
      },
      {
        name = CHS[7002028],
        x = 13,
        y = 7,
        icon = 6079
      }
    },
    hide_fly_fog = true
  },
  [18000] = {
    map_name = CHS[6000317],
    map_id = 18000,
    monster_level = 0,
    teleport_x = 42,
    teleport_y = 64,
    npc = {
      {
        name = CHS[6000363],
        x = 28,
        y = 70,
        icon = 6244
      },
      {
        name = "船夫2",
        x = 18,
        y = 87,
        icon = 6044,
        alias = "船夫"
      },
      {
        name = CHS[6000365],
        x = 51,
        y = 49,
        icon = 6108
      },
      {
        name = CHS[6000385],
        x = 46,
        y = 23,
        icon = 6249
      },
      {
        name = CHS[4200152],
        x = 16,
        y = 37,
        icon = 6003
      }
    }
  },
  [25002] = {
    map_name = CHS[6000332],
    map_id = 25002,
    monster_level = 0,
    teleport_x = 26,
    teleport_y = 20,
    npc = {
      {
        name = CHS[4200153],
        x = 45,
        y = 11,
        icon = 6003
      }
    }
  },
  [14002] = {
    map_name = CHS[6000339],
    map_id = 14002,
    monster_level = 0,
    teleport_x = 23,
    teleport_y = 20,
    npc = {
      {
        name = CHS[6000362],
        x = 21,
        y = 9,
        icon = 6032,
        defalut_talk = CHS[6000377]
      }
    },
    hide_fly_fog = true
  },
  [27002] = {
    map_name = CHS[6000340],
    map_id = 27002,
    monster_level = 0,
    teleport_x = 31,
    teleport_y = 24,
    npc = {
      {
        name = CHS[6000360],
        x = 13,
        y = 7,
        icon = 6079
      },
      {
        name = CHS[6000361],
        x = 43,
        y = 9,
        icon = 6054
      },
      {
        name = "侍女1",
        x = 17,
        y = 16,
        icon = 6173,
        alias = "侍女"
      },
      {
        name = "侍女2",
        x = 26,
        y = 12,
        icon = 6173,
        alias = "侍女"
      }
    },
    hide_fly_fog = true
  },
  [27003] = {
    map_name = CHS[4000382],
    map_id = 27002,
    monster_level = 0,
    teleport_x = 43,
    teleport_y = 25,
    npc = {
      {
        name = CHS[4200142],
        x = 13,
        y = 7,
        icon = 6079
      }
    },
    hide_fly_fog = true
  },
  [27001] = {
    map_name = CHS[6000341],
    map_id = 27001,
    monster_level = 0,
    teleport_x = 27,
    teleport_y = 22,
    npc = {
      {
        name = "龙宫使者1",
        x = 46,
        y = 19,
        icon = 6163,
        defalut_talk = CHS[6000376],
        alias = "龙宫使者"
      }
    },
    hide_fly_fog = true
  },
  [9002] = {
    map_name = CHS[4100278],
    map_id = 9000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "曹国舅1",
        x = 35,
        y = 41,
        icon = 20011,
        alias = "曹国舅"
      },
      {
        name = CHS[4100281],
        x = 22,
        y = 13,
        icon = 6124
      },
      {
        name = CHS[4100282],
        x = 16,
        y = 45,
        icon = 6223
      }
    }
  },
  [25005] = {
    map_name = "飘渺仙府",
    map_id = 25000,
    monster_level = 0,
    teleport_x = 31,
    teleport_y = 27,
    npc = {
      {
        name = "引路童子",
        x = 27,
        y = 19,
        icon = 6069
      },
      {
        name = "恶仆",
        x = 37,
        y = 30,
        icon = 6245
      },
      {
        name = "武痴",
        x = 7,
        y = 26,
        icon = 20037
      }
    }
  },
  [25006] = {
    map_name = "仙府秘境",
    map_id = 25002,
    monster_level = 0,
    teleport_x = 26,
    teleport_y = 20,
    npc = {
      {
        name = "双面鬼",
        x = 14,
        y = 31,
        icon = 20058
      }
    }
  },
  [27004] = {
    map_name = CHS[4100283],
    map_id = 27002,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = CHS[4100284],
        x = 18,
        y = 10,
        icon = 6190
      }
    },
    hide_fly_fog = true
  },
  [27007] = {
    map_name = "仙府大殿",
    map_id = 27002,
    monster_level = 0,
    teleport_x = 31,
    teleport_y = 24,
    npc = {
      {
        name = "侍剑者",
        x = 26,
        y = 12,
        icon = 6272
      },
      {
        name = "侍书者",
        x = 17,
        y = 16,
        icon = 6307
      },
      {
        name = "飘渺府主",
        x = 13,
        y = 7,
        icon = 20008
      }
    },
    hide_fly_fog = true
  },
  [3002] = {
    map_name = CHS[4100318],
    map_id = 3000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "白发老翁",
        x = 14,
        y = 22,
        icon = 20009
      }
    }
  },
  [14007] = {
    map_name = CHS[4100319],
    map_id = 14000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "东华上仙",
        x = 22,
        y = 12,
        icon = 6066
      },
      {
        name = "太上老君1",
        x = 18,
        y = 45,
        icon = 6065,
        alias = "太上老君"
      }
    }
  },
  [16103] = {
    map_name = CHS[4100320],
    map_id = 16100,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "玉匣",
        x = 21,
        y = 21,
        icon = 20038
      },
      {
        name = "李副将",
        x = 43,
        y = 34,
        icon = 860801
      }
    }
  },
  [16104] = {
    map_name = CHS[7003009],
    map_id = 16100,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = CHS[7003014],
        x = 37,
        y = 38,
        icon = 6241
      }
    },
    monster_level = 0
  },
  [38010] = {
    map_name = CHS[7002105],
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0
  },
  [38011] = {
    map_name = CHS[7002128],
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0
  },
  [38007] = {
    map_name = "全民热身赛场",
    map_id = 38001,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "全民PK赛接引人",
        x = 38,
        y = 48,
        icon = 6236
      },
      {
        name = "全民战场物资员1",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    monster_level = 0
  },
  [38008] = {
    map_name = "全民楼兰城",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "全民楼兰城接引人",
        x = 62,
        y = 36,
        icon = 6236
      },
      {
        name = "全民战场物资员2",
        x = 101,
        y = 33,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    monster_level = 0
  },
  [38009] = {
    map_name = "全民赛场",
    map_id = 38001,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "全民战场物资员3",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    monster_level = 0
  },
  [38028] = {
    map_name = "主播楼兰城",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "主播楼兰城接引人",
        x = 62,
        y = 36,
        icon = 6236
      },
      {
        name = "主播战场物资员1",
        x = 101,
        y = 33,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    monster_level = 0
  },
  [38029] = {
    map_name = "主播赛场",
    map_id = 38001,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "主播战场物资员2",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    monster_level = 0
  },
  [38020] = {
    map_name = "争霸楼兰城",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "名人争霸赛场接引人",
        x = 62,
        y = 36,
        icon = 6236,
        alias = "赛场接引人"
      },
      {
        name = "战场物资员5",
        x = 101,
        y = 33,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    monster_level = 0
  },
  [38021] = {
    map_name = "争霸战场",
    map_id = 38001,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "战场物资员6",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      },
      {
        name = "名人争霸战场接引人",
        x = 38,
        y = 48,
        icon = 6223,
        alias = "战场接引人"
      }
    },
    monster_level = 0
  },
  [38022] = {
    map_name = "城市赛场",
    map_id = 38001,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "全民战场物资员7",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    monster_level = 0
  },
  [15004] = {
    map_name = "须弥秘境",
    map_id = 15001,
    teleport_x = 43,
    teleport_y = 25,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [38014] = {
    map_name = "蓝毛巨兽巢穴",
    map_id = 8100,
    teleport_x = 41,
    teleport_y = 41,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [38015] = {
    map_name = "聚宝矿洞",
    map_id = 8200,
    teleport_x = 59,
    teleport_y = 38,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [38016] = {
    map_name = "赤焰炼魔巢穴",
    map_id = 8300,
    teleport_x = 25,
    teleport_y = 37,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [10102] = {
    map_name = "万妖窟一层",
    map_id = 10100,
    teleport_x = 64,
    teleport_y = 34,
    npc = {
      {
        name = "玄武神将1",
        x = 73,
        y = 13,
        icon = 6223,
        alias = "玄武神将"
      }
    },
    monster_level = 0,
    unfly = true,
    unfly_tip = "本地图插翅难飞！",
    unswitch_line = true,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [10202] = {
    map_name = "万妖窟二层",
    map_id = 10200,
    teleport_x = 64,
    teleport_y = 34,
    npc = {
      {
        name = "玄武神将2",
        x = 74,
        y = 53,
        icon = 6223,
        alias = "玄武神将"
      }
    },
    monster_level = 0,
    unfly = true,
    unfly_tip = "本地图插翅难飞！",
    unswitch_line = true,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [10302] = {
    map_name = "万妖窟三层",
    map_id = 10300,
    teleport_x = 64,
    teleport_y = 34,
    npc = {
      {
        name = "玄武神将3",
        x = 10,
        y = 54,
        icon = 6223,
        alias = "玄武神将"
      }
    },
    monster_level = 0,
    unfly = true,
    unfly_tip = "本地图插翅难飞！",
    unswitch_line = true,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [10402] = {
    map_name = "万妖窟四层",
    map_id = 10400,
    teleport_x = 64,
    teleport_y = 34,
    npc = {
      {
        name = "玄武神将4",
        x = 11,
        y = 13,
        icon = 6223,
        alias = "玄武神将"
      }
    },
    monster_level = 0,
    unfly = true,
    unfly_tip = "本地图插翅难飞！",
    unswitch_line = true,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [10502] = {
    map_name = "万妖窟五层",
    map_id = 10500,
    teleport_x = 64,
    teleport_y = 34,
    npc = {
      {
        name = "玄武神将5",
        x = 5,
        y = 16,
        icon = 6223,
        alias = "玄武神将"
      }
    },
    monster_level = 0,
    unfly = true,
    unfly_tip = "本地图插翅难飞！",
    unswitch_line = true,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [38012] = {
    map_name = "先锋营地",
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "先锋官",
        x = 92,
        y = 25,
        icon = 6031
      },
      {
        name = "义士头领",
        x = 85,
        y = 21,
        icon = 6033
      },
      {
        name = "试炼木桩",
        x = 81,
        y = 24,
        icon = 6219
      },
      {
        name = "蛮熊将军",
        x = 22,
        y = 77,
        icon = 6203,
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 0,
    unfly = true,
    unfly_tip = "当前地图无法直接离开。",
    unswitch_line = true,
    unmatch_team = true
  },
  [38013] = {
    map_name = "中洲古城",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "蛮熊主帅",
        x = 82,
        y = 46,
        icon = 6600,
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    monster_level = 0,
    unfly = true,
    unfly_tip = "当前地图无法直接离开。",
    unswitch_line = true,
    unmatch_team = true
  },
  [19002] = {
    map_name = "雪域冰原",
    map_id = 19002,
    teleport_x = 41,
    teleport_y = 25,
    npc = {
      {
        name = CHS[7002272],
        x = 14,
        y = 47,
        icon = 6003
      },
      {
        name = "无底洞",
        x = 55,
        y = 19,
        icon = 6274,
        isActiveNPC = true
      },
      {
        name = "球球",
        x = 21,
        y = 5,
        icon = 20018
      }
    },
    monster_level = 0
  },
  [21000] = {
    map_name = "迷境花树",
    map_id = 21000,
    teleport_x = 35,
    teleport_y = 30,
    npc = {
      {
        name = CHS[7002273],
        x = 44,
        y = 38,
        icon = 6003
      }
    },
    monster_level = 0
  },
  [22000] = {
    map_name = "水云间",
    map_id = 22000,
    teleport_x = 33,
    teleport_y = 25,
    npc = {
      {
        name = CHS[7002274],
        x = 15,
        y = 36,
        icon = 6003
      }
    },
    monster_level = 0
  },
  [20002] = {
    map_name = CHS[7190107],
    map_id = 20002,
    teleport_x = 11,
    teleport_y = 22,
    npc = {
      {
        name = "热砂荒漠守护神",
        x = 24,
        y = 13,
        icon = 6003
      }
    },
    monster_level = 0,
    exit_level = {}
  },
  [20003] = {
    map_name = "埋骨之地",
    map_id = 20002,
    teleport_x = 11,
    teleport_y = 22,
    npc = {
      {
        name = "埋骨逍遥仙",
        x = 35,
        y = 36,
        icon = 6032,
        alias = "逍遥仙"
      },
      {
        name = "大日金乌",
        x = 55,
        y = 18,
        icon = 6310
      },
      {
        name = "金乌之灵",
        x = 51,
        y = 24,
        icon = 6311
      },
      {
        name = "火狮兽",
        x = 57,
        y = 26,
        icon = 6312
      },
      {
        name = "火焰之灵",
        x = 47,
        y = 22,
        icon = 6313
      }
    },
    monster_level = 0,
    unmatch_team = true
  },
  [20004] = {
    map_name = "极热之地",
    map_id = 20002,
    teleport_x = 39,
    teleport_y = 42,
    monster_level = 0,
    npc = {
      {
        name = "炼魔",
        x = 31,
        y = 12,
        icon = 6153
      }
    }
  },
  [37001] = {
    map_name = "粽仙楼一层",
    map_id = 37000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "仙楼神将1",
        x = 31,
        y = 10,
        icon = 6223,
        alias = "仙楼神将"
      },
      {
        name = "青龙1",
        x = 8,
        y = 16,
        icon = 6190,
        alias = "青龙"
      },
      {
        name = "白虎1",
        x = 19,
        y = 11,
        icon = 6189,
        alias = "白虎"
      },
      {
        name = "朱雀1",
        x = 43,
        y = 11,
        icon = 6192,
        alias = "朱雀"
      },
      {
        name = "玄武1",
        x = 53,
        y = 16,
        icon = 6191,
        alias = "玄武"
      }
    },
    monster_level = 0
  },
  [37002] = {
    map_name = "粽仙楼二层",
    map_id = 37000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "仙楼神将2",
        x = 31,
        y = 10,
        icon = 6223,
        alias = "仙楼神将"
      },
      {
        name = "粽仙楼左护法",
        x = 19,
        y = 11,
        icon = 6249
      },
      {
        name = "粽仙楼右护法",
        x = 43,
        y = 11,
        icon = 6248
      }
    },
    monster_level = 0
  },
  [37003] = {
    map_name = "粽仙楼三层",
    map_id = 37000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "粽仙幻影",
        x = 31,
        y = 10,
        icon = 20010
      }
    },
    monster_level = 0
  },
  [28100] = {
    map_name = "小舍-前庭",
    map_id = 28100,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 48,
      y1 = 0,
      y2 = 72
    },
    monster_level = 0
  },
  [28101] = {
    map_name = "小舍-房屋",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "管家1",
        x = 23,
        y = 34,
        icon = 6011,
        alias = "管家"
      }
    },
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [28102] = {
    map_name = "小舍-后院",
    map_id = 28102,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "园丁1",
        x = 26,
        y = 34,
        icon = 51517,
        alias = "园丁"
      }
    },
    croplands = {
      [2] = {
        name = "农田",
        x = 690,
        y = 562
      },
      [4] = {
        name = "农田",
        x = 570,
        y = 502
      },
      [6] = {
        name = "农田",
        x = 450,
        y = 442
      },
      [8] = {
        name = "农田",
        x = 330,
        y = 382
      },
      [1] = {
        name = "农田",
        x = 810,
        y = 502
      },
      [3] = {
        name = "农田",
        x = 690,
        y = 442
      },
      [5] = {
        name = "农田",
        x = 570,
        y = 382
      },
      [7] = {
        name = "农田",
        x = 450,
        y = 322
      }
    },
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 96,
      y2 = 0
    },
    monster_level = 0
  },
  [28103] = {
    map_name = "小童父母家",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28104] = {
    map_name = "小童叔叔家",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28105] = {
    map_name = "常舌馥家",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28106] = {
    map_name = "小童爷爷家",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28200] = {
    map_name = "雅筑-前庭",
    map_id = 28200,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 48,
      y1 = 0,
      y2 = 72
    },
    monster_level = 0
  },
  [28201] = {
    map_name = "雅筑-房屋",
    map_id = 28201,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "管家2",
        x = 27,
        y = 40,
        icon = 6011,
        alias = "管家"
      }
    },
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["28_45"] = 1.2,
      ["72_22"] = 1.2
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [28202] = {
    map_name = "雅筑-后院",
    map_id = 28202,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "园丁2",
        x = 30,
        y = 32,
        icon = 51517,
        alias = "园丁"
      }
    },
    croplands = {
      [3] = {
        name = "农田",
        x = 678,
        y = 760
      },
      [6] = {
        name = "农田",
        x = 558,
        y = 700
      },
      [9] = {
        name = "农田",
        x = 438,
        y = 640
      },
      [12] = {
        name = "农田",
        x = 318,
        y = 580
      },
      [2] = {
        name = "农田",
        x = 798,
        y = 700
      },
      [5] = {
        name = "农田",
        x = 678,
        y = 640
      },
      [8] = {
        name = "农田",
        x = 558,
        y = 580
      },
      [11] = {
        name = "农田",
        x = 438,
        y = 520
      },
      [1] = {
        name = "农田",
        x = 918,
        y = 640
      },
      [4] = {
        name = "农田",
        x = 798,
        y = 580
      },
      [7] = {
        name = "农田",
        x = 678,
        y = 520
      },
      [10] = {
        name = "农田",
        x = 558,
        y = 460
      }
    },
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 96,
      y2 = 0
    },
    monster_level = 0
  },
  [28300] = {
    map_name = "豪宅-前庭",
    map_id = 28300,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 48,
      y1 = 0,
      y2 = 72
    },
    monster_level = 0
  },
  [28301] = {
    map_name = "豪宅-房屋",
    map_id = 28301,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "管家3",
        x = 32,
        y = 46,
        icon = 6011,
        alias = "管家"
      }
    },
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["32_51"] = 1.2,
      ["84_24"] = 1.2
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [28401] = {
    map_name = "小岚之家",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [28302] = {
    map_name = "豪宅-后院",
    map_id = 28302,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "园丁3",
        x = 34,
        y = 38,
        icon = 51517,
        alias = "园丁"
      }
    },
    croplands = {
      [4] = {
        name = "农田",
        x = 681,
        y = 877
      },
      [8] = {
        name = "农田",
        x = 561,
        y = 817
      },
      [12] = {
        name = "农田",
        x = 441,
        y = 757
      },
      [16] = {
        name = "农田",
        x = 321,
        y = 697
      },
      [3] = {
        name = "农田",
        x = 801,
        y = 817
      },
      [7] = {
        name = "农田",
        x = 681,
        y = 757
      },
      [11] = {
        name = "农田",
        x = 561,
        y = 697
      },
      [15] = {
        name = "农田",
        x = 441,
        y = 637
      },
      [2] = {
        name = "农田",
        x = 921,
        y = 757
      },
      [6] = {
        name = "农田",
        x = 801,
        y = 697
      },
      [10] = {
        name = "农田",
        x = 681,
        y = 637
      },
      [14] = {
        name = "农田",
        x = 561,
        y = 577
      },
      [1] = {
        name = "农田",
        x = 1041,
        y = 697
      },
      [5] = {
        name = "农田",
        x = 921,
        y = 637
      },
      [9] = {
        name = "农田",
        x = 801,
        y = 577
      },
      [13] = {
        name = "农田",
        x = 681,
        y = 517
      }
    },
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 192,
      y2 = 0
    },
    monster_level = 0
  },
  [28308] = {
    map_name = "神秘房间-前庭",
    map_id = 28300,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 48,
      y1 = 0,
      y2 = 72
    },
    monster_level = 0,
    notDrawTeam = true
  },
  [28307] = {
    map_name = "神秘房间-室内",
    map_id = 28301,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["32_51"] = 1.2,
      ["84_24"] = 1.2
    },
    need_hide_doors = {
      ["84_24"] = {
        {
          name = "o:10110houmen_1916_353"
        }
      },
      ["32_51"] = {
        {
          name = "o:10110diban_715_1205"
        },
        {
          name = "o:10110diban_619_1157"
        }
      }
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28309] = {
    map_name = "神秘房间-后院",
    map_id = 28302,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 192,
      y2 = 0
    },
    monster_level = 0,
    notDrawTeam = true,
    croplands = {
      [4] = {
        name = "农田",
        x = 681,
        y = 877
      },
      [8] = {
        name = "农田",
        x = 561,
        y = 817
      },
      [12] = {
        name = "农田",
        x = 441,
        y = 757
      },
      [16] = {
        name = "农田",
        x = 321,
        y = 697
      },
      [3] = {
        name = "农田",
        x = 801,
        y = 817
      },
      [7] = {
        name = "农田",
        x = 681,
        y = 757
      },
      [11] = {
        name = "农田",
        x = 561,
        y = 697
      },
      [15] = {
        name = "农田",
        x = 441,
        y = 637
      },
      [2] = {
        name = "农田",
        x = 921,
        y = 757
      },
      [6] = {
        name = "农田",
        x = 801,
        y = 697
      },
      [10] = {
        name = "农田",
        x = 681,
        y = 637
      },
      [14] = {
        name = "农田",
        x = 561,
        y = 577
      },
      [1] = {
        name = "农田",
        x = 1041,
        y = 697
      },
      [5] = {
        name = "农田",
        x = 921,
        y = 637
      },
      [9] = {
        name = "农田",
        x = 801,
        y = 577
      },
      [13] = {
        name = "农田",
        x = 681,
        y = 517
      }
    }
  },
  [28310] = {
    map_name = CHS[7100936],
    map_id = 28300,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = CHS[7100939],
        x = 96,
        y = 43,
        icon = 6031
      }
    },
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 192,
      y2 = 0
    },
    monster_level = 0,
    notDrawTeam = true
  },
  [28311] = {
    map_name = CHS[7100937],
    map_id = 28301,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = CHS[7100940],
        x = 39,
        y = 35,
        icon = 6036
      },
      {
        name = CHS[7100941],
        x = 71,
        y = 45,
        icon = 6015
      }
    },
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 192,
      y2 = 0
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28312] = {
    map_name = "张府-前庭",
    map_id = 28300,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "张员外妻子",
        x = 96,
        y = 43,
        icon = 6040
      }
    },
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 192,
      y2 = 0
    },
    monster_level = 0,
    notDrawTeam = true,
    mapType = 4
  },
  [28313] = {
    map_name = "张府-房屋",
    map_id = 28301,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "张员外",
        x = 75,
        y = 31,
        icon = 6014
      },
      {
        name = "张员外小妾",
        x = 64,
        y = 33,
        icon = 6139
      }
    },
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 192,
      y2 = 0
    },
    monster_level = 0,
    notDrawTeam = true,
    mapType = 4,
    hide_fly_fog = true
  },
  [37004] = {
    map_name = "众仙塔一层",
    map_id = 37000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "仙塔传送人1",
        x = 31,
        y = 10,
        icon = 6223,
        alias = "仙塔传送人"
      },
      {
        name = "修士1",
        x = 4,
        y = 23,
        icon = 861101,
        alias = "修士"
      },
      {
        name = "修士2",
        x = 8,
        y = 16,
        icon = 861102,
        alias = "修士"
      },
      {
        name = "修士3",
        x = 19,
        y = 11,
        icon = 861103,
        alias = "修士"
      },
      {
        name = "修士4",
        x = 43,
        y = 11,
        icon = 861104,
        alias = "修士"
      },
      {
        name = "修士5",
        x = 53,
        y = 16,
        icon = 861101,
        alias = "修士"
      },
      {
        name = "修士6",
        x = 58,
        y = 23,
        icon = 871101,
        alias = "修士"
      }
    },
    monster_level = 0
  },
  [37005] = {
    map_name = "众仙塔二层",
    map_id = 37000,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "仙塔传送人2",
        x = 31,
        y = 10,
        icon = 6223,
        alias = "仙塔传送人"
      },
      {
        name = "修士7",
        x = 8,
        y = 16,
        icon = 871102,
        alias = "修士"
      },
      {
        name = "修士8",
        x = 19,
        y = 11,
        icon = 871103,
        alias = "修士"
      },
      {
        name = "修士9",
        x = 43,
        y = 11,
        icon = 871104,
        alias = "修士"
      },
      {
        name = "修士10",
        x = 53,
        y = 16,
        icon = 871105,
        alias = "修士"
      }
    },
    monster_level = 0
  },
  [38017] = {
    map_name = "跨服楼兰城",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "联赛战场接引人",
        x = 62,
        y = 36,
        icon = 6236,
        alias = "战场接引人"
      },
      {
        name = "联赛战场物资员",
        x = 101,
        y = 33,
        icon = 6014,
        alias = "战场物资员"
      }
    }
  },
  [38001] = {
    map_name = "跨服战场",
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "雷霆战神",
        x = 38,
        y = 48,
        icon = 6223
      },
      {
        name = "联赛战场物资员",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      }
    }
  },
  [39002] = {
    map_name = "左方帮派营地",
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    flipX = true,
    npc = {
      {
        name = "帮战使者1",
        x = 25,
        y = 18,
        icon = 6043,
        alias = "帮战使者"
      },
      {
        name = "寨门守卫1",
        x = 56,
        y = 34,
        icon = 6236,
        alias = "寨门守卫"
      },
      {
        name = "战场物资员11",
        x = 10,
        y = 17,
        icon = 6014,
        alias = "战场物资员",
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    unmatch_team = true,
    hide_fly_fog = true
  },
  [39003] = {
    map_name = "右方帮派营地",
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "帮战使者2",
        x = 108,
        y = 18,
        icon = 6043,
        alias = "帮战使者"
      },
      {
        name = "寨门守卫2",
        x = 77,
        y = 34,
        icon = 6236,
        alias = "寨门守卫"
      },
      {
        name = "战场物资员12",
        x = 123,
        y = 17,
        icon = 6014,
        alias = "战场物资员",
        notInSmallMap = true,
        isActiveNPC = true
      }
    },
    unmatch_team = true,
    hide_fly_fog = true
  },
  [39001] = {
    map_name = "矿区",
    map_id = 39001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [18001] = {
    map_name = "雪精圣地",
    map_id = 19002,
    monster_level = 0,
    teleport_x = 42,
    teleport_y = 64,
    npc = {
      {
        name = "雪精碎片1",
        x = 20,
        y = 50,
        icon = 20015,
        alias = "雪精碎片"
      },
      {
        name = "雪精碎片2",
        x = 39,
        y = 45,
        icon = 20015,
        alias = "雪精碎片"
      },
      {
        name = "雪精碎片3",
        x = 25,
        y = 31,
        icon = 20015,
        alias = "雪精碎片"
      },
      {
        name = "雪精碎片4",
        x = 55,
        y = 36,
        icon = 20015,
        alias = "雪精碎片"
      },
      {
        name = "雪精碎片5",
        x = 57,
        y = 21,
        icon = 20015,
        alias = "雪精碎片"
      },
      {
        name = "雪精碎片6",
        x = 32,
        y = 19,
        icon = 20015,
        alias = "雪精碎片"
      },
      {
        name = "雪精碎片7",
        x = 39,
        y = 6,
        icon = 20015,
        alias = "雪精碎片"
      },
      {
        name = "雪精碎片8",
        x = 11,
        y = 10,
        icon = 20015,
        alias = "雪精碎片"
      },
      {
        name = "调皮的雪精",
        x = 12,
        y = 23,
        icon = 20018
      },
      {
        name = "稳重的雪精",
        x = 8,
        y = 43,
        icon = 20018
      }
    },
    unmatch_team = true,
    unswitch_line = true,
    hide_fly_fog = true
  },
  [38018] = {
    map_name = "竞技楼兰城",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "竞技接引人",
        x = 62,
        y = 36,
        icon = 6236
      },
      {
        name = "战场物资员3",
        x = 101,
        y = 33,
        icon = 6014,
        alias = "战场物资员"
      }
    }
  },
  [38019] = {
    map_name = "跨服竞技战场",
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "跨服竞技使者",
        x = 38,
        y = 48,
        icon = 6223,
        alias = "竞技使者"
      },
      {
        name = "战场物资员4",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    unmatch_team = true
  },
  [29002] = {
    map_name = "证道殿",
    map_id = 29002,
    teleport_x = 120,
    teleport_y = 175,
    npc = {
      {
        name = "道虚真人",
        x = 14,
        y = 11,
        icon = 6058
      }
    },
    monster_level = 0
  },
  [29003] = {
    map_name = "证道殿二层",
    map_id = 29002,
    teleport_x = 120,
    teleport_y = 175,
    npc = {
      {
        name = "道虚真人2",
        x = 14,
        y = 11,
        icon = 6058,
        alias = "道虚真人"
      }
    },
    monster_level = 0
  },
  [5005] = {
    map_name = "喜来客栈",
    map_id = 5005,
    teleport_x = 5,
    teleport_y = 5,
    monster_level = 0,
    npc = {
      {
        name = "客栈掌柜",
        x = 15,
        y = 42,
        icon = 6011
      },
      {
        name = "店小二",
        x = 26,
        y = 41,
        icon = 6017,
        notInSmallMap = true
      }
    },
    mapType = 2,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [5007] = {
    map_name = "中秋大胃王",
    map_id = 5005,
    teleport_x = 5,
    teleport_y = 5,
    monster_level = 0,
    npc = {},
    mapType = 2,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [5008] = {
    map_name = "相约元宵客栈",
    map_id = 5005,
    teleport_x = 5,
    teleport_y = 5,
    monster_level = 0,
    npc = {},
    mapType = 2,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [5009] = {
    map_name = "千面酒会",
    map_id = 5005,
    teleport_x = 5,
    teleport_y = 5,
    monster_level = 0,
    npc = {},
    unmatch_team = true,
    hide_fly_fog = true
  },
  [5004] = {
    map_name = "官府",
    map_id = 5004,
    teleport_x = 21,
    teleport_y = 29,
    npc = {
      {
        name = "70",
        x = 38,
        y = 51,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "80",
        x = 23,
        y = 43,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "90",
        x = 44,
        y = 48,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "100",
        x = 30,
        y = 39,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "110",
        x = 51,
        y = 44,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "120",
        x = 37,
        y = 35,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "130",
        x = 58,
        y = 40,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "140",
        x = 44,
        y = 32,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "150",
        x = 65,
        y = 37,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "160",
        x = 51,
        y = 28,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "170",
        x = 72,
        y = 33,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = "180",
        x = 56,
        y = 25,
        icon = 6223,
        notInSmallMap = true,
        alias = "英雄会评判员",
        isActiveNPC = true
      },
      {
        name = CHS[3000844],
        x = 69,
        y = 19,
        icon = 6031
      },
      {
        name = CHS[3000839],
        x = 76,
        y = 23,
        icon = 6011
      },
      {
        name = CHS[7190217],
        x = 33,
        y = 29,
        icon = 6043
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [50000] = {
    map_name = "云霄宫",
    map_id = 50000,
    teleport_x = 42,
    teleport_y = 57,
    monster_level = 0,
    npc = {
      {
        name = "复元仙",
        x = 88,
        y = 25,
        icon = 20071
      },
      {
        name = "百宝仙",
        x = 101,
        y = 38,
        icon = 20072,
        funcLogo = CHS[7270003]
      },
      {
        name = "通灵药王",
        x = 100,
        y = 70,
        icon = 20075,
        funcLogo = CHS[7270000]
      },
      {
        name = "钧天君",
        x = 82,
        y = 50,
        icon = 6418
      },
      {
        name = "魔龙吞天",
        x = 53,
        y = 37,
        icon = 6730
      }
    }
  },
  [50001] = {
    map_name = "南天门",
    map_id = 50001,
    teleport_x = 22,
    teleport_y = 51,
    monster_level = 0,
    npc = {
      {
        name = "太清真君",
        x = 8,
        y = 20,
        icon = 20065
      },
      {
        name = "太玄真君",
        x = 71,
        y = 54,
        icon = 20065
      },
      {
        name = "魔龙之尾",
        x = 22,
        y = 43,
        icon = 6710
      },
      {
        name = "魔龙之爪",
        x = 40,
        y = 20,
        icon = 6720
      }
    }
  },
  [50003] = {
    map_name = "灵霄宝殿",
    map_id = 50003,
    teleport_x = 22,
    teleport_y = 51,
    monster_level = 0,
    npc = {
      {
        name = "天帝",
        x = 57,
        y = 20,
        icon = 22001
      },
      {
        name = "太白金星2",
        x = 34,
        y = 24,
        icon = 22005,
        alias = "太白金星"
      },
      {
        name = "孔宣",
        x = 55,
        y = 36,
        icon = 22003
      },
      {
        name = "李靖",
        x = 24,
        y = 29,
        icon = 22008
      },
      {
        name = "哪吒",
        x = 45,
        y = 41,
        icon = 22009
      },
      {
        name = "雷震子",
        x = 12,
        y = 35,
        icon = 22010
      },
      {
        name = "杨戬",
        x = 33,
        y = 47,
        icon = 22006
      },
      {
        name = "哮天犬",
        x = 31,
        y = 49,
        icon = 22007
      }
    }
  },
  [50004] = {
    map_name = "瑶池",
    map_id = 50004,
    teleport_x = 22,
    teleport_y = 51,
    monster_level = 0,
    npc = {
      {
        name = "西王母2",
        x = 14,
        y = 12,
        icon = 22002,
        alias = "西王母"
      },
      {
        name = "九天玄女",
        x = 21,
        y = 12,
        icon = 22004,
        offsetPos = {x = 25, y = 0}
      }
    }
  },
  [50005] = {
    map_name = "广寒宫",
    map_id = 50005,
    teleport_x = 22,
    teleport_y = 51,
    monster_level = 0,
    npc = {
      {
        name = "嫦娥",
        x = 62,
        y = 17,
        icon = 22011
      },
      {
        name = "吴刚",
        x = 72,
        y = 53,
        icon = 22012
      }
    }
  },
  [17101] = {
    map_name = "花谷幻境一",
    map_id = 17100,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "幻境傀儡1",
        x = 36,
        y = 21,
        icon = 51524,
        notInSmallMap = true,
        alias = CHS[7190255]
      }
    }
  },
  [17102] = {
    map_name = "万花谷",
    map_id = 17100,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {},
    unmatch_team = true,
    unswitch_line = true,
    notShowExitInSmallMap = true,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [17202] = {
    map_name = "花谷幻境二",
    map_id = 17200,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "幻境傀儡2",
        x = 39,
        y = 22,
        icon = 51524,
        notInSmallMap = true,
        alias = CHS[7190255]
      }
    }
  },
  [17302] = {
    map_name = "花谷幻境三",
    map_id = 17300,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "幻境傀儡3",
        x = 38,
        y = 22,
        icon = 51524,
        notInSmallMap = true,
        alias = CHS[7190255]
      }
    }
  },
  [17303] = {
    map_name = "神秘幻境",
    map_id = 17300,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    monster_level = 0,
    notDrawTeam = true
  },
  [17401] = {
    map_name = "卧龙花谷",
    map_id = 17400,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {},
    hide_fly_fog = true
  },
  [27008] = {
    map_name = "幻·大殿",
    map_id = 27002,
    monster_level = 0,
    npc = {
      {
        name = "仙童",
        x = 35,
        y = 18,
        icon = 6302
      }
    },
    hide_fly_fog = true
  },
  [25008] = {
    map_name = "幻·秘境",
    map_id = 25002,
    monster_level = 0,
    teleport_x = 31,
    teleport_y = 24,
    npc = {}
  },
  [25009] = {
    map_name = "幻·仙府",
    map_id = 25000,
    monster_level = 0,
    teleport_x = 31,
    teleport_y = 24,
    npc = {
      {
        name = "幻境—恶仆",
        x = 37,
        y = 30,
        icon = 6245,
        alias = "恶仆"
      },
      {
        name = "幻境—引路童子",
        x = 27,
        y = 19,
        icon = 6069,
        alias = "引路童子"
      }
    }
  },
  [33001] = {
    map_name = "幻·烈火涧",
    map_id = 16000,
    teleport_x = 39,
    teleport_y = 44,
    npc = {},
    exit_level = {},
    monster_level = 35
  },
  [33101] = {
    map_name = "幻·烈火涧西",
    map_id = 16001,
    teleport_x = 23,
    teleport_y = 22,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [33201] = {
    map_name = "幻·烈火涧北",
    map_id = 16001,
    teleport_x = 23,
    teleport_y = 22,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [33301] = {
    map_name = "幻·烈火涧东",
    map_id = 16001,
    teleport_x = 23,
    teleport_y = 22,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [38023] = {
    map_name = "宝物守卫战",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {},
    hide_fly_fog = true
  },
  [38024] = {
    map_name = "月试道楼兰城",
    map_id = 38000,
    teleport_x = 83,
    teleport_y = 46,
    monster_level = 0,
    npc = {
      {
        name = "月试道接引人",
        x = 62,
        y = 36,
        icon = 6236,
        alias = "试道接引人"
      },
      {
        name = "月试道战场物资员",
        x = 101,
        y = 33,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    unmatch_team = true
  },
  [38025] = {
    map_name = "月跨服试道战场",
    map_id = 38001,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {
      {
        name = "月跨服天下道尊",
        x = 38,
        y = 48,
        icon = 6223,
        alias = "天下道尊"
      },
      {
        name = "月跨服战场物资员",
        x = 77,
        y = 63,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    unmatch_team = true
  },
  [28203] = {
    map_name = "赵老板居所-前庭",
    map_id = 28200,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {}
  },
  [28205] = {
    map_name = "朱府-前庭",
    map_id = 28200,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {}
  },
  [28208] = {
    map_name = "陈家-前庭",
    map_id = 28100,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {},
    mapType = 4,
    hide_fly_fog = true
  },
  [28204] = {
    map_name = "赵老板居所-房屋",
    map_id = 28201,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {
      {
        name = "管家5",
        x = 27,
        y = 40,
        icon = 51513,
        alias = "管家"
      }
    },
    hide_fly_fog = true
  },
  [28206] = {
    map_name = "朱府-房屋",
    map_id = 28201,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {
      {
        name = "朱氏",
        x = 33,
        y = 25,
        icon = 51514,
        alias = "朱氏"
      }
    },
    hide_fly_fog = true
  },
  [28209] = {
    map_name = "陈家-房屋",
    map_id = 28101,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {
      {
        name = "陈母",
        x = 33,
        y = 25,
        icon = 6013,
        alias = "陈母"
      }
    },
    mapType = 4,
    hide_fly_fog = true
  },
  [28207] = {
    map_name = "赵府-房屋",
    map_id = 28201,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {
      {
        name = "赵晚来",
        x = 43,
        y = 20,
        icon = 6039
      },
      {
        name = "赵氏",
        x = 33,
        y = 25,
        icon = 6040
      }
    },
    hide_fly_fog = true
  },
  [28210] = {
    map_name = "莫家",
    map_id = 28101,
    teleport_x = 66,
    teleport_y = 39,
    npc = {
      {
        name = "莫父",
        x = 38,
        y = 23,
        icon = 6059
      }
    },
    monster_level = 0,
    mapType = 4,
    hide_fly_fog = true
  },
  [28114] = {
    map_name = "伊撮毛家",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28115] = {
    map_name = "司条腿家",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28107] = {
    map_name = "乐善施居所-前庭",
    map_id = 28100,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {}
  },
  [28108] = {
    map_name = "乐善施居所-房屋",
    map_id = 28101,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {
      {
        name = "管家4",
        x = 23,
        y = 34,
        icon = 6011,
        alias = "管家"
      }
    },
    hide_fly_fog = true
  },
  [28303] = {
    map_name = "钱老板居所-前庭",
    map_id = 28300,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {}
  },
  [28304] = {
    map_name = "钱老板居所-房屋",
    map_id = 28301,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {
      {
        name = "管家6",
        x = 32,
        y = 46,
        icon = 51514,
        alias = "管家"
      }
    },
    hide_fly_fog = true
  },
  [36000] = {
    map_name = "方丈岛",
    map_id = 36000,
    teleport_x = 68,
    teleport_y = 59,
    monster_level = 132,
    npc = {
      {
        name = "船夫10",
        x = 82,
        y = 65,
        icon = 6044,
        alias = "船夫"
      },
      {
        name = "方丈岛守护神",
        x = 16,
        y = 74,
        icon = 6003
      }
    }
  },
  [37100] = {
    map_name = "通天塔顶",
    map_id = 37100,
    teleport_x = 66,
    teleport_y = 39,
    monster_level = 0,
    npc = {
      {
        name = "北斗神将2",
        icon = 6223,
        x = 29,
        y = 10,
        alias = "北斗神将",
        armatureType = 4,
        magicIcon = 2039,
        actionName = "Bottom",
        isFloat = true,
        bottom_image_Zorder = -1,
        defalut_talk = "传送出塔顶"
      },
      {
        name = "开阳星君2",
        icon = 6004,
        x = 16,
        y = 19,
        alias = "开阳星君",
        armatureType = 4,
        magicIcon = 2039,
        actionName = "Bottom",
        isFloat = true,
        bottom_image_Zorder = -1
      },
      {
        name = "摇光星君2",
        icon = 7004,
        x = 47,
        y = 10,
        alias = "摇光星君",
        armatureType = 4,
        magicIcon = 2039,
        actionName = "Bottom",
        isFloat = true,
        bottom_image_Zorder = -1
      },
      {
        name = "天枢星君2",
        icon = 6001,
        x = 62,
        y = 17,
        alias = "天枢星君",
        armatureType = 4,
        magicIcon = 2039,
        actionName = "Bottom",
        isFloat = true,
        bottom_image_Zorder = -1
      },
      {
        name = "天璇星君2",
        icon = 7005,
        x = 64,
        y = 29,
        alias = "天璇星君",
        armatureType = 4,
        magicIcon = 2039,
        actionName = "Bottom",
        isFloat = true,
        bottom_image_Zorder = -1
      },
      {
        name = "天玑星君2",
        icon = 7002,
        x = 51,
        y = 39,
        alias = "天玑星君",
        armatureType = 4,
        magicIcon = 2039,
        actionName = "Bottom",
        isFloat = true,
        bottom_image_Zorder = -1
      },
      {
        name = "天权星君2",
        icon = 6005,
        x = 31,
        y = 39,
        alias = "天权星君",
        armatureType = 4,
        magicIcon = 2039,
        actionName = "Bottom",
        isFloat = true,
        bottom_image_Zorder = -1
      },
      {
        name = "玉衡星君2",
        icon = 6003,
        x = 16,
        y = 33,
        alias = "玉衡星君",
        armatureType = 4,
        magicIcon = 2039,
        actionName = "Bottom",
        bottom_image_Zorder = -1,
        isFloat = true
      }
    }
  },
  [37101] = {
    map_name = "神秘房间",
    map_id = 37101,
    teleport_x = 31,
    teleport_y = 27,
    monster_level = 0,
    npc = {
      {
        name = "北斗星使1",
        icon = 6047,
        x = 35,
        y = 24,
        alias = "北斗星使",
        defalut_talk = "返回挑战通天塔"
      }
    },
    hide_fly_fog = true
  },
  [37110] = {
    map_name = "避暑山庄幻境",
    map_id = 11000,
    teleport_x = 31,
    teleport_y = 27,
    monster_level = 0,
    npc = {},
    hide_fly_fog = true
  },
  [37111] = {
    map_name = "仙粽秘境",
    map_id = 10000,
    teleport_x = 31,
    teleport_y = 27,
    monster_level = 0,
    npc = {},
    mapType = 2,
    hide_fly_fog = true
  },
  [37115] = {
    map_name = "西岐大营",
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {}
  },
  [37116] = {
    map_name = "过去的七宝林",
    map_id = 21001,
    teleport_x = 27,
    teleport_y = 16,
    monster_level = 0,
    npc = {}
  },
  [37117] = {
    map_name = "万仙阵",
    map_id = 14006,
    monster_level = 0,
    teleport_x = 50,
    teleport_y = 44,
    npc = {}
  },
  [37118] = {
    map_name = "混沌之牢",
    map_id = 60006,
    monster_level = 0,
    teleport_x = 20,
    teleport_y = 20,
    npc = {}
  },
  [37119] = {
    map_name = "洪荒之巅",
    map_id = 44000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {}
  },
  [38026] = {
    map_name = "月跨服楼兰城",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "月跨服战场接引人",
        x = 62,
        y = 36,
        icon = 6236,
        alias = "战场接引人"
      },
      {
        name = "战场物资员9",
        x = 101,
        y = 33,
        icon = 6014,
        alias = "战场物资员"
      }
    }
  },
  [40000] = {
    map_name = "冰火秘境",
    map_id = 37101,
    map_obstacle_id = 40000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {},
    mapMagicAlwaysShow = true,
    hide_fly_fog = true
  },
  [40001] = {
    map_name = "门派迷阵",
    map_id = 40001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {},
    hide_fly_fog = true
  },
  [40002] = {
    map_name = "库房",
    map_id = 37101,
    teleport_x = 31,
    teleport_y = 27,
    monster_level = 0,
    npc = {},
    hide_fly_fog = true
  },
  [41000] = {
    map_name = "南部战场",
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    flipX = true,
    npc = {
      {
        name = "战场侦察员1",
        x = 40,
        y = 25,
        icon = 6036,
        alias = "战场侦察员"
      },
      {
        name = "战场物资员7",
        x = 25,
        y = 19,
        icon = 6014,
        alias = "战场物资员"
      },
      {
        name = "雷霆战神1",
        x = 69,
        y = 25,
        icon = 6223,
        alias = "雷霆战神"
      }
    },
    unmatch_team = true,
    hide_fly_fog = true
  },
  [42000] = {
    map_name = "北部战场",
    map_id = 38001,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "战场侦察员2",
        x = 93,
        y = 26,
        icon = 6036,
        alias = "战场侦察员"
      },
      {
        name = "战场物资员8",
        x = 107,
        y = 18,
        icon = 6014,
        alias = "战场物资员"
      },
      {
        name = "雷霆战神2",
        x = 66,
        y = 26,
        icon = 6223,
        alias = "雷霆战神"
      }
    },
    unmatch_team = true,
    hide_fly_fog = true
  },
  [43000] = {
    map_name = "西部战旗区",
    map_id = 44000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    flipX = true,
    npc = {},
    unmatch_team = true,
    hide_fly_fog = true
  },
  [44000] = {
    map_name = "东部战旗区",
    map_id = 44000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {},
    unmatch_team = true,
    hide_fly_fog = true
  },
  [45000] = {
    map_name = "中央战场",
    map_id = 45000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [37102] = {
    map_name = "对决场",
    map_id = 37102,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 96,
      y2 = 0
    },
    monster_level = 0,
    isLimitMove = 1,
    hide_fly_fog = true
  },
  [37128] = {
    map_name = "祈雪台",
    map_id = 37102,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 96,
      y2 = 0
    },
    monster_level = 0,
    sendMoveInterval = 0.3,
    hide_fly_fog = true
  },
  [37103] = {
    map_name = "对决场",
    map_id = 37103,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 96,
      y2 = 0
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [37013] = {
    map_name = "玉露仙池",
    map_id = 37013,
    teleport_x = 98,
    teleport_y = 62,
    npc = {
      {
        name = "仙池妹妹",
        x = 16,
        y = 17,
        icon = 20072
      }
    },
    monster_level = 0,
    unswitch_line_dlg = true,
    unswitch_line = true,
    unmatch_team = true,
    fly_confirm_tips = CHS[5450464],
    sendMoveInterval = 0.3,
    hide_fly_fog = true
  },
  [5010] = {
    map_name = "论道场",
    map_id = 5000,
    map_obstacle_id = 5006,
    teleport_x = 191,
    teleport_y = 83,
    range = {
      x1 = 3768,
      x2 = 80,
      y1 = 1752,
      y2 = 1064
    },
    npc = {
      {
        name = "战场物资员10",
        x = 195,
        y = 80,
        icon = 6014,
        alias = "战场物资员"
      }
    },
    monster_level = 0
  },
  [18002] = {
    map_name = CHS[7190607],
    map_id = 18000,
    monster_level = 0,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "夕阳团领队",
        x = 30,
        y = 82,
        icon = 6044
      },
      {
        name = "屠夫",
        x = 14,
        y = 45,
        icon = 6230
      }
    },
    unmatch_team = true,
    unswitch_line = true,
    unfly = true,
    unfly_tip = "当前地图无法直接离开。",
    hide_fly_fog = true
  },
  [8102] = {
    map_name = CHS[7190610],
    map_id = 8100,
    monster_level = 0,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    hide_fly_fog = true
  },
  [60000] = {
    map_name = CHS[7190617],
    map_id = 60000,
    monster_level = 0,
    teleport_x = 89,
    teleport_y = 67,
    npc = {
      {
        name = "阎罗王",
        x = 134,
        y = 38,
        icon = 20051,
        offsetPos = {x = 20, y = 0}
      },
      {
        name = "崔判官",
        x = 129,
        y = 37,
        icon = 20076,
        offsetPos = {x = -20, y = 0}
      },
      {
        name = "钟馗",
        x = 115,
        y = 28,
        icon = 20077
      },
      {
        name = "地藏王",
        x = 18,
        y = 14,
        icon = 20050
      },
      {
        name = "谛听1",
        x = 21,
        y = 11,
        icon = 31058,
        alias = "谛听",
        offsetPos = {x = 25, y = 10}
      },
      {
        name = "地府守卫1",
        x = 87,
        y = 65,
        icon = 20053,
        alias = "地府守卫",
        offsetPos = {x = -15, y = 0}
      },
      {
        name = "地府守卫2",
        x = 95,
        y = 68,
        icon = 20053,
        alias = "地府守卫",
        offsetPos = {x = 0, y = -10}
      },
      {
        name = "地府守卫3",
        x = 110,
        y = 45,
        icon = 20053,
        alias = "地府守卫",
        offsetPos = {x = -15, y = 0}
      },
      {
        name = "地府守卫4",
        x = 118,
        y = 49,
        icon = 20053,
        alias = "地府守卫",
        offsetPos = {x = 0, y = -10}
      },
      {
        name = "地府守卫5",
        x = 23,
        y = 100,
        icon = 20053,
        alias = "地府守卫",
        offsetPos = {x = 25, y = 0}
      },
      {
        name = "地府守卫6",
        x = 17,
        y = 103,
        icon = 20053,
        alias = "地府守卫",
        offsetPos = {x = 0, y = -10}
      },
      {
        name = "唤灵台",
        x = 78,
        y = 17,
        icon = 51540,
        funcLogo = CHS[7270015]
      },
      {
        name = "九幽药师",
        x = 55,
        y = 46,
        icon = 31053,
        funcLogo = CHS[7270000]
      },
      {
        name = "冥市小妖",
        x = 86,
        y = 90,
        icon = 6049,
        funcLogo = CHS[7270003]
      }
    },
    hide_fly_fog = true
  },
  [60001] = {
    map_name = CHS[7190611],
    map_id = 60001,
    monster_level = 0,
    teleport_x = 43,
    teleport_y = 26,
    npc = {
      {
        name = "船夫11",
        x = 28,
        y = 35,
        icon = 20060,
        alias = "船夫"
      },
      {
        name = "牛头2",
        x = 51,
        y = 21,
        icon = 20056,
        alias = "牛头"
      },
      {
        name = "马面2",
        x = 64,
        y = 28,
        icon = 20057,
        alias = "马面"
      }
    },
    hide_fly_fog = true
  },
  [60002] = {
    map_name = CHS[7190612],
    map_id = 60002,
    monster_level = 0,
    teleport_x = 16,
    teleport_y = 13,
    npc = {
      {
        name = "孟婆",
        x = 59,
        y = 31,
        icon = 20052
      }
    },
    hide_fly_fog = true
  },
  [60003] = {
    map_name = CHS[7190751],
    map_id = 60003,
    monster_level = 0,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    mapType = 2,
    hide_fly_fog = true
  },
  [60004] = {
    map_name = CHS[7100737],
    map_id = 60006,
    monster_level = 0,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    unmatch_team = true,
    unswitch_line = true,
    unfly = true,
    unfly_tip = CHS[7100738],
    hide_fly_fog = true
  },
  [60005] = {
    map_name = CHS[7100736],
    map_id = 60001,
    monster_level = 0,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    unmatch_team = true,
    unswitch_line = true,
    unfly = true,
    unfly_tip = CHS[7100738],
    hide_fly_fog = true
  },
  [61001] = {
    map_name = "地宫1_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61002] = {
    map_name = "地宫2_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61003] = {
    map_name = "地宫3_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61004] = {
    map_name = "地宫4_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61005] = {
    map_name = "地宫5_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61006] = {
    map_name = "地宫6_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61007] = {
    map_name = "地宫7_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61008] = {
    map_name = "地宫8_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61009] = {
    map_name = "地宫9_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61010] = {
    map_name = "地宫10_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61011] = {
    map_name = "地宫11_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61012] = {
    map_name = "地宫12_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61013] = {
    map_name = "地宫13_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61014] = {
    map_name = "地宫14_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61015] = {
    map_name = "地宫15_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61016] = {
    map_name = "地宫16_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61017] = {
    map_name = "地宫17_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61018] = {
    map_name = "地宫18_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61019] = {
    map_name = "地宫19_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61020] = {
    map_name = "地宫20_1",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61021] = {
    map_name = "地宫1_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61022] = {
    map_name = "地宫2_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61023] = {
    map_name = "地宫3_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61024] = {
    map_name = "地宫4_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61025] = {
    map_name = "地宫5_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61026] = {
    map_name = "地宫6_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61027] = {
    map_name = "地宫7_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61028] = {
    map_name = "地宫8_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61029] = {
    map_name = "地宫9_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61030] = {
    map_name = "地宫10_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61031] = {
    map_name = "地宫11_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61032] = {
    map_name = "地宫12_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61033] = {
    map_name = "地宫13_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61034] = {
    map_name = "地宫14_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61035] = {
    map_name = "地宫15_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61036] = {
    map_name = "地宫16_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61037] = {
    map_name = "地宫17_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61038] = {
    map_name = "地宫18_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61039] = {
    map_name = "地宫19_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61040] = {
    map_name = "地宫20_2",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61041] = {
    map_name = "地宫1_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61042] = {
    map_name = "地宫2_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61043] = {
    map_name = "地宫3_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61044] = {
    map_name = "地宫4_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61045] = {
    map_name = "地宫5_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61046] = {
    map_name = "地宫6_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61047] = {
    map_name = "地宫7_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61048] = {
    map_name = "地宫8_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61049] = {
    map_name = "地宫9_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61050] = {
    map_name = "地宫10_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61051] = {
    map_name = "地宫11_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61052] = {
    map_name = "地宫12_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61053] = {
    map_name = "地宫13_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61054] = {
    map_name = "地宫14_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61055] = {
    map_name = "地宫15_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61056] = {
    map_name = "地宫16_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61057] = {
    map_name = "地宫17_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61058] = {
    map_name = "地宫18_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61059] = {
    map_name = "地宫19_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61060] = {
    map_name = "地宫20_3",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    unmatch_team = true
  },
  [61091] = {
    map_name = "地宫夹层",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    map_data_source = 2,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [37104] = {
    map_name = "修炼迷阵",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    map_data_source = 2,
    unmatch_team = true,
    sendMoveInterval = 0.3,
    hide_fly_fog = true
  },
  [37109] = {
    map_name = "火焰迷阵",
    map_id = 61001,
    npc = {},
    monster_level = 0,
    mapType = 3,
    map_data_source = 2,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [37105] = {
    map_name = "丰收之地",
    map_id = 12000,
    teleport_x = 52,
    teleport_y = 35,
    npc = {
      {
        name = "丰收村村民",
        x = 47,
        y = 34,
        icon = 51517
      }
    },
    monster_level = 31,
    hide_fly_fog = true
  },
  [60006] = {
    map_name = "地狱深渊",
    map_id = 60006,
    teleport_x = 41,
    teleport_y = 31,
    npc = {
      {
        name = "地府守卫7",
        x = 56,
        y = 27,
        icon = 20053,
        alias = "地府守卫"
      },
      {
        name = "炼狱冥炎",
        x = 39,
        y = 25,
        icon = 6510
      }
    },
    monster_level = 17,
    hide_fly_fog = true
  },
  [38027] = {
    map_name = "演武场",
    map_id = 38000,
    teleport_x = 20,
    teleport_y = 20,
    monster_level = 0,
    npc = {
      {
        name = "演武大使",
        x = 72,
        y = 38,
        icon = 6236
      }
    },
    unswitch_line_dlg = true
  },
  [37107] = {
    map_name = "帮派后院",
    map_id = 37107,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 48,
      y1 = 0,
      y2 = 72
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [37106] = {
    map_name = CHS[7190857],
    map_id = 19002,
    monster_level = 0,
    teleport_x = 42,
    teleport_y = 64,
    npc = {},
    unmatch_team = true,
    unswitch_line = true,
    hide_fly_fog = true
  },
  [37112] = {
    map_name = "帮派别院",
    map_id = 37107,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = "乐管事",
        x = 88,
        y = 54,
        icon = 6014
      }
    },
    range = {
      x1 = 96,
      x2 = 48,
      y1 = 0,
      y2 = 72
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [37113] = {
    map_name = "幻变林地",
    map_id = 37102,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 96,
      y2 = 0
    },
    monster_level = 0,
    isLimitMove = 1,
    hide_fly_fog = true
  },
  [28109] = {
    map_name = "明察秋毫-前庭",
    map_id = 28100,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 48,
      y1 = 0,
      y2 = 72
    },
    monster_level = 0
  },
  [28110] = {
    map_name = "明察秋毫-房屋",
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    mapType = 2,
    hide_fly_fog = true
  },
  [28111] = {
    map_name = CHS[7100934],
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {
      {
        name = CHS[7100938],
        x = 42,
        y = 17,
        icon = 51513
      }
    },
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28112] = {
    map_name = CHS[7100917],
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28113] = {
    map_name = CHS[7100918],
    map_id = 28101,
    teleport_x = 20,
    teleport_y = 20,
    npc = {},
    range = {
      x1 = 96,
      x2 = 168,
      y1 = 0,
      y2 = 96
    },
    exit_range = {
      ["24_39"] = 1.2,
      ["60_20"] = 1.2
    },
    monster_level = 0,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [60007] = {
    map_name = "地府竞技场",
    map_id = 60006,
    teleport_x = 41,
    teleport_y = 31,
    npc = {
      {
        name = "地府竞技使者",
        x = 56,
        y = 27,
        icon = 20053,
        alias = "地府守卫"
      }
    },
    monster_level = 17,
    hide_fly_fog = true
  },
  [17701] = {
    map_name = "百花秘境",
    map_id = 17700,
    monster_level = 0,
    teleport_x = 46,
    teleport_y = 45,
    npc = {},
    unmatch_team = true,
    unswitch_line = true,
    hide_fly_fog = true
  },
  [19003] = {
    map_name = "雪域秘境",
    map_id = 19002,
    monster_level = 0,
    teleport_x = 41,
    teleport_y = 25,
    npc = {},
    unmatch_team = true,
    unswitch_line = true,
    hide_fly_fog = true
  },
  [36002] = {
    map_name = "断魂窟",
    map_id = 36002,
    teleport_x = 41,
    teleport_y = 45,
    monster_level = 132,
    npc = {
      {
        name = "断魂窟守护神",
        x = 66,
        y = 21,
        icon = 6003
      }
    },
    hide_fly_fog = true
  },
  [50002] = {
    map_name = "弑神殿",
    map_id = 50002,
    teleport_x = 29,
    teleport_y = 37,
    monster_level = 132,
    npc = {
      {
        name = "弑神殿守护神",
        x = 25,
        y = 25,
        icon = 6003
      }
    }
  },
  [60008] = {
    map_name = "火魔深渊",
    map_id = 60006,
    teleport_x = 52,
    teleport_y = 33,
    npc = {},
    monster_level = 0
  },
  [60009] = {
    map_name = "监斩台",
    map_id = 60006,
    teleport_x = 52,
    teleport_y = 33,
    npc = {},
    monster_level = 0,
    hide_fly_fog = true
  },
  [37114] = {
    map_name = "记忆中的大罗宫",
    map_id = 20000,
    teleport_x = 39,
    teleport_y = 35,
    npc = {},
    monster_level = 0,
    notDrawTeam = true
  },
  [37120] = {
    map_name = "通天剑阵",
    map_id = 37000,
    teleport_x = 31,
    teleport_y = 24,
    npc = {},
    monster_level = 0,
    notDrawTeam = true
  },
  [37121] = {
    map_name = "心魔窟",
    map_id = 16100,
    teleport_x = 49,
    teleport_y = 40,
    npc = {},
    monster_level = 0,
    notDrawTeam = true
  },
  [37122] = {
    map_name = "断念之桥",
    map_id = 60002,
    teleport_x = 22,
    teleport_y = 7,
    npc = {},
    monster_level = 0,
    notDrawTeam = true
  },
  [37123] = {
    map_name = CHS[7366707],
    map_id = 37101,
    npc = {
      {
        name = CHS[7366708],
        x = 35,
        y = 24,
        icon = 20062
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [37124] = {
    map_name = "演练等候区",
    map_id = 37102,
    teleport_x = 37,
    teleport_y = 17,
    npc = {
      {
        name = "演练管理员",
        x = 22,
        y = 10,
        icon = 6050
      },
      {
        name = "演练场传送员",
        x = 48,
        y = 24,
        icon = 6045
      }
    },
    range = {
      x1 = 0,
      x2 = 0,
      y1 = 96,
      y2 = 0
    },
    monster_level = 0,
    unswitch_line_dlg = true,
    unfly = true,
    mapType = 4,
    unfly_tip = "当前地图无法直接离开。",
    hide_fly_fog = true
  },
  [37125] = {
    map_name = "护粮演练场",
    map_id = 37125,
    teleport_x = 52,
    teleport_y = 33,
    npc = {},
    monster_level = 0,
    sendMoveInterval = 0.3,
    hideFollowObj = true,
    hide_fly_fog = true
  },
  [37126] = {
    map_name = "上古遗迹",
    map_id = 38000,
    map_obstacle_id = 37126,
    teleport_x = 71,
    teleport_y = 39,
    npc = {},
    monster_level = 0,
    hideFollowObj = true,
    sendMoveInterval = 0.6,
    not_show_follow_magic = true,
    hide_fly_fog = true
  },
  [37129] = {
    map_name = "极寒雪域",
    map_id = 19002,
    monster_level = 0,
    hide_fly_fog = true
  },
  [37130] = {
    map_name = "火怪巢穴",
    map_id = 16100,
    npc = {
      {
        name = CHS[7366722],
        x = 20,
        y = 20,
        icon = 31057
      }
    },
    monster_level = 0,
    hide_fly_fog = true
  },
  [17204] = {
    map_name = "围猎场",
    map_id = 17200,
    monster_level = 0,
    hide_fly_fog = true
  },
  [37134] = {
    map_name = "灵木幻境",
    map_id = 37134,
    monster_level = 0,
    sendMoveInterval = 0.3,
    hideFollowObj = true,
    mapType = 5,
    hide_fly_fog = true
  },
  [1005] = {
    map_name = "飞仙镇",
    map_id = 1000,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true
  },
  [5012] = {
    map_name = "飞仙客栈",
    map_id = 5005,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28122] = {
    map_name = "天字甲号客房",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    hide_fly_fog = true
  },
  [28123] = {
    map_name = "天字乙号客房",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    hide_fly_fog = true
  },
  [28124] = {
    map_name = "天字丙号客房",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    hide_fly_fog = true
  },
  [28125] = {
    map_name = "地字甲号客房",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    hide_fly_fog = true
  },
  [28126] = {
    map_name = "地字乙号客房",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    hide_fly_fog = true
  },
  [28127] = {
    map_name = "地字丙号客房",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    need_hide_doors = {
      ["60_20"] = {
        {
          name = "o:10110houmen_1344_255"
        }
      }
    },
    hide_fly_fog = true
  },
  [28128] = {
    map_name = "虞天仇家",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28129] = {
    map_name = "一眨眼家",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28130] = {
    map_name = "医馆-房屋",
    map_id = 28101,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true,
    hide_fly_fog = true
  },
  [28131] = {
    map_name = "医馆-后院",
    map_id = 28102,
    monster_level = 0,
    queryNpcFunc = "TanAnMgr:queryYsddNpcs",
    unmatch_team = true,
    unswitch_line = true,
    notDrawTeam = true
  },
  [70000] = {
    map_name = "歇马坡",
    map_id = 12000,
    teleport_x = 28,
    teleport_y = 54,
    npc = {
      {
        name = "程维",
        x = 48,
        y = 62,
        icon = 6033
      },
      {
        name = "罗刹寨看门喽啰",
        x = 6,
        y = 24,
        icon = 6201,
        offsetPos = {x = 30, y = 0}
      },
      {
        name = "黑风寨看门喽啰",
        x = 76,
        y = 65,
        icon = 6231,
        offsetPos = {x = -18, y = 0}
      },
      {
        name = "潜龙寨看门喽啰",
        x = 57,
        y = 19,
        icon = 6250,
        serverShow = true
      }
    },
    monster_level = 0,
    unmatch_team = true
  },
  [70001] = {
    map_name = "梁府-前庭",
    map_id = 28300,
    teleport_x = 40,
    teleport_y = 70,
    npc = {
      {
        name = "茅山道士2",
        x = 63,
        y = 55,
        icon = 6042,
        offsetPos = {x = -20, y = 0},
        alias = "茅山道士"
      },
      {
        name = "章管家",
        x = 69,
        y = 55,
        icon = 6010,
        offsetPos = {x = 20, y = 0}
      },
      {
        name = "梁府家丁",
        x = 93,
        y = 52,
        icon = 51517
      },
      {
        name = "梁府厨子",
        x = 34,
        y = 40,
        icon = 6045
      },
      {
        name = "侍女阿梅",
        x = 91,
        y = 37,
        icon = 6040,
        serverShow = true
      },
      {
        name = "夫家管事",
        x = 78,
        y = 24,
        icon = 20006,
        offsetPos = {x = -22, y = 0},
        serverShow = true
      },
      {
        name = "夫家随从",
        x = 84,
        y = 23,
        icon = 6043,
        offsetPos = {x = 22, y = 0},
        serverShow = true
      },
      {
        name = "游魂",
        x = 121,
        y = 48,
        icon = 6305,
        serverShow = true
      }
    },
    monster_level = 0,
    unmatch_team = true,
    mapType = 4
  },
  [70002] = {
    map_name = "罗刹寨",
    map_id = 16000,
    teleport_x = 12,
    teleport_y = 45,
    npc = {
      {
        name = "神秘的罗刹寨喽啰",
        x = 13,
        y = 36,
        icon = 6201,
        serverShow = true
      },
      {
        name = "罗刹寨喽啰",
        x = 22,
        y = 40,
        icon = 6201
      },
      {
        name = "受伤的罗刹寨喽啰",
        x = 22,
        y = 22,
        icon = 6201,
        offsetPos = {x = -18, y = 0}
      }
    },
    monster_level = 0,
    unmatch_team = true
  },
  [70003] = {
    map_name = "罗刹寨石洞",
    map_id = 16001,
    teleport_x = 20,
    teleport_y = 42,
    monster_level = 0,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [70004] = {
    map_name = "黑风寨",
    map_id = 18000,
    teleport_x = 47,
    teleport_y = 65,
    npc = {
      {
        name = "黑风寨喽啰",
        x = 11,
        y = 34,
        icon = 6230
      },
      {
        name = "奇怪的黑风寨喽啰",
        x = 49,
        y = 82,
        icon = 6230,
        serverShow = true
      },
      {
        name = "黑风寨寨主",
        x = 46,
        y = 23,
        icon = 6252
      },
      {
        name = "黑风寨师爷",
        x = 43,
        y = 10,
        icon = 6249
      }
    },
    monster_level = 0,
    unmatch_team = true,
    mask_opacity = 77
  },
  [70005] = {
    map_name = "潜龙寨",
    map_id = 26000,
    teleport_x = 19,
    teleport_y = 43,
    npc = {
      {
        name = "潜龙寨喽啰",
        x = 37,
        y = 22,
        icon = 6250
      },
      {
        name = "铁憨憨",
        x = 61,
        y = 11,
        icon = 6005
      },
      {
        name = "潜龙寨寨主",
        x = 38,
        y = 12,
        icon = 51526,
        serverShow = true
      }
    },
    monster_level = 0,
    unmatch_team = true
  },
  [70006] = {
    map_name = "潜龙寨仓库",
    map_id = 28101,
    teleport_x = 29,
    teleport_y = 36,
    monster_level = 0,
    unmatch_team = true,
    mapType = 4,
    hide_fly_fog = true
  },
  [70007] = {
    map_name = "潜龙寨暗库",
    map_id = 14006,
    teleport_x = 9,
    teleport_y = 15,
    monster_level = 0,
    unmatch_team = true
  },
  [70008] = {
    map_name = "潜龙寨后山山洞",
    map_id = 10500,
    teleport_x = 61,
    teleport_y = 45,
    npc = {
      {
        name = "寨主的妹妹",
        x = 38,
        y = 20,
        icon = 7004,
        serverShow = true
      },
      {
        name = "梁飞燕",
        x = 38,
        y = 20,
        icon = 7004,
        serverShow = true
      },
      {
        name = "寨主的姐姐",
        x = 45,
        y = 24,
        icon = 6087,
        serverShow = true
      },
      {
        name = "侍女阿珠",
        x = 45,
        y = 24,
        icon = 6087,
        serverShow = true
      },
      {
        name = "聂潜龙",
        x = 31,
        y = 20,
        icon = 51526,
        serverShow = true
      },
      {
        name = "聂潜龙的尸体",
        x = 31,
        y = 20,
        icon = 51526,
        offsetPos = {x = -28, y = 0},
        serverShow = true
      }
    },
    monster_level = 0,
    unmatch_team = true,
    hide_fly_fog = true
  },
  [70009] = {
    map_name = "梁府-房屋",
    map_id = 28301,
    npc = {
      {
        name = "梁老爷",
        x = 59,
        y = 16,
        icon = 6038
      },
      {
        name = "侍女阿梅2",
        x = 43,
        y = 36,
        icon = 6040,
        alias = "侍女阿梅",
        serverShow = true
      }
    },
    monster_level = 0,
    unmatch_team = true,
    mapType = 4,
    hide_fly_fog = true
  },
  [3003] = {
    map_name = "终南山之巅",
    map_id = 3000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "风之力",
        x = 51,
        y = 7,
        icon = 6285,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "雷之力",
        x = 55,
        y = 32,
        icon = 6172,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "少年雷震子",
        x = 13,
        y = 34,
        icon = 22010,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "云中子上仙分身",
        x = 20,
        y = 31,
        icon = 6053,
        notInSmallMap = true,
        isActiveNPC = true
      }
    }
  },
  [12002] = {
    map_name = "终南山迷阵",
    map_id = 12000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "姬昌",
        x = 43,
        y = 33,
        icon = 20009
      },
      {
        name = "殷破败",
        x = 60,
        y = 43,
        icon = 6245,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "雷开",
        x = 57,
        y = 46,
        icon = 6248,
        notInSmallMap = true,
        isActiveNPC = true
      },
      {
        name = "少年雷震子2",
        x = 47,
        y = 37,
        icon = 22010,
        alias = "少年雷震子",
        notInSmallMap = true,
        isActiveNPC = true
      }
    }
  },
  [14011] = {
    map_name = "终南山福地",
    map_id = 14000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "云中子上仙",
        x = 31,
        y = 19,
        icon = 6053
      }
    }
  },
  [14012] = {
    map_name = "盘虬迷洞",
    map_id = 14002,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    hide_fly_fog = true
  },
  [37131] = {
    map_name = "智者宝塔一层",
    map_id = 37101,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "宝塔管理员1",
        alias = "宝塔管理员",
        x = 47,
        y = 17,
        icon = 6058
      }
    },
    hide_fly_fog = true
  },
  [37132] = {
    map_name = "智者宝塔二层",
    map_id = 37101,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "宝塔管理员2",
        alias = "宝塔管理员",
        x = 47,
        y = 17,
        icon = 6058
      }
    },
    hide_fly_fog = true
  },
  [37133] = {
    map_name = "智者宝塔顶层",
    map_id = 37101,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "宝塔管理员3",
        alias = "宝塔管理员",
        x = 47,
        y = 17,
        icon = 6058
      }
    },
    hide_fly_fog = true
  },
  [9004] = {
    map_name = "陈塘关海滨",
    map_id = 9000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "陈塘关渔民",
        alias = "陈塘关渔民",
        x = 56,
        y = 34,
        icon = 6044
      }
    }
  },
  [27009] = {
    map_name = "东海海底",
    map_id = 27000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {}
  },
  [23002] = {
    map_name = "陈塘关",
    map_id = 23000,
    monster_level = 0,
    teleport_x = 17,
    teleport_y = 44,
    npc = {
      {
        name = "李靖2",
        alias = "李靖",
        x = 47,
        y = 66,
        icon = 6031
      },
      {
        name = "陈塘关守军1",
        alias = "陈塘关守军",
        x = 27,
        y = 48,
        icon = 6050,
        isActiveNPC = true
      },
      {
        name = "陈塘关守军2",
        alias = "陈塘关守军",
        x = 36,
        y = 51,
        icon = 6050,
        isActiveNPC = true
      },
      {
        name = "陈塘关守军3",
        alias = "陈塘关守军",
        x = 62,
        y = 63,
        icon = 6050,
        isActiveNPC = true
      },
      {
        name = "陈塘关守军4",
        alias = "陈塘关守军",
        x = 69,
        y = 67,
        icon = 6050,
        isActiveNPC = true
      },
      {
        name = "陈塘关守军5",
        alias = "陈塘关守军",
        x = 77,
        y = 71,
        icon = 6050,
        isActiveNPC = true
      }
    }
  }
}
