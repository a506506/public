return {
  {
    class_id = 10089,
    x = 49,
    y = 41,
    cy = -3,
    cx = -12,
    dir = 0
  },
  {
    class_id = 10071,
    x = 41,
    y = 42,
    cy = 10,
    cx = 4,
    dir = 1
  },
  {
    class_id = 10068,
    x = 36,
    y = 19,
    cy = -9,
    cx = -11,
    dir = 1
  },
  {
    class_id = 10068,
    x = 36,
    y = 34,
    cy = 2,
    cx = 9,
    dir = 0
  },
  {
    class_id = 10068,
    x = 57,
    y = 23,
    cy = 12,
    cx = 11,
    dir = 0
  },
  {
    class_id = 10068,
    x = 47,
    y = 28,
    cy = 9,
    cx = 11,
    dir = 0
  },
  {
    class_id = 10109,
    x = 53,
    y = 24,
    cy = -1,
    cx = -8,
    dir = 0
  },
  {
    class_id = 10109,
    x = 45,
    y = 28,
    cy = 5,
    cx = 8,
    dir = 0
  },
  {
    class_id = 10109,
    x = 38,
    y = 32,
    cy = 11,
    cx = 0,
    dir = 0
  },
  {
    class_id = 10109,
    x = 31,
    y = 35,
    cy = -7,
    cx = -7,
    dir = 0
  },
  {
    class_id = 10044,
    x = 44,
    y = 15,
    cy = 9,
    cx = -9,
    dir = 1
  },
  {
    class_id = 10108,
    x = 42,
    y = 42,
    cy = 3,
    cx = -2,
    dir = 1
  },
  {
    class_id = 10117,
    x = 56,
    y = 33,
    cy = -3,
    cx = -3,
    dir = 0
  },
  {
    class_id = 10108,
    x = 64,
    y = 31,
    cy = 2,
    cx = -6,
    dir = 1
  },
  {
    class_id = 10059,
    x = 68,
    y = 26,
    cy = 9,
    cx = 8,
    dir = 1
  },
  {
    class_id = 10068,
    x = 48,
    y = 35,
    cy = 9,
    cx = -6,
    dir = 1
  }
}
