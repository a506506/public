return {
  ["iPhone13,1"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone13,2"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone13,3"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone13,4"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone12,1"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone12,3"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone12,5"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone10,3"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone10,6"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone11,1"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone11,2"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone11,4"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone11,6"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPhone11,8"] = {
    scale = 1,
    x = 0,
    y = 10,
    width = 1320,
    height = 640,
    designWidth = 1428,
    designHeight = 660
  },
  ["iPad8,1"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1080,
    height = 754,
    designWidth = 1100,
    designHeight = 768
  },
  ["iPad8,2"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1080,
    height = 754,
    designWidth = 1100,
    designHeight = 768
  },
  ["iPad8,3"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1080,
    height = 754,
    designWidth = 1100,
    designHeight = 768
  },
  ["iPad8,4"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1080,
    height = 754,
    designWidth = 1100,
    designHeight = 768
  },
  ["iPad8,5"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1004,
    height = 754,
    designWidth = 1024,
    designHeight = 768
  },
  ["iPad8,6"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1004,
    height = 754,
    designWidth = 1024,
    designHeight = 768
  },
  ["iPad8,7"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1004,
    height = 754,
    designWidth = 1024,
    designHeight = 768
  },
  ["iPad8,8"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1004,
    height = 754,
    designWidth = 1024,
    designHeight = 768
  },
  ["iPad13,1"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1084,
    height = 754,
    designWidth = 1104,
    designHeight = 768
  },
  ["iPad13,2"] = {
    scale = 1,
    x = 0,
    y = 7,
    width = 1084,
    height = 754,
    designWidth = 1104,
    designHeight = 768
  },
  ["PAAM00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["PAAT00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["PACM00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["PACT00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["PBAT00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["PBAM00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["PBAM10"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["CPH1831"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["CPH1833"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["CPH1803"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["CPH1851"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["vivo X21"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo X21A"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo X21i"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo X21i A"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo X21UD"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo X21UD A"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo Z1"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo Z1A"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo Z1i"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["vivo Z1i A"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1236,
    height = 640,
    designWidth = 1352,
    designHeight = 640,
    checkWidth = 2196
  },
  ["ANE-AL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["ANE-TL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["COL-AL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["COL-AL10"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["COL-TL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["COL-TL10"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1248,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["CLT-AL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1226,
    height = 640,
    designWidth = 1330,
    designHeight = 640
  },
  ["CLT-AL01"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1226,
    height = 640,
    designWidth = 1330,
    designHeight = 640
  },
  ["CLT-TL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1226,
    height = 640,
    designWidth = 1330,
    designHeight = 640
  },
  ["CLT-TL01"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1226,
    height = 640,
    designWidth = 1330,
    designHeight = 640
  },
  ["EML-AL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1226,
    height = 640,
    designWidth = 1330,
    designHeight = 640
  },
  ["EML-TL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1226,
    height = 640,
    designWidth = 1330,
    designHeight = 640
  },
  ["HLK-AL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1338,
    height = 640,
    designWidth = 1386,
    designHeight = 640
  },
  ["COR-AL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1283,
    height = 640,
    designWidth = 1387,
    designHeight = 640
  },
  ["COR-AL10"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1283,
    height = 640,
    designWidth = 1387,
    designHeight = 640
  },
  ["MI 8"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1224,
    height = 640,
    designWidth = 1332,
    designHeight = 640
  },
  ["dipper"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1224,
    height = 640,
    designWidth = 1332,
    designHeight = 640
  },
  ["MI 8 SE"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1226,
    height = 640,
    designWidth = 1330,
    designHeight = 640
  },
  ["sirius"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1226,
    height = 640,
    designWidth = 1330,
    designHeight = 640
  },
  ["ursa"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1224,
    height = 640,
    designWidth = 1332,
    designHeight = 640
  },
  ["Redmi 6 Pro"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1243,
    height = 640,
    designWidth = 1351,
    designHeight = 640
  },
  ["sakura"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1243,
    height = 640,
    designWidth = 1351,
    designHeight = 640
  },
  ["DE106"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1225,
    height = 640,
    designWidth = 1329,
    designHeight = 640
  },
  ["vivo NEX"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1332,
    height = 640,
    designWidth = 1372,
    designHeight = 640
  },
  ["vivo NEX S"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1332,
    height = 640,
    designWidth = 1372,
    designHeight = 640
  },
  ["vivo NEX A"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1332,
    height = 640,
    designWidth = 1372,
    designHeight = 640
  },
  ["V1836A"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1406,
    height = 640,
    designWidth = 1458,
    designHeight = 640
  },
  ["PAFM00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1338,
    height = 640,
    designWidth = 1386,
    designHeight = 640
  },
  ["PCAM00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1320,
    height = 640,
    designWidth = 1386,
    designHeight = 640
  },
  ["PCKM00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1380,
    height = 640,
    designWidth = 1420,
    designHeight = 640
  },
  ["TNY-AL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1328,
    height = 640,
    designWidth = 1388,
    designHeight = 640
  },
  ["TNY-TL00"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1328,
    height = 640,
    designWidth = 1388,
    designHeight = 640
  },
  ["MI 8 Lite"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1252,
    height = 640,
    designWidth = 1352,
    designHeight = 640
  },
  ["MIX 3"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1350,
    height = 640,
    designWidth = 1386,
    designHeight = 640
  },
  ["Redmi K20 Pro"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1346,
    height = 640,
    designWidth = 1386,
    designHeight = 640
  },
  ["Redmi K20 Pro Premium"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1346,
    height = 640,
    designWidth = 1386,
    designHeight = 640
  },
  ["Redmi K20 Pro Premium Edition"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1346,
    height = 640,
    designWidth = 1386,
    designHeight = 640
  },
  ["16th Plus"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1232,
    height = 640,
    designWidth = 1280,
    designHeight = 640
  },
  ["16th"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1232,
    height = 640,
    designWidth = 1280,
    designHeight = 640
  },
  ["SM-G9550"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1268,
    height = 640,
    designWidth = 1316,
    designHeight = 640
  },
  ["SM-G9500"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1268,
    height = 640,
    designWidth = 1316,
    designHeight = 640
  },
  ["GM1910"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1338,
    height = 640,
    designWidth = 1386,
    designHeight = 640
  },
  ["SHARK KLE-A0"] = {
    scale = 1,
    x = 0,
    y = 0,
    width = 1374,
    height = 640,
    designWidth = 1422,
    designHeight = 640
  }
}
