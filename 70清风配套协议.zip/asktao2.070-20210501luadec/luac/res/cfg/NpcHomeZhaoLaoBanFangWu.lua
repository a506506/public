return {
  {
    class_id = 10109,
    x = 20,
    y = 34,
    dir = 0,
    cx = 3,
    cy = -9
  },
  {
    class_id = 10085,
    x = 70,
    y = 38,
    dir = 1,
    cx = 10,
    cy = 2
  },
  {
    class_id = 10068,
    x = 64,
    y = 38,
    dir = 1,
    cx = -12,
    cy = 11
  },
  {
    class_id = 10069,
    x = 55,
    y = 41,
    dir = 1,
    cx = -10,
    cy = -10
  },
  {
    class_id = 10075,
    x = 42,
    y = 47,
    dir = 0,
    cx = -11,
    cy = -1
  },
  {
    class_id = 10071,
    x = 46,
    y = 48,
    dir = 1,
    cx = -4,
    cy = -10
  },
  {
    class_id = 10109,
    x = 51,
    y = 46,
    dir = 1,
    cx = 5,
    cy = -7
  },
  {
    class_id = 10109,
    x = 46,
    y = 49,
    dir = 1,
    cx = -11,
    cy = -1
  },
  {
    class_id = 10080,
    x = 71,
    y = 29,
    dir = 0,
    cx = 5,
    cy = -1
  },
  {
    class_id = 10067,
    x = 43,
    y = 42,
    dir = 0,
    cx = -9,
    cy = -4
  },
  {
    class_id = 10067,
    x = 59,
    y = 31,
    dir = 0,
    cx = 9,
    cy = 0
  },
  {
    class_id = 10109,
    x = 78,
    y = 35,
    dir = 1,
    cx = -2,
    cy = -8
  },
  {
    class_id = 10108,
    x = 56,
    y = 21,
    dir = 0,
    cx = -11,
    cy = -5
  },
  {
    class_id = 10067,
    x = 51,
    y = 26,
    dir = 0,
    cx = 1,
    cy = 10
  },
  {
    class_id = 10067,
    x = 61,
    y = 21,
    dir = 0,
    cx = 1,
    cy = 9
  },
  {
    class_id = 10090,
    x = 30,
    y = 23,
    dir = 0,
    cx = 5,
    cy = 11
  },
  {
    class_id = 10093,
    x = 24,
    y = 26,
    dir = 0,
    cx = -6,
    cy = 10
  },
  {
    class_id = 10067,
    x = 70,
    y = 26,
    dir = 0,
    cx = -4,
    cy = 10
  },
  {
    class_id = 10067,
    x = 37,
    y = 23,
    dir = 1,
    cx = -3,
    cy = 8
  },
  {
    class_id = 10129,
    x = 30,
    y = 32,
    dir = 0,
    cx = -10,
    cy = 11
  },
  {
    class_id = 10129,
    x = 36,
    y = 32,
    dir = 0,
    cx = 3,
    cy = -4
  },
  {
    class_id = 10129,
    x = 36,
    y = 28,
    dir = 0,
    cx = 2,
    cy = 4
  },
  {
    class_id = 10129,
    x = 29,
    y = 28,
    dir = 0,
    cx = 1,
    cy = -3
  },
  {
    class_id = 10063,
    x = 33,
    y = 30,
    dir = 0,
    cx = -12,
    cy = 5
  },
  {
    class_id = 10059,
    x = 82,
    y = 30,
    dir = 1,
    cx = 9,
    cy = 2
  },
  {
    class_id = 10047,
    x = 40,
    y = 18,
    dir = 0,
    cx = 7,
    cy = -1
  },
  {
    class_id = 10044,
    x = 48,
    y = 14,
    dir = 0,
    cx = 6,
    cy = 8
  },
  {
    class_id = 10132,
    x = 16,
    y = 30,
    dir = 0,
    cx = -9,
    cy = 6
  },
  {floor_index = 2}
}
