return {
  {
    field = "resist_forgotten",
    chs = "抗遗忘"
  },
  {
    field = "resist_poison",
    chs = "抗中毒"
  },
  {
    field = "resist_frozen",
    chs = "抗冰冻"
  },
  {
    field = "resist_sleep",
    chs = "抗昏睡"
  },
  {
    field = "resist_confusion",
    chs = "抗混乱"
  },
  {field = "phy_absorb", chs = "抗物理"},
  {field = "mag_absorb", chs = "抗法术"},
  {
    field = "resist_metal",
    chs = "抗金"
  },
  {
    field = "resist_wood",
    chs = "抗木"
  },
  {
    field = "resist_water",
    chs = "抗水"
  },
  {
    field = "resist_fire",
    chs = "抗火"
  },
  {
    field = "resist_earth",
    chs = "抗土"
  },
  {
    field = "double_hit_rate",
    chs = "物理连击率"
  },
  {
    field = "counter_attack_rate",
    chs = "反击率"
  },
  {
    field = "damage_sel_rate",
    chs = "反震率"
  },
  {
    field = "stunt_rate",
    chs = "物理必杀率"
  },
  {
    field = "double_hit",
    chs = "物理连击数"
  },
  {
    field = "counter_attack",
    chs = "反击数"
  },
  {
    field = "mag_dodge",
    chs = "几率躲避攻击",
    isShow = false
  },
  {
    field = "penetrate_rate",
    chs = "破防率",
    isShow = false
  },
  {
    field = "penetrate",
    chs = "破防",
    isShow = false
  },
  {field = "damage_sel", chs = "反震度"},
  {field = "mag_power", chs = "法伤"},
  {
    field = "mstunt_rate",
    chs = "法术必杀率"
  },
  {
    field = "ignore_all_resist_except",
    chs = "忽视所有抗异常"
  },
  {
    field = "ignore_all_resist_polar",
    chs = "忽视所有抗性"
  },
  {
    field = "super_forgotten",
    chs = "强力遗忘"
  },
  {
    field = "super_poison",
    chs = "强力中毒"
  },
  {
    field = "super_frozen",
    chs = "强力冰冻"
  },
  {
    field = "super_sleep",
    chs = "强力昏睡"
  },
  {
    field = "super_confusion",
    chs = "强力混乱"
  },
  {field = "max_life", chs = "气血"},
  {field = "max_mana", chs = "法力"},
  {field = "phy_power", chs = "物伤"},
  {field = "speed", chs = "速度"},
  {field = "def", chs = "防御"}
}
