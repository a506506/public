return {
  {
    class_id = 10095,
    x = 73,
    y = 22,
    dir = 1,
    cx = -8,
    cy = 6
  },
  {
    class_id = 10095,
    x = 49,
    y = 10,
    dir = 1,
    cx = -3,
    cy = 3
  },
  {
    class_id = 10095,
    x = 38,
    y = 10,
    dir = 0,
    cx = 4,
    cy = 1
  },
  {
    class_id = 10095,
    x = 14,
    y = 22,
    dir = 0,
    cx = 9,
    cy = 8
  },
  {
    class_id = 10095,
    x = 27,
    y = 15,
    dir = 0,
    cx = -10,
    cy = -11
  },
  {
    class_id = 10066,
    x = 28,
    y = 20,
    dir = 0,
    cx = 10,
    cy = 11
  },
  {
    class_id = 10131,
    x = 67,
    y = 26,
    dir = 1,
    cx = 6,
    cy = 5
  },
  {
    class_id = 10043,
    x = 32,
    y = 25,
    dir = 0,
    cx = 8,
    cy = 4
  }
}
