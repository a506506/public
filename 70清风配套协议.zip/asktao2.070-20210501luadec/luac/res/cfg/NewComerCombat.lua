return {
  ["chatTip"] = CHS[3001351],
  ["hasWaitTime"] = false,
  ["isChechSkill"] = false,
  ["skills"] = {
    "B1",
    "B2",
    "B3",
    "B4",
    CHS[3001352],
    "B5"
  },
  ["skillCmdDesc"] = {
    ["B3"] = CHS[3001353],
    ["B4"] = CHS[3001354],
    ["B5"] = CHS[6000386],
    [CHS[3001352]] = CHS[3001355]
  },
  ["mapIndex"] = 1,
  ["mapInfo"] = {
    [1] = {
      mapId = 10000,
      x = 28,
      y = 17
    },
    [2] = {
      mapId = 14000,
      x = 37,
      y = 15
    },
    [3] = {
      mapId = 15000,
      x = 49,
      y = 16
    },
    [4] = {
      mapId = 13000,
      x = 27,
      y = 22
    },
    [5] = {
      mapId = 16000,
      x = 23,
      y = 39
    }
  },
  ["opponents"] = {
    [2] = {
      icon = 6260,
      id = 2,
      org_icon = 6260,
      suit_light_effect = 0,
      pos = 2,
      suit_icon = 0,
      leader = 0,
      type = 2,
      weapon_icon = 0,
      name = CHS[3001356],
      owner_id = 0
    },
    [3] = {
      icon = 6258,
      id = 3,
      org_icon = 6258,
      suit_light_effect = 0,
      pos = 3,
      suit_icon = 0,
      leader = 1,
      type = 2,
      weapon_icon = 0,
      name = CHS[3001357],
      owner_id = 0
    },
    [4] = {
      icon = 6260,
      id = 4,
      org_icon = 6260,
      suit_light_effect = 0,
      pos = 4,
      suit_icon = 0,
      leader = 0,
      type = 2,
      weapon_icon = 0,
      name = CHS[3001356],
      owner_id = 0
    },
    [5] = {
      icon = 6260,
      id = 5,
      org_icon = 6260,
      suit_light_effect = 0,
      pos = 5,
      suit_icon = 0,
      leader = 0,
      type = 2,
      weapon_icon = 0,
      name = CHS[3001356],
      owner_id = 0
    },
    [1] = {
      icon = 6260,
      id = 6,
      org_icon = 6260,
      suit_light_effect = 0,
      pos = 1,
      suit_icon = 0,
      leader = 0,
      type = 2,
      weapon_icon = 0,
      name = CHS[3001356],
      owner_id = 0
    }
  },
  ["friends"] = {
    [1] = {
      mana = 16000,
      icon = {6001, 7001},
      id = 11,
      max_mana = 16000,
      max_life = 91200,
      suit_light_effect = 0,
      life = 91200,
      org_icon = 6001,
      pos = 5,
      suit_icon = {861301, 871301},
      leader = 0,
      type = 32,
      weapon_icon = 1168,
      name = CHS[3001358],
      owner_id = 13,
      polar = 1
    },
    [2] = {
      mana = 16000,
      icon = {6002, 7002},
      id = 12,
      max_mana = 16000,
      max_life = 91200,
      suit_light_effect = 0,
      life = 91200,
      org_icon = 6002,
      pos = 4,
      suit_icon = {871302, 861302},
      leader = 0,
      type = 32,
      weapon_icon = 1166,
      name = CHS[3001359],
      owner_id = 13,
      polar = 2
    },
    [3] = {
      mana = 20000,
      icon = {6003, 7003},
      id = 13,
      max_mana = 20000,
      max_life = 169000,
      suit_light_effect = 0,
      life = 169000,
      org_icon = 6003,
      pos = 3,
      suit_icon = {871303, 861303},
      leader = 1,
      type = 1,
      weapon_icon = 1169,
      name = CHS[3001360],
      owner_id = 0,
      polar = 3
    },
    [4] = {
      mana = 16000,
      icon = {6004, 7004},
      id = 14,
      max_mana = 16000,
      max_life = 91200,
      suit_light_effect = 0,
      life = 91200,
      org_icon = 6004,
      pos = 2,
      suit_icon = {861304, 871304},
      leader = 0,
      type = 32,
      weapon_icon = 1167,
      name = CHS[3001361],
      owner_id = 13,
      polar = 4
    },
    [5] = {
      mana = 16000,
      icon = {6005, 7005},
      id = 15,
      max_mana = 16000,
      max_life = 91200,
      suit_light_effect = 0,
      life = 91200,
      org_icon = 6005,
      pos = 1,
      suit_icon = {861305, 871305},
      leader = 0,
      type = 32,
      weapon_icon = 1170,
      name = CHS[3001362],
      owner_id = 13,
      polar = 5
    }
  },
  [1] = {
    round = 0,
    curIndex = 1,
    {
      id = 13,
      content = CHS[3001363]
    },
    {
      id = 3,
      content = CHS[3001364]
    },
    {
      id = 13,
      content = CHS[3001365]
    },
    {
      id = 3,
      content = CHS[3001366]
    }
  },
  [2] = {
    round = 1,
    effect = {
      114,
      133,
      165,
      173,
      214,
      15,
      65,
      501
    },
    prepare = {guideId = 10001},
    actions = {
      [1] = {
        ["charId"] = 13,
        ["skill"] = "B5",
        ["opId"] = 3,
        ["op"] = 3,
        ["tip"] = CHS[3001367],
        ["para"] = "<B5>",
        [1] = {
          type = 7,
          id = 13,
          hitter_id = 13,
          point = -3500,
          effect_no = 0,
          damage_type = 2
        },
        [2] = {
          type = 2,
          count = 5,
          {
            hitter_id = 13,
            damage_type = 2,
            id = 2,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 2,
            id = 3,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 2,
            id = 4,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 2,
            id = 5,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [3] = {
          type = 3,
          id = 2,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [4] = {
          type = 3,
          id = 3,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [5] = {
          type = 3,
          id = 4,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [6] = {
          type = 3,
          id = 5,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [7] = {
          type = 3,
          id = 6,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [8] = {
          type = 12,
          id = 13,
          effect_no = 8013,
          name = "番天印"
        }
      },
      [2] = {
        ["charId"] = 13,
        ["skill"] = "B5",
        ["opId"] = 3,
        ["op"] = 3,
        ["para"] = "<B5>",
        [1] = {
          type = 2,
          count = 5,
          {
            hitter_id = 13,
            damage_type = 2,
            id = 2,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 2,
            id = 3,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 2,
            id = 4,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 2,
            id = 5,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 2,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [3] = {
          type = 3,
          id = 3,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [4] = {
          type = 3,
          id = 4,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [5] = {
          type = 3,
          id = 5,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        },
        [6] = {
          type = 3,
          id = 6,
          hitter_id = 13,
          point = -math.random(30500, 31500),
          effect_no = 0,
          damage_type = 2
        }
      },
      [3] = {
        ["charId"] = 3,
        ["skill"] = CHS[3001352],
        ["opId"] = 13,
        ["op"] = 3,
        ["tip"] = CHS[3001368],
        [1] = {
          type = 2,
          count = 5,
          {
            hitter_id = 3,
            damage_type = 1,
            id = 13,
            missed = 1
          },
          {
            hitter_id = 3,
            damage_type = 1,
            id = 11,
            missed = 1
          },
          {
            hitter_id = 3,
            damage_type = 1,
            id = 12,
            missed = 1
          },
          {
            hitter_id = 3,
            damage_type = 1,
            id = 14,
            missed = 1
          },
          {
            hitter_id = 3,
            damage_type = 1,
            id = 15,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 11,
          hitter_id = 3,
          point = -math.random(15500, 16500),
          effect_no = 0,
          damage_type = 4097
        },
        [3] = {
          type = 3,
          id = 12,
          hitter_id = 3,
          point = -math.random(15500, 16500),
          effect_no = 0,
          damage_type = 4097
        },
        [4] = {
          type = 3,
          id = 13,
          hitter_id = 3,
          point = -math.random(27500, 28500),
          effect_no = 0,
          damage_type = 4097
        },
        [5] = {
          type = 3,
          id = 14,
          hitter_id = 3,
          point = -math.random(15500, 16500),
          effect_no = 0,
          damage_type = 4097
        },
        [6] = {
          type = 12,
          id = 15,
          effect_no = 8015,
          name = "定海珠"
        },
        [7] = {type = 6, id = 13}
      },
      [4] = {
        ["charId"] = 11,
        ["skill"] = "B5",
        ["opId"] = 3,
        ["op"] = 3,
        ["tip"] = CHS[3001369],
        ["para"] = "<B5>",
        [1] = {
          type = 2,
          count = 5,
          {
            hitter_id = 11,
            damage_type = 2,
            id = 2,
            missed = 1
          },
          {
            hitter_id = 11,
            damage_type = 2,
            id = 3,
            missed = 1
          },
          {
            hitter_id = 11,
            damage_type = 2,
            id = 4,
            missed = 1
          },
          {
            hitter_id = 11,
            damage_type = 2,
            id = 5,
            missed = 1
          },
          {
            hitter_id = 11,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 2,
          hitter_id = 11,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [3] = {
          type = 3,
          id = 3,
          hitter_id = 11,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [4] = {
          type = 3,
          id = 4,
          hitter_id = 11,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [5] = {
          type = 3,
          id = 5,
          hitter_id = 11,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [6] = {
          type = 3,
          id = 6,
          hitter_id = 11,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        }
      },
      [5] = {
        ["charId"] = 14,
        ["skill"] = "B5",
        ["opId"] = 3,
        ["op"] = 3,
        ["tip"] = CHS[3001370],
        ["para"] = "<B5>",
        [1] = {
          type = 2,
          count = 5,
          {
            hitter_id = 14,
            damage_type = 2,
            id = 2,
            missed = 1
          },
          {
            hitter_id = 14,
            damage_type = 2,
            id = 3,
            missed = 1
          },
          {
            hitter_id = 14,
            damage_type = 2,
            id = 4,
            missed = 1
          },
          {
            hitter_id = 14,
            damage_type = 2,
            id = 5,
            missed = 1
          },
          {
            hitter_id = 14,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 2,
          hitter_id = 14,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [3] = {
          type = 3,
          id = 3,
          hitter_id = 14,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [4] = {
          type = 3,
          id = 4,
          hitter_id = 14,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [5] = {
          type = 3,
          id = 5,
          hitter_id = 14,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [6] = {
          type = 3,
          id = 6,
          hitter_id = 14,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        }
      },
      [6] = {
        ["charId"] = 2,
        ["skill"] = CHS[3001352],
        ["opId"] = 13,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 2,
          {
            hitter_id = 2,
            damage_type = 1,
            id = 13,
            missed = 1
          },
          {
            hitter_id = 2,
            damage_type = 1,
            id = 12,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 12,
          hitter_id = 2,
          point = -math.random(7200, 7800),
          effect_no = 0,
          damage_type = 4097
        },
        [3] = {
          type = 3,
          id = 13,
          hitter_id = 2,
          point = -math.random(13700, 14300),
          effect_no = 0,
          damage_type = 4097
        }
      },
      [7] = {
        ["charId"] = 5,
        ["skill"] = CHS[3001352],
        ["opId"] = 13,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 2,
          {
            hitter_id = 5,
            damage_type = 1,
            id = 13,
            missed = 1
          },
          {
            hitter_id = 5,
            damage_type = 1,
            id = 12,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 12,
          hitter_id = 5,
          point = -math.random(7200, 7800),
          effect_no = 0,
          damage_type = 4097
        },
        [3] = {
          type = 3,
          id = 13,
          hitter_id = 5,
          point = -math.random(13700, 14300),
          effect_no = 0,
          damage_type = 4097
        }
      },
      [8] = {
        ["charId"] = 12,
        ["skill"] = "B5",
        ["opId"] = 3,
        ["op"] = 3,
        ["tip"] = CHS[3001371],
        ["para"] = "<B5>",
        [1] = {
          type = 2,
          count = 5,
          {
            hitter_id = 12,
            damage_type = 2,
            id = 2,
            missed = 1
          },
          {
            hitter_id = 12,
            damage_type = 2,
            id = 3,
            missed = 1
          },
          {
            hitter_id = 12,
            damage_type = 2,
            id = 4,
            missed = 1
          },
          {
            hitter_id = 12,
            damage_type = 2,
            id = 5,
            missed = 1
          },
          {
            hitter_id = 12,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 2,
          hitter_id = 12,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [3] = {
          type = 3,
          id = 3,
          hitter_id = 12,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [4] = {
          type = 3,
          id = 4,
          hitter_id = 12,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [5] = {
          type = 3,
          id = 5,
          hitter_id = 12,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [6] = {
          type = 3,
          id = 6,
          hitter_id = 12,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        }
      },
      [9] = {
        ["charId"] = 15,
        ["skill"] = "B5",
        ["opId"] = 3,
        ["op"] = 3,
        ["tip"] = CHS[3001372],
        ["para"] = "<B5>",
        [1] = {
          type = 2,
          count = 5,
          {
            hitter_id = 15,
            damage_type = 2,
            id = 2,
            missed = 1
          },
          {
            hitter_id = 15,
            damage_type = 2,
            id = 3,
            missed = 1
          },
          {
            hitter_id = 15,
            damage_type = 2,
            id = 4,
            missed = 1
          },
          {
            hitter_id = 15,
            damage_type = 2,
            id = 5,
            missed = 1
          },
          {
            hitter_id = 15,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 2,
          hitter_id = 15,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [3] = {
          type = 3,
          id = 3,
          hitter_id = 15,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [4] = {
          type = 3,
          id = 4,
          hitter_id = 15,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [5] = {
          type = 3,
          id = 5,
          hitter_id = 15,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        },
        [6] = {
          type = 3,
          id = 6,
          hitter_id = 15,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 2
        }
      },
      [10] = {
        ["charId"] = 6,
        ["skill"] = CHS[3001352],
        ["opId"] = 13,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 2,
          {
            hitter_id = 6,
            damage_type = 1,
            id = 13,
            missed = 1
          },
          {
            hitter_id = 6,
            damage_type = 1,
            id = 12,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 13,
          hitter_id = 6,
          point = -math.random(13700, 14300),
          effect_no = 0,
          damage_type = 4097
        },
        [3] = {
          type = 3,
          id = 12,
          hitter_id = 6,
          point = -math.random(7200, 7800),
          effect_no = 0,
          damage_type = 4097
        }
      },
      [11] = {
        ["charId"] = 4,
        ["skill"] = CHS[3001352],
        ["opId"] = 13,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 2,
          {
            hitter_id = 4,
            damage_type = 1,
            id = 13,
            missed = 1
          },
          {
            hitter_id = 4,
            damage_type = 1,
            id = 12,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 13,
          hitter_id = 4,
          point = -math.random(13700, 14300),
          effect_no = 0,
          damage_type = 4097
        },
        [3] = {
          type = 3,
          id = 12,
          hitter_id = 4,
          point = -math.random(7200, 7800),
          effect_no = 0,
          damage_type = 4097
        }
      }
    }
  },
  [3] = {
    round = 2,
    effect = {
      64,
      113,
      124,
      164,
      213,
      14,
      501
    },
    prepare = {guideId = 10002},
    actions = {
      [1] = {
        ["charId"] = 13,
        ["skill"] = CHS[3001352],
        ["opId"] = 3,
        ["op"] = 3,
        ["tip"] = CHS[3001373],
        ["para"] = CHS[3001352],
        [1] = {
          type = 7,
          id = 13,
          hitter_id = 13,
          point = -5500,
          effect_no = 0,
          damage_type = 2
        },
        [2] = {
          type = 2,
          count = 4,
          {
            hitter_id = 13,
            damage_type = 1,
            id = 3,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 1,
            id = 2,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 1,
            id = 4,
            missed = 1
          },
          {
            hitter_id = 13,
            damage_type = 1,
            id = 5,
            missed = 1
          }
        },
        [3] = {
          type = 3,
          id = 2,
          hitter_id = 13,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 4097
        },
        [4] = {
          type = 3,
          id = 3,
          hitter_id = 13,
          point = -math.random(37500, 38500),
          effect_no = 0,
          damage_type = 4097
        },
        [5] = {
          type = 3,
          id = 4,
          hitter_id = 13,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 4097
        },
        [6] = {
          type = 3,
          id = 5,
          hitter_id = 13,
          point = -math.random(18500, 19500),
          effect_no = 0,
          damage_type = 4097
        },
        [7] = {
          type = 4,
          id = 4,
          damage_type = 2
        },
        [8] = {
          type = 4,
          id = 5,
          damage_type = 2
        }
      },
      [2] = {
        ["charId"] = 3,
        ["skill"] = CHS[3001352],
        ["opId"] = 13,
        ["op"] = 3,
        ["tip"] = CHS[3001374],
        [1] = {
          type = 12,
          id = 3,
          effect_no = 8016,
          name = "混元金斗"
        },
        [2] = {
          type = 2,
          count = 5,
          {
            hitter_id = 3,
            damage_type = 1,
            id = 13,
            missed = 1
          },
          {
            hitter_id = 3,
            damage_type = 1,
            id = 11,
            missed = 1
          },
          {
            hitter_id = 3,
            damage_type = 1,
            id = 12,
            missed = 1
          },
          {
            hitter_id = 3,
            damage_type = 1,
            id = 14,
            missed = 1
          },
          {
            hitter_id = 3,
            damage_type = 1,
            id = 15,
            missed = 1
          }
        },
        [3] = {
          type = 3,
          id = 13,
          hitter_id = 3,
          point = -math.random(67500, 71250),
          effect_no = 0,
          damage_type = 4097
        },
        [4] = {
          type = 3,
          id = 11,
          hitter_id = 3,
          point = -math.random(33750, 35625),
          effect_no = 0,
          damage_type = 4097
        },
        [5] = {
          type = 3,
          id = 12,
          hitter_id = 3,
          point = -math.random(33750, 35625),
          effect_no = 0,
          damage_type = 4097
        },
        [6] = {
          type = 3,
          id = 14,
          hitter_id = 3,
          point = -math.random(33750, 35625),
          effect_no = 0,
          damage_type = 4097
        },
        [7] = {
          type = 3,
          id = 15,
          hitter_id = 3,
          point = -math.random(33750, 35625),
          effect_no = 0,
          damage_type = 4097
        }
      },
      [3] = {
        ["charId"] = 11,
        ["skill"] = CHS[3001375],
        ["opId"] = 13,
        ["op"] = 42,
        ["tip"] = CHS[3001376],
        ["para"] = "{13}",
        [1] = {
          type = 5,
          id = 13,
          hitter_id = 11,
          point = 56000,
          effect_no = 0,
          damage_type = 0
        }
      },
      [4] = {
        ["charId"] = 14,
        ["skill"] = CHS[3001375],
        ["opId"] = 12,
        ["op"] = 42,
        ["tip"] = CHS[3001377],
        [1] = {
          type = 5,
          id = 12,
          hitter_id = 14,
          point = 36000,
          effect_no = 0,
          damage_type = 0
        }
      },
      [5] = {
        ["charId"] = 6,
        ["skill"] = CHS[3001352],
        ["opId"] = 13,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 2,
          {
            hitter_id = 6,
            damage_type = 1,
            id = 13,
            missed = 1
          },
          {
            hitter_id = 6,
            damage_type = 1,
            id = 12,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 13,
          hitter_id = 6,
          point = -math.random(13700, 14300),
          effect_no = 0,
          damage_type = 4097
        },
        [3] = {
          type = 3,
          id = 12,
          hitter_id = 6,
          point = -math.random(7200, 7800),
          effect_no = 0,
          damage_type = 4097
        }
      },
      [6] = {
        ["charId"] = 12,
        ["skill"] = "B4",
        ["opId"] = 2,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 1,
          {
            hitter_id = 12,
            damage_type = 2,
            id = 2,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 2,
          hitter_id = 12,
          point = -math.random(39500, 40500),
          effect_no = 0,
          damage_type = 2
        },
        [3] = {
          type = 4,
          id = 2,
          damage_type = 2
        }
      },
      [7] = {
        ["charId"] = 15,
        ["skill"] = "B4",
        ["opId"] = 6,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 1,
          {
            hitter_id = 15,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 6,
          hitter_id = 15,
          point = -math.random(39500, 40500),
          effect_no = 0,
          damage_type = 2
        }
      }
    }
  },
  [4] = {
    round = 3,
    effect = {
      64,
      113,
      124,
      164,
      213,
      14,
      501
    },
    prepare = {guideId = 10003},
    actions = {
      [1] = {
        ["charId"] = 3,
        ["skill"] = CHS[3001375],
        ["opId"] = 3,
        ["op"] = 42,
        [1] = {
          type = 5,
          id = 3,
          hitter_id = 3,
          point = math.random(5500, 6500),
          effect_no = 0,
          damage_type = 0
        }
      },
      [2] = {
        ["charId"] = 11,
        ["skill"] = "B4",
        ["opId"] = 6,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 1,
          {
            hitter_id = 11,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 6,
          hitter_id = 11,
          point = -math.random(39500, 40500),
          effect_no = 0,
          damage_type = 2
        }
      },
      [3] = {
        ["charId"] = 14,
        ["skill"] = "B4",
        ["opId"] = 6,
        ["op"] = 3,
        [1] = {
          type = 2,
          count = 1,
          {
            hitter_id = 14,
            damage_type = 2,
            id = 6,
            missed = 1
          }
        },
        [2] = {
          type = 3,
          id = 6,
          hitter_id = 14,
          point = -math.random(39500, 40500),
          effect_no = 0,
          damage_type = 2
        },
        [3] = {
          type = 4,
          id = 6,
          damage_type = 2
        }
      },
      [4] = {
        ["charId"] = 13,
        ["skill"] = "B4",
        ["opId"] = 3,
        ["op"] = 3,
        ["tip"] = CHS[3001378],
        ["para"] = "<B4>",
        [1] = {
          type = 7,
          id = 13,
          hitter_id = 13,
          point = -5000,
          effect_no = 0,
          damage_type = 2
        },
        [2] = {
          type = 2,
          count = 1,
          {
            hitter_id = 13,
            damage_type = 2,
            id = 3,
            missed = 1
          }
        },
        [3] = {
          type = 3,
          id = 3,
          hitter_id = 13,
          point = -math.random(46500, 47500),
          effect_no = 0,
          damage_type = 2
        },
        [4] = {
          type = 4,
          id = 3,
          damage_type = 2
        }
      },
      [5] = {
        ["charId"] = 3,
        ["skill"] = 0,
        ["opId"] = 3,
        ["op"] = 3,
        ["tip"] = CHS[3001379],
        [1] = {
          type = 8,
          id = 3,
          no = 6010,
          owner_id = 0
        }
      },
      [6] = {
        ["charId"] = 3,
        ["skill"] = 0,
        ["opId"] = 3,
        ["op"] = 3,
        [1] = {type = 11, id = 3}
      },
      [7] = {
        charId = 3,
        skill = 0,
        opId = 3,
        op = 7
      },
      [8] = {
        ["charId"] = 3,
        ["skill"] = 0,
        ["opId"] = 3,
        ["op"] = 3,
        [1] = {type = 9, id = 3}
      }
    }
  },
  [5] = {
    round = 0,
    curIndex = 1,
    {
      id = 13,
      content = CHS[3001380]
    }
  }
}
