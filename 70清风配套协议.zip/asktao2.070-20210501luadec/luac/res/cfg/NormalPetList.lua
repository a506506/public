return {
  [CHS[3001381]] = {
    index = 1,
    icon = 6101,
    zoon = {
      CHS[3001382]
    },
    polar = CHS[3001383],
    level_req = 1,
    life = 20,
    mana = 20,
    speed = -10,
    phy_attack = -40,
    mag_attack = -10
  },
  [CHS[3001384]] = {
    index = 2,
    icon = 6166,
    zoon = {
      CHS[3001382]
    },
    polar = CHS[3001385],
    level_req = 1,
    life = 10,
    mana = -5,
    speed = 0,
    phy_attack = 15,
    mag_attack = -40
  },
  [CHS[3001386]] = {
    index = 3,
    icon = 6165,
    zoon = {
      CHS[3001387]
    },
    polar = CHS[3001388],
    level_req = 1,
    life = 25,
    mana = 20,
    speed = -10,
    phy_attack = -40,
    mag_attack = -10
  },
  [CHS[3001389]] = {
    index = 4,
    icon = 6102,
    zoon = {
      CHS[3001387]
    },
    polar = CHS[3001385],
    level_req = 1,
    life = 10,
    mana = 0,
    speed = 0,
    phy_attack = 15,
    mag_attack = -40
  },
  [CHS[3001390]] = {
    index = 5,
    icon = 6103,
    zoon = {
      CHS[3001391]
    },
    polar = CHS[3001385],
    level_req = 5,
    life = 10,
    mana = 0,
    speed = 5,
    phy_attack = 20,
    mag_attack = -40
  },
  [CHS[3001392]] = {
    index = 6,
    icon = 6167,
    zoon = {
      CHS[3001391]
    },
    polar = CHS[3001393],
    level_req = 5,
    life = 15,
    mana = 10,
    speed = 0,
    phy_attack = -40,
    mag_attack = 10
  },
  [CHS[3001394]] = {
    index = 7,
    icon = 6168,
    zoon = {
      CHS[3001395]
    },
    polar = CHS[3001388],
    level_req = 5,
    life = 10,
    mana = 10,
    speed = 5,
    phy_attack = -40,
    mag_attack = 10
  },
  [CHS[3001396]] = {
    index = 8,
    icon = 6104,
    zoon = {
      CHS[3001395]
    },
    polar = CHS[3001385],
    level_req = 5,
    life = 15,
    mana = 0,
    speed = 0,
    phy_attack = 20,
    mag_attack = -40
  },
  [CHS[3001397]] = {
    index = 9,
    icon = 6106,
    zoon = {
      CHS[3001398]
    },
    polar = CHS[3001388],
    skills = {
      CHS[3001399]
    },
    level_req = 15,
    life = 10,
    mana = 30,
    speed = 5,
    phy_attack = -40,
    mag_attack = 0
  },
  [CHS[3001400]] = {
    index = 10,
    icon = 6107,
    zoon = {
      CHS[3001398]
    },
    polar = CHS[3001388],
    skills = {
      CHS[3001399]
    },
    level_req = 15,
    life = 10,
    mana = 30,
    speed = 5,
    phy_attack = -40,
    mag_attack = 0
  },
  [CHS[3001401]] = {
    index = 11,
    icon = 6126,
    zoon = {
      CHS[3001402]
    },
    polar = CHS[3001383],
    skills = {
      CHS[3001403],
      CHS[3001404]
    },
    level_req = 20,
    life = 45,
    mana = 10,
    speed = 5,
    phy_attack = -40,
    mag_attack = 10
  },
  [CHS[3001405]] = {
    index = 12,
    icon = 6108,
    zoon = {
      CHS[3001406]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407]
    },
    level_req = 20,
    life = 35,
    mana = 0,
    speed = -10,
    phy_attack = 30,
    mag_attack = -40
  },
  [CHS[3001408]] = {
    index = 13,
    icon = 6123,
    zoon = {
      CHS[3001406],
      CHS[3001402]
    },
    polar = CHS[3001409],
    skills = {
      CHS[3001410]
    },
    level_req = 20,
    life = 5,
    mana = 30,
    speed = 10,
    phy_attack = -40,
    mag_attack = 10
  },
  [CHS[3001411]] = {
    index = 14,
    icon = 6116,
    zoon = {
      CHS[3001412]
    },
    polar = CHS[3001383],
    skills = {
      CHS[3001403],
      CHS[3001413]
    },
    level_req = 25,
    life = 10,
    mana = 35,
    speed = 5,
    phy_attack = -40,
    mag_attack = 10
  },
  [CHS[3001414]] = {
    index = 15,
    icon = 6122,
    zoon = {
      CHS[3001412],
      CHS[3001415],
      CHS[3001416]
    },
    polar = CHS[3001417],
    skills = {
      CHS[3001418],
      CHS[3001419]
    },
    level_req = 30,
    life = 25,
    mana = 30,
    speed = 5,
    phy_attack = -40,
    mag_attack = 10
  },
  [CHS[3001420]] = {
    index = 16,
    icon = 6113,
    zoon = {
      CHS[3001415]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407],
      CHS[3001421]
    },
    level_req = 30,
    life = 35,
    mana = 0,
    speed = 5,
    phy_attack = 30,
    mag_attack = -40
  },
  [CHS[3001422]] = {
    index = 17,
    icon = 6110,
    zoon = {
      CHS[3001416]
    },
    polar = CHS[3001388],
    skills = {
      CHS[3001399],
      CHS[3001423]
    },
    level_req = 35,
    life = 10,
    mana = 35,
    speed = 20,
    phy_attack = -40,
    mag_attack = 10
  },
  [CHS[3001424]] = {
    index = 18,
    icon = 6120,
    zoon = {
      CHS[3001425],
      CHS[3001426],
      CHS[3001427],
      CHS[3001428],
      CHS[3001429],
      CHS[3001430]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407],
      CHS[3001419]
    },
    level_req = 35,
    life = 25,
    mana = 0,
    speed = 15,
    phy_attack = 35,
    mag_attack = -40
  },
  [CHS[3001431]] = {
    index = 19,
    icon = 6121,
    zoon = {
      CHS[3001425],
      CHS[3001426],
      CHS[3001427],
      CHS[3001428],
      CHS[3001429],
      CHS[3001430]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407],
      CHS[3001421]
    },
    level_req = 35,
    life = 45,
    mana = 0,
    speed = -5,
    phy_attack = 35,
    mag_attack = -40
  },
  [CHS[3001432]] = {
    index = 20,
    icon = 6117,
    zoon = {
      CHS[3001433]
    },
    polar = CHS[3001393],
    skills = {
      CHS[3001434],
      CHS[3001435],
      CHS[3001421]
    },
    level_req = 50,
    life = 30,
    mana = 35,
    speed = 15,
    phy_attack = -40,
    mag_attack = 15
  },
  [CHS[3001436]] = {
    index = 21,
    icon = 6128,
    zoon = {
      CHS[3001433]
    },
    polar = CHS[3001388],
    skills = {
      CHS[3001399],
      CHS[3001413],
      CHS[3001437]
    },
    level_req = 40,
    life = 25,
    mana = 30,
    speed = 15,
    phy_attack = -40,
    mag_attack = 15
  },
  [CHS[3001438]] = {
    index = 22,
    icon = 6118,
    zoon = {
      CHS[3001439]
    },
    polar = CHS[3001417],
    skills = {
      CHS[3001418],
      CHS[3001435],
      CHS[3001413]
    },
    level_req = 50,
    life = 30,
    mana = 35,
    speed = 15,
    phy_attack = -40,
    mag_attack = 15
  },
  [CHS[3001440]] = {
    index = 23,
    icon = 6125,
    zoon = {
      CHS[3001439]
    },
    polar = CHS[3001383],
    skills = {
      CHS[3001403],
      CHS[3001404],
      CHS[3001419]
    },
    level_req = 40,
    life = 25,
    mana = 35,
    speed = 10,
    phy_attack = -40,
    mag_attack = 15
  },
  [CHS[3001441]] = {
    index = 24,
    icon = 6119,
    zoon = {
      CHS[3001442]
    },
    polar = CHS[3001383],
    skills = {
      CHS[3001403],
      CHS[3001435],
      CHS[3001404]
    },
    level_req = 50,
    life = 30,
    mana = 35,
    speed = 15,
    phy_attack = -40,
    mag_attack = 15
  },
  [CHS[3001443]] = {
    index = 25,
    icon = 6131,
    zoon = {
      CHS[3001442]
    },
    polar = CHS[3001393],
    skills = {
      CHS[3001434],
      CHS[3001419],
      CHS[3001421]
    },
    level_req = 45,
    life = 35,
    mana = 30,
    speed = 10,
    phy_attack = -40,
    mag_attack = 15
  },
  [CHS[3001444]] = {
    index = 26,
    icon = 6124,
    zoon = {
      CHS[3001445]
    },
    polar = CHS[3001388],
    skills = {
      CHS[3001399],
      CHS[3001435],
      CHS[3001423]
    },
    level_req = 50,
    life = 30,
    mana = 35,
    speed = 15,
    phy_attack = -40,
    mag_attack = 15
  },
  [CHS[3001446]] = {
    index = 27,
    icon = 6129,
    zoon = {
      CHS[3001445]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407],
      CHS[3001421],
      CHS[3001419]
    },
    level_req = 45,
    life = 30,
    mana = 0,
    speed = 10,
    phy_attack = 50,
    mag_attack = -40
  },
  [CHS[3001447]] = {
    index = 28,
    icon = 6127,
    zoon = {
      CHS[3001448]
    },
    polar = CHS[3001409],
    skills = {
      CHS[3001410],
      CHS[3001435],
      CHS[3001421]
    },
    level_req = 50,
    life = 30,
    mana = 35,
    speed = 15,
    phy_attack = -40,
    mag_attack = 15
  },
  [CHS[3001449]] = {
    index = 29,
    icon = 6130,
    zoon = {
      CHS[3001448]
    },
    polar = CHS[3001417],
    skills = {
      CHS[3001418],
      CHS[3001413],
      CHS[3001423]
    },
    level_req = 50,
    life = 20,
    mana = 35,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001450]] = {
    index = 30,
    icon = 6132,
    zoon = {
      CHS[3001451]
    },
    polar = CHS[3001417],
    skills = {
      CHS[3001418],
      CHS[3001404],
      CHS[3001421]
    },
    level_req = 55,
    life = 60,
    mana = 35,
    speed = -10,
    phy_attack = -30,
    mag_attack = 5
  },
  [CHS[3001452]] = {
    index = 31,
    icon = 6142,
    zoon = {
      CHS[3001451]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407],
      CHS[3001453],
      CHS[3001419]
    },
    level_req = 55,
    life = 55,
    mana = 0,
    speed = 0,
    phy_attack = 45,
    mag_attack = -40
  },
  [CHS[3001454]] = {
    index = 32,
    icon = 6140,
    zoon = {
      CHS[3001455]
    },
    polar = CHS[3001388],
    skills = {
      CHS[3001399],
      CHS[3001419],
      CHS[3001453]
    },
    level_req = 60,
    life = 35,
    mana = 35,
    speed = 15,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001456]] = {
    index = 33,
    icon = 6141,
    zoon = {
      CHS[3001455]
    },
    polar = CHS[3001383],
    skills = {
      CHS[3001403],
      CHS[3001404],
      CHS[3001437]
    },
    level_req = 60,
    life = 35,
    mana = 35,
    speed = 15,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001457]] = {
    index = 34,
    icon = 6139,
    zoon = {
      CHS[3001458]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407],
      CHS[3001421],
      CHS[3001435]
    },
    level_req = 65,
    life = 50,
    mana = 0,
    speed = 10,
    phy_attack = 50,
    mag_attack = -40
  },
  [CHS[3001459]] = {
    index = 35,
    icon = 6172,
    zoon = {
      CHS[3001458]
    },
    polar = CHS[3001417],
    skills = {
      CHS[3001418],
      CHS[3001453],
      CHS[3001413]
    },
    level_req = 65,
    life = 45,
    mana = 20,
    speed = 30,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001460]] = {
    index = 36,
    icon = 6134,
    zoon = {
      CHS[3001461]
    },
    polar = CHS[3001388],
    skills = {
      CHS[3001399],
      CHS[3001423],
      CHS[3001413]
    },
    level_req = 70,
    life = 30,
    mana = 40,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001462]] = {
    index = 37,
    icon = 6170,
    zoon = {
      CHS[3001461]
    },
    polar = CHS[3001383],
    skills = {
      CHS[3001403],
      CHS[3001413],
      CHS[3001437]
    },
    level_req = 70,
    life = 50,
    mana = 25,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001463]] = {
    index = 38,
    icon = 6133,
    zoon = {
      CHS[3001464]
    },
    polar = CHS[3001409],
    skills = {
      CHS[3001410],
      CHS[3001423],
      CHS[3001421]
    },
    level_req = 70,
    life = 30,
    mana = 40,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001465]] = {
    index = 39,
    icon = 6169,
    zoon = {
      CHS[3001464]
    },
    polar = CHS[3001393],
    skills = {
      CHS[3001434],
      CHS[3001419],
      CHS[3001423]
    },
    level_req = 70,
    life = 45,
    mana = 20,
    speed = 25,
    phy_attack = -40,
    mag_attack = 25
  },
  [CHS[3001466]] = {
    index = 40,
    icon = 6136,
    zoon = {
      CHS[3001467]
    },
    polar = CHS[3001417],
    skills = {
      CHS[3001418],
      CHS[3001404],
      CHS[3001419]
    },
    level_req = 70,
    life = 30,
    mana = 40,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001468]] = {
    index = 41,
    icon = 6175,
    zoon = {
      CHS[3001467]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001423],
      CHS[3001437],
      CHS[3001419]
    },
    level_req = 70,
    life = 40,
    mana = 0,
    speed = 25,
    phy_attack = 50,
    mag_attack = -40
  },
  [CHS[3001469]] = {
    index = 42,
    icon = 6137,
    zoon = {
      CHS[3001470]
    },
    polar = CHS[3001393],
    skills = {
      CHS[3001434],
      CHS[3001423],
      CHS[3001453]
    },
    level_req = 70,
    life = 30,
    mana = 40,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001471]] = {
    index = 43,
    icon = 6173,
    zoon = {
      CHS[3001470]
    },
    polar = CHS[3001383],
    skills = {
      CHS[3001403],
      CHS[3001453],
      CHS[3001423]
    },
    level_req = 70,
    life = 50,
    mana = 25,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001472]] = {
    index = 44,
    icon = 6138,
    zoon = {
      CHS[3001473]
    },
    polar = CHS[3001383],
    skills = {
      CHS[3001403],
      CHS[3001404],
      CHS[3001413]
    },
    level_req = 70,
    life = 30,
    mana = 40,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[3001474]] = {
    index = 45,
    icon = 6174,
    zoon = {
      CHS[3001473]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407],
      CHS[3001413],
      CHS[3001437]
    },
    level_req = 70,
    life = 60,
    mana = 0,
    speed = 5,
    phy_attack = 50,
    mag_attack = -40
  },
  [CHS[3001475]] = {
    index = 46,
    icon = 6135,
    zoon = {
      CHS[3001476]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001407],
      CHS[3001421],
      CHS[3001419]
    },
    level_req = 75,
    life = 40,
    mana = 0,
    speed = 20,
    phy_attack = 50,
    mag_attack = -40
  },
  [CHS[3001477]] = {
    index = 47,
    icon = 6171,
    zoon = {
      CHS[3001476]
    },
    polar = CHS[3001409],
    skills = {
      CHS[3001410],
      CHS[3001423],
      CHS[3001435]
    },
    level_req = 75,
    life = 45,
    mana = 15,
    speed = 25,
    phy_attack = -40,
    mag_attack = 30
  },
  [CHS[6000308]] = {
    index = 48,
    icon = 6147,
    zoon = {
      CHS[6000309]
    },
    polar = CHS[6000315],
    skills = {
      CHS[3001434],
      CHS[3001404],
      CHS[3001413]
    },
    level_req = 80,
    life = 45,
    mana = 45,
    speed = 10,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[5440001]] = {
    index = 49,
    icon = 6148,
    zoon = {
      CHS[6000309]
    },
    polar = CHS[6000312],
    skills = {
      CHS[3000083],
      CHS[3001423],
      CHS[3001419]
    },
    level_req = 80,
    life = 35,
    mana = 40,
    speed = 25,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[6000316]] = {
    index = 50,
    icon = 6143,
    zoon = {
      CHS[6000317]
    },
    polar = CHS[6000314],
    skills = {
      CHS[3000080],
      CHS[3001404],
      CHS[3000079]
    },
    level_req = 80,
    life = 45,
    mana = 25,
    speed = 25,
    phy_attack = -40,
    mag_attack = 25
  },
  [CHS[6000318]] = {
    index = 51,
    icon = 6144,
    zoon = {
      CHS[6000317]
    },
    polar = CHS[6000315],
    skills = {
      CHS[3001434],
      CHS[3001589],
      CHS[3001592]
    },
    level_req = 80,
    life = 40,
    mana = 30,
    speed = 20,
    phy_attack = -40,
    mag_attack = 30
  },
  [CHS[6000319]] = {
    index = 52,
    icon = 6149,
    zoon = {
      CHS[6000320]
    },
    polar = CHS[6000313],
    skills = {
      CHS[3001863],
      CHS[3001856],
      CHS[3001589]
    },
    level_req = 85,
    life = 35,
    mana = 45,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[6000321]] = {
    index = 53,
    icon = 6150,
    zoon = {
      CHS[6000320]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001583],
      CHS[3001584],
      CHS[3001585]
    },
    level_req = 85,
    life = 35,
    mana = 0,
    speed = 25,
    phy_attack = 60,
    mag_attack = -40
  },
  [CHS[6000322]] = {
    index = 54,
    icon = 6151,
    zoon = {
      CHS[6000323]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001583],
      CHS[3001586],
      CHS[3001590]
    },
    level_req = 90,
    life = 50,
    mana = 0,
    speed = 30,
    phy_attack = 45,
    mag_attack = -40
  },
  [CHS[5440002]] = {
    index = 55,
    icon = 6152,
    zoon = {
      CHS[6000323]
    },
    polar = CHS[6000311],
    skills = {
      CHS[3001514],
      CHS[3001586],
      CHS[3001589]
    },
    level_req = 90,
    life = 35,
    mana = 40,
    speed = 25,
    phy_attack = -40,
    mag_attack = 25
  },
  [CHS[6000325]] = {
    index = 56,
    icon = 6153,
    zoon = {
      CHS[6000326]
    },
    polar = CHS[6000314],
    skills = {
      CHS[3001562],
      CHS[3001584],
      CHS[3001588]
    },
    level_req = 95,
    life = 35,
    mana = 45,
    speed = 30,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[6000327]] = {
    index = 57,
    icon = 6154,
    zoon = {
      CHS[6000326]
    },
    polar = CHS[6000313],
    skills = {
      CHS[3001546],
      CHS[3001584],
      CHS[3001592]
    },
    level_req = 95,
    life = 45,
    mana = 50,
    speed = 10,
    phy_attack = -40,
    mag_attack = 25
  },
  [CHS[6000328]] = {
    index = 58,
    icon = 6163,
    zoon = {
      CHS[6000329]
    },
    polar = CHS[6000313],
    skills = {
      CHS[3001546],
      CHS[3001591],
      CHS[3001584]
    },
    level_req = 95,
    life = 40,
    mana = 45,
    speed = 25,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[6000330]] = {
    index = 59,
    icon = 6164,
    zoon = {
      CHS[6000329]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001588],
      CHS[3001591],
      CHS[3001589]
    },
    level_req = 95,
    life = 50,
    mana = 0,
    speed = 20,
    phy_attack = 60,
    mag_attack = -40
  },
  [CHS[6000331]] = {
    index = 60,
    icon = 6162,
    zoon = {
      CHS[6000332]
    },
    polar = CHS[6000313],
    skills = {
      CHS[3001546],
      CHS[3001588],
      CHS[3001583]
    },
    level_req = 100,
    life = 60,
    mana = 25,
    speed = 20,
    phy_attack = -40,
    mag_attack = 30
  },
  [CHS[6000333]] = {
    index = 61,
    icon = 6146,
    zoon = {
      CHS[6000332]
    },
    polar = CHS[6000311],
    skills = {
      CHS[3001514],
      CHS[3001584],
      CHS[3001590]
    },
    level_req = 100,
    life = 50,
    mana = 15,
    speed = 35,
    phy_attack = -40,
    mag_attack = 35
  },
  [CHS[7002257]] = {
    index = 62,
    icon = 6271,
    zoon = {
      CHS[7002263]
    },
    polar = CHS[6000312],
    skills = {
      CHS[3001530],
      CHS[3001584],
      CHS[3001585]
    },
    level_req = 105,
    life = 60,
    mana = 20,
    speed = 35,
    phy_attack = -40,
    mag_attack = 20
  },
  [CHS[7002258]] = {
    index = 63,
    icon = 6272,
    zoon = {
      CHS[7002263]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001588],
      CHS[3001591],
      CHS[3001592]
    },
    level_req = 105,
    life = 50,
    mana = 0,
    speed = 35,
    phy_attack = 50,
    mag_attack = -40
  },
  [CHS[7002260]] = {
    index = 64,
    icon = 6276,
    zoon = {
      CHS[7002264]
    },
    polar = CHS[3001385],
    skills = {
      CHS[3001588],
      CHS[3001584],
      CHS[3001590]
    },
    level_req = 110,
    life = 60,
    mana = 0,
    speed = 15,
    phy_attack = 65,
    mag_attack = -40
  },
  [CHS[7002259]] = {
    index = 65,
    icon = 6275,
    zoon = {
      CHS[7002264]
    },
    polar = CHS[6000314],
    skills = {
      CHS[3001562],
      CHS[3001583],
      CHS[3001585]
    },
    level_req = 110,
    life = 55,
    mana = 20,
    speed = 30,
    phy_attack = -40,
    mag_attack = 35
  },
  [CHS[7002262]] = {
    index = 66,
    icon = 6282,
    zoon = {
      CHS[7002265]
    },
    polar = CHS[6000313],
    skills = {
      CHS[3001546],
      CHS[3001584],
      CHS[3001590]
    },
    level_req = 115,
    life = 65,
    mana = 25,
    speed = 20,
    phy_attack = -40,
    mag_attack = 30
  },
  [CHS[7002261]] = {
    index = 67,
    icon = 6281,
    zoon = {
      CHS[7002265]
    },
    polar = CHS[6000313],
    skills = {
      CHS[3001546],
      CHS[3001583],
      CHS[3001585]
    },
    level_req = 115,
    life = 60,
    mana = 15,
    speed = 25,
    phy_attack = -40,
    mag_attack = 40
  },
  [CHS[7190099]] = {
    index = 68,
    icon = 6283,
    zoon = {
      CHS[7190107]
    },
    polar = CHS[3001409],
    skills = {
      CHS[3004290],
      CHS[3004289],
      CHS[3004313]
    },
    level_req = 120,
    life = 60,
    mana = 20,
    speed = 40,
    phy_attack = -40,
    mag_attack = 25
  },
  [CHS[7190100]] = {
    index = 69,
    icon = 6284,
    zoon = {
      CHS[7190107]
    },
    polar = CHS[3001417],
    skills = {
      CHS[3004288],
      CHS[3004293],
      CHS[3004286]
    },
    level_req = 120,
    life = 70,
    mana = 20,
    speed = 20,
    phy_attack = -40,
    mag_attack = 35
  },
  [CHS[4101558]] = {
    index = 70,
    icon = 6285,
    zoon = {
      CHS[4101560]
    },
    polar = CHS[3001385],
    skills = {
      CHS[4000176],
      CHS[4000172],
      CHS[4000179]
    },
    level_req = 125,
    life = 65,
    mana = 0,
    speed = 15,
    phy_attack = 65,
    mag_attack = -40
  },
  [CHS[4101559]] = {
    index = 71,
    icon = 6286,
    zoon = {
      CHS[4101560]
    },
    polar = CHS[3001393],
    skills = {
      CHS[4000171],
      CHS[4000175],
      CHS[4000174]
    },
    level_req = 125,
    life = 60,
    mana = 20,
    speed = 35,
    phy_attack = -40,
    mag_attack = 30
  },
  [CHS[7190860]] = {
    index = 72,
    icon = 6289,
    zoon = {
      CHS[7190864]
    },
    polar = CHS[6000313],
    skills = {
      CHS[4000169],
      CHS[4000173],
      CHS[4000179]
    },
    level_req = 130,
    life = 65,
    mana = 20,
    speed = 20,
    phy_attack = -40,
    mag_attack = 40
  },
  [CHS[7190861]] = {
    index = 73,
    icon = 6288,
    zoon = {
      CHS[7190864]
    },
    polar = CHS[6000312],
    skills = {
      CHS[4000168],
      CHS[4000176],
      CHS[4000174]
    },
    level_req = 130,
    life = 70,
    mana = 20,
    speed = 10,
    phy_attack = -40,
    mag_attack = 45
  },
  [CHS[7190862]] = {
    index = 74,
    icon = 6161,
    zoon = {
      CHS[7190865]
    },
    polar = CHS[6000313],
    skills = {
      CHS[4000169],
      CHS[4000173],
      CHS[4000179]
    },
    level_req = 135,
    life = 70,
    mana = 10,
    speed = 30,
    phy_attack = -40,
    mag_attack = 40
  },
  [CHS[7190863]] = {
    index = 75,
    icon = 6305,
    zoon = {
      CHS[7190865]
    },
    polar = CHS[6000312],
    skills = {
      CHS[4000168],
      CHS[4000172],
      CHS[4000174]
    },
    level_req = 135,
    life = 75,
    mana = 35,
    speed = 20,
    phy_attack = -40,
    mag_attack = 20
  }
}
