return {
  resourceCfg = {
    map1 = {
      "Qianlxh/QianlxhWater.png",
      "Qianlxh/QianlxhWaterLeft.png",
      "Qianlxh/QianlxhWaterRight.png"
    },
    map2 = {
      "Qianlxh/QianlxhBeach.png",
      "Qianlxh/QianlxhBeachLeft.png",
      "Qianlxh/QianlxhBeachRight.png"
    },
    arrow0 = {
      "Qianlxh/QianlxhNotTouchArrow1.png",
      "Qianlxh/QianlxhNotTouchArrow2.png"
    },
    arrow1 = {
      "Qianlxh/QianlxhWaterArrow1.png",
      "Qianlxh/QianlxhWaterArrow2.png"
    },
    arrow2 = {
      "Qianlxh/QianlxhWaterArrow1.png",
      "Qianlxh/QianlxhWaterArrow2.png"
    },
    arrow3 = {
      "GiftHandOut/GiftHandOutArrow03.png",
      "GiftHandOut/GiftHandOutArrow04.png"
    },
    arrow4 = {
      "GiftHandOut/GiftHandOutArrow05.png",
      "GiftHandOut/GiftHandOutArrow06.png"
    },
    arrow5 = {
      "GiftHandOut/GiftHandOutArrow01.png",
      "GiftHandOut/GiftHandOutArrow02.png"
    },
    arrow6 = {
      "Qianlxh/QianlxhWaterArrow1.png",
      "Qianlxh/QianlxhWaterArrow2.png"
    },
    beachAdd1 = "Qianlxh/QianlxhBeachAdd1.png",
    beachAdd2 = "Qianlxh/QianlxhBeachAdd2.png",
    bigBoat = {
      "Qianlxh/QianlxhBigBoat3.png",
      "Qianlxh/QianlxhBigBoat7.png"
    },
    bigShadow = "Qianlxh/QianlxhBigBoatShadow.png",
    smallBoat = {
      "Qianlxh/QianlxhSmallBoat3.png",
      "Qianlxh/QianlxhSmallBoat7.png"
    },
    smallShadow = "Qianlxh/QianlxhSmallBoatShadow.png",
    endTitle = "Qianlxh/QianlxhFinish.png",
    house = "Qianlxh/QianlxhHouse.png",
    speedArrow = "Qianlxh/QianlxhSpeedArrow.png",
    stone1 = "Qianlxh/QianlxhStone1.png",
    stone2 = "Qianlxh/QianlxhStone2.png",
    stone3 = "Qianlxh/QianlxhStone3.png",
    gift = "Icon0118"
  },
  walkSpeed = {x = 66, y = 33},
  girdMagin = cc.size(72, 36),
  downWaterKeyFrame = 24
}
