return {
  beta = {
    ["如意令"] = {normal_effect = 1011, full_effect = 1023},
    ["问道情"] = {normal_effect = 1453, full_effect = 1465},
    ["八卦阵"] = {normal_effect = 1454, full_effect = 1466},
    ["吉祥结"] = {normal_effect = 1455, full_effect = 1467},
    ["星辰奇缘"] = {
      normal_effect = 1456,
      full_effect = 1468,
      hide_unofficial = 1
    },
    ["月亮之上"] = {normal_effect = 1461, full_effect = 1469},
    ["大风车"] = {normal_effect = 1462, full_effect = 1470},
    ["归来兮"] = {normal_effect = 1514, full_effect = 1515}
  },
  release = {
    ["如意令"] = {normal_effect = 1011, full_effect = 1023},
    ["问道情"] = {normal_effect = 1453, full_effect = 1465},
    ["八卦阵"] = {normal_effect = 1454, full_effect = 1466},
    ["吉祥结"] = {normal_effect = 1455, full_effect = 1467},
    ["星辰奇缘"] = {
      normal_effect = 1456,
      full_effect = 1468,
      hide_unofficial = 1
    },
    ["月亮之上"] = {normal_effect = 1461, full_effect = 1469},
    ["大风车"] = {normal_effect = 1462, full_effect = 1470},
    ["归来兮"] = {normal_effect = 1514, full_effect = 1515}
  }
}
