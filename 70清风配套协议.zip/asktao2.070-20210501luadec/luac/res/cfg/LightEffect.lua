return {
  [1002] = {
    icon = 1002,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [6047] = {
    icon = 6047,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [3002] = {
    icon = 3002,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [3021] = {
    icon = 3021,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [6071] = {
    icon = 6071,
    pos = 2,
    behind = false,
    magicKey = false
  },
  [6007] = {
    icon = 6007,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [1121] = {
    icon = 1121,
    pos = 2,
    behind = false,
    magicKey = true,
    armatureType = 1
  },
  [7010] = {
    icon = 7010,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [7011] = {
    icon = 7010,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [1123] = {
    icon = 1123,
    pos = 1,
    behind = false,
    magicKey = true
  },
  [1124] = {
    icon = 1124,
    pos = 1,
    behind = false,
    magicKey = true
  },
  [8049] = {
    icon = 8049,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [8050] = {
    icon = 8050,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [8051] = {
    icon = 8051,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [6068] = {
    icon = 6068,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [6066] = {
    icon = 6066,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [1158] = {
    icon = 1158,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [1159] = {
    icon = 1159,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [1243] = {
    icon = 1243,
    pos = 2,
    behind = false,
    magicKey = true,
    armatureType = 1
  },
  [1424] = {
    icon = 1424,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [8043] = {
    icon = 8043,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {loopInterval = 5000}
  },
  [8044] = {
    icon = 8043,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {
      loopInterval = 5000,
      scaleX = 0.75,
      scaleY = 0.75
    }
  },
  [8045] = {
    icon = 8045,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {loopInterval = 5000}
  },
  [8046] = {
    icon = 8045,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {
      loopInterval = 5000,
      scaleX = 0.75,
      scaleY = 0.75
    }
  },
  [1288] = {
    icon = 1288,
    pos = 1,
    behind = true,
    magicKey = true,
    armatureType = 1,
    action = {
      [1] = "Bottom04",
      [3] = "Bottom01",
      [5] = "Bottom02",
      [7] = "Bottom03"
    }
  },
  [1296] = {
    icon = 1296,
    pos = 2,
    behind = false,
    magicKey = true,
    armatureType = 1,
    action = {
      [5] = "Top01"
    }
  },
  [1307] = {
    icon = 1307,
    pos = 2,
    behind = false,
    magicKey = true,
    armatureType = 1,
    action = {
      [5] = "Top02"
    }
  },
  [4002] = {
    icon = 4002,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [4004] = {
    icon = 4004,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [4006] = {
    icon = 4006,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [4008] = {
    icon = 4008,
    pos = 1,
    behind = false,
    magicKey = true
  },
  [4010] = {
    icon = 4010,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [3022] = {
    icon = 3022,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [3015] = {
    icon = 3015,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [3025] = {
    icon = 3025,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [3014] = {
    icon = 3014,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [3012] = {
    icon = 3012,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [1160] = {
    icon = 1160,
    pos = 1,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  },
  [1161] = {
    icon = 1161,
    pos = 1,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  },
  [1065] = {
    icon = 1065,
    pos = 1,
    behind = false,
    magicKey = true
  },
  [3018] = {
    icon = 3018,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [6049] = {
    icon = 6049,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [4005] = {
    icon = 4005,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [4001] = {
    icon = 4001,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [4009] = {
    icon = 4009,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [4003] = {
    icon = 4003,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [4010] = {
    icon = 4010,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [7001] = {
    icon = 7001,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [7002] = {
    icon = 7002,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [7003] = {
    icon = 7003,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [7004] = {
    icon = 7004,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [7005] = {
    icon = 7005,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [1261] = {
    icon = 1261,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  },
  [1427] = {
    icon = 1427,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  },
  [50201] = {
    icon = 50201,
    pos = 1,
    behind = false,
    magicKey = true
  },
  [4007] = {
    icon = 4007,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [1769] = {
    icon = 4007,
    pos = 1,
    behind = false,
    magicKey = true
  },
  [6042] = {
    icon = 6042,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [2016] = {
    icon = 2016,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [3020] = {
    icon = 3020,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [8117] = {
    icon = 8117,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [1301] = {
    icon = 1288,
    pos = 1,
    behind = true,
    magicKey = true,
    armatureType = 1,
    action = {
      [4] = "Top01",
      [5] = "Top02",
      [6] = "Top03"
    }
  },
  [1331] = {
    icon = 1331,
    pos = 3,
    behind = false,
    armatureType = 2,
    offset = cc.p(0, -10),
    action = {
      [5] = "Bottom"
    }
  },
  [1330] = {
    icon = 1330,
    pos = 1,
    behind = false,
    armatureType = 2,
    action = {
      [5] = "Top"
    }
  },
  [1333] = {
    icon = 1333,
    pos = 2,
    behind = false,
    armatureType = 2,
    action = {
      [5] = "Top"
    }
  },
  [1329] = {
    icon = 1329,
    pos = 2,
    behind = false,
    armatureType = 2,
    action = {
      [5] = "Top"
    }
  },
  [1479] = {
    icon = 1479,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [1350] = {
    icon = 1350,
    pos = 3,
    behind = false,
    armatureType = 4,
    magicKey = true
  },
  [1351] = {
    icon = 1351,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {loopInterval = 2000}
  },
  [1425] = {
    icon = 1425,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  },
  [2192] = {
    icon = 2192,
    pos = 1,
    behind = false,
    magicKey = true,
    armatureType = 4,
    relateMagic = {219201}
  },
  [219201] = {
    icon = 2192,
    pos = 1,
    behind = true,
    magicKey = true,
    armatureType = 4
  },
  [1352] = {
    icon = 1352,
    pos = 2,
    behind = false,
    armatureType = 4,
    magicKey = true
  },
  [1354] = {
    icon = 1354,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add", loopInterval = 2000}
  },
  [1355] = {
    icon = 1355,
    pos = 2,
    behind = true,
    magicKey = true,
    extraPara = {loopInterval = 2000}
  },
  [1375] = {
    icon = 1375,
    pos = 2,
    behind = false,
    magicKey = true,
    offset = cc.p(-5, 0),
    extraPara = {blendMode = "add"}
  },
  [1356] = {
    icon = 1356,
    pos = 1,
    behind = true,
    armatureType = 4,
    follow_dis = 50,
    show_action = {
      [1] = "Bottom02",
      [3] = "Bottom03",
      [5] = "Bottom04",
      [7] = "Bottom01"
    }
  },
  [1357] = {
    icon = 1357,
    pos = 1,
    behind = true,
    armatureType = 4,
    follow_dis = 58,
    show_action = {
      [1] = "Bottom02",
      [3] = "Bottom03",
      [5] = "Bottom04",
      [7] = "Bottom01"
    }
  },
  [1358] = {
    icon = 1358,
    pos = 1,
    behind = true,
    armatureType = 4,
    follow_dis = 58,
    show_action = {
      [1] = "Bottom02",
      [3] = "Bottom03",
      [5] = "Bottom04",
      [7] = "Bottom01"
    }
  },
  [2089] = {
    icon = 2089,
    pos = 1,
    behind = true,
    armatureType = 4,
    follow_dis = 58,
    show_action = {
      [1] = "Bottom02",
      [3] = "Bottom03",
      [5] = "Bottom04",
      [7] = "Bottom01"
    }
  },
  [2184] = {
    icon = 2184,
    pos = 2,
    behind = false,
    armatureType = 4,
    magicKey = true,
    action = {
      [5] = "Top"
    }
  },
  [2117] = {
    icon = 2117,
    pos = 1,
    armatureType = 5
  },
  [1336] = {
    icon = 1336,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  },
  [8246] = {
    icon = 8246,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [8247] = {
    icon = 8247,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [1337] = {
    icon = 1337,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [1338] = {
    icon = 1338,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [6011] = {
    icon = 6011,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [4009] = {
    icon = 4009,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [4010] = {
    icon = 4010,
    pos = 2,
    behind = false,
    magicKey = true
  },
  [1406] = {
    icon = 1406,
    pos = 1,
    behind = false,
    magicKey = true
  },
  [1418] = {
    icon = 1418,
    pos = 1,
    behind = false,
    magicKey = true
  },
  [1405] = {
    icon = 1405,
    pos = 2,
    behind = false,
    magicKey = false,
    offset = cc.p(0, 10),
    extraPara = {blendMode = "add"}
  },
  [1485] = {
    icon = 1485,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [1497] = {
    icon = 1497,
    pos = 2,
    behind = false,
    magicKey = false
  },
  [1484] = {
    icon = 1484,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [1616] = {
    icon = 1616,
    pos = 1,
    behind = false,
    magicKey = false,
    offset = cc.p(0, 5)
  },
  [1617] = {
    icon = 1617,
    pos = 1,
    behind = false,
    magicKey = false,
    offset = cc.p(0, 5)
  },
  [1011] = {
    icon = 1011,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1453] = {
    icon = 1453,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1454] = {
    icon = 1454,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1455] = {
    icon = 1455,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1456] = {
    icon = 1456,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1461] = {
    icon = 1461,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1462] = {
    icon = 1462,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1514] = {
    icon = 1514,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1023] = {
    icon = 1023,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1465] = {
    icon = 1465,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1466] = {
    icon = 1466,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1467] = {
    icon = 1467,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1468] = {
    icon = 1468,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1469] = {
    icon = 1469,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1470] = {
    icon = 1470,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1515] = {
    icon = 1515,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [1463] = {
    icon = 1463,
    pos = 2,
    behind = true,
    magicKey = false
  },
  [1464] = {
    icon = 1464,
    pos = 2,
    behind = true,
    magicKey = false
  },
  [1660] = {
    icon = 1660,
    pos = 2,
    behind = true,
    magicKey = false
  },
  [1476] = {
    icon = 1476,
    pos = 3,
    behind = false,
    magicKey = false,
    offset = cc.p(-10, 0)
  },
  [1477] = {
    icon = 1476,
    pos = 3,
    behind = false,
    magicKey = false,
    offset = cc.p(10, 0)
  },
  [1489] = {
    icon = 1489,
    pos = 2,
    behind = false,
    magicKey = false,
    extraPara = {blendMode = "add"}
  },
  [1482] = {
    icon = 1482,
    pos = 1,
    behind = false,
    magicKey = false,
    extraPara = {blendMode = "add"}
  },
  [2057] = {
    icon = 2057,
    pos = 2,
    behind = true,
    armatureType = 4,
    action = {
      [5] = "Bottom03"
    }
  },
  [2058] = {
    icon = 2057,
    pos = 2,
    behind = true,
    armatureType = 4,
    action = {
      [5] = "Bottom02"
    }
  },
  [2059] = {
    icon = 2057,
    pos = 2,
    behind = true,
    armatureType = 4,
    action = {
      [5] = "Bottom01"
    }
  },
  [2191] = {
    icon = 2191,
    pos = 2,
    behind = true,
    armatureType = 4,
    magicKey = true,
    action = {
      [3] = "Top01"
    }
  },
  [1452] = {
    icon = 1452,
    pos = 1,
    behind = false,
    magicKey = false
  },
  [1437] = {
    icon = 1437,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [1061] = {
    icon = 1061,
    pos = 1,
    behind = true,
    magicKey = true
  },
  [2064] = {
    icon = 2064,
    pos = 2,
    behind = false,
    armatureType = 4,
    magicKey = true
  },
  [1627] = {
    icon = 1627,
    spcialIcon = true,
    effect_para = "TongzhjDlg_zhuabuzhe"
  },
  [1628] = {
    icon = 1628,
    spcialIcon = true,
    effect_para = "TongzhjDlg_deng"
  },
  [1651] = {
    icon = 1651,
    spcialIcon = true,
    effect_para = "scale_and_fadeOut"
  },
  [1707] = {
    icon = 1707,
    spcialIcon = true,
    effect_para = "leitbw",
    pos = 3
  },
  [1658] = {
    icon = 1658,
    pos = 3,
    spcialIcon = true,
    para = "shalu_zhixin",
    magicKey = false
  },
  [1661] = {
    icon = 1661,
    pos = 3,
    behind = false,
    magicKey = false
  },
  [1659] = {
    icon = 1659,
    pos = 3,
    behind = false,
    magicKey = true
  },
  [2125] = {
    icon = 2125,
    pos = 1,
    behind = false,
    armatureType = 2,
    offset = cc.p(0, 0),
    action = {
      [5] = "Bottom"
    }
  },
  [1638] = {
    icon = 1638,
    pos = 2,
    behind = false,
    magicKey = false
  },
  [1648] = {
    icon = 1648,
    pos = 1,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  },
  [2196] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = true,
    effectKey = 2196,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Bottom01"
  },
  [2197] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2197,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top01"
  },
  [2198] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2198,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top02"
  },
  [2199] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2199,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top03"
  },
  [2200] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2200,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top04"
  },
  [2201] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2201,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top05"
  },
  [2202] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2197,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top06"
  },
  [2203] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2198,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top07"
  },
  [2204] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2199,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top08"
  },
  [2205] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2200,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top09"
  },
  [2206] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2201,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top10"
  },
  [2207] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2197,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top11"
  },
  [2208] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2198,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top12"
  },
  [2209] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2199,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top13"
  },
  [2210] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2200,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top14"
  },
  [2211] = {
    icon = 2196,
    pos = 1,
    armatureType = 5,
    behind = false,
    effectKey = 2201,
    magicKey = true,
    offset = cc.p(-30, -50),
    show_action = "Top15"
  },
  [1706] = {
    icon = 1700,
    pos = 1,
    behind = false,
    offset = cc.p(100, -50)
  },
  [2223] = {
    icon = 2223,
    pos = 2,
    behind = true,
    magicKey = true,
    armatureType = 4,
    offset = cc.p(62, 59),
    action = "Top"
  },
  [2224] = {
    icon = 2224,
    pos = 2,
    behind = true,
    armatureType = 4,
    offset = cc.p(62, 59),
    action = {
      [5] = "Top"
    }
  },
  [2225] = {
    icon = 2225,
    pos = 2,
    behind = true,
    armatureType = 4,
    offset = cc.p(62, 59),
    action = {
      [5] = "Top"
    }
  },
  [2226] = {
    icon = 2226,
    pos = 2,
    behind = true,
    armatureType = 4,
    offset = cc.p(62, 59),
    action = {
      [5] = "Top"
    }
  },
  [2228] = {
    icon = 2228,
    pos = 2,
    behind = false,
    magicKey = true,
    armatureType = 4,
    action = "Top"
  },
  [2229] = {
    icon = 2229,
    pos = 2,
    behind = false,
    armatureType = 4,
    action = {
      [5] = "Top"
    }
  },
  [2230] = {
    icon = 2230,
    pos = 2,
    behind = false,
    armatureType = 4,
    action = {
      [5] = "Top"
    }
  },
  [2231] = {
    icon = 2231,
    pos = 2,
    behind = false,
    armatureType = 4,
    action = {
      [5] = "Top"
    }
  },
  [2232] = {
    icon = 2232,
    pos = 2,
    behind = false,
    magicKey = true,
    armatureType = 4,
    action = "Top"
  },
  [2233] = {
    icon = 2233,
    pos = 2,
    behind = false,
    armatureType = 4,
    action = {
      [5] = "Top"
    }
  },
  [2234] = {
    icon = 2234,
    pos = 2,
    behind = false,
    armatureType = 4,
    action = {
      [5] = "Top"
    }
  },
  [2235] = {
    icon = 2235,
    pos = 2,
    behind = false,
    armatureType = 4,
    action = {
      [5] = "Top"
    }
  },
  [1703] = {
    icon = 1703,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  },
  [1704] = {
    icon = 1704,
    pos = 2,
    behind = false,
    magicKey = true,
    extraPara = {blendMode = "add"}
  }
}
