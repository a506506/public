return {
  [CHS[3000377]] = "phy_power",
  ["phy_power"] = CHS[3000377],
  [CHS[3000378]] = "mag_power",
  ["mag_power"] = CHS[3000378],
  ["power"] = CHS[3000379],
  [CHS[3000379]] = "power",
  ["str"] = CHS[3000380],
  [CHS[3000380]] = "str",
  ["dex"] = CHS[3000381],
  [CHS[3000381]] = "dex",
  ["wiz"] = CHS[3000382],
  [CHS[3000382]] = "wiz",
  ["con"] = CHS[3000383],
  [CHS[3000383]] = "con",
  ["speed"] = CHS[3000384],
  [CHS[3000384]] = "speed",
  ["max_life"] = CHS[3000385],
  [CHS[3000385]] = "max_life",
  ["max_mana"] = CHS[3000386],
  [CHS[3000386]] = "max_mana",
  ["def"] = CHS[3000387],
  [CHS[3000387]] = "def",
  ["metal"] = CHS[3000388],
  [CHS[3000388]] = "metal",
  ["wood"] = CHS[3000389],
  [CHS[3000389]] = "wood",
  ["water"] = CHS[3000390],
  [CHS[3000390]] = "water",
  ["fire"] = CHS[3000391],
  [CHS[3000391]] = "fire",
  ["earth"] = CHS[3000392],
  [CHS[3000392]] = "earth",
  ["double_hit"] = CHS[3000393],
  [CHS[3000393]] = "double_hit",
  [CHS[2200017]] = "double_hit",
  ["counter_attack"] = CHS[3000394],
  [CHS[3000394]] = "counter_attack",
  ["double_hit_rate"] = CHS[3000395],
  [CHS[3000395]] = "double_hit_rate",
  ["counter_attack_rate"] = CHS[3000396],
  [CHS[4000042]] = "double_hit_rate",
  [CHS[3000396]] = "counter_attack_rate",
  ["damage_sel_rate"] = CHS[3000397],
  [CHS[3000397]] = "damage_sel_rate",
  ["damage_sel"] = CHS[3000398],
  [CHS[3000398]] = "damage_sel",
  ["stunt_rate"] = CHS[3000399],
  [CHS[3000399]] = "stunt_rate",
  ["phy_power"] = CHS[2500087],
  [CHS[2500087]] = "phy_power",
  ["mag_power"] = CHS[2500088],
  [CHS[2500088]] = "mag_power",
  ["resist_stunt_rate"] = CHS[2500089],
  [CHS[2500089]] = "resist_stunt_rate",
  ["resist_mstunt_rate"] = CHS[2500090],
  [CHS[2500090]] = "resist_mstunt_rate",
  ["resist_double_hit"] = CHS[2500091],
  [CHS[2500091]] = "resist_double_hit",
  ["magic_stunt_rate"] = CHS[2500092],
  [CHS[2500092]] = "magic_stunt_rate",
  ["all_skill"] = CHS[3000400],
  [CHS[3000400]] = "all_skill",
  ["all_polar"] = CHS[3000401],
  [CHS[3000401]] = "all_polar",
  ["all_attrib"] = CHS[3000402],
  [CHS[3000402]] = "all_attrib",
  ["all_resist_except"] = CHS[3000403],
  [CHS[3000403]] = "all_resist_except",
  ["all_resist_polar"] = CHS[3000404],
  [CHS[3000404]] = "all_resist_polar",
  ["ignore_all_resist_polar"] = CHS[3000405],
  [CHS[3000405]] = "ignore_all_resist_polar",
  ["ignore_all_resist_except"] = CHS[3000406],
  [CHS[3000406]] = "ignore_all_resist_except",
  ["enhanced_phy"] = CHS[3000407],
  [CHS[3000407]] = "enhanced_phy",
  ["ignore_resist_confusion"] = CHS[3000408],
  [CHS[3000408]] = "ignore_resist_confusion",
  ["ignore_resist_sleep"] = CHS[3000409],
  [CHS[3000409]] = "ignore_resist_sleep",
  ["ignore_resist_frozen"] = CHS[3000410],
  [CHS[3000410]] = "ignore_resist_frozen",
  ["ignore_resist_poison"] = CHS[3000411],
  [CHS[3000411]] = "ignore_resist_poison",
  ["ignore_resist_forgotten"] = CHS[3000412],
  [CHS[3000412]] = "ignore_resist_forgotten",
  ["enhanced_metal"] = CHS[3000413],
  [CHS[3000413]] = "enhanced_metal",
  ["enhanced_wood"] = CHS[3000414],
  [CHS[3000414]] = "enhanced_wood",
  ["enhanced_water"] = CHS[3000415],
  [CHS[3000415]] = "enhanced_water",
  ["enhanced_fire"] = CHS[3000416],
  [CHS[3000416]] = "enhanced_fire",
  ["enhanced_earth"] = CHS[3000417],
  [CHS[3000417]] = "enhanced_earth",
  ["skill_low_cost"] = CHS[3000418],
  [CHS[3000418]] = "skill_low_cost",
  ["mag_dodge"] = CHS[3000419],
  [CHS[3000419]] = "mag_dodge",
  ["accurate"] = CHS[3000420],
  [CHS[3000420]] = "accurate",
  [CHS[3000421]] = "resist_poison",
  ["resist_poison"] = CHS[3000421],
  [CHS[3000422]] = "resist_frozen",
  ["resist_frozen"] = CHS[3000422],
  [CHS[3000423]] = "resist_sleep",
  ["resist_sleep"] = CHS[3000423],
  [CHS[3000424]] = "resist_forgotten",
  ["resist_forgotten"] = CHS[3000424],
  [CHS[3000425]] = "resist_confusion",
  ["resist_confusion"] = CHS[3000425],
  ["resist_metal"] = CHS[3000426],
  [CHS[3000426]] = "resist_metal",
  ["resist_wood"] = CHS[3000427],
  [CHS[3000427]] = "resist_wood",
  ["resist_water"] = CHS[3000428],
  [CHS[3000428]] = "resist_water",
  ["resist_fire"] = CHS[3000429],
  [CHS[3000429]] = "resist_fire",
  ["resist_earth"] = CHS[3000430],
  [CHS[3000430]] = "resist_earth",
  ["super_excluse_metal"] = CHS[3000431],
  ["super_excluse_wood"] = CHS[3000432],
  ["super_excluse_water"] = CHS[3000433],
  ["super_excluse_fire"] = CHS[3000434],
  ["super_excluse_earth"] = CHS[3000435],
  [CHS[3000431]] = "super_excluse_metal",
  [CHS[3000432]] = "super_excluse_wood",
  [CHS[3000433]] = "super_excluse_water",
  [CHS[3000434]] = "super_excluse_fire",
  [CHS[3000435]] = "super_excluse_earth",
  [CHS[3000436]] = "ignore_resist_metal",
  [CHS[3000437]] = "ignore_resist_wood",
  [CHS[3000438]] = "ignore_resist_water",
  [CHS[3000439]] = "ignore_resist_fire",
  [CHS[3000440]] = "ignore_resist_earth",
  ["ignore_resist_metal"] = CHS[3000436],
  ["ignore_resist_wood"] = CHS[3000437],
  ["ignore_resist_water"] = CHS[3000438],
  ["ignore_resist_fire"] = CHS[3000439],
  ["ignore_resist_earth"] = CHS[3000440],
  [CHS[3000441]] = "B_skill_low_cost",
  ["B_skill_low_cost"] = CHS[3000441],
  [CHS[3000442]] = "C_skill_low_cost",
  ["C_skill_low_cost"] = CHS[3000442],
  [CHS[3000443]] = "D_skill_low_cost",
  ["D_skill_low_cost"] = CHS[3000443],
  [CHS[3000444]] = "super_forgotten",
  ["super_forgotten"] = CHS[3000444],
  [CHS[3000445]] = "super_poison",
  ["super_poison"] = CHS[3000445],
  [CHS[3000446]] = "super_frozen",
  ["super_frozen"] = CHS[3000446],
  [CHS[3000447]] = "super_sleep",
  ["super_sleep"] = CHS[3000447],
  [CHS[3000448]] = "super_confusion",
  ["super_confusion"] = CHS[3000448],
  [CHS[3000449]] = "ignore_mag_dodge",
  ["ignore_mag_dodge"] = CHS[3000449],
  [CHS[3000450]] = "release_forgotten",
  ["release_forgotten"] = CHS[3000450],
  [CHS[3000451]] = "release_poison",
  ["release_poison"] = CHS[3000451],
  [CHS[3000452]] = "release_frozen",
  ["release_frozen"] = CHS[3000452],
  [CHS[3000453]] = "release_sleep",
  ["release_sleep"] = CHS[3000453],
  [CHS[3000454]] = "release_confusion",
  ["release_confusion"] = CHS[3000454],
  [CHS[3000455]] = "penetrate_rate",
  ["penetrate_rate"] = CHS[3000455],
  [CHS[3000456]] = "penetrate",
  ["penetrate"] = CHS[3000456],
  [CHS[7190141]] = "mstunt_rate",
  ["mstunt_rate"] = CHS[7190141],
  [CHS[3000457]] = {
    accurate = 1,
    double_hit_rate = 1,
    counter_attack_rate = 1,
    stunt_rate = 1,
    mstunt_rate = 1,
    damage_sel_rate = 1,
    resist_metal = 1,
    resist_wood = 1,
    resist_water = 1,
    resist_fire = 1,
    resist_earth = 1,
    resist_poison = 1,
    resist_frozen = 1,
    resist_sleep = 1,
    resist_forgotten = 1,
    resist_confusion = 1,
    all_resist_except = 1,
    all_resist_polar = 1,
    super_excluse_metal = 1,
    super_excluse_wood = 1,
    super_excluse_water = 1,
    super_excluse_fire = 1,
    super_excluse_earth = 1,
    enhanced_metal = 1,
    enhanced_wood = 1,
    enhanced_water = 1,
    enhanced_fire = 1,
    enhanced_earth = 1,
    enhanced_phy = 1,
    mag_dodge = 1,
    B_skill_low_cost = 1,
    C_skill_low_cost = 1,
    D_skill_low_cost = 1,
    super_forgotten = 1,
    super_poison = 1,
    super_frozen = 1,
    super_sleep = 1,
    super_confusion = 1,
    ignore_resist_metal = 1,
    ignore_resist_wood = 1,
    ignore_resist_water = 1,
    ignore_resist_fire = 1,
    ignore_resist_earth = 1,
    ignore_resist_forgotten = 1,
    ignore_resist_poison = 1,
    ignore_resist_frozen = 1,
    ignore_resist_sleep = 1,
    ignore_resist_confusion = 1,
    ignore_all_resist_polar = 1,
    ignore_all_resist_except = 1,
    ignore_mag_dodge = 1,
    release_forgotten = 1,
    release_poison = 1,
    release_frozen = 1,
    release_sleep = 1,
    release_confusion = 1,
    ignore_defense_rate = 1,
    ignore_defense = 1,
    penetrate_rate = 1,
    penetrate = 1,
    resist_stunt_rate = 1,
    resist_mstunt_rate = 1,
    resist_double_hit = 1,
    magic_stunt_rate = 1
  },
  [CHS[3000458]] = {
    "phy_power",
    "mag_power",
    "power",
    "str",
    "dex",
    "wiz",
    "con",
    "speed",
    "max_life",
    "max_mana",
    "def",
    "metal",
    "wood",
    "water",
    "fire",
    "earth",
    "double_hit",
    "counter_attack",
    "double_hit_rate",
    "counter_attack_rate",
    "damage_sel_rate",
    "damage_sel",
    "stunt_rate",
    "all_skill",
    "all_polar",
    "all_attrib",
    "all_resist_except",
    "all_resist_polar",
    "ignore_all_resist_polar",
    "ignore_all_resist_except",
    "enhanced_phy",
    "ignore_resist_confusion",
    "ignore_resist_sleep",
    "ignore_resist_frozen",
    "ignore_resist_poison",
    "ignore_resist_forgotten",
    "enhanced_metal",
    "enhanced_wood",
    "enhanced_water",
    "enhanced_fire",
    "enhanced_earth",
    "skill_low_cost",
    "mag_dodge",
    "accurate",
    "resist_poison",
    "resist_frozen",
    "resist_sleep",
    "resist_forgotten",
    "resist_confusion",
    "resist_metal",
    "resist_wood",
    "resist_water",
    "resist_fire",
    "resist_earth",
    "super_excluse_metal",
    "super_excluse_wood",
    "super_excluse_water",
    "super_excluse_fire",
    "super_excluse_earth",
    "ignore_resist_metal",
    "ignore_resist_wood",
    "ignore_resist_water",
    "ignore_resist_fire",
    "ignore_resist_earth",
    "B_skill_low_cost",
    "C_skill_low_cost",
    "D_skill_low_cost",
    "super_forgotten",
    "super_poison",
    "super_frozen",
    "super_sleep",
    "super_confusion",
    "ignore_mag_dodge",
    "release_forgotten",
    "release_poison",
    "release_frozen",
    "release_sleep",
    "release_confusion",
    "penetrate_rate",
    "penetrate",
    "resist_stunt_rate",
    "resist_mstunt_rate",
    "resist_double_hit",
    "magic_stunt_rate"
  },
  [CHS[3000459]] = {
    CHS[3000379],
    CHS[3000388],
    CHS[3000389],
    CHS[3000390],
    CHS[3000391],
    CHS[3000392],
    CHS[3000382],
    CHS[3000380],
    CHS[3000381],
    CHS[3000383],
    CHS[3000405],
    CHS[3000400],
    CHS[3000406],
    CHS[3000399],
    CHS[3000395],
    CHS[3000396]
  },
  [CHS[3000460]] = {
    CHS[3000382],
    CHS[3000380],
    CHS[3000381],
    CHS[3000383],
    CHS[3000404],
    CHS[3000403],
    CHS[3000397],
    CHS[3000387],
    CHS[3000385]
  },
  [CHS[3000461]] = {
    CHS[3000382],
    CHS[3000380],
    CHS[3000381],
    CHS[3000383],
    CHS[3000393],
    CHS[3000394],
    CHS[3000398],
    CHS[3000462],
    CHS[3000385]
  },
  [CHS[3000463]] = {
    CHS[3000382],
    CHS[3000380],
    CHS[3000381],
    CHS[3000383],
    CHS[3000384],
    CHS[3000393],
    CHS[3000394],
    CHS[3000398],
    CHS[3000462]
  },
  [CHS[3000464]] = {
    {
      att = CHS[3000378],
      field = "mag_power"
    },
    {
      att = CHS[3000385],
      field = "max_life"
    },
    {
      att = CHS[3000387],
      field = "def"
    },
    {
      att = CHS[3000384],
      field = "speed"
    },
    {
      att = CHS[3000377],
      field = "phy_power"
    }
  },
  [CHS[3000465]] = {
    {
      att = CHS[3000421],
      field = "resist_poison"
    },
    {
      att = CHS[3000422],
      field = "resist_frozen"
    },
    {
      att = CHS[3000423],
      field = "resist_sleep"
    },
    {
      att = CHS[3000424],
      field = "resist_forgotten"
    },
    {
      att = CHS[3000425],
      field = "resist_confusion"
    },
    {
      att = CHS[3000431],
      field = "super_excluse_metal"
    },
    {
      att = CHS[3000432],
      field = "super_excluse_wood"
    },
    {
      att = CHS[3000433],
      field = "super_excluse_water"
    },
    {
      att = CHS[3000434],
      field = "super_excluse_fire"
    },
    {
      att = CHS[3000435],
      field = "super_excluse_earth"
    },
    {
      att = CHS[3000413],
      field = "enhanced_metal"
    },
    {
      att = CHS[3000414],
      field = "enhanced_wood"
    },
    {
      att = CHS[3000415],
      field = "enhanced_water"
    },
    {
      att = CHS[3000416],
      field = "enhanced_fire"
    },
    {
      att = CHS[3000417],
      field = "enhanced_earth"
    },
    {
      att = CHS[3000407],
      field = "enhanced_phy"
    },
    {
      att = CHS[3000419],
      field = "mag_dodge"
    },
    {
      att = CHS[3000441],
      field = "B_skill_low_cost"
    },
    {
      att = CHS[3000442],
      field = "C_skill_low_cost"
    },
    {
      att = CHS[3000443],
      field = "D_skill_low_cost"
    },
    {
      att = CHS[3000444],
      field = "super_forgotten"
    },
    {
      att = CHS[3000445],
      field = "super_poison"
    },
    {
      att = CHS[3000446],
      field = "super_frozen"
    },
    {
      att = CHS[3000447],
      field = "super_sleep"
    },
    {
      att = CHS[3000448],
      field = "super_confusion"
    },
    {
      att = CHS[3000436],
      field = "ignore_resist_metal"
    },
    {
      att = CHS[3000437],
      field = "ignore_resist_wood"
    },
    {
      att = CHS[3000438],
      field = "ignore_resist_water"
    },
    {
      att = CHS[3000439],
      field = "ignore_resist_fire"
    },
    {
      att = CHS[3000440],
      field = "ignore_resist_earth"
    },
    {
      att = CHS[3000456],
      field = "penetrate"
    },
    {
      att = CHS[3000455],
      field = "penetrate_rate"
    },
    {
      att = CHS[3000454],
      field = "release_confusion"
    },
    {
      att = CHS[3000453],
      field = "release_sleep"
    },
    {
      att = CHS[3000452],
      field = "release_frozen"
    },
    {
      att = CHS[3000451],
      field = "release_poison"
    },
    {
      att = CHS[3000450],
      field = "release_forgotten"
    },
    {
      att = CHS[3000449],
      field = "ignore_mag_dodge"
    },
    {
      att = CHS[3000406],
      field = "ignore_all_resist_except"
    },
    {
      att = CHS[3000405],
      field = "ignore_all_resist_polar"
    },
    {
      att = CHS[3000411],
      field = "ignore_resist_poison"
    },
    {
      att = CHS[3000410],
      field = "ignore_resist_frozen"
    },
    {
      att = CHS[3000409],
      field = "ignore_resist_sleep"
    },
    {
      att = CHS[3000408],
      field = "ignore_resist_confusion"
    },
    {
      att = CHS[3000412],
      field = "ignore_resist_forgotten"
    }
  },
  [CHS[3000466]] = {
    "enhanced_metal",
    "enhanced_wood",
    "enhanced_water",
    "enhanced_fire",
    "enhanced_earth",
    "enhanced_phy",
    "ignore_resist_forgotten",
    "ignore_resist_poison",
    "ignore_resist_frozen",
    "ignore_resist_sleep",
    "ignore_resist_confusion",
    "all_resist_except",
    "skill_low_cost",
    "mag_dodge"
  },
  [CHS[3000467]] = {
    accurate = {
      min = 10,
      norm = 20,
      max = 40
    },
    double_hit_rate = {
      min = 10,
      norm = 20,
      max = 30
    },
    counter_attack_rate = {
      min = 10,
      norm = 20,
      max = 30
    },
    stunt_rate = {
      min = 10,
      norm = 20,
      max = 30
    },
    damage_sel_rate = {
      min = 10,
      norm = 20,
      max = 30
    },
    double_hit = {
      min = 1,
      norm = 2,
      max = 12
    },
    counter_attack = {
      min = 1,
      norm = 3,
      max = 10
    },
    damage_sel = {
      min = 10,
      norm = 20,
      max = 30
    },
    metal = {
      min = 1,
      norm = 1,
      max = 5
    },
    wood = {
      min = 1,
      norm = 1,
      max = 5
    },
    water = {
      min = 1,
      norm = 1,
      max = 5
    },
    fire = {
      min = 1,
      norm = 1,
      max = 5
    },
    earth = {
      min = 1,
      norm = 1,
      max = 5
    },
    resist_metal = {
      min = 5,
      norm = 8,
      max = 15
    },
    resist_wood = {
      min = 5,
      norm = 8,
      max = 15
    },
    resist_water = {
      min = 5,
      norm = 8,
      max = 15
    },
    resist_fire = {
      min = 5,
      norm = 8,
      max = 15
    },
    resist_earth = {
      min = 5,
      norm = 8,
      max = 15
    },
    resist_poison = {
      min = 5,
      norm = 10,
      max = 20
    },
    resist_frozen = {
      min = 5,
      norm = 10,
      max = 20
    },
    resist_sleep = {
      min = 5,
      norm = 10,
      max = 20
    },
    resist_forgotten = {
      min = 5,
      norm = 10,
      max = 20
    },
    resist_confusion = {
      min = 5,
      norm = 10,
      max = 20
    },
    all_polar = {
      min = 1,
      norm = 1,
      max = 5
    },
    all_resist_polar = {
      min = 5,
      norm = 8,
      max = 15
    },
    all_resist_except = {
      min = 5,
      norm = 8,
      max = 15
    },
    all_skill = {
      min = 1,
      norm = 2,
      max = 10
    },
    super_excluse_metal = {
      min = 5,
      norm = 10,
      max = 20
    },
    super_excluse_wood = {
      min = 5,
      norm = 10,
      max = 20
    },
    super_excluse_water = {
      min = 5,
      norm = 10,
      max = 20
    },
    super_excluse_fire = {
      min = 5,
      norm = 10,
      max = 20
    },
    super_excluse_earth = {
      min = 5,
      norm = 10,
      max = 20
    },
    enhanced_metal = {
      min = 3,
      norm = 5,
      max = 10
    },
    enhanced_wood = {
      min = 3,
      norm = 5,
      max = 10
    },
    enhanced_water = {
      min = 3,
      norm = 5,
      max = 10
    },
    enhanced_fire = {
      min = 3,
      norm = 5,
      max = 10
    },
    enhanced_earth = {
      min = 3,
      norm = 5,
      max = 10
    },
    enhanced_phy = {
      min = 3,
      norm = 5,
      max = 10
    },
    mag_dodge = {
      min = 10,
      norm = 15,
      max = 30
    },
    B_skill_low_cost = {
      min = 1,
      norm = 3,
      max = 10
    },
    C_skill_low_cost = {
      min = 1,
      norm = 3,
      max = 10
    },
    D_skill_low_cost = {
      min = 1,
      norm = 3,
      max = 10
    },
    super_forgotten = {
      min = 5,
      norm = 15,
      max = 30
    },
    super_poison = {
      min = 5,
      norm = 15,
      max = 30
    },
    super_frozen = {
      min = 5,
      norm = 15,
      max = 30
    },
    super_sleep = {
      min = 5,
      norm = 15,
      max = 30
    },
    super_confusion = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_metal = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_wood = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_water = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_fire = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_earth = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_forgotten = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_poison = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_frozen = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_sleep = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_resist_confusion = {
      min = 5,
      norm = 15,
      max = 30
    },
    ignore_all_resist_polar = {
      min = 5,
      norm = 10,
      max = 20
    },
    ignore_all_resist_except = {
      min = 5,
      norm = 10,
      max = 20
    },
    ignore_mag_dodge = {
      min = 5,
      norm = 8,
      max = 15
    },
    release_forgotten = {
      min = 5,
      norm = 8,
      max = 15
    },
    release_poison = {
      min = 5,
      norm = 8,
      max = 15
    },
    release_frozen = {
      min = 5,
      norm = 8,
      max = 15
    },
    release_sleep = {
      min = 5,
      norm = 8,
      max = 15
    },
    release_confusion = {
      min = 5,
      norm = 8,
      max = 15
    },
    penetrate_rate = {
      min = 10,
      norm = 20,
      max = 30
    },
    penetrate = {
      min = 10,
      norm = 20,
      max = 30
    }
  }
}
