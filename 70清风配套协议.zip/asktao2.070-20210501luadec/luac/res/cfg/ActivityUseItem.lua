return {
  [CHS[7002033]] = {
    [CHS[7002029]] = {isFightItem = true, sortIndex = 1},
    [CHS[7002030]] = {isFightItem = true, sortIndex = 2},
    [CHS[7002031]] = {isFightItem = true, sortIndex = 3}
  },
  [CHS[7190607]] = {
    [CHS[7190608]] = {isFightItem = true, sortIndex = 1},
    [CHS[7190609]] = {isFightItem = true, sortIndex = 2}
  },
  [CHS[7333440]] = {
    [CHS[5410475]] = {virPosOffset = 0, sortIndex = 1},
    [CHS[5410476]] = {virPosOffset = 1, sortIndex = 2},
    [CHS[5410477]] = {virPosOffset = 2, sortIndex = 3},
    [CHS[5410478]] = {virPosOffset = 3, sortIndex = 4}
  },
  [COMBAT_MODE.COMBAT_MODE_XCWL] = {
    [CHS[7333424]] = {
      virPosOffset = 4,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_VICTIM
      },
      isFightItem = true,
      sortIndex = 1
    },
    [CHS[7333423]] = {
      virPosOffset = 5,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_VICTIM
      },
      isFightItem = true,
      sortIndex = 2
    },
    [CHS[7333422]] = {
      virPosOffset = 6,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_VICTIM
      },
      isFightItem = true,
      sortIndex = 3
    },
    [CHS[7333421]] = {
      virPosOffset = 7,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_VICTIM
      },
      isFightItem = true,
      sortIndex = 4
    },
    [CHS[7333420]] = {
      virPosOffset = 8,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_VICTIM
      },
      isFightItem = true,
      sortIndex = 5
    },
    [CHS[7333419]] = {
      virPosOffset = 9,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_VICTIM
      },
      isFightItem = true,
      sortIndex = 6
    },
    [CHS[7333418]] = {
      virPosOffset = 10,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_FRIEND,
        ITEM_ATTRIB.APPLY_ON_MYSELF
      },
      isFightItem = true,
      sortIndex = 7
    },
    [CHS[7333417]] = {
      virPosOffset = 11,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_FRIEND,
        ITEM_ATTRIB.APPLY_ON_MYSELF
      },
      isFightItem = true,
      sortIndex = 8
    },
    [CHS[7333416]] = {
      virPosOffset = 12,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_FRIEND,
        ITEM_ATTRIB.APPLY_ON_MYSELF
      },
      isFightItem = true,
      sortIndex = 9
    },
    [CHS[7333415]] = {
      virPosOffset = 13,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_FRIEND,
        ITEM_ATTRIB.APPLY_ON_MYSELF
      },
      isFightItem = true,
      sortIndex = 10
    },
    [CHS[7333414]] = {
      virPosOffset = 14,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_FRIEND,
        ITEM_ATTRIB.APPLY_ON_MYSELF
      },
      isFightItem = true,
      sortIndex = 11
    },
    [CHS[7333413]] = {
      virPosOffset = 15,
      attribs = {
        ITEM_ATTRIB.APPLY_ON_FRIEND,
        ITEM_ATTRIB.APPLY_ON_MYSELF
      },
      isFightItem = true,
      sortIndex = 12
    }
  }
}
