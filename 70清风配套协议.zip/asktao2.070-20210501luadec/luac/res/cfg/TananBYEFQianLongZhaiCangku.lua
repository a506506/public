return {
  {
    class_id = 10052,
    x = 39,
    y = 41,
    dir = 11,
    cx = -9,
    cy = 11
  },
  {
    class_id = 10062,
    x = 37,
    y = 38,
    dir = 0,
    cx = -3,
    cy = 0
  },
  {
    class_id = 10062,
    x = 49,
    y = 38,
    dir = 0,
    cx = -4,
    cy = -11
  },
  {
    class_id = 10052,
    x = 50,
    y = 41,
    dir = 11,
    cx = 5,
    cy = -5
  },
  {
    class_id = 10106,
    x = 27,
    y = 25,
    dir = 0,
    cx = 5,
    cy = -5
  },
  {
    class_id = 10106,
    x = 21,
    y = 32,
    dir = 1,
    cx = -3,
    cy = -6
  },
  {
    class_id = 10106,
    x = 23,
    y = 28,
    dir = 1,
    cx = 3,
    cy = -11
  },
  {
    class_id = 10106,
    x = 19,
    y = 30,
    dir = 1,
    cx = -12,
    cy = 7
  },
  {
    class_id = 10046,
    x = 61,
    y = 24,
    dir = 1,
    cx = 2,
    cy = -7
  },
  {
    class_id = 10046,
    x = 67,
    y = 24,
    dir = 1,
    cx = 7,
    cy = 9
  },
  {
    class_id = 10046,
    x = 15,
    y = 26,
    dir = 0,
    cx = 3,
    cy = -7
  },
  {
    class_id = 10046,
    x = 21,
    y = 23,
    dir = 0,
    cx = 1,
    cy = -7
  },
  {
    class_id = 10046,
    x = 27,
    y = 21,
    dir = 0,
    cx = -12,
    cy = 12
  },
  {
    class_id = 10046,
    x = 32,
    y = 18,
    dir = 0,
    cx = 4,
    cy = 12
  },
  {
    class_id = 10087,
    x = 43,
    y = 20,
    dir = 0,
    cx = -12,
    cy = 3
  },
  {
    class_id = 10087,
    x = 35,
    y = 23,
    dir = 0,
    cx = 6,
    cy = 7
  },
  {
    class_id = 10087,
    x = 41,
    y = 23,
    dir = 0,
    cx = -5,
    cy = -8
  },
  {
    class_id = 10087,
    x = 33,
    y = 26,
    dir = 0,
    cx = -12,
    cy = -1
  },
  {
    class_id = 10087,
    x = 48,
    y = 15,
    dir = 0,
    cx = 0,
    cy = 7
  },
  {
    class_id = 10087,
    x = 43,
    y = 17,
    dir = 0,
    cx = 0,
    cy = 11
  },
  {
    class_id = 10087,
    x = 50,
    y = 21,
    dir = 0,
    cx = -5,
    cy = 0
  },
  {
    class_id = 10087,
    x = 51,
    y = 18,
    dir = 0,
    cx = 0,
    cy = 8
  },
  {
    class_id = 10106,
    x = 30,
    y = 35,
    dir = 0,
    cx = -11,
    cy = -6
  },
  {
    class_id = 10052,
    x = 58,
    y = 37,
    dir = 11,
    cx = 11,
    cy = -9
  },
  {
    class_id = 10052,
    x = 62,
    y = 35,
    dir = 11,
    cx = 11,
    cy = -10
  },
  {
    class_id = 10052,
    x = 66,
    y = 33,
    dir = 11,
    cx = 3,
    cy = -11
  },
  {
    class_id = 10052,
    x = 56,
    y = 32,
    dir = 11,
    cx = 8,
    cy = 8
  },
  {
    class_id = 10052,
    x = 56,
    y = 27,
    dir = 17,
    cx = 10,
    cy = -1
  },
  {
    class_id = 10052,
    x = 60,
    y = 29,
    dir = 17,
    cx = -9,
    cy = -5
  },
  {
    class_id = 10052,
    x = 40,
    y = 35,
    dir = 17,
    cx = 11,
    cy = -9
  },
  {
    class_id = 10052,
    x = 45,
    y = 42,
    dir = 11,
    cx = 2,
    cy = 6
  },
  {
    class_id = 10052,
    x = 62,
    y = 32,
    dir = 11,
    cx = 2,
    cy = -2
  },
  {
    class_id = 10052,
    x = 54,
    y = 35,
    dir = 11,
    cx = 0,
    cy = -6
  },
  {
    class_id = 10052,
    x = 54,
    y = 39,
    dir = 17,
    cx = 10,
    cy = 3
  },
  {
    class_id = 10062,
    x = 54,
    y = 30,
    dir = 0,
    cx = -11,
    cy = -7
  },
  {
    class_id = 10092,
    x = 21,
    y = 33,
    dir = 0,
    cx = -2,
    cy = 4
  },
  {
    class_id = 10092,
    x = 32,
    y = 38,
    dir = 0,
    cx = -5,
    cy = -7
  },
  {
    class_id = 10062,
    x = 51,
    y = 33,
    dir = 0,
    cx = 11,
    cy = 7
  },
  {
    class_id = 10046,
    x = 73,
    y = 27,
    dir = 1,
    cx = 9,
    cy = -6
  },
  {
    class_id = 10046,
    x = 43,
    y = 12,
    dir = 0,
    cx = 7,
    cy = 6
  },
  {
    class_id = 10046,
    x = 38,
    y = 15,
    dir = 0,
    cx = -11,
    cy = 7
  },
  {floor_index = 1},
  {wall_index = 1}
}
