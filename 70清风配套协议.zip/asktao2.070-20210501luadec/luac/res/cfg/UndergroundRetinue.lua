return {
  Retinue = {
    [CHS[7100488]] = {
      name = CHS[7100488],
      type = 1,
      icon = 6129,
      polar = 1,
      fightType = 1,
      color = 1,
      skillList = {},
      effect1 = CHS[7100502],
      effect2 = CHS[7100526]
    },
    [CHS[7100489]] = {
      name = CHS[7100489],
      type = 1,
      icon = 6136,
      polar = 4,
      fightType = 2,
      color = 2,
      skillList = {"B4"},
      effect1 = CHS[7100503],
      effect2 = CHS[7100527]
    },
    [CHS[7100490]] = {
      name = CHS[7100490],
      type = 1,
      icon = 6134,
      polar = 2,
      fightType = 4,
      color = 2,
      skillList = {"D4", "B2"},
      effect1 = CHS[7100504],
      effect2 = CHS[7100528]
    },
    [CHS[7100491]] = {
      name = CHS[7100491],
      type = 1,
      icon = 6231,
      polar = 3,
      fightType = 1,
      color = 1,
      skillList = {},
      effect1 = CHS[7100505],
      effect2 = CHS[7100529]
    },
    [CHS[7100492]] = {
      name = CHS[7100492],
      type = 1,
      icon = 6201,
      polar = 5,
      fightType = 3,
      color = 1,
      skillList = {"C4", "B2"},
      effect1 = CHS[7100506],
      effect2 = CHS[7100530]
    },
    [CHS[7100493]] = {
      name = CHS[7100493],
      type = 1,
      icon = 6307,
      polar = 2,
      fightType = 3,
      color = 1,
      skillList = {"C4", "B2"},
      effect1 = CHS[7100507],
      effect2 = CHS[7100531]
    },
    [CHS[7100494]] = {
      name = CHS[7100494],
      type = 1,
      icon = 51525,
      polar = 3,
      fightType = 4,
      color = 3,
      skillList = {"D4", "B2"},
      effect1 = CHS[7100508],
      effect2 = CHS[7100532]
    },
    [CHS[7100495]] = {
      name = CHS[7100495],
      type = 1,
      icon = 51526,
      polar = 3,
      fightType = 2,
      color = 3,
      skillList = {"B4"},
      effect1 = CHS[7100509],
      effect2 = CHS[7100533]
    },
    [CHS[7100496]] = {
      name = CHS[7100496],
      type = 2,
      icon = 6140,
      polar = 1,
      fightType = 4,
      color = 1,
      skillList = {"D4", "B2"},
      effect1 = CHS[7100510],
      effect2 = CHS[7100534]
    },
    [CHS[7100497]] = {
      name = CHS[7100497],
      type = 2,
      icon = 6141,
      polar = 1,
      fightType = 3,
      color = 1,
      skillList = {"C3", "B2"},
      effect1 = CHS[7100511],
      effect2 = CHS[7100535]
    },
    [CHS[7100498]] = {
      name = CHS[7100498],
      type = 2,
      icon = 6148,
      polar = 2,
      fightType = 1,
      color = 1,
      skillList = {},
      effect1 = CHS[7100512],
      effect2 = CHS[7100536]
    },
    [CHS[7100499]] = {
      name = CHS[7100499],
      type = 2,
      icon = 6313,
      polar = 4,
      fightType = 2,
      color = 1,
      skillList = {"B4"},
      effect1 = CHS[7100513],
      effect2 = CHS[7100537]
    },
    [CHS[7100500]] = {
      name = CHS[7100500],
      type = 2,
      icon = 20059,
      polar = 5,
      fightType = 3,
      color = 2,
      skillList = {"C3", "B2"},
      effect1 = CHS[7100514],
      effect2 = CHS[7100538]
    },
    [CHS[7100501]] = {
      name = CHS[7100501],
      type = 2,
      icon = 20058,
      polar = 4,
      fightType = 4,
      color = 1,
      skillList = {"D3", "B2"},
      effect1 = CHS[7100515],
      effect2 = CHS[7100539]
    },
    [CHS[7100590]] = {
      name = CHS[7100590],
      type = 2,
      icon = 20051,
      polar = 5,
      fightType = 2,
      color = 2,
      skillList = {"B3"},
      effect1 = CHS[7100516],
      effect2 = CHS[7100540]
    },
    [CHS[7100611]] = {
      name = CHS[7100611],
      type = 2,
      icon = 6272,
      polar = 5,
      fightType = 1,
      color = 3,
      skillList = {"lpqj"},
      effect1 = CHS[7100517],
      effect2 = CHS[7100541]
    },
    [CHS[7100612]] = {
      name = CHS[7100612],
      type = 3,
      icon = 20004,
      polar = 4,
      fightType = 1,
      color = 1,
      skillList = {"lpqj"},
      effect1 = CHS[7100518],
      effect2 = CHS[7100542]
    },
    [CHS[7100613]] = {
      name = CHS[7100613],
      type = 3,
      icon = 20005,
      polar = 4,
      fightType = 3,
      color = 1,
      skillList = {"C3", "B2"},
      effect1 = CHS[7100519],
      effect2 = CHS[7100543]
    },
    [CHS[7100614]] = {
      name = CHS[7100614],
      type = 3,
      icon = 20006,
      polar = 3,
      fightType = 1,
      color = 2,
      skillList = {"lpqj"},
      effect1 = CHS[7100520],
      effect2 = CHS[7100544]
    },
    [CHS[7100615]] = {
      name = CHS[7100615],
      type = 3,
      icon = 20007,
      polar = 2,
      fightType = 4,
      color = 2,
      skillList = {"D3", "B2"},
      effect1 = CHS[7100521],
      effect2 = CHS[7100545]
    },
    [CHS[7100616]] = {
      name = CHS[7100616],
      type = 3,
      icon = 20008,
      polar = 1,
      fightType = 2,
      color = 1,
      skillList = {"B3"},
      effect1 = CHS[7100522],
      effect2 = CHS[7100546]
    },
    [CHS[7100618]] = {
      name = CHS[7100618],
      type = 3,
      icon = 20009,
      polar = 2,
      fightType = 2,
      color = 1,
      skillList = {"B3"},
      effect1 = CHS[7100523],
      effect2 = CHS[7100547]
    },
    [CHS[7100619]] = {
      name = CHS[7100619],
      type = 3,
      icon = 20010,
      polar = 3,
      fightType = 4,
      color = 1,
      skillList = {"D3", "B2"},
      effect1 = CHS[7100524],
      effect2 = CHS[7100548]
    },
    [CHS[7100620]] = {
      name = CHS[7100620],
      type = 3,
      icon = 20011,
      polar = 2,
      fightType = 3,
      color = 3,
      skillList = {"C3", "B2"},
      effect1 = CHS[7100525],
      effect2 = CHS[7100549]
    }
  },
  typeEffect = {
    {
      CHS[7100551],
      CHS[7100550],
      CHS[7100552]
    },
    {
      CHS[7100554],
      CHS[7100553],
      CHS[7100555]
    },
    {
      CHS[7100557],
      CHS[7100556],
      CHS[7100558]
    }
  },
  polarEffect = {
    {
      CHS[7100559],
      CHS[7100560],
      CHS[7100561]
    },
    {
      CHS[7100562],
      CHS[7100563],
      CHS[7100564]
    },
    {
      CHS[7100565],
      CHS[7100566],
      CHS[7100567]
    },
    {
      CHS[7100568],
      CHS[7100569],
      CHS[7100570]
    },
    {
      CHS[7100571],
      CHS[7100572],
      CHS[7100573]
    }
  },
  typeChs = {
    CHS[7100575],
    CHS[7100576],
    CHS[7100577]
  },
  polarChs = {
    CHS[7100578],
    CHS[7100579],
    CHS[7100580],
    CHS[7100581],
    CHS[7100582]
  },
  fightChs = {
    CHS[7100583],
    CHS[7100584],
    CHS[7100585],
    CHS[7100586]
  }
}
