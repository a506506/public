return {
  ["diem"] = "diem.mp3",
  ["dief"] = "dief.mp3",
  ["escape"] = "escape.mp3",
  ["recover"] = "recover.mp3",
  ["button"] = "button.mp3",
  ["item"] = "item.mp3",
  ["money"] = "money.mp3",
  ["level_up"] = "level_up.mp3",
  ["friend"] = "friend.mp3",
  ["cast"] = "cast.mp3",
  ["cast2"] = "cast2.mp3",
  ["cast5"] = "cast5.mp3",
  ["cast6"] = "cast6.mp3",
  ["cast7"] = "cast7.mp3",
  ["cast9"] = "cast9.mp3",
  ["bianshen"] = "bianshen.mp3",
  ["yaoqian"] = "yaoqian.mp3",
  ["diaoqian"] = "diaoqian.mp3",
  [CHS[3001666]] = "Music02002.mp3",
  [CHS[3001667]] = "Music01001.mp3",
  [CHS[3001668]] = "Music01001.mp3",
  [CHS[3001669]] = "Music02002.mp3",
  [CHS[3001670]] = "Music02002.mp3",
  [CHS[3001671]] = "Music02002.mp3",
  [CHS[3001672]] = "Music02002.mp3",
  [CHS[3001673]] = "Music02002.mp3",
  [CHS[3001674]] = "Music02002.mp3",
  [CHS[3001675]] = "Music02002.mp3",
  [CHS[3001676]] = "Music02002.mp3",
  [CHS[3001677]] = "Music02002.mp3",
  ["飞仙镇"] = "Music02002.mp3",
  ["祈雪台"] = "Music02002.mp3",
  ["青竹镇"] = "Music02002.mp3",
  ["幻变林地"] = "Music02002.mp3",
  ["童真幻境"] = "Music02002.mp3",
  ["瑶池"] = "Music02012.mp3",
  ["蛟龙宫殿"] = "Music02009.mp3",
  ["王母寝宫"] = "Music02002.mp3",
  [CHS[3001679]] = "Music02007.mp3",
  [CHS[3001680]] = "Music02007.mp3",
  [CHS[3001681]] = "Music02007.mp3",
  ["东胜岛"] = "Music02007.mp3",
  ["方丈岛"] = "Music02007.mp3",
  ["揽仙镇外"] = "Music02001.mp3",
  ["卧龙坡"] = "Music02001.mp3",
  [CHS[3001684]] = "Music02007.mp3",
  ["十里坡"] = "Music02001.mp3",
  ["不周山"] = "Music02001.mp3",
  [CHS[3001686]] = "Music02007.mp3",
  ["百花岛"] = "Music02001.mp3",
  ["百花谷一"] = "Music02001.mp3",
  ["百花谷二"] = "Music02001.mp3",
  ["百花谷三"] = "Music02001.mp3",
  ["百花谷四"] = "Music02001.mp3",
  ["百花谷五"] = "Music02001.mp3",
  ["百花谷六"] = "Music02001.mp3",
  ["百花谷七"] = "Music02001.mp3",
  ["百花丛中"] = "Music02001.mp3",
  ["风月谷"] = "Music02001.mp3",
  ["桃柳林"] = "Music02001.mp3",
  ["玉露仙池"] = "Music02001.mp3",
  [CHS[7333441]] = "Music02001.mp3",
  [CHS[3001696]] = "Music02011.mp3",
  [CHS[3001697]] = "Music02011.mp3",
  [CHS[3001698]] = "Music02011.mp3",
  [CHS[3001699]] = "Music02011.mp3",
  [CHS[3001700]] = "Music02011.mp3",
  [CHS[3001701]] = "Music02011.mp3",
  [CHS[3001702]] = "Music02011.mp3",
  [CHS[3001703]] = "Music02011.mp3",
  [CHS[3001704]] = "Music02011.mp3",
  [CHS[3001705]] = "Music02011.mp3",
  [CHS[3001706]] = "Music02011.mp3",
  [CHS[3001707]] = "Music02011.mp3",
  [CHS[4100107]] = "Music02011.mp3",
  [CHS[7000063]] = "Music02011.mp3",
  [CHS[3001708]] = "Music03001.mp3",
  [CHS[3001709]] = "Music03001.mp3",
  [CHS[3001710]] = "Music03001.mp3",
  ["断念之桥"] = "Music02021.mp3",
  ["心魔窟"] = "Music02011.mp3",
  ["通天剑阵"] = "Music03001.mp3",
  ["西岐大营"] = "Music03001.mp3",
  ["过去的七宝林"] = "Music01001.mp3",
  ["演练等候区"] = "Music02002.mp3",
  ["护粮演练场"] = "Music03001.mp3",
  ["上古遗迹"] = "Music03001.mp3",
  ["乱斗场"] = "Music03001.mp3",
  ["准备厅"] = "Music03001.mp3",
  ["库房"] = "Music03001.mp3",
  ["门派迷阵"] = "Music03001.mp3",
  ["fight1"] = "Music03003.mp3",
  ["fight2"] = "Music03004.mp3",
  [CHS[3001711]] = "Music02007.mp3",
  ["兰若寺后山"] = "Music02001.mp3",
  ["幻·兰若寺"] = "Music02007.mp3",
  ["幻·后山"] = "Music02001.mp3",
  ["幻·洞穴"] = "Music02011.mp3",
  [CHS[3001713]] = "Music02011.mp3",
  [CHS[3001714]] = "Music02011.mp3",
  [CHS[3001715]] = "Music02011.mp3",
  [CHS[7278001]] = "Music02011.mp3",
  [CHS[7278002]] = "Music02011.mp3",
  [CHS[7278003]] = "Music02011.mp3",
  [CHS[7278004]] = "Music02011.mp3",
  ["幻·黑风一层"] = "Music02011.mp3",
  ["幻·黑风二层"] = "Music02011.mp3",
  ["幻·黑风三层"] = "Music02011.mp3",
  ["地狱深渊"] = "Music02021.mp3",
  ["地府竞技场"] = "Music02021.mp3",
  ["监斩台"] = "Music02021.mp3",
  [CHS[3001716]] = "Music02011.mp3",
  [CHS[3001717]] = "Music02011.mp3",
  [CHS[3001718]] = "Music02011.mp3",
  [CHS[3001719]] = "Music02011.mp3",
  [CHS[3001720]] = "Music02011.mp3",
  [CHS[3001721]] = "Music02011.mp3",
  [CHS[3001722]] = "Music03001.mp3",
  [CHS[3001723]] = "Music03001.mp3",
  ["loginMusic"] = "Music01006.mp3",
  ["东海深宫"] = "Music02009.mp3",
  [CHS[4000381]] = "Music02007.mp3",
  ["百花小径"] = "Music02007.mp3",
  ["洞房"] = "Music02002.mp3",
  ["marryMusic"] = "wedding.mp3",
  ["碧游宫"] = "Music02009.mp3",
  ["大罗宫"] = "Music02009.mp3",
  ["七宝林"] = "Music01001.mp3",
  ["避暑山庄幻境"] = "Music01001.mp3",
  ["八德池"] = "Music02009.mp3",
  ["西昆仑"] = "Music02009.mp3",
  [CHS[6000317]] = "Music02007.mp3",
  ["海底迷宫"] = "Music02010.mp3",
  ["昆仑云海"] = "Music02010.mp3",
  [CHS[6000320]] = "Music02011.mp3",
  [CHS[6000323]] = "Music02011.mp3",
  [CHS[6000326]] = "Music02011.mp3",
  [CHS[6000339]] = "Music02011.mp3",
  [CHS[6000309]] = "Music02011.mp3",
  ["火焰迷阵"] = "Music02011.mp3",
  [CHS[7366707]] = "Music02011.mp3",
  ["龙宫"] = "Music02009.mp3",
  ["龙宫大殿"] = "Music02009.mp3",
  ["灵霄宝殿"] = "Music02012.mp3",
  ["八仙瑶池"] = "Music02012.mp3",
  ["广寒宫"] = "Music02012.mp3",
  [CHS[2000120]] = "Bobing.mp3",
  ["吐蕃境内"] = "Music02001.mp3",
  ["丰收之地"] = "Music02001.mp3",
  ["紫金四皓峰"] = "Music02002.mp3",
  ["龙崆洞"] = "Music02011.mp3",
  ["阎罗殿"] = "Music02011.mp3",
  ["云中道"] = "Music02010.mp3",
  ["李家庄"] = "Music01001.mp3",
  ["李氏渔村"] = "Music01001.mp3",
  ["李氏渔村(3天前)"] = "Music01001.mp3",
  ["落魄崖"] = "Music02001.mp3",
  ["乡间小路"] = "Music02007.mp3",
  ["缘分山谷"] = "Music02001.mp3",
  ["通天塔顶"] = "Music03001.mp3",
  ["神秘房间"] = "Music03001.mp3",
  [CHS[7002022]] = "Music02007.mp3",
  [CHS[7002023]] = "Music02010.mp3",
  [CHS[7002024]] = "Music03001.mp3",
  [CHS[5400028]] = "Music03001.mp3",
  [CHS[5400030]] = "Music03001.mp3",
  [CHS[7003008]] = "Music02011.mp3",
  [CHS[7003009]] = "Music02011.mp3",
  ["万仙阵"] = "Music02011.mp3",
  ["混沌之牢"] = "Music02021.mp3",
  ["洪荒之巅"] = "Music03001.mp3",
  [CHS[7002105]] = "Music03001.mp3",
  [CHS[7002128]] = "Music03001.mp3",
  [CHS[7002184]] = "Music03001.mp3",
  [CHS[7002185]] = "Music03001.mp3",
  [CHS[7002186]] = "Music03001.mp3",
  ["主播楼兰城"] = "Music03001.mp3",
  ["主播赛场"] = "Music03001.mp3",
  [CHS[7100160]] = "Music02011.mp3",
  [CHS[7100157]] = "Music02011.mp3",
  [CHS[7100158]] = "Music02011.mp3",
  [CHS[7190148]] = "Music02011.mp3",
  [CHS[7190149]] = "Music02011.mp3",
  [CHS[7190257]] = "Music02001.mp3",
  [CHS[7190258]] = "Music02001.mp3",
  [CHS[7190259]] = "Music02001.mp3",
  [CHS[7190260]] = "Music02001.mp3",
  ["跨服楼兰城"] = "Music03001.mp3",
  ["跨服战场"] = "Music03001.mp3",
  ["月跨服楼兰城"] = "Music03001.mp3",
  ["南部战场"] = "Music03001.mp3",
  ["北部战场"] = "Music03001.mp3",
  ["东部战旗区"] = "Music03001.mp3",
  ["西部战旗区"] = "Music03001.mp3",
  ["中央战场"] = "Music03001.mp3",
  ["竞技楼兰城"] = "Music03001.mp3",
  ["跨服竞技战场"] = "Music03001.mp3",
  ["宝物守卫战"] = "Music03001.mp3",
  ["月试道楼兰城"] = "Music03001.mp3",
  ["月跨服试道战场"] = "Music03001.mp3",
  [CHS[7002198]] = "Music02002.mp3",
  ["万妖窟一层"] = "Music02011.mp3",
  ["万妖窟二层"] = "Music02011.mp3",
  ["万妖窟三层"] = "Music02011.mp3",
  ["万妖窟四层"] = "Music02011.mp3",
  ["万妖窟五层"] = "Music02011.mp3",
  ["先锋营地"] = "Music03001.mp3",
  ["中洲古城"] = "Music03001.mp3",
  [CHS[7002227]] = "Music02011.mp3",
  [CHS[7002228]] = "Music02011.mp3",
  [CHS[7002229]] = "Music02011.mp3",
  ["粽仙楼一层"] = "Music03001.mp3",
  ["粽仙楼二层"] = "Music03001.mp3",
  ["粽仙楼三层"] = "Music03001.mp3",
  ["雪域冰原"] = "Music02007.mp3",
  ["迷境花树"] = "Music02010.mp3",
  ["水云间"] = "Music02010.mp3",
  ["热砂荒漠"] = "Music02007.mp3",
  [CHS[7366723]] = "Music02007.mp3",
  [CHS[7366724]] = "Music02011.mp3",
  ["智者宝塔一层"] = "Music02011.mp3",
  ["智者宝塔二层"] = "Music02011.mp3",
  ["智者宝塔顶层"] = "Music02011.mp3",
  ["矿区"] = "Music03001.mp3",
  ["左方帮派营地"] = "Music03001.mp3",
  ["右方帮派营地"] = "Music03001.mp3",
  ["飘渺仙府"] = "Music02009.mp3",
  ["仙府秘境"] = "Music02010.mp3",
  ["仙府大殿"] = "Music02009.mp3",
  ["弑神殿"] = "Music02012.mp3",
  ["朱府-前庭"] = "Music02020.mp3",
  ["朱府-房屋"] = "Music02020.mp3",
  ["赵府-房屋"] = "Music02020.mp3",
  ["张府-前庭"] = "Music02020.mp3",
  ["张府-房屋"] = "Music02020.mp3",
  ["陈家-前庭"] = "Music02020.mp3",
  ["陈家-房屋"] = "Music02020.mp3",
  ["莫家"] = "Music02020.mp3",
  ["客栈-甲字客房"] = "Music02020.mp3",
  ["客栈-乙字客房"] = "Music02020.mp3",
  ["客栈-丙字客房"] = "Music02020.mp3",
  ["客栈-丁字客房"] = "Music02020.mp3",
  ["客栈-戊字客房"] = "Music02020.mp3",
  ["客栈-神秘客房"] = "Music02020.mp3",
  ["伊撮毛家"] = "Music02020.mp3",
  ["司条腿家"] = "Music02020.mp3",
  ["小舍-前庭"] = "Music02020.mp3",
  ["小舍-房屋"] = "Music02020.mp3",
  ["小舍-后院"] = "Music02020.mp3",
  ["雅筑-前庭"] = "Music02020.mp3",
  ["雅筑-房屋"] = "Music02020.mp3",
  ["雅筑-后院"] = "Music02020.mp3",
  ["豪宅-前庭"] = "Music02020.mp3",
  ["豪宅-房屋"] = "Music02020.mp3",
  ["豪宅-后院"] = "Music02020.mp3",
  ["神秘房间-前庭"] = "Music02011.mp3",
  ["神秘房间-室内"] = "Music02011.mp3",
  ["神秘房间-后院"] = "Music02011.mp3",
  ["神秘幻境"] = "Music02001.mp3",
  ["明察秋毫-前庭"] = "Music02020.mp3",
  ["明察秋毫-房屋"] = "Music02020.mp3",
  ["帮派后院"] = "Music02020.mp3",
  ["赵老板居所-前庭"] = "Music02020.mp3",
  ["赵老板居所-房屋"] = "Music02020.mp3",
  ["乐善施居所-前庭"] = "Music02020.mp3",
  ["乐善施居所-房屋"] = "Music02020.mp3",
  ["钱老板居所-前庭"] = "Music02020.mp3",
  ["钱老板居所-房屋"] = "Music02020.mp3",
  ["李芸家"] = "Music02020.mp3",
  ["李芸家(3天前)"] = "Music02020.mp3",
  ["颂德小镇"] = "Music01001.mp3",
  ["颂德医馆"] = "Music02020.mp3",
  ["西门家-前庭"] = "Music02020.mp3",
  ["西门家-房屋"] = "Music02020.mp3",
  ["众仙塔一层"] = "Music03001.mp3",
  ["众仙塔二层"] = "Music03001.mp3",
  ["争霸楼兰城"] = "Music03001.mp3",
  ["争霸战场"] = "Music03001.mp3",
  ["城市赛场"] = "Music03001.mp3",
  ["决斗场"] = "Music03001.mp3",
  ["论道场"] = "Music03001.mp3",
  ["雪精圣地"] = "Music02007.mp3",
  ["埋骨之地"] = "Music02007.mp3",
  ["无名仙境"] = "Music02007.mp3",
  ["极热之地"] = "Music02007.mp3",
  ["证道殿"] = "Music02009.mp3",
  ["证道殿二层"] = "Music02009.mp3",
  ["官府"] = "Music02009.mp3",
  ["云霄宫"] = "Music02012.mp3",
  ["南天门"] = "Music02012.mp3",
  ["喜来客栈"] = "Music02002.mp3",
  ["迷仙镇"] = "Music02002.mp3",
  ["聚仙镇"] = "Music02002.mp3",
  ["仙粽秘境"] = "Music02002.mp3",
  ["帮派别院"] = "Music02020.mp3",
  ["记忆中的大罗宫"] = "Music02009.mp3",
  ["小童父母家"] = "Music02020.mp3",
  ["小童叔叔家"] = "Music02020.mp3",
  ["常舌馥家"] = "Music02020.mp3",
  ["小童爷爷家"] = "Music02020.mp3",
  ["天字甲号客房"] = "Music02020.mp3",
  ["天字乙号客房"] = "Music02020.mp3",
  ["天字丙号客房"] = "Music02020.mp3",
  ["地字甲号客房"] = "Music02020.mp3",
  ["地字乙号客房"] = "Music02020.mp3",
  ["地字丙号客房"] = "Music02020.mp3",
  ["虞天仇家"] = "Music02020.mp3",
  ["一眨眼家"] = "Music02020.mp3",
  ["医馆-房屋"] = "Music02020.mp3",
  ["医馆-后院"] = "Music02020.mp3",
  ["黑风寨"] = "Music02007.mp3",
  ["歇马坡"] = "Music02001.mp3",
  ["潜龙寨后山山洞"] = "Music02011.mp3",
  ["罗刹寨"] = "Music02011.mp3",
  ["罗刹寨石洞"] = "Music02011.mp3",
  ["潜龙寨暗库"] = "Music02011.mp3",
  ["潜龙寨"] = "Music03001.mp3",
  ["潜龙寨仓库"] = "Music02020.mp3",
  ["梁府-前庭"] = "Music02020.mp3",
  ["梁府-房屋"] = "Music02020.mp3",
  ["幻·大殿"] = "Music02009.mp3",
  ["幻·秘境"] = "Music02010.mp3",
  ["幻·仙府"] = "Music02009.mp3",
  ["幻·烈火涧"] = "Music02011.mp3",
  ["幻·烈火涧西"] = "Music02011.mp3",
  ["幻·烈火涧北"] = "Music02011.mp3",
  ["幻·烈火涧东"] = "Music02011.mp3",
  ["相约元宵客栈"] = "Music02002.mp3",
  ["飞仙客栈"] = "Music02002.mp3",
  ["万花谷"] = "Music02001.mp3",
  ["千面酒会"] = "Music02002.mp3",
  ["冰火秘境"] = "Music03001.mp3",
  ["登高驱邪"] = "Music02007.mp3",
  ["鬼域"] = "Music02011.mp3",
  ["鬼门关"] = "Music02021.mp3",
  ["奈何桥"] = "Music02021.mp3",
  ["地府引魂"] = "Music02021.mp3",
  ["地府主城"] = "Music02021.mp3",
  ["修炼迷阵"] = "Music02011.mp3",
  ["火魔深渊"] = "Music02021.mp3",
  ["对决场"] = "Music02002.mp3",
  ["对决场(踩影子)"] = "Music02002.mp3",
  ["雪球大战"] = "Music02002.mp3",
  ["断魂窟"] = "Music02021.mp3",
  ["灵木幻境"] = "Music02010.mp3",
  ["地宫1_1"] = "Music02021.mp3",
  ["地宫2_1"] = "Music02021.mp3",
  ["地宫3_1"] = "Music02021.mp3",
  ["地宫4_1"] = "Music02021.mp3",
  ["地宫5_1"] = "Music02021.mp3",
  ["地宫6_1"] = "Music02021.mp3",
  ["地宫7_1"] = "Music02021.mp3",
  ["地宫8_1"] = "Music02021.mp3",
  ["地宫9_1"] = "Music02021.mp3",
  ["地宫10_1"] = "Music02021.mp3",
  ["地宫11_1"] = "Music02021.mp3",
  ["地宫12_1"] = "Music02021.mp3",
  ["地宫13_1"] = "Music02021.mp3",
  ["地宫14_1"] = "Music02021.mp3",
  ["地宫15_1"] = "Music02021.mp3",
  ["地宫16_1"] = "Music02021.mp3",
  ["地宫17_1"] = "Music02021.mp3",
  ["地宫18_1"] = "Music02021.mp3",
  ["地宫19_1"] = "Music02021.mp3",
  ["地宫20_1"] = "Music02021.mp3",
  ["地宫21_1"] = "Music02021.mp3",
  ["地宫22_1"] = "Music02021.mp3",
  ["地宫23_1"] = "Music02021.mp3",
  ["地宫24_1"] = "Music02021.mp3",
  ["地宫25_1"] = "Music02021.mp3",
  ["地宫26_1"] = "Music02021.mp3",
  ["地宫27_1"] = "Music02021.mp3",
  ["地宫28_1"] = "Music02021.mp3",
  ["地宫29_1"] = "Music02021.mp3",
  ["地宫30_1"] = "Music02021.mp3",
  ["地宫1_2"] = "Music02021.mp3",
  ["地宫2_2"] = "Music02021.mp3",
  ["地宫3_2"] = "Music02021.mp3",
  ["地宫4_2"] = "Music02021.mp3",
  ["地宫5_2"] = "Music02021.mp3",
  ["地宫6_2"] = "Music02021.mp3",
  ["地宫7_2"] = "Music02021.mp3",
  ["地宫8_2"] = "Music02021.mp3",
  ["地宫9_2"] = "Music02021.mp3",
  ["地宫10_2"] = "Music02021.mp3",
  ["地宫11_2"] = "Music02021.mp3",
  ["地宫12_2"] = "Music02021.mp3",
  ["地宫13_2"] = "Music02021.mp3",
  ["地宫14_2"] = "Music02021.mp3",
  ["地宫15_2"] = "Music02021.mp3",
  ["地宫16_2"] = "Music02021.mp3",
  ["地宫17_2"] = "Music02021.mp3",
  ["地宫18_2"] = "Music02021.mp3",
  ["地宫19_2"] = "Music02021.mp3",
  ["地宫20_2"] = "Music02021.mp3",
  ["地宫21_2"] = "Music02021.mp3",
  ["地宫22_2"] = "Music02021.mp3",
  ["地宫23_2"] = "Music02021.mp3",
  ["地宫24_2"] = "Music02021.mp3",
  ["地宫25_2"] = "Music02021.mp3",
  ["地宫26_2"] = "Music02021.mp3",
  ["地宫27_2"] = "Music02021.mp3",
  ["地宫28_2"] = "Music02021.mp3",
  ["地宫29_2"] = "Music02021.mp3",
  ["地宫30_2"] = "Music02021.mp3",
  ["地宫1_3"] = "Music02021.mp3",
  ["地宫2_3"] = "Music02021.mp3",
  ["地宫3_3"] = "Music02021.mp3",
  ["地宫4_3"] = "Music02021.mp3",
  ["地宫5_3"] = "Music02021.mp3",
  ["地宫6_3"] = "Music02021.mp3",
  ["地宫7_3"] = "Music02021.mp3",
  ["地宫8_3"] = "Music02021.mp3",
  ["地宫9_3"] = "Music02021.mp3",
  ["地宫10_3"] = "Music02021.mp3",
  ["地宫11_3"] = "Music02021.mp3",
  ["地宫12_3"] = "Music02021.mp3",
  ["地宫13_3"] = "Music02021.mp3",
  ["地宫14_3"] = "Music02021.mp3",
  ["地宫15_3"] = "Music02021.mp3",
  ["地宫16_3"] = "Music02021.mp3",
  ["地宫17_3"] = "Music02021.mp3",
  ["地宫18_3"] = "Music02021.mp3",
  ["地宫19_3"] = "Music02021.mp3",
  ["地宫20_3"] = "Music02021.mp3",
  ["地宫21_3"] = "Music02021.mp3",
  ["地宫22_3"] = "Music02021.mp3",
  ["地宫23_3"] = "Music02021.mp3",
  ["地宫24_3"] = "Music02021.mp3",
  ["地宫25_3"] = "Music02021.mp3",
  ["地宫26_3"] = "Music02021.mp3",
  ["地宫27_3"] = "Music02021.mp3",
  ["地宫28_3"] = "Music02021.mp3",
  ["地宫29_3"] = "Music02021.mp3",
  ["地宫30_3"] = "Music02021.mp3",
  ["地宫夹层"] = "Music02021.mp3",
  ["演武场"] = "Music03001.mp3",
  ["陈塘关海滨"] = "Music02007.mp3",
  ["陈塘关"] = "Music01001.mp3",
  ["东海海底"] = "Music02010.mp3",
  ["goldcast1"] = "goldcast1.mp3",
  ["goldcast2"] = "goldcast2.mp3",
  ["goldcast3"] = "goldcast3.mp3",
  ["woodcast1"] = "woodcast1.mp3",
  ["woodcast2"] = "woodcast2.mp3",
  ["woodcast3"] = "woodcast3.mp3",
  ["watercast1"] = "watercast1.mp3",
  ["watercast2"] = "watercast2.mp3",
  ["watercast3"] = "watercast3.mp3",
  ["firecast1"] = "firecast1.mp3",
  ["firecast2"] = "firecast2.mp3",
  ["firecast3"] = "firecast3.mp3",
  ["earthcast1"] = "earthcast1.mp3",
  ["earthcast2"] = "earthcast2.mp3",
  ["earthcast3"] = "earthcast3.mp3",
  ["yanhuabaozhu"] = "yanhuabaozhu.mp3",
  ["yanhua"] = "yanhua.mp3",
  ["OpenDoor"] = "OpenDoor.mp3",
  [8238] = {
    "Special_1.mp3",
    0
  },
  [1332] = {
    "Special_1.mp3",
    0
  },
  [8389] = {
    "Special_2.mp3",
    0
  },
  [8400] = {
    "Special_2.mp3",
    0
  },
  [8221] = {
    "Special_3.mp3",
    0
  },
  [8222] = {
    "Special_4.mp3",
    0
  },
  [1347] = {
    "Special_5.mp3",
    0
  },
  [1330] = {
    "Special_6.mp3",
    0
  },
  [3005] = {
    "firecast1.mp3",
    0
  },
  [6041] = {
    "firecast1.mp3",
    0.1
  },
  [6043] = {
    "firecast1.mp3",
    0
  },
  [3018] = {
    "firecast1.mp3",
    0
  },
  [5010] = {
    "firecast1.mp3",
    0.1
  },
  [3007] = {
    "firecast2.mp3",
    0
  },
  [6061] = {
    "firecast2.mp3",
    0
  },
  [6053] = {
    "firecast2.mp3",
    0
  },
  [3014] = {
    "firecast2.mp3",
    0
  },
  [5012] = {
    "firecast2.mp3",
    0
  },
  [6040] = {
    "firecast3.mp3",
    0
  },
  [3006] = {
    "firecast3.mp3",
    0
  },
  [6051] = {
    "firecast3.mp3",
    0
  },
  [3016] = {
    "firecast3.mp3",
    0
  },
  [5011] = {
    "firecast3.mp3",
    0
  },
  [2019] = {
    "watercast1.mp3",
    0
  },
  [6049] = {
    "watercast1.mp3",
    0
  },
  [6042] = {
    "watercast1.mp3",
    0
  },
  [3021] = {
    "watercast1.mp3",
    0
  },
  [5006] = {
    "watercast1.mp3",
    0
  },
  [6047] = {
    "watercast2.mp3",
    0
  },
  [6060] = {
    "watercast2.mp3",
    0.1
  },
  [3002] = {
    "watercast2.mp3",
    0
  },
  [3025] = {
    "watercast2.mp3",
    0
  },
  [5009] = {
    "watercast2.mp3",
    0
  },
  [3001] = {
    "watercast3.mp3",
    0
  },
  [6059] = {
    "watercast3.mp3",
    0
  },
  [6045] = {
    "watercast3.mp3",
    0
  },
  [3017] = {
    "watercast3.mp3",
    0
  },
  [5007] = {
    "watercast3.mp3",
    0
  },
  [6063] = {
    "woodcast1.mp3",
    0.1
  },
  [6034] = {
    "woodcast1.mp3",
    0
  },
  [2016] = {
    "woodcast1.mp3",
    0
  },
  [3020] = {
    "woodcast1.mp3",
    0
  },
  [5003] = {
    "woodcast1.mp3",
    0
  },
  [2018] = {
    "woodcast2.mp3",
    0
  },
  [6058] = {
    "woodcast2.mp3",
    0
  },
  [6052] = {
    "woodcast2.mp3",
    0
  },
  [3015] = {
    "woodcast2.mp3",
    0
  },
  [5005] = {
    "woodcast2.mp3",
    0
  },
  [2017] = {
    "woodcast3.mp3",
    0
  },
  [6037] = {
    "woodcast3.mp3",
    0
  },
  [6062] = {
    "woodcast3.mp3",
    0
  },
  [3026] = {
    "woodcast3.mp3",
    0
  },
  [5004] = {
    "woodcast3.mp3",
    0
  },
  [3009] = {
    "earthcast1.mp3",
    0
  },
  [6039] = {
    "earthcast1.mp3",
    0
  },
  [6036] = {
    "earthcast1.mp3",
    0
  },
  [3024] = {
    "earthcast1.mp3",
    0
  },
  [5013] = {
    "earthcast1.mp3",
    0
  },
  [6044] = {
    "earthcast2.mp3",
    0
  },
  [3011] = {
    "earthcast2.mp3",
    0
  },
  [6050] = {
    "earthcast2.mp3",
    0
  },
  [3012] = {
    "earthcast2.mp3",
    0
  },
  [5015] = {
    "earthcast2.mp3",
    0.05
  },
  [3010] = {
    "earthcast3.mp3",
    0
  },
  [6048] = {
    "earthcast3.mp3",
    0
  },
  [6055] = {
    "earthcast3.mp3",
    0
  },
  [3013] = {
    "earthcast3.mp3",
    0
  },
  [5014] = {
    "earthcast3.mp3",
    0
  },
  [6054] = {
    "goldcast1.mp3",
    0
  },
  [2011] = {
    "goldcast1.mp3",
    0
  },
  [6035] = {
    "goldcast1.mp3",
    0
  },
  [3019] = {
    "goldcast1.mp3",
    0
  },
  [2013] = {
    "goldcast1.mp3",
    0
  },
  [2015] = {
    "goldcast2.mp3",
    0
  },
  [6038] = {
    "goldcast2.mp3",
    0
  },
  [6056] = {
    "goldcast2.mp3",
    0
  },
  [3022] = {
    "goldcast2.mp3",
    0
  },
  [5002] = {
    "goldcast2.mp3",
    0
  },
  [2014] = {
    "goldcast3.mp3",
    0
  },
  [6046] = {
    "goldcast3.mp3",
    0
  },
  [6057] = {
    "goldcast3.mp3",
    0
  },
  [3023] = {
    "goldcast3.mp3",
    0
  },
  [5001] = {
    "goldcast3.mp3",
    0
  },
  [8117] = "lipocast3.mp3",
  ["attack_shan"] = "attack_shan.mp3",
  ["attack_jian"] = "attack_jian.mp3",
  ["attack_zhua"] = {
    "attack_zhua.mp3",
    -0.3
  },
  ["attack_chui"] = {
    "attack_chui.mp3",
    -0.4
  },
  ["attack_qiang"] = {
    "attack_qiang.mp3",
    -0.3
  },
  ["attack"] = "attack.mp3"
}
