return {
  [1] = {
    exp = 258,
    jingyandan_exp = 25875,
    gaoji_jingyandan_exp = 258750
  },
  [2] = {
    exp = 336,
    jingyandan_exp = 33637,
    gaoji_jingyandan_exp = 336375
  },
  [3] = {
    exp = 414,
    jingyandan_exp = 41400,
    gaoji_jingyandan_exp = 414000
  },
  [4] = {
    exp = 491,
    jingyandan_exp = 49162,
    gaoji_jingyandan_exp = 491625
  },
  [5] = {
    exp = 569,
    jingyandan_exp = 56925,
    gaoji_jingyandan_exp = 569250
  },
  [6] = {
    exp = 646,
    jingyandan_exp = 64687,
    gaoji_jingyandan_exp = 646875
  },
  [7] = {
    exp = 724,
    jingyandan_exp = 72450,
    gaoji_jingyandan_exp = 724500
  },
  [8] = {
    exp = 802,
    jingyandan_exp = 80212,
    gaoji_jingyandan_exp = 802125
  },
  [9] = {
    exp = 879,
    jingyandan_exp = 87975,
    gaoji_jingyandan_exp = 879750
  },
  [10] = {
    exp = 957,
    jingyandan_exp = 95737,
    gaoji_jingyandan_exp = 957375
  },
  [11] = {
    exp = 1159,
    jingyandan_exp = 103500,
    gaoji_jingyandan_exp = 1035000
  },
  [12] = {
    exp = 1513,
    jingyandan_exp = 111262,
    gaoji_jingyandan_exp = 1112625
  },
  [13] = {
    exp = 2047,
    jingyandan_exp = 119025,
    gaoji_jingyandan_exp = 1190250
  },
  [14] = {
    exp = 2789,
    jingyandan_exp = 126787,
    gaoji_jingyandan_exp = 1267875
  },
  [15] = {
    exp = 3767,
    jingyandan_exp = 134550,
    gaoji_jingyandan_exp = 1345500
  },
  [16] = {
    exp = 5009,
    jingyandan_exp = 142312,
    gaoji_jingyandan_exp = 1423125
  },
  [17] = {
    exp = 6543,
    jingyandan_exp = 150075,
    gaoji_jingyandan_exp = 1500750
  },
  [18] = {
    exp = 8396,
    jingyandan_exp = 157837,
    gaoji_jingyandan_exp = 1578375
  },
  [19] = {
    exp = 10598,
    jingyandan_exp = 165600,
    gaoji_jingyandan_exp = 1656000
  },
  [20] = {
    exp = 13175,
    jingyandan_exp = 173362,
    gaoji_jingyandan_exp = 1733625
  },
  [21] = {
    exp = 20141,
    jingyandan_exp = 181125,
    gaoji_jingyandan_exp = 1811250
  },
  [22] = {
    exp = 28257,
    jingyandan_exp = 188887,
    gaoji_jingyandan_exp = 1888875
  },
  [23] = {
    exp = 37599,
    jingyandan_exp = 196650,
    gaoji_jingyandan_exp = 1966500
  },
  [24] = {
    exp = 48241,
    jingyandan_exp = 204412,
    gaoji_jingyandan_exp = 2044125
  },
  [25] = {
    exp = 60257,
    jingyandan_exp = 212175,
    gaoji_jingyandan_exp = 2121750
  },
  [26] = {
    exp = 73723,
    jingyandan_exp = 219937,
    gaoji_jingyandan_exp = 2199375
  },
  [27] = {
    exp = 88711,
    jingyandan_exp = 227700,
    gaoji_jingyandan_exp = 2277000
  },
  [28] = {
    exp = 105298,
    jingyandan_exp = 235462,
    gaoji_jingyandan_exp = 2354625
  },
  [29] = {
    exp = 123558,
    jingyandan_exp = 243225,
    gaoji_jingyandan_exp = 2432250
  },
  [30] = {
    exp = 143564,
    jingyandan_exp = 250987,
    gaoji_jingyandan_exp = 2509875
  },
  [31] = {
    exp = 169740,
    jingyandan_exp = 258750,
    gaoji_jingyandan_exp = 2587500
  },
  [32] = {
    exp = 198285,
    jingyandan_exp = 266512,
    gaoji_jingyandan_exp = 2665125
  },
  [33] = {
    exp = 229293,
    jingyandan_exp = 274275,
    gaoji_jingyandan_exp = 2742750
  },
  [34] = {
    exp = 262858,
    jingyandan_exp = 282037,
    gaoji_jingyandan_exp = 2820375
  },
  [35] = {
    exp = 299073,
    jingyandan_exp = 289800,
    gaoji_jingyandan_exp = 2898000
  },
  [36] = {
    exp = 338031,
    jingyandan_exp = 297562,
    gaoji_jingyandan_exp = 2975625
  },
  [37] = {
    exp = 346849,
    jingyandan_exp = 305325,
    gaoji_jingyandan_exp = 3053250
  },
  [38] = {
    exp = 355667,
    jingyandan_exp = 313087,
    gaoji_jingyandan_exp = 3130875
  },
  [39] = {
    exp = 364485,
    jingyandan_exp = 320850,
    gaoji_jingyandan_exp = 3208500
  },
  [40] = {
    exp = 373303,
    jingyandan_exp = 328612,
    gaoji_jingyandan_exp = 3286125
  },
  [41] = {
    exp = 382122,
    jingyandan_exp = 336375,
    gaoji_jingyandan_exp = 3363750
  },
  [42] = {
    exp = 390940,
    jingyandan_exp = 344137,
    gaoji_jingyandan_exp = 3441375
  },
  [43] = {
    exp = 399758,
    jingyandan_exp = 351900,
    gaoji_jingyandan_exp = 3519000
  },
  [44] = {
    exp = 408576,
    jingyandan_exp = 359662,
    gaoji_jingyandan_exp = 3596625
  },
  [45] = {
    exp = 417394,
    jingyandan_exp = 367425,
    gaoji_jingyandan_exp = 3674250
  },
  [46] = {
    exp = 426213,
    jingyandan_exp = 375187,
    gaoji_jingyandan_exp = 3751875
  },
  [47] = {
    exp = 435031,
    jingyandan_exp = 382950,
    gaoji_jingyandan_exp = 3829500
  },
  [48] = {
    exp = 443849,
    jingyandan_exp = 390712,
    gaoji_jingyandan_exp = 3907125
  },
  [49] = {
    exp = 452667,
    jingyandan_exp = 398475,
    gaoji_jingyandan_exp = 3984750
  },
  [50] = {
    exp = 553782,
    jingyandan_exp = 406237,
    gaoji_jingyandan_exp = 4062375
  },
  [51] = {
    exp = 564364,
    jingyandan_exp = 414000,
    gaoji_jingyandan_exp = 4140000
  },
  [52] = {
    exp = 574946,
    jingyandan_exp = 421762,
    gaoji_jingyandan_exp = 4217625
  },
  [53] = {
    exp = 585528,
    jingyandan_exp = 429525,
    gaoji_jingyandan_exp = 4295250
  },
  [54] = {
    exp = 596110,
    jingyandan_exp = 437287,
    gaoji_jingyandan_exp = 4372875
  },
  [55] = {
    exp = 660097,
    jingyandan_exp = 445050,
    gaoji_jingyandan_exp = 4450500
  },
  [56] = {
    exp = 736816,
    jingyandan_exp = 452812,
    gaoji_jingyandan_exp = 4528125
  },
  [57] = {
    exp = 826824,
    jingyandan_exp = 460575,
    gaoji_jingyandan_exp = 4605750
  },
  [58] = {
    exp = 930679,
    jingyandan_exp = 468337,
    gaoji_jingyandan_exp = 4683375
  },
  [59] = {
    exp = 1048943,
    jingyandan_exp = 476100,
    gaoji_jingyandan_exp = 4761000
  },
  [60] = {
    exp = 1182172,
    jingyandan_exp = 483862,
    gaoji_jingyandan_exp = 4838625
  },
  [61] = {
    exp = 1330927,
    jingyandan_exp = 491625,
    gaoji_jingyandan_exp = 4916250
  },
  [62] = {
    exp = 1495765,
    jingyandan_exp = 499387,
    gaoji_jingyandan_exp = 4993875
  },
  [63] = {
    exp = 1677246,
    jingyandan_exp = 507150,
    gaoji_jingyandan_exp = 5071500
  },
  [64] = {
    exp = 1875928,
    jingyandan_exp = 514912,
    gaoji_jingyandan_exp = 5149125
  },
  [65] = {
    exp = 2092372,
    jingyandan_exp = 522675,
    gaoji_jingyandan_exp = 5226750
  },
  [66] = {
    exp = 2327135,
    jingyandan_exp = 530437,
    gaoji_jingyandan_exp = 5304375
  },
  [67] = {
    exp = 2580776,
    jingyandan_exp = 538200,
    gaoji_jingyandan_exp = 5382000
  },
  [68] = {
    exp = 2853855,
    jingyandan_exp = 545962,
    gaoji_jingyandan_exp = 5459625
  },
  [69] = {
    exp = 3146929,
    jingyandan_exp = 553725,
    gaoji_jingyandan_exp = 5537250
  },
  [70] = {
    exp = 5212400,
    jingyandan_exp = 561487,
    gaoji_jingyandan_exp = 5614875
  },
  [71] = {
    exp = 10066161,
    jingyandan_exp = 569250,
    gaoji_jingyandan_exp = 5692500
  },
  [72] = {
    exp = 15050332,
    jingyandan_exp = 577012,
    gaoji_jingyandan_exp = 5770125
  },
  [73] = {
    exp = 20164912,
    jingyandan_exp = 584775,
    gaoji_jingyandan_exp = 5847750
  },
  [74] = {
    exp = 25409904,
    jingyandan_exp = 592537,
    gaoji_jingyandan_exp = 5925375
  },
  [75] = {
    exp = 28601461,
    jingyandan_exp = 600300,
    gaoji_jingyandan_exp = 6003000
  },
  [76] = {
    exp = 31215058,
    jingyandan_exp = 608062,
    gaoji_jingyandan_exp = 6080625
  },
  [77] = {
    exp = 33885942,
    jingyandan_exp = 615825,
    gaoji_jingyandan_exp = 6158250
  },
  [78] = {
    exp = 36614114,
    jingyandan_exp = 623587,
    gaoji_jingyandan_exp = 6235875
  },
  [79] = {
    exp = 39399573,
    jingyandan_exp = 631350,
    gaoji_jingyandan_exp = 6313500
  },
  [80] = {
    exp = 42242319,
    jingyandan_exp = 639112,
    gaoji_jingyandan_exp = 6391125
  },
  [81] = {
    exp = 45142353,
    jingyandan_exp = 646875,
    gaoji_jingyandan_exp = 6468750
  },
  [82] = {
    exp = 48099673,
    jingyandan_exp = 654637,
    gaoji_jingyandan_exp = 6546375
  },
  [83] = {
    exp = 51114280,
    jingyandan_exp = 662400,
    gaoji_jingyandan_exp = 6624000
  },
  [84] = {
    exp = 54186176,
    jingyandan_exp = 670162,
    gaoji_jingyandan_exp = 6701625
  },
  [85] = {
    exp = 57315358,
    jingyandan_exp = 677925,
    gaoji_jingyandan_exp = 6779250
  },
  [86] = {
    exp = 60501828,
    jingyandan_exp = 685687,
    gaoji_jingyandan_exp = 6856875
  },
  [87] = {
    exp = 63745585,
    jingyandan_exp = 693450,
    gaoji_jingyandan_exp = 6934500
  },
  [88] = {
    exp = 67046629,
    jingyandan_exp = 701212,
    gaoji_jingyandan_exp = 7012125
  },
  [89] = {
    exp = 70404960,
    jingyandan_exp = 708975,
    gaoji_jingyandan_exp = 7089750
  },
  [90] = {
    exp = 75981181,
    jingyandan_exp = 716737,
    gaoji_jingyandan_exp = 7167375
  },
  [91] = {
    exp = 79555733,
    jingyandan_exp = 724500,
    gaoji_jingyandan_exp = 7245000
  },
  [92] = {
    exp = 83189249,
    jingyandan_exp = 732262,
    gaoji_jingyandan_exp = 7322625
  },
  [93] = {
    exp = 86881728,
    jingyandan_exp = 740025,
    gaoji_jingyandan_exp = 7400250
  },
  [94] = {
    exp = 90633172,
    jingyandan_exp = 747787,
    gaoji_jingyandan_exp = 7477875
  },
  [95] = {
    exp = 94443580,
    jingyandan_exp = 755550,
    gaoji_jingyandan_exp = 7555500
  },
  [96] = {
    exp = 98312952,
    jingyandan_exp = 763312,
    gaoji_jingyandan_exp = 7633125
  },
  [97] = {
    exp = 102241287,
    jingyandan_exp = 771075,
    gaoji_jingyandan_exp = 7710750
  },
  [98] = {
    exp = 106228587,
    jingyandan_exp = 778837,
    gaoji_jingyandan_exp = 7788375
  },
  [99] = {
    exp = 110274850,
    jingyandan_exp = 786600,
    gaoji_jingyandan_exp = 7866000
  },
  [100] = {
    exp = 119800934,
    jingyandan_exp = 794362,
    gaoji_jingyandan_exp = 7943625
  },
  [101] = {
    exp = 124162481,
    jingyandan_exp = 802125,
    gaoji_jingyandan_exp = 8021250
  },
  [102] = {
    exp = 128585786,
    jingyandan_exp = 809887,
    gaoji_jingyandan_exp = 8098875
  },
  [103] = {
    exp = 133070849,
    jingyandan_exp = 817650,
    gaoji_jingyandan_exp = 8176500
  },
  [104] = {
    exp = 137617671,
    jingyandan_exp = 825412,
    gaoji_jingyandan_exp = 8254125
  },
  [105] = {
    exp = 142226251,
    jingyandan_exp = 833175,
    gaoji_jingyandan_exp = 8331750
  },
  [106] = {
    exp = 146896590,
    jingyandan_exp = 840937,
    gaoji_jingyandan_exp = 8409375
  },
  [107] = {
    exp = 151628687,
    jingyandan_exp = 848700,
    gaoji_jingyandan_exp = 8487000
  },
  [108] = {
    exp = 156422542,
    jingyandan_exp = 856462,
    gaoji_jingyandan_exp = 8564625
  },
  [109] = {
    exp = 161278157,
    jingyandan_exp = 864225,
    gaoji_jingyandan_exp = 8642250
  },
  [110] = {
    exp = 171610044,
    jingyandan_exp = 871987,
    gaoji_jingyandan_exp = 8719875
  },
  [111] = {
    exp = 176751391,
    jingyandan_exp = 879750,
    gaoji_jingyandan_exp = 8797500
  },
  [112] = {
    exp = 181956508,
    jingyandan_exp = 887512,
    gaoji_jingyandan_exp = 8875125
  },
  [113] = {
    exp = 187225396,
    jingyandan_exp = 895275,
    gaoji_jingyandan_exp = 8952750
  },
  [114] = {
    exp = 192558055,
    jingyandan_exp = 903037,
    gaoji_jingyandan_exp = 9030375
  },
  [115] = {
    exp = 197954484,
    jingyandan_exp = 910800,
    gaoji_jingyandan_exp = 9108000
  },
  [116] = {
    exp = 203414683,
    jingyandan_exp = 918562,
    gaoji_jingyandan_exp = 9185625
  },
  [117] = {
    exp = 208938653,
    jingyandan_exp = 926325,
    gaoji_jingyandan_exp = 9263250
  },
  [118] = {
    exp = 214526393,
    jingyandan_exp = 934087,
    gaoji_jingyandan_exp = 9340875
  },
  [119] = {
    exp = 220177904,
    jingyandan_exp = 941850,
    gaoji_jingyandan_exp = 9418500
  },
  [120] = {
    exp = 225893185,
    jingyandan_exp = 949612,
    gaoji_jingyandan_exp = 9496125
  },
  [121] = {
    exp = 231672238,
    jingyandan_exp = 957375,
    gaoji_jingyandan_exp = 9573750
  },
  [122] = {
    exp = 237515060,
    jingyandan_exp = 965137,
    gaoji_jingyandan_exp = 9651375
  },
  [123] = {
    exp = 243421652,
    jingyandan_exp = 972900,
    gaoji_jingyandan_exp = 9729000
  },
  [124] = {
    exp = 249392016,
    jingyandan_exp = 980662,
    gaoji_jingyandan_exp = 9806625
  },
  [125] = {
    exp = 255426150,
    jingyandan_exp = 988425,
    gaoji_jingyandan_exp = 9884250
  },
  [126] = {
    exp = 261524054,
    jingyandan_exp = 996187,
    gaoji_jingyandan_exp = 9961875
  },
  [127] = {
    exp = 267685729,
    jingyandan_exp = 1003950,
    gaoji_jingyandan_exp = 10039500
  },
  [128] = {
    exp = 273911174,
    jingyandan_exp = 1011712,
    gaoji_jingyandan_exp = 10117125
  },
  [129] = {
    exp = 280200390,
    jingyandan_exp = 1019475,
    gaoji_jingyandan_exp = 10194750
  },
  [130] = {
    exp = 286553376,
    jingyandan_exp = 1027237,
    gaoji_jingyandan_exp = 10272375
  },
  [131] = {
    exp = 292970133,
    jingyandan_exp = 1035000,
    gaoji_jingyandan_exp = 10350000
  },
  [132] = {
    exp = 299450660,
    jingyandan_exp = 1042762,
    gaoji_jingyandan_exp = 10427625
  },
  [133] = {
    exp = 305994958,
    jingyandan_exp = 1050525,
    gaoji_jingyandan_exp = 10505250
  },
  [134] = {
    exp = 312603026,
    jingyandan_exp = 1058287,
    gaoji_jingyandan_exp = 10582875
  },
  [135] = {
    exp = 319274865,
    jingyandan_exp = 1066050,
    gaoji_jingyandan_exp = 10660500
  }
}
