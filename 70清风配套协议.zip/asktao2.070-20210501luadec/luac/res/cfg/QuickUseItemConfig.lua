return {
  [CHS[6400034]] = {
    dlgName = "QuickUseTwoDlg",
    needDoublePoint = 4,
    needChongfsPoint = 4
  },
  [CHS[6400035]] = {
    dlgName = "QuickUseTwoDlg",
    needDoublePoint = 4,
    needChongfsPoint = 4
  },
  [CHS[5400070]] = {
    dlgName = "QuickUseTwoDlg",
    needDoublePoint = 40,
    needChongfsPoint = 40
  },
  [CHS[4100323]] = {
    dlgName = "QuickUseOneDlg",
    needDoublePoint = 4
  },
  [CHS[4300001]] = {
    dlgName = "QuickUseOneDlg",
    needDoublePoint = 4
  }
}
