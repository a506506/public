return {
  [CHS[5410245]] = {
    {
      index = 101,
      name = CHS[3000171],
      level = 2,
      needItems = {
        {
          name = CHS[3000171],
          level = 1,
          num = 3
        }
      }
    },
    {
      index = 102,
      name = CHS[3000171],
      level = 3,
      needItems = {
        {
          name = CHS[3000171],
          level = 2,
          num = 3
        }
      }
    },
    {
      index = 103,
      name = CHS[3000171],
      level = 4,
      needItems = {
        {
          name = CHS[3000171],
          level = 3,
          num = 3
        }
      }
    },
    {
      index = 104,
      name = CHS[3000171],
      level = 5,
      needItems = {
        {
          name = CHS[3000171],
          level = 4,
          num = 3
        }
      }
    },
    {
      index = 105,
      name = CHS[3000171],
      level = 6,
      needItems = {
        {
          name = CHS[3000171],
          level = 5,
          num = 3
        }
      }
    },
    {
      index = 106,
      name = CHS[3000171],
      level = 7,
      needItems = {
        {
          name = CHS[3000171],
          level = 6,
          num = 3
        }
      }
    },
    {
      index = 107,
      name = CHS[3000171],
      level = 8,
      needItems = {
        {
          name = CHS[3000171],
          level = 7,
          num = 3
        }
      }
    },
    {
      index = 108,
      name = CHS[3000171],
      level = 9,
      needItems = {
        {
          name = CHS[3000171],
          level = 8,
          num = 3
        }
      }
    },
    {
      index = 109,
      name = CHS[3000171],
      level = 10,
      needItems = {
        {
          name = CHS[3000171],
          level = 9,
          num = 3
        }
      }
    },
    {
      index = 110,
      name = CHS[3000171],
      level = 11,
      needItems = {
        {
          name = CHS[3000171],
          level = 10,
          num = 3
        }
      }
    },
    {
      index = 111,
      name = CHS[3000171],
      level = 12,
      needItems = {
        {
          name = CHS[3000171],
          level = 11,
          num = 3
        }
      }
    },
    {
      index = 112,
      name = CHS[3000171],
      level = 13,
      needItems = {
        {
          name = CHS[3000171],
          level = 12,
          num = 3
        }
      }
    },
    {
      index = 121,
      name = CHS[3000172],
      level = 2,
      needItems = {
        {
          name = CHS[3000172],
          level = 1,
          num = 3
        }
      }
    },
    {
      index = 122,
      name = CHS[3000172],
      level = 3,
      needItems = {
        {
          name = CHS[3000172],
          level = 2,
          num = 3
        }
      }
    },
    {
      index = 123,
      name = CHS[3000172],
      level = 4,
      needItems = {
        {
          name = CHS[3000172],
          level = 3,
          num = 3
        }
      }
    },
    {
      index = 124,
      name = CHS[3000172],
      level = 5,
      needItems = {
        {
          name = CHS[3000172],
          level = 4,
          num = 3
        }
      }
    },
    {
      index = 125,
      name = CHS[3000172],
      level = 6,
      needItems = {
        {
          name = CHS[3000172],
          level = 5,
          num = 3
        }
      }
    },
    {
      index = 126,
      name = CHS[3000172],
      level = 7,
      needItems = {
        {
          name = CHS[3000172],
          level = 6,
          num = 3
        }
      }
    },
    {
      index = 127,
      name = CHS[3000172],
      level = 8,
      needItems = {
        {
          name = CHS[3000172],
          level = 7,
          num = 3
        }
      }
    },
    {
      index = 128,
      name = CHS[3000172],
      level = 9,
      needItems = {
        {
          name = CHS[3000172],
          level = 8,
          num = 3
        }
      }
    },
    {
      index = 129,
      name = CHS[3000172],
      level = 10,
      needItems = {
        {
          name = CHS[3000172],
          level = 9,
          num = 3
        }
      }
    },
    {
      index = 130,
      name = CHS[3000172],
      level = 11,
      needItems = {
        {
          name = CHS[3000172],
          level = 10,
          num = 3
        }
      }
    },
    {
      index = 131,
      name = CHS[3000172],
      level = 12,
      needItems = {
        {
          name = CHS[3000172],
          level = 11,
          num = 3
        }
      }
    },
    {
      index = 132,
      name = CHS[3000172],
      level = 13,
      needItems = {
        {
          name = CHS[3000172],
          level = 12,
          num = 3
        }
      }
    },
    {
      index = 141,
      name = CHS[3000173],
      level = 2,
      needItems = {
        {
          name = CHS[3000173],
          level = 1,
          num = 3
        }
      }
    },
    {
      index = 142,
      name = CHS[3000173],
      level = 3,
      needItems = {
        {
          name = CHS[3000173],
          level = 2,
          num = 3
        }
      }
    },
    {
      index = 143,
      name = CHS[3000173],
      level = 4,
      needItems = {
        {
          name = CHS[3000173],
          level = 3,
          num = 3
        }
      }
    },
    {
      index = 144,
      name = CHS[3000173],
      level = 5,
      needItems = {
        {
          name = CHS[3000173],
          level = 4,
          num = 3
        }
      }
    },
    {
      index = 145,
      name = CHS[3000173],
      level = 6,
      needItems = {
        {
          name = CHS[3000173],
          level = 5,
          num = 3
        }
      }
    },
    {
      index = 146,
      name = CHS[3000173],
      level = 7,
      needItems = {
        {
          name = CHS[3000173],
          level = 6,
          num = 3
        }
      }
    },
    {
      index = 147,
      name = CHS[3000173],
      level = 8,
      needItems = {
        {
          name = CHS[3000173],
          level = 7,
          num = 3
        }
      }
    },
    {
      index = 148,
      name = CHS[3000173],
      level = 9,
      needItems = {
        {
          name = CHS[3000173],
          level = 8,
          num = 3
        }
      }
    },
    {
      index = 149,
      name = CHS[3000173],
      level = 10,
      needItems = {
        {
          name = CHS[3000173],
          level = 9,
          num = 3
        }
      }
    },
    {
      index = 150,
      name = CHS[3000173],
      level = 11,
      needItems = {
        {
          name = CHS[3000173],
          level = 10,
          num = 3
        }
      }
    },
    {
      index = 151,
      name = CHS[3000173],
      level = 12,
      needItems = {
        {
          name = CHS[3000173],
          level = 11,
          num = 3
        }
      }
    },
    {
      index = 152,
      name = CHS[3000173],
      level = 13,
      needItems = {
        {
          name = CHS[3000173],
          level = 12,
          num = 3
        }
      }
    },
    {
      index = 161,
      name = CHS[3000174],
      level = 2,
      needItems = {
        {
          name = CHS[3000174],
          level = 1,
          num = 3
        }
      }
    },
    {
      index = 162,
      name = CHS[3000174],
      level = 3,
      needItems = {
        {
          name = CHS[3000174],
          level = 2,
          num = 3
        }
      }
    },
    {
      index = 163,
      name = CHS[3000174],
      level = 4,
      needItems = {
        {
          name = CHS[3000174],
          level = 3,
          num = 3
        }
      }
    },
    {
      index = 164,
      name = CHS[3000174],
      level = 5,
      needItems = {
        {
          name = CHS[3000174],
          level = 4,
          num = 3
        }
      }
    },
    {
      index = 165,
      name = CHS[3000174],
      level = 6,
      needItems = {
        {
          name = CHS[3000174],
          level = 5,
          num = 3
        }
      }
    },
    {
      index = 166,
      name = CHS[3000174],
      level = 7,
      needItems = {
        {
          name = CHS[3000174],
          level = 6,
          num = 3
        }
      }
    },
    {
      index = 167,
      name = CHS[3000174],
      level = 8,
      needItems = {
        {
          name = CHS[3000174],
          level = 7,
          num = 3
        }
      }
    },
    {
      index = 168,
      name = CHS[3000174],
      level = 9,
      needItems = {
        {
          name = CHS[3000174],
          level = 8,
          num = 3
        }
      }
    },
    {
      index = 169,
      name = CHS[3000174],
      level = 10,
      needItems = {
        {
          name = CHS[3000174],
          level = 9,
          num = 3
        }
      }
    },
    {
      index = 170,
      name = CHS[3000174],
      level = 11,
      needItems = {
        {
          name = CHS[3000174],
          level = 10,
          num = 3
        }
      }
    },
    {
      index = 171,
      name = CHS[3000174],
      level = 12,
      needItems = {
        {
          name = CHS[3000174],
          level = 11,
          num = 3
        }
      }
    },
    {
      index = 172,
      name = CHS[3000174],
      level = 13,
      needItems = {
        {
          name = CHS[3000174],
          level = 12,
          num = 3
        }
      }
    },
    {
      index = 181,
      name = CHS[3000175],
      level = 2,
      needItems = {
        {
          name = CHS[3000175],
          level = 1,
          num = 3
        }
      }
    },
    {
      index = 182,
      name = CHS[3000175],
      level = 3,
      needItems = {
        {
          name = CHS[3000175],
          level = 2,
          num = 3
        }
      }
    },
    {
      index = 183,
      name = CHS[3000175],
      level = 4,
      needItems = {
        {
          name = CHS[3000175],
          level = 3,
          num = 3
        }
      }
    },
    {
      index = 184,
      name = CHS[3000175],
      level = 5,
      needItems = {
        {
          name = CHS[3000175],
          level = 4,
          num = 3
        }
      }
    },
    {
      index = 185,
      name = CHS[3000175],
      level = 6,
      needItems = {
        {
          name = CHS[3000175],
          level = 5,
          num = 3
        }
      }
    },
    {
      index = 186,
      name = CHS[3000175],
      level = 7,
      needItems = {
        {
          name = CHS[3000175],
          level = 6,
          num = 3
        }
      }
    },
    {
      index = 187,
      name = CHS[3000175],
      level = 8,
      needItems = {
        {
          name = CHS[3000175],
          level = 7,
          num = 3
        }
      }
    },
    {
      index = 188,
      name = CHS[3000175],
      level = 9,
      needItems = {
        {
          name = CHS[3000175],
          level = 8,
          num = 3
        }
      }
    },
    {
      index = 189,
      name = CHS[3000175],
      level = 10,
      needItems = {
        {
          name = CHS[3000175],
          level = 9,
          num = 3
        }
      }
    },
    {
      index = 190,
      name = CHS[3000175],
      level = 11,
      needItems = {
        {
          name = CHS[3000175],
          level = 10,
          num = 3
        }
      }
    },
    {
      index = 191,
      name = CHS[3000175],
      level = 12,
      needItems = {
        {
          name = CHS[3000175],
          level = 11,
          num = 3
        }
      }
    },
    {
      index = 192,
      name = CHS[3000175],
      level = 13,
      needItems = {
        {
          name = CHS[3000175],
          level = 12,
          num = 3
        }
      }
    },
    {
      index = 201,
      name = CHS[3004454],
      level = 2,
      needItems = {
        {
          name = CHS[3004454],
          level = 1,
          num = 3
        }
      }
    },
    {
      index = 202,
      name = CHS[3004454],
      level = 3,
      needItems = {
        {
          name = CHS[3004454],
          level = 2,
          num = 3
        }
      }
    },
    {
      index = 203,
      name = CHS[3004454],
      level = 4,
      needItems = {
        {
          name = CHS[3004454],
          level = 3,
          num = 3
        }
      }
    },
    {
      index = 204,
      name = CHS[3004454],
      level = 5,
      needItems = {
        {
          name = CHS[3004454],
          level = 4,
          num = 3
        }
      }
    },
    {
      index = 205,
      name = CHS[3004454],
      level = 6,
      needItems = {
        {
          name = CHS[3004454],
          level = 5,
          num = 3
        }
      }
    },
    {
      index = 206,
      name = CHS[3004454],
      level = 7,
      needItems = {
        {
          name = CHS[3004454],
          level = 6,
          num = 3
        }
      }
    },
    {
      index = 207,
      name = CHS[3004454],
      level = 8,
      needItems = {
        {
          name = CHS[3004454],
          level = 7,
          num = 3
        }
      }
    },
    {
      index = 208,
      name = CHS[3004454],
      level = 9,
      needItems = {
        {
          name = CHS[3004454],
          level = 8,
          num = 3
        }
      }
    },
    {
      index = 209,
      name = CHS[3004454],
      level = 10,
      needItems = {
        {
          name = CHS[3004454],
          level = 9,
          num = 3
        }
      }
    },
    {
      index = 210,
      name = CHS[3004454],
      level = 11,
      needItems = {
        {
          name = CHS[3004454],
          level = 10,
          num = 3
        }
      }
    },
    {
      index = 211,
      name = CHS[3004454],
      level = 12,
      needItems = {
        {
          name = CHS[3004454],
          level = 11,
          num = 3
        }
      }
    },
    {
      index = 212,
      name = CHS[3004454],
      level = 13,
      needItems = {
        {
          name = CHS[3004454],
          level = 12,
          num = 3
        }
      }
    }
  },
  ["娃娃玩具"] = {
    {
      index = 2001,
      showName = "竹马",
      name = "竹马（紫色）",
      level = "紫色",
      needItems = {
        {
          name = "竹马（蓝色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2007,
      showName = "竹马",
      name = "竹马（金色）",
      level = "金色",
      needItems = {
        {
          name = "竹马（紫色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2003,
      showName = "蹴球",
      name = "蹴球（紫色）",
      level = "紫色",
      needItems = {
        {
          name = "蹴球（蓝色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2009,
      showName = "蹴球",
      name = "蹴球（金色）",
      level = "金色",
      needItems = {
        {
          name = "蹴球（紫色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2002,
      showName = "毽子",
      name = "毽子（紫色）",
      level = "紫色",
      needItems = {
        {
          name = "毽子（蓝色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2008,
      showName = "毽子",
      name = "毽子（金色）",
      level = "金色",
      needItems = {
        {
          name = "毽子（紫色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2004,
      showName = "弹弓",
      name = "弹弓（紫色）",
      level = "紫色",
      needItems = {
        {
          name = "弹弓（蓝色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2010,
      showName = "弹弓",
      name = "弹弓（金色）",
      level = "金色",
      needItems = {
        {
          name = "弹弓（紫色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2005,
      showName = "陀螺",
      name = "陀螺（紫色）",
      level = "紫色",
      needItems = {
        {
          name = "陀螺（蓝色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2011,
      showName = "陀螺",
      name = "陀螺（金色）",
      level = "金色",
      needItems = {
        {
          name = "陀螺（紫色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2006,
      showName = "风筝",
      name = "风筝（紫色）",
      level = "紫色",
      needItems = {
        {
          name = "风筝（蓝色）",
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 2012,
      showName = "风筝",
      name = "风筝（金色）",
      level = "金色",
      needItems = {
        {
          name = "风筝（紫色）",
          level = 0,
          num = 3
        }
      }
    }
  },
  [CHS[5410246]] = {
    {
      index = 301,
      name = CHS[4100422],
      level = 0,
      needItems = {
        {
          name = CHS[4100421],
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 302,
      name = CHS[4100423],
      level = 0,
      needItems = {
        {
          name = CHS[4100422],
          level = 0,
          num = 3
        }
      }
    },
    {
      index = 303,
      name = CHS[4100424],
      level = 0,
      needItems = {
        {
          name = CHS[4100423],
          level = 0,
          num = 3
        }
      }
    }
  },
  [CHS[5410247]] = {
    {
      index = 1001,
      name = CHS[5410239],
      level = 0,
      bind = true,
      needItems = {
        {
          name = CHS[3001144],
          level = 0,
          num = -1,
          max_value = 100,
          names = {
            CHS[3001144],
            CHS[5410239]
          }
        }
      }
    },
    {
      index = 1002,
      name = CHS[5410240],
      level = 0,
      bind = true,
      needItems = {
        {
          name = CHS[7000081],
          level = 0,
          num = -1,
          max_value = 50,
          names = {
            CHS[7000081],
            CHS[5410240]
          }
        }
      }
    },
    {
      index = 1003,
      name = CHS[5410241],
      level = 0,
      bind = true,
      needItems = {
        {
          name = CHS[3001136],
          level = 0,
          num = -1,
          max_value = 40000000,
          names = {
            CHS[3001136],
            CHS[5410241]
          }
        }
      }
    },
    {
      index = 1004,
      name = CHS[5410242],
      level = 0,
      bind = true,
      needItems = {
        {
          name = CHS[3001139],
          level = 0,
          num = -1,
          max_value = 40000000,
          names = {
            CHS[3001139],
            CHS[5410242]
          }
        }
      }
    },
    {
      index = 1005,
      name = CHS[5410243],
      level = 0,
      bind = true,
      needItems = {
        {
          name = CHS[3001140],
          level = 0,
          num = -1,
          max_value = 100000000,
          names = {
            CHS[3001140],
            CHS[5410243]
          }
        }
      }
    },
    {
      index = 1006,
      name = CHS[5410244],
      level = 0,
      bind = true,
      needItems = {
        {
          name = CHS[3001141],
          level = 0,
          num = -1,
          max_value = 100000000,
          names = {
            CHS[3001141],
            CHS[5410244]
          }
        }
      }
    },
    {
      index = 1007,
      name = CHS[4300795],
      level = 0,
      bind = true,
      needItems = {
        {
          name = CHS[4200378],
          level = 0,
          num = -1,
          max_value = 100,
          names = {
            CHS[4200378],
            CHS[4300795]
          }
        }
      }
    }
  },
  [CHS[2100293]] = {
    {
      index = 401,
      name = CHS[2100294],
      level = 0,
      bind = true,
      needItems = {
        {
          name = CHS[2100296],
          level = 0,
          num = 5
        }
      }
    }
  }
}
