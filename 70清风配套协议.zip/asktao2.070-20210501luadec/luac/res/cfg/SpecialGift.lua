return {
  ["VIP888"] = true,
  ["四周年快乐"] = true,
  ["4周年快乐"] = true,
  ["tianyu"] = true,
  ["LT666"] = true,
  ["牛牛牛"] = true,
  ["春节快乐"] = true,
  ["林更新"] = true
}
