return {
  {
    name = CHS[3000713],
    level = 30,
    times = 3,
    weekCanRewardDays = 3,
    activeValue = 3.34,
    activeLimit = 10,
    actitiveDate = "2,4,6",
    activityTime = {
      {
        CHS[5410231],
        "npc",
        CHS[3000715]
      }
    },
    team = CHS[3000698],
    desc = CHS[3000716] .. CHS[3000717],
    reward = CHS[3000718],
    icon = "Icon0072.png",
    pushContent = CHS[3000719],
    pushTime = {"20:30"}
  },
  {
    name = CHS[3000693],
    level = 40,
    times = 5,
    activeValue = 2,
    activeLimit = 10,
    actitiveDate = "0",
    activityTime = {
      {
        CHS[3000694],
        "npc",
        CHS[3000695]
      },
      {
        CHS[3000696],
        "npc",
        CHS[3000697]
      }
    },
    team = CHS[3000698],
    desc = CHS[3000699],
    reward = CHS[3000700],
    icon = "BigRewardIcon0007.png",
    pushContent = CHS[3000701],
    pushTime = {
      CHS[3000702],
      CHS[3000703]
    }
  },
  {
    name = CHS[5450336],
    short_name = CHS[7120050],
    level = 60,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "1",
    activityTime = {
      {
        CHS[6400002],
        "",
        ""
      }
    },
    team = CHS[3000698],
    desc = CHS[5450337],
    reward = CHS[5450338],
    pushContent = CHS[5450334],
    pushTime = {"20:30"},
    itemName = CHS[3000176]
  },
  {
    name = CHS[5450332],
    level = 60,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "1",
    activityTime = {
      {
        CHS[6400002],
        "",
        ""
      }
    },
    team = CHS[3000698],
    desc = CHS[5450333],
    reward = CHS[6400004],
    pushContent = CHS[5450334],
    pushTime = {"20:30"},
    itemName = CHS[3000176]
  },
  {
    name = CHS[3000734],
    level = 30,
    times = 1,
    activeValue = 10,
    activeLimit = 10,
    actitiveDate = "9",
    activityTime = {
      {
        CHS[3000735],
        "npc",
        CHS[3000736]
      }
    },
    team = CHS[3000730],
    desc = CHS[3000737],
    reward = CHS[3000738],
    icon = "BigRewardIcon0008.png"
  },
  {
    name = CHS[3000739],
    short_name = CHS[7002167],
    level = 45,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "0",
    activityTime = {
      {
        CHS[3000740],
        "dlg",
        "GetTaoDlg"
      }
    },
    team = CHS[3000698],
    desc = CHS[3000741],
    reward = CHS[3000742],
    icon = "BigRewardIcon0006.png",
    pushContent = CHS[3000743],
    pushTime = {"18:20"}
  },
  {
    mainType = "luobo_taozi_dashouji",
    name = CHS[5400047],
    short_name = CHS[7002170],
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    dateFromServer = true,
    actitiveDate = "",
    activityTime = {
      {
        "21:30-22:00",
        "npc",
        CHS[5400049]
      }
    },
    team = CHS[3000730],
    desc = CHS[5400045],
    reward = CHS[5400046],
    icon = "BigRewardIcon0052.png"
  },
  {
    mainType = "huazhuang_wuhui",
    name = CHS[7002107],
    short_name = CHS[2200037],
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    dateFromServer = true,
    actitiveDate = "",
    activityTime = {
      {
        "21:20-22:00",
        "",
        ""
      }
    },
    team = CHS[3000730],
    desc = CHS[7002108],
    reward = CHS[7002109],
    icon = "BigRewardIcon0052.png",
    pushTime = {}
  },
  {
    mainType = "baishouzhiwang",
    name = CHS[7002122],
    short_name = CHS[2200036],
    dugeonTaskName = CHS[7002130],
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    dateFromServer = true,
    actitiveDate = "",
    activityTime = {
      {
        "21:20-22:00",
        "",
        ""
      }
    },
    team = CHS[3000698],
    desc = CHS[7002125],
    reward = CHS[7002126],
    icon = "BigRewardIcon0052.png",
    pushTime = {}
  },
  {
    mainType = "yongchuang_wanyaoku",
    name = CHS[2100059],
    short_name = CHS[2200035],
    dugeonTaskName = CHS[2100043],
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    dateFromServer = true,
    actitiveDate = "",
    activityTime = {
      {
        "21:20-22:00",
        "",
        ""
      }
    },
    team = CHS[3000730],
    desc = CHS[2200026],
    reward = CHS[7002126],
    icon = "BigRewardIcon0052.png",
    pushTime = {}
  },
  {
    mainType = "yizu_ruqin",
    name = CHS[2200027],
    short_name = CHS[2200034],
    dugeonTaskName = CHS[7150070],
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    dateFromServer = true,
    actitiveDate = "",
    activityTime = {
      {
        "21:20-22:00",
        "",
        ""
      }
    },
    team = CHS[2200028],
    desc = CHS[2200029],
    reward = CHS[2200030],
    icon = "BigRewardIcon0052.png",
    pushTime = {}
  },
  {
    mainType = "kuangshidazhan",
    name = CHS[2200031],
    short_name = CHS[2200033],
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    dateFromServer = true,
    actitiveDate = "",
    activityTime = {
      {
        "21:20-21:50",
        "",
        ""
      }
    },
    team = CHS[5000245],
    desc = CHS[7002231],
    reward = CHS[7002232],
    icon = "BigRewardIcon0052.png",
    pushTime = {}
  },
  {
    mainType = "xianchi_wenquan",
    name = CHS[5450454],
    short_name = CHS[5450457],
    level = 30,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    dateFromServer = true,
    actitiveDate = "",
    activityTime = {
      {
        "21:30-21:50",
        "func",
        ""
      }
    },
    team = CHS[5000245],
    desc = CHS[5450455],
    reward = CHS[5450456],
    icon = "BigRewardIcon0052.png",
    pushTime = {}
  },
  {
    mainType = "cs_league_100",
    name = CHS[4100704],
    short_name = CHS[4100704],
    level = 100,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "12",
    activityTime = {
      {
        "每天 21:00-23:00",
        "",
        ""
      }
    },
    team = CHS[3000730],
    desc = CHS[4300279],
    reward = CHS[4300280],
    icon = "BigRewardIcon0052.png",
    pushTime = {}
  },
  {
    mainType = "celebrity_guess",
    name = CHS[4200511],
    short_name = CHS[4200511],
    level = 1,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "12",
    activityTime = {
      {
        CHS[4200512],
        "cmd",
        "CMD_CG_REQUEST_INFO"
      }
    },
    team = CHS[5000245],
    desc = CHS[4200513],
    reward = CHS[4200514],
    icon = "BigRewardIcon0022.png",
    pushTime = {},
    showLevel = 30,
    notShowLeftTime = true
  },
  {
    mainType = "cs_mon_league",
    name = CHS[4010310],
    short_name = CHS[4010310],
    level = 100,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "12",
    activityTime = {
      {
        CHS[4010387],
        "",
        ""
      }
    },
    team = CHS[3000730],
    desc = CHS[4010312],
    reward = CHS[4010313],
    icon = "BigRewardIcon0052.png",
    pushTime = {}
  },
  {
    mainType = "shengxiao_dataowang",
    name = CHS[4101295],
    short_name = CHS[4101295],
    level = 70,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "12",
    activityTime = {
      {
        CHS[4200512],
        "npc",
        CHS[4101296]
      }
    },
    team = CHS[5000245],
    desc = CHS[4101297],
    reward = CHS[4101298],
    icon = "BigRewardIcon0052.png",
    pushTime = {},
    showLevel = 70
  },
  {
    mainType = "shouhu_nantianmen",
    name = CHS[4101299],
    short_name = CHS[4101299],
    level = 70,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "12",
    activityTime = {
      {
        CHS[4200512],
        "npc",
        ""
      }
    },
    team = CHS[5000250],
    desc = CHS[4101300],
    reward = CHS[4101301],
    icon = "BigRewardIcon0052.png",
    pushTime = {},
    showLevel = 70
  },
  {
    mainType = "good_voice",
    name = CHS[4200659],
    short_name = CHS[4200659],
    level = 70,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "12",
    activityTime = {
      {
        "",
        "npc",
        CHS[4200660]
      }
    },
    team = CHS[5000245],
    desc = CHS[4200661],
    reward = CHS[4200662],
    icon = "BigRewardIcon0022.png",
    pushTime = {},
    notShowLeftTime = true
  },
  {
    mainType = "biwu_dahui",
    name = CHS[4200808],
    short_name = CHS[4200808],
    level = 35,
    times = -1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "1",
    activityTime = {
      {
        CHS[4200809],
        "",
        ""
      }
    },
    team = CHS[6400026],
    desc = CHS[4200810],
    reward = CHS[4200811],
    icon = "BigRewardIcon0052.png",
    pushTime = {"20:25"},
    showLevel = 35,
    pushContent = CHS[4200917]
  },
  {
    mainType = "chaos_battle",
    name = CHS[7100750],
    short_name = CHS[3004465],
    level = 75,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    showByServer = true,
    actitiveDate = "0",
    activityTime = {
      {
        CHS[8000025],
        "npc",
        CHS[8000026]
      }
    },
    team = CHS[5000245],
    desc = CHS[7100753],
    reward = CHS[7100786],
    icon = "BigRewardIcon0022.png",
    pushTime = {"20:50"},
    pushContent = CHS[4200918]
  },
  {
    name = CHS[4101740],
    mainType = "ghostdom_contest",
    short_name = CHS[4101751],
    level = 75,
    times = 1,
    activeValue = 0,
    activeLimit = 0,
    actitiveDate = "13:7",
    activityTime = {
      {
        CHS[4101741],
        "",
        ""
      }
    },
    needLevelTip = true,
    team = CHS[5000250],
    desc = CHS[4101743],
    reward = CHS[4101744],
    icon = "BigRewardIcon0022.png",
    pushTime = {"20:20"},
    pushContent = CHS[4200919]
  }
}
