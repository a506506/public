return {
  MENU_ICON = {
    ["成就总览-"] = "ui/Icon0007.png",
    ["人物成长-等级"] = "ui/Icon1347.png",
    ["人物成长-技能"] = "ui/Icon1348.png",
    ["人物成长-道行"] = "ui/Icon1349.png",
    ["人物成长-战斗"] = "ui/Icon1350.png",
    ["人物成长-金钱"] = "ui/Icon1351.png",
    ["人物成长-附灵"] = "ui/Icon1351.png",
    ["伙伴培养-宠物养成"] = "ui/Icon1352.png",
    ["伙伴培养-守护养成"] = "ui/Icon1353.png",
    ["装备打造-装备"] = "ui/Icon1354.png",
    ["装备打造-首饰"] = "ui/Icon1355.png",
    ["装备打造-法宝"] = "ui/Icon1356.png",
    ["装备打造-魂器"] = "ui/Icon2802.png",
    ["装备打造-洛书"] = "ui/Icon1362.png",
    ["人物社交-好友"] = "ui/Icon1357.png",
    ["人物社交-帮派"] = "ui/Icon1358.png",
    ["人物社交-人物关系"] = "ui/Icon1359.png",
    ["人物社交-个人空间"] = "ui/Icon1383.png",
    ["任务活动-剧情任务"] = "ui/Icon1360.png",
    ["任务活动-日常活动"] = "ui/Icon1361.png",
    ["任务活动-其他活动"] = "ui/Icon1362.png",
    ["中洲轶事-趣闻"] = "ui/Icon1363.png",
    ["中洲轶事-光辉岁月"] = "ui/Icon1364.png"
  },
  INFO = {
    ["人物成长-等级"] = {
      ["无名小卒"] = {
        achieve_desc = "人物等级达到20级",
        order = 10
      },
      ["初入道门"] = {
        achieve_desc = "人物等级达到30级",
        order = 20
      },
      ["小小道童"] = {
        achieve_desc = "人物等级达到40级",
        order = 30
      },
      ["略有顿悟"] = {
        achieve_desc = "人物等级达到50级",
        order = 40
      },
      ["修为精进"] = {
        achieve_desc = "人物等级达到60级",
        order = 50
      },
      ["了然如胸"] = {
        achieve_desc = "人物等级达到70级",
        order = 60
      },
      ["小有所成"] = {
        achieve_desc = "人物等级达到80级",
        order = 70
      },
      ["心领神会"] = {
        achieve_desc = "人物等级达到90级",
        order = 80
      },
      ["顿悟道心"] = {
        achieve_desc = "人物等级达到100级",
        order = 90
      },
      ["神乎其技"] = {
        achieve_desc = "人物等级达到110级",
        order = 100
      },
      ["出神入化"] = {
        achieve_desc = "人物等级达到120级",
        order = 110
      },
      ["超凡入圣"] = {
        achieve_desc = "人物等级达到130级",
        order = 111
      },
      ["神婴初成"] = {
        achieve_desc = "元婴（血婴）等级达到10级",
        order = 120
      },
      ["固本培元"] = {
        achieve_desc = "元婴（血婴）等级达到20级",
        order = 130
      },
      ["婴体凝实"] = {
        achieve_desc = "元婴（血婴）等级达到30级",
        order = 140
      },
      ["婴随心动"] = {
        achieve_desc = "元婴（血婴）等级达到40级",
        order = 150
      },
      ["意至婴出"] = {
        achieve_desc = "元婴（血婴）等级达到50级",
        order = 160
      },
      ["驾轻就熟"] = {
        achieve_desc = "元婴（血婴）等级达到60级",
        order = 170
      },
      ["神婴小成"] = {
        achieve_desc = "元婴（血婴）等级达到70级",
        order = 180
      },
      ["妙领婴机"] = {
        achieve_desc = "元婴（血婴）等级达到80级",
        order = 190
      },
      ["融会贯通"] = {
        achieve_desc = "元婴（血婴）等级达到90级",
        order = 200
      },
      ["神婴出窍"] = {
        achieve_desc = "元婴（血婴）等级达到100级",
        order = 210
      },
      ["神婴合体"] = {
        achieve_desc = "元婴（血婴）等级达到110级",
        order = 220
      },
      ["无我无婴"] = {
        achieve_desc = "元婴（血婴）等级达到120级",
        order = 230
      },
      ["神婴大成"] = {
        achieve_desc = "元婴（血婴）等级达到130级",
        order = 240
      },
      ["脱胎换骨"] = {
        achieve_desc = "元婴（血婴）等级达到140级",
        order = 250
      },
      ["神婴炼虚"] = {
        achieve_desc = "元婴（血婴）等级达到150级",
        order = 260
      },
      ["大罗神婴"] = {
        achieve_desc = "元婴（血婴）等级达到160级",
        order = 270
      },
      ["炉火纯青"] = {
        achieve_desc = "元婴（血婴）等级达到170级",
        order = 280
      }
    },
    ["人物成长-技能"] = {
      ["炼体入门"] = {
        achieve_desc = "神体术修炼至50级",
        order = 10
      },
      ["身强体壮"] = {
        achieve_desc = "神体术修炼至100级",
        order = 20
      },
      ["刀枪不入"] = {
        achieve_desc = "神体术修炼至150级",
        order = 30
      },
      ["金刚不坏"] = {
        achieve_desc = "神体术修炼至200级",
        order = 40
      },
      ["修道入门"] = {
        achieve_desc = "修道术修炼至50级",
        order = 50
      },
      ["炼气化神"] = {
        achieve_desc = "修道术修炼至100级",
        order = 60
      },
      ["化神为虚"] = {
        achieve_desc = "修道术修炼至150级",
        order = 70
      },
      ["化虚为无"] = {
        achieve_desc = "修道术修炼至200级",
        order = 80
      },
      ["初学道法"] = {
        achieve_desc = "任意本系技能等级修炼至50级",
        order = 90
      },
      ["略知皮毛"] = {
        achieve_desc = "任意本系技能等级修炼至100级",
        order = 100
      },
      ["得心应手"] = {
        achieve_desc = "任意本系技能等级修炼至150级",
        order = 110
      },
      ["心到技至"] = {
        achieve_desc = "任意本系技能等级修炼至200级",
        order = 120
      },
      ["初窥变化"] = {
        achieve_desc = "所有本系法攻、障碍和辅助技能等级修炼至50级",
        order = 130
      },
      ["略知一二"] = {
        achieve_desc = "所有本系法攻、障碍和辅助技能等级修炼至100级",
        order = 140
      },
      ["游刃有余"] = {
        achieve_desc = "所有本系法攻、障碍和辅助技能等级修炼至150级",
        order = 150
      },
      ["呼风唤雨"] = {
        achieve_desc = "所有本系法攻、障碍和辅助技能等级修炼至200级",
        order = 160
      },
      ["力破十钧"] = {
        achieve_desc = "力破千钧技能等级修炼至50级",
        order = 170
      },
      ["力破百钧"] = {
        achieve_desc = "力破千钧技能等级修炼至100级",
        order = 180
      },
      ["力破千钧"] = {
        achieve_desc = "力破千钧技能等级修炼至150级",
        order = 190
      },
      ["力破万钧"] = {
        achieve_desc = "力破千钧技能等级修炼至200级",
        order = 200
      },
      ["后发制人"] = {
        achieve_desc = "获得仙技能后发制人",
        order = 210
      },
      ["釜底抽薪"] = {
        achieve_desc = "获得魔技能釜底抽薪",
        order = 220
      }
    },
    ["人物成长-道行"] = {
      ["标准道行"] = {
        achieve_desc = "达到当前等级标准道行",
        order = 10
      },
      ["二倍标道"] = {
        achieve_desc = "达到当前等级2倍标准道行",
        order = 20
      },
      ["三倍标道"] = {
        achieve_desc = "达到当前等级3倍标准道行",
        order = 30
      },
      ["四倍标道"] = {
        achieve_desc = "达到当前等级4倍标准道行",
        order = 40
      },
      ["五倍标道"] = {
        achieve_desc = "达到当前等级5倍标准道行",
        order = 50
      },
      ["六倍标道"] = {
        achieve_desc = "达到当前等级6倍标准道行",
        order = 60
      },
      ["七倍标道"] = {
        achieve_desc = "达到当前等级7倍标准道行",
        order = 70
      },
      ["八倍标道"] = {
        achieve_desc = "达到当前等级8倍标准道行",
        order = 80
      },
      ["九倍标道"] = {
        achieve_desc = "达到当前等级9倍标准道行",
        order = 90
      },
      ["十倍标道"] = {
        achieve_desc = "达到当前等级10倍标准道行",
        order = 100
      },
      ["十一倍标道"] = {
        achieve_desc = "达到当前等级11倍标准道行",
        order = 110
      },
      ["十二倍标道"] = {
        achieve_desc = "达到当前等级12倍标准道行",
        order = 120
      },
      ["十三倍标道"] = {
        achieve_desc = "达到当前等级13倍标准道行",
        order = 130
      },
      ["十四倍标道"] = {
        achieve_desc = "达到当前等级14倍标准道行",
        order = 140
      },
      ["十五倍标道"] = {
        achieve_desc = "达到当前等级15倍标准道行",
        order = 150
      },
      ["凡间千年"] = {
        achieve_desc = "道行达到1000年",
        order = 160
      },
      ["修行五千载"] = {
        achieve_desc = "道行达到5000年",
        order = 170
      },
      ["万年修为"] = {
        achieve_desc = "道行达到10000年",
        order = 180
      },
      ["纵游世间两万年"] = {
        achieve_desc = "道行达到20000年",
        order = 190
      },
      ["三万道行入仙途"] = {
        achieve_desc = "道行达到30000年",
        order = 200
      },
      ["四万年始闻大道"] = {
        achieve_desc = "道行达到40000年",
        order = 200
      },
      ["五万年人道相通"] = {
        achieve_desc = "道行达到50000年",
        order = 200
      },
      ["六万年天道自然"] = {
        achieve_desc = "道行达到60000年",
        order = 200
      },
      ["七万年通达道源"] = {
        achieve_desc = "道行达到70000年",
        order = 200
      },
      ["八万年炼虚合道"] = {
        achieve_desc = "道行达到80000年",
        order = 200
      },
      ["九万年悟道成圣"] = {
        achieve_desc = "道行达到90000年",
        order = 200
      },
      ["十万年神道不灭"] = {
        achieve_desc = "道行达到100000年",
        order = 200
      }
    },
    ["人物成长-战斗"] = {
      ["我...我竟然？！"] = {
        achieve_desc = "第1次受到死亡惩罚",
        order = 10
      },
      ["死着死着就习惯了"] = {
        achieve_desc = "受到死亡惩罚次数达到%d次",
        order = 20
      },
      ["糟糕，有点上瘾了..."] = {
        achieve_desc = "受到死亡惩罚次数达到%d次",
        order = 30
      },
      ["停手，别打了！"] = {
        achieve_desc = "战斗获得胜利，但人物受到死亡惩罚",
        order = 40
      },
      ["战斗也是为了历练"] = {
        achieve_desc = "累计进行%d场除切磋以外的战斗",
        order = 50
      },
      ["来啊！继续啊！"] = {
        achieve_desc = "累计进行%d场除切磋以外的战斗",
        order = 60
      },
      ["连战连胜"] = {
        achieve_desc = "累计获得%d次除切磋以外的战斗胜利",
        order = 70
      },
      ["失败乃成功之母"] = {
        achieve_desc = "累计在除切磋以外的战斗中失败%d次",
        order = 80
      },
      ["你们顶住，我先撤！"] = {
        achieve_desc = "累计%d次5人组队进行除切磋以外的战斗第一个逃跑成功",
        order = 90
      },
      ["36计走为上"] = {
        achieve_desc = "累计在除切磋以外的战斗中逃跑%d次",
        order = 100
      },
      ["我怂..."] = {
        achieve_desc = "累计在除切磋以外的战斗中逃跑%d次",
        order = 110
      },
      ["除邪义士"] = {
        achieve_desc = "累计击败怪物%d只",
        order = 120
      },
      ["征战四方"] = {
        achieve_desc = "累计击败怪物%d只",
        order = 130
      },
      ["朋友，听说过无双吗？"] = {
        achieve_desc = "累计击败怪物%d只",
        order = 140
      },
      ["还有谁！"] = {
        achieve_desc = "累计击败怪物%d只",
        order = 150
      },
      ["要补，要补哇"] = {
        achieve_desc = "战斗中累计使用药品%d次",
        order = 160
      },
      ["队友也要打"] = {
        achieve_desc = "战斗中角色对友方进行攻击",
        order = 170
      },
      ["打敌人哪有打队友好玩"] = {
        achieve_desc = "战斗中角色对友方进行攻击累计达到%d次",
        order = 180
      },
      ["极致的战斗都是11打9"] = {
        achieve_desc = "战斗中角色对友方进行攻击累计达到%d次",
        order = 190
      },
      ["我挡！"] = {
        achieve_desc = "角色成功使用防御指令抵挡敌方攻击",
        order = 200
      },
      ["我再挡！"] = {
        achieve_desc = "角色成功使用防御指令抵挡敌方攻击%d次",
        order = 210
      },
      ["我再再挡！"] = {
        achieve_desc = "角色成功使用防御指令抵挡敌方攻击%d次",
        order = 220
      },
      ["宝宝快过来"] = {
        achieve_desc = "在野外成功捕捉%d只宝宝",
        order = 230
      },
      ["你是我的了！"] = {
        achieve_desc = "在野外成功捕捉%d只宝宝",
        order = 240
      },
      ["捉宝宝大师"] = {
        achieve_desc = "在野外成功捕捉%d只宝宝",
        order = 250
      },
      ["妖怪幼儿园"] = {
        achieve_desc = "在野外成功捕捉%d只宝宝",
        order = 260
      },
      ["你敢打我？"] = {
        achieve_desc = "通过反震将敌方击杀",
        order = 270
      },
      ["我只是站着你们就死光了"] = {
        achieve_desc = "通过反震击杀%d名敌人",
        order = 280
      },
      ["刺猬"] = {
        achieve_desc = "通过反震击杀%d名敌人",
        order = 290
      },
      ["反击"] = {
        achieve_desc = "通过反击将敌方击杀",
        order = 300
      },
      ["反击，再反击！"] = {
        achieve_desc = "通过反击击杀%d名敌人",
        order = 310
      },
      ["阿哒！"] = {
        achieve_desc = "通过反击击杀%d名敌人",
        order = 320
      },
      ["同门协作"] = {
        achieve_desc = "进入除切磋以外的战斗时我方5名队员相性皆相同",
        order = 330
      },
      ["门派内斗"] = {
        achieve_desc = "进入除切磋以外的战斗时敌我双方10名玩家相性皆相同",
        order = 340
      },
      ["各派协作"] = {
        achieve_desc = "进入除切磋以外的战斗时我方5名队员相性皆不相同",
        order = 350
      },
      ["最佳队友"] = {
        achieve_desc = "累计释放%d次辅助技能",
        order = 360
      },
      ["冲锋陷阵"] = {
        achieve_desc = "累计释放%d次力破千钧",
        order = 370
      },
      ["后方火力"] = {
        achieve_desc = "累计释放%d次法攻技能",
        order = 380
      },
      ["灵巧控制"] = {
        achieve_desc = "累计释放%d次障碍技能",
        order = 390
      },
      ["旋转跳跃，我闭着眼"] = {
        achieve_desc = "累计闪避攻击%d次",
        order = 400
      },
      ["内鬼"] = {
        achieve_desc = "战斗击杀队友%d次",
        order = 410
      },
      ["宠物杀手"] = {
        achieve_desc = "击杀自己的宠物%d次",
        order = 420
      },
      ["看我好欺负？！"] = {
        achieve_desc = "通过后发制人将敌方击杀",
        order = 430
      },
      ["还敢欺负我？！"] = {
        achieve_desc = "累计通过后发制人击杀%d名敌人",
        order = 440
      },
      ["来，随便打！"] = {
        achieve_desc = "累计通过后发制人击杀%d名敌人",
        order = 450
      },
      ["没蓝了吧？"] = {
        achieve_desc = "通过釜底抽薪将敌方法力消耗完",
        order = 460
      },
      ["都没蓝了吧？"] = {
        achieve_desc = "通过釜底抽薪将%d名敌人法力消耗完",
        order = 470
      },
      ["法玲珑快用完了吧？"] = {
        achieve_desc = "通过釜底抽薪将%d名敌人法力消耗完",
        order = 480
      },
      ["反杀！"] = {
        achieve_desc = "在他人发起的PK战斗中获得胜利",
        order = 490
      },
      ["杀气腾腾"] = {
        achieve_desc = "主动发起PK战斗并获得胜利",
        order = 500
      }
    },
    ["人物成长-金钱"] = {
      ["小有积蓄"] = {
        achieve_desc = "身上金钱达到1000万",
        order = 10
      },
      ["发家致富"] = {
        achieve_desc = "身上金钱达到1亿",
        order = 20
      },
      ["富甲一方"] = {
        achieve_desc = "身上金钱达到10亿",
        order = 30
      },
      ["富可敌国"] = {
        achieve_desc = "身上金钱达到20亿",
        order = 40
      },
      ["小奢侈一下"] = {
        achieve_desc = "一天内花费1000万",
        order = 50
      },
      ["买买买！"] = {
        achieve_desc = "一天内花费1亿",
        order = 60
      },
      ["就是管不住手！"] = {
        achieve_desc = "一天内花费10亿",
        order = 70
      },
      ["钱？身外之物！"] = {
        achieve_desc = "一天内花费20亿",
        order = 80
      }
    },
    ["人物成长-附灵"] = {
      ["附灵阵启动！"] = {
        achieve_desc = "附灵阵被成功激活",
        order = 10
      },
      ["真灵附体"] = {
        achieve_desc = "被任意真灵附身",
        order = 20
      },
      ["真灵初成"] = {
        achieve_desc = "任意真灵达到10级",
        order = 30
      },
      ["有如神助"] = {
        achieve_desc = "任意真灵达到50级",
        order = 40
      },
      ["灵阵大成"] = {
        achieve_desc = "附灵阵提升至5阶10级",
        order = 50
      }
    },
    ["伙伴培养-宠物养成"] = {
      ["一脸讨好"] = {
        achieve_desc = "成功使用1次超级神兽丹",
        order = 10
      },
      ["乖，听话"] = {
        achieve_desc = "拥有一只亲密（不包括天书增加的亲密）达到100000的宠物",
        order = 20
      },
      ["我们会永远在一起吧？"] = {
        achieve_desc = "拥有一只亲密（不包括天书增加的亲密）达到500000的宠物",
        order = 30
      },
      ["强烈的羁绊"] = {
        achieve_desc = "拥有一只亲密（不包括天书增加的亲密）达到1000000的宠物",
        order = 40
      },
      ["主人，我飞升啦！"] = {
        achieve_desc = "任意一只宠物完成宠物飞升任务 ",
        order = 50
      },
      ["天生技能"] = {
        achieve_desc = "任意一只宠物拥有1种天生技能",
        order = 60
      },
      ["主人，我可能是个天才"] = {
        achieve_desc = "任意一只宠物拥有3种天生技能",
        order = 70
      },
      ["天生技能略有精进"] = {
        achieve_desc = "拥有一只天生技能等级达到50级的宠物",
        order = 80
      },
      ["天生技能略有小成"] = {
        achieve_desc = "拥有一只天生技能等级达到100级的宠物",
        order = 90
      },
      ["天生技能融会贯通"] = {
        achieve_desc = "拥有一只天生技能等级达到150级的宠物",
        order = 100
      },
      ["天生技能出神入化"] = {
        achieve_desc = "拥有一只天生技能等级达到200级的宠物",
        order = 110
      },
      ["研发技能"] = {
        achieve_desc = "任意一只宠物拥有1种研发技能",
        order = 120
      },
      ["宠物也需要勤学苦练"] = {
        achieve_desc = "任意一只宠物拥有4种研发技能",
        order = 130
      },
      ["研发技能略有精进"] = {
        achieve_desc = "拥有一只研发技能等级达到50级的宠物",
        order = 140
      },
      ["研发技能略有小成"] = {
        achieve_desc = "拥有一只研发技能等级达到100级的宠物",
        order = 150
      },
      ["研发技能融会贯通"] = {
        achieve_desc = "拥有一只研发技能等级达到150级的宠物",
        order = 160
      },
      ["研发技能出神入化"] = {
        achieve_desc = "拥有一只研发技能等级达到200级的宠物",
        order = 170
      },
      ["顿悟技能？"] = {
        achieve_desc = "成功进行1次宠物顿悟操作",
        order = 180
      },
      ["一发顿悟！"] = {
        achieve_desc = "任意一只宠物拥有顿悟进阶技能",
        order = 190
      },
      ["顿悟技能略有精进"] = {
        achieve_desc = "任意宠物的顿悟进阶技能等级达到40级",
        order = 200
      },
      ["顿悟技能略有小成"] = {
        achieve_desc = "任意宠物的顿悟进阶技能等级达到80级",
        order = 210
      },
      ["顿悟技能融会贯通"] = {
        achieve_desc = "任意宠物的顿悟进阶技能等级达到120级",
        order = 220
      },
      ["顿悟技能出神入化"] = {
        achieve_desc = "任意宠物的顿悟进阶技能等级达到160级",
        order = 230
      },
      ["我觉得这次可以强化成功"] = {
        achieve_desc = "成功进行1次宠物强化操作",
        order = 240
      },
      ["这次成长会是多少呢？"] = {
        achieve_desc = "成功进行1次宠物成长洗炼操作",
        order = 250
      },
      ["满成长！"] = {
        achieve_desc = "拥有一只所有成长皆满的宠物",
        order = 260
      },
      ["开启点化之旅"] = {
        achieve_desc = "进行1次宠物点化操作",
        order = 270
      },
      ["踏上羽化之路"] = {
        achieve_desc = "进行1次宠物羽化操作",
        order = 275
      },
      ["打怪升级太慢了！"] = {
        achieve_desc = "进行1次宠物经验丹喂养操作",
        order = 280
      },
      ["火箭一样的升级速度"] = {
        achieve_desc = "累计使用%d个宠物经验丹",
        order = 290
      },
      ["乖乖站好，吃经验！"] = {
        achieve_desc = "累计使用%d个宠物经验丹",
        order = 300
      },
      ["进化吧！"] = {
        achieve_desc = "任意一只宠物完成进化操作",
        order = 310
      },
      ["薪火相传"] = {
        achieve_desc = "任意一只宠物完成继承操作",
        order = 320
      },
      ["初次幻化"] = {
        achieve_desc = "成功进行1次宠物幻化操作",
        order = 330
      },
      ["出门在外，怎能无坐骑？"] = {
        achieve_desc = "成功进行1次精怪驯化操作",
        order = 340
      },
      ["加油，我的坐骑！"] = {
        achieve_desc = "成功进行1次坐骑融合操作",
        order = 350
      },
      ["风...风灵丸！"] = {
        achieve_desc = "进行1次坐骑风灵丸喂养操作",
        order = 360
      },
      ["二阶坐骑"] = {
        achieve_desc = "拥有一只基础阶位为二阶的坐骑",
        order = 370
      },
      ["三阶坐骑"] = {
        achieve_desc = "拥有一只基础阶位为三阶的坐骑",
        order = 380
      },
      ["四阶坐骑"] = {
        achieve_desc = "拥有一只基础阶位为四阶的坐骑",
        order = 390
      },
      ["五阶坐骑"] = {
        achieve_desc = "拥有一只基础阶位为五阶的坐骑",
        order = 400
      },
      ["六阶坐骑"] = {
        achieve_desc = "拥有一只基础阶位为六阶的坐骑",
        order = 410
      },
      ["八阶坐骑"] = {
        achieve_desc = "拥有一只基础阶位为八阶的坐骑",
        order = 420
      },
      ["日积月累终成变异"] = {
        achieve_desc = "使用100个变异召唤令兑换1只变异宠物",
        order = 430
      },
      ["日积月累终成神兽"] = {
        achieve_desc = "使用100个召唤令·上古神兽兑换1只神兽宠物",
        order = 431
      },
      ["主人，保护好我！"] = {
        achieve_desc = "任意一只宠物死亡1次",
        order = 440
      },
      ["宠物死亡也是要消耗寿命的！"] = {
        achieve_desc = "任意一只宠物死亡%d次",
        order = 450
      },
      ["快速消耗的忠诚储备"] = {
        achieve_desc = "任意一只宠物死亡%d次",
        order = 460
      },
      ["哼，三脚猫功夫"] = {
        achieve_desc = "宠物成功复活1次",
        order = 470
      },
      ["我又站起来啦！"] = {
        achieve_desc = "宠物成功复活%d次",
        order = 480
      },
      ["信主人，得永生"] = {
        achieve_desc = "宠物成功复活%d次",
        order = 490
      },
      ["整齐划一"] = {
        achieve_desc = "进入非切磋战斗时，5人同时出战相同宠物（战斗中切换不算）",
        order = 500
      },
      ["你知道反击天书吗？"] = {
        achieve_desc = "通过反击天书将敌方击杀",
        order = 510
      },
      ["宠物的反击美学"] = {
        achieve_desc = "通过反击天书击杀%d名敌人",
        order = 520
      },
      ["你们为什么都要用物理攻击打我？"] = {
        achieve_desc = "通过反击天书击杀%d名敌人",
        order = 530
      },
      ["生死与共"] = {
        achieve_desc = "成功进行1次宠物共生操作",
        order = 540
      },
      ["培本固元"] = {
        achieve_desc = "成功进行1次鬼宠培元操作",
        order = 550
      },
      ["凝心会神"] = {
        achieve_desc = "成功进行1次鬼宠凝神操作",
        order = 560
      },
      ["鬼中仙"] = {
        achieve_desc = "拥有一只鬼仙",
        order = 580
      }
    },
    ["伙伴培养-守护养成"] = {
      ["出来吧，我的守护！"] = {
        achieve_desc = "成功召唤1位守护",
        order = 10
      },
      ["想被守护围殴吗？"] = {
        achieve_desc = "成功召唤%d位守护",
        order = 20
      },
      ["守护也是要历练的"] = {
        achieve_desc = "完成1次守护历练",
        order = 30
      },
      ["修道不停，历练不止"] = {
        achieve_desc = "所有守护达到紫色品质以上",
        order = 40
      },
      ["守护已成仙"] = {
        achieve_desc = "所有守护达到金色品质以上",
        order = 50
      },
      ["快吃下这颗元气丹！"] = {
        achieve_desc = "进行一次守护培养操作",
        order = 60
      },
      ["百分之99？？？"] = {
        achieve_desc = "累计使用%d颗元气丹",
        order = 70
      },
      ["声望都用来兑换元气丹"] = {
        achieve_desc = "累计使用%d颗元气丹",
        order = 80
      },
      ["帮派贡献也用来兑换元气丹"] = {
        achieve_desc = "累计使用%d颗元气丹",
        order = 90
      },
      ["这是守护变强的第一步"] = {
        achieve_desc = "任意一只守护培养等级到达5级",
        order = 100
      },
      ["谁说守护一定比人弱？"] = {
        achieve_desc = "任意一只守护培养等级到达10级",
        order = 110
      },
      ["极致的守护"] = {
        achieve_desc = "任意一只守护培养等级到达15级",
        order = 120
      }
    },
    ["装备打造-装备"] = {
      ["合身装备"] = {
        achieve_desc = "穿戴任意1件70级装备",
        order = 10
      },
      ["衣冠楚楚"] = {
        achieve_desc = "同时穿戴4件70级装备",
        order = 20
      },
      ["人要衣装"] = {
        achieve_desc = "穿戴任意1件80级装备",
        order = 30
      },
      ["精装加身"] = {
        achieve_desc = "同时穿戴4件80级装备",
        order = 40
      },
      ["人间利器"] = {
        achieve_desc = "穿戴任意1件90级装备",
        order = 50
      },
      ["锦绣衣衫"] = {
        achieve_desc = "同时穿戴4件90级装备",
        order = 60
      },
      ["珠光宝器"] = {
        achieve_desc = "穿戴任意1件100级装备",
        order = 70
      },
      ["降妖宝衣"] = {
        achieve_desc = "同时穿戴4件100级装备",
        order = 80
      },
      ["修道法器"] = {
        achieve_desc = "穿戴任意1件110级装备",
        order = 90
      },
      ["伏魔武装"] = {
        achieve_desc = "同时穿戴4件110级装备",
        order = 100
      },
      ["极致法宝"] = {
        achieve_desc = "穿戴任意1件120级装备",
        order = 110
      },
      ["千秋北斗"] = {
        achieve_desc = "同时穿戴4件120级装备",
        order = 120
      },
      ["神兵利器"] = {
        achieve_desc = "穿戴任意1件130级装备",
        order = 121
      },
      ["渡邪华装"] = {
        achieve_desc = "同时穿戴4件130级装备",
        order = 122
      },
      ["属性拆分"] = {
        achieve_desc = "装备属性拆分成功",
        order = 130
      },
      ["竟然拆不出来？"] = {
        achieve_desc = "装备属性拆分失败",
        order = 140
      },
      ["装备重组"] = {
        achieve_desc = "进行1次装备重组操作",
        order = 150
      },
      ["哇，满属性！"] = {
        achieve_desc = "获得1件满属性装备",
        order = 160
      },
      ["蓝色属性强化已满"] = {
        achieve_desc = "将装备蓝属性强化成满属性",
        order = 170
      },
      ["装备粉属性炼化"] = {
        achieve_desc = "进行1次装备粉属性炼化操作",
        order = 180
      },
      ["粉属性所相"] = {
        achieve_desc = "装备粉属性炼化出所有相性",
        order = 190
      },
      ["粉属性所属"] = {
        achieve_desc = "装备粉属性炼化出所有属性",
        order = 200
      },
      ["粉色满属性"] = {
        achieve_desc = "装备粉属性炼化出满属性",
        order = 210
      },
      ["粉色属性强化已满"] = {
        achieve_desc = "将装备粉属性强化成满属性",
        order = 220
      },
      ["装备黄属性炼化"] = {
        achieve_desc = "进行1次装备黄属性炼化操作",
        order = 230
      },
      ["黄属性所相"] = {
        achieve_desc = "装备黄属性炼化出所有相性",
        order = 240
      },
      ["黄属性所属"] = {
        achieve_desc = "装备黄属性炼化出所有属性",
        order = 250
      },
      ["黄色满属性"] = {
        achieve_desc = "装备黄属性炼化出满属性",
        order = 260
      },
      ["黄色属性强化已满"] = {
        achieve_desc = "将装备黄属性强化成满属性",
        order = 270
      },
      ["装备绿属性炼化"] = {
        achieve_desc = "进行1次装备绿属性炼化操作",
        order = 280
      },
      ["绿色满属性"] = {
        achieve_desc = "装备绿属性炼化出满属性",
        order = 290
      },
      ["套装满属性"] = {
        achieve_desc = "装备套装暗属性炼化出满属性",
        order = 300
      },
      ["装备属性强化"] = {
        achieve_desc = "进行1次装备属性强化操作",
        order = 310
      },
      ["装备属性强化成功！"] = {
        achieve_desc = "通过装备属性强化使属性值提升",
        order = 320
      },
      ["改1防具"] = {
        achieve_desc = "拥有一件改造1级防具",
        order = 330
      },
      ["改2防具"] = {
        achieve_desc = "拥有一件改造2级防具",
        order = 340
      },
      ["改3防具"] = {
        achieve_desc = "拥有一件改造3级防具",
        order = 350
      },
      ["改4防具"] = {
        achieve_desc = "拥有一件改造4级防具",
        order = 360
      },
      ["改5防具"] = {
        achieve_desc = "拥有一件改造5级防具",
        order = 370
      },
      ["改6防具"] = {
        achieve_desc = "拥有一件改造6级防具",
        order = 380
      },
      ["改7防具"] = {
        achieve_desc = "拥有一件改造7级防具",
        order = 390
      },
      ["改8防具"] = {
        achieve_desc = "拥有一件改造8级防具",
        order = 400
      },
      ["改9防具"] = {
        achieve_desc = "拥有一件改造9级防具",
        order = 410
      },
      ["改10防具"] = {
        achieve_desc = "拥有一件改造10级防具",
        order = 420
      },
      ["改1武器"] = {
        achieve_desc = "拥有一件改造1级武器",
        order = 430
      },
      ["改2武器"] = {
        achieve_desc = "拥有一件改造2级武器",
        order = 440
      },
      ["改3武器"] = {
        achieve_desc = "拥有一件改造3级武器",
        order = 450
      },
      ["改4武器"] = {
        achieve_desc = "拥有一件改造4级武器",
        order = 460
      },
      ["改5武器"] = {
        achieve_desc = "拥有一件改造5级武器",
        order = 470
      },
      ["改6武器"] = {
        achieve_desc = "拥有一件改造6级武器",
        order = 480
      },
      ["改7武器"] = {
        achieve_desc = "拥有一件改造7级武器",
        order = 490
      },
      ["改8武器"] = {
        achieve_desc = "拥有一件改造8级武器",
        order = 500
      },
      ["改9武器"] = {
        achieve_desc = "拥有一件改造9级武器",
        order = 510
      },
      ["改10武器"] = {
        achieve_desc = "拥有一件改造10级武器",
        order = 520
      },
      ["一步改5"] = {
        achieve_desc = "在改造完成度未满的情况下直接改5成功",
        order = 530
      },
      ["翻手改6"] = {
        achieve_desc = "在改造完成度未满的情况下直接改6成功",
        order = 540
      },
      ["弹指改7"] = {
        achieve_desc = "在改造完成度未满的情况下直接改7成功",
        order = 550
      },
      ["装备进化"] = {
        achieve_desc = "进行1次装备进化操作",
        order = 560
      },
      ["装备共鸣"] = {
        achieve_desc = "进行1次装备共鸣操作",
        order = 561
      },
      ["装备改造继承"] = {
        achieve_desc = "进行1次装备改造继承操作",
        order = 560
      },
      ["普通鉴定"] = {
        achieve_desc = "进行1次装备普通鉴定操作",
        order = 570
      },
      ["精致鉴定"] = {
        achieve_desc = "进行1次装备精致鉴定操作",
        order = 580
      },
      ["宝石鉴定"] = {
        achieve_desc = "进行1次装备宝石鉴定操作",
        order = 590
      }
    },
    ["装备打造-首饰"] = {
      ["低级首饰"] = {
        achieve_desc = "穿戴任意1件70级首饰",
        order = 10
      },
      ["平民搭配"] = {
        achieve_desc = "同时穿戴4件70级首饰",
        order = 20
      },
      ["进阶首饰"] = {
        achieve_desc = "穿戴任意1件80级首饰",
        order = 30
      },
      ["珠光初现"] = {
        achieve_desc = "同时穿戴4件80级首饰",
        order = 40
      },
      ["人间至宝"] = {
        achieve_desc = "穿戴任意1件90级首饰",
        order = 50
      },
      ["锦绣光华"] = {
        achieve_desc = "同时穿戴4件90级首饰",
        order = 60
      },
      ["开光首饰"] = {
        achieve_desc = "穿戴任意1件100级首饰",
        order = 70
      },
      ["降妖饰品"] = {
        achieve_desc = "同时穿戴4件100级首饰",
        order = 80
      },
      ["静修挂饰"] = {
        achieve_desc = "穿戴任意1件110级首饰",
        order = 90
      },
      ["伏魔仙饰"] = {
        achieve_desc = "同时穿戴4件110级首饰",
        order = 100
      },
      ["极致首饰"] = {
        achieve_desc = "穿戴任意1件120级首饰",
        order = 110
      },
      ["无价玄通"] = {
        achieve_desc = "同时穿戴4件120级首饰",
        order = 120
      },
      ["仙灵宝饰"] = {
        achieve_desc = "穿戴任意1件130级首饰",
        order = 121
      },
      ["霞光万丈"] = {
        achieve_desc = "同时穿戴4件130级首饰",
        order = 122
      },
      ["80级首饰合成"] = {
        achieve_desc = "成功合成1件80级首饰",
        order = 130
      },
      ["90级首饰合成"] = {
        achieve_desc = "成功合成1件90级首饰",
        order = 140
      },
      ["100级首饰合成"] = {
        achieve_desc = "成功合成1件100级首饰",
        order = 150
      },
      ["110级首饰合成"] = {
        achieve_desc = "成功合成1件110级首饰",
        order = 160
      },
      ["120级首饰合成"] = {
        achieve_desc = "成功合成1件120级首饰",
        order = 170
      },
      ["130级首饰合成"] = {
        achieve_desc = "成功合成1件130级首饰",
        order = 171
      },
      ["首饰重铸"] = {
        achieve_desc = "进行1次首饰重铸操作",
        order = 180
      },
      ["首饰分解"] = {
        achieve_desc = "进行1次首饰分解操作",
        order = 190
      },
      ["首饰属性转换"] = {
        achieve_desc = "进行1次首饰属性转换操作",
        order = 200
      },
      ["首饰强化之始"] = {
        achieve_desc = "进行1次首饰强化操作",
        order = 200
      },
      ["首饰强化成功"] = {
        achieve_desc = "强化首饰使其提升1级",
        order = 200
      },
      ["首饰强化与运气的关系"] = {
        achieve_desc = "首饰强化时提升一条附加属性",
        order = 200
      },
      ["首饰强化满级"] = {
        achieve_desc = "将任意1件首饰强化到20级",
        order = 200
      },
      ["珠光宝气"] = {
        achieve_desc = "同时穿戴4件强化等级达到10级的首饰",
        order = 200
      }
    },
    ["装备打造-法宝"] = {
      ["法宝加身"] = {
        achieve_desc = "穿戴任意1件法宝",
        order = 10
      },
      ["2级法宝"] = {
        achieve_desc = "任意法宝等级达到2级",
        order = 20
      },
      ["3级法宝"] = {
        achieve_desc = "任意法宝等级达到3级",
        order = 30
      },
      ["4级法宝"] = {
        achieve_desc = "任意法宝等级达到4级",
        order = 40
      },
      ["5级法宝"] = {
        achieve_desc = "任意法宝等级达到5级",
        order = 50
      },
      ["6级法宝"] = {
        achieve_desc = "任意法宝等级达到6级",
        order = 60
      },
      ["7级法宝"] = {
        achieve_desc = "任意法宝等级达到7级",
        order = 70
      },
      ["8级法宝"] = {
        achieve_desc = "任意法宝等级达到8级",
        order = 80
      },
      ["9级法宝"] = {
        achieve_desc = "任意法宝等级达到9级",
        order = 90
      },
      ["10级法宝"] = {
        achieve_desc = "任意法宝等级达到10级",
        order = 100
      },
      ["11级法宝"] = {
        achieve_desc = "任意法宝等级达到11级",
        order = 110
      },
      ["12级法宝"] = {
        achieve_desc = "任意法宝等级达到12级",
        order = 120
      },
      ["13级法宝"] = {
        achieve_desc = "任意法宝等级达到13级",
        order = 130
      },
      ["14级法宝"] = {
        achieve_desc = "任意法宝等级达到14级",
        order = 140
      },
      ["15级法宝"] = {
        achieve_desc = "任意法宝等级达到15级",
        order = 150
      },
      ["16级法宝"] = {
        achieve_desc = "任意法宝等级达到16级",
        order = 160
      },
      ["17级法宝"] = {
        achieve_desc = "任意法宝等级达到17级",
        order = 170
      },
      ["18级法宝"] = {
        achieve_desc = "任意法宝等级达到18级",
        order = 180
      },
      ["19级法宝"] = {
        achieve_desc = "任意法宝等级达到19级",
        order = 190
      },
      ["20级法宝"] = {
        achieve_desc = "任意法宝等级达到20级",
        order = 200
      },
      ["21级法宝"] = {
        achieve_desc = "任意法宝等级达到21级",
        order = 210
      },
      ["22级法宝"] = {
        achieve_desc = "任意法宝等级达到22级",
        order = 220
      },
      ["23级法宝"] = {
        achieve_desc = "任意法宝等级达到23级",
        order = 230
      },
      ["24级法宝"] = {
        achieve_desc = "任意法宝等级达到24级",
        order = 231
      },
      ["法宝洗炼"] = {
        achieve_desc = "进行1次法宝洗炼",
        order = 240
      },
      ["法宝特技1级"] = {
        achieve_desc = "任意法宝特技达到1级",
        order = 250
      },
      ["法宝特技2级"] = {
        achieve_desc = "任意法宝特技达到2级",
        order = 260
      },
      ["法宝特技3级"] = {
        achieve_desc = "任意法宝特技达到3级",
        order = 270
      },
      ["法宝特技4级"] = {
        achieve_desc = "任意法宝特技达到4级",
        order = 280
      },
      ["法宝特技5级"] = {
        achieve_desc = "任意法宝特技达到5级",
        order = 290
      },
      ["法宝特技6级"] = {
        achieve_desc = "任意法宝特技达到6级",
        order = 300
      },
      ["法宝特技7级"] = {
        achieve_desc = "任意法宝特技达到7级",
        order = 310
      },
      ["法宝特技8级"] = {
        achieve_desc = "任意法宝特技达到8级",
        order = 320
      },
      ["法宝特技9级"] = {
        achieve_desc = "任意法宝特技达到9级",
        order = 330
      },
      ["法宝特技10级"] = {
        achieve_desc = "任意法宝特技达到10级",
        order = 340
      },
      ["法宝特技11级"] = {
        achieve_desc = "任意法宝特技达到11级",
        order = 350
      },
      ["法宝特技12级"] = {
        achieve_desc = "任意法宝特技达到12级",
        order = 360
      },
      ["法宝特技13级"] = {
        achieve_desc = "任意法宝特技达到13级",
        order = 370
      },
      ["法宝特技14级"] = {
        achieve_desc = "任意法宝特技达到14级",
        order = 380
      },
      ["法宝特技15级"] = {
        achieve_desc = "任意法宝特技达到15级",
        order = 390
      },
      ["法宝特技16级"] = {
        achieve_desc = "任意法宝特技达到16级",
        order = 400
      },
      ["法宝特技17级"] = {
        achieve_desc = "任意法宝特技达到17级",
        order = 410
      },
      ["法宝特技18级"] = {
        achieve_desc = "任意法宝特技达到18级",
        order = 420
      },
      ["法宝特技19级"] = {
        achieve_desc = "任意法宝特技达到19级",
        order = 430
      },
      ["法宝特技20级"] = {
        achieve_desc = "任意法宝特技达到20级",
        order = 440
      },
      ["法宝特技21级"] = {
        achieve_desc = "任意法宝特技达到21级",
        order = 450
      },
      ["法宝特技22级"] = {
        achieve_desc = "任意法宝特技达到22级",
        order = 460
      },
      ["法宝特技23级"] = {
        achieve_desc = "任意法宝特技达到23级",
        order = 470
      },
      ["法宝特技24级"] = {
        achieve_desc = "任意法宝特技达到24级",
        order = 480
      },
      ["灵气没了怎么行"] = {
        achieve_desc = "进行1次法宝补灵气操作",
        order = 490
      }
    },
    ["装备打造-魂器"] = {
      ["引动混沌"] = {
        achieve_desc = "进行1次魂器属性引动混沌操作",
        order = 10
      },
      ["两仪分化"] = {
        achieve_desc = "进行1次魂器属性两仪分化操作",
        order = 20
      },
      ["魂器技能升级"] = {
        achieve_desc = "进行1次魂器技能升级操作",
        order = 30
      },
      ["魂器进化"] = {
        achieve_desc = "进行1次魂器进化操作",
        order = 40
      },
      ["阴阳平衡？"] = {
        achieve_desc = "进行两仪分化时某条属性获得大于66点的阴阳值",
        order = 50
      }
    },
    ["装备打造-洛书"] = {
      ["凝气聚灵"] = {
        achieve_desc = "洛书品阶达到聚灵·高阶",
        order = 10
      },
      ["破邪镇魔"] = {
        achieve_desc = "洛书品阶达到镇魔·高阶",
        order = 20
      },
      ["执掌乾坤"] = {
        achieve_desc = "洛书品阶达到乾坤·高阶",
        order = 30
      },
      ["大道无极"] = {
        achieve_desc = "洛书品阶达到无极·高阶",
        order = 40
      }
    },
    ["人物社交-好友"] = {
      ["社交初建"] = {
        achieve_desc = "拥有%d个好友",
        order = 10
      },
      ["左右逢源"] = {
        achieve_desc = "拥有%d个好友",
        order = 20
      },
      ["八面玲珑"] = {
        achieve_desc = "拥有%d个好友",
        order = 30
      },
      ["好友遍天下"] = {
        achieve_desc = "拥有%d个好友",
        order = 40
      },
      ["亲密好友"] = {
        achieve_desc = "与1个好友友好度达到5000",
        order = 50
      },
      ["无间好友"] = {
        achieve_desc = "与1个好友友好度达到10000",
        order = 60
      },
      ["生死之交"] = {
        achieve_desc = "与1个好友友好度达到50000",
        order = 70
      },
      ["不离不弃"] = {
        achieve_desc = "与2个好友友好度达到50000",
        order = 80
      },
      ["心有灵犀"] = {
        achieve_desc = "与3个好友友好度达到50000",
        order = 90
      },
      ["莫逆之交"] = {
        achieve_desc = "与4个好友友好度达到50000",
        order = 100
      },
      ["天涯毗邻"] = {
        achieve_desc = "与5个好友友好度达到50000",
        order = 110
      }
    },
    ["人物社交-帮派"] = {
      ["加入帮派"] = {
        achieve_desc = "首次加入帮派",
        order = 10
      },
      ["些许贡献不足挂齿"] = {
        achieve_desc = "累计获得%d点帮贡",
        order = 20
      },
      ["努力奉献获得赏识"] = {
        achieve_desc = "累计获得%d点帮贡",
        order = 30
      },
      ["热情献给了帮派"] = {
        achieve_desc = "累计获得%d点帮贡",
        order = 40
      },
      ["为帮派贡献了青春"] = {
        achieve_desc = "累计获得%d点帮贡",
        order = 50
      },
      ["帮派血肉"] = {
        achieve_desc = "累计获得%d点帮贡",
        order = 60
      },
      ["帮派灵魂"] = {
        achieve_desc = "累计获得%d点帮贡",
        order = 70
      },
      ["帮派互助"] = {
        achieve_desc = "同帮派5人组队进行1场除切磋以外的战斗",
        order = 80
      },
      ["发红包啦"] = {
        achieve_desc = "首次发放帮派红包",
        order = 90
      },
      ["饿狼啊！"] = {
        achieve_desc = "发放的帮派红包30秒内被抢光",
        order = 100
      },
      ["风卷残云"] = {
        achieve_desc = "发放的帮派红包3秒内被抢光",
        order = 110
      },
      ["今天心情不错"] = {
        achieve_desc = "单日发放%d次帮派红包",
        order = 120
      },
      ["就是喜欢发红包"] = {
        achieve_desc = "累积发放过%d次帮派红包",
        order = 130
      },
      ["帮派书童"] = {
        achieve_desc = "累积发放帮派红包达到%d元宝",
        order = 140
      },
      ["帮派师爷"] = {
        achieve_desc = "累积发放帮派红包达到%d元宝",
        order = 150
      },
      ["帮派财神"] = {
        achieve_desc = "累积发放帮派红包达到%d元宝",
        order = 160
      },
      ["抢红包啦"] = {
        achieve_desc = "首次抢到帮派红包",
        order = 170
      },
      ["1元宝？"] = {
        achieve_desc = "在帮派红包中抢到1元宝",
        order = 180
      },
      ["手气最佳"] = {
        achieve_desc = "首次在抢帮派红包中获得手气最佳",
        order = 190
      },
      ["红包好多我好兴奋！"] = {
        achieve_desc = "当日内成功抢到%d个帮派红包",
        order = 200
      },
      ["抢红包小能手"] = {
        achieve_desc = "累计抢到%d个帮派红包 ",
        order = 210
      },
      ["抢红包发家致富"] = {
        achieve_desc = "累计抢夺帮派红包的总金额数超过%d元宝",
        order = 220
      },
      ["帮派功臣"] = {
        achieve_desc = "累计获得%d次帮派功臣",
        order = 230
      },
      ["帮派大功臣"] = {
        achieve_desc = "累计获得%d次帮派功臣",
        order = 240
      }
    },
    ["人物社交-人物关系"] = {
      ["好心人"] = {
        achieve_desc = "首次获得好心值",
        order = 10
      },
      ["路见不平"] = {
        achieve_desc = "累积获得%d点好心值",
        order = 20
      },
      ["拔刀相助"] = {
        achieve_desc = "累积获得%d点好心值",
        order = 30
      },
      ["热心之士"] = {
        achieve_desc = "累积获得%d点好心值",
        order = 40
      },
      ["侠义之士"] = {
        achieve_desc = "累积获得%d点好心值",
        order = 50
      },
      ["新婚"] = {
        achieve_desc = "首次与异性结婚",
        order = 60
      },
      ["桃园结义"] = {
        achieve_desc = "首次与他人进行结拜",
        order = 70
      },
      ["豪华婚礼"] = {
        achieve_desc = "举办1次豪华婚礼",
        order = 80
      },
      ["布婚"] = {
        achieve_desc = "结婚满%d天",
        order = 90
      },
      ["皮婚"] = {
        achieve_desc = "结婚满%d天",
        order = 100
      },
      ["木婚"] = {
        achieve_desc = "结婚满%d天",
        order = 110
      },
      ["银婚"] = {
        achieve_desc = "结婚满%d天",
        order = 120
      },
      ["金婚"] = {
        achieve_desc = "结婚满%d天",
        order = 130
      },
      ["郎情妾意"] = {
        achieve_desc = "夫妻之间友好度达到%d",
        order = 140
      },
      ["比翼双飞"] = {
        achieve_desc = "夫妻之间友好度达到%d",
        order = 150
      },
      ["情比金坚"] = {
        achieve_desc = "夫妻之间友好度达到%d",
        order = 151
      },
      ["至死不渝"] = {
        achieve_desc = "夫妻之间友好度达到%d",
        order = 152
      },
      ["君子之交"] = {
        achieve_desc = "结拜满%d天",
        order = 160
      },
      ["君子之交"] = {
        achieve_desc = "结拜满%d天",
        order = 170
      },
      ["忘形之交"] = {
        achieve_desc = "结拜满%d天",
        order = 180
      },
      ["肺腑之交"] = {
        achieve_desc = "结拜满%d天",
        order = 190
      },
      ["患难之交"] = {
        achieve_desc = "结拜满%d天",
        order = 200
      },
      ["金石之交"] = {
        achieve_desc = "结拜满%d天",
        order = 210
      },
      ["初为人师"] = {
        achieve_desc = "1名徒弟出师",
        order = 220
      },
      ["教书育人"] = {
        achieve_desc = "%d名徒弟出师",
        order = 230
      },
      ["桃李满天下"] = {
        achieve_desc = "%d名徒弟出师",
        order = 240
      }
    },
    ["人物社交-个人空间"] = {
      ["今天的空间状态是..."] = {
        achieve_desc = "在个人空间发送状态1次  ",
        order = 10
      },
      ["接下来的空间状态是..."] = {
        achieve_desc = "在个人空间累计发送状态%d次 ",
        order = 20
      },
      ["这里是我的地盘"] = {
        achieve_desc = "第一次设置空间签名",
        order = 30
      },
      ["我在这里呀！"] = {
        achieve_desc = "在个人空间设置我的家乡信息 ",
        order = 40
      },
      ["哎呦，不错呦"] = {
        achieve_desc = "进行1次点赞",
        order = 50
      },
      ["送人花束，手留余香"] = {
        achieve_desc = "在个人空间赠送他人1次郁金香花束",
        order = 60
      },
      ["潜力空间"] = {
        achieve_desc = "空间人气达到100",
        order = 70
      },
      ["人气空间"] = {
        achieve_desc = "空间人气达到1000",
        order = 80
      },
      ["热门空间"] = {
        achieve_desc = "空间人气达到5000",
        order = 90
      },
      ["巨星空间"] = {
        achieve_desc = "空间人气达到10000",
        order = 100
      }
    },
    ["任务活动-剧情任务"] = {
      ["浮生若梦"] = {
        achieve_desc = "完成主线浮生若梦",
        order = 10
      },
      ["拜入师门"] = {
        achieve_desc = "完成主线拜入师门",
        order = 20
      },
      ["山雨欲来"] = {
        achieve_desc = "完成主线山雨欲来",
        order = 30
      },
      ["天机难测"] = {
        achieve_desc = "完成主线天机难测",
        order = 40
      },
      ["道心我心"] = {
        achieve_desc = "完成主线道心我心",
        order = 50
      },
      ["渐入佳境"] = {
        achieve_desc = "完成主线渐入佳境",
        order = 60
      },
      ["欲渡无舟"] = {
        achieve_desc = "完成主线欲渡无舟",
        order = 70
      },
      ["如梦似真"] = {
        achieve_desc = "完成主线如梦似真",
        order = 80
      },
      ["镜花水月"] = {
        achieve_desc = "完成主线镜花水月",
        order = 90
      },
      ["画外河山"] = {
        achieve_desc = "完成主线画外河山",
        order = 100
      },
      ["天地之间"] = {
        achieve_desc = "完成主线天地之间",
        order = 110
      },
      ["谁与争锋"] = {
        achieve_desc = "完成主线谁与争锋",
        order = 120
      },
      ["万里乘风"] = {
        achieve_desc = "完成主线万里乘风",
        order = 121
      },
      ["天魔初现"] = {
        achieve_desc = "完成主线天魔初现",
        order = 122
      },
      ["山门考验之明智"] = {
        achieve_desc = "完成山门考验之明智",
        order = 123
      },
      ["山门考验之沐德"] = {
        achieve_desc = "完成山门考验之沐德",
        order = 124
      },
      ["阴阳煞之东海疑云"] = {
        achieve_desc = "完成阴阳煞之东海疑云",
        order = 124
      },
      ["阴阳煞之天墉波澜"] = {
        achieve_desc = "完成阴阳煞之天墉波澜",
        order = 124
      },
      ["阴阳煞之姜女相助"] = {
        achieve_desc = "完成阴阳煞之姜女相助",
        order = 124
      },
      ["阴阳煞之平息祸事"] = {
        achieve_desc = "完成阴阳煞之平息祸事",
        order = 124
      },
      ["妖魔道之勇擒鱼怪"] = {
        achieve_desc = "完成妖魔道之勇擒鱼怪",
        order = 130
      },
      ["妖魔道之真假神兽"] = {
        achieve_desc = "完成妖魔道之真假神兽",
        order = 140
      },
      ["妖魔道之试练之道"] = {
        achieve_desc = "完成妖魔道之试练之道",
        order = 150
      },
      ["妖魔道之力擒恶匪"] = {
        achieve_desc = "完成妖魔道之力擒恶匪",
        order = 160
      },
      ["妖魔道之探寻真相"] = {
        achieve_desc = "完成妖魔道之探寻真相",
        order = 170
      },
      ["妖魔道之妖魔当道"] = {
        achieve_desc = "完成妖魔道之妖魔当道",
        order = 180
      },
      ["妖魔道之除魔卫道"] = {
        achieve_desc = "完成妖魔道之除魔卫道",
        order = 190
      },
      ["仙魔录之初现疑云"] = {
        achieve_desc = "完成仙魔录之初现疑云",
        order = 200
      },
      ["仙魔录之谜局难解"] = {
        achieve_desc = "完成仙魔录之谜局难解",
        order = 210
      },
      ["仙魔录之初知真情"] = {
        achieve_desc = "完成仙魔录之初知真情",
        order = 220
      },
      ["仙魔录之猪精伏诛"] = {
        achieve_desc = "完成仙魔录之猪精伏诛",
        order = 230
      },
      ["仙魔录之真假难辨"] = {
        achieve_desc = "完成仙魔录之真假难辨",
        order = 240
      },
      ["仙魔录之获知详情"] = {
        achieve_desc = "完成仙魔录之获知详情",
        order = 250
      },
      ["仙魔录之封印得解"] = {
        achieve_desc = "完成仙魔录之封印得解",
        order = 260
      },
      ["仙魔录之重镇心魔"] = {
        achieve_desc = "完成仙魔录之重镇心魔",
        order = 270
      },
      ["仙魔录之混迹魔军"] = {
        achieve_desc = "完成仙魔录之混迹魔军",
        order = 280
      },
      ["仙魔录之大祸得消"] = {
        achieve_desc = "完成仙魔录之大祸得消",
        order = 290
      },
      ["幻仙劫之离奇失踪"] = {
        achieve_desc = "完成幻仙劫之离奇失踪",
        order = 300
      },
      ["幻仙劫之惊现魔教"] = {
        achieve_desc = "完成幻仙劫之惊现魔教",
        order = 310
      },
      ["幻仙劫之洞悉阴谋"] = {
        achieve_desc = "完成幻仙劫之洞悉阴谋",
        order = 320
      },
      ["幻仙劫之浮出水面"] = {
        achieve_desc = "完成幻仙劫之浮出水面",
        order = 330
      },
      ["幻仙劫之力挽狂澜"] = {
        achieve_desc = "完成幻仙劫之力挽狂澜",
        order = 340
      },
      ["伏魔记之突然事起"] = {
        achieve_desc = "完成伏魔记之突然事起",
        order = 350
      },
      ["伏魔记之再起风云"] = {
        achieve_desc = "完成伏魔记之再起风云",
        order = 360
      },
      ["伏魔记之误入圈套"] = {
        achieve_desc = "完成伏魔记之误入圈套",
        order = 370
      },
      ["伏魔记之幡然悔悟"] = {
        achieve_desc = "完成伏魔记之幡然悔悟",
        order = 380
      },
      ["伏魔记之解救仙山"] = {
        achieve_desc = "完成伏魔记之解救仙山",
        order = 390
      },
      ["鲲鹏变之北海事起"] = {
        achieve_desc = "完成鲲鹏变之北海事起",
        order = 400
      },
      ["鲲鹏变之五大灵阵"] = {
        achieve_desc = "完成鲲鹏变之五大灵阵",
        order = 410
      },
      ["鲲鹏变之祸乱不息"] = {
        achieve_desc = "完成鲲鹏变之祸乱不息",
        order = 420
      },
      ["鲲鹏变之寻访后羿"] = {
        achieve_desc = "完成鲲鹏变之寻访后羿",
        order = 430
      },
      ["鲲鹏变之斩妖封魔"] = {
        achieve_desc = "完成鲲鹏变之斩妖封魔",
        order = 440
      },
      ["地劫第一劫"] = {
        achieve_desc = "完成地劫第一劫",
        order = 450
      },
      ["地劫第二劫"] = {
        achieve_desc = "完成地劫第二劫",
        order = 460
      },
      ["地劫第三劫"] = {
        achieve_desc = "完成地劫第三劫",
        order = 470
      },
      ["地劫第四劫"] = {
        achieve_desc = "完成地劫第四劫",
        order = 480
      },
      ["地劫第五劫"] = {
        achieve_desc = "完成地劫第五劫",
        order = 490
      },
      ["地劫第六劫"] = {
        achieve_desc = "完成地劫第六劫",
        order = 500
      },
      ["地劫第七劫"] = {
        achieve_desc = "完成地劫第七劫",
        order = 510
      },
      ["地劫第八劫"] = {
        achieve_desc = "完成地劫第八劫",
        order = 520
      },
      ["地劫第九劫"] = {
        achieve_desc = "完成地劫第九劫",
        order = 530
      },
      ["地劫第十劫"] = {
        achieve_desc = "完成地劫第十劫",
        order = 540
      },
      ["寻得机缘，元神突破"] = {
        achieve_desc = "完成突破—剑冢机缘",
        order = 550
      },
      ["天劫第一劫"] = {
        achieve_desc = "完成天劫第一劫",
        order = 560
      },
      ["天劫第二劫"] = {
        achieve_desc = "完成天劫第二劫",
        order = 570
      },
      ["天劫第三劫"] = {
        achieve_desc = "完成天劫第三劫",
        order = 580
      },
      ["天劫第四劫"] = {
        achieve_desc = "完成天劫第四劫",
        order = 590
      },
      ["天劫第五劫"] = {
        achieve_desc = "完成天劫第五劫",
        order = 600
      },
      ["天劫第六劫"] = {
        achieve_desc = "完成天劫第六劫",
        order = 610
      },
      ["天劫第七劫"] = {
        achieve_desc = "完成天劫第七劫",
        order = 620
      },
      ["天劫第八劫"] = {
        achieve_desc = "完成天劫第八劫",
        order = 630
      },
      ["天劫第九劫"] = {
        achieve_desc = "完成天劫第九劫",
        order = 640
      },
      ["天劫第十劫"] = {
        achieve_desc = "完成天劫第十劫",
        order = 645
      },
      ["南天门试炼"] = {
        achieve_desc = "完成南天门试炼",
        order = 650
      },
      ["探寻地府"] = {
        achieve_desc = "完成探寻地府",
        order = 660
      },
      ["深入地府"] = {
        achieve_desc = "完成深入地府",
        order = 670
      },
      ["初入天界"] = {
        achieve_desc = "完成初入天界",
        order = 680
      },
      ["天界扬名"] = {
        achieve_desc = "完成天界扬名",
        order = 690
      },
      ["神算天机"] = {
        achieve_desc = "在神将嫦娥的获取任务中领悟神算子的提示",
        order = 670
      }
    },
    ["任务活动-日常活动"] = {
      ["师门任务"] = {
        achieve_desc = "累计%d天完成每日师门任务",
        order = 10
      },
      ["修行在个人"] = {
        achieve_desc = "累计%d天完成每日师门任务",
        order = 20
      },
      ["勤学苦练"] = {
        achieve_desc = "连续%d天完成每日师门任务",
        order = 30
      },
      ["吃苦耐劳"] = {
        achieve_desc = "连续%d天完成每日师门任务",
        order = 40
      },
      ["缉拿强盗"] = {
        achieve_desc = "累计%d天完成每日除暴任务",
        order = 50
      },
      ["强盗克星"] = {
        achieve_desc = "累计%d天完成每日除暴任务",
        order = 60
      },
      ["锄强扶弱"] = {
        achieve_desc = "连续%d天完成每日除暴任务",
        order = 70
      },
      ["以暴制暴"] = {
        achieve_desc = "连续%d天完成每日除暴任务",
        order = 80
      },
      ["修炼之路"] = {
        achieve_desc = "累计%d天完成每日修炼任务",
        order = 90
      },
      ["脚踏实地"] = {
        achieve_desc = "累计%d天完成每日修炼任务",
        order = 100
      },
      ["一步一个脚印"] = {
        achieve_desc = "连续%d天完成每日修炼任务",
        order = 110
      },
      ["时刻不忘修炼自身"] = {
        achieve_desc = "连续%d天完成每日修炼任务",
        order = 120
      },
      ["通天试炼"] = {
        achieve_desc = "累计%d天完成每日通天塔任务",
        order = 130
      },
      ["无尽的挑战"] = {
        achieve_desc = "累计%d天完成每日通天塔任务",
        order = 140
      },
      ["不懈挑战"] = {
        achieve_desc = "连续%d天完成每日通天塔任务",
        order = 150
      },
      ["挑战之路"] = {
        achieve_desc = "连续%d天完成每日通天塔任务",
        order = 160
      },
      ["通天塔突破10层"] = {
        achieve_desc = "通天塔挑战层突破%d层",
        order = 170
      },
      ["通天塔突破20层"] = {
        achieve_desc = "通天塔挑战层突破%d层",
        order = 180
      },
      ["通天塔突破30层"] = {
        achieve_desc = "通天塔挑战层突破%d层",
        order = 190
      },
      ["通天塔突破40层"] = {
        achieve_desc = "通天塔挑战层突破%d层",
        order = 200
      },
      ["通天塔突破50层"] = {
        achieve_desc = "通天塔挑战层突破%d层",
        order = 210
      },
      ["通天塔突破60层"] = {
        achieve_desc = "通天塔挑战层突破%d层",
        order = 220
      },
      ["通天塔通关！"] = {
        achieve_desc = "通关通天塔",
        order = 230
      },
      ["通天塔飞升"] = {
        achieve_desc = "通天塔中进行1次飞升操作",
        order = 235
      },
      ["爬塔从不一层一层走"] = {
        achieve_desc = "通天塔中累计飞升%d次",
        order = 240
      },
      ["我无需出手"] = {
        achieve_desc = "通天塔挑战层中角色始终使用防御指令获得1场战斗胜利",
        order = 241
      },
      ["通天塔顶"] = {
        achieve_desc = "在通天塔顶与任意星君的战斗中获得胜利",
        order = 242
      },
      ["高处不胜寒"] = {
        achieve_desc = "在通天塔顶中累计战胜所有%d种星君阵容",
        order = 243
      },
      ["神秘的房间"] = {
        achieve_desc = "触发通天塔神秘房间事件",
        order = 243
      },
      ["小戏法难不倒我"] = {
        achieve_desc = "通过通天塔神秘房间之变戏法挑战",
        order = 243
      },
      ["我让你吃你就得吃"] = {
        achieve_desc = "通过通天塔神秘房间之超级大胃王挑战",
        order = 243
      },
      ["任你七十二变"] = {
        achieve_desc = "通过通天塔神秘房间之变身舞会挑战",
        order = 243
      },
      ["灵魂舞者"] = {
        achieve_desc = "通过通天塔神秘房间之手舞足蹈挑战",
        order = 243
      },
      ["幽灵你慢点走"] = {
        achieve_desc = "通过通天塔神秘房间之幽灵漫步挑战",
        order = 243
      },
      ["一点都不神秘嘛"] = {
        achieve_desc = "通过通天塔神秘房间任意%d种挑战",
        order = 243
      },
      ["助人为乐"] = {
        achieve_desc = "累计%d天完成每日助人为乐任务",
        order = 250
      },
      ["大善人"] = {
        achieve_desc = "累计%d天完成每日助人为乐任务",
        order = 260
      },
      ["每日一帮"] = {
        achieve_desc = "连续%d天完成每日助人为乐任务",
        order = 270
      },
      ["贵在坚持"] = {
        achieve_desc = "连续%d天完成每日助人为乐任务",
        order = 280
      },
      ["谁说白帮忙？"] = {
        achieve_desc = "助人为乐获得5倍奖励",
        order = 290
      },
      ["八仙梦境"] = {
        achieve_desc = "累计完成%d次八仙梦境任务",
        order = 300
      },
      ["梦中人"] = {
        achieve_desc = "累计完成%d次八仙梦境任务",
        order = 310
      },
      ["八仙过海"] = {
        achieve_desc = "完成1次八仙梦境之八仙过海",
        order = 320
      },
      ["唰唰唰，八仙通关！"] = {
        achieve_desc = "使用八仙玲珑骰累计掷%d次6点",
        order = 330
      },
      ["帮派任务"] = {
        achieve_desc = "累计%d天完成每日帮派任务",
        order = 340
      },
      ["为帮为己"] = {
        achieve_desc = "累计%d天完成每日帮派任务",
        order = 350
      },
      ["帮派大忙人"] = {
        achieve_desc = "连续%d天完成每日帮派任务",
        order = 360
      },
      ["为帮派奔波"] = {
        achieve_desc = "连续%d天完成每日帮派任务",
        order = 370
      },
      ["帮派日常挑战"] = {
        achieve_desc = "累计%d天完成每日帮派日常挑战任务",
        order = 380
      },
      ["帮派挑战狂人"] = {
        achieve_desc = "累计%d天完成每日帮派日常挑战任务",
        order = 390
      },
      ["沉迷挑战不可自拔"] = {
        achieve_desc = "连续%d天完成每日帮派挑战任务",
        order = 400
      },
      ["你又来啦"] = {
        achieve_desc = "连续%d天完成每日帮派挑战任务",
        order = 410
      },
      ["刷道开始"] = {
        achieve_desc = "累计刷道%d次",
        order = 420
      },
      ["投入热情来刷道"] = {
        achieve_desc = "累计刷道%d次",
        order = 430
      },
      ["投入赤诚来刷道"] = {
        achieve_desc = "累计刷道%d次",
        order = 440
      },
      ["投入情怀来刷道"] = {
        achieve_desc = "累计刷道%d次",
        order = 450
      },
      ["投入热血来刷道"] = {
        achieve_desc = "累计刷道%d次",
        order = 460
      },
      ["投入青春来刷道"] = {
        achieve_desc = "累计刷道%d次",
        order = 470
      },
      ["投入年华来刷道"] = {
        achieve_desc = "累计刷道%d次",
        order = 480
      },
      ["投入生命来刷道"] = {
        achieve_desc = "累计刷道%d次",
        order = 490
      },
      ["通关黑风洞"] = {
        achieve_desc = "通关普通难度黑风洞副本",
        order = 500
      },
      ["三人挑战，黑风洞！"] = {
        achieve_desc = "三人组队通关普通难度黑风洞副本",
        order = 500
      },
      ["无伤，黑风洞"] = {
        achieve_desc = "通关普通难度黑风洞副本且每场战斗结束时全员皆存活",
        order = 500
      },
      ["二当家来袭"] = {
        achieve_desc = "完成普通难度黑风洞隐藏事件二当家来袭",
        order = 510
      },
      ["移形换影"] = {
        achieve_desc = "完成普通难度黑风洞隐藏事件移形换影",
        order = 520
      },
      ["同生共死"] = {
        achieve_desc = "完成普通难度黑风洞隐藏事件同生共死",
        order = 530
      },
      ["通关终南山"] = {
        achieve_desc = "通关普通难度终南山副本",
        order = 535
      },
      ["三人挑战，终南山"] = {
        achieve_desc = "三人组队通关普通难度终南山副本",
        order = 535
      },
      ["无伤，终南山"] = {
        achieve_desc = "通关普通难度终南山且每场战斗结束时全员皆存活",
        order = 535
      },
      ["变异怪鸟"] = {
        achieve_desc = "完成普通难度终南山隐藏事件变异怪鸟",
        order = 535
      },
      ["压制爆点"] = {
        achieve_desc = "完成普通难度终南山隐藏事件压制爆点",
        order = 535
      },
      ["闻风丧胆"] = {
        achieve_desc = "完成普通难度终南山隐藏事件闻风丧胆",
        order = 535
      },
      ["通关兰若寺"] = {
        achieve_desc = "通关普通难度兰若寺副本",
        order = 540
      },
      ["三人挑战，兰若寺！"] = {
        achieve_desc = "三人组队通关普通难度兰若寺副本",
        order = 540
      },
      ["无伤，兰若寺"] = {
        achieve_desc = "通关普通难度兰若寺副本且每场战斗结束时全员皆存活",
        order = 540
      },
      ["血遁大法"] = {
        achieve_desc = "完成普通难度兰若寺隐藏事件血遁大法",
        order = 550
      },
      ["毫发无损"] = {
        achieve_desc = "完成普通难度兰若寺隐藏事件毫发无损",
        order = 560
      },
      ["敲山震虎"] = {
        achieve_desc = "完成普通难度兰若寺隐藏事件敲山震虎",
        order = 570
      },
      ["通关陈塘关"] = {
        achieve_desc = "通关普通难度陈塘关副本",
        order = 575
      },
      ["三人挑战，陈塘关！"] = {
        achieve_desc = "三人组队通关普通难度陈塘关副本",
        order = 575
      },
      ["无伤，陈塘关"] = {
        achieve_desc = "通关普通难度陈塘关且每场战斗结束时全员皆存活",
        order = 575
      },
      ["水牢之术"] = {
        achieve_desc = "完成普通难度陈塘关隐藏事件水牢之术",
        order = 575
      },
      ["以柔克刚"] = {
        achieve_desc = "完成普通难度陈塘关隐藏事件以柔克刚",
        order = 575
      },
      ["群龙无首"] = {
        achieve_desc = "完成普通难度陈塘关隐藏事件群龙无首",
        order = 575
      },
      ["通关烈火涧"] = {
        achieve_desc = "通关普通难度烈火涧副本",
        order = 580
      },
      ["三人挑战，烈火涧！"] = {
        achieve_desc = "三人组队通关普通难度烈火涧副本",
        order = 580
      },
      ["无伤，烈火涧"] = {
        achieve_desc = "通关普通难度烈火涧副本且每场战斗结束时全员皆存活",
        order = 580
      },
      ["盗宝小贼"] = {
        achieve_desc = "完成普通难度烈火涧隐藏事件盗宝小贼",
        order = 590
      },
      ["斩尽杀绝"] = {
        achieve_desc = "完成普通难度烈火涧隐藏事件斩尽杀绝",
        order = 600
      },
      ["道法通天"] = {
        achieve_desc = "完成普通难度烈火涧隐藏事件道法通天",
        order = 610
      },
      ["通关飘渺仙府"] = {
        achieve_desc = "通关普通难度飘渺仙府副本",
        order = 620
      },
      ["三人挑战，飘渺仙府！"] = {
        achieve_desc = "三人组队通关普通难度飘渺仙府副本",
        order = 620
      },
      ["无伤，飘渺仙府"] = {
        achieve_desc = "通关普通难度飘渺仙府副本且每场战斗结束时全员皆存活",
        order = 620
      },
      ["阴阳失衡"] = {
        achieve_desc = "完成普通难度飘渺仙府隐藏事件阴阳失衡",
        order = 630
      },
      ["倒行逆施"] = {
        achieve_desc = "完成普通难度飘渺仙府隐藏事件倒行逆施",
        order = 640
      },
      ["书剑双全"] = {
        achieve_desc = "完成普通难度飘渺仙府隐藏事件书剑双全",
        order = 650
      },
      ["幻境兰若寺"] = {
        achieve_desc = "通关困难难度兰若寺副本",
        order = 660
      },
      ["三人挑战，幻境兰若寺！"] = {
        achieve_desc = "三人组队通关困难难度兰若寺副本",
        order = 660
      },
      ["无伤，幻境兰若寺"] = {
        achieve_desc = "通关困难难度兰若寺副本且每场战斗结束时全员皆存活",
        order = 660
      },
      ["正面突破"] = {
        achieve_desc = "完成困难难度兰若寺隐藏事件正面突破",
        order = 670
      },
      ["狂气杀手"] = {
        achieve_desc = "完成困难难度兰若寺隐藏事件狂气杀手",
        order = 680
      },
      ["集中火力"] = {
        achieve_desc = "完成困难难度兰若寺隐藏事件集中火力",
        order = 690
      },
      ["幻境黑风洞"] = {
        achieve_desc = "通关困难难度黑风洞副本",
        order = 700
      },
      ["三人挑战，幻境黑风洞！"] = {
        achieve_desc = "三人组队通关困难难度黑风洞副本",
        order = 700
      },
      ["无伤，幻境黑风洞"] = {
        achieve_desc = "通关困难难度黑风洞副本且每场战斗结束时全员皆存活",
        order = 700
      },
      ["坚守人性"] = {
        achieve_desc = "完成困难难度黑风洞隐藏事件坚守人性",
        order = 710
      },
      ["兄弟齐整"] = {
        achieve_desc = "完成困难难度黑风洞隐藏事件兄弟齐整",
        order = 720
      },
      ["拯救狼王"] = {
        achieve_desc = "完成困难难度黑风洞隐藏事件拯救狼王",
        order = 730
      },
      ["幻境飘渺仙府"] = {
        achieve_desc = "通关困难难度飘渺仙府副本",
        order = 740
      },
      ["三人挑战，幻境飘渺仙府！"] = {
        achieve_desc = "三人组队通关困难难度飘渺仙府副本",
        order = 740
      },
      ["无伤，幻境飘渺仙府"] = {
        achieve_desc = "通关困难难度飘渺仙府副本且每场战斗结束时全员皆存活",
        order = 740
      },
      ["一己之力"] = {
        achieve_desc = "完成困难难度飘渺仙府隐藏事件一己之力",
        order = 750
      },
      ["书剑双绝"] = {
        achieve_desc = "完成困难难度飘渺仙府隐藏事件书剑双绝",
        order = 760
      },
      ["幕后修士"] = {
        achieve_desc = "完成困难难度飘渺仙府隐藏事件幕后修士",
        order = 770
      },
      ["幻境烈火涧"] = {
        achieve_desc = "通关困难难度烈火涧副本",
        order = 740
      },
      ["三人挑战，幻境烈火涧！"] = {
        achieve_desc = "三人组队通关困难难度烈火涧副本",
        order = 740
      },
      ["无伤，幻境烈火涧"] = {
        achieve_desc = "通关困难难度烈火涧副本且每场战斗结束时全员皆存活",
        order = 740
      },
      ["无处可逃"] = {
        achieve_desc = "完成困难难度烈火涧隐藏事件无处可逃",
        order = 750
      },
      ["先诛强者"] = {
        achieve_desc = "完成困难难度烈火涧隐藏事件先诛强者",
        order = 760
      },
      ["无辜困兽"] = {
        achieve_desc = "完成困难难度烈火涧隐藏事件无辜困兽",
        order = 770
      },
      ["引魂入殿"] = {
        achieve_desc = "完成1次引魂入殿任务",
        order = 780
      },
      ["助魂为乐"] = {
        achieve_desc = "累计完成%d次引魂入殿任务",
        order = 790
      },
      ["地宫初战"] = {
        achieve_desc = "在地宫中战斗胜利1次",
        order = 800
      },
      ["一个子儿都不能少"] = {
        achieve_desc = "完成地宫宝藏小偷战斗时1个小偷都没跑",
        order = 810
      },
      ["小鬼莫慌"] = {
        achieve_desc = "帮地宫中迷路的小鬼成功找到妈妈",
        order = 820
      },
      ["地宫赌王"] = {
        achieve_desc = "在地宫双面鬼事件中赢得100地宫铜币",
        order = 830
      },
      ["一股神秘的力量"] = {
        achieve_desc = "在地宫神秘灵石事件中获得10点阳气值",
        order = 840
      },
      ["商人无处不在"] = {
        achieve_desc = "在地宫商人处购买一次商品",
        order = 850
      },
      ["行囊越大越好"] = {
        achieve_desc = "在地宫行囊工匠处扩展一次行囊空间",
        order = 860
      },
      ["深入地宫"] = {
        achieve_desc = "通关地宫前%d层",
        order = 870
      },
      ["地宫？小意思"] = {
        achieve_desc = "打败最后一关地宫的头领火焰战神",
        order = 890
      },
      ["地宫中的伙伴"] = {
        achieve_desc = "招募1次地宫随从",
        order = 900
      },
      ["人多力量大"] = {
        achieve_desc = "在地宫中上阵随从达到4名",
        order = 910
      },
      ["哇，这个随从好厉害"] = {
        achieve_desc = "在地宫中招募1次金色随从",
        order = 920
      },
      ["更强大的随从"] = {
        achieve_desc = "在地宫中进行1次随从升星操作",
        order = 930
      },
      ["闪亮的随从"] = {
        achieve_desc = "在地宫中将随从升至3星",
        order = 940
      },
      ["你走吧，缘尽地宫"] = {
        achieve_desc = "出售1次地宫随从",
        order = 950
      },
      ["地宫是我家"] = {
        achieve_desc = "通关地宫第20层时，本周消耗阳气值小于等于80点",
        order = 960
      },
      ["在地宫，我好强"] = {
        achieve_desc = "地宫属性强化等级达到40",
        order = 970
      }
    },
    ["任务活动-其他活动"] = {
      ["法宝任务，完成！"] = {
        achieve_desc = "完成%d次法宝任务",
        order = 10
      },
      ["坚持不懈，法宝任务"] = {
        achieve_desc = "完成%d次法宝任务",
        order = 20
      },
      ["法宝收藏家"] = {
        achieve_desc = "完成%d次法宝任务",
        order = 30
      },
      ["修法任务"] = {
        achieve_desc = "完成%d次修法任务",
        order = 40
      },
      ["修法之旅"] = {
        achieve_desc = "完成%d次修法任务",
        order = 50
      },
      ["修法也能爆10倍"] = {
        achieve_desc = "修法任务获得10倍奖励",
        order = 60
      },
      ["36天罡星"] = {
        achieve_desc = "成功战胜%d次天罡星",
        order = 70
      },
      ["击破！36天罡星"] = {
        achieve_desc = "成功战胜%d次天罡星",
        order = 80
      },
      ["72地煞星"] = {
        achieve_desc = "成功战胜%d次地煞星",
        order = 90
      },
      ["击破！72地煞星"] = {
        achieve_desc = "成功战胜%d次地煞星",
        order = 100
      },
      ["28变异星宿"] = {
        achieve_desc = "成功战胜%d次变异星宿",
        order = 110
      },
      ["击破！28变异星宿"] = {
        achieve_desc = "成功战胜%d次变异星宿",
        order = 120
      },
      ["三人挑战！28变异星宿"] = {
        achieve_desc = "三人组队挑战变异星宿成功",
        order = 130
      },
      ["十大鬼差"] = {
        achieve_desc = "成功战胜%d次鬼差",
        order = 140
      },
      ["击破！十大鬼差"] = {
        achieve_desc = "成功战胜%d次鬼差",
        order = 150
      },
      ["三人挑战！十大鬼差"] = {
        achieve_desc = "三人组队挑战十大鬼差成功",
        order = 160
      },
      ["上古妖王"] = {
        achieve_desc = "成功战胜%d次上古妖王",
        order = 170
      },
      ["击破！上古妖王"] = {
        achieve_desc = "成功战胜%d次上古妖王",
        order = 180
      },
      ["万年老妖"] = {
        achieve_desc = "成功战胜%d次万年老妖",
        order = 190
      },
      ["击破！万年老妖"] = {
        achieve_desc = "成功战胜%d次万年老妖",
        order = 200
      },
      ["三人挑战，万年老妖！"] = {
        achieve_desc = "三人组队挑战万年老妖成功",
        order = 210
      },
      ["铲除妖王"] = {
        achieve_desc = "在铲除妖王战斗中获得%d次胜利",
        order = 220
      },
      ["中洲护卫者"] = {
        achieve_desc = "在铲除妖王战斗中获得%d次胜利",
        order = 230
      },
      ["屹立不倒"] = {
        achieve_desc = "铲除妖王战斗中角色从未倒地且战斗胜利",
        order = 231
      },
      ["讨伐，黑熊妖皇！"] = {
        achieve_desc = "在黑熊妖皇战斗中获得%d次胜利",
        order = 240
      },
      ["三人挑战，黑熊妖皇！"] = {
        achieve_desc = "三人组队挑战黑熊妖皇成功",
        order = 250
      },
      ["讨伐，血炼魔猪！"] = {
        achieve_desc = "在血炼魔猪战斗中获得%d次胜利",
        order = 260
      },
      ["三人挑战，血炼魔猪！"] = {
        achieve_desc = "三人组队挑战血炼魔猪成功",
        order = 270
      },
      ["讨伐，赤血鬼猿！"] = {
        achieve_desc = "在赤血鬼猿战斗中获得%d次胜利",
        order = 280
      },
      ["三人挑战，赤血鬼猿！"] = {
        achieve_desc = "三人组队挑战赤血鬼猿成功",
        order = 290
      },
      ["讨伐，魅影蝎后！"] = {
        achieve_desc = "在魅影蝎后战斗中获得%d次胜利",
        order = 300
      },
      ["三人挑战，魅影蝎后！"] = {
        achieve_desc = "三人组队挑战魅影蝎后成功",
        order = 310
      },
      ["讨伐，九幽冥雀！"] = {
        achieve_desc = "在九幽冥雀战斗中获得%d次胜利",
        order = 300
      },
      ["三人挑战，九幽冥雀！"] = {
        achieve_desc = "三人组队挑战九幽冥雀成功",
        order = 310
      },
      ["讨伐，真武魔帝！"] = {
        achieve_desc = "在真武魔帝战斗中获得%d次胜利",
        order = 300
      },
      ["三人挑战，真武魔帝！"] = {
        achieve_desc = "三人组队挑战真武魔帝成功",
        order = 310
      },
      ["讨伐，东山邪灵！"] = {
        achieve_desc = "在东山邪灵战斗中获得%d次胜利",
        order = 300
      },
      ["三人挑战，东山邪灵！"] = {
        achieve_desc = "三人组队挑战东山邪灵成功",
        order = 310
      },
      ["讨伐，杀戮魔皇！"] = {
        achieve_desc = "在杀戮魔皇战斗中获得%d次胜利",
        order = 300
      },
      ["三人挑战，杀戮魔皇！"] = {
        achieve_desc = "三人组队挑战杀戮魔皇成功",
        order = 310
      },
      ["七杀星君的考验"] = {
        achieve_desc = "在七杀试炼战斗中获得1次胜利",
        order = 311
      },
      ["讨伐，火焰之灵！"] = {
        achieve_desc = "在火焰之灵的战斗中获得%d次胜利",
        order = 312
      },
      ["讨伐，火狮兽！"] = {
        achieve_desc = "在火狮兽的战斗中获得%d次胜利",
        order = 313
      },
      ["讨伐，金乌之灵！"] = {
        achieve_desc = "在金乌之灵的战斗中获得%d次胜利",
        order = 314
      },
      ["讨伐，大日金乌！"] = {
        achieve_desc = "在大日金乌战斗中获得%d次胜利",
        order = 315
      },
      ["更快、更高、更强！"] = {
        achieve_desc = "获得大日金乌排行前100名奖励",
        order = 316
      },
      ["最强的矛对上最强的盾"] = {
        achieve_desc = "在九天真君挑战中成功战胜昊天君",
        order = 317
      },
      ["不惧蛮力，全员应战！"] = {
        achieve_desc = "在九天真君挑战中成功战胜阳天君",
        order = 318
      },
      ["赤天君的指教！"] = {
        achieve_desc = "在九天真君挑战中成功战胜赤天君",
        order = 319
      },
      ["单挑还是群殴！"] = {
        achieve_desc = "在九天真君挑战中成功战胜朱天君",
        order = 319
      },
      ["苦战成天君！"] = {
        achieve_desc = "在九天真君挑战中成功战胜成天君",
        order = 319
      },
      ["日与月的光辉！"] = {
        achieve_desc = "在九天真君挑战中成功战胜幽天君",
        order = 319
      },
      ["煞气弥漫！"] = {
        achieve_desc = "在九天真君挑战中成功战胜玄天君",
        order = 319
      },
      ["逃不出的五指山！"] = {
        achieve_desc = "在九天真君挑战中成功战胜变天君",
        order = 319
      },
      ["九天归位！"] = {
        achieve_desc = "在九天真君挑战中成功战胜钧天君",
        order = 319
      },
      ["怒火中烧·一层"] = {
        achieve_desc = "成功挑战一层怒火下的炼狱冥炎",
        order = 319
      },
      ["怒火中烧·二层"] = {
        achieve_desc = "成功挑战二层怒火下的炼狱冥炎",
        order = 319
      },
      ["怒火中烧·三层"] = {
        achieve_desc = "成功挑战三层怒火下的炼狱冥炎",
        order = 319
      },
      ["怒火中烧·四层"] = {
        achieve_desc = "成功挑战四层怒火下的炼狱冥炎",
        order = 319
      },
      ["怒火中烧·五层"] = {
        achieve_desc = "成功挑战五层怒火下的炼狱冥炎",
        order = 319
      },
      ["怒火中烧·六层"] = {
        achieve_desc = "成功挑战六层怒火下的炼狱冥炎",
        order = 319
      },
      ["怒火中烧·七层"] = {
        achieve_desc = "成功挑战七层怒火下的炼狱冥炎",
        order = 319
      },
      ["怒火中烧·八层"] = {
        achieve_desc = "成功挑战八层怒火下的炼狱冥炎",
        order = 319
      },
      ["怒火中烧·九层"] = {
        achieve_desc = "成功挑战九层怒火下的炼狱冥炎",
        order = 319
      },
      ["中洲守护神"] = {
        achieve_desc = "成功战胜%d次精英头领",
        order = 320
      },
      ["周活动之化妆舞会"] = {
        achieve_desc = "参加%d次化妆舞会活动",
        order = 330
      },
      ["周活动之勇闯万妖窟"] = {
        achieve_desc = "参加%d次勇闯万妖窟活动",
        order = 340
      },
      ["周活动之异族入侵"] = {
        achieve_desc = "参加%d次异族入侵活动",
        order = 350
      },
      ["周活动之矿石大战"] = {
        achieve_desc = "参加%d次矿石大战活动",
        order = 360
      },
      ["周活动之百兽之王"] = {
        achieve_desc = "参加%d次百兽之王活动",
        order = 370
      },
      ["周活动之萝卜桃子大收集"] = {
        achieve_desc = "参加%d次萝卜桃子大收集活动",
        order = 380
      },
      ["畅玩周活动"] = {
        achieve_desc = "参加过所有周活动",
        order = 390
      },
      ["镖行万里"] = {
        achieve_desc = "完成%d次镖行万里任务",
        order = 400
      },
      ["镖行百万里"] = {
        achieve_desc = "完成%d次镖行万里任务",
        order = 410
      },
      ["击败海盗"] = {
        achieve_desc = "在海盗入侵战斗中获得%d次胜利",
        order = 420
      },
      ["海盗猎人"] = {
        achieve_desc = "在海盗入侵战斗中获得%d次胜利",
        order = 430
      },
      ["清除叛逆"] = {
        achieve_desc = "在悬赏任务战斗中获得%d次胜利",
        order = 440
      },
      ["叛逆追捕者"] = {
        achieve_desc = "在悬赏任务战斗中获得%d次胜利",
        order = 450
      },
      ["帮战后勤人员"] = {
        achieve_desc = "帮战中完成1次筹措军备",
        order = 460
      },
      ["黄金矿工"] = {
        achieve_desc = "帮战中成功开采1次金矿",
        order = 470
      },
      ["承包矿区！"] = {
        achieve_desc = "帮战中成功占领矿区战旗 ",
        order = 480
      },
      ["惩戒通天魔王"] = {
        achieve_desc = "帮战中成功战胜1次通天魔王 ",
        order = 490
      },
      ["战旗破坏者"] = {
        achieve_desc = "帮战中成功破坏1次敌方营地战旗 ",
        order = 500
      },
      ["初战告捷"] = {
        achieve_desc = "帮战中与敌方帮派成员战斗并获得胜利 ",
        order = 510
      },
      ["帮派战神"] = {
        achieve_desc = "一场帮战中与敌方帮派成员战斗并获得%d场胜利 ",
        order = 520
      },
      ["军备我包了，你们放心上！"] = {
        achieve_desc = "跨服帮战中完成1次筹措军备",
        order = 520
      },
      ["在哪儿都要挖金矿！"] = {
        achieve_desc = "跨服帮战中成功开采1次金矿",
        order = 520
      },
      ["我的矿区我做主！"] = {
        achieve_desc = "跨服帮战中成功占领矿区战旗",
        order = 520
      },
      ["通天魔王的梦魇"] = {
        achieve_desc = "跨服帮战中成功战胜1次通天魔王",
        order = 520
      },
      ["这里不准有战旗，拆！"] = {
        achieve_desc = "跨服帮战中成功破坏1次敌方营地战旗",
        order = 520
      },
      ["初建战功"] = {
        achieve_desc = "跨服帮战中与敌方帮派成员战斗并获得胜利",
        order = 520
      },
      ["战无不胜"] = {
        achieve_desc = "一场跨服帮战中与敌方帮派成员战斗并获得%d场胜利",
        order = 520
      },
      ["初试证道"] = {
        achieve_desc = "挑战证道殿护法并获得胜利",
        order = 530
      },
      ["无上尊者"] = {
        achieve_desc = "自身证道殿护法雕像坚持2小时不败",
        order = 540
      },
      ["初入英雄会"] = {
        achieve_desc = "获得一场英雄会战斗的胜利",
        order = 550
      },
      ["不败英雄"] = {
        achieve_desc = "自身英雄会英雄雕像坚持2小时不败",
        order = 560
      },
      ["叫我探案高手！"] = {
        achieve_desc = "成功登上过一次“十佳捕快排行榜”",
        order = 570
      },
      ["咦，这就叫破案了吗？"] = {
        achieve_desc = "成为三等捕快",
        order = 580
      },
      ["探案这事儿交给我！"] = {
        achieve_desc = "成为二等捕快",
        order = 590
      },
      ["名捕！名捕！"] = {
        achieve_desc = "成为一等捕快",
        order = 600
      },
      ["我成为捕头啦！"] = {
        achieve_desc = "成为新晋捕头",
        order = 610
      },
      ["就没我破不了的案！"] = {
        achieve_desc = "成为金牌捕头",
        order = 620
      },
      ["鏖战，魔龙之尾"] = {
        achieve_desc = "在魔龙吞天挑战中成功战胜魔龙之尾",
        order = 700
      },
      ["鏖战，魔龙之爪"] = {
        achieve_desc = "在魔龙吞天挑战中成功战胜魔龙之爪",
        order = 710
      },
      ["鏖战，魔龙之首"] = {
        achieve_desc = "在魔龙吞天挑战中成功战胜魔龙之首",
        order = 720
      },
      ["鏖战，魔龙吞天"] = {
        achieve_desc = "在魔龙吞天挑战中成功战胜魔龙吞天",
        order = 730
      },
      ["鏖战，魔龙吞天·怒"] = {
        achieve_desc = "在魔龙吞天挑战中成功战胜魔龙吞天·怒",
        order = 740
      },
      ["奇门秘境·第10关"] = {
        achieve_desc = "奇门秘境达到第%d关",
        order = 750
      },
      ["奇门秘境·第60关"] = {
        achieve_desc = "奇门秘境达到第%d关",
        order = 750
      },
      ["奇门秘境·第90关"] = {
        achieve_desc = "奇门秘境达到第%d关",
        order = 750
      },
      ["奇门秘境·第120关"] = {
        achieve_desc = "奇门秘境达到第%d关",
        order = 750
      },
      ["奇门秘境·第180关"] = {
        achieve_desc = "奇门秘境达到第%d关",
        order = 750
      },
      ["奇门秘境·第240关"] = {
        achieve_desc = "奇门秘境达到第%d关",
        order = 750
      },
      ["奇门秘境·第360关"] = {
        achieve_desc = "奇门秘境达到第%d关",
        order = 750
      }
    },
    ["中洲轶事-趣闻"] = {
      ["道至婴成！"] = {
        achieve_desc = "成功凝结元婴（血婴）",
        order = 10
      },
      ["霞举飞升！"] = {
        achieve_desc = "完成飞升—仙道难任务飞升成仙或者魔",
        order = 11
      },
      ["逆天改命！"] = {
        achieve_desc = "完成一次仙魔转换",
        order = 12
      },
      ["筑基炼气"] = {
        achieve_desc = "内丹成功进入筑基炼气境界",
        order = 13
      },
      ["凝气化神"] = {
        achieve_desc = "内丹成功进入凝气化神境界",
        order = 14
      },
      ["还虚合道"] = {
        achieve_desc = "内丹成功进入还虚合道境界",
        order = 15
      },
      ["内丹初成"] = {
        achieve_desc = "内丹成功进入内丹初成境界",
        order = 16
      },
      ["金丹大成"] = {
        achieve_desc = "内丹成功进入金丹大成境界",
        order = 17
      },
      ["竞技场前100"] = {
        achieve_desc = "进入竞技场前100名",
        order = 20
      },
      ["竞技场前10"] = {
        achieve_desc = "进入竞技场前10名",
        order = 30
      },
      ["一统竞技场！"] = {
        achieve_desc = "竞技场排位第1名",
        order = 40
      },
      ["斗宠大会前100"] = {
        achieve_desc = "进入斗宠大会前100名",
        order = 45
      },
      ["斗宠大会前10"] = {
        achieve_desc = "进入斗宠大会前10名",
        order = 46
      },
      ["斗宠之王"] = {
        achieve_desc = "斗宠大会排位第1名",
        order = 47
      },
      ["人品小爆发"] = {
        achieve_desc = "五行生肖乐只猜中相性",
        order = 50
      },
      ["人品大爆发"] = {
        achieve_desc = "五行生肖乐只猜中生肖",
        order = 60
      },
      ["人品超级爆发"] = {
        achieve_desc = "五行生肖乐同时猜中相性和生肖",
        order = 70
      },
      ["财神降世"] = {
        achieve_desc = "商贾货站连续20期盈利",
        order = 71
      },
      ["衰神附体"] = {
        achieve_desc = "商贾货站连续20期亏损",
        order = 72
      },
      ["人生就像海上的波浪"] = {
        achieve_desc = "商贾货站盈利亏损交替连续20期",
        order = 73
      },
      ["小幸运"] = {
        achieve_desc = "天灯祈福获得己等奖",
        order = 73
      },
      ["气运强盛"] = {
        achieve_desc = "天灯祈福获得戊等奖",
        order = 74
      },
      ["天下掉陷饼"] = {
        achieve_desc = "天灯祈福获得丁等奖",
        order = 75
      },
      ["今日上吉"] = {
        achieve_desc = "天灯祈福获得丙等奖",
        order = 76
      },
      ["上上签"] = {
        achieve_desc = "天灯祈福获得乙等奖",
        order = 77
      },
      ["我就是锦鲤"] = {
        achieve_desc = "天灯祈福获得甲等奖",
        order = 78
      },
      ["中洲善人"] = {
        achieve_desc = "累计进行%d期天灯祈福",
        order = 79
      },
      ["要不洗个手?"] = {
        achieve_desc = "天灯祈福连续%d期未中奖",
        order = 79.1
      },
      ["这个性别不适合我"] = {
        achieve_desc = "使用改头换面卡进行%d次变性操作",
        order = 80
      },
      ["这个名字不适合我"] = {
        achieve_desc = "使用改头换面卡进行%d次改名操作",
        order = 90
      },
      ["战至天罡"] = {
        achieve_desc = "擂台结算时位于天罡段位",
        order = 100
      },
      ["战至地煞"] = {
        achieve_desc = "擂台结算时位于地煞段位",
        order = 110
      },
      ["战至星宿"] = {
        achieve_desc = "擂台结算时位于星宿段位",
        order = 120
      },
      ["战至紫微"] = {
        achieve_desc = "擂台结算时位于紫微段位",
        order = 130
      },
      ["又闯祸了"] = {
        achieve_desc = "挖宝时挖出上古妖王",
        order = 140
      },
      ["祸多不压身"] = {
        achieve_desc = "累计挖出%d次上古妖王",
        order = 150
      },
      ["闯大祸啦"] = {
        achieve_desc = "挖宝时挖出万年老妖",
        order = 160
      },
      ["老妖的好朋友"] = {
        achieve_desc = "累计挖出%d次万年老妖",
        order = 170
      },
      ["智多星"] = {
        achieve_desc = "帮派智多星困难难度中答对所有题目",
        order = 180
      },
      ["写作人之卷，读作天之卷"] = {
        achieve_desc = "帮派智多星活动中使用人之卷成功回答问题%d次",
        order = 181
      },
      ["圈圈王者"] = {
        achieve_desc = "帮派圈圈乐活动中获得冠军",
        order = 181
      },
      ["圈圈爱好者"] = {
        achieve_desc = "一次帮派圈圈乐活动中累计踩中%d个以上的圈圈",
        order = 181
      },
      ["帮派大厨"] = {
        achieve_desc = "一次帮派宴会活动中累计提交%d个以上正确食材",
        order = 181
      },
      ["超级美味！"] = {
        achieve_desc = "帮派宴会活动中品尝到5星菜肴",
        order = 181
      },
      ["难得“友”情人"] = {
        achieve_desc = "一次帮派温泉活动中，对同一个对象连续丢%d次肥皂",
        order = 181
      },
      ["有福同享"] = {
        achieve_desc = "帮派温泉活动中使用一次玉露精华",
        order = 181
      },
      ["愿好运常伴"] = {
        achieve_desc = "一次帮派踩方块活动中踩中12次幸运方块",
        order = 181
      },
      ["延年益寿"] = {
        achieve_desc = "帮派混元仙树活动中采集珍品仙果获得数值奖励",
        order = 181
      },
      ["寿与天齐"] = {
        achieve_desc = "帮派混元仙树活动中采集绝品仙果获得数值奖励",
        order = 181
      },
      ["日常签到"] = {
        achieve_desc = "首次完成签到操作",
        order = 190
      },
      ["累计签到30天"] = {
        achieve_desc = "累计%d天完成每日签到",
        order = 200
      },
      ["累计签到100天"] = {
        achieve_desc = "累计%d天完成每日签到",
        order = 210
      },
      ["累计签到365天"] = {
        achieve_desc = "累计%d天完成每日签到",
        order = 220
      },
      ["竟然存在1000元宝"] = {
        achieve_desc = "神秘大礼抽取1000银元宝奖励",
        order = 230
      },
      ["擂台争霸"] = {
        achieve_desc = "在擂台累计进行%d场切磋",
        order = 240
      },
      ["不服来战！"] = {
        achieve_desc = "在擂台累计进行%d场切磋",
        order = 250
      },
      ["小霸王就是我"] = {
        achieve_desc = "成为1次擂台小霸王",
        order = 250
      },
      ["满满王霸之气！"] = {
        achieve_desc = "成为1次擂台霸王",
        order = 250
      },
      ["小猜怡情"] = {
        achieve_desc = "累计进行%d次五行生肖乐",
        order = 260
      },
      ["中猜伤身"] = {
        achieve_desc = "累计进行%d次五行生肖乐",
        order = 270
      },
      ["大猜伤神"] = {
        achieve_desc = "累计进行%d次五行生肖乐",
        order = 280
      },
      ["强猜灰飞烟灭"] = {
        achieve_desc = "累计进行%d次五行生肖乐",
        order = 290
      },
      ["常胜将军"] = {
        achieve_desc = "竞技场%d连胜",
        order = 300
      },
      ["不败神话"] = {
        achieve_desc = "竞技场%d连胜",
        order = 310
      },
      ["斗宠奇才"] = {
        achieve_desc = "斗宠大会%d连胜",
        order = 311
      },
      ["斗宠无双"] = {
        achieve_desc = "斗宠大会%d连胜",
        order = 312
      },
      ["不想下线"] = {
        achieve_desc = "连续在线12小时",
        order = 320
      },
      ["怎能下线"] = {
        achieve_desc = "连续在线24小时",
        order = 330
      },
      ["大发言家"] = {
        achieve_desc = " 在世界频道累计发言%d次",
        order = 340
      },
      ["位列仙班·灵识初开"] = {
        achieve_desc = "从位列仙班月卡、季卡、年卡会员中任意购买一种",
        order = 350,
        IOSReview_desc = "从位列仙班·灵识初开、道法自然、大道无穷中任意购买一种"
      },
      ["位列仙班·道法自然"] = {
        achieve_desc = "从位列仙班季卡、年卡会员中任意购买一种",
        order = 360,
        IOSReview_desc = "从位列仙班·道法自然、大道无穷中任意购买一种"
      },
      ["位列仙班·大道无穷"] = {
        achieve_desc = "购买1次位列仙班年卡会员",
        order = 370,
        IOSReview_desc = "购买1次位列仙班·大道无穷"
      },
      ["哎呦，掉了块女娲"] = {
        achieve_desc = "通过系统奖励获得超级女娲石",
        order = 380
      },
      ["我有一个家"] = {
        achieve_desc = "拥有任意等级居所",
        order = 390
      },
      ["装修必须富丽堂皇"] = {
        achieve_desc = "居所舒适度大于等于1000",
        order = 400
      },
      ["烹饪学徒"] = {
        achieve_desc = "累计进行%d次烹饪",
        order = 410
      },
      ["烹饪能手"] = {
        achieve_desc = "累计进行%d次烹饪",
        order = 420
      },
      ["烹饪大师"] = {
        achieve_desc = "累计进行%d次烹饪",
        order = 430
      },
      ["鲁班学徒"] = {
        achieve_desc = "累计打造%d件家具",
        order = 440
      },
      ["能工巧匠"] = {
        achieve_desc = "累计打造%d件家具",
        order = 450
      },
      ["鲁班再世"] = {
        achieve_desc = "累计打造%d件家具",
        order = 460
      },
      ["种豆南山下"] = {
        achieve_desc = "累计收获%d次作物",
        order = 470
      },
      ["面朝黄土背朝天"] = {
        achieve_desc = "累计收获%d次作物",
        order = 480
      },
      ["劳动最光荣"] = {
        achieve_desc = "累计收获%d次作物",
        order = 490
      },
      ["小样，还想跑！"] = {
        achieve_desc = "累计手动钓鱼成功%d次",
        order = 500
      },
      ["鱼见愁"] = {
        achieve_desc = "累计手动钓鱼成功%d次",
        order = 510
      },
      ["愿者上钩"] = {
        achieve_desc = "累计手动钓鱼成功%d次",
        order = 520
      },
      ["钓鱼看的是技术"] = {
        achieve_desc = "连续手动钓鱼成功%d次",
        order = 530
      },
      ["我不是清洁工"] = {
        achieve_desc = "累计协助他人打扫居所%d次",
        order = 540
      },
      ["害虫克星"] = {
        achieve_desc = "累计清理农田害虫%d次",
        order = 550
      },
      ["斩草除根"] = {
        achieve_desc = "累计清理农田杂草%d次",
        order = 560
      },
      ["行云布雨"] = {
        achieve_desc = "累计为农田浇水%d次",
        order = 570
      },
      ["观音像的神韵"] = {
        achieve_desc = "白玉观音像请神成功时加成属性值等于15%%",
        order = 580
      },
      ["流光溢彩的如意"] = {
        achieve_desc = "七宝如意聚气成功时加成属性值等于15%%",
        order = 590
      },
      ["灵性十足"] = {
        achieve_desc = "金丝鸟笼通灵成功时加成属性值等于15%%",
        order = 600
      },
      ["材料供应商"] = {
        achieve_desc = "完成当日所有居所委托任务",
        order = 610
      },
      ["投我以木瓜，报之以琼琚"] = {
        achieve_desc = "在居所通过居所材料互赠与好友交换材料",
        order = 620
      },
      ["雇佣丫鬟"] = {
        achieve_desc = "拥有1名丫鬟",
        order = 630
      },
      ["零用钱还够花吗？"] = {
        achieve_desc = "为丫鬟发放1次零用钱 ",
        order = 640
      },
      ["书生管家"] = {
        achieve_desc = "拥有年轻男管家",
        order = 650
      },
      ["成熟女管家"] = {
        achieve_desc = "拥有中年女管家",
        order = 660
      },
      ["哼哼哈嘿！"] = {
        achieve_desc = "进行一场木桩战斗",
        order = 670
      },
      ["乘毯而行"] = {
        achieve_desc = "使用家具西域飞毯进行1次传送 ",
        order = 680
      },
      ["姜太公钓鱼"] = {
        achieve_desc = "钓鱼脱竿次数达到%d次",
        order = 690
      },
      ["鲨鱼吃面团"] = {
        achieve_desc = "使用鱼饵面团钓起1只鲨鱼",
        order = 700
      },
      ["秘制河虾"] = {
        achieve_desc = "使用秘制鱼饵钓起1只河虾",
        order = 710
      },
      ["旗鼓相当的对手"] = {
        achieve_desc = " 与黄仨儿猜拳连续3次平局",
        order = 720
      },
      ["淘宝"] = {
        achieve_desc = "师门巡逻任务中淘到%d种不同的宝贝",
        order = 730
      },
      ["全民公敌"] = {
        achieve_desc = "累计PK并击败的人数达到%d人",
        order = 740
      },
      ["小小捕快"] = {
        achieve_desc = "成功抓捕1名恶人",
        order = 750
      },
      ["行侠仗义"] = {
        achieve_desc = "累计抓捕%d名恶人",
        order = 760
      },
      ["有钱人的强帮之道"] = {
        achieve_desc = "在强帮之道任务中上交1件满属性装备",
        order = 770
      },
      ["我就要这个"] = {
        achieve_desc = "强帮之道任务连续5次需求同一件装备",
        order = 780
      },
      ["听好了！"] = {
        achieve_desc = "成功使用1个喇叭",
        order = 790
      },
      ["音传四海"] = {
        achieve_desc = "累计使用%d个喇叭",
        order = 800
      },
      ["声震三界"] = {
        achieve_desc = "累计使用%d个喇叭",
        order = 810
      },
      ["专家级灵猫翻牌"] = {
        achieve_desc = "2018周年庆灵猫翻牌中，累计%d天以9个宝箱的成绩完成游戏",
        order = 820
      },
      ["客栈老板"] = {
        achieve_desc = "在冯喜来处盘下客栈分店",
        order = 830
      },
      ["豪华客栈"] = {
        achieve_desc = "将客栈等级提升至14级",
        order = 840
      },
      ["我比恶霸更凶狠"] = {
        achieve_desc = "在客栈触发事件“恶霸堵门”中，通过战斗赶走恶霸",
        order = 850
      },
      ["恶霸恶霸见我就怕"] = {
        achieve_desc = "在客栈触发事件“恶霸堵门”中，一场战斗击败10个恶霸",
        order = 851
      },
      ["息事宁人吧"] = {
        achieve_desc = "在客栈触发事件“恶霸堵门”中，通过给钱赶走恶霸",
        order = 860
      },
      ["好人有好报"] = {
        achieve_desc = "在客栈触发事件“落难书生”中，最终获得了书生的双倍回报",
        order = 870
      },
      ["我的直觉非常准"] = {
        achieve_desc = "在客栈触发事件“变戏法”中，最终获得了5倍的道具奖励",
        order = 880
      },
      ["砍价小能手"] = {
        achieve_desc = "在客栈触发事件“黑市商人”中，将价格砍至原价的4成及以下",
        order = 890
      },
      ["黑市商人的馈赠"] = {
        achieve_desc = "在客栈触发事件“黑市商人”中，购买到神秘女娲礼盒",
        order = 900
      },
      ["乞丐也有情义"] = {
        achieve_desc = "在客栈触发事件“乞丐上门”中，受到乞丐的报恩",
        order = 910
      },
      ["乞丐也有怒火"] = {
        achieve_desc = "在客栈触发事件“乞丐上门”中，受到乞丐的报复",
        order = 920
      },
      ["制霸中秋节"] = {
        achieve_desc = "2018中秋活动中，佩戴“中秋大胃王”称谓时通关真假月饼活动",
        order = 930
      },
      ["集卡王"] = {
        achieve_desc = "激活所有变身卡图鉴",
        order = 940
      },
      ["年年有鱼"] = {
        achieve_desc = "在居所钓出所有种类的鱼",
        order = 950
      },
      ["菊酒神"] = {
        achieve_desc = "2018年重阳节活动中击败酒册上所有的揽仙镇居民",
        order = 960
      },
      ["楼兰宝物守卫者"] = {
        achieve_desc = "2019元旦活动中，获得“楼兰宝物守卫者”称谓",
        order = 970
      },
      ["四方棋圣"] = {
        achieve_desc = "2018国庆节四方棋局活动中，与好友对战获胜%d次",
        order = 1050
      },
      ["情圣传人"] = {
        achieve_desc = "2019年元宵节活动中获得莲花姑娘和大胡子的青睐",
        order = 1060
      },
      ["翻牌高手"] = {
        achieve_desc = "2019年周年庆萌宠翻牌活动中，单次翻牌数达到100",
        order = 1070
      },
      ["火焰战神的天敌"] = {
        achieve_desc = "2020年【暑假】火魔深渊活动中战胜火焰战神",
        order = 1071
      },
      ["一展歌喉"] = {
        achieve_desc = "问道好声音活动中上传一首声音",
        order = 1080
      },
      ["我来也"] = {
        achieve_desc = "妙音电台中上传一个作品",
        order = 1081
      },
      ["生肖对决王者"] = {
        achieve_desc = "2019年暑假生肖对决活动中，连续获得7场胜利",
        order = 1090
      },
      ["划船我最快"] = {
        achieve_desc = "2019年暑假小舟竞赛活动中，连续7次游戏获得第一名",
        order = 1090
      },
      ["天赐之子"] = {
        achieve_desc = "通过送子娘娘的机缘考验，成功获得天地灵石",
        order = 1500
      },
      ["恩爱结晶"] = {
        achieve_desc = "通过周公之礼成功获得胎儿",
        order = 1510
      },
      ["萌娃出世"] = {
        achieve_desc = "娃娃成功出生",
        order = 1520
      },
      ["家有萌娃初长成"] = {
        achieve_desc = "娃娃成功拜师并进入儿童期",
        order = 1520
      },
      ["黑……金光中的一道黑暗"] = {
        achieve_desc = "通过引魂获得%d道金色品质的太阴之气",
        order = 1530,
        showProgress = true
      },
      ["黑暗中的一片金光"] = {
        achieve_desc = "通过引魂获得%d道金色品质的太阴之气",
        order = 1540,
        showProgress = true
      },
      ["黑暗中的一串金光"] = {
        achieve_desc = "通过引魂获得%d道金色品质的太阴之气",
        order = 1550,
        showProgress = true
      },
      ["黑暗中的一道金光"] = {
        achieve_desc = "通过引魂获得1道金色品质的太阴之气",
        order = 1560
      },
      ["神游太虚"] = {
        achieve_desc = "神魂达到五阶",
        order = 1570
      },
      ["天人合一"] = {
        achieve_desc = "神魂达到十阶",
        order = 1580
      },
      ["初探秘境"] = {
        achieve_desc = "秘境试炼活动中进入秘境30层",
        order = 1590
      },
      ["深入秘境"] = {
        achieve_desc = "秘境试炼活动中进入秘境300层",
        order = 1591
      },
      ["秘境只是后花园"] = {
        achieve_desc = "秘境试炼活动中进入秘境500层",
        order = 1592
      },
      ["食神的菜谱"] = {
        achieve_desc = "食神季活动中研究成功一次食神菜谱中的菜肴",
        order = 1593
      },
      ["掌勺高手"] = {
        achieve_desc = "食神季活动中烹饪等级达到6级",
        order = 1594
      },
      ["请叫我食神"] = {
        achieve_desc = "食神季活动中烹饪等级达到10级",
        order = 1594
      },
      ["多宝道人的馈赠"] = {
        achieve_desc = "在洛书随机事件“天材地宝”中，获得了多宝道人炼制的金色神格",
        order = 1594
      },
      ["玄天宗的祝福"] = {
        achieve_desc = "在洛书随机事件“驱逐心魔”中，受到玄天宗的祝福",
        order = 1594
      },
      ["哪吒真能闹"] = {
        achieve_desc = "在洛书随机事件“好瓜孬瓜”中，遭遇哪吒闹事",
        order = 1594
      },
      ["哮天巨宝"] = {
        achieve_desc = "在洛书随机事件“哮天宝藏”中，得到3个超级女娲石",
        order = 1594
      },
      ["猛犬落跑"] = {
        achieve_desc = "在洛书随机事件“哮天宝藏”中，成功吓跑哮天",
        order = 1594
      },
      ["哮天的报复"] = {
        achieve_desc = "在洛书随机事件“哮天宝藏”中，遭到哮天犬诅咒",
        order = 1594
      },
      ["明耀匠神的馈赠"] = {
        achieve_desc = "在洛书随机事件“真假匠神”中，获得了真匠神打造的金色神将装备",
        order = 1594
      },
      ["明耀界大忽悠"] = {
        achieve_desc = "在洛书随机事件“真假匠神”中，遭到假匠神携款逃跑",
        order = 1594
      },
      ["吓唬谁呢！"] = {
        achieve_desc = "在探案任务不翼而飞中将梁府老爷吓倒在地",
        order = 1594
      },
      ["我爱放鞭炮"] = {
        achieve_desc = "在2021年周年庆活动燃放鞭炮中通过14-5关",
        order = 1594
      },
      ["勤劳花农"] = {
        achieve_desc = "在2021年周年庆活动万花纳福中福缘等级达到60级",
        order = 1594
      }
    },
    ["中洲轶事-光辉岁月"] = {
      ["第一万年道"] = {
        achieve_desc = "本服本系第一个达到万年道行",
        order = 10
      },
      ["首杀，黑熊妖皇！"] = {
        achieve_desc = "完成黑熊妖皇首杀",
        order = 20
      },
      ["首杀，血炼魔猪！"] = {
        achieve_desc = "完成血炼魔猪首杀",
        order = 30
      },
      ["首杀，赤血鬼猿！"] = {
        achieve_desc = "完成赤血鬼猿首杀",
        order = 40
      },
      ["首杀，魅影蝎后！"] = {
        achieve_desc = "完成魅影蝎后首杀",
        order = 50
      },
      ["首杀，七杀试炼！"] = {
        achieve_desc = "完成七杀试炼首杀",
        order = 51
      },
      ["首杀，九幽冥雀！"] = {
        achieve_desc = "完成九幽冥雀首杀",
        order = 51
      },
      ["首杀，真武魔帝！"] = {
        achieve_desc = "完成真武魔帝首杀",
        order = 51
      },
      ["首杀，东山邪灵！"] = {
        achieve_desc = "完成东山邪灵首杀",
        order = 51
      },
      ["首杀，杀戮魔皇！"] = {
        achieve_desc = "完成杀戮魔皇首杀",
        order = 51
      },
      ["首杀，朱天君！"] = {
        achieve_desc = "完成朱天君首杀",
        order = 52
      },
      ["首杀，成天君！"] = {
        achieve_desc = "完成成天君首杀",
        order = 53
      },
      ["首杀，幽天君！"] = {
        achieve_desc = "完成幽天君首杀",
        order = 54
      },
      ["首杀，玄天君！"] = {
        achieve_desc = "完成玄天君首杀",
        order = 54
      },
      ["首杀，变天君！"] = {
        achieve_desc = "完成变天君首杀",
        order = 54
      },
      ["首杀，钧天君！"] = {
        achieve_desc = "完成钧天君首杀",
        order = 54
      },
      ["首杀，炼狱冥炎·怒意六层！"] = {
        achieve_desc = "完成炼狱冥炎怒意六层首杀",
        order = 54
      },
      ["首杀，炼狱冥炎·怒意七层！"] = {
        achieve_desc = "完成炼狱冥炎怒意七层首杀",
        order = 54
      },
      ["首杀，炼狱冥炎·怒意八层！"] = {
        achieve_desc = "完成炼狱冥炎怒意八层首杀",
        order = 54
      },
      ["首杀，炼狱冥炎·怒意九层！"] = {
        achieve_desc = "完成炼狱冥炎怒意九层首杀",
        order = 54
      },
      ["接好这只太极熊！"] = {
        achieve_desc = "使用精怪诱饵成功召唤太极熊",
        order = 60
      },
      ["竟然是墨麒麟！"] = {
        achieve_desc = "使用精怪诱饵成功召唤墨麒麟",
        order = 60
      },
      ["变异宠物的青睐"] = {
        achieve_desc = "通过系统奖励获得变异宠物",
        order = 70
      },
      ["金光现，神兽出！"] = {
        achieve_desc = "通过系统奖励获得神兽",
        order = 75
      },
      ["本服试道王者"] = {
        achieve_desc = "在本服试道中获得冠军",
        order = 80
      },
      ["跨服试道王者"] = {
        achieve_desc = "在跨服试道中获得冠军",
        order = 90
      },
      ["全民PK王者"] = {
        achieve_desc = "在全民PK中获得冠军",
        order = 100
      },
      ["名人中的名人"] = {
        achieve_desc = "在名人争霸赛中获得最强战队",
        order = 101
      },
      ["最强团队"] = {
        achieve_desc = "在名人争霸赛中获得最强团队",
        order = 101
      },
      ["所有相性5"] = {
        achieve_desc = "通过首饰合成、重铸或强化获得所有相性5属性的首饰",
        order = 110
      },
      ["集齐十二生肖，召唤神兽！"] = {
        achieve_desc = "使用12只不同的生肖变异宠物兑换获得神兽",
        order = 111
      },
      ["中洲天籁"] = {
        achieve_desc = "问道好声音活动位列3甲",
        order = 120
      },
      ["问道万人迷"] = {
        achieve_desc = "玩家个人妙音电台听众总数达到10000",
        order = 121
      },
      ["首杀，魔龙之首！"] = {
        achieve_desc = "完成魔龙之首首杀",
        order = 130
      },
      ["首杀，魔龙吞天！"] = {
        achieve_desc = "完成魔龙吞天首杀",
        order = 131
      },
      ["首杀，魔龙吞天·怒！"] = {
        achieve_desc = "完成魔龙吞天·怒首杀",
        order = 132
      }
    }
  }
}
