return {
  ["止血草"] = {
    icon = 1001,
    descript = "最常见的草药，有四片嫩绿的叶子，外敷伤处，可恢复少量气血",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=止血草#Z"
    },
    unit = "棵",
    func = "战斗中使用，气血恢复100点。战斗外使用，增加100点气血储备"
  },
  ["一叶草"] = {
    icon = 1002,
    descript = "只有一片叶子的绿色怪草，叶面上有经脉纹路，有助于气血的恢复",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=一叶草#Z"
    },
    unit = "棵",
    func = "战斗中使用，气血恢复200点。战斗外使用，增加200点气血储备"
  },
  ["兰芝草"] = {
    icon = 1003,
    descript = "生长在阴暗潮湿的地方，形如兰花，花分三瓣，对疗伤有一定帮助",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=兰芝草#Z"
    },
    unit = "棵",
    func = "战斗中使用，气血恢复350点。战斗外使用，增加350点气血储备"
  },
  ["地云草"] = {
    icon = 1004,
    descript = "地衣类植物，绿色芽状，茎肥厚，叶细长，能够恢复一定的气血值",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=地云草#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=地云草#Z"
    },
    unit = "棵",
    func = "战斗中使用，气血恢复600点。战斗外使用，增加650点气血储备"
  },
  ["七叶莲"] = {
    icon = 1005,
    descript = "常见的水生草药，粉红色花骨朵状，味稍苦涩，可以补充一定的气血",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=七叶莲#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=七叶莲#Z"
    },
    unit = "棵",
    func = "战斗中使用，气血恢复1000点。战斗外使用，增加1100点气血储备"
  },
  ["七色花"] = {
    icon = 1006,
    descript = "花开七瓣，每片一色，共七种颜色，内有花蕊，可以恢复一定的气血",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=七色花#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=七色花#Z"
    },
    unit = "棵",
    func = "战斗中使用，气血恢复1500点。战斗外使用，增加1650点气血储备"
  },
  ["青花菇"] = {
    icon = 1013,
    descript = "在野外潮湿环境里生长的一种深绿色青菇，对疗伤有较大的帮助",
    rescourse = {
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=青花菇#Z"
    },
    unit = "朵",
    func = "战斗中使用，气血恢复2000点。战斗外使用，增加2250点气血储备"
  },
  ["六月雪"] = {
    icon = 1014,
    descript = "生于关外的荒原，六月多见，通体洁白如雪，对气血的恢复很有好处",
    rescourse = {
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=六月雪#Z"
    },
    unit = "朵",
    func = "战斗中使用，气血恢复2500点。战斗外使用，增加2800点气血储备"
  },
  ["金创药"] = {
    icon = 1017,
    descript = "江湖郎中卖的黑色药丸，失传于江湖很久了，能够补充很多的气血",
    rescourse = {
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=金创药#Z"
    },
    unit = "瓶",
    func = "战斗中使用，气血恢复3000点。战斗外使用，增加3450点气血储备"
  },
  ["跌打酒"] = {
    icon = 1018,
    descript = "江湖郎中兜售的，用多种疗伤灵药泡制而成，能够恢复较多气血值",
    rescourse = {
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=跌打酒#Z"
    },
    unit = "罐",
    func = "战斗中使用，气血恢复4000点。战斗外使用，增加4650点气血储备"
  },
  ["蟒灵丹"] = {
    icon = 1019,
    descript = "取自原始丛林中巨蟒的内丹，晶莹剔透，尤其对恢复气血很有帮助",
    rescourse = {
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=蟒灵丹#Z"
    },
    unit = "颗",
    func = "战斗中使用，气血恢复5000点。战斗外使用，增加5850点气血储备"
  },
  ["猴头丝"] = {
    icon = 1020,
    descript = "一种海边生长的褐色蘑菇，状如猴子的脑袋，在气血恢复上很有效",
    rescourse = {
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=猴头丝#Z"
    },
    unit = "朵",
    func = "战斗中使用，气血恢复6000点。战斗外使用，增加7200点气血储备"
  },
  ["蜂王蜜"] = {
    icon = 1021,
    descript = "源自天上五彩蜜蜂酿制，入口爽滑，清香甘美，恢复气血方面很有效",
    rescourse = {
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=蜂王蜜#Z",
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=蜂王蜜#Z"
    },
    unit = "瓶",
    func = "战斗中使用，气血恢复8000点。战斗外使用，增加9900点气血储备"
  },
  ["血浆果"] = {
    icon = 1022,
    descript = "生于雪峰，状若苹果，果实红嫩，汁如鲜血，特别适合气血亏损的人",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=血浆果#Z"
    },
    unit = "个",
    func = "战斗中使用，气血恢复10000点。战斗外使用，增加12600点气血储备"
  },
  ["人参"] = {
    icon = 1023,
    descript = "椭圆形的根茎，有很多细长的须，已似人形，补气生血的高效妙药",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=人参#Z"
    },
    unit = "支",
    func = "战斗中使用，气血恢复15000点。战斗外使用，增加19200点气血储备"
  },
  ["鹿茸"] = {
    icon = 1024,
    descript = "仙鹿之幼角，深褐色，外被绒毛，内充精血，在恢复气血方面有奇效",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=鹿茸#Z"
    },
    unit = "个",
    func = "战斗中使用，气血恢复20000点。战斗外使用，增加26100点气血储备"
  },
  ["玉髓芝"] = {
    icon = 1050,
    descript = "散遗于远古苍山的仙草，凝聚天地元气，很有助于气血的恢复",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=玉髓芝#Z"
    },
    unit = "棵",
    func = "战斗中使用，目标等级<100，气血恢复20000点；目标等级>=100，气血恢复25000点。战斗外使用，增加33300点气血储备",
    effect_in_combat = "目标等级<100，气血恢复20000点；目标等级>=100，气血恢复25000点"
  },
  ["萦香丸"] = {
    icon = 1051,
    descript = "集多种名贵药材炼制而成，环绕红褐色光环，相传乃气血恢复之奇品",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=萦香丸#Z"
    },
    unit = "颗",
    func = "战斗中使用，目标等级<100，气血恢复25000点；目标等级>=100，气血恢复30000点。战斗外使用，增加40500点气血储备",
    effect_in_combat = "目标等级<100，气血恢复25000点；目标等级>=100，气血恢复30000点"
  },
  ["天灵元阳丹"] = {
    icon = 1054,
    descript = "得道仙人修炼时所用的仙丹，服用后令人神清气爽，可以恢复大量气血",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=天灵元阳丹#Z"
    },
    unit = "颗",
    func = "战斗中使用，目标等级<120，气血恢复30000点；目标等级>=120，气血恢复40000点。战斗外使用，增加54000点气血储备",
    effect_in_combat = "目标等级<120，气血恢复30000点；目标等级>=120，气血恢复40000点"
  },
  ["千年沉香"] = {
    icon = 1055,
    descript = "深埋于地下的千年沉香，散发着浓郁的香气，乃恢复气血之极品",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=千年沉香#Z"
    },
    unit = "截",
    func = "战斗中使用，目标等级<130，气血恢复40000点；目标等级>=130，气血恢复50000点。战斗外使用，增加67500点气血储备",
    effect_in_combat = "目标等级<130，气血恢复40000点；目标等级>=130，气血恢复50000点"
  },
  ["白果"] = {
    icon = 1008,
    descript = "银杏的果实，绿色，无花果状，有硬壳，服食后可恢复少量法力",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=白果#Z"
    },
    unit = "个",
    func = "战斗中使用，法力恢复80点。战斗外使用，增加80点法力储备"
  },
  ["蛇胆"] = {
    icon = 1009,
    descript = "取自五步蛇王的胆，紫红色，稍有腥味，服食后可恢复一定法力",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=蛇胆#Z"
    },
    unit = "个",
    func = "战斗中使用，法力恢复150点。战斗外使用，增加150点法力储备"
  },
  ["灵芽草"] = {
    icon = 1011,
    descript = "长有细长的芽孢，外表白嫩，金针菇状，对法力的恢复有些帮助",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=灵芽草#Z"
    },
    unit = "棵",
    func = "战斗中使用，法力恢复300点。战斗外使用，增加300点法力储备"
  },
  ["紫椹"] = {
    icon = 1012,
    descript = "棕黄色果实，如鸭梨状，入口甘甜，多汁，服食后有助于法力的恢复",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=紫椹#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=紫椹#Z"
    },
    unit = "个",
    func = "战斗中使用，法力恢复500点。战斗外使用，增加500点法力储备"
  },
  ["葫芦枣"] = {
    icon = 1015,
    descript = "貌似葫芦的一种枣类，色如水蜜桃，味美，对法力的恢复有一定帮助",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=葫芦枣#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=葫芦枣#Z"
    },
    unit = "个",
    func = "战斗中使用，法力恢复750点。战斗外使用，增加750点法力储备"
  },
  ["拐儿枣"] = {
    icon = 1016,
    descript = "扁平状，浅紫色果实，有异味，常为有钱人服用，有助于法力的恢复",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=拐儿枣#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=拐儿枣#Z"
    },
    unit = "个",
    func = "战斗中使用，法力恢复1000点。战斗外使用，增加1050点法力储备"
  },
  ["补气丹"] = {
    icon = 1025,
    descript = "行血补气的丹药，绿色大颗粒药丸，味腥，对恢复法力有一定的好处",
    rescourse = {
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=补气丹#Z"
    },
    unit = "颗",
    func = "战斗中使用，法力恢复1200点。战斗外使用，增加1300点法力储备"
  },
  ["云香精"] = {
    icon = 1026,
    descript = "花仙子以晨露泡制的丹药，呈白色珍珠状，服食后可恢复一定法力",
    rescourse = {
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=云香精#Z"
    },
    unit = "盒",
    func = "战斗中使用，法力恢复1500点。战斗外使用，增加1650点法力储备"
  },
  ["静心丹"] = {
    icon = 1027,
    descript = "和气安神之灵药，原是江湖郎中无意所得，可以帮助法力的恢复",
    rescourse = {
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=静心丹#Z"
    },
    unit = "瓶",
    func = "战斗中使用，法力恢复1800点。战斗外使用，增加2000点法力储备"
  },
  ["回神丹"] = {
    icon = 1028,
    descript = "泛着浅紫色光的药丸，江湖郎中无意所得，服食后可恢复较多法力",
    rescourse = {
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=回神丹#Z"
    },
    unit = "颗",
    func = "战斗中使用，法力恢复2500点。战斗外使用，增加2800点法力储备"
  },
  ["舒心丸"] = {
    icon = 1029,
    descript = "墨绿色的大颗粒药丸，有健脾理气之功效，对法力的恢复很有帮助",
    rescourse = {
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=舒心丸#Z"
    },
    unit = "颗",
    func = "战斗中使用，法力恢复3000点。战斗外使用，增加3400点法力储备"
  },
  ["暗香丸"] = {
    icon = 1030,
    descript = "传说中雪梨花酒泡制成的药丸，暗香扑鼻，对法力的恢复很有好处",
    rescourse = {
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=暗香丸#Z"
    },
    unit = "颗",
    func = "战斗中使用，法力恢复4000点。战斗外使用，增加4600点法力储备"
  },
  ["八珍汤"] = {
    icon = 1031,
    descript = "以八种珍贵补品精心酿制而成，晶莹剔透，特别有助于法力的恢复",
    rescourse = {
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=八珍汤#Z",
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=八珍汤#Z"
    },
    unit = "碗",
    func = "战斗中使用，法力恢复5000点。战斗外使用，增加5800点法力储备"
  },
  ["紫茸膏"] = {
    icon = 1032,
    descript = "用紫禁山巅之紫茸研磨，加以晨露熬制的药膏，对恢复法力有特效",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=紫茸膏#Z"
    },
    unit = "盒",
    func = "战斗中使用，法力恢复6000点。战斗外使用，增加7000点法力储备"
  },
  ["陈桑酒"] = {
    icon = 1033,
    descript = "以九九八十一种珍贵药材，用仙水泡制的陈酒，对恢复法力非常有效",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=陈桑酒#Z"
    },
    unit = "瓶",
    func = "战斗中使用，法力恢复8000点。战斗外使用，增加9400点法力储备"
  },
  ["天一丸"] = {
    icon = 1034,
    descript = "相传凡人吃上一粒，就能达到天人合一的境界，对恢复法力效果不错",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=天一丸#Z"
    },
    unit = "颗",
    func = "战斗中使用，法力恢复10000点。战斗外使用，增加11800点法力储备"
  },
  ["龙纹果"] = {
    icon = 1052,
    descript = "常年植于深山丛中，其色艳丽如血，其形似有龙鳞雕附，对法力恢复非常有效",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=龙纹果#Z"
    },
    unit = "颗",
    func = "战斗中使用，目标等级<100，法力恢复10000点；目标等级>=100，法力恢复15000点。战斗外使用，增加18000点法力储备",
    effect_in_combat = "目标等级<100，法力恢复10000点；目标等级>=100，法力恢复15000点"
  },
  ["聚灵丹"] = {
    icon = 1053,
    descript = "得道圣贤潜心闭关修炼之仙丹，吸取天地之灵气，此药乃恢复法力之奇品",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=聚灵丹#Z"
    },
    unit = "颗",
    func = "战斗中使用，目标等级<100，法力恢复15000点；目标等级>=100，法力恢复20000点。战斗外使用，增加24000点法力储备",
    effect_in_combat = "目标等级<100，法力恢复15000点；目标等级>=100，法力恢复20000点"
  },
  ["虎骨酒"] = {
    icon = 1056,
    descript = "以珍贵的虎胫骨和糯米熬制而成，陈酿数十年，可以恢复大量的法力",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=虎骨酒#Z"
    },
    unit = "瓶",
    func = "战斗中使用，目标等级<120，法力恢复20000点；目标等级>=120，法力恢复25000点。战斗外使用，增加30000点法力储备",
    effect_in_combat = "目标等级<120，法力恢复20000点；目标等级>=120，法力恢复25000点"
  },
  ["天山玉露"] = {
    icon = 1057,
    descript = "相传采集于千年仙山之中的甘露，乃恢复法力之极品",
    rescourse = {
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=天山玉露#Z"
    },
    unit = "瓶",
    func = "战斗中使用，目标等级<130，法力恢复25000点；目标等级>=130，法力恢复30000点。战斗外使用，增加36000点法力储备",
    effect_in_combat = "目标等级<130，法力恢复25000点；目标等级>=130，法力恢复30000点"
  },
  ["折扇"] = {
    icon = 1101,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 1
  },
  ["精铁扇"] = {
    icon = 1102,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 10
  },
  ["逍遥扇"] = {
    icon = 1103,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 20
  },
  ["玉骨扇"] = {
    icon = 1104,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 30
  },
  ["阴阳扇"] = {
    icon = 1105,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 40
  },
  ["凤羽扇"] = {
    icon = 1106,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:50#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 50
  },
  ["百花扇"] = {
    icon = 1107,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:60#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 60
  },
  ["流云扇"] = {
    icon = 1108,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:70#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 70
  },
  ["蔽日扇"] = {
    icon = 1109,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:80#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 80
  },
  ["乾坤扇"] = {
    icon = 1110,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:90#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 90
  },
  ["五彩神焰扇"] = {
    icon = 1157,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:100#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 100
  },
  ["离火七翎扇"] = {
    icon = 1111,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:110#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 110
  },
  ["赤霄烈焰扇"] = {
    icon = 1156,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:120#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 120
  },
  ["红云火霞扇"] = {
    icon = 1167,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:扇:130#@"
    },
    unit = "把",
    equipType = "扇",
    polar = 4,
    req_level = 130
  },
  ["铜锤"] = {
    icon = 1112,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "锤",
    polar = 5,
    req_level = 1
  },
  ["流星锤"] = {
    icon = 1113,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "锤",
    polar = 5,
    req_level = 10
  },
  ["八棱锤"] = {
    icon = 1114,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "锤",
    polar = 5,
    req_level = 20
  },
  ["亮银锤"] = {
    icon = 1115,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "锤",
    polar = 5,
    req_level = 30
  },
  ["乌金锤"] = {
    icon = 1116,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "锤",
    polar = 5,
    req_level = 40
  },
  ["混元锤"] = {
    icon = 1117,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:50#@"
    },
    unit = "对",
    equipType = "锤",
    polar = 5,
    req_level = 50
  },
  ["霹雳锤"] = {
    icon = 1118,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:60#@"
    },
    unit = "对",
    equipType = "锤",
    polar = 5,
    req_level = 60
  },
  ["晃金锤"] = {
    icon = 1119,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:70#@"
    },
    unit = "对",
    equipType = "锤",
    polar = 5,
    req_level = 70
  },
  ["撼地锤"] = {
    icon = 1120,
    descript = "",
    unit = "对",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:80#@"
    },
    equipType = "锤",
    polar = 5,
    req_level = 80
  },
  ["破天锤"] = {
    icon = 1121,
    descript = "",
    unit = "对",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:90#@"
    },
    equipType = "锤",
    polar = 5,
    req_level = 90
  },
  ["加持杵"] = {
    icon = 1122,
    descript = "",
    unit = "对",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:100#@"
    },
    equipType = "锤",
    polar = 5,
    req_level = 100
  },
  ["炼狱麒麟杵"] = {
    icon = 1158,
    descript = "",
    unit = "对",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:110#@"
    },
    equipType = "锤",
    polar = 5,
    req_level = 110
  },
  ["风雷如意杵"] = {
    icon = 1159,
    descript = "",
    unit = "对",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:120#@"
    },
    equipType = "锤",
    polar = 5,
    req_level = 120
  },
  ["玄黄破坚锤"] = {
    icon = 1170,
    descript = "",
    unit = "对",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:锤:130#@"
    },
    equipType = "锤",
    polar = 5,
    req_level = 130
  },
  ["长剑"] = {
    icon = 1123,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 1
  },
  ["青锋剑"] = {
    icon = 1124,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 10
  },
  ["沉香剑"] = {
    icon = 1125,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 20
  },
  ["飞虹剑"] = {
    icon = 1126,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 30
  },
  ["乾元剑"] = {
    icon = 1127,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 40
  },
  ["斩妖剑"] = {
    icon = 1128,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:50#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 50
  },
  ["昆吾剑"] = {
    icon = 1129,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:60#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 60
  },
  ["追魂剑"] = {
    icon = 1130,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:70#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 70
  },
  ["九黎剑"] = {
    icon = 1131,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:80#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 80
  },
  ["轩辕剑"] = {
    icon = 1132,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:90#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 90
  },
  ["乙木神剑"] = {
    icon = 1133,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:100#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 100
  },
  ["紫青玄魔剑"] = {
    icon = 1160,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:110#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 110
  },
  ["封神诛仙剑"] = {
    icon = 1161,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:120#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 120
  },
  ["九天玄冥剑"] = {
    icon = 1169,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:剑:130#@"
    },
    unit = "把",
    equipType = "剑",
    polar = 3,
    req_level = 130
  },
  ["长枪"] = {
    icon = 1134,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 1
  },
  ["铁枪"] = {
    icon = 1135,
    descript = "",
    unit = "把",
    rescourse = {},
    equipType = "枪",
    polar = 1,
    req_level = 10
  },
  ["点钢枪"] = {
    icon = 1136,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 20
  },
  ["乌金枪"] = {
    icon = 1137,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 30
  },
  ["火焰枪"] = {
    icon = 1138,
    descript = "",
    rescourse = {},
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 40
  },
  ["双头枪"] = {
    icon = 1139,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:50#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 50
  },
  ["寒风枪"] = {
    icon = 1140,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:60#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 60
  },
  ["暴雨梨花枪"] = {
    icon = 1141,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:70#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 70
  },
  ["云龙枪"] = {
    icon = 1142,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:80#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 80
  },
  ["蕴雷枪"] = {
    icon = 1143,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:90#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 90
  },
  ["风火游龙枪"] = {
    icon = 1162,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:100#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 100
  },
  ["九转金刚刃"] = {
    icon = 1163,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:110#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 110
  },
  ["混元斩龙戟"] = {
    icon = 1144,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:120#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 120
  },
  ["赤眼神龙枪"] = {
    icon = 1168,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:枪:130#@"
    },
    unit = "把",
    equipType = "枪",
    polar = 1,
    req_level = 130
  },
  ["铁爪"] = {
    icon = 1145,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 1
  },
  ["虎爪"] = {
    icon = 1146,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 10
  },
  ["赤炼爪"] = {
    icon = 1147,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 20
  },
  ["残青爪"] = {
    icon = 1148,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 30
  },
  ["阴风爪"] = {
    icon = 1149,
    descript = "",
    rescourse = {},
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 40
  },
  ["寒冰刺"] = {
    icon = 1150,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:50#@"
    },
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 50
  },
  ["骷髅爪"] = {
    icon = 1151,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:60#@"
    },
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 60
  },
  ["幽冥鬼爪"] = {
    icon = 1152,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:70#@"
    },
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 70
  },
  ["噬魂魔爪"] = {
    icon = 1153,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:80#@"
    },
    unit = "顶",
    equipType = "爪",
    polar = 2,
    req_level = 80
  },
  ["拂兰指"] = {
    icon = 1154,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:90#@"
    },
    unit = "顶",
    equipType = "爪",
    polar = 2,
    req_level = 90
  },
  ["啼血爪"] = {
    icon = 1155,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:100#@"
    },
    unit = "顶",
    equipType = "爪",
    polar = 2,
    req_level = 100
  },
  ["七巧玲珑爪"] = {
    icon = 1165,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:110#@"
    },
    unit = "顶",
    equipType = "爪",
    polar = 2,
    req_level = 110
  },
  ["镇魂摄天刺"] = {
    icon = 1164,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:120#@"
    },
    unit = "顶",
    equipType = "爪",
    polar = 2,
    req_level = 120
  },
  ["红绫火毒爪"] = {
    icon = 1166,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:爪:130#@"
    },
    unit = "对",
    equipType = "爪",
    polar = 2,
    req_level = 130
  },
  ["方巾"] = {
    icon = 1201,
    descript = "",
    rescourse = {},
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 1
  },
  ["皮帽"] = {
    icon = 1202,
    descript = "",
    rescourse = {},
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 10
  },
  ["青铜盔"] = {
    icon = 1203,
    descript = "",
    rescourse = {},
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 20
  },
  ["冲天盔"] = {
    icon = 1204,
    descript = "",
    rescourse = {},
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 30
  },
  ["虎头盔"] = {
    icon = 1205,
    descript = "",
    rescourse = {},
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 40
  },
  ["神龙盔"] = {
    icon = 1206,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:50#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 50
  },
  ["白玉冠"] = {
    icon = 1207,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:60#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 60
  },
  ["乾坤冠"] = {
    icon = 1208,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:70#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 70
  },
  ["龙冠"] = {
    icon = 1209,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:80#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 80
  },
  ["蟠龙冠"] = {
    icon = 1210,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:90#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 90
  },
  ["九霄烈焰冠"] = {
    icon = 1211,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:100#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 100
  },
  ["星耀冠"] = {
    icon = 1255,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:110#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 110
  },
  ["七星宝冠"] = {
    icon = 1256,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:120#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 120
  },
  ["白玉星冠"] = {
    icon = 1266,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男帽:130#@"
    },
    unit = "顶",
    equipType = "男帽",
    gender = 1,
    req_level = 130
  },
  ["簪子"] = {
    icon = 1212,
    descript = "",
    rescourse = {},
    unit = "支",
    equipType = "女帽",
    gender = 2,
    req_level = 1
  },
  ["飞凤钗"] = {
    icon = 1213,
    descript = "",
    rescourse = {},
    unit = "支",
    equipType = "女帽",
    gender = 2,
    req_level = 10
  },
  ["碧玉钗"] = {
    icon = 1214,
    descript = "",
    rescourse = {},
    unit = "支",
    equipType = "女帽",
    gender = 2,
    req_level = 20
  },
  ["蝴蝶钗"] = {
    icon = 1215,
    descript = "",
    rescourse = {},
    unit = "支",
    equipType = "女帽",
    gender = 2,
    req_level = 30
  },
  ["金钗"] = {
    icon = 1216,
    descript = "",
    rescourse = {},
    unit = "支",
    equipType = "女帽",
    gender = 2,
    req_level = 40
  },
  ["珍珠钗"] = {
    icon = 1217,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:50#@"
    },
    unit = "支",
    equipType = "女帽",
    gender = 2,
    req_level = 50
  },
  ["凤尾钗"] = {
    icon = 1218,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:60#@"
    },
    unit = "支",
    equipType = "女帽",
    gender = 2,
    req_level = 60
  },
  ["鱼尾冠"] = {
    icon = 1219,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:70#@"
    },
    unit = "支",
    equipType = "女帽",
    gender = 2,
    req_level = 70
  },
  ["凤冠"] = {
    icon = 1220,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:80#@"
    },
    unit = "顶",
    equipType = "女帽",
    gender = 2,
    req_level = 80
  },
  ["金霞冠"] = {
    icon = 1221,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:90#@"
    },
    unit = "顶",
    equipType = "女帽",
    gender = 2,
    req_level = 90
  },
  ["九霄凤鸣冠"] = {
    icon = 1615,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:100#@"
    },
    unit = "顶",
    equipType = "女帽",
    gender = 2,
    req_level = 100
  },
  ["凌波霞冠"] = {
    icon = 1257,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:110#@"
    },
    unit = "顶",
    equipType = "女帽",
    gender = 2,
    req_level = 110
  },
  ["天灵宝冠"] = {
    icon = 1258,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:120#@"
    },
    unit = "顶",
    equipType = "女帽",
    gender = 2,
    req_level = 120
  },
  ["九彩玲珠冠"] = {
    icon = 1265,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女帽:130#@"
    },
    unit = "顶",
    equipType = "女帽",
    gender = 2,
    req_level = 130
  },
  ["布衣"] = {
    icon = 1222,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 1
  },
  ["虎皮衣"] = {
    icon = 1223,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 10
  },
  ["青铜铠"] = {
    icon = 1224,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 20
  },
  ["皂罗袍"] = {
    icon = 1225,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 30
  },
  ["金锁甲"] = {
    icon = 1226,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 40
  },
  ["莽龙袍"] = {
    icon = 1227,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:50#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 50
  },
  ["金丝甲"] = {
    icon = 1228,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:60#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 60
  },
  ["八卦衣"] = {
    icon = 1229,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:70#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 70
  },
  ["连环甲"] = {
    icon = 1230,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:80#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 80
  },
  ["金缕衣"] = {
    icon = 1231,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:90#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 90
  },
  ["天衣"] = {
    icon = 1232,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:100#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 100
  },
  ["瀚宇法袍"] = {
    icon = 1259,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:110#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 110
  },
  ["诸天法袍"] = {
    icon = 1260,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:120#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 120
  },
  ["天玄真神甲"] = {
    icon = 1267,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:男衣:130#@"
    },
    unit = "件",
    equipType = "男衣",
    gender = 1,
    req_level = 130
  },
  ["布裙"] = {
    icon = 1233,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 1
  },
  ["绛紫裙"] = {
    icon = 1234,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 10
  },
  ["虹羽衣"] = {
    icon = 1235,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 20
  },
  ["凤暖袍"] = {
    icon = 1236,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 30
  },
  ["锦月袄"] = {
    icon = 1237,
    descript = "",
    rescourse = {},
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 40
  },
  ["凝霜衣"] = {
    icon = 1238,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:50#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 50
  },
  ["水合袍"] = {
    icon = 1239,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:60#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 60
  },
  ["狐皮袄"] = {
    icon = 1240,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:70#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 70
  },
  ["蛟皮袄"] = {
    icon = 1241,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:80#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 80
  },
  ["天蚕衣"] = {
    icon = 1242,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:90#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 90
  },
  ["霓裳羽衣"] = {
    icon = 1243,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:100#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 100
  },
  ["星晶法衣"] = {
    icon = 1261,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:110#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 110
  },
  ["神鸢凤裘"] = {
    icon = 1262,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:120#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 120
  },
  ["万霞霓罗裳"] = {
    icon = 1268,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:女衣:130#@"
    },
    unit = "件",
    equipType = "女衣",
    gender = 2,
    req_level = 130
  },
  ["麻鞋"] = {
    icon = 1244,
    descript = "",
    rescourse = {},
    unit = "双",
    equipType = "鞋",
    req_level = 1
  },
  ["布鞋"] = {
    icon = 1245,
    descript = "",
    unit = "双",
    rescourse = {},
    equipType = "鞋",
    req_level = 10
  },
  ["马靴"] = {
    icon = 1246,
    descript = "",
    rescourse = {},
    unit = "双",
    equipType = "鞋",
    req_level = 20
  },
  ["牛皮靴"] = {
    icon = 1247,
    descript = "",
    rescourse = {},
    unit = "双",
    equipType = "鞋",
    req_level = 30
  },
  ["长筒靴"] = {
    icon = 1248,
    descript = "",
    rescourse = {},
    unit = "双",
    equipType = "鞋",
    req_level = 40
  },
  ["追云履"] = {
    icon = 1249,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:50#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 50
  },
  ["亮银靴"] = {
    icon = 1250,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:60#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 60
  },
  ["疾风履"] = {
    icon = 1251,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:70#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 70
  },
  ["无影靴"] = {
    icon = 1252,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:80#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 80
  },
  ["天行履"] = {
    icon = 1253,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:90#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 90
  },
  ["踏云靴"] = {
    icon = 1254,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:100#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 100
  },
  ["御风履"] = {
    icon = 1263,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:110#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 110
  },
  ["钧天履"] = {
    icon = 1264,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:120#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 120
  },
  ["雷弧闪"] = {
    icon = 1269,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备:鞋:130#@"
    },
    unit = "双",
    equipType = "鞋",
    req_level = 130
  },
  ["青珑挂珠"] = {
    icon = 1301,
    descript = "青玉制成的挂坠，佩带后使人神清气爽",
    rescourse = {
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:项链:20#@"
    },
    unit = "串",
    equipType = "饰品",
    pos = 4,
    req_level = 20,
    double_type = 1
  },
  ["紫晶坠子"] = {
    icon = 1302,
    descript = "紫水晶雕成的坠子，佩带后有益气增法之功效",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:项链:35#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 35,
    double_type = 1
  },
  ["三才项圈"] = {
    icon = 1303,
    descript = "道家修法的绝佳物品，具有入定安神之奇效",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:项链:50#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 50,
    double_type = 1
  },
  ["幻彩项链"] = {
    icon = 1304,
    descript = "古拙玄幻的色彩中蕴藏着无尽的法力",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:项链:60#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 60,
    double_type = 1
  },
  ["雪魂丝链"] = {
    icon = 1305,
    descript = "传说中雪魔女被降伏时的眼泪化作的丝链，佩带后可法力大增",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:项链:70#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 70,
    double_type = 1
  },
  ["天机锁链"] = {
    icon = 1306,
    descript = "上古流传下来暗藏无上法力的神秘锁链",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:项链:80#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 80
  },
  ["秘魔灵珠"] = {
    icon = 1307,
    descript = "乃天庭雷部留在人间降魔的灵珠，法力无边",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:项链:90#@"
    },
    unit = "串",
    equipType = "饰品",
    pos = 4,
    req_level = 90
  },
  ["金碧莲花"] = {
    icon = 1308,
    descript = "紫虚府中的奇珍，于修道练法之人有无上裨益",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:项链:100#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 100
  },
  ["流光绝影"] = {
    icon = 1325,
    descript = "此链挂坠为夜明珠所制，入夜之后光芒万丈",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:项链:110#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 110
  },
  ["五蕴悯光"] = {
    icon = 1326,
    descript = "寒玉莲放出五彩霞光，可给人带来无穷的法力",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:项链:120#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 120
  },
  ["千彩流光"] = {
    icon = 1332,
    descript = "万道彩虹凝炼流光，百年露珠始得星珠，珠有千彩，千彩流光",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:项链:130#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 4,
    req_level = 130
  },
  ["纹龙佩"] = {
    icon = 1309,
    descript = "刻有龙纹的玉佩，长期佩带有强身健体之效",
    rescourse = {
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:玉佩:20#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 20,
    double_type = 1
  },
  ["温玉玦"] = {
    icon = 1310,
    descript = "一种由温玉制成的饰物，可以增强体质",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:玉佩:35#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 35,
    double_type = 1
  },
  ["血心石"] = {
    icon = 1311,
    descript = "一种血红色心形石头，可使人气血充沛",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:玉佩:50#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 50,
    double_type = 1
  },
  ["八角晶牌"] = {
    icon = 1312,
    descript = "刻有八卦符文的玉牌，为灵鹫仙人养气之物",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:玉佩:60#@"
    },
    unit = "面",
    equipType = "饰品",
    pos = 5,
    req_level = 60,
    double_type = 1
  },
  ["蟠螭结"] = {
    icon = 1313,
    descript = "圣兽蟠螭所化，魂魄凝聚，生气活血之极品",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:玉佩:70#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 70,
    double_type = 1
  },
  ["七龙珠"] = {
    icon = 1314,
    descript = "上古七条孽龙的元丹炼化而成，精气四溢",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:玉佩:80#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 80
  },
  ["金蝉宝囊"] = {
    icon = 1315,
    descript = "彩蝉翼制成的香囊，佩带后使人延年益寿",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:玉佩:90#@"
    },
    unit = "个",
    equipType = "饰品",
    pos = 5,
    req_level = 90
  },
  ["通灵宝玉"] = {
    icon = 1316,
    descript = "传说中通晓灵性的宝玉，有缘人方可得之",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:玉佩:100#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 100
  },
  ["寒玉龙勾"] = {
    icon = 1327,
    descript = "九天神龙所化，有延年益寿之功效",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:玉佩:110#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 110
  },
  ["八宝如意"] = {
    icon = 1328,
    descript = "传说中，天上的神仙所遗留的如意佩，此法宝法力无穷",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:玉佩:120#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 120
  },
  ["游火灵焰"] = {
    icon = 1331,
    descript = "焰灵像蛇一样飞舞，缠绕在炽热的聚灵晶石上，它的法力源源不断",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:玉佩:130#@"
    },
    unit = "块",
    equipType = "饰品",
    pos = 5,
    req_level = 130
  },
  ["金刚手镯"] = {
    icon = 1317,
    descript = "奇异的手镯，泛着金光，佩带后杀伤力陡增",
    rescourse = {
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:手镯:20#@"
    },
    unit = "个",
    equipType = "饰品",
    pos = 6,
    req_level = 20,
    double_type = 1
  },
  ["七星手链"] = {
    icon = 1318,
    descript = "暗藏北斗七星之势，可令对手未战而先寒",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:手镯:35#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 6,
    req_level = 35,
    double_type = 1
  },
  ["凤舞环"] = {
    icon = 1319,
    descript = "犹如彩凤翻飞，能迷惑对手心神而攻其不备",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:手镯:50#@"
    },
    unit = "个",
    equipType = "饰品",
    pos = 6,
    req_level = 50,
    double_type = 1
  },
  ["龙鳞手镯"] = {
    icon = 1320,
    descript = "用青龙之鳞炼化而成，佩带者锐不可挡",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:手镯:60#@"
    },
    unit = "个",
    equipType = "饰品",
    pos = 6,
    req_level = 60,
    double_type = 1
  },
  ["法文手轮"] = {
    icon = 1321,
    descript = "闪现奇异符咒的手镯，能够产生奇特的力量而令对手防不胜防",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=低级首饰:手镯:70#@"
    },
    unit = "个",
    equipType = "饰品",
    req_level = 70,
    double_type = 1
  },
  ["闭月双环"] = {
    icon = 1322,
    descript = "清柔雅致的光环舞动起来光影漫漫，令对方眼花缭乱，暗藏杀机",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:手镯:80#@"
    },
    unit = "个",
    equipType = "饰品",
    pos = 6,
    req_level = 80
  },
  ["三清手镯"] = {
    icon = 1323,
    descript = "道家无上法宝，所蕴藏的法力威力无穷",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:手镯:90#@"
    },
    unit = "个",
    equipType = "饰品",
    pos = 6,
    req_level = 90
  },
  ["天星奇光"] = {
    icon = 1324,
    descript = "若隐若现的星光看似平淡无奇，飘闪的寒芒却可造成致命的一击",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:手镯:100#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 6,
    req_level = 100
  },
  ["碎梦涵光"] = {
    icon = 1329,
    descript = "传说中，仙女所遗留的法宝，此物内藏强大的法力，功效无穷",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:手镯:110#@"
    },
    unit = "个",
    equipType = "饰品",
    pos = 6,
    req_level = 110
  },
  ["九天霜华"] = {
    icon = 1330,
    descript = "由九天之外霜露凝结而制，神光内敛，无形中散发出致命的气息",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:手镯:120#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 6,
    req_level = 120
  },
  ["岚金火链"] = {
    icon = 1333,
    descript = "灵气四溢的金色流火，如有灵性般摇曳盈动",
    rescourse = {
      "#@首饰合成|JewelryUpgradeDlg#@",
      "#@集市逛摊|MarketBuyDlg=高级首饰:手镯:130#@"
    },
    unit = "条",
    equipType = "饰品",
    pos = 6,
    req_level = 130
  },
  ["定海珠"] = {
    icon = 1409,
    descript = "珠有二十四颗，攒成一串，谓之“定海珠”。此珠后来兴于释门，化为二十四诸天",
    rescourse = {
      "#@法宝任务|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=法宝:定海珠:金相性#@"
    },
    unit = "串",
    equipType = "法宝",
    pos = 9,
    req_level = 90
  },
  ["混元金斗"] = {
    icon = 1410,
    descript = "内按三才，包藏天地之妙，因果不知，劫数不显，神通不明",
    rescourse = {
      "#@法宝任务|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=法宝:混元金斗:金相性#@"
    },
    unit = "个",
    equipType = "法宝",
    pos = 9,
    req_level = 100
  },
  ["金蛟剪"] = {
    icon = 1411,
    descript = "两条蛟龙，采天地灵气，受日月精华，起在空中，往来上下，祥云护体。头并头如剪，一剪两段",
    rescourse = {
      "#@法宝任务|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=法宝:金蛟剪:金相性#@"
    },
    unit = "把",
    equipType = "法宝",
    pos = 9,
    req_level = 100
  },
  ["阴阳镜"] = {
    icon = 1412,
    descript = "此镜半边白半边红，白的一晃是死路，红的一晃是生门",
    rescourse = {
      "#@法宝任务|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=法宝:阴阳镜:金相性#@"
    },
    unit = "面",
    equipType = "法宝",
    pos = 9,
    req_level = 100
  },
  ["卸甲金葫"] = {
    icon = 1413,
    descript = "借力使力，化敌方戾气于无形，虽无上天入地之功，却有卸甲去势之力",
    rescourse = {
      "#@法宝任务|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=法宝:卸甲金葫:金相性#@"
    },
    unit = "个",
    equipType = "法宝",
    pos = 9,
    req_level = 100
  },
  ["九龙神火罩"] = {
    icon = 1414,
    descript = "仙家法宝，施展之时罩内腾腾焰起，烈烈火生，有九条火龙盘绕",
    rescourse = {
      "#@法宝任务|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=法宝:九龙神火罩:金相性#@"
    },
    unit = "个",
    equipType = "法宝",
    pos = 9,
    req_level = 90
  },
  ["番天印"] = {
    icon = 1415,
    descript = "玉虚至宝番天印，晃一晃地动山摇，颠一颠山呼海啸",
    rescourse = {
      "#@法宝任务|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=法宝:番天印:金相性#@"
    },
    unit = "个",
    equipType = "法宝",
    pos = 9,
    req_level = 90
  },
  ["超级归元露"] = {
    icon = 9006,
    descript = "神奇的仙家药物，可用于洗炼宝宝宠物基础成长及天生技能；也可将野生宠物洗炼为宝宝宠物",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级归元露#@",
      "#@每日签到|DailySignDlg#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:超级归元露#@"
    },
    unit = "瓶",
    coin = 216,
    double_type = 1,
    color = "金色"
  },
  ["天星石"] = {
    icon = 9180,
    descript = "能激活装备灵性，使装备可以进化成长的天下至宝",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备道具:天星石#@",
      "#P北斗星使|北斗星使E=购买天星石#P"
    },
    unit = "块",
    apply = "EquipmentEvolveDlg",
    use_level = 70,
    level_tip = "角色等级达到#R70级#n后开放该功能。",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    color = "金色"
  },
  ["宠物强化丹"] = {
    icon = 9008,
    descript = "神奇的仙家药物，宝宝使用后可以强化物攻和法攻成长，不会改变宝宝的等级、天技等级、人宠亲密度",
    rescourse = {
      "#@在线商城|OnlineMallDlg=宠物强化丹#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:宠物强化丹#@"
    },
    unit = "颗",
    coin = 518,
    apply = "PetAttribDlg",
    double_type = 1,
    color = "金色"
  },
  ["血池"] = {
    icon = 9012,
    descript = "使用后可以一次性增加300,000的气血储备，战斗结束后自动补满角色及宠物所耗费的气血",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=血池#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=血池#Z",
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=血池#Z",
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=血池#Z",
      "#@活跃奖励|ActivitiesDlg#@"
    },
    unit = "个"
  },
  ["灵池"] = {
    icon = 9013,
    descript = "使用后可以一次性增加300,000的法力储备，战斗结束后自动补满角色及宠物所耗费的法力",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=灵池#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=灵池#Z",
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=灵池#Z",
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=灵池#Z",
      "#@活跃奖励|ActivitiesDlg#@"
    },
    unit = "个"
  },
  ["超级灵石"] = {
    icon = 9021,
    descript = "可以用来改造武器并提升武器改造属性加成的超级宝石",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级灵石#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "藏宝图",
      "挑战巨兽",
      "#@铲除妖王|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:超级灵石#@"
    },
    unit = "块",
    apply = "EquipmentUpgradeDlg",
    coin = 398,
    use_level = 40,
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R40级#n后开放该功能。",
    color = "金色"
  },
  ["超级晶石"] = {
    icon = 9022,
    descript = "可以用来改造防具并提升防具改造属性加成的超级宝石",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级晶石#@",
      "#@每日签到|DailySignDlg#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "藏宝图",
      "挑战巨兽",
      "#@铲除妖王|ActivitiesDlg=其它活动#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:超级晶石#@"
    },
    unit = "块",
    coin = 108,
    apply = "EquipmentUpgradeDlg",
    use_level = 40,
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R40级#n后开放该功能。",
    color = "金色"
  },
  ["驯兽诀"] = {
    icon = 9026,
    descript = "使用后可以一次性增加300的忠诚储备，战斗结束后自动补满宠物所耗费的忠诚",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=驯兽诀#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=驯兽诀#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=驯兽诀#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=驯兽诀#Z"
    },
    unit = "本"
  },
  ["特级藏宝图"] = {
    icon = 8079,
    descript = "记载了比超级藏宝图更加珍贵的宝藏，使用后不仅有一定几率获得更多金钱、数枚召唤令·十二生肖，更有5倍几率获得十二生肖变异宠",
    rescourse = {
      "#@在线商城|OnlineMallDlg=特级藏宝图#@",
      "#@合成|AlchemyDlg=特级藏宝图#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:各类藏宝图:特级藏宝图#@"
    },
    unit = "张",
    coin = 100,
    use_level = 30,
    level_tip = "以你现在的能力还无法知晓特级藏宝图的秘密，#R30级#n以后再来寻宝吧。",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    color = "金色"
  },
  ["超级藏宝图"] = {
    icon = 9029,
    descript = "传说中记载了超级宝藏埋藏点的地图，使用超级藏宝图不仅有一定几率能获得大量金钱，更有可能获得召唤令·十二生肖甚至十二生肖变异宠",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级藏宝图#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:各类藏宝图:超级藏宝图#@"
    },
    unit = "张",
    coin = 100,
    use_level = 30,
    level_tip = "以你现在的能力还无法知晓超级藏宝图的秘密，#R30级#n以后再来寻宝吧。",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    color = "金色"
  },
  ["藏宝图"] = {
    icon = 1514,
    descript = "传说中记载了宝藏埋藏点的地图，使用藏宝图不仅能有一定几率获得金钱奖励，更有可能获得首饰、超级归元露甚至强化材料等珍贵道具",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:各类藏宝图:藏宝图#@",
      "#@海盗入侵|ActivitiesDlg=限时活动#@",
      "#@铲除妖王|ActivitiesDlg=其它活动#@"
    },
    unit = "张",
    double_type = 0,
    use_level = 20,
    level_tip = "以你现在的能力还无法知晓藏宝图的秘密，#R20级#n以后再来寻宝吧。",
    try_level_tip = "适用等级：大于等于%d级",
    color = "金色"
  },
  ["超级黑水晶"] = {
    icon = 9040,
    descript = "能够拆分装备附加属性的神奇水晶",
    attdescript = "已吸附装备附加属性的超级黑水晶，可以用于进行装备炼化",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级黑水晶#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:超级黑水晶#@"
    },
    hasAttrRscourse = {
      "#@集市逛摊|MarketBuyDlg=超级黑水晶#@",
      "#@拍卖|MarketAuctionDlg#@",
      "#@装备拆分|EquipmentSplitDlg#@"
    },
    unit = "颗",
    coin = 328,
    use_level = 50,
    apply = "EquipmentRefiningDlg",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R50级#n后开放该功能。",
    color = "金色"
  },
  ["血玲珑"] = {
    icon = 9050,
    descript = "存储了4,000,000气血的神奇道具，仅限战斗中使用，目标等级<120，气血每次最多恢复39000+最大气血的10%点；目标等级>=120，气血每次最多恢复50000+最大气血的20%点",
    rescourse = {
      "#@在线商城|OnlineMallDlg=血玲珑#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=血玲珑#P",
      "#@集市逛摊|MarketBuyDlg=其他道具:玲珑药品:血玲珑#@"
    },
    unit = "颗",
    coin = 216,
    double_type = 2,
    max_expend = 4000000,
    color = "金色"
  },
  ["法玲珑"] = {
    icon = 9051,
    descript = "存储了4,000,000法力的神奇道具，仅限战斗中使用，目标等级<120，法力每次最多恢复26000+最大法力的10%点；目标等级>=120，法力每次最多恢复30000+最大法力的20%点",
    rescourse = {
      "#@在线商城|OnlineMallDlg=法玲珑#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=法玲珑#P",
      "#@集市逛摊|MarketBuyDlg=其他道具:玲珑药品:法玲珑#@"
    },
    unit = "颗",
    coin = 618,
    double_type = 2,
    max_expend = 4000000,
    color = "金色"
  },
  ["超级神兽丹"] = {
    icon = 9065,
    descript = "一次性恢复宠物5000点寿命并能增加2000点宠物亲密度的灵药",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级神兽丹#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:超级神兽丹#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=超级神兽丹#P"
    },
    unit = "颗",
    coin = 108,
    double_type = 1,
    color = "金色"
  },
  ["黄水晶"] = {
    icon = 9066,
    descript = "能够增加装备灵性，炼化装备黄属性的神奇水晶",
    rescourse = {
      "#@在线商城|OnlineMallDlg=黄水晶#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:黄水晶#@"
    },
    apply = "EquipmentRefiningDlg",
    unit = "颗",
    coin = 418,
    use_level = 65,
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R65级#n后开放该功能。",
    color = "金色"
  },
  ["天书"] = {
    icon = 9068,
    descript = "上古奇书，得知其中任何一页散卷即可受益无穷（使用天书后可随机掉落两本天书散卷，宠物使用散卷后可以拥有相应的技能）",
    rescourse = {
      "#@在线商城|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:天书#@"
    },
    unit = "册",
    coin = 318,
    double_type = 1,
    color = "金色"
  },
  ["魔引"] = {
    icon = 9319,
    descript = "天书散落之物，记载了魔引技能的卷本，魔引：物理攻击命中对手的时候，有一定几率造成被攻击方的法力消耗",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:魔引#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["狂暴"] = {
    icon = 9320,
    descript = "天书散落之物，记载了狂暴技能的卷本，狂暴：物理攻击命中对手的时候，有一定几率使被攻击方周围的几个目标同时受到真实伤害",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:狂暴#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["怒击"] = {
    icon = 9328,
    descript = "天书散落之物，记载了怒击技能的卷本，怒击：使用法术攻击命中对方时，有一定几率使法术攻击力增强",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:怒击#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["破天"] = {
    icon = 9326,
    descript = "天书散落之物，记载了破天技能的卷本，破天：使用物理或法术攻击命中对方时，有一定几率破防",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:破天#@"
    },
    unit = "卷",
    color = "金色",
    max_expend = 6000,
    double_type = 1
  },
  ["反击"] = {
    icon = 9327,
    descript = "天书散落之物，记载了反击技能的卷本，反击：受到物理攻击时，有一定几率物理反击",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:反击#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["降魔斩"] = {
    icon = 9329,
    descript = "天书散落之物，记载了降魔斩技能的卷本，降魔斩：使用法术攻击命中对方时，有一定几率忽视对方的法术抗性",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:降魔斩#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["修罗术"] = {
    icon = 9330,
    descript = "天书散落之物，记载了修罗术技能的卷本，修罗术：使用法术攻击对方时，有一定几率出现连击效果",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:修罗术#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["尽忠"] = {
    icon = 9333,
    descript = "天书散落之物，记载了尽忠技能的卷本，尽忠：宠物在受到忠诚度降低操作时有几率按照一定百分比降低被减少的忠诚度",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:尽忠#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["云体"] = {
    icon = 9331,
    descript = "天书散落之物，记载了云体技能的卷本，云体：宠物作为主目标受到物理必杀攻击时有一定几率触发此效果，该效果触发后，必杀只对该宠物造成普通物理伤害",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:云体#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["仙风"] = {
    icon = 9332,
    descript = "天书散落之物，记载了仙风技能的卷本，仙风：宠物在受到物理连击时有一定几率只受到普通攻击的伤害，闪避后续的所有连击伤害",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:仙风#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["惊雷"] = {
    icon = 9322,
    descript = "天书散落之物，记载了惊雷技能的卷本，惊雷：物理攻击命中对手时，有几率附加金系法术伤害（会以宠物法伤或物伤的较高值进行伤害计算），该附加伤害不受五色光环、如意圈影响，但会受到乾坤罩、神龙罩影响，可同时触发物理必杀、物理连击",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:惊雷#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["青木"] = {
    icon = 9323,
    descript = "天书散落之物，记载了青木技能的卷本，青木：物理攻击命中对手时，有几率附加木系法术伤害（会以宠物法伤或物伤的较高值进行伤害计算），该附加伤害不受五色光环、如意圈影响，但会受到乾坤罩、神龙罩影响，可同时触发物理必杀、物理连击",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:青木#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["寒冰"] = {
    icon = 9325,
    descript = "天书散落之物，记载了寒冰技能的卷本，寒冰：物理攻击命中对手时，有几率附加水系法术伤害（会以宠物法伤或物伤的较高值进行伤害计算），该附加伤害不受五色光环、如意圈影响，但会受到乾坤罩、神龙罩影响，可同时触发物理必杀、物理连击",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:寒冰#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["烈炎"] = {
    icon = 9321,
    descript = "天书散落之物，记载了烈炎技能的卷本，烈炎：物理攻击命中对手时，有几率附加火系法术伤害（会以宠物法伤或物伤的较高值进行伤害计算），该附加伤害不受五色光环、如意圈影响，但会受到乾坤罩、神龙罩影响，可同时触发物理必杀、物理连击",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:烈炎#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["碎石"] = {
    icon = 9324,
    descript = "天书散落之物，记载了碎石技能的卷本，碎石：物理攻击命中对手时，有几率附加土系法术伤害（会以宠物法伤或物伤的较高值进行伤害计算），该附加伤害不受五色光环、如意圈影响，但会受到乾坤罩、神龙罩影响，可同时触发物理必杀、物理连击",
    rescourse = {
      "#@天书|OnlineMallDlg=天书#@",
      "#@集市逛摊|MarketBuyDlg=天书:碎石#@"
    },
    unit = "卷",
    double_type = 1,
    color = "金色",
    max_expend = 6000
  },
  ["高级血池"] = {
    icon = 9070,
    descript = "使用后可以一次性增加7,500,000的气血储备，战斗结束后自动补满角色及宠物所耗费的气血",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=高级血池#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=高级血池#Z",
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=高级血池#Z",
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=高级血池#Z"
    },
    unit = "个"
  },
  ["高级灵池"] = {
    icon = 9071,
    descript = "使用后可以一次性增加7,500,000的法力储备，战斗结束后自动补满角色及宠物所耗费的法力",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=高级灵池#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=高级灵池#Z",
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=高级灵池#Z",
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=高级灵池#Z"
    },
    unit = "个"
  },
  ["高级血玲珑"] = {
    icon = 9073,
    descript = "存储了20,000,000气血的神奇道具，仅限战斗中使用，目标等级<120，气血每次最多恢复39000+最大气血的10%点；目标等级>=120，气血每次最多恢复50000+最大气血的20%点",
    rescourse = {
      "#@在线商城|OnlineMallDlg=高级血玲珑#@"
    },
    unit = "颗",
    double_type = 2,
    coin = 800,
    max_expend = 20000000,
    color = "金色"
  },
  ["高级法玲珑"] = {
    icon = 9074,
    descript = "存储了20,000,000法力的神奇道具，仅限战斗中使用，目标等级<120，法力每次最多恢复26000+最大法力的10%点；目标等级>=120，法力每次最多恢复30000+最大法力的20%点",
    rescourse = {
      "#@在线商城|OnlineMallDlg=高级法玲珑#@"
    },
    unit = "颗",
    double_type = 2,
    coin = 2400,
    max_expend = 20000000,
    color = "金色"
  },
  ["无量心经"] = {
    icon = 9076,
    descript = "用来记录修炼过程中各种心得体会的经卷。记录完成以后会生成一本一定等级的对应心得：经验心得或道武心得。生成的经验心得最高等级为100级",
    rescourse = {
      "#@在线商城|OnlineMallDlg=无量心经#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:无量心经#@"
    },
    use_level = 70,
    level_tip = "角色等级达到#R70级#n后才能使用。",
    unit = "本",
    apply = "WulxjApplyDlg",
    try_level_tip = "适用等级：大于等于%d级",
    double_type = 1,
    coin = 100,
    color = "金色"
  },
  ["元气丹"] = {
    icon = 9090,
    descript = "神奇的仙家药物，守护使用后可激发潜能，大大增加守护能力",
    rescourse = {
      "#@帮派商店|PartyShopDlg=元气丹#@",
      "#P声望商店|竞技使者|M=声望商店::ArenaStoreDlg=元气丹#P"
    },
    unit = "颗",
    use_level = 55,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R55级#n后开放该功能。",
    color = "金色"
  },
  ["高级驯兽诀"] = {
    icon = 9104,
    descript = "使用后可以一次性增加2,500的忠诚储备，战斗结束后自动补满宠物所耗费的忠诚",
    rescourse = {
      "#@在线商城|OnlineMallDlg=高级驯兽诀#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:高级驯兽诀#@"
    },
    unit = "本",
    coin = 800,
    double_type = 1,
    color = "金色"
  },
  ["中级血池"] = {
    icon = 9119,
    descript = "使用后可以一次性增加1,500,000的气血储备，战斗结束后自动补满角色及宠物所耗费的气血",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=中级血池#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=中级血池#Z",
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=中级血池#Z",
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=中级血池#Z"
    },
    unit = "个"
  },
  ["中级灵池"] = {
    icon = 9120,
    descript = "使用后可以一次性增加1,500,000的法力储备，战斗结束后自动补满角色及宠物所耗费的法力",
    rescourse = {
      "#Z万全药铺|::王老板|$0|M=买卖::PharmacyDlg=中级灵池#Z",
      "#Z回春堂药铺|::杜卜思|$0|M=买卖::PharmacyDlg=中级灵池#Z",
      "#Z东海药铺|::药店老板|$0|M=买卖::PharmacyDlg=中级灵池#Z",
      "#Z无名药铺|::无名药铺老板|$0|M=买卖::PharmacyDlg=中级灵池#Z"
    },
    unit = "个"
  },
  ["中级血玲珑"] = {
    icon = 9121,
    descript = "存储了10,000,000气血的神奇道具，仅限战斗中使用，目标等级<120，气血每次最多恢复39000+最大气血的10%点；目标等级>=120，气血每次最多恢复50000+最大气血的20%点",
    rescourse = {
      "#@在线商城|OnlineMallDlg=中级血玲珑#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:玲珑药品:中级血玲珑#@"
    },
    unit = "颗",
    coin = 418,
    double_type = 2,
    max_expend = 10000000,
    color = "金色"
  },
  ["中级法玲珑"] = {
    icon = 9122,
    descript = "存储了10,000,000法力的神奇道具，仅限战斗中使用，目标等级<120，法力每次最多恢复26000+最大法力的10%点；目标等级>=120，法力每次最多恢复30000+最大法力的20%点",
    rescourse = {
      "#@在线商城|OnlineMallDlg=中级法玲珑#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:玲珑药品:中级法玲珑#@"
    },
    unit = "颗",
    coin = 1400,
    double_type = 2,
    max_expend = 10000000,
    color = "金色"
  },
  ["凝香幻彩"] = {
    icon = 1560,
    descript = "相传为彩霞遗落人间之物，对宠物可活其血，肉其骨。其色殷红，其形隐约，汩汩而似闻其声，清脆如冰碎",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=凝香幻彩#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=凝香幻彩#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=凝香幻彩#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=凝香幻彩#Z",
      "#@合成|AlchemyDlg=凝香幻彩#@",
      "#@集市逛摊|MarketBuyDlg=妖石:凝香幻彩#@"
    },
    unit = "块",
    use_level = Const.PET_STONE_OPEN_LEVEL,
    level_tip = "角色等级达到#R30级#n后开放该功能。",
    color = "金色"
  },
  ["枯月流魂"] = {
    icon = 1561,
    descript = "九华池内天水成其形，封印戾魂之物，不周山之战时其神被化而为石。石中杀气溶于宠物后即可所向披靡",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=枯月流魂#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=枯月流魂#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=枯月流魂#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=枯月流魂#Z",
      "#@合成|AlchemyDlg=枯月流魂#@",
      "#@集市逛摊|MarketBuyDlg=妖石:枯月流魂#@"
    },
    unit = "块",
    use_level = Const.PET_STONE_OPEN_LEVEL,
    level_tip = "角色等级达到#R30级#n后开放该功能。",
    color = "金色"
  },
  ["风寂云清"] = {
    icon = 1562,
    descript = "远古时天水相接处，有大神持斧而破。轻者却未能上浮成云，后游荡于空灵，滴水成石。此石可护主，使其临险境而无忧",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=风寂云清#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=风寂云清#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=风寂云清#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=风寂云清#Z",
      "#@合成|AlchemyDlg=风寂云清#@",
      "#@集市逛摊|MarketBuyDlg=妖石:风寂云清#@"
    },
    unit = "块",
    use_level = Const.PET_STONE_OPEN_LEVEL,
    level_tip = "角色等级达到#R30级#n后开放该功能。",
    color = "金色"
  },
  ["炫影霜星"] = {
    icon = 1563,
    descript = "尝有燧人氏取火时，火中跳出一虚幻之貌。女娲娘娘以五昧神火炼之成石。其间灵气若霜降流星，可助宠物行速如风",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=炫影霜星#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=炫影霜星#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=炫影霜星#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=炫影霜星#Z",
      "#@合成|AlchemyDlg=炫影霜星#@",
      "#@集市逛摊|MarketBuyDlg=妖石:炫影霜星#@"
    },
    unit = "块",
    use_level = Const.PET_STONE_OPEN_LEVEL,
    level_tip = "角色等级达到#R30级#n后开放该功能。",
    color = "金色"
  },
  ["雷极弧光"] = {
    icon = 1564,
    descript = "九天雷池锤炼凝聚之物，漂浮于霄汉，遇尘聚石坠落人间。宠物得之后即可战无不胜",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=雷极弧光#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=雷极弧光#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=雷极弧光#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=雷极弧光#Z",
      "#@合成|AlchemyDlg=雷极弧光#@",
      "#@集市逛摊|MarketBuyDlg=妖石:雷极弧光#@"
    },
    unit = "块",
    use_level = Const.PET_STONE_OPEN_LEVEL,
    level_tip = "角色等级达到#R30级#n后开放该功能。",
    color = "金色"
  },
  ["冰落残阳"] = {
    icon = 1566,
    descript = "终日受夕阳普照的北极寒冰，经岁月锤炼而破，月圆之夜落地成石。灵气氤氲、法力充沛",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=冰落残阳#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=冰落残阳#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=冰落残阳#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=冰落残阳#Z",
      "#@合成|AlchemyDlg=冰落残阳#@",
      "#@集市逛摊|MarketBuyDlg=妖石:冰落残阳#@"
    },
    unit = "块",
    use_level = Const.PET_STONE_OPEN_LEVEL,
    level_tip = "角色等级达到#R30级#n后开放该功能。",
    color = "金色"
  },
  ["超级女娲石"] = {
    icon = 1716,
    descript = "女娲补天遗留之石聚合而成的精华，用于合成首饰时有很高几率成功 ",
    rescourse = {
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@帮派任务|ActivitiesDlg=日常活动#@",
      "#@帮派日常挑战|ActivitiesDlg=日常活动#@",
      "#@八仙梦境|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:超级女娲石#@"
    },
    apply = "JewelryUpgradeDlg",
    unit = "块",
    use_level = 35,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R35级#n后开放该功能。",
    double_type = 1,
    color = "金色"
  },
  ["宠物经验丹"] = {
    icon = 1841,
    descript = "非野生宠物使用后将获得大量经验奖励",
    rescourse = {
      "放生非野生宠物",
      "#P声望商店|竞技使者|M=声望商店::ArenaStoreDlg=宠物经验丹#P",
      "#@帮派商店|PartyShopDlg=宠物经验丹#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:宠物经验丹:宠物经验丹#@"
    },
    unit = "颗",
    apply = "PetAttribDlg",
    use_level = 40,
    try_level_tip = "适用等级：角色大于等于%d级",
    level_tip = "角色等级达到#R40级#n后开放该功能。"
  },
  ["宠物顿悟丹"] = {
    icon = 9219,
    descript = "聚三清之气，开万物灵智，乃道家至宝。用于学习与遗忘宠物顿悟技能，也可用于补充宠物顿悟技能灵气",
    rescourse = {
      "#@在线商城|OnlineMallDlg=宠物顿悟丹#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:宠物顿悟丹#@"
    },
    unit = "颗",
    double_type = 1,
    coin = 100,
    color = "金色"
  },
  ["神兽丹"] = {
    icon = 7102,
    descript = "恢复宠物500点寿命的神奇丹药",
    rescourse = {
      "#P声望商店|竞技使者|M=声望商店::ArenaStoreDlg=神兽丹#P",
      "#@帮派商店|PartyShopDlg=神兽丹#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:神兽丹#@"
    },
    unit = "颗"
  },
  ["天技秘笈散卷"] = {
    icon = 8077,
    descript = "",
    rescourse = {},
    unit = "份"
  },
  ["翻转乾坤秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到翻转乾坤技能的神秘典籍。翻转乾坤：可在几回合内，使敌对方1个对象的相性全部改变，改变相性随机",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:翻转乾坤秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon311.png",
    color = "金色"
  },
  ["神圣之光秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到神圣之光技能的神秘典籍。神圣之光：可以使敌方人员的特殊状态消失（乾坤罩、神龙罩、如意圈等，对障碍性法术所带来的效果无效）",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:神圣之光秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon318.png",
    color = "金色"
  },
  ["死亡缠绵秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到死亡缠绵技能的神秘典籍。死亡缠绵：被施法者使用普通攻击时，可以以连击的方式攻击敌人",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:死亡缠绵秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon320.png",
    color = "金色"
  },
  ["游说之舌秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到游说之舌技能的神秘典籍。游说之舌：有效回合内临时降低敌方的战斗能力，包括：攻击、防御、速度，也可以使被使用的宠物的忠诚降低",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:游说之舌秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon322.png",
    color = "金色"
  },
  ["漫天血舞秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到漫天血舞技能的神秘典籍。漫天血舞：被法术击中目标的HP值会有一定量被施法者吸收，以补充施法者的HP，被施法者减少相应的HP值",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:漫天血舞秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon313.png",
    color = "金色"
  },
  ["舍命一击秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到舍命一击技能的神秘典籍。舍命一击：被法术击中目标的MP相应下降，而施法者的HP值降为1",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:舍命一击秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon316.png",
    color = "金色"
  },
  ["乾坤罩秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到乾坤罩技能的神秘典籍。乾坤罩：被施法者被法术罩住，反弹对方物理攻击一次",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:乾坤罩秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon314.png",
    color = "金色"
  },
  ["神龙罩秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到神龙罩技能的神秘典籍。神龙罩：被施法者在几次物理攻击内被法术罩住，可使被施法者吸收一定量对方的物理攻击伤害",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:神龙罩秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon317.png",
    color = "金色"
  },
  ["如意圈秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到如意圈技能的神秘典籍。如意圈：被施法者在几次魔法攻击内被法术罩住，可使被施法者吸收一定量对方的法术攻击伤害",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:如意圈秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon315.png",
    color = "金色"
  },
  ["十万火急秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到十万火急技能的神秘典籍。十万火急：被施法者的速度在几回合内提升",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:十万火急秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon319.png",
    color = "金色"
  },
  ["天生神力秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到天生神力技能的神秘典籍。天生神力：被施法者的攻击力在几回合内提高",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:天生神力秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon321.png",
    color = "金色"
  },
  ["鞭长莫及秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到鞭长莫及技能的神秘典籍。鞭长莫及：被施法者的躲闪率在几回合内提升",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:鞭长莫及秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon310.png",
    color = "金色"
  },
  ["拔苗助长秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到拔苗助长技能的神秘典籍。拔苗助长：被施法者的气血值在几回合内提升，且具有复活效果",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:拔苗助长秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon309.png",
    color = "金色"
  },
  ["防微杜渐秘笈"] = {
    icon = 8057,
    double_type = 1,
    descript = "可以让宠物领悟到防微杜渐技能的神秘典籍。防微杜渐：被施法者的防御力在几回合内提升，同时略微提升抗障碍能力",
    rescourse = {
      "#P秘笈宝袋|屠娇娇|M=我要兑换天技秘笈#P",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:防微杜渐秘笈#@"
    },
    unit = "本",
    artName = "ui/Icon312.png",
    color = "金色"
  },
  ["守护成长丹"] = {
    icon = 9182,
    descript = "神奇的仙家药物，守护使用后有较大概率提升属性效果 ",
    rescourse = {},
    unit = "颗",
    use_level = 45
  },
  ["超级绿水晶"] = {
    icon = 9077,
    descript = "能够增加装备灵性，炼化装备套装属性的神奇水晶",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级绿水晶#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:超级绿水晶#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=超级绿水晶#P"
    },
    unit = "颗",
    coin = 1000,
    use_level = 70,
    apply = "EquipmentRefiningSuitDlg",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    isCanMail = true,
    level_tip = "角色等级达到#R70级#n后开放该功能。",
    color = "金色"
  },
  ["召唤令·梅兰竹菊"] = {
    icon = 1801,
    descript = "封印了变异宠物精魂的神奇令牌，集齐100个可去找屠娇娇兑换梅兰竹菊变异宠物",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=宠物道具:召唤令·梅兰竹菊#@"
    },
    unit = "枚",
    color = "金色"
  },
  ["召唤令·十二生肖"] = {
    icon = 1800,
    descript = "封印了变异宠物精魂的神奇令牌，集齐100个可去找屠娇娇兑换十二生肖变异宠物",
    rescourse = {
      "#@超级藏宝图|OnlineMallDlg=超级藏宝图#@",
      "#@试道大会|ActivitiesDlg=限时活动#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:召唤令·十二生肖#@"
    },
    unit = "枚",
    color = "金色"
  },
  ["召唤令·上古神兽"] = {
    icon = 2006,
    descript = "封印了神兽宠物精魂的神奇令牌，集齐100个可去找屠娇娇兑换上古神兽宠物 ",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=宠物道具:召唤令·上古神兽#@"
    },
    unit = "枚",
    color = "金色"
  },
  ["火眼金睛"] = {
    icon = 9031,
    descript = "使用后在战斗中可显示怪物气血并持续5回合，可使用10次",
    rescourse = {
      "#@在线商城|OnlineMallDlg=火眼金睛#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=火眼金睛#P",
      "#@集市逛摊|MarketBuyDlg=其他道具:火眼金睛#@"
    },
    unit = "个",
    double_type = 2,
    coin = 216,
    color = "金色"
  },
  ["大力丸"] = {
    icon = 1029,
    descript = "江湖郎中售卖的药品，质量参差不齐，药效未知",
    rescourse = {}
  },
  ["传家宝"] = {
    icon = 1779,
    descript = "这件物品形状和颜色很奇怪，不知道是件什么东西",
    rescourse = {
      "#@师门任务|ActivitiesDlg=日常活动#@"
    },
    unit = "件"
  },
  ["猴毛"] = {
    icon = 1613,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["狗耳朵"] = {
    icon = 1616,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["桃枝"] = {
    icon = 1617,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["柳根"] = {
    icon = 1620,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["白猿眼睛"] = {
    icon = 1621,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["虎耳"] = {
    icon = 1624,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["鹰眼"] = {
    icon = 1625,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["僵尸头骨"] = {
    icon = 1628,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["蝙蝠翅膀"] = {
    icon = 1630,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["鱼尾"] = {
    icon = 1632,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["鱼眼睛"] = {
    icon = 1634,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["龟趾"] = {
    icon = 1636,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["狼眼"] = {
    icon = 1637,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["狼头"] = {
    icon = 1638,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["狼尾"] = {
    icon = 1639,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["蟒尾"] = {
    icon = 1641,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["蟒皮"] = {
    icon = 1642,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["花妖刺"] = {
    icon = 1645,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["火鸦爪"] = {
    icon = 1648,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["火鸦嘴"] = {
    icon = 1649,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["地裂兽牙齿"] = {
    icon = 1650,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["巨蜥眼睛"] = {
    icon = 1653,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["乌龙筋"] = {
    icon = 1655,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["炎龙筋"] = {
    icon = 1657,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["冰龙筋"] = {
    icon = 1659,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["青龙筋"] = {
    icon = 1661,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["黄龙筋"] = {
    icon = 1663,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["石魔掌"] = {
    icon = 1674,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["石料"] = {
    icon = 1677,
    descript = "完成某些任务所需物品。",
    rescourse = {
      "#@帮派任务|ActivitiesDlg=日常活动#@"
    }
  },
  ["石板"] = {
    icon = 1678,
    descript = "完成某些任务所需物品。",
    rescourse = {
      "#@帮派任务|ActivitiesDlg=日常活动#@"
    }
  },
  ["石块"] = {
    icon = 1679,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["木材"] = {
    icon = 1680,
    descript = "完成某些任务所需物品。",
    rescourse = {
      "#@帮派任务|ActivitiesDlg=日常活动#@"
    }
  },
  ["木板"] = {
    icon = 1681,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["木料"] = {
    icon = 1682,
    descript = "完成某些任务所需物品。",
    rescourse = {}
  },
  ["木块"] = {
    icon = 1683,
    descript = "完成某些任务所需物品。",
    rescourse = {
      "#@帮派任务|ActivitiesDlg=日常活动#@"
    }
  },
  ["金钱"] = {
    icon = 1002,
    descript = "金钱是中洲世界通用货币，可用于购买普通物品。可获得%d文钱",
    rescourse = {
      "#@除暴任务|ActivitiesDlg=日常活动#@",
      "#@修行|ActivitiesDlg=日常活动#@",
      "#@十绝阵|ActivitiesDlg=日常活动#@",
      "#@镖行万里|ActivitiesDlg=限时活动#@",
      "#@海盗入侵|ActivitiesDlg=限时活动#@",
      "#@超级藏宝图|OnlineMallDlg=超级藏宝图#@",
      "#@特级藏宝图|OnlineMallDlg=特级藏宝图#@",
      "#@商城购买|OnlineMallExchangeMoneyDlg#@",
      "#@珍宝购买|MarketGoldBuyDlg=金钱#@"
    }
  },
  ["银元宝"] = {
    icon = 1002,
    descript = "银元宝是中洲世界通行的高级货币，可购买大部分稀有物品。可获得%d银元宝",
    rescourse = {
      "#@每日签到|DailySignDlg#@",
      "#@活跃度奖励|ActivitiesDlg#@",
      "#@神秘大礼|OnlineGiftDlg#@",
      "#@位列仙班|OnlineMallVIPDlg#@"
    }
  },
  ["未鉴定装备"] = {
    descript = "可对未鉴定装备进行鉴定，鉴定后此装备将有更高的几率拥有较高的属性值",
    double_type = 1,
    rescourse = {
      "#P助人为乐|白邦芒#P",
      "#P副本|赤灵尊神#P",
      "#P修行任务|柳如尘#P",
      "#@72地煞星|ActivitiesDlg=其它活动#@",
      "#@36天罡星|ActivitiesDlg=其它活动#@"
    }
  },
  ["天技秘笈残片"] = {
    icon = 8077,
    descript = "天技秘笈的残片，保留着宠物对天生技能的残存记忆，点击使用后可前往屠娇娇处兑换秘笈宝袋",
    rescourse = {
      "放生带天技宠物",
      "#@集市逛摊|MarketBuyDlg=天技秘笈:天技秘笈残片#@"
    },
    unit = "张",
    color = "金色"
  },
  ["秘笈宝袋"] = {
    icon = 8001,
    double_type = 1,
    descript = "蕴藏天技秘笈的宝袋，打开后可随机获得一本",
    rescourse = {
      "#P天技秘笈商店|屠娇娇|M=我要兑换天技秘笈::RowSkillShopDlg=秘笈宝袋#P"
    },
    color = "金色"
  },
  ["经验心得"] = {
    icon = 8042,
    descript = "记录了经验心得的宝物，角色或宠物使用后可提升一定的经验（受自身和使用道具的等级差削减）。每个角色或宠物每天最多可以使用4本，元婴/血婴无法使用经验心得",
    rescourse = {
      "#@无量心经|OnlineMallDlg=无量心经#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:经验心得#@"
    },
    unit = "本",
    try_level_tip = "适用等级：%d～%d级",
    double_type = 1,
    apply = "SubmitXinDeDlg"
  },
  ["藏宝箱"] = {
    icon = 8043,
    descript = "使用钥匙可以打开的神奇宝箱，不但有首饰、满属性装备及装备打造材料奖励，更有召唤令·十二生肖和十二生肖变异宠大奖",
    rescourse = {
      "欢乐宝箱活动",
      "#@集市逛摊|MarketBuyDlg=其他道具:藏宝箱#@"
    },
    unit = "个",
    use_level = 30,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R30级#n后才能使用。"
  },
  ["钥匙串"] = {
    icon = 9086,
    descript = "神秘的钥匙串，串着各种神奇的钥匙",
    rescourse = {
      "#@在线商城|OnlineMallDlg=钥匙串#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:钥匙:钥匙串#@"
    },
    unit = "串",
    coin = 100,
    use_level = 30,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R30级#n后才能使用。",
    double_type = 1,
    color = "金色"
  },
  ["银钥匙"] = {
    icon = 9087,
    descript = "神奇的钥匙，可以用来打开宝箱，获得奖品",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=银钥匙#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=银钥匙#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=银钥匙#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=银钥匙#Z",
      "#@钥匙串|OnlineMallDlg=钥匙串#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:钥匙:银钥匙#@"
    },
    unit = "把",
    use_level = 30,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R30级#n后才能使用。",
    double_type = 0,
    color = "金色"
  },
  ["金钥匙"] = {
    icon = 9088,
    descript = "神奇的钥匙，可以用来打开宝箱，并有几率获得商城道具和召唤令·十二生肖奖励",
    rescourse = {
      "#@钥匙串|OnlineMallDlg=钥匙串#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:钥匙:金钥匙#@"
    },
    unit = "把",
    use_level = 30,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R30级#n后才能使用。",
    double_type = 1,
    color = "金色"
  },
  ["水晶钥匙"] = {
    icon = 9089,
    descript = "神奇的钥匙，可以用来打开宝箱，并有更高几率获得商城道具、召唤令·十二生肖和十二生肖变异宠奖励",
    rescourse = {
      "#@钥匙串|OnlineMallDlg=钥匙串#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:钥匙:水晶钥匙#@"
    },
    unit = "把",
    use_level = 30,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R30级#n后才能使用。",
    double_type = 1,
    color = "金色"
  },
  ["道武心得"] = {
    icon = 8061,
    descript = "记录了道行和武学心得的宝物，角色或宠物使用后可提升一定的道行或武学（受到自身道行或武学的削减）。每个角色或宠物每天最多可以使用4本",
    rescourse = {
      "#@无量心经|OnlineMallDlg=无量心经#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:道武心得#@"
    },
    unit = "本",
    try_level_tip = "适用等级：%d～%d级",
    double_type = 1,
    apply = "SubmitXinDeDlg"
  },
  ["通天令牌"] = {
    icon = 8065,
    descript = "在进行通天塔挑战时，可以改变当前层数挑战目标的神奇道具",
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:通天令牌#@"
    },
    unit = "块",
    double_type = 2,
    color = "金色"
  },
  ["高级通天令牌"] = {
    icon = 8066,
    descript = "在进行通天塔挑战时，可以自行选择想要挑战的星君",
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@"
    },
    unit = "块",
    double_type = 2,
    color = "金色"
  },
  ["如意通天令"] = {
    icon = 8067,
    descript = "在进行通天塔挑战时，可直接获得突破阶段的所有挑战奖励，并直接获得挑战通天塔顶的机会",
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@"
    },
    unit = "块",
    double_type = 2,
    color = "金色"
  },
  ["混沌玉"] = {
    icon = 9117,
    descript = "混沌中生成的神石，可以保证拆分装备时必定成功",
    rescourse = {
      "#@在线商城|OnlineMallDlg=混沌玉#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:混沌玉#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=混沌玉#P"
    },
    unit = "块",
    coin = 518,
    use_level = 50,
    apply = "EquipmentSplitDlg",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R50级#n后开放该功能。",
    color = "金色"
  },
  ["超级圣水晶"] = {
    icon = 9138,
    descript = "可以强化装备属性，并保证失败后参与强化的超级黑水晶不消失、被强化的属性值不会降低，并且会增加强化属性的完成度的神奇水晶",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级圣水晶#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:超级圣水晶#@"
    },
    unit = "颗",
    coin = 1000,
    use_level = 50,
    apply = "EquipmentRefiningDlg",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R50级#n后开放该功能。",
    color = "金色"
  },
  ["超级粉水晶"] = {
    icon = 9145,
    descript = "能够增加装备灵性，炼化装备粉属性的神奇水晶",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级粉水晶#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:超级粉水晶#@"
    },
    coin = 2800,
    use_level = 60,
    unit = "颗",
    apply = "EquipmentRefiningDlg",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R60级#n后开放该功能。",
    color = "金色"
  },
  ["装备共鸣石"] = {
    icon = 9147,
    descript = "传说此石可使相性相同之物产生共鸣，可以生成或重置装备共鸣属性",
    rescourse = {
      "#@在线商城|OnlineMallDlg=装备共鸣石#@",
      "#@集市逛摊|MarketBuyDlg=装备道具:装备共鸣石#@"
    },
    coin = 328,
    use_level = 70,
    unit = "块",
    apply = "EquipmentUpgradeDlg",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R70级#n后开放该功能。",
    color = "金色"
  },
  ["袖珍灵石"] = {
    icon = 9622,
    descript = "形状较小的超级灵石，只能改造低级的武器。袖珍类道具只能对适用等级装备使用，在改造装备时优先使用袖珍道具",
    rescourse = {
      "指引任务"
    },
    unit = "块",
    use_level = 40,
    double_type = 1,
    apply = "EquipmentUpgradeDlg",
    try_level_tip = "适用等级：%d～%d级",
    level_tip = "角色等级达到#R40级#n后开放该功能。"
  },
  ["袖珍晶石"] = {
    icon = 9623,
    descript = "形状较小的超级晶石，只能改造低级的防具，可以额外增加其防御的神奇石头，成功率等同于超级晶石。袖珍类道具只能对适用等级装备使用，在改造装备时优先使用袖珍道具",
    rescourse = {
      "指引任务"
    },
    unit = "块",
    use_level = 40,
    double_type = 1,
    apply = "EquipmentUpgradeDlg",
    try_level_tip = "适用等级：%d～%d级",
    level_tip = "角色等级达到#R40级#n后开放该功能。"
  },
  ["袖珍黑水晶"] = {
    icon = 9616,
    descript = "形状较小的超级黑水晶，能够将特定等级的未改造蓝装备、粉装备和金装备的附加属性拆分出来的神奇水晶，抽取属性成功后可生成超级黑水晶。袖珍类道具只能对适用等级装备使用，在装备拆分时优先使用袖珍道具",
    rescourse = {
      "指引任务"
    },
    unit = "颗",
    use_level = 50,
    double_type = 1,
    apply = "EquipmentSplitDlg",
    try_level_tip = "适用等级：%d～%d级",
    level_tip = "角色等级达到#R50级#n后开放该功能。"
  },
  ["袖珍混沌玉"] = {
    icon = 9620,
    descript = "形状较小的混沌玉，可以保证拆分装备时一颗超级黑水晶必定成功。袖珍类道具只能对适用等级装备使用，在装备拆分时优先使用袖珍道具",
    rescourse = {
      "指引任务"
    },
    unit = "块",
    use_level = 50,
    double_type = 1,
    apply = "EquipmentSplitDlg",
    try_level_tip = "适用等级：%d～%d级",
    level_tip = "角色等级达到#R50级#n后开放该功能。"
  },
  ["袖珍粉水晶"] = {
    icon = 9618,
    descript = "形状较小的超级粉水晶，只对特定等级的装备有效，可以将蓝装备炼化成粉装备，也可以改变粉装备、金装备、绿装备等的粉属性，对改造后的装备同样适用。袖珍类道具只能对适用等级装备使用，在炼化属性时优先使用袖珍道具",
    rescourse = {
      "指引任务"
    },
    unit = "颗",
    use_level = 60,
    double_type = 1,
    apply = "EquipmentRefiningDlg",
    try_level_tip = "适用等级：%d～%d",
    level_tip = "角色等级达到#R60级#n后开放该功能。"
  },
  ["袖珍黄水晶"] = {
    icon = 9617,
    descript = "形状较小的黄水晶，通过品质转换可以将特定等级的粉装备转换成金装备的神奇水晶，同时可用于炼化装备金属性。袖珍类道具只能对适用等级装备使用，在炼化属性时优先使用袖珍道具",
    rescourse = {
      "指引任务"
    },
    unit = "颗",
    use_level = 65,
    double_type = 1,
    apply = "EquipmentRefiningDlg",
    try_level_tip = "适用等级：%d～%d级",
    level_tip = "角色等级达到#R65级#n后开放该功能。"
  },
  ["袖珍绿水晶"] = {
    icon = 9614,
    descript = "形状较小的超级绿水晶，通过炼化可以使特定等级的金装备变成绿装备，也可以改变该等级的绿装备属性，并且保证炼化成功率100％的神奇水晶。袖珍类道具只能对适用等级装备使用，在炼化套装时优先使用袖珍道具",
    rescourse = {
      "指引任务"
    },
    unit = "颗",
    use_level = 70,
    double_type = 1,
    apply = "EquipmentRefiningSuitDlg",
    try_level_tip = "适用等级：%d～%d级",
    level_tip = "角色等级达到#R70级#n后开放该功能。"
  },
  ["超级仙风散"] = {
    icon = 9002,
    unit = "包",
    use_level = 20,
    level_tip = "角色等级达到#R20级#n后方可使用。",
    rescourse = {
      "#@在线商城|OnlineMallDlg=超级仙风散#@",
      "#@活跃奖励|ActivitiesDlg#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=超级仙风散#P",
      "#@集市逛摊|MarketBuyDlg=其他道具:超级仙风散#@"
    },
    descript = "使用后可以得到200点双倍点数的神奇药品，一阶降妖、伏魔每场消耗4点，二阶降妖、伏魔每场消耗8点，一阶飞仙渡邪每场消耗16点，二阶飞仙渡邪每场消耗32点",
    try_level_tip = "适用等级：大于等于%d级",
    coin = 108,
    double_type = 1,
    canApplyAll = true,
    color = "金色"
  },
  ["急急如律令"] = {
    icon = 9010,
    unit = "个",
    use_level = 45,
    coin = 328,
    level_tip = "角色等级达到#R45级#n以上玩家方可使用该道具！",
    fight_tip = "只能在战斗外使用。",
    rescourse = {
      "#@在线商城|OnlineMallDlg=急急如律令#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=急急如律令#P",
      "#@集市逛摊|MarketBuyDlg=其他道具:急急如律令#@"
    },
    descript = "使用后获得200点急急如律令点数，开启后能使每场刷道战斗奖励按照满怪情况结算，但不改变刷道战斗中的实际怪物数量，一阶降妖、伏魔每场消耗1点，二阶降妖、伏魔每场消耗2点，一阶飞仙渡邪每场消耗4点，二阶飞仙渡邪每场消耗8点",
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    canApplyAll = true,
    color = "金色"
  },
  ["60级满属礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 50,
    descript = "内含60级武器满属性超级黑水晶10颗",
    level_tip = "角色等级达到50级后方可使用本礼包。",
    try_level_tip = "适用等级：大于等于%d级",
    rescourse = {"兑换码"}
  },
  ["70级满属礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含70级各部位满属性超级黑水晶各5颗，共计20颗",
    level_tip = "角色等级达到60级后方可使用本礼包。",
    try_level_tip = "适用等级：大于等于%d级",
    rescourse = {"兑换码"}
  },
  ["70级装备打造礼包"] = {
    icon = 9109,
    unit = "个",
    use_level = 50,
    descript = "内含一件70级稀有满属性装备及随机装备打造道具，有机会获得超级粉水晶！",
    level_tip = "角色等级达到#R50级#n以上方可使用该道具！",
    try_level_tip = "适用等级：大于等于%d级",
    double_type = 1,
    rescourse = {
      "#@商城限时特惠|OnlineMallDlg=70级装备打造礼包#@"
    }
  },
  ["20级安卓首测礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 20,
    descript = "内含2本天书和30级安卓首测礼包 ",
    try_level_tip = "适用等级：大于等于%d级",
    rescourse = {"兑换码"},
    level_tip = "角色等级达到20级后方可使用本礼包。"
  },
  ["30级安卓首测礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 30,
    descript = "内含10张超级藏宝图、60级满属礼包和70级满属礼包",
    try_level_tip = "适用等级：大于等于%d级",
    rescourse = {"兑换码"},
    level_tip = "角色等级达到30级后方可使用本礼包。"
  },
  ["超级灵石礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含超级灵石10块",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到60级后方可使用本礼包"
  },
  ["超级晶石礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含超级晶石10块",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到60级后方可使用本礼包"
  },
  ["超级粉水晶礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含超级粉水晶3颗",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到60级后方可使用本礼包"
  },
  ["黄水晶礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含黄水晶18颗",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到60级后方可使用本礼包"
  },
  ["超级绿水晶礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含超级绿水晶10颗",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到60级后方可使用本礼包"
  },
  ["超级圣水晶礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含超级圣水晶10颗",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到60级后方可使用本礼包"
  },
  ["20级豪华新手礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 20,
    descript = "内含3本天书、3包超级仙风散和30级豪华新手礼包",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["30级豪华新手礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 30,
    descript = "内含3个神木鼎、1个火眼金睛和40级豪华新手礼包",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R30级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["40级豪华新手礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 40,
    descript = "内含3个急急如律令、1个天神护佑和50级豪华新手礼包",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R40级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["50级豪华新手礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 50,
    descript = "内含3块超级晶石、1块超级灵石、2颗超级黑水晶、2块混沌玉和60级豪华新手礼包",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R50级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["60级豪华新手礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 60,
    descript = "内含3颗宠物强化丹、3颗点化丹、满成长宠物：电精和70级豪华新手礼包",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R60级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["70级豪华新手礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 70,
    descript = "内含1颗超级粉水晶、6颗黄水晶、1颗超级绿水晶和1颗超级圣水晶",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R70级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["36宠物成长礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 1,
    descript = "内含1本天书、3颗点化丹、8颗宠物强化丹和6颗超级神兽丹（原价3678元宝）",
    rescourse = {
      "#@商城限购|OnlineMallDlg=36宠物成长礼包#@"
    }
  },
  ["88宠物成长礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 1,
    descript = "内含3本天书、10颗点化丹、19颗宠物强化丹和11颗超级神兽丹（原价9526元宝）",
    rescourse = {
      "#@商城限购|OnlineMallDlg=88宠物成长礼包#@"
    },
    color = "金色"
  },
  ["98神兵利器礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 1,
    descript = "内含3颗超级黑水晶、2块混沌玉、2块超级灵石、1颗超级粉水晶、6颗黄水晶、1颗超级绿水晶和1颗超级圣水晶（原价10124元宝）",
    rescourse = {
      "#@商城限购|OnlineMallDlg=98神兵利器礼包#@"
    }
  },
  ["198神兵利器礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 1,
    descript = "内含7颗超级黑水晶、6块混沌玉、4块超级灵石、2颗超级粉水晶、9颗黄水晶、3颗超级绿水晶和2颗超级圣水晶（原价21358元宝）",
    rescourse = {
      "#@商城限购|OnlineMallDlg=198神兵利器礼包#@"
    },
    color = "金色"
  },
  ["298神兵利器礼包"] = {
    icon = 9109,
    unit = "个",
    use_level = 1,
    descript = "内含10颗超级黑水晶、9块混沌玉、5块超级灵石、4颗超级粉水晶、12颗黄水晶、4颗超级绿水晶和3颗超级圣水晶（原价33148元宝）",
    rescourse = {
      "#@商城限购|OnlineMallDlg=298神兵利器礼包#@"
    }
  },
  ["宠物武学礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 1,
    descript = "内含14包宠风散（原价3024元宝）",
    rescourse = {
      "#@商城限购|OnlineMallDlg=宠物武学礼包#@"
    }
  },
  ["宠物修炼礼包"] = {
    icon = 9108,
    unit = "个",
    use_level = 1,
    descript = "内含10包超级仙风散、10包宠风散和10个急急如律令（原价6520元宝）",
    rescourse = {
      "#@商城限购|OnlineMallDlg=宠物修炼礼包#@"
    }
  },
  ["超级洗髓丹"] = {
    icon = 9004,
    descript = "使用后能重置角色当前所有已分配属性、相性点数",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "颗",
    double_type = 2,
    not_sell = 1
  },
  ["冥灵石"] = {
    icon = 1530,
    descript = "八仙梦境中的任务道具",
    use_level = 1,
    rescourse = {
      "八仙梦境"
    },
    unit = "块"
  },
  ["玄冰玉"] = {
    icon = 1531,
    descript = "八仙梦境中的任务道具",
    use_level = 1,
    rescourse = {
      "八仙梦境"
    },
    unit = "块"
  },
  ["水芙蓉"] = {
    icon = 7969,
    descript = "又名水莲花，八仙梦境中的任务道具",
    use_level = 1,
    rescourse = {
      "八仙梦境"
    },
    unit = "株"
  },
  ["雷神元神"] = {
    icon = 6232,
    descript = "雷神的一缕元神凝结而成，使用后可获得守护：雷神",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "首充礼包",
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["70级满属黑水晶"] = {
    icon = 9040,
    descript = "使用后随机获得一颗70级满属性超级黑水晶",
    use_level = 60,
    unit = "颗",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R60级#n后方可使用本道具。",
    rescourse = {}
  },
  ["满属性装备"] = {
    icon = "BigRewardIcon0014.png",
    descript = "随机获得一件满属性装备",
    rescourse = {
      "#@充值抽奖|NewChargeDrawGiftDlg#@"
    },
    isUsePlist = true
  },
  ["60级首饰"] = {
    icon = "BigRewardIcon0012.png",
    descript = "随机获得一件60级首饰",
    rescourse = {
      "#@充值抽奖|NewChargeDrawGiftDlg#@"
    },
    isUsePlist = true
  },
  ["50级首饰"] = {
    icon = "BigRewardIcon0012.png",
    descript = "随机获得一件50级首饰",
    rescourse = {
      "#@充值抽奖|NewChargeDrawGiftDlg#@"
    },
    isUsePlist = true
  },
  ["35级首饰"] = {
    icon = "BigRewardIcon0012.png",
    descript = "随机获得一件35级首饰",
    rescourse = {
      "#@充值抽奖|NewChargeDrawGiftDlg#@"
    },
    isUsePlist = true
  },
  ["20级首饰"] = {
    icon = "BigRewardIcon0012.png",
    descript = "随机获得一件20级首饰",
    rescourse = {
      "#@充值抽奖|NewChargeDrawGiftDlg#@"
    },
    isUsePlist = true
  },
  ["70级优质满属礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含3颗70级随机部位优质满属性超级黑水晶",
    level_tip = "角色等级达到60级后方可使用本礼包。",
    try_level_tip = "适用等级：大于等于%d级",
    rescourse = {"兑换码"}
  },
  ["天神护佑"] = {
    icon = 9007,
    unit = "个",
    coin = 518,
    use_level = 30,
    descript = "使用后可以得到天神的护佑，死亡后没有任何损失，但死亡后天神护佑的效果也同时消失，主动PK方及红名死亡不受此效果保护",
    level_tip = "角色等级达到#R30级#n后才能使用。",
    try_level_tip = "适用等级：大于等于%d级",
    rescourse = {
      "#@在线商城|OnlineMallDlg=天神护佑#@",
      "#@活跃宝箱|ActivitiesDlg#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=天神护佑#P",
      "#@集市逛摊|MarketBuyDlg=其他道具:天神护佑#@"
    },
    double_type = 1,
    color = "金色"
  },
  ["野生山药"] = {
    icon = 7952,
    descript = "署蓣，日干捣细筛为粉，食之大美，且愈疾而补",
    use_level = 1,
    rescourse = {
      "师门任务"
    },
    unit = "块"
  },
  ["金银花瓣"] = {
    icon = 7951,
    descript = "有藤鹭鸶藤，天生非人有，金花间银蕊，苍翠自成簇",
    use_level = 1,
    rescourse = {
      "师门任务"
    },
    unit = "株"
  },
  ["西当归"] = {
    icon = 7960,
    descript = "古之仙草，因灵气滋益，焕发强烈的生命气息，具有补益气血的作用",
    use_level = 1,
    rescourse = {
      "师门任务"
    },
    unit = "株"
  },
  ["三七根"] = {
    icon = 7958,
    descript = "三七根，止血之神药也。无论上、中、下之血，凡有外越者，一味独用亦效，加入于补气补血药中则更神。盖此药得补而无沸腾之患，补红得此而有安静之休也",
    use_level = 1,
    rescourse = {
      "师门任务"
    },
    unit = "株"
  },
  ["千年何首乌"] = {
    icon = 7957,
    descript = "古之仙草，取根若获九数者，服之乃仙",
    use_level = 1,
    rescourse = {
      "师门任务"
    },
    unit = "株"
  },
  ["莲花姑娘的包裹"] = {
    icon = 8015,
    descript = "莲花姑娘托付的包裹，其中不知准备的什么东西",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "个"
  },
  ["玉佩"] = {
    icon = 1309,
    descript = "张老板祖传的玉佩，温润无暇，价值连城",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "个"
  },
  ["丢失的包裹"] = {
    icon = 8015,
    descript = "不慎遗失的包裹，里面的点心已经被野狗吃掉了，只好把一些干粮放进去充数",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "个"
  },
  ["照妖镜"] = {
    icon = 6012,
    descript = "一面看似平常的铜镜，却能探知妖怪本源，使之无所遁形",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "面",
    double_type = 2
  },
  ["书信"] = {
    icon = 1513,
    descript = "神算子写给灵兽异人的信，里面不知写了些关于住宅风水还是催要银两的内容",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "封",
    double_type = 2
  },
  ["银两"] = {
    icon = 8045,
    descript = "灵兽异人给神算子的酬劳，充满了无尽的怨念，所以很沉",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "两",
    double_type = 2
  },
  ["定魂香"] = {
    icon = 1510,
    descript = "有定魂安神之功效，还能使鬼魂安然遁入轮回",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "个",
    double_type = 2
  },
  ["烟花"] = {
    icon = 8004,
    descript = "象征喜庆的烟花，点燃能散发五色光束，照耀夜空",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "个",
    double_type = 2
  },
  ["桃花糕"] = {
    icon = 1831,
    descript = "白素姑娘精心制作的桃花糕，大概能骗过杨镖头吧",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "块",
    double_type = 2
  },
  ["花露"] = {
    icon = 7121,
    descript = "终南山上金银花采集而来的花露，甘甜可口",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "份"
  },
  ["花神的佩剑"] = {
    icon = 6023,
    descript = "花神的佩剑，能让疯道人变得清醒，里面不知又有什么故事",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "把",
    double_type = 2
  },
  ["无字天书"] = {
    icon = 7700,
    descript = "没有任何文字的卷本，却又能知晓天地万物，玄妙无穷",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "卷",
    double_type = 2
  },
  ["草药"] = {
    icon = 1001,
    descript = "与路边杂草长相无二，非医者不能辨识",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "棵",
    double_type = 2
  },
  ["奇怪的玉石"] = {
    icon = 1523,
    descript = "一块通体发红的奇怪玉石，似乎蕴含了无尽的能量",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "块",
    double_type = 2
  },
  ["画像"] = {
    icon = 1586,
    descript = "骗走揽火玉之人的画像，已被玉泉真人施展道法，非神通广大者不可见",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "张",
    double_type = 2
  },
  ["火鸦骨"] = {
    icon = 1646,
    descript = "已故火鸦的骨骸，充斥了浓浓的火气",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "块",
    double_type = 2
  },
  ["显形香"] = {
    icon = 1510,
    descript = "能够使凡人昏睡、妖怪显形的神奇道具",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "个",
    double_type = 2
  },
  ["双生鱼"] = {
    icon = 7811,
    descript = "一条能活在火中的奇异鱼类，十分罕见",
    use_level = 1,
    rescourse = {
      "主线任务"
    },
    unit = "条",
    double_type = 2
  },
  ["袖珍血玲珑"] = {
    icon = 9602,
    descript = "存储了1,000,000气血的神奇道具，仅限战斗中使用，目标等级<120，气血每次最多恢复39000+最大气血的10%点；目标等级>=120，气血每次最多恢复50000+最大气血的20%点",
    use_level = 1,
    rescourse = {
      "新手礼包"
    },
    unit = "颗",
    double_type = 2,
    color = "金色"
  },
  ["袖珍法玲珑"] = {
    icon = 9603,
    descript = "存储了1,000,000法力的神奇道具，仅限战斗中使用，目标等级<120，法力每次最多恢复26000+最大法力的10%点；目标等级>=120，法力每次最多恢复30000+最大法力的20%点",
    use_level = 1,
    rescourse = {
      "新手礼包"
    },
    unit = "颗",
    double_type = 2,
    color = "金色"
  },
  ["修行卷轴"] = {
    icon = 7706,
    unit = "本",
    descript = "使用后可获得1次修行战斗经验奖励（双倍点数有效），但不获得游戏币、装备奖励，并消耗1次修行战斗次数，每日使用上限为20次。使用修行卷轴可获得5%的队长额外经验奖励。",
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    fight_tip = "战斗中不可进行此操作。"
  },
  ["修炼卷轴"] = {
    icon = 7706,
    unit = "本",
    double_type = 0,
    rescourse = {
      "#@镖行万里|ActivitiesDlg=限时活动#@",
      "#@海盗入侵|ActivitiesDlg=限时活动#@",
      "#P师徒任务|辛仁皑|M=查看师徒关系#P",
      "#@集市逛摊|MarketBuyDlg=其他道具:修炼卷轴#@"
    },
    descript = "使用后可获得1次修炼战斗经验奖励（双倍点数有效），但不获得游戏币、装备奖励，并消耗1次修炼战斗次数，每日使用上限为20次。使用修炼卷轴可获得5%的队长额外经验奖励",
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    fight_tip = "战斗中不可进行此操作。"
  },
  ["点化丹"] = {
    icon = 9172,
    rescourse = {
      "#@在线商城|OnlineMallDlg=点化丹#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:点化丹#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=点化丹#P"
    },
    unit = "颗",
    double_type = 1,
    descript = "凝天地精华，结为无尽通灵一丸（可用于开启宠物点化，也可喂养宠物增加点化灵气6000点）",
    coin = 328,
    color = "金色"
  },
  ["超级青蛙卡"] = {
    icon = 8101,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为青蛙",
    double_type = 0
  },
  ["超级松鼠卡"] = {
    icon = 8102,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为松鼠",
    double_type = 0
  },
  ["超级蛇卡"] = {
    icon = 8103,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蛇",
    double_type = 0
  },
  ["超级兔子卡"] = {
    icon = 8104,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为兔子",
    double_type = 0
  },
  ["超级猴子卡"] = {
    icon = 8105,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为猴子",
    double_type = 0
  },
  ["超级山猫卡"] = {
    icon = 8106,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为山猫",
    double_type = 0
  },
  ["超级野狗卡"] = {
    icon = 8107,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为野狗",
    double_type = 0
  },
  ["超级狐狸卡"] = {
    icon = 8108,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为狐狸",
    double_type = 0
  },
  ["超级桃精卡"] = {
    icon = 8109,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为桃精",
    double_type = 0
  },
  ["超级柳鬼卡"] = {
    icon = 8110,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为柳鬼",
    double_type = 0
  },
  ["超级白猿卡"] = {
    icon = 8111,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为白猿",
    double_type = 0
  },
  ["超级鹰卡"] = {
    icon = 8112,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为鹰",
    double_type = 0
  },
  ["超级海龟卡"] = {
    icon = 8113,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为海龟",
    double_type = 0
  },
  ["超级蝙蝠卡"] = {
    icon = 8114,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蝙蝠",
    double_type = 0
  },
  ["超级蟒卡"] = {
    icon = 8115,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蟒",
    double_type = 0
  },
  ["超级狼卡"] = {
    icon = 8116,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为狼",
    double_type = 0
  },
  ["超级老虎卡"] = {
    icon = 8117,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为老虎",
    double_type = 0
  },
  ["超级僵尸卡"] = {
    icon = 8118,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为僵尸",
    double_type = 0
  },
  ["超级鬼火萤卡"] = {
    icon = 8119,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为鬼火萤",
    double_type = 0
  },
  ["超级紫燕卡"] = {
    icon = 8121,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为紫燕",
    double_type = 0
  },
  ["超级火光鼠卡"] = {
    icon = 8120,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为火光鼠",
    double_type = 0
  },
  ["超级乌龙卡"] = {
    icon = 8122,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为乌龙",
    double_type = 0
  },
  ["超级花妖卡"] = {
    icon = 8123,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为花妖",
    double_type = 0
  },
  ["超级炎龙卡"] = {
    icon = 8124,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为炎龙",
    double_type = 0
  },
  ["超级鱼人卡"] = {
    icon = 8125,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为鱼人",
    double_type = 0
  },
  ["超级冰龙卡"] = {
    icon = 8126,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为冰龙",
    double_type = 0
  },
  ["超级地裂兽卡"] = {
    icon = 8127,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为地裂兽",
    double_type = 0
  },
  ["超级青龙卡"] = {
    icon = 8128,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为青龙",
    double_type = 0
  },
  ["超级金头陀卡"] = {
    icon = 8129,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为金头陀",
    double_type = 0
  },
  ["超级巨蜥卡"] = {
    icon = 8130,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为巨蜥",
    double_type = 0
  },
  ["超级石魔卡"] = {
    icon = 8131,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为石魔",
    double_type = 0
  },
  ["超级黄龙卡"] = {
    icon = 8132,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为黄龙",
    double_type = 0
  },
  ["超级火鸦卡"] = {
    icon = 8133,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为火鸦",
    double_type = 0
  },
  ["超级屈魂卡"] = {
    icon = 8134,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为屈魂",
    double_type = 0
  },
  ["超级怨鬼卡"] = {
    icon = 8135,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为怨鬼",
    double_type = 0
  },
  ["超级粉衣仙子卡"] = {
    icon = 8136,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为粉衣仙子",
    double_type = 0
  },
  ["超级电精卡"] = {
    icon = 8137,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为电精",
    double_type = 0
  },
  ["超级青衣仙子卡"] = {
    icon = 8138,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为青衣仙子",
    double_type = 0
  },
  ["超级雨兽卡"] = {
    icon = 8139,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为雨兽",
    double_type = 0
  },
  ["超级黄衣仙子卡"] = {
    icon = 8140,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为黄衣仙子",
    double_type = 0
  },
  ["超级风怪卡"] = {
    icon = 8141,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为风怪",
    double_type = 0
  },
  ["超级红衣仙子卡"] = {
    icon = 8142,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为红衣仙子",
    double_type = 0
  },
  ["超级虹妖卡"] = {
    icon = 8143,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为虹妖",
    double_type = 0
  },
  ["超级紫衣仙子卡"] = {
    icon = 8144,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为紫衣仙子",
    double_type = 0
  },
  ["超级雪女卡"] = {
    icon = 8145,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为雪女",
    double_type = 0
  },
  ["超级蓝衣仙子卡"] = {
    icon = 8146,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蓝衣仙子",
    double_type = 0
  },
  ["超级云兽卡"] = {
    icon = 8147,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为云兽",
    double_type = 0
  },
  ["超级白衣仙子卡"] = {
    icon = 8148,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为白衣仙子",
    double_type = 0
  },
  ["超级雷怪卡"] = {
    icon = 8149,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为雷怪",
    double_type = 0
  },
  ["超级石牛妖卡"] = {
    icon = 8150,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为石牛妖",
    double_type = 0
  },
  ["超级骷髅战将卡"] = {
    icon = 8151,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为不灭战将",
    double_type = 0
  },
  ["超级不灭战将卡"] = {
    icon = 8151,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为不灭战将",
    double_type = 0
  },
  ["超级蓝毛巨兽卡"] = {
    icon = 8152,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蓝毛巨兽",
    double_type = 0
  },
  ["超级螳螂怪卡"] = {
    icon = 8153,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为螳螂怪",
    double_type = 0
  },
  ["超级三头巨犬卡"] = {
    icon = 8154,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为三头巨犬",
    double_type = 0
  },
  ["超级嗜血巨人卡"] = {
    icon = 8155,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为凶蛮巨人",
    double_type = 0
  },
  ["超级凶蛮巨人卡"] = {
    icon = 8155,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为凶蛮巨人",
    double_type = 0
  },
  ["超级炼魔卡"] = {
    icon = 8156,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为炼魔",
    double_type = 0
  },
  ["超级寒冰怪卡"] = {
    icon = 8157,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为寒冰怪",
    double_type = 0
  },
  ["超级虾兵卡"] = {
    icon = 8158,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为虾兵",
    double_type = 0
  },
  ["超级蟹将卡"] = {
    icon = 8159,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蟹将",
    double_type = 0
  },
  ["超级冰晶龙鳞兽卡"] = {
    icon = 8169,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为冰晶龙鳞兽",
    double_type = 0
  },
  ["超级金翅鸢卡"] = {
    icon = 8161,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为金翅鸢",
    double_type = 0
  },
  ["超级伶俐鼠卡"] = {
    icon = 8306,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为伶俐鼠",
    double_type = 0
  },
  ["超级笨笨牛卡"] = {
    icon = 8307,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为笨笨牛",
    double_type = 0
  },
  ["超级威威虎卡"] = {
    icon = 8308,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为威威虎",
    double_type = 0
  },
  ["超级跳跳兔卡"] = {
    icon = 8309,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为跳跳兔",
    double_type = 0
  },
  ["超级酷酷龙卡"] = {
    icon = 8310,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为酷酷龙",
    double_type = 0
  },
  ["超级花花蛇卡"] = {
    icon = 8311,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为花花蛇",
    double_type = 0
  },
  ["超级溜溜马卡"] = {
    icon = 8312,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为溜溜马",
    double_type = 0
  },
  ["超级咩咩羊卡"] = {
    icon = 8313,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为咩咩羊",
    double_type = 0
  },
  ["超级帅帅猴卡"] = {
    icon = 8314,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为帅帅猴",
    double_type = 0
  },
  ["超级蛋蛋鸡卡"] = {
    icon = 8315,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蛋蛋鸡",
    double_type = 0
  },
  ["超级乖乖狗卡"] = {
    icon = 8316,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为乖乖狗",
    double_type = 0
  },
  ["超级招财猪卡"] = {
    icon = 8317,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为招财猪",
    double_type = 0
  },
  ["超级幽雪卡"] = {
    icon = 8450,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为幽雪",
    double_type = 0
  },
  ["超级馥汀卡"] = {
    icon = 8451,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为馥汀",
    double_type = 0
  },
  ["超级陌玉卡"] = {
    icon = 8452,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为陌玉",
    double_type = 0
  },
  ["超级九华卡"] = {
    icon = 8453,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:变异变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "变异卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为九华",
    double_type = 0
  },
  ["超级羊头怪卡"] = {
    icon = 8318,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:火相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为羊头怪",
    double_type = 0
  },
  ["超级牛头怪卡"] = {
    icon = 8319,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:金相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为牛头怪",
    double_type = 0
  },
  ["超级黑熊精卡"] = {
    icon = 8320,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:无相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为黑熊精",
    double_type = 0
  },
  ["超级狂狮怪卡"] = {
    icon = 8321,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:金相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为狂狮怪",
    double_type = 0
  },
  ["超级刺猬精卡"] = {
    icon = 8322,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:木相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为刺猬精",
    double_type = 0
  },
  ["超级猪妖卡"] = {
    icon = 8323,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:土相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为猪妖",
    double_type = 0
  },
  ["超级象精卡"] = {
    icon = 8324,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:水相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为象精",
    double_type = 0
  },
  ["超级百花羞卡"] = {
    icon = 8325,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:木相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为百花羞",
    double_type = 0
  },
  ["超级牛魔王卡"] = {
    icon = 8326,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:无相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为牛魔王",
    double_type = 0
  },
  ["超级夜叉王卡"] = {
    icon = 8445,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:火相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为夜叉王",
    double_type = 0
  },
  ["超级雪狐卡"] = {
    icon = 8170,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为雪狐",
    double_type = 0
  },
  ["超级剑魂卡"] = {
    icon = 8171,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为剑魂",
    double_type = 0
  },
  ["超级蝶仙卡"] = {
    icon = 8351,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蝶仙",
    double_type = 0
  },
  ["超级狰兽卡"] = {
    icon = 8352,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为狰兽",
    double_type = 0
  },
  ["超级水魔神卡"] = {
    icon = 8173,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为水魔神",
    double_type = 0
  },
  ["超级蚌姬卡"] = {
    icon = 8172,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为蚌姬",
    double_type = 0
  },
  ["超级金甲蝎卡"] = {
    icon = 8174,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为金甲蝎",
    double_type = 0
  },
  ["超级斗魔蜥卡"] = {
    icon = 8175,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为斗魔蜥",
    double_type = 0
  },
  ["超级化蛇兽卡"] = {
    icon = 8176,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为化蛇兽",
    double_type = 0
  },
  ["超级狐灵卡"] = {
    icon = 8177,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为狐灵",
    double_type = 0
  },
  ["超级罗刹王卡"] = {
    icon = 8446,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:金相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为罗刹王",
    double_type = 0
  },
  ["超级白骨精卡"] = {
    icon = 8447,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:木相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为白骨精",
    double_type = 0
  },
  ["超级玄武卡"] = {
    icon = 8304,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:神兽变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "神兽卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为玄武",
    double_type = 0
  },
  ["超级朱雀卡"] = {
    icon = 8305,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:神兽变身卡:火相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "神兽卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为朱雀",
    double_type = 0
  },
  ["超级疆良卡"] = {
    icon = 8302,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:神兽变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "神兽卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为疆良",
    double_type = 0
  },
  ["超级东山神灵卡"] = {
    icon = 8303,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:神兽变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "神兽卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为东山神灵",
    double_type = 0
  },
  ["超级九尾狐卡"] = {
    icon = 8448,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:神兽变身卡:土相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "神兽卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为九尾狐",
    double_type = 0
  },
  ["超级白矖卡"] = {
    icon = 8449,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:神兽变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "神兽卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为白矖",
    double_type = 0
  },
  ["超级勾陈卡"] = {
    icon = 8455,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:神兽变身卡:金相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "神兽卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为勾陈",
    double_type = 0
  },
  ["超级精卫卡"] = {
    icon = 8456,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:神兽变身卡:无相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "神兽卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为精卫",
    double_type = 0
  },
  ["儿童节糖果"] = {
    icon = 1596,
    rescourse = {
      "2016年儿童节"
    },
    unit = "颗",
    descript = "击败糖果大盗获得的儿童节糖果，使用后可获得商城道具奖励。（2016年6月4日04:59:59前使用有效）",
    test_descript = "击败糖果大盗获得的儿童节糖果，使用后可获得商城道具奖励。（2016年05月23日04:59:59前使用有效）"
  },
  ["朱雀神羽"] = {
    icon = 6018,
    rescourse = {
      "出师任务"
    },
    unit = "根",
    descript = "获得朱雀认可后获得的一根羽毛，交给辛仁皑即可完成出师考验"
  },
  ["授业卷轴"] = {
    icon = 7700,
    rescourse = {"任务"},
    unit = "卷",
    double_type = 0,
    descript = "师父带领徒弟完成十绝阵、修行、除暴、副本任务或徒弟完成传道授业任务时师父获得的回馈，开启后可获得丰厚道行奖励"
  },
  ["神木鼎"] = {
    icon = 9043,
    rescourse = {
      "#@在线商城|OnlineMallDlg=神木鼎#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:神木鼎#@"
    },
    unit = "个",
    double_type = 1,
    descript = "使用后可以得到1000点神木鼎点数的神奇道具。（在巡逻界面开启神木鼎后练功区战斗可获得对应怪物的变身卡片，并有几率获得特殊变身卡。）",
    use_level = 20,
    level_tip = "角色等级达到#R20级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    coin = 328,
    canApplyAll = true,
    color = "金色"
  },
  ["可口粽子"] = {
    icon = 1579,
    rescourse = {
      "2016年端午节"
    },
    unit = "个",
    double_type = 1,
    descript = "快把可口的粽子分享给天墉城居民们吧。"
  },
  ["糯米"] = {
    icon = 1829,
    rescourse = {
      "2016年端午节"
    },
    unit = "份",
    double_type = 1,
    descript = "糯米，制作粽子的材料"
  },
  ["粽叶"] = {
    icon = 1868,
    rescourse = {
      "2016年端午节"
    },
    unit = "片",
    double_type = 1,
    descript = "粽叶，制作粽子的材料"
  },
  ["香甜粽子"] = {
    icon = 1871,
    rescourse = {
      "2016年端午节"
    },
    unit = "个",
    double_type = 1,
    descript = "活动大使精心制作的香甜粽子。使用后获得商城道具。（2016年6月12日04:59:59前使用有效）",
    test_descript = "活动大使精心制作的香甜粽子。使用后获得商城道具。（2016年5月28日04:59:59前使用有效）"
  },
  ["美味桃花糕"] = {
    icon = 1832,
    rescourse = {
      "2016年端午节"
    },
    unit = "块",
    double_type = 1,
    descript = "美味可口，杨镖头的最爱，是要自己吃掉还是与杨镖头分享呢？（2016年6月12日04:59:59前使用有效）",
    test_descript = "美味可口，杨镖头的最爱，是要自己吃掉还是与杨镖头分享呢？（2016年5月28日04:59:59前使用有效）"
  },
  ["美味狗不理"] = {
    icon = 9132,
    rescourse = {
      "2016年端午节"
    },
    unit = "个",
    double_type = 1,
    descript = "美味可口，衙门口乞丐的最爱，是要自己吃掉还是与衙门口乞丐分享呢？（2016年6月12日04:59:59前使用有效）",
    test_descript = "美味可口，衙门口乞丐的最爱，是要自己吃掉还是与衙门口乞丐分享呢？（2016年5月28日04:59:59前使用有效）"
  },
  ["美味糖葫芦"] = {
    icon = 9183,
    rescourse = {
      "2016年端午节"
    },
    unit = "串",
    double_type = 1,
    descript = "美味可口，黄仨儿的最爱，是要自己吃掉还是与黄仨儿分享呢？（2016年6月12日04:59:59前使用有效）",
    test_descript = "美味可口，黄仨儿的最爱，是要自己吃掉还是与黄仨儿分享呢？（2016年5月28日04:59:59前使用有效）"
  },
  ["再续征程卷轴"] = {
    icon = 7702,
    rescourse = {
      "再续征程礼包"
    },
    unit = "本",
    double_type = 2,
    descript = "使用后可获得大量经验、道行、武学、潜能奖励，每天可使用一次，共可使用7次。",
    use_level = 35,
    level_tip = "角色等级达到#R35级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["金玉满堂"] = {
    icon = 8010,
    rescourse = {
      "天降宝盒"
    },
    unit = "个",
    double_type = 0,
    descript = "金光绚烂，鸿运不断。使用后可获得道行奖励，更有机会获得商城道具奖励"
  },
  ["吉祥如意"] = {
    icon = 8009,
    rescourse = {
      "天降宝盒"
    },
    unit = "个",
    double_type = 0,
    descript = "金光耀眼，洪福无边。使用后可获得经验奖励，更有机会获得商城道具奖励"
  },
  ["强盗领赏令"] = {
    icon = 20000,
    rescourse = {
      "#@刷道积分|GetTaoPointDlg#@"
    },
    unit = "枚",
    descript = "每天累积一定刷道积分可领取，使用后可获得大量道行、武学、代金券奖励（位列仙班道友可获得金钱奖励）",
    use_level = 45,
    try_level_tip = "适用等级：角色大于等于%d级",
    level_tip = "角色等级达到#R45级#n后方可使用本道具。"
  },
  ["强盗领赏令（双倍）"] = {
    icon = 20001,
    rescourse = {
      "#@刷道积分|GetTaoPointDlg#@"
    },
    unit = "枚",
    descript = "领取刷道积分奖励时有几率获得，使用后可获得普通强盗领赏令的双倍常规道行、双倍常规武学、单倍本月道行、单倍本月武学和单倍代金券奖励（位列仙班道友可获得金钱奖励）",
    use_level = 45,
    try_level_tip = "适用等级：角色大于等于%d级",
    level_tip = "角色等级达到#R45级#n后方可使用本道具。",
    color = "蓝色"
  },
  ["强盗召唤令"] = {
    icon = 20000,
    rescourse = {},
    unit = "枚",
    descript = "使用后可获得大量道行、武学、代金券奖励（位列仙班道友可获得金钱奖励）",
    use_level = 45,
    level_tip = "角色等级达到#R45级#n后方可使用本道具。"
  },
  ["强盗召唤令（双倍）"] = {
    icon = 20001,
    rescourse = {},
    unit = "枚",
    descript = "使用后可获得普通强盗召唤令的双倍道行、双倍武学和单倍代金券奖励（位列仙班道友可获得金钱奖励）",
    use_level = 45,
    level_tip = "角色等级达到#R45级#n后方可使用本道具。"
  },
  ["强盗召唤令（全局）"] = {
    icon = 20001,
    rescourse = {},
    unit = "枚",
    descript = "使用后可获得普通强盗召唤令的双倍道行、双倍武学和单倍代金券奖励（位列仙班道友可获得金钱奖励）",
    use_level = 45,
    level_tip = "角色等级达到#R45级#n后方可使用本道具。"
  },
  ["大胡子的锄头"] = {
    icon = 1512,
    rescourse = {
      "同甘共苦"
    },
    unit = "个",
    double_type = 2,
    descript = "同甘共苦所需的任务物品"
  },
  ["喇叭"] = {
    icon = 9176,
    descript = "神奇的喇叭，可以在特殊的区域内进行#R一次#n喊话",
    rescourse = {
      "#@在线商城|OnlineMallDlg=喇叭#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:喇叭#@"
    },
    unit = "个",
    double_type = 1,
    coin = 325,
    use_level = 30,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到30级方可使用喇叭。",
    chat_icon = "ui/Background0125.png",
    bubble_tip_horn = "channel/Icon1512.png",
    bubble_tip_back = "FriendChannelDlg/Background0124.png",
    bubble_tip_back_plist = 1,
    bubble_tip_back_main = "MainImg0012.png",
    color = "金色"
  },
  ["星芒喇叭"] = {
    icon = 9178,
    descript = "神奇而华丽的喇叭，可以在特殊的区域内进行#R一次#n喊话",
    rescourse = {
      "道心特权活动"
    },
    unit = "个",
    double_type = 1,
    use_level = 30,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到30级方可使用喇叭。",
    chat_icon = "ui/Background0177.png",
    bubble_tip_horn = "channel/Icon1784.png",
    bubble_tip_back = "ui/Background0176.png",
    bubble_tip_back_main = "MainImg0013.png",
    color = "金色"
  },
  ["情缘盒"] = {
    icon = 9030,
    rescourse = {
      "#@在线商城|OnlineMallDlg=情缘盒#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:友好度道具:情缘盒#@"
    },
    unit = "个",
    double_type = 1,
    descript = "精巧美丽的情缘盒，里面装有玫瑰、巧克力和百合等快速增加友好度的道具",
    coin = 108,
    color = "金色"
  },
  ["玫瑰"] = {
    icon = 9034,
    rescourse = {
      "#@情缘盒|OnlineMallDlg=情缘盒#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:友好度道具:玫瑰#@"
    },
    unit = "枝",
    double_type = 0,
    descript = "（仅限男性使用）由仙露所培育的玫瑰，送给女子后，可以使你们之间的友好度增加66点",
    color = "金色"
  },
  ["巧克力"] = {
    icon = 9035,
    rescourse = {
      "#@情缘盒|OnlineMallDlg=情缘盒#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:友好度道具:巧克力#@"
    },
    unit = "块",
    double_type = 0,
    descript = "（仅限女性使用）有情人制作的巧克力，送给心仪的男子后，可以使你们之间的友好度增加66点",
    color = "金色"
  },
  ["百合"] = {
    icon = 9036,
    rescourse = {
      "#@情缘盒|OnlineMallDlg=情缘盒#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:友好度道具:百合#@"
    },
    unit = "枝",
    double_type = 0,
    descript = "由仙露所培育的百合，送给朋友后，可以使你们之间的友好度增加88点",
    color = "金色"
  },
  ["改头换面卡"] = {
    icon = 9028,
    rescourse = {
      "#@在线商城|OnlineMallDlg=改头换面卡#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:改头换面卡#@"
    },
    unit = "张",
    use_level = 20,
    coin = 8800,
    double_type = 1,
    descript = "使用后可选择改变当前角色名称、角色性别%s或帮派名称（只有帮主可修改）",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["女儿红"] = {
    icon = 1684,
    rescourse = {
      "提亲任务"
    },
    unit = "坛",
    double_type = 2,
    descript = "完成某些任务所需物品"
  },
  ["丝绸"] = {
    icon = 1685,
    rescourse = {
      "提亲任务"
    },
    unit = "匹",
    double_type = 2,
    descript = "完成某些任务所需物品"
  },
  ["天陨石"] = {
    icon = 1686,
    rescourse = {
      "提亲任务"
    },
    unit = "块",
    double_type = 2,
    descript = "完成某些任务所需物品"
  },
  ["鉴心镜"] = {
    icon = 1687,
    rescourse = {
      "提亲任务"
    },
    unit = "面",
    double_type = 2,
    descript = "完成某些任务所需物品"
  },
  ["金猴毫毛"] = {
    icon = 1612,
    rescourse = {
      "2016年暑假活动"
    },
    unit = "根",
    double_type = 1,
    descript = "完成2016年暑假活动产出的道具。可在天墉城#Y活动大使#n处抽取商城道具奖励。2016年08月07日04:59:59前抽取更有奖励现金888、iPhone6S Plus、索尼U9电视等实物大奖。2016年9月5日04:59:59前使用有效",
    test_descript = "完成2016年暑假活动产出的道具。可在天墉城#Y活动大使#n处抽取商城道具奖励。2016年08月07日04:59:59前使用有效"
  },
  ["菊花瓣"] = {
    icon = 7951,
    rescourse = {
      "2016年暑假活动"
    },
    unit = "株",
    double_type = 1,
    descript = "散风清热，平肝明目，清热解毒。制作老猴凉茶的上好材料"
  },
  ["甘草根"] = {
    icon = 7958,
    rescourse = {
      "2016年暑假活动"
    },
    unit = "株",
    double_type = 1,
    descript = "气微，味甜而特殊，清热解毒、祛痰止咳。制作老猴凉茶的上好材料"
  },
  ["仙草叶"] = {
    icon = 1868,
    rescourse = {
      "2016年暑假活动"
    },
    unit = "株",
    double_type = 1,
    descript = "清暑，解渴，除热毒。制作老猴凉茶的上好材料"
  },
  ["冰晶石"] = {
    icon = 1522,
    rescourse = {
      "2016年暑假活动"
    },
    unit = "块",
    double_type = 1,
    descript = "至寒之物，带在身上就能够对付赤焰火鸦"
  },
  ["老猴凉茶"] = {
    icon = 7121,
    rescourse = {
      "2016年暑假活动"
    },
    unit = "碗",
    double_type = 1,
    descript = "猴哥赠送的礼物，使用后可获得商城道具奖励（2016年9月5日04:59:59前使用有效）",
    test_descript = "猴哥赠送的礼物，使用后可获得商城道具奖励（2016年08月07日04:59:59前使用有效）"
  },
  ["礼物"] = {
    icon = 9108,
    rescourse = {
      "2016年暑假活动"
    },
    unit = "个",
    double_type = 1,
    descript = "天墉城居民送给来做客小猴的礼物"
  },
  ["玉竹"] = {
    icon = 1569,
    rescourse = {
      "2016年七夕"
    },
    unit = "节",
    double_type = 1,
    descript = "玉竹，制作祈愿牌的上乘材料"
  },
  ["竹牌"] = {
    icon = 9101,
    rescourse = {
      "2016年七夕"
    },
    unit = "块",
    double_type = 1,
    descript = "竹子做的牌子，用上好的玉竹削制而成"
  },
  ["竹牌（已刻字）"] = {
    icon = 9101,
    rescourse = {
      "2016年七夕"
    },
    unit = "块",
    double_type = 1,
    descript = "竹子做的牌子，用上好的玉竹削制而成"
  },
  ["金丝绳"] = {
    icon = 1527,
    rescourse = {
      "2016年七夕"
    },
    unit = "团",
    double_type = 1,
    descript = "用来系挂祈愿牌的金丝绳"
  },
  ["祈愿牌"] = {
    icon = 1306,
    rescourse = {
      "2016年七夕"
    },
    unit = "块",
    double_type = 1,
    descript = "祈愿牌，用来为姻缘祈愿，但需要三生石为其注入灵气才能更加灵验"
  },
  ["三生石"] = {
    icon = 1546,
    rescourse = {
      "2016年七夕"
    },
    unit = "颗",
    double_type = 1,
    descript = "三生石，能为祈愿牌注入灵气"
  },
  ["缘定三生祈愿牌"] = {
    icon = 1311,
    rescourse = {
      "2016年七夕"
    },
    unit = "块",
    double_type = 1,
    descript = "镶嵌三生石的姻缘祈愿牌，拥有它佳缘就将近了"
  },
  ["鹊灵"] = {
    icon = 2020,
    rescourse = {
      "2016年七夕"
    },
    unit = "个",
    double_type = 1,
    descript = "喜鹊的精魄，通过和残忍的鸟怪战斗救出喜鹊而获得，点击使用后可到月老处兑换奖励（请在2016年8月10日 04:59:59前使用，逾期该物品将消失）"
  },
  ["猴宝的礼物"] = {
    icon = 9107,
    rescourse = {
      "2016年暑假活动"
    },
    unit = "个",
    double_type = 1,
    descript = "猴宝赠送的礼物，使用后可获得商城道具奖励（2016年9月5日04:59:59前使用有效）",
    test_descript = "猴宝赠送的礼物，使用后可获得商城道具奖励（2016年08月07日04:59:59前使用有效）"
  },
  ["结婚礼单"] = {
    icon = 1797,
    rescourse = {
      "#P豪华婚礼|月老#P"
    },
    unit = "份",
    double_type = 2,
    descript = "夫妻自行定制的结婚礼单，可供查看，婚礼结束时此道具即刻消失"
  },
  ["鸾凤宝玉"] = {
    icon = 1796,
    rescourse = {
      "#P豪华婚礼|月老#P"
    },
    unit = "枚",
    double_type = 2,
    descript = "夫妻双方在宝玉上刻上对方的姓名后，夫妻组队时会有奇异效果",
    custom_tips = "豪华婚礼获得",
    color = "金色"
  },
  ["龙凤呈祥服·新娘"] = {
    icon = 9203,
    rescourse = {
      "#P豪华婚礼|月老#P"
    },
    unit = "件",
    gender = 2,
    double_type = 2,
    descript = "带着喜庆与吉祥的礼服， 新娘穿上后更显娇美与华丽。在礼服效果生效后，双方组队非暂离时，队长在聊天栏当前频道输入：#R拥抱、亲吻、交杯、跪拜#n后，屏幕上将会出现相应的动作",
    item_class = ITEM_CLASS.WEDDING_CLOTHES,
    custom_tips = "豪华婚礼获得",
    color = "金色"
  },
  ["龙凤呈祥服·新郎"] = {
    icon = 9206,
    rescourse = {
      "#P豪华婚礼|月老#P"
    },
    unit = "件",
    gender = 1,
    double_type = 2,
    descript = "带着喜庆与吉祥的礼服， 新郎穿上后更显尊贵与华丽。在礼服效果生效后，双方组队非暂离时，队长在聊天栏当前频道输入：#R拥抱、亲吻、交杯、跪拜#n后，屏幕上将会出现相应的动作",
    item_class = ITEM_CLASS.WEDDING_CLOTHES,
    custom_tips = "豪华婚礼获得",
    color = "金色"
  },
  ["绛染容华服·新娘"] = {
    icon = 9205,
    rescourse = {
      "#P豪华婚礼|月老#P"
    },
    unit = "件",
    gender = 2,
    double_type = 2,
    descript = "珍贵又美丽的礼服，还可#R穿着进入战斗#n。在礼服效果生效后，双方组队非暂离时，队长在聊天栏当前频道输入：#R拥抱、亲吻、交杯、跪拜#n后，屏幕上将会出现相应的动作",
    item_class = ITEM_CLASS.WEDDING_CLOTHES,
    custom_tips = "豪华婚礼获得",
    color = "金色"
  },
  ["绛染容华服·新郎"] = {
    icon = 9208,
    rescourse = {
      "#P豪华婚礼|月老#P"
    },
    unit = "件",
    gender = 1,
    double_type = 2,
    descript = "珍贵又美丽的礼服，还可#R穿着进入战斗#n。在礼服效果生效后，双方组队非暂离时，队长在聊天栏当前频道输入：#R拥抱、亲吻、交杯、跪拜#n后，屏幕上将会出现相应的动作",
    item_class = ITEM_CLASS.WEDDING_CLOTHES,
    custom_tips = "豪华婚礼获得",
    color = "金色"
  },
  ["再续前缘卷轴"] = {
    icon = 7701,
    descript = "获得后两周内可使用，使用后可获得大量经验、道行、武学、潜能奖励，每天可使用一次，共可使用7次",
    unit = "本",
    use_level = 35,
    level_tip = "角色等级达到#R35级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "客服VIP召回礼包"
    }
  },
  ["花神元神"] = {
    icon = 6233,
    descript = "花神的一缕元神凝结而成，使用后可获得守护：花神",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["龙神元神"] = {
    icon = 6234,
    descript = "龙神的一缕元神凝结而成，使用后可获得守护：龙神",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["炎神元神"] = {
    icon = 6235,
    descript = "炎神的一缕元神凝结而成，使用后可获得守护：炎神",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["山神元神"] = {
    icon = 6236,
    descript = "山神的一缕元神凝结而成，使用后可获得守护：山神",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["云霄长老元神"] = {
    icon = 20033,
    descript = "云霄长老的一缕元神凝结而成，使用后可获得守护：云霄长老",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["玉柱长老元神"] = {
    icon = 20034,
    descript = "玉柱长老的一缕元神凝结而成，使用后可获得守护：玉柱长老",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["斗阙长老元神"] = {
    icon = 20035,
    descript = "斗阙长老的一缕元神凝结而成，使用后可获得守护：斗阙长老",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["金光长老元神"] = {
    icon = 20036,
    descript = "金光长老的一缕元神凝结而成，使用后可获得守护：金光长老",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["白骨长老元神"] = {
    icon = 20037,
    descript = "白骨长老的一缕元神凝结而成，使用后可获得守护：白骨长老",
    use_level = 20,
    unit = "个",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R20级#n后方可使用本道具。",
    isGuard = true,
    rescourse = {
      "#@守护召唤|GuardAttribDlg#@"
    }
  },
  ["宠风散"] = {
    icon = 9081,
    descript = "使用后获得200点宠风散点数，开启宠风散点数使宠物在特定战斗获得三倍武学奖励，一阶降妖、伏魔每场消耗4点，二阶降妖、伏魔每场消耗8点，一阶飞仙渡邪每场消耗16点，二阶飞仙渡邪每场消耗32点",
    use_level = 45,
    unit = "包",
    level_tip = "角色等级达到#R45级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "#@在线商城|OnlineMallDlg=宠风散#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=宠风散#P",
      "#@集市逛摊|MarketBuyDlg=其他道具:宠风散#@"
    },
    double_type = 1,
    coin = 216,
    canApplyAll = true,
    color = "金色"
  },
  ["神秘菜品"] = {
    icon = 1779,
    rescourse = {
      "2016年中元节活动"
    },
    unit = "份",
    double_type = 2,
    descript = "神秘的菜品，味道如何只有吃了才知道。"
  },
  ["活跃度宝箱"] = {
    descript = "可随机获得商城道具、低级首饰或超级女娲石奖励。",
    rescourse = {
      "#@活跃度奖励|ActivitiesDlg#@"
    },
    double_type = 2
  },
  ["“教”字卡"] = {
    icon = 1616,
    rescourse = {
      "2016年教师节活动"
    },
    unit = "张",
    double_type = 1,
    descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月12日04:59:59前使用有效）",
    test_descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月01日04:59:59前使用有效）"
  },
  ["“师”字卡"] = {
    icon = 1617,
    rescourse = {
      "2016年教师节活动"
    },
    unit = "张",
    double_type = 1,
    descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月12日04:59:59前使用有效）",
    test_descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月01日04:59:59前使用有效）"
  },
  ["“节”字卡"] = {
    icon = 1618,
    rescourse = {
      "2016年教师节活动"
    },
    unit = "张",
    double_type = 1,
    descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月12日04:59:59前使用有效）",
    test_descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月01日04:59:59前使用有效）"
  },
  ["“快”字卡"] = {
    icon = 1619,
    rescourse = {
      "2016年教师节活动"
    },
    unit = "张",
    double_type = 1,
    descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月12日04:59:59前使用有效）",
    test_descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月01日04:59:59前使用有效）"
  },
  ["“乐”字卡"] = {
    icon = 1620,
    rescourse = {
      "2016年教师节活动"
    },
    unit = "张",
    double_type = 1,
    descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月12日04:59:59前使用有效）",
    test_descript = "贺帖上丢失的字，可以直接使用，也可以集齐一整句“教师节快乐”后交给师尊。（2016年9月01日04:59:59前使用有效）"
  },
  ["感谢信"] = {
    icon = 9695,
    rescourse = {
      "2016年教师节活动"
    },
    unit = "封",
    double_type = 1,
    descript = "师尊赠送的礼物，使用后可获得商城道具奖励。（2016年9月12日04:59:59前使用有效）",
    test_descript = "师尊赠送的礼物，使用后可获得商城道具奖励。（2016年9月01日04:59:59前使用有效）"
  },
  ["骰子"] = {
    icon = 1621,
    rescourse = {
      "2020年中秋节"
    },
    unit = "颗",
    double_type = 1,
    descript = "可在中秋节任务中获得，在活动大使处用于博饼的物品。",
    test_descript = "可在中秋节任务中获得，在活动大使处用于博饼的物品。",
    fight_tip = "战斗中不可进行此操作。"
  },
  ["骰子·2018中秋"] = {
    icon = 1621,
    rescourse = {
      "2019年中秋活动"
    },
    unit = "颗",
    double_type = 1,
    descript = "可在中秋节任务中获得，在活动大使处用于博饼的物品。",
    test_descript = "可在中秋节任务中获得，在活动大使处用于博饼的物品。",
    fight_tip = "战斗中不可进行此操作。"
  },
  ["骰子·2018中秋"] = {
    icon = 1621,
    rescourse = {
      "2018年中秋节活动"
    },
    unit = "颗",
    double_type = 1,
    descript = "可在中秋节任务中获得，在活动大使处用于博饼的物品。（请在2018-09-27 04:59:59前使用，逾期该物品将失效）",
    test_descript = "可在中秋节任务中获得，在活动大使处用于博饼的物品。（请在2018-08-23 04:59:59前使用，逾期该物品将失效）",
    fight_tip = "战斗中不可进行此操作。"
  },
  ["月饼"] = {
    icon = 1622,
    rescourse = {
      "2016年中秋活动"
    },
    unit = "个",
    double_type = 1,
    descript = "由嫦娥仙子制作，从仙界月宫落下凡间（请在当日提交，次日5:00月饼会消失）",
    test_descript = "由嫦娥仙子制作，从仙界月宫落下凡间（请在当日提交，次日5:00月饼会消失）",
    fight_tip = "战斗中不可进行此操作。"
  },
  ["年糕"] = {
    icon = 1623,
    rescourse = {
      "2016年中秋活动"
    },
    unit = "个",
    double_type = 1,
    descript = "收集月饼时意外得到的玉兔特制年糕，快拿去交给玉兔吧（请在2016-09-18 04:59:59前提交，逾期该物品将失效）  ",
    test_descript = "收集月饼时意外得到的玉兔特制年糕，快拿去交给玉兔吧（请在2016-09-04 04:59:59前提交，逾期该物品将失效）  ",
    fight_tip = "战斗中不可进行此操作。"
  },
  ["实物·iPhone7"] = {
    icon = 10006,
    descript = "异世界的舶来品，据说价值不菲，趋之若鹜。请尽快点击使用按钮来提交收货信息（本活动的奖品由雷霆游戏提供，与苹果公司无关）",
    unit = "部",
    rescourse = {
      "100活跃抽大奖"
    }
  },
  ["实物·话费"] = {
    icon = 10007,
    descript = "异世界的舶来品，听说好友传音居然还要花钱，还是中洲大陆消息往来便利啊。请尽快点击使用按钮来提交收货信息。",
    unit = "份",
    rescourse = {
      "活跃抽大奖"
    }
  },
  ["实物·话费1000元"] = {
    icon = 11000,
    descript = "异世界的舶来品，听说好友传音居然还要花钱，还是中洲大陆消息往来便利啊。请尽快点击使用按钮来提交收货信息。",
    unit = "份",
    rescourse = {
      "活跃抽大奖"
    }
  },
  ["实物·话费500元"] = {
    icon = 11001,
    descript = "异世界的舶来品，听说好友传音居然还要花钱，还是中洲大陆消息往来便利啊。请尽快点击使用按钮来提交收货信息。",
    unit = "份",
    rescourse = {
      "活跃抽大奖"
    }
  },
  ["实物·话费10元"] = {
    icon = 11002,
    descript = "异世界的舶来品，听说好友传音居然还要花钱，还是中洲大陆消息往来便利啊。请尽快点击使用按钮来提交收货信息。",
    unit = "份",
    rescourse = {
      "活跃抽大奖"
    }
  },
  ["清泉"] = {
    icon = 7121,
    rescourse = {
      "2016年国庆节活动"
    },
    unit = "碗",
    double_type = 2,
    descript = "来自天墉城荷花池的清泉，饮用后消热解暑。  "
  },
  ["菊花酒"] = {
    icon = 1624,
    rescourse = {
      "2016年重阳节活动"
    },
    unit = "壶",
    double_type = 1,
    descript = "酿酒仙人特地为重阳节酿造的上好菊花酒，快去送给天墉城的白发长者们吧",
    fight_tip = "战斗中不可进行此操作。"
  },
  ["蓬饵"] = {
    icon = 1625,
    rescourse = {
      "2016年重阳节活动"
    },
    unit = "块",
    double_type = 1,
    descript = "又名重阳糕，重阳佳节传统食物，使用后可获得商城道具奖励（2016年10月12日04:59:59前使用有效） ",
    test_descript = "又名重阳糕，重阳佳节传统食物，使用后可获得商城道具奖励（2016年09月26日04:59:59前使用有效）"
  },
  ["百岁龟甲"] = {
    icon = 1626,
    rescourse = {
      "2016年重阳节活动"
    },
    unit = "片",
    double_type = 1,
    descript = "百岁长寿龟升仙时留下的龟甲，集齐#Y3片#n交给长寿仙人可为长者们祈福。（2016年10月12日04:59:59前使用有效）",
    test_descript = "百岁长寿龟升仙时留下的龟甲，集齐#Y3片#n交给长寿仙人可为长者们祈福。（2016年09月26日04:59:59前使用有效）"
  },
  ["青莲符"] = {
    icon = 10001,
    rescourse = {
      "全服红包",
      "如意红包雨"
    },
    unit = "张",
    double_type = 1,
    descript = "五行符咒之一，集齐青莲符、杏黄符、赤焰符、素白符、黑水符各一张后使用可兑换#Y指如疾风#n的称谓 ",
    item_class = ITEM_CLASS.WUXING_FU,
    color = "金色"
  },
  ["杏黄符"] = {
    icon = 10002,
    rescourse = {
      "全服红包",
      "如意红包雨"
    },
    unit = "张",
    double_type = 1,
    descript = "五行符咒之一，集齐青莲符、杏黄符、赤焰符、素白符、黑水符各一张后使用可兑换#Y指如疾风#n的称谓 ",
    item_class = ITEM_CLASS.WUXING_FU,
    color = "金色"
  },
  ["赤焰符"] = {
    icon = 10003,
    rescourse = {
      "全服红包",
      "如意红包雨"
    },
    unit = "张",
    double_type = 1,
    descript = "五行符咒之一，集齐青莲符、杏黄符、赤焰符、素白符、黑水符各一张后使用可兑换#Y指如疾风#n的称谓 ",
    item_class = ITEM_CLASS.WUXING_FU,
    color = "金色"
  },
  ["素白符"] = {
    icon = 10004,
    rescourse = {
      "全服红包",
      "如意红包雨"
    },
    unit = "张",
    double_type = 1,
    descript = "五行符咒之一，集齐青莲符、杏黄符、赤焰符、素白符、黑水符各一张后使用可兑换#Y指如疾风#n的称谓 ",
    item_class = ITEM_CLASS.WUXING_FU,
    color = "金色"
  },
  ["黑水符"] = {
    icon = 10005,
    rescourse = {
      "全服红包",
      "如意红包雨"
    },
    unit = "张",
    double_type = 1,
    descript = "五行符咒之一，集齐青莲符、杏黄符、赤焰符、素白符、黑水符各一张后使用可兑换#Y指如疾风#n的称谓 ",
    item_class = ITEM_CLASS.WUXING_FU,
    color = "金色"
  },
  ["定魂丹"] = {
    icon = 1565,
    rescourse = {
      "八仙梦境"
    },
    unit = "颗",
    descript = "八仙梦境中的任务道具"
  },
  ["九魂丹"] = {
    icon = 1571,
    descript = "八仙梦境中的任务道具",
    use_level = 1,
    rescourse = {
      "八仙梦境"
    },
    unit = "颗"
  },
  ["唤心草"] = {
    icon = 7951,
    descript = "八仙梦境中的任务道具",
    use_level = 1,
    rescourse = {
      "八仙梦境"
    },
    unit = "株"
  },
  ["活跃礼包【免费】"] = {
    icon = 8009,
    rescourse = {
      "2016年国庆节活动"
    },
    unit = "个",
    descript = "内含100银元宝、1包宠风散、1包超级仙风散"
  },
  ["登录礼包【免费】"] = {
    icon = 8010,
    rescourse = {
      "2016年国庆节活动"
    },
    unit = "个",
    descript = "内含300银元宝、1个神木鼎、1个情缘盒"
  },
  ["寻宝大礼包"] = {
    icon = 8001,
    rescourse = {
      "2016年国庆节活动"
    },
    unit = "个",
    descript = "内含6张藏宝图、6张超级藏宝图"
  },
  ["宠物欢乐礼包"] = {
    icon = 9107,
    rescourse = {
      "2016年国庆节活动"
    },
    unit = "个",
    descript = "内含3瓶超级归元露、2册天书、7颗宠物强化丹、3颗点化丹"
  },
  ["刷道豪华礼包"] = {
    icon = 9108,
    rescourse = {
      "2016年国庆节活动"
    },
    unit = "个",
    descript = "内含12包超级仙风散、12包宠风散、8个急急如律令"
  },
  ["装备进阶礼包"] = {
    icon = 9109,
    rescourse = {
      "2016年国庆节活动"
    },
    unit = "个",
    descript = "内含3块超级灵石、3块超级晶石、1颗超级粉水晶、6颗黄水晶、1颗超级绿水晶"
  },
  ["装备豪华礼包"] = {
    icon = 8063,
    rescourse = {
      "2016年国庆节活动"
    },
    unit = "个",
    descript = "内含6颗超级黑水晶、6块混沌玉、6颗超级圣水晶、3颗超级粉水晶、6颗超级绿水晶"
  },
  ["单身券"] = {
    icon = 1627,
    unit = "张",
    rescourse = {
      "2016年光棍节活动"
    },
    descript = "又名'注孤生'券，可在光棍节转盘抽奖1次。（请在2016-11-14 04:59:59前使用，逾期该物品将失效）",
    test_descript = "又名'注孤生'券，可在光棍节转盘抽奖1次。（请在2016-10-27 04:59:59前使用，逾期该物品将失效）",
    apply = "BachelorDrawDlg"
  },
  ["精致糕点"] = {
    icon = 1628,
    unit = "盒",
    rescourse = {
      "2016年光棍节活动"
    },
    descript = "一看就昂贵无比的糕点，散发出诱人的香气。"
  },
  ["精怪诱饵"] = {
    icon = 9091,
    descript = "由多种精怪喜爱的食物精制而成，为召唤精怪必备之物，使用后可在玉真子处召唤精怪",
    use_level = 40,
    level_tip = "角色等级达到#R40级#n后开放该功能。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "#@在线商城|OnlineMallDlg=精怪诱饵#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:精怪诱饵#@"
    },
    unit = "袋",
    double_type = 1,
    coin = 1000,
    color = "金色"
  },
  ["灵物囊"] = {
    icon = 9097,
    descript = "内含驯化精怪所需灵物，使用后可随机获得拘首环，困灵砂，驱力刺，定鞍石，控心玉中的一种",
    rescourse = {
      "#@在线商城|OnlineMallDlg=灵物囊#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:精怪灵物:灵物囊#@"
    },
    unit = "袋",
    double_type = 1,
    coin = 398,
    color = "金色"
  },
  ["拘首环"] = {
    icon = 9098,
    descript = "用上古奇兽的头骨精磨而成，炼制后可大小如意，轻重随心，大凡仙人皆将其安于自己坐骑头上，可以控制其前行方向，行走于四海八方 ",
    rescourse = {
      "#@灵物囊|OnlineMallDlg=灵物囊#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:精怪灵物:拘首环#@"
    },
    unit = "个",
    double_type = 1,
    color = "金色"
  },
  ["困灵砂"] = {
    icon = 9099,
    descript = "荒漠之母辰砂的附近常伴生着大量的困灵砂，接近者皆法力禁锢，怯弱无力。有大神通者取之，用于桀骜精怪，可困其一身灵力蛮力",
    rescourse = {
      "#@灵物囊|OnlineMallDlg=灵物囊#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:精怪灵物:困灵砂#@"
    },
    unit = "盏",
    double_type = 1,
    color = "金色"
  },
  ["驱力刺"] = {
    icon = 9100,
    descript = "传闻有上古奇蜂，尾刺极尖，坚硬异常。仙人获此物炼制成极坚破刚之物，用于桀骜精怪可破其皮，痛其心肺，莫不敢奋力驰骋也",
    rescourse = {
      "#@灵物囊|OnlineMallDlg=灵物囊#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:精怪灵物:驱力刺#@"
    },
    unit = "个",
    double_type = 1,
    color = "金色"
  },
  ["定鞍石"] = {
    icon = 9101,
    descript = "万年灵龟伏于海底，化而为石，成一灵物。此物似软非硬，耐久坚韧，更可变幻如意，仙人们常用其作为坐骑之鞍，坚固牢靠",
    rescourse = {
      "#@灵物囊|OnlineMallDlg=灵物囊#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:精怪灵物:定鞍石#@"
    },
    unit = "块",
    double_type = 1,
    color = "金色"
  },
  ["控心玉"] = {
    icon = 9102,
    descript = "千年道行狐妖的内丹被万年钟乳石化，转而为玉，流光溢彩，馋香四溢。精怪皆难以摆脱其诱惑，吞而食之则失去思想，任人操控",
    rescourse = {
      "#@灵物囊|OnlineMallDlg=灵物囊#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:精怪灵物:控心玉#@"
    },
    unit = "块",
    double_type = 1,
    color = "金色"
  },
  ["风灵丸"] = {
    icon = 9135,
    descript = "御灵食物，使用后增加御灵5天风灵丸效果：提高1级移动速度（每次使用可累计，最高可达御灵能力阶位），提高主人各项属性，需要骑乘该御灵才能生效",
    rescourse = {
      "#@在线商城|OnlineMallDlg=风灵丸#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:风灵丸#@"
    },
    unit = "颗",
    isCanDouble = true,
    double_type = 1,
    coin = 328,
    color = "金色"
  },
  ["女娲宝箱"] = {
    icon = 9151,
    unit = "个",
    use_level = 1,
    descript = "打开后可随机获得1块、2块或5块超级女娲石的神奇宝箱",
    rescourse = {
      "#@在线商城|OnlineMallDlg=女娲宝箱#@"
    },
    color = "金色",
    double_type = 1
  },
  ["聚灵石"] = {
    icon = 9170,
    descript = "富含天地灵气的石头，具有将精怪或御灵进行融合的效果。高阶融合时必定会增加骑宠融合完成度，有一定概率直接完成融合",
    rescourse = {
      "#@在线商城|OnlineMallDlg=聚灵石#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:聚灵石#@"
    },
    unit = "颗",
    isCanDouble = true,
    coin = 328,
    double_type = 1,
    color = "金色"
  },
  ["元蛋"] = {
    icon = 1559,
    unit = "枚",
    rescourse = {
      "2017年元旦节"
    },
    descript = "活动大使从仙界带来的奇物，孵化完成后可获得商城道具与随机宠物奖励，更有机会获得天技宠物或变异宠物"
  },
  ["遗失的圣诞礼物"] = {
    icon = 9107,
    descript = "不知是谁遗失的精美圣诞礼物，还是把它交给#R圣诞麋鹿#n吧（活动结束后道具消失）",
    rescourse = {
      "2016年圣诞节活动"
    },
    unit = "个",
    isCanDouble = false,
    double_type = 2
  },
  ["装饰盒"] = {
    icon = 8063,
    descript = "用来装扮圣诞树的装饰盒，赶快上交给喜欢的圣诞树吧",
    rescourse = {
      "2016年圣诞节活动"
    },
    unit = "个",
    isCanDouble = false,
    double_type = 2
  },
  ["幸运折扣券·1折"] = {
    icon = 1631,
    descript = "鸿运当头，优惠不断。在此劵有效期内，在商城勾选“仅用金元宝购买”模式并点击购买原价商品时，将出现打折结算界面，可在该界面上选择使用此券，使用后可对1个道具进行打折优惠，但最高优惠额度不可超过5,000元宝",
    test_descript = "鸿运当头，优惠不断。在此劵有效期内，在商城点击购买原价商品时，将出现打折结算界面，可在该界面上选择使用此券，使用后可对1个道具进行打折优惠，但最高优惠额度不可超过5,000元宝",
    rescourse = {
      "幸运折扣券活动"
    },
    unit = "张",
    isCanDouble = true,
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["幸运折扣券·5折"] = {
    icon = 1635,
    descript = "鸿运当头，优惠不断。在此劵有效期内，在商城勾选“仅用金元宝购买”模式并点击购买原价商品时，将出现打折结算界面，可在该界面上选择使用此券，使用后可对1个道具进行打折优惠，但最高优惠额度不可超过5,000元宝",
    test_descript = "鸿运当头，优惠不断。在此劵有效期内，在商城点击购买原价商品时，将出现打折结算界面，可在该界面上选择使用此券，使用后可对1个道具进行打折优惠，但最高优惠额度不可超过5,000元宝",
    rescourse = {
      "幸运折扣券活动"
    },
    unit = "张",
    isCanDouble = true,
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["幸运折扣券·9折"] = {
    icon = 1639,
    descript = "鸿运当头，优惠不断。在此劵有效期内，在商城勾选“仅用金元宝购买”模式并点击购买原价商品时，将出现打折结算界面，可在该界面上选择使用此券，使用后可对1个道具进行打折优惠，但最高优惠额度不可超过5,000元宝",
    test_descript = "鸿运当头，优惠不断。在此劵有效期内，在商城点击购买原价商品时，将出现打折结算界面，可在该界面上选择使用此券，使用后可对1个道具进行打折优惠，但最高优惠额度不可超过5,000元宝",
    rescourse = {
      "幸运折扣券活动"
    },
    unit = "张",
    isCanDouble = true,
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["70级直升丹"] = {
    icon = 9090,
    descript = "使用后可直接将角色真身及当前出战宠物升级到70级的神奇丹药",
    rescourse = {
      "内测专区新手礼包"
    },
    unit = "颗",
    use_level = 20,
    level_tip = "角色真身等级达到#R20级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["2阶骑宠灵魄"] = {
    icon = 12002,
    descript = "由2阶骑宠（精怪、御灵）转化而成的灵魄，可在骑宠融合中代替副宠作为融合材料",
    test_descript = "由2阶骑宠（精怪、御灵）转化而成的灵魄，可在骑宠融合中代替副宠作为融合材料",
    rescourse = {
      "#@骑宠转化|PetHorseDlg#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:骑宠灵魄:2阶#@"
    },
    unit = "个",
    isCanDouble = true,
    color = "金色"
  },
  ["3阶骑宠灵魄"] = {
    icon = 12003,
    descript = "由3阶骑宠（精怪、御灵）转化而成的灵魄，可在骑宠融合中代替副宠作为融合材料",
    test_descript = "由3阶骑宠（精怪、御灵）转化而成的灵魄，可在骑宠融合中代替副宠作为融合材料",
    rescourse = {
      "#@骑宠转化|PetHorseDlg#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:骑宠灵魄:3阶#@"
    },
    unit = "个",
    isCanDouble = true,
    color = "金色"
  },
  ["4阶骑宠灵魄"] = {
    icon = 12004,
    descript = "由4阶骑宠（精怪、御灵）转化而成的灵魄，可在骑宠融合中代替副宠作为融合材料",
    test_descript = "由4阶骑宠（精怪、御灵）转化而成的灵魄，可在骑宠融合中代替副宠作为融合材料",
    rescourse = {
      "#@骑宠转化|PetHorseDlg#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:骑宠灵魄:4阶#@"
    },
    unit = "个",
    isCanDouble = true,
    color = "金色"
  },
  ["蓝松石"] = {
    icon = 8085,
    descript = "此物乃是世界上最古老的玉石品种之一",
    unit = "枚",
    isCanDouble = true,
    rescourse = {
      "#@鉴定宝石|EquipmentIdentifyDlg=鉴定宝石#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:宝石:蓝松石#@"
    }
  },
  ["芙蓉石"] = {
    icon = 8086,
    descript = "此物乃是世界上最古老的玉石品种之一，晶莹剔透，色泽柔美",
    isCanDouble = true,
    unit = "枚",
    rescourse = {
      "#@鉴定宝石|EquipmentIdentifyDlg=鉴定宝石#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:宝石:芙蓉石#@",
      "#@合成|AlchemyDlg=芙蓉石#@"
    }
  },
  ["红宝石"] = {
    icon = 8087,
    descript = "一种罕见的宝石，质地坚硬，外观华美",
    isCanDouble = true,
    unit = "枚",
    rescourse = {
      "#@鉴定宝石|EquipmentIdentifyDlg=鉴定宝石#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:宝石:红宝石#@",
      "#@合成|AlchemyDlg=红宝石#@"
    }
  },
  ["蓝宝石"] = {
    icon = 8088,
    descript = "极为珍贵罕见的一种宝石",
    isCanDouble = true,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:宝石:蓝宝石#@",
      "#@合成|AlchemyDlg=蓝宝石#@"
    },
    unit = "枚"
  },
  ["千年雪糍"] = {
    icon = 8068,
    descript = "极寒之地千年孕育而出的松软雪糍，对雪精灵来说是大补之物",
    rescourse = {
      "2017年寒假活动"
    },
    unit = "个",
    double_type = 0
  },
  ["锄头"] = {
    icon = 1512,
    descript = "闪烁着寒光的锄头，在玄洲使用可采集千年雪糍",
    rescourse = {
      "2017年寒假活动"
    },
    unit = "把",
    double_type = 2
  },
  ["寒假刮刮券"] = {
    icon = 1641,
    descript = "手感冰凉的神奇奖券，可进行1次寒假刮刮乐活动（2017年01月26日04:59:59前使用有效）",
    test_descript = "手感冰凉的神奇奖券，可进行1次寒假刮刮乐活动（2017年01月02日04:59:59前使用有效）",
    rescourse = {
      "2017年寒假活动"
    },
    unit = "张",
    double_type = 0,
    apply = "ScratchRewardDlg"
  },
  ["圈圈运动仪"] = {
    icon = 1640,
    unit = "枚",
    descript = "寒假活动道具，在天墉城使用后开启踩圈圈挑战，你准备好了吗？（活动结束道具回收）",
    rescourse = {
      "2017年寒假活动"
    },
    double_type = 2
  },
  ["圈圈发生仪"] = {
    icon = 1640,
    unit = "枚",
    descript = "寒假活动道具，在天墉城使用后开启踩圈圈挑战，你准备好了吗？（活动结束道具回收）",
    rescourse = {
      "2017年寒假活动"
    },
    double_type = 2
  },
  ["雪人娃娃"] = {
    icon = 8072,
    descript = "寒假活动道具，使用后可在原地堆砌雪人（活动结束道具回收）",
    double_type = 2,
    rescourse = {
      "2017年寒假活动"
    },
    unit = "个"
  },
  ["紫气鸿蒙"] = {
    icon = 9210,
    descript = "使用后可以得到200点紫气鸿蒙点数的神奇道具，开启紫气鸿蒙后可使刷道战斗额外获得道法奖励，一阶降妖、伏魔每场消耗4点，二阶降妖、伏魔每场消耗8点，一阶飞仙渡邪每场消耗16点，二阶飞仙渡邪每场消耗32点",
    isCanDouble = true,
    rescourse = {
      "#@在线商城|OnlineMallDlg=紫气鸿蒙#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:紫气鸿蒙#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=紫气鸿蒙#P"
    },
    use_level = 70,
    double_type = 1,
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R70级#n后方可使用。",
    unit = "道",
    coin = 418,
    canApplyAll = true,
    color = "金色"
  },
  ["【丁酉春节】新年礼包"] = {
    icon = 8009,
    descript = "内含1块超级晶石，1颗点化丹",
    rescourse = {
      "2017年春节活动"
    }
  },
  ["【丁酉春节】登录礼包"] = {
    icon = 8010,
    descript = "内含1颗宠物强化丹，1瓶超级归元露，1颗超级黑水晶",
    rescourse = {
      "2017年春节活动"
    }
  },
  ["【丁酉春节】日常消耗礼包"] = {
    icon = 8001,
    descript = "内含1颗血玲珑，1颗法玲珑",
    rescourse = {
      "2017年春节活动"
    }
  },
  ["【丁酉春节】宠物强化礼包"] = {
    icon = 9107,
    descript = "内含3颗超级神兽丹，3瓶超级归元露，3颗宠物强化丹，3颗点化丹",
    rescourse = {
      "2017年春节活动"
    }
  },
  ["【丁酉春节】豪华刷道礼包"] = {
    icon = 9108,
    descript = "内含10包超级仙风散，10包宠风散，5个急急如律令，5道紫气鸿蒙",
    rescourse = {
      "2017年春节活动"
    }
  },
  ["【丁酉春节】装备改造礼包"] = {
    icon = 9109,
    descript = "内含20块超级灵石，20块超级晶石",
    rescourse = {
      "2017年春节活动"
    }
  },
  ["【丁酉春节】豪华骑宠礼包"] = {
    icon = 8063,
    descript = "内含10袋精怪诱饵，5个灵物囊，3颗聚灵石",
    rescourse = {
      "2017年春节活动"
    }
  },
  ["【丁酉春节】装备炼化礼包"] = {
    icon = 8063,
    descript = "内含4颗超级粉水晶，24颗黄水晶，4颗超级绿水晶",
    rescourse = {
      "2017年春节活动"
    }
  },
  ["糖葫芦"] = {
    icon = 9183,
    descript = "香甜爽口的糖葫芦，不来一串吗。卖给揽仙镇的居民，可换取新年钱币",
    double_type = 0,
    rescourse = {
      "2018年春节活动"
    },
    unit = "串"
  },
  ["中国结"] = {
    icon = 8910,
    descript = "象征着吉祥如意的中国结。卖给揽仙镇的居民，可换取新年钱币",
    double_type = 0,
    rescourse = {
      "2018年春节活动"
    },
    unit = "个"
  },
  ["新衣裳"] = {
    icon = 1260,
    descript = "过新年，就要穿新衣。卖给揽仙镇的居民，可换取新年钱币",
    double_type = 0,
    rescourse = {
      "2018年春节活动"
    },
    unit = "件"
  },
  ["多情桃花"] = {
    icon = 1650,
    descript = "多情桃精的桃花，代表着人间的缘分与真情 ",
    double_type = 2,
    rescourse = {
      "2017年情人节活动"
    },
    unit = "片 "
  },
  ["绝情寒冰"] = {
    icon = 1651,
    descript = "绝情雪女掉落的寒冰块，代表着人间的决然与冷漠  ",
    double_type = 2,
    rescourse = {
      "2017年情人节活动"
    },
    unit = "块"
  },
  ["情意桃花糕"] = {
    icon = 1652,
    descript = "由多情桃花制成，具有暖心忆情的神奇糕点 ",
    double_type = 2,
    rescourse = {
      "2017年情人节活动"
    },
    unit = "块 "
  },
  ["淡忧忘情水"] = {
    icon = 1653,
    descript = "由绝情寒冰制成，具有忘情消愁之效的神奇药水 ",
    double_type = 2,
    rescourse = {
      "2017年情人节活动"
    },
    unit = "壶 "
  },
  ["空白姻缘签"] = {
    icon = 1654,
    descript = "月老给的空白的姻缘签，等待你写上自己对姻缘的愿景 ",
    double_type = 2,
    rescourse = {
      "2017年情人节活动"
    },
    unit = "张"
  },
  ["姻缘签"] = {
    icon = 1655,
    descript = "写有道友对姻缘最诚心的愿景，快将其挂上姻缘树祈愿吧。通过点击相关任务提示可前往姻缘树挂上姻缘签 ",
    double_type = 2,
    rescourse = {
      "2017年情人节活动"
    },
    unit = "张"
  },
  ["空白祝福签"] = {
    icon = 1654,
    descript = "小岚给的空白的祝福签，等待你写上对他们的祝福",
    double_type = 2,
    rescourse = {
      "水岚之缘祝福活动"
    },
    unit = "张"
  },
  ["祝福签"] = {
    icon = 1606,
    descript = "写有道友对小水和小岚最诚心的祝福，快将其挂上桃花树祈愿吧。通过点击相关任务提示可前往桃花树挂上祝福签",
    double_type = 2,
    rescourse = {
      "水岚之缘祝福活动"
    },
    unit = "张"
  },
  ["古树灵物"] = {
    icon = 1697,
    descript = "古树的灵物，可用于召唤古树护卫，击败恶灵大将后还可用于强化古树护卫的能力与获得大地的祝福",
    double_type = 0,
    rescourse = {
      "2017年植树节活动"
    },
    unit = "个 "
  },
  ["黑驴蹄子"] = {
    icon = 1657,
    descript = "专门克制#R僵尸#n的驱邪法器，可令僵尸失去行动能力。仅限战斗中使用（点击战斗操作栏中的道具按钮，选中黑驴蹄子后再选择敌方对应目标）",
    double_type = 2,
    rescourse = {
      "2017年清明节活动"
    },
    unit = "只",
    effect_in_combat = "克制僵尸"
  },
  ["桃木剑"] = {
    icon = 1658,
    descript = "专门克制#R恶鬼#n的驱邪法器，可令恶鬼失去大量气血。仅限战斗中使用（点击战斗操作栏中的道具按钮，选中桃木剑后再选择敌方对应目标）",
    double_type = 2,
    rescourse = {
      "2017年清明节活动"
    },
    unit = "把",
    effect_in_combat = "克制恶鬼"
  },
  ["照妖玄镜"] = {
    icon = 1659,
    descript = "专门克制#R花妖#n的驱邪法器，可令花妖陷入眩晕无法惑人。仅限战斗中使用（点击战斗操作栏中的道具按钮，选中照妖玄镜后再选择敌方对应目标）",
    double_type = 2,
    rescourse = {
      "2017年清明节活动"
    },
    unit = "面",
    effect_in_combat = "克制花妖"
  },
  ["通宝"] = {
    icon = 1660,
    descript = "天地人三界中皆可使用的珍贵货币，可交予轩辕庙处的驱邪道人兑换商城道具奖励（2017年04月07日04:59:59前使用有效）",
    test_descript = "天地人三界中皆可使用的珍贵货币，可交予轩辕庙处的驱邪道人兑换商城道具奖励（2017年03月09日04:59:59前使用有效）",
    double_type = 0,
    rescourse = {
      "2017年清明节活动"
    },
    unit = "个"
  },
  ["清明祭品"] = {
    icon = 1656,
    descript = "祭拜时所用的各类香烛祭品",
    double_type = 0,
    rescourse = {
      "2017年清明节活动"
    },
    unit = "套",
    need_stop_walk_before_use = true
  },
  ["不可名状的材料"] = {
    icon = 1779,
    descript = "一团黏糊不可名状的物质，看一眼就让人毛骨悚然",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】拜访杜卜思",
    unit = "个"
  },
  ["异常柔软的石材"] = {
    icon = 1678,
    descript = "明明是石材却异常柔软，甚至可以弯曲",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】野外探索",
    unit = "个"
  },
  ["韧性十足的木条"] = {
    icon = 1683,
    descript = "韧性十足的木条，用力弯曲都不会折断",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】野外探索",
    unit = "个"
  },
  ["粗糙的木块"] = {
    icon = 1680,
    descript = "粗糙的木块，毫无用处",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】野外探索",
    unit = "个"
  },
  ["粗糙的石材"] = {
    icon = 1677,
    descript = "粗糙的石材，毫无用处",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】野外探索",
    unit = "个"
  },
  ["神秘材料"] = {
    icon = 1779,
    descript = "神秘的材料，质地坚硬，到底要怎样用呢",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】灵兽异人",
    unit = "个"
  },
  ["装好的礼物"] = {
    icon = 1578,
    descript = "已经装好的礼物盒，真好奇里面到底装的什么",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】讨伐熊妖",
    unit = "个"
  },
  ["水草耙"] = {
    icon = 1512,
    descript = "为了捞水草特制的草耙",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】捞水草",
    unit = "个"
  },
  ["水草"] = {
    icon = 1868,
    descript = "东海渔村特有的水草，夜晚会发出五彩荧光",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    item_task = "【委托】捞水草",
    unit = "个"
  },
  ["未发放的礼物"] = {
    icon = 1578,
    descript = "还没有发放的愚人节礼物，诚意十足还是愚人满满由你选择",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    unit = "个"
  },
  ["愚人节礼物"] = {
    icon = 1578,
    descript = "精致的愚人节礼物，里面到底装着什么呢？",
    double_type = 0,
    rescourse = {
      "2017年愚人节活动"
    },
    unit = "个"
  },
  ["刷道卷轴"] = {
    icon = 7705,
    unit = "本",
    descript = "当日活跃度达50点后可使用，使用后可获得10轮全局刷道战斗（角色等级<80级时为一阶降妖战斗，>=80级为一阶伏魔战斗）道行、武学奖励（双倍、宠风散点数有效），但不获得其他奖励，每日使用上限为5次。使用刷道卷轴可获得5%的队长额外道行、武学奖励",
    double_type = 0,
    rescourse = {
      "回归礼包"
    },
    use_level = 45,
    level_tip = "角色等级达到#R45级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["消储经验丹"] = {
    icon = 2003,
    unit = "颗",
    descript = "当日活跃度达80点后可使用，使用后可将当前储备经验的50%直接转化为人物经验，每日使用上限为1次",
    double_type = 0,
    rescourse = {
      "回归礼包"
    },
    use_level = 35,
    level_tip = "角色等级达到#R35级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["萝卜"] = {
    icon = 1508,
    unit = "个",
    descript = "又脆又甜的萝卜，交给千面怪可获得奖励",
    double_type = 0,
    rescourse = {
      "萝卜桃子大收集"
    }
  },
  ["大萝卜"] = {
    icon = 1572,
    unit = "个",
    descript = "个头比较大的萝卜，交给千面怪可获得更多的奖励",
    double_type = 0,
    rescourse = {
      "萝卜桃子大收集"
    }
  },
  ["桃子"] = {
    icon = 1507,
    unit = "个",
    descript = "熟透的桃子，交给千面怪可获得奖励",
    double_type = 0,
    rescourse = {
      "萝卜桃子大收集"
    }
  },
  ["大桃子"] = {
    icon = 1573,
    unit = "个",
    descript = "熟透的桃子，让人忍不住想咬一口，交给千面怪可获得奖励",
    double_type = 0,
    rescourse = {
      "萝卜桃子大收集"
    }
  },
  ["欺诈萝卜"] = {
    icon = 1574,
    unit = "个",
    descript = "一个假萝卜，可以放在地上用来骗人",
    double_type = 0,
    rescourse = {
      "萝卜桃子大收集"
    }
  },
  ["欺诈桃子"] = {
    icon = 1575,
    unit = "个",
    descript = "一个假桃子，可以放在地上用来骗人",
    double_type = 0,
    rescourse = {
      "萝卜桃子大收集"
    }
  },
  ["猎人陷阱"] = {
    icon = 1576,
    unit = "个",
    descript = "猎人用来捕捉野兽的陷阱，使用后可放置一个陷阱，把人夹住",
    double_type = 0,
    rescourse = {
      "萝卜桃子大收集"
    }
  },
  ["传送符"] = {
    icon = 1577,
    unit = "个",
    descript = "可以直接传送到千面怪面前，但偶尔也会出点意外",
    double_type = 0,
    rescourse = {
      "萝卜桃子大收集"
    }
  },
  ["周年庆五行石"] = {
    icon = 1661,
    unit = "颗 ",
    descript = "周年狂欢，五行送福，活动期间参与修行、十绝阵、师门、除暴、刷道任务、2017年周年庆各活动均有机会获得周年庆五行石奖励，可在周年庆五行商店兑换各种珍稀奖励#R（请在活动期间内尽快使用，活动结束时将被销毁）#n",
    double_type = 0,
    rescourse = {
      "2017年周年庆活动"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["元神碎片·问羽"] = {
    icon = 1662,
    unit = "片",
    descript = "2017年周年庆纪念宠问羽的元神碎片，集齐100个并使用后可召唤问羽",
    double_type = 0,
    rescourse = {
      "2017年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·问羽#@"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["元神碎片·鸿道"] = {
    icon = 1663,
    unit = "片",
    descript = "2017年周年庆纪念宠鸿道的元神碎片，集齐100个并使用后可召唤鸿道",
    double_type = 0,
    rescourse = {
      "2017年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·鸿道#@"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["元神碎片·白灵"] = {
    icon = 1945,
    unit = "片",
    descript = "2018年周年庆纪念宠白灵的元神碎片，集齐100个并使用后可召唤白灵",
    double_type = 0,
    rescourse = {
      "2018年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·白灵#@"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["元神碎片·迅影"] = {
    icon = 1946,
    unit = "片",
    descript = "2018年周年庆纪念宠迅影的元神碎片，集齐100个并使用后可召唤迅影",
    double_type = 0,
    rescourse = {
      "2018年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·迅影#@"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["元神碎片·回雪"] = {
    icon = 2166,
    unit = "片",
    descript = "2020年周年庆纪念宠回雪的元神碎片，集齐100个并使用后可召唤回雪",
    double_type = 0,
    rescourse = {
      "2020年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·回雪#@"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["元神碎片·流风"] = {
    icon = 2165,
    unit = "片",
    descript = "2020年周年庆纪念宠流风的元神碎片，集齐100个并使用后可召唤流风",
    double_type = 0,
    rescourse = {
      "2020年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·流风#@"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["周年庆抽奖券"] = {
    icon = 1664,
    unit = "张",
    use_level = 30,
    descript = "周年抽奖乐翻天，使用此券可在周年抽奖界面进行一次抽奖，有机会获得随机变异宠物、北极熊等，还有机会获得周年庆礼盒，内含周年庆绝版周边及珍稀纪念宠鸿道（宝宝）#R（请在活动结束时间：2017-05-12 04:59:59前尽快使用，活动结束时该道具将失效）#n",
    rescourse = {
      "2017年周年庆活动"
    },
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["周年庆礼盒"] = {
    icon = 1665,
    unit = "个",
    use_level = 30,
    descript = "价值888元的周年庆独有礼盒，内含周年庆绝版周边实物奖励，以及周年庆珍稀纪念宠鸿道（宝宝）#R（请在有效期内尽快使用）#n",
    rescourse = {
      "2017年周年庆活动"
    },
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["周年庆绝版周边"] = {
    icon = 1666,
    unit = "份",
    descript = "问道手游1周年精美绝版周边，惊喜将于收到包裹那一刻揭晓。请于2017-05-15 04:59前点击使用按钮来提交收货信息",
    rescourse = {
      "2017年周年庆活动"
    }
  },
  ["14天法宝体验券"] = {
    icon = 1667,
    unit = "张",
    descript = "使用该券可在活动大使处领取任意一个限时14天的8级法宝#R（请在有效期内尽快使用，有效期结束时将被销毁）#n",
    rescourse = {
      "2017年周年庆活动"
    }
  },
  ["【周年狂欢】活跃礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "2017年周年庆活动"
    },
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石"
  },
  ["【周年狂欢】登录礼包"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "2017年周年庆活动"
    },
    descript = "内含188银元宝、1颗点化丹、1颗宠物强化丹"
  },
  ["【周年狂欢】寻宝大礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2017年周年庆活动"
    },
    descript = "内含6张藏宝图、6张超级藏宝图"
  },
  ["【周年狂欢】宠物欢乐礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2017年周年庆活动"
    },
    descript = "内含3瓶超级归元露、2颗宠物强化丹、2颗宠物顿悟丹、3册天书"
  },
  ["【周年狂欢】豪华刷道礼包"] = {
    icon = 9108,
    unit = "个",
    rescourse = {
      "2017年周年庆活动"
    },
    descript = "内含10包超级仙风散、10包宠风散、5个急急如律令、5道紫气鸿蒙"
  },
  ["【周年狂欢】装备进阶礼包"] = {
    icon = 9109,
    unit = "个",
    rescourse = {
      "2017年周年庆活动"
    },
    descript = "内含3块超级灵石、3块超级晶石、1颗超级粉水晶、6颗黄水晶、1颗超级绿水晶"
  },
  ["【周年狂欢】豪华骑宠礼包"] = {
    icon = 8063,
    unit = "个",
    rescourse = {
      "2017年周年庆活动"
    },
    descript = "内含1袋精怪诱饵、6颗风灵丸、2颗聚灵石、2个4阶骑宠灵魄、4个2阶骑宠灵魄"
  },
  ["【周年狂欢】装备高级礼包"] = {
    icon = 8063,
    unit = "个",
    rescourse = {
      "2017年周年庆活动"
    },
    descript = "内含4颗超级圣水晶、4块混沌玉、3颗超级粉水晶、3颗超级绿水晶、18颗黄水晶"
  },
  ["矿石"] = {
    icon = 1580,
    unit = "块",
    rescourse = {
      "矿石大战"
    },
    descript = "在蓝毛巨兽和赤焰炼魔的世界里，矿石数代表着一切，拥有矿石就等于拥有荣誉。于矿石大战活动地图内采集初级矿石、中级矿石、高级矿石可获得#R（活动结束时将被销毁，并获得相应奖励）#n"
  },
  ["加速宝石"] = {
    icon = 1581,
    unit = "颗",
    rescourse = {
      "矿石大战"
    },
    descript = "可以在接下来的15秒内，使自身移动速度、采集速度得到显著提升的神奇道具，仅可在矿石大战地图中使用#R（活动结束时将被销毁）#n"
  },
  ["虚隐宝石"] = {
    icon = 1582,
    unit = "颗",
    rescourse = {
      "矿石大战"
    },
    descript = "可以在接下来的15秒内，使自身处于虚隐状态避免被敌族切磋的神奇道具，仅可在矿石大战地图中使用#R（活动结束时将被销毁）#n"
  },
  ["强力宝石"] = {
    icon = 1583,
    unit = "颗",
    rescourse = {
      "矿石大战"
    },
    descript = "在接下来的1场战斗中，使自身所有属性提升30%的神奇道具，可叠加使用，最多可叠加5层效果（即提升150%），战斗结束后提升效果全部消失，仅可在矿石大战地图中使用#R（活动结束时将被销毁）#n"
  },
  ["异族腰牌"] = {
    icon = 9150,
    unit = "枚",
    descript = "异族士兵携带的腰牌，作为击败异族的凭证，可用于义士晋升军衔",
    double_type = 0,
    rescourse = {
      "异族入侵"
    }
  },
  ["八仙的信物"] = {
    icon = 9695,
    unit = "个",
    descript = "八仙遗失的信物，交给八仙后他们会协助你击退异族",
    double_type = 0,
    rescourse = {
      "异族入侵"
    }
  },
  ["八仙玲珑骰"] = {
    icon = 1532,
    unit = "颗",
    descript = "凝聚了八仙力量的神秘骰子，可根据掷骰所得点数直接通关对应数量的八仙梦境副本，并获得对应奖励",
    double_type = 0,
    rescourse = {
      "八仙过海"
    }
  },
  ["仙粽"] = {
    icon = 1579,
    unit = "个",
    descript = "蕴含仙气的粽子，吃掉后会获得稀有奖励。#R(请在2017年05月31日04:59前食用)#n",
    test_descript = "蕴含仙气的粽子，吃掉后会获得稀有奖励。#R(请在2017年05月14日04:59前食用)#n",
    double_type = 0,
    rescourse = {
      "2017年端午节"
    }
  },
  ["刷道礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "内含1包超级仙风散、1包宠风散、1个急急如律令、1道紫气鸿蒙和328银元宝(道具价值1070元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限时特惠|OnlineMallDlg=刷道礼包#@"
    },
    color = "金色"
  },
  ["位列仙班·月卡礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "内含1套自选时装20天(与礼包使用者的性别一致)，位列仙班·月卡资格30天(礼包价值5000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=位列仙班·月卡礼包#@"
    }
  },
  ["位列仙班·季卡礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "内含1套自选时装40天(与礼包使用者的性别一致)，位列仙班·季卡资格90天(礼包价值13000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=位列仙班·季卡礼包#@"
    },
    color = "金色"
  },
  ["位列仙班·年卡礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含1套自选时装120天(与礼包使用者的性别一致)，位列仙班·年卡资格360天(礼包价值48000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=位列仙班·年卡礼包#@"
    },
    color = "金色"
  },
  ["位列仙班·月卡礼包2020"] = {
    icon = 9107,
    unit = "个",
    descript = "内含1套自选时装20天(与礼包使用者的性别一致，与获得礼包时商城中的出售列表范围一致)，位列仙班·月卡资格30天(礼包价值5000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=位列仙班·月卡礼包2020#@"
    }
  },
  ["位列仙班·季卡礼包2020"] = {
    icon = 9108,
    unit = "个",
    descript = "内含1套自选时装40天(与礼包使用者的性别一致，与获得礼包时商城中的出售列表范围一致)，位列仙班·季卡资格90天(礼包价值13000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=位列仙班·季卡礼包2020#@"
    },
    color = "金色"
  },
  ["位列仙班·年卡礼包2020"] = {
    icon = 9109,
    unit = "个",
    descript = "内含1套自选时装120天(与礼包使用者的性别一致，与获得礼包时商城中的出售列表范围一致)，位列仙班·年卡资格360天(礼包价值48000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=位列仙班·年卡礼包2020#@"
    },
    color = "金色"
  },
  ["水岚缘·月卡礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "内含1套峥岚衣/水光衫时装20天(与礼包使用者的性别一致)，位列仙班·月卡资格30天(礼包价值5000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=水岚缘·月卡礼包#@"
    }
  },
  ["水岚缘·季卡礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "内含1套峥岚衣/水光衫时装40天(与礼包使用者的性别一致)，位列仙班·季卡资格90天(礼包价值13000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=水岚缘·季卡礼包#@"
    }
  },
  ["水岚缘·年卡礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含1套峥岚衣/水光衫时装120天(与礼包使用者的性别一致)，位列仙班·年卡资格360天(礼包价值48000元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=水岚缘·年卡礼包#@"
    }
  },
  ["宠物成长礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "内含1颗点化丹、1颗宠物强化丹、1颗超级神兽丹和216银元宝(道具价值652元宝)",
    double_type = 2,
    rescourse = {
      "#@商城限时特惠|OnlineMallDlg=宠物成长礼包#@"
    }
  },
  ["1天太极熊体验券"] = {
    icon = 1668,
    unit = "张",
    descript = "使用后可获得一只限时1天的8阶太极熊，等级与使用者等级相同。#R（请在有效期间内尽快使用，有效期结束时将被销毁）#n ",
    double_type = 2,
    rescourse = {
      "稀有物品商店"
    }
  },
  ["妖劫咒"] = {
    icon = 9676,
    unit = "张",
    descript = "战斗中能够困住灵妖魂魄5回合的道家灵符",
    double_type = 0,
    rescourse = {
      "地劫第四劫"
    }
  },
  ["蒙尘的红灵珠"] = {
    icon = 8034,
    unit = "颗",
    descript = "一颗透出微弱红光的珠子，需要邮寄给好友后才能唤醒灵性",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    },
    item_class = ITEM_CLASS.SUMMER_2017_MCD
  },
  ["蒙尘的蓝灵珠"] = {
    icon = 8033,
    unit = "颗",
    descript = "一颗透出微弱蓝光的珠子，需要邮寄给好友后才能唤醒灵性",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    },
    item_class = ITEM_CLASS.SUMMER_2017_MCD
  },
  ["蒙尘的绿灵珠"] = {
    icon = 8032,
    unit = "颗",
    descript = "一颗透出微弱绿光的珠子，需要邮寄给好友后才能唤醒灵性",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    },
    item_class = ITEM_CLASS.SUMMER_2017_MCD
  },
  ["耀眼的红灵珠"] = {
    icon = 8028,
    unit = "颗",
    descript = "一颗迸发出耀眼红光的珠子，已被好友唤醒灵性，可大幅提升修道之人的攻击，最多可使用3颗，仅在【暑假】保卫渔村活动的战斗中生效",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    },
    item_class = ITEM_CLASS.SUMMER_2017_YCD
  },
  ["耀眼的蓝灵珠"] = {
    icon = 8027,
    unit = "颗",
    descript = "一颗迸发出耀眼蓝光的珠子，已被好友唤醒灵性，可大幅提升修道之人的防御，最多可使用3颗，仅在【暑假】保卫渔村活动的战斗中生效   ",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    },
    item_class = ITEM_CLASS.SUMMER_2017_YCD
  },
  ["耀眼的绿灵珠"] = {
    icon = 8029,
    unit = "颗",
    descript = "一颗迸发出耀眼绿光的珠子，已被好友唤醒灵性，可大幅提升修道之人的气血，最多可使用3颗，仅在【暑假】保卫渔村活动的战斗中生效",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    },
    item_class = ITEM_CLASS.SUMMER_2017_YCD
  },
  ["仙树苗"] = {
    icon = 8806,
    unit = "株",
    descript = "一株仙树幼苗，种下之后顷刻之间可化为参天大树",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    }
  },
  ["百年仙桃"] = {
    icon = 1507,
    unit = "个",
    descript = "仙树结出的神奇果实，凡人服用之后可周身通泰、寒暑莫侵，摘下之后要尽快吃掉",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    }
  },
  ["千年仙桃"] = {
    icon = 1573,
    unit = "个",
    descript = "仙树结出的神奇果实，修道之人服用之后可定心凝神、修身悟道，摘下之后要尽快吃掉",
    double_type = 0,
    rescourse = {
      "2017年暑假活动"
    }
  },
  ["九曲玲珑笔"] = {
    icon = 9704,
    unit = "支",
    descript = "上古时期遗留下来的神笔，笔尖一点，变化万千。能隐藏变身卡形象或变身为特殊形象，每次使用耗费1点耐久(神将类耗费2点)，每次使用持续4小时",
    double_type = 2,
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=九曲玲珑笔#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=九曲玲珑笔#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=九曲玲珑笔#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=九曲玲珑笔#Z"
    },
    color = "金色"
  },
  ["九曲玲珑笔·融合"] = {
    icon = 9704,
    unit = "支",
    descript = "上古时期遗留下来的神笔，笔尖一点，变化万千。能隐藏变身卡形象或变身为特殊形象，每次使用耗费1点耐久(神将类耗费2点)，每次使用持续4小时",
    double_type = 2,
    rescourse = {
      "#@合成|AlchemyDlg=九曲玲珑笔·融合#@"
    },
    color = "金色"
  },
  ["如意刷道令"] = {
    icon = 20002,
    unit = "枚",
    descript = "使用后可获得200点如意刷道令点数，队长开启后在完成刷道第十轮之后会自动继续领取任务，且领取任务时可以免除老君查岗，自动领取首轮任务时扣除10点，在刷道全局双倍期间不会消耗点数",
    double_type = 0,
    use_level = 45,
    level_tip = "角色等级达到#R45级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=如意刷道令#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=如意刷道令#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=如意刷道令#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=如意刷道令#Z"
    },
    canApplyAll = true
  },
  ["造化丹"] = {
    icon = 2005,
    unit = "颗",
    descript = "使用后体内会积攒造化之力，当每日达到一定活跃度后可吸收造化之力，获得大量经验与储备经验 ",
    double_type = 0,
    rescourse = {
      "【福利】造化之池"
    }
  },
  ["千秋梦"] = {
    icon = 9500,
    unit = "套",
    gender = 1,
    descript = "昨日汉宫秋夜暖，月染雕栏玉如纱。一枕黄粱千秋梦，只忆相思万古长。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "汉宫秋",
    color = "金色"
  },
  ["汉宫秋"] = {
    icon = 9501,
    unit = "套",
    gender = 2,
    descript = "昨日汉宫秋夜暖，月染雕栏玉如纱。一枕黄粱千秋梦，只忆相思万古长。女子使用后将会身着华美的服饰 ",
    double_type = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "千秋梦",
    color = "金色"
  },
  ["龙吟水"] = {
    icon = 9502,
    unit = "套",
    gender = 1,
    descript = "龙吟水上，凤鸣空野，刀剑行世间。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "凤鸣空",
    color = "金色"
  },
  ["凤鸣空"] = {
    icon = 9503,
    unit = "套",
    gender = 2,
    descript = "龙吟水上，凤鸣空野，刀剑行世间。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "龙吟水",
    color = "金色"
  },
  ["峥岚衣"] = {
    icon = 9504,
    unit = "套",
    gender = 1,
    descript = "气定天下怡然色，仗剑当空千里去。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "水光衫",
    color = "金色"
  },
  ["水光衫"] = {
    icon = 9505,
    unit = "套",
    gender = 2,
    descript = "昔有佳人水光色，一舞剑器动四方。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "峥岚衣",
    color = "金色"
  },
  ["如意年"] = {
    icon = 9506,
    unit = "套",
    gender = 1,
    descript = "爆竹声声如意年，九洲同庆吉祥天。稚童新衣相夸耀，旧去新来气象清。男子使用后将会身着华美的服饰",
    func = "\n#R(购买后可获得如意年时装并赠送1只萌萌的跟宠%s，使用期限与对应时装相同)#n",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=如意年#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "吉祥天",
    color = "金色"
  },
  ["吉祥天"] = {
    icon = 9507,
    unit = "套",
    gender = 2,
    descript = "爆竹声声如意年，九洲同庆吉祥天。稚童新衣相夸耀，旧去新来气象清。女子使用后将会身着华美的服饰",
    func = "\n#R(购买后可获得吉祥天时装并赠送1只萌萌的跟宠%s，使用期限与对应时装相同)#n",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=吉祥天#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "如意年",
    color = "金色"
  },
  ["狐灵逸"] = {
    icon = 9510,
    unit = "套",
    gender = 1,
    descript = "山有狐兮，月有灵兮。山隐其行，月影其容。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "再续前缘活动",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "狐灵娇",
    color = "金色"
  },
  ["狐灵娇"] = {
    icon = 9511,
    unit = "套",
    gender = 2,
    descript = "山有狐兮，月有灵兮。山隐其行，月影其容。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "再续前缘活动",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "狐灵逸",
    color = "金色"
  },
  ["星寒魄"] = {
    icon = 9508,
    unit = "套",
    gender = 1,
    descript = "星随月孤，影魄相依。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "道心特权活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "月孤影",
    custom_tips = "道心会员专属",
    color = "金色"
  },
  ["月孤影"] = {
    icon = 9509,
    unit = "套",
    gender = 2,
    descript = "星随月孤，影魄相依。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "道心特权活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "星寒魄",
    custom_tips = "道心会员专属",
    color = "金色"
  },
  ["陆吾曦光"] = {
    icon = 9530,
    unit = "套",
    gender = 1,
    descript = "天微明晨星现，日初升曦光呈。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "道心特权活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "陆吾晨星",
    custom_tips = "道心会员专属",
    color = "金色"
  },
  ["陆吾晨星"] = {
    icon = 9531,
    unit = "套",
    gender = 2,
    descript = "天微明晨星现，日初升曦光呈。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "道心特权活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "陆吾曦光",
    custom_tips = "道心会员专属",
    color = "金色"
  },
  ["日耀辰辉"] = {
    icon = 9514,
    unit = "套",
    gender = 1,
    descript = "日耀大泽，星垂平野，万里天地乘风。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=日耀辰辉#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "星垂月涌",
    color = "金色"
  },
  ["星垂月涌"] = {
    icon = 9515,
    unit = "套",
    gender = 2,
    descript = "日耀大泽，星垂平野，万里天地乘风。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=星垂月涌#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "日耀辰辉",
    color = "金色"
  },
  ["星火昭"] = {
    icon = 9516,
    unit = "套",
    gender = 1,
    descript = "平沙莽莽起星火，胡琴旷野点红烛。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=星火昭#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "点红烛",
    color = "金色"
  },
  ["点红烛"] = {
    icon = 9517,
    unit = "套",
    gender = 2,
    descript = "平沙莽莽起星火，胡琴旷野点红烛。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=点红烛#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "星火昭",
    color = "金色"
  },
  ["剑魄琴心"] = {
    icon = 9518,
    unit = "套",
    gender = 1,
    descript = "欲将心事付瑶琴。知音少，弦断有谁听？男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=剑魄琴心#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "引天长歌",
    color = "金色"
  },
  ["引天长歌"] = {
    icon = 9519,
    unit = "套",
    gender = 2,
    descript = "欲将心事付瑶琴。知音少，弦断有谁听？女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=引天长歌#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "剑魄琴心",
    color = "金色"
  },
  ["踏雪寻梅"] = {
    icon = 9520,
    unit = "套",
    gender = 1,
    descript = "紫岚故梦暖絮扬，踏雪寻梅暗香凛。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=踏雪寻梅#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "紫岚故梦",
    color = "金色"
  },
  ["紫岚故梦"] = {
    icon = 9521,
    unit = "套",
    gender = 2,
    descript = "紫岚故梦暖絮扬，踏雪寻梅暗香凛。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=紫岚故梦#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "踏雪寻梅",
    color = "金色"
  },
  ["镇星辰"] = {
    icon = 9522,
    unit = "套",
    gender = 1,
    descript = "玄冥行令肃冰霜，稳看腾踏上星辰。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=镇星辰#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "玄冥临",
    color = "金色"
  },
  ["玄冥临"] = {
    icon = 9523,
    unit = "套",
    gender = 2,
    descript = "玄冥行令肃冰霜，稳看腾踏上星辰。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=玄冥临#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "镇星辰",
    color = "金色"
  },
  ["极道棋魂"] = {
    icon = 9532,
    unit = "套",
    gender = 1,
    descript = "棋道虽缥缈，静气且凝神，燃魂入知命，养心悟机要。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "新服活动",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "仙道棋心",
    color = "金色"
  },
  ["仙道棋心"] = {
    icon = 9533,
    unit = "套",
    gender = 2,
    descript = "棋道虽缥缈，静气且凝神，燃魂入知命，养心悟机要。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "新服活动",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "极道棋魂",
    color = "金色"
  },
  ["高级宠物经验丹"] = {
    icon = 1950,
    unit = "颗",
    descript = "等级达到#R70级#n的非野生宠物使用后将获得海量经验奖励",
    apply = "PetAttribDlg",
    use_level = 70,
    try_level_tip = "适用等级：角色大于等于%d级",
    level_tip = "角色等级达到#R70级#n后开放该功能。",
    rescourse = {
      "#P声望商店|竞技使者|M=声望商店::ArenaStoreDlg=高级宠物经验丹#P",
      "#@帮派商店|PartyShopDlg=高级宠物经验丹#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:宠物经验丹:高级宠物经验丹#@"
    }
  },
  ["金光符"] = {
    icon = 1933,
    unit = "道",
    descript = "结金光为符令，光华外着，法威强大，乃降魔卫道之利器，仅在【中元节】度化游魂活动的战斗中生效",
    double_type = 0,
    rescourse = {
      "2017年中元节活动"
    }
  },
  ["重阳糕"] = {
    icon = 1934,
    unit = "份",
    descript = "亦称“花糕”，传统重阳节食品 ",
    double_type = 0,
    rescourse = {
      "2017年重阳节活动"
    }
  },
  ["菊花酒"] = {
    icon = 1935,
    unit = "份",
    descript = "古称长寿酒，其味清凉甜美，有养肝、明目、健脑、延缓衰老等功效 ",
    double_type = 0,
    rescourse = {
      "2017年重阳节活动"
    }
  },
  ["爽滑羊肉面"] = {
    icon = 1936,
    unit = "份",
    descript = "口感爽滑，食用后补气滋阴、暖中补虚、开胃健力 ",
    double_type = 0,
    rescourse = {
      "2017年重阳节活动"
    }
  },
  ["可口大盘蟹"] = {
    icon = 1937,
    unit = "份",
    descript = "盘大量足，色泽红亮，蟹肉细嫩，鲜香可口  ",
    double_type = 0,
    rescourse = {
      "2017年重阳节活动"
    }
  },
  ["喷香牛肉煲"] = {
    icon = 1938,
    unit = "份",
    descript = "散发着诱人气息的美味牛肉煲，食用后滋养脾胃、强健筋骨  ",
    double_type = 0,
    rescourse = {
      "2017年重阳节活动"
    }
  },
  ["居所空间改造券"] = {
    icon = 1669,
    unit = "张",
    descript = "使用该券可在郝艾佳处免费进行一次居所空间改造#R（仅可用于空间改造，无法用于居所升级）#n",
    double_type = 2
  },
  ["随机道具礼盒"] = {
    icon = 1665,
    unit = "个",
    descript = "使用后随机获得奖品列表中除超级女娲石外的任意道具奖励，有机会抽中召唤令·十二生肖！",
    rescourse = {
      "充值积分活动",
      "消费积分活动"
    }
  },
  ["谦谦有礼礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含1套龙吟水/凤鸣空时装30天(与礼包使用者的性别一致)、位列仙班·月卡资格30天(道具价值5888元宝)",
    double_type = 2,
    not_sell = 1,
    rescourse = {
      "#@商城限购|OnlineMallDlg=谦谦有礼礼包#@"
    }
  },
  ["【国庆】活跃礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含1包超级仙风散、1颗宠物顿悟丹"
  },
  ["【国庆】登录礼包"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含2颗超级神兽丹、1个火眼金睛、1颗超级黑水晶"
  },
  ["【国庆】超级寻宝礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含4张超级藏宝图、4串钥匙串"
  },
  ["【国庆】宠物强化礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含2颗宠物强化丹、2册天书、2颗点化丹、2颗宠物顿悟丹"
  },
  ["【国庆】召唤骑宠礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含1袋精怪诱饵、5袋灵物囊、2颗聚灵石"
  },
  ["【国庆】强力刷道礼包"] = {
    icon = 9108,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含9包超级仙风散、5个急急如律令、10道紫气鸿蒙、10包宠风散"
  },
  ["【国庆】装备打造礼包"] = {
    icon = 9109,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含16颗黄水晶、2颗超级粉水晶、2颗超级绿水晶"
  },
  ["【国庆】装备升级礼包"] = {
    icon = 8063,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含8块超级晶石、10块超级灵石、6颗超级圣水晶、3颗超级粉水晶、6颗超级绿水晶"
  },
  ["健体羹(1品)"] = {
    icon = 14001,
    unit = "碗",
    item_level = 1,
    rescourse = {
      "居所烹饪"
    },
    descript = "使用一些小虾和蔬菜就可做成的1品健体羹，美味又实惠",
    func = "#G战斗中使用，气血恢复25000点。战斗外使用，增加33300点气血储备#n",
    effect_in_combat = "气血恢复25000点",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["健体羹(2品)"] = {
    icon = 14002,
    unit = "碗",
    item_level = 2,
    rescourse = {
      "居所烹饪"
    },
    descript = "使用常见的小黄鱼和蔬菜就可做成的2品健体羹，美味又实惠",
    func = "#G战斗中使用，气血恢复30000点。战斗外使用，增加40500点气血储备#n",
    effect_in_combat = "气血恢复30000点",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["健体羹(3品)"] = {
    icon = 14003,
    unit = "碗",
    item_level = 3,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:健体羹:3品#@",
      "居所烹饪"
    },
    descript = "使用鲶鱼和蔬菜炖制而成的3品健体羹，实乃上品",
    func = "#G战斗中使用，气血恢复50%。战斗外使用，增加51000点气血储备#n",
    effect_in_combat = "气血恢复50%",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["健体羹(4品)"] = {
    icon = 14004,
    unit = "碗",
    item_level = 4,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:健体羹:4品#@",
      "居所烹饪"
    },
    descript = "使用鲤鱼和蔬菜炖制而成的4品健体羹，实乃上品",
    func = "#G战斗中使用，气血恢复60%。战斗外使用，增加60000点气血储备#n",
    effect_in_combat = "气血恢复60%",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["健体羹(5品)"] = {
    icon = 14005,
    unit = "碗",
    item_level = 5,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:健体羹:5品#@",
      "居所烹饪"
    },
    descript = "使用珍稀的多宝鱼和蔬菜炖制而成的5品健体羹，补血极品",
    func = "#G战斗中使用，气血恢复70%。战斗外使用，增加99000点气血储备#n",
    effect_in_combat = "气血恢复70%",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["安神羹(1品)"] = {
    icon = 14006,
    unit = "碗",
    item_level = 1,
    rescourse = {
      "居所烹饪"
    },
    descript = "使用一些小蟹和蔬菜就可做成的1品安神羹，补气佳肴，美味又实惠",
    func = "#G战斗中使用，法力恢复15000点。战斗外使用，增加18000点法力储备#n",
    effect_in_combat = "法力恢复15000点",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["安神羹(2品)"] = {
    icon = 14007,
    unit = "碗",
    item_level = 2,
    rescourse = {
      "居所烹饪"
    },
    descript = "使用常见的草鱼和蔬菜就可做成的2品安神羹，补气佳肴，美味又实惠",
    func = "#G战斗中使用，法力恢复20000点。战斗外使用，增加24000点法力储备#n",
    effect_in_combat = "法力恢复20000点",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["安神羹(3品)"] = {
    icon = 14008,
    unit = "碗",
    item_level = 3,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:安神羹:3品#@",
      "居所烹饪"
    },
    descript = "使用泥鳅和蔬菜炖制而成的3品安神羹，补气上品",
    func = "#G战斗中使用，法力恢复50%。战斗外使用，增加30000点法力储备#n",
    effect_in_combat = "法力恢复50%",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["安神羹(4品)"] = {
    icon = 14009,
    unit = "碗",
    item_level = 4,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:安神羹:4品#@",
      "居所烹饪"
    },
    descript = "使用河豚和蔬菜炖制而成的4品安神羹，补气上品",
    func = "#G战斗中使用，法力恢复60%。战斗外使用，增加35000点法力储备#n",
    effect_in_combat = "法力恢复60%",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["安神羹(5品)"] = {
    icon = 14010,
    unit = "碗",
    item_level = 5,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:安神羹:5品#@",
      "居所烹饪"
    },
    descript = "使用珍稀的石斑鱼和蔬菜炖制而成的5品安神羹，补气极品",
    func = "#G战斗中使用，法力恢复70%。战斗外使用，增加50000点法力储备#n",
    effect_in_combat = "法力恢复70%",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["秘制鱼汤(1品)"] = {
    icon = 14011,
    unit = "碗",
    item_level = 1,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:秘制鱼汤:1品#@",
      "居所烹饪"
    },
    descript = "使用传说中的青龙鱼秘制而成的1品鲜鱼汤，气血、法力双补，是不可多得的圣品",
    func = "#G战斗中使用，气血恢复20%，法力恢复20%。战斗外使用，增加108000点气血储备#n",
    effect_in_combat = "气血恢复20%，法力恢复20%",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["秘制鱼汤(2品)"] = {
    icon = 14012,
    unit = "碗",
    item_level = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:秘制鱼汤:2品#@",
      "居所烹饪"
    },
    descript = "使用传说中的鲨鱼秘制而成的2品鲜鱼汤，气血、法力双补，是不可多得的圣品",
    func = "#G战斗中使用，气血恢复30%，法力恢复30%。战斗外使用，增加53000点法力储备#n",
    effect_in_combat = "气血恢复30%，法力恢复30%",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["灵芝鱼丸(1品)"] = {
    icon = 14013,
    unit = "颗",
    item_level = 1,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:灵芝鱼丸:1品#@",
      "居所烹饪"
    },
    descript = "灵芝与小黄鱼制作而成的1品药膳大补鱼丸",
    func = "#G食用后基础防御增加5%，维持10分钟，食用相同鱼丸可叠加时间，最多可叠加至30分钟（在刷道战斗及与玩家的战斗中无效）#n",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["灵芝鱼丸(2品)"] = {
    icon = 14014,
    unit = "颗",
    item_level = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:灵芝鱼丸:2品#@",
      "居所烹饪"
    },
    descript = "灵芝与泥鳅制作而成的2品药膳大补鱼丸",
    func = "#G食用后基础防御增加10%，维持10分钟，食用相同鱼丸可叠加时间，最多可叠加至30分钟（在刷道战斗及与玩家的战斗中无效）#n",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["灵芝鱼丸(3品)"] = {
    icon = 14015,
    unit = "颗",
    item_level = 3,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:灵芝鱼丸:3品#@",
      "居所烹饪"
    },
    descript = "灵芝与多宝鱼制作而成的3品药膳大补鱼丸",
    func = "#G食用后基础防御增加15%，维持10分钟，食用相同鱼丸可叠加时间，最多可叠加至30分钟（在刷道战斗及与玩家的战斗中无效）#n",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["灵芝鱼丸(4品)"] = {
    icon = 14016,
    unit = "颗",
    item_level = 4,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:灵芝鱼丸:4品#@",
      "居所烹饪"
    },
    descript = "灵芝与青龙鱼制作而成的4品药膳大补鱼丸",
    func = "#G食用后基础防御增加20%，维持10分钟，食用相同鱼丸可叠加时间，最多可叠加至30分钟（在刷道战斗及与玩家的战斗中无效）#n",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["人参鱼丸(1品)"] = {
    icon = 14017,
    unit = "颗",
    item_level = 1,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:人参鱼丸:1品#@",
      "居所烹饪"
    },
    descript = "移山参与草鱼制作而成的1品药膳大补鱼丸",
    func = "#G食用后基础伤害增加1%，维持10分钟，食用相同鱼丸可叠加时间，最多可叠加至30分钟（在刷道战斗及与玩家的战斗中无效）#n",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["人参鱼丸(2品)"] = {
    icon = 14018,
    unit = "颗",
    item_level = 2,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:人参鱼丸:2品#@",
      "居所烹饪"
    },
    descript = "移山参与鲤鱼制作而成的2品药膳大补鱼丸",
    func = "#G食用后基础伤害增加2%，维持10分钟，食用相同鱼丸可叠加时间，最多可叠加至30分钟（在刷道战斗及与玩家的战斗中无效）#n",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["人参鱼丸(3品)"] = {
    icon = 14019,
    unit = "颗",
    item_level = 3,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:人参鱼丸:3品#@",
      "居所烹饪"
    },
    descript = "移山参与石斑鱼制作而成的3品药膳大补鱼丸",
    func = "#G食用后基础伤害增加4%，维持10分钟，食用相同鱼丸可叠加时间，最多可叠加至30分钟（在刷道战斗及与玩家的战斗中无效）#n",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["人参鱼丸(4品)"] = {
    icon = 14020,
    unit = "颗",
    item_level = 4,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=菜肴:人参鱼丸:4品#@",
      "居所烹饪"
    },
    descript = "移山参与鲨鱼制作而成的4品药膳大补鱼丸",
    func = "#G食用后基础伤害增加6%，维持10分钟，食用相同鱼丸可叠加时间，最多可叠加至30分钟（在刷道战斗及与玩家的战斗中无效）#n",
    item_class = ITEM_CLASS.CAIYAO
  },
  ["河虾"] = {
    icon = 13201,
    unit = "只",
    rescourse = {
      "居所钓鱼"
    },
    descript = "河虾常居于池塘中的，肉质鲜嫩可口",
    level = 1,
    func = "食用后增加132000点气血储备",
    item_class = ITEM_CLASS.FISH
  },
  ["河蟹"] = {
    icon = 13202,
    unit = "只",
    rescourse = {
      "居所钓鱼"
    },
    descript = "河蟹常穴居于江、河、湖沼的泥岸，身小壳薄，肉质细嫩",
    level = 2,
    func = "食用后增加55000点法力储备",
    item_class = ITEM_CLASS.FISH
  },
  ["小黄鱼"] = {
    icon = 13203,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "小黄鱼喜欢在近海层活动，肉质鲜嫩，营养丰富",
    level = 3,
    func = "食用后增加198000点气血储备",
    item_class = ITEM_CLASS.FISH
  },
  ["草鱼"] = {
    icon = 13204,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "草鱼喜居于水的中下层和近岸多水草区域，肉味美，鱼胆有毒",
    level = 4,
    func = "食用后增加77000点法力储备",
    item_class = ITEM_CLASS.FISH
  },
  ["鲶鱼"] = {
    icon = 13205,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "鲶鱼主要生活在江河、湖泊、水库、坑塘的中下层，多在沿岸地带活动，味甘性温，营养丰富",
    level = 5,
    func = "食用后增加264000点气血储备",
    item_class = ITEM_CLASS.FISH
  },
  ["泥鳅"] = {
    icon = 13206,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "泥鳅生活在淤泥底的静止或缓流水体内，适应性较强，肉质鲜美，可食用、入药，营养价值高",
    level = 6,
    func = "食用后增加99000点法力储备",
    item_class = ITEM_CLASS.FISH
  },
  ["鲤鱼"] = {
    icon = 13207,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "鲤鱼是为温带性淡水鱼，喜欢生活在平原上的暖和湖泊，肉质细嫩、味道鲜美，鱼中上品，难得美味",
    level = 7,
    func = "食用后增加330000点气血储备",
    item_class = ITEM_CLASS.FISH
  },
  ["鳗鱼"] = {
    icon = 13208,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "鳗鱼是一种降河性洄游鱼类，味道鲜美，少刺多肉，并具有清凉解暑、滋补强身的作用",
    level = 8,
    func = "食用后增加121000点法力储备",
    item_class = ITEM_CLASS.FISH
  },
  ["河豚"] = {
    icon = 13208,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "河豚为暖温带及热带近海底层鱼类，肉质细嫩、营养丰富",
    level = 8,
    func = "食用后增加121000点法力储备",
    item_class = ITEM_CLASS.FISH
  },
  ["多宝鱼"] = {
    icon = 13209,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "多宝鱼是世界公认的优质比目鱼之一，胶质蛋白含量高，味道鲜美，营养丰富",
    level = 9,
    func = "食用后增加396000点气血储备",
    item_class = ITEM_CLASS.FISH
  },
  ["石斑鱼"] = {
    icon = 13210,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "石斑鱼喜栖息在沿岸岛屿附近的岩礁底质的海区，营养丰富，肉质细嫩洁白，营养价值极高",
    level = 10,
    func = "食用后增加143000点法力储备",
    item_class = ITEM_CLASS.FISH
  },
  ["青龙鱼"] = {
    icon = 13211,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "青龙鱼为观赏价值极高的鱼类，分布区域较广但十分难遇到，它的味道始终是个迷",
    level = 11,
    func = "食用后增加462000点气血储备",
    item_class = ITEM_CLASS.FISH
  },
  ["鲨鱼"] = {
    icon = 13212,
    unit = "条",
    rescourse = {
      "居所钓鱼"
    },
    descript = "鲨鱼为海中霸主，常生活于较深海域，这条似乎是贪玩的幼崽，不知味道如何",
    level = 12,
    func = "食用后增加165000点法力储备",
    item_class = ITEM_CLASS.FISH
  },
  ["钓鱼-木质鱼竿"] = {
    icon = 13001,
    level = 1,
    unit = "根",
    descript = "最朴实的鱼竿，不是特别好用，但十分便宜",
    purchase_cost = 1,
    purchase_type = 1
  },
  ["钓鱼-坚韧鱼竿"] = {
    icon = 13002,
    level = 2,
    unit = "根",
    descript = "较为趁手的鱼竿，在与鱼儿拉扯时可提供更多助力",
    purchase_cost = 1,
    purchase_type = 3
  },
  ["钓鱼-专业鱼竿"] = {
    icon = 13003,
    level = 3,
    unit = "根",
    descript = "高级鱼竿，在与鱼儿拉扯时最为好用，新手进阶最爱",
    purchase_cost = 1,
    purchase_type = 2
  },
  ["钓鱼-面团"] = {
    icon = 13101,
    level = 1,
    unit = "团",
    descript = "简单的小面团，可以吸引一些不挑食的小虾小蟹",
    func = "主要吸引：河虾、河蟹",
    purchase_cost = 1.9,
    purchase_type = 1
  },
  ["钓鱼-小蚯蚓"] = {
    icon = 13102,
    level = 2,
    unit = "条",
    descript = "小小的蚯蚓，可以吸引靠近岸边的鱼儿",
    func = "主要吸引：河蟹、小黄鱼、草鱼",
    purchase_cost = 3.4,
    purchase_type = 1
  },
  ["钓鱼-大蚯蚓"] = {
    icon = 13103,
    level = 3,
    unit = "条",
    descript = "粗壮的蚯蚓，可以吸引一些挑食的鱼儿",
    func = "主要吸引：草鱼、鲶鱼、泥鳅",
    purchase_cost = 5.1,
    purchase_type = 1
  },
  ["钓鱼-肉丁"] = {
    icon = 13104,
    level = 4,
    unit = "块",
    descript = "充满吸引力的肉丁，可将潜伏在远处的鱼儿都吸引过来",
    func = "主要吸引：泥鳅、鲤鱼、河豚",
    purchase_cost = 6.9,
    purchase_type = 1
  },
  ["钓鱼-虾米"] = {
    icon = 13105,
    level = 5,
    unit = "只",
    descript = "美味的虾米，可吸引远处海中的特殊鱼类",
    func = "主要吸引：河豚、多宝鱼、石斑鱼",
    purchase_cost = 8.6,
    purchase_type = 1
  },
  ["钓鱼-秘制鱼饵"] = {
    icon = 13106,
    level = 6,
    unit = "份",
    descript = "超高级秘制鱼饵，可以将深海里的特殊鱼类都吸引过来",
    func = "主要吸引：石斑鱼、青龙鱼、鲨鱼",
    purchase_cost = 10,
    purchase_type = 1
  },
  ["万圣节糖果"] = {
    icon = 1596,
    unit = "颗",
    rescourse = {
      "2017年万圣节"
    },
    descript = "万圣节的糖果，巧克力味，容易变质，请尽快食用！"
  },
  ["随机变异宠"] = {
    descript = "化身为十二生肖的强力变异宠物，拥有出众的成长和技能"
  },
  ["易经洗髓丹"] = {
    icon = 9220,
    descript = "使用后可以洗去角色四种属性各2点，用以重新分配的神奇丹药（每项属性的数值不能低于相应的人物等级）",
    rescourse = {
      "#@在线商城|OnlineMallDlg=易经洗髓丹#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:洗点道具:易经洗髓丹#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=易经洗髓丹#P"
    },
    unit = "颗",
    coin = 216,
    double_type = 1,
    use_level = 10,
    try_level_tip = "适用等级：角色大于等于%d级",
    confirm_tips = "是否确认使用易经洗髓丹#R洗去四种属性各2点#n？\n（请注意每项属性不能低于相应的人物等级）",
    color = "金色"
  },
  ["五行合缘露"] = {
    icon = 7103,
    descript = "使用后可以洗去角色五种相性各1点，用以重新分配的灵丹妙药（每个相性的数值不能低于0）",
    rescourse = {
      "#@在线商城|OnlineMallDlg=五行合缘露#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:洗点道具:五行合缘露#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=五行合缘露#P"
    },
    unit = "瓶",
    coin = 328,
    double_type = 1,
    use_level = 10,
    confirm_tips = "是否确认使用五行合缘露#R洗去五种相性各1点#n？\n（请注意每种相性不能低于0点）",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["山贼的宝贝"] = {
    icon = 9268,
    descript = "在山贼的藏身之处搜出的袋子，不知里面藏有什么宝贝，可以请活动大使代为鉴定一番，仅在【元旦节】好运鉴宝活动的中生效",
    rescourse = {
      "2018年元旦节活动"
    },
    unit = "袋",
    double_type = 1
  },
  ["搜邪罗盘"] = {
    icon = 1604,
    descript = "充满灵性的罗盘，激发后可探寻千里之内藏污纳垢之地，仅在【元旦节】罗盘寻踪活动的中生效",
    rescourse = {
      "2018年元旦节活动"
    },
    unit = "个",
    double_type = 1
  },
  ["仙魔散"] = {
    icon = 9169,
    descript = "使用后可以洗去角色已分配的仙道点、魔道点各1点，用以重新分配的灵丹妙药",
    rescourse = {
      "#@在线商城|OnlineMallDlg=仙魔散#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:洗点道具:仙魔散#@",
      "#P好心值兑换|乐善施|M=兑换好心值::GoodValueDlg=仙魔散#P"
    },
    unit = "瓶",
    double_type = 1,
    use_level = 120,
    confirm_tips = "是否使用仙魔散洗去已分配的仙道点、魔道点#R各1点#n？",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["作业"] = {
    icon = 1940,
    descript = "《Subject》科目的寒假作业，可以选择自己写完或“参考”好友的作业副本完成",
    rescourse = {
      "2018年寒假活动"
    },
    unit = "本",
    double_type = 2
  },
  ["作业副本"] = {
    icon = 1941,
    descript = "由#Yplayername#n完成的作业副本，使用后将完全复制#Yplayername#n的作业答案，以完成或修改自己的寒假作业。此副本可通过邮寄赠送给好友",
    rescourse = {
      "2018年寒假活动"
    },
    unit = "张",
    double_type = 1
  },
  ["作业（写完）"] = {
    icon = 1942,
    descript = "由自己亲手写完的寒假作业，快去拿给师尊评定一下吧",
    rescourse = {
      "2018年寒假活动"
    },
    unit = "本",
    double_type = 2
  },
  ["作业（抄完）"] = {
    icon = 1943,
    descript = "在#Yplayname#n的“帮助”下完成的寒假作业，师尊倒是看不出来，但是成绩可就全看#Yplayername#n的了",
    rescourse = {
      "2018年寒假活动"
    },
    unit = "本",
    double_type = 2
  },
  ["夏总兵的红包"] = {
    icon = 1939,
    descript = "夏总兵发给天墉城居民的红包，可不要私自贪污了哦",
    rescourse = {
      "2018年春节活动"
    },
    unit = "个"
  },
  ["新年红包"] = {
    icon = 1939,
    descript = "大大的新年红包，里面到底有什么东西呢",
    rescourse = {
      "2018年春节活动"
    },
    unit = "个"
  },
  ["宜忌符"] = {
    icon = 1933,
    descript = "神奇的符咒，只要心中默念，就能知晓今日宜忌口味",
    rescourse = {
      "2018年元宵节活动"
    },
    unit = "道",
    double_type = 2
  },
  ["【戊戌春节】新年礼包"] = {
    icon = 8009,
    descript = "内含1颗超级神兽丹、1颗超级黑水晶",
    rescourse = {
      "2018年春节活动"
    }
  },
  ["【戊戌春节】登录礼包"] = {
    icon = 8010,
    descript = "内含1包超级仙风散、1瓶超级归元露、1颗点化丹",
    rescourse = {
      "2018年春节活动"
    }
  },
  ["【戊戌春节】超级寻宝礼包"] = {
    icon = 8001,
    descript = "内含8张超级藏宝图",
    rescourse = {
      "2018年春节活动"
    }
  },
  ["【戊戌春节】宠物培养礼包"] = {
    icon = 9107,
    descript = "内含15颗超级神兽丹、3瓶超级归元露、3颗宠物强化丹、3颗宠物顿悟丹",
    rescourse = {
      "2018年春节活动"
    }
  },
  ["【戊戌春节】刷道豪华礼包"] = {
    icon = 9108,
    descript = "内含10包超级仙风散、10包宠风散、10个急急如律令",
    rescourse = {
      "2018年春节活动"
    }
  },
  ["【戊戌春节】装备提升礼包"] = {
    icon = 9109,
    descript = "内含20块超级灵石、20块超级晶石、5颗超级绿水晶",
    rescourse = {
      "2018年春节活动"
    }
  },
  ["【戊戌春节】装备强化礼包"] = {
    icon = 8063,
    descript = "内含5颗超级粉水晶、5颗黄水晶、5颗超级圣水晶、5颗超级绿水晶",
    rescourse = {
      "2018年春节活动"
    }
  },
  ["黑熊血精"] = {
    icon = 2007,
    descript = "黑熊妖皇魂魄凝成的血精，可用于参悟七杀星的奥秘，也可直接使用可获得数值奖励，最多可携带10个",
    rescourse = {
      "#@精英头领|ActivitiesDlg=其他活动#@"
    },
    unit = "个"
  },
  ["魔猪血精"] = {
    icon = 2008,
    descript = "血炼魔猪魂魄凝成的血精，可用于参悟七杀星的奥秘，也可直接使用可获得数值奖励，最多可携带10个",
    rescourse = {
      "#@精英头领|ActivitiesDlg=其他活动#@"
    },
    unit = "个"
  },
  ["鬼猿血精"] = {
    icon = 2009,
    descript = "赤血鬼猿魂魄凝成的血精，可用于参悟七杀星的奥秘，也可直接使用可获得数值奖励，最多可携带10个",
    rescourse = {
      "#@精英头领|ActivitiesDlg=其他活动#@"
    },
    unit = "个"
  },
  ["蝎后血精"] = {
    icon = 2010,
    descript = "魅影蝎后魂魄凝成的血精，可用于参悟七杀星的奥秘，也可直接使用可获得数值奖励，最多可携带10个",
    rescourse = {
      "#@精英头领|ActivitiesDlg=其他活动#@"
    },
    unit = "个"
  },
  ["魔皇血精"] = {
    icon = 2308,
    descript = "魔皇类精英头领的血精，可用于参悟七杀星的奥秘，也可直接使用可获得数值奖励，最多可携带10个",
    rescourse = {
      "#@精英头领|ActivitiesDlg=其他活动#@"
    },
    unit = "个"
  },
  ["白萝卜"] = {
    icon = 1572,
    descript = "到了冬天都还没有收获的大白萝卜，好在并没有开裂",
    rescourse = {
      "2018年春节活动"
    }
  },
  ["星星头像框"] = {
    icon = 2011,
    descript = "使用后可获得特殊的星星头像框使用时间，美丽的星星将装饰你的聊天头像，让你聊天时尽显独特魅力",
    rescourse = {
      "道心特权活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Icon1539.png",
    chat_icon_res_type = 1
  },
  ["星星聊天底框"] = {
    icon = 2012,
    descript = "使用后可获得特殊的星星聊天底框使用时间，美丽的星星将装饰你的聊天底框，让你聊天时尽显独特魅力",
    rescourse = {
      "道心特权活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Background0131.png",
    chat_icon_res_type = 1
  },
  ["星影特效"] = {
    icon = 2013,
    descript = "使用后可获得特殊的星影特效围绕身边，让你充满独特魅力",
    func = "使用后可获得特殊的星影特效",
    rescourse = {
      "道心特权活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    custom_tips = "道心会员专属"
  },
  ["星月小精灵"] = {
    icon = 2014,
    descript = "使用后可获得特殊的星月小精灵跟随自身",
    rescourse = {
      "道心特权活动"
    },
    unit = "只",
    double_type = 2,
    color = "金色",
    custom_tips = "道心会员专属"
  },
  ["星月空间头像框"] = {
    icon = 2015,
    descript = "使用后可获得特殊的星月空间头像框使用时间，美丽的星星和月亮将装饰你的个人空间头像，让你彰显独特魅力",
    rescourse = {
      "道心特权活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["星月空间装饰"] = {
    icon = 2016,
    descript = "使用后可获得特殊的星月空间装饰使用时间，美丽的星星和月亮将装饰你的个人空间背景，让你彰显独特魅力",
    rescourse = {
      "道心特权活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["天界头像框"] = {
    icon = 2200,
    descript = "使用后可获得特殊的天界头像框使用时间，云朵将装饰你的聊天头像，让你聊天时尽显独特魅力",
    rescourse = {
      "特殊测试活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Icon3215.png",
    chat_icon_res_type = 1
  },
  ["天界聊天底框"] = {
    icon = 2201,
    descript = "使用后可获得特殊的天界聊天底框使用时间，云朵将装饰你的聊天底框，让你聊天时尽显独特魅力",
    rescourse = {
      "特殊测试活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Background0321.png",
    chat_icon_res_type = 1
  },
  ["天界空间头像框"] = {
    icon = 2202,
    descript = "使用后可获得特殊的天界空间头像框使用时间，云朵将装饰你的个人空间头像，让你彰显独特魅力",
    rescourse = {
      "特殊测试活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["天界空间装饰"] = {
    icon = 2203,
    descript = "使用后可获得特殊的天界空间装饰使用时间，云朵将装饰你的个人空间背景，让你彰显独特魅力",
    rescourse = {
      "特殊测试活动"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["赤焰礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含1只赤焰葫芦（御灵，限时3天）",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R60级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["贺新春·时装礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "内含30天非限制交易如意年、吉祥天时装各一套(礼包价值5776元宝)",
    rescourse = {
      "#@商城限购|OnlineMallDlg=贺新春·时装礼包#@"
    }
  },
  ["庆新年·时装礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "内含90天非限制交易如意年、吉祥天时装各一套(礼包价值13776元宝)",
    rescourse = {
      "#@商城限购|OnlineMallDlg=庆新年·时装礼包#@"
    }
  },
  ["40级豪华成长礼包"] = {
    icon = 9109,
    unit = "个",
    use_level = 40,
    descript = "内含10包超级仙风散、1个高级血池、1个高级灵池和50级豪华成长礼包",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R40级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["50级豪华成长礼包"] = {
    icon = 9109,
    unit = "个",
    use_level = 50,
    descript = "内含8个急急如律令、10枚如意刷道令和60级豪华成长礼包",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R50级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["60级豪华成长礼包"] = {
    icon = 9109,
    unit = "个",
    use_level = 60,
    descript = "内含5个天神护佑、10包宠风散和70级豪华成长礼包",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R60级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["70级豪华成长礼包"] = {
    icon = 9109,
    unit = "个",
    use_level = 70,
    descript = "内含80本修炼卷轴、6道紫气鸿蒙",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R70级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["柳精魄"] = {
    icon = 1546,
    descript = "内含柳精魂魄，点击使用可查看柳精信息",
    rescourse = {
      "2018年清明节活动"
    },
    unit = "枚 ",
    double_type = 2
  },
  ["笑林广记"] = {
    icon = 1944,
    descript = "收录了中洲世界最有趣的笑话",
    rescourse = {
      "2018年愚人节活动"
    },
    unit = "本"
  },
  ["羽化丹"] = {
    icon = 9365,
    descript = "汇聚天地之灵气凝结为此丸，宠物食之可提升羽化灵气（宠物点化完成后可使用羽化丹开启羽化，也可喂养宠物增加羽化灵气3000点）",
    rescourse = {
      "#@在线商城|OnlineMallDlg=羽化丹#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:羽化丹#@"
    },
    unit = "颗",
    coin = 518,
    double_type = 1,
    apply = "PetAttribDlg",
    use_level = 70,
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["【二周年庆】活跃礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "2018年周年庆活动"
    },
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石"
  },
  ["【二周年庆】登录礼包"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "2018年周年庆活动"
    },
    descript = "内含188银元宝、1颗点化丹、1颗宠物强化丹"
  },
  ["【二周年庆】寻宝大礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2018年周年庆活动"
    },
    descript = "内含6张藏宝图、6张超级藏宝图"
  },
  ["【二周年庆】宠物欢乐礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2018年周年庆活动"
    },
    descript = "内含3瓶超级归元露、2颗宠物强化丹、2颗宠物顿悟丹、2册天书"
  },
  ["【二周年庆】宠物进阶礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2018年周年庆活动"
    },
    descript = "内含3颗点化丹、3颗羽化丹、2颗宠物顿悟丹、2颗宠物强化丹"
  },
  ["【二周年庆】豪华刷道礼包"] = {
    icon = 9108,
    unit = "个",
    rescourse = {
      "2018年周年庆活动"
    },
    descript = "内含10包超级仙风散、10包宠风散、6个急急如律令、3道紫气鸿蒙"
  },
  ["【二周年庆】装备提升礼包"] = {
    icon = 9109,
    unit = "个",
    rescourse = {
      "2018年周年庆活动"
    },
    descript = "内含20块超级灵石、20块超级晶石、6块装备共鸣石"
  },
  ["【二周年庆】装备高级礼包"] = {
    icon = 8063,
    unit = "个",
    rescourse = {
      "2018年周年庆活动"
    },
    descript = "内含3颗超级粉水晶、3颗超级绿水晶、18颗黄水晶、5颗超级圣水晶、5块装备共鸣石"
  },
  ["菜肴"] = {
    icon = 1779,
    unit = "份",
    rescourse = {
      "2018年儿童节活动"
    },
    descript = "刚刚做好的热乎乎的菜肴，不知道味道如何",
    double_type = 2
  },
  ["周年蛋糕"] = {
    icon = 9711,
    unit = "块",
    descript = "仙气凝聚而成的蛋糕，天机老人出品，对修道之人大有裨益，得到之后需尽快吃掉",
    double_type = 0,
    rescourse = {
      "2018年周年庆活动"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["支持券"] = {
    icon = 2018,
    unit = "张",
    descript = "名人争霸赛支持券，可用于竞猜比赛结果，赢取竞猜点数",
    double_type = 0,
    rescourse = {
      "2018名人争霸赛"
    }
  },
  ["周年红包"] = {
    icon = 1939,
    unit = "个",
    descript = "使用后可获得经验、道行、武学奖励，更有机会获得商城道具、纪念宠元神碎片。每日最多可使用20个",
    double_type = 0,
    rescourse = {
      "2019年周年庆活动"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["晓色红妆"] = {
    icon = 9512,
    unit = "套",
    gender = 2,
    descript = "晓看天色暮看云，行也，坐也。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "名人争霸赛",
      "全民PK赛"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "云暮风华",
    color = "金色"
  },
  ["云暮风华"] = {
    icon = 9513,
    unit = "套",
    gender = 1,
    descript = "晓看天色暮看云，行也，坐也。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "名人争霸赛",
      "全民PK赛"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "晓色红妆",
    color = "金色"
  },
  ["火眼金睛·融合"] = {
    icon = 9031,
    descript = "使用后在战斗中可显示怪物气血并持续5回合，可使用100次",
    rescourse = {
      "#@合成|AlchemyDlg=火眼金睛·融合#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["通天令牌·融合"] = {
    icon = 8065,
    descript = "在进行通天塔挑战时，可以改变当前层数挑战目标的神奇道具",
    rescourse = {
      "#@合成|AlchemyDlg=通天令牌·融合#@"
    },
    unit = "块",
    double_type = 2,
    color = "金色"
  },
  ["中级血玲珑·融合"] = {
    icon = 9121,
    descript = "存储了100,000,000气血的神奇道具，仅限战斗中使用，目标等级<120，气血每次最多恢复39000+最大气血的10%点；目标等级>=120，气血每次最多恢复50000+最大气血的20%点",
    rescourse = {
      "#@合成|AlchemyDlg=中级血玲珑·融合#@"
    },
    unit = "颗",
    coin = 418,
    double_type = 2,
    max_expend = 100000000
  },
  ["中级法玲珑·融合"] = {
    icon = 9122,
    descript = "存储了100,000,000法力的神奇道具，仅限战斗中使用，目标等级<120，法力每次最多恢复26000+最大法力的10%点；目标等级>=120，法力每次最多恢复30000+最大法力的20%点",
    rescourse = {
      "#@合成|AlchemyDlg=中级法玲珑·融合#@"
    },
    unit = "颗",
    coin = 1400,
    double_type = 2,
    max_expend = 100000000
  },
  ["血玲珑·融合"] = {
    icon = 9050,
    descript = "存储了40,000,000气血的神奇道具，仅限战斗中使用，目标等级<120，气血每次最多恢复39000+最大气血的10%点；目标等级>=120，气血每次最多恢复50000+最大气血的20%点",
    rescourse = {
      "#@合成|AlchemyDlg=血玲珑·融合#@"
    },
    unit = "颗",
    double_type = 2,
    max_expend = 40000000,
    color = "金色"
  },
  ["法玲珑·融合"] = {
    icon = 9051,
    descript = "存储了40,000,000法力的神奇道具，仅限战斗中使用，目标等级<120，法力每次最多恢复26000+最大法力的10%点；目标等级>=120，法力每次最多恢复30000+最大法力的20%点",
    rescourse = {
      "#@合成|AlchemyDlg=法玲珑·融合#@"
    },
    unit = "颗",
    double_type = 2,
    max_expend = 40000000,
    color = "金色"
  },
  ["彩凤之魂"] = {
    icon = 12005,
    unit = "抹",
    descript = "上古坐骑彩凤的魂魄，可注入5阶及以上坐骑中。注入后在与伴侣组队时，可显示同骑效果。彩凤之魂可用100个碎片·彩凤之魂合成",
    double_type = 2,
    rescourse = {
      "#P夫妻任务|月老#P"
    },
    color = "金色"
  },
  ["碎片·彩凤之魂"] = {
    icon = 12006,
    unit = "片",
    descript = "集齐100片并使用后可获得彩凤之魂。彩凤之魂可注入5阶及以上坐骑中，注入后在与伴侣组队时可显示同骑效果。",
    double_type = 0,
    rescourse = {
      "#P夫妻任务|月老#P"
    }
  },
  ["仙粽材料"] = {
    icon = 1833,
    unit = "个",
    descript = "被小心包装的用于制作仙粽的材料，易腐坏，需要尽快交给活动大使保存",
    double_type = 0,
    rescourse = {
      "2018年端午节"
    }
  },
  ["仙粽2"] = {
    icon = 1579,
    unit = "个",
    descript = "蕴含仙气的粽子，吃掉后会获得稀有奖励。#R(请在2018年06月21日04:59前食用)#n",
    test_descript = "蕴含仙气的粽子，吃掉后会获得稀有奖励。#R(请在2018年05月17日04:59前食用)#n",
    double_type = 0,
    rescourse = {
      "2018年端午节"
    }
  },
  ["结婚纪念册"] = {
    icon = 1798,
    unit = "本",
    gender = 2,
    descript = "记录了结婚后的美好回忆",
    double_type = 2,
    rescourse = {
      "#P结婚|月老#P"
    },
    isShowShare = true
  },
  ["球队支持卡"] = {
    icon = 1951,
    unit = "张",
    descript = "世界杯球队支持卡，可用于支持自己喜欢的球队，支持的球队晋级后可前往#R世界杯使者#n处领取奖励。#R请在2018年7月14日22:00前使用#n",
    double_type = 0,
    rescourse = {
      "2018年世界杯"
    },
    cmd = "CMD_WORLD_CUP_2018_PLAY_TABLE"
  },
  ["球队粉丝卡"] = {
    icon = 1952,
    unit = "张",
    descript = "世界杯球队粉丝卡，#Rxx#n的粉丝 xx为支持的球队名称",
    double_type = 0,
    rescourse = {
      "2018年世界杯"
    },
    isShowShare = true,
    cmd = "CMD_WORLD_CUP_2018_PLAY_TABLE"
  },
  ["寒气"] = {
    icon = 1947,
    unit = "道",
    descript = "炎炎夏日中用于消暑的神奇物品，易于消散，请尽快使用！",
    double_type = 0,
    rescourse = {
      "2018年暑假活动"
    }
  },
  ["残损的地图"] = {
    icon = 2019,
    unit = "张",
    descript = "被涂抹后撕成几块的地图，已经看不清上面的信息了 ",
    double_type = 1,
    rescourse = {
      "2018暑假活动"
    }
  },
  ["行雨令"] = {
    icon = 2021,
    unit = "块",
    descript = "用来行雨布雨的令牌，看起来平平无奇，也不知是真是假 ",
    double_type = 1,
    rescourse = {
      "2018暑假活动"
    }
  },
  ["证道魂"] = {
    icon = 2022,
    unit = "枚",
    descript = "纯正的证道之魂，将其上交可获得额外证道殿挑战次数或直接使用获得道行和武学奖励",
    double_type = 2,
    rescourse = {"证道殿"}
  },
  ["神秘女娲礼盒"] = {
    icon = 1665,
    unit = "个",
    descript = "打开后可获得8块超级女娲石的神奇礼盒",
    double_type = 2,
    rescourse = {
      "喜来客栈随机事件"
    }
  },
  ["云容丝·灰"] = {
    icon = 16000,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容丝·褐"] = {
    icon = 16001,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容丝·红"] = {
    icon = 16002,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容丝·紫"] = {
    icon = 16003,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容丝·蓝"] = {
    icon = 16004,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容丝·绿"] = {
    icon = 16005,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼丝·褐"] = {
    icon = 16006,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼丝·红"] = {
    icon = 16007,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼丝·紫"] = {
    icon = 16008,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼丝·蓝"] = {
    icon = 16009,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼丝·天蓝"] = {
    icon = 16010,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼丝·绿"] = {
    icon = 16011,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅丝·灰"] = {
    icon = 16012,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅丝·紫"] = {
    icon = 16013,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅丝·红"] = {
    icon = 16014,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅丝·绿"] = {
    icon = 16015,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅丝·蓝"] = {
    icon = 16016,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅丝·黑"] = {
    icon = 16017,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思丝·白"] = {
    icon = 16018,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思丝·黄"] = {
    icon = 16019,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思丝·红"] = {
    icon = 16020,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思丝·粉"] = {
    icon = 16021,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思丝·蓝"] = {
    icon = 16022,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "成就系统奖励"
    },
    custom_tips = "特殊途径获得"
  },
  ["相思丝·黑"] = {
    icon = 16023,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶丝·白"] = {
    icon = 16024,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶丝·褐"] = {
    icon = 16025,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶丝·红"] = {
    icon = 16026,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶丝·蓝"] = {
    icon = 16027,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶丝·紫"] = {
    icon = 16028,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶丝·黑"] = {
    icon = 16029,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞丝·白"] = {
    icon = 16030,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞丝·褐"] = {
    icon = 16031,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞丝·红"] = {
    icon = 16032,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞丝·蓝"] = {
    icon = 16033,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞丝·紫"] = {
    icon = 16034,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞丝·黑"] = {
    icon = 16035,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 2,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容衣·白"] = {
    icon = 17000,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容衣·黄"] = {
    icon = 17001,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容衣·红"] = {
    icon = 17002,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容衣·紫"] = {
    icon = 17003,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容衣·天蓝"] = {
    icon = 17004,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容衣·绿"] = {
    icon = 17005,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼衣·白"] = {
    icon = 17006,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼衣·红"] = {
    icon = 17007,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼衣·粉"] = {
    icon = 17008,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼衣·蓝"] = {
    icon = 17009,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼衣·天蓝"] = {
    icon = 17010,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼衣·绿"] = {
    icon = 17011,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅衣·白"] = {
    icon = 17012,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅衣·粉"] = {
    icon = 17013,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅衣·红"] = {
    icon = 17014,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅衣·绿"] = {
    icon = 17015,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅衣·蓝"] = {
    icon = 17016,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅衣·黑"] = {
    icon = 17017,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思衣·白"] = {
    icon = 17018,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思衣·黄"] = {
    icon = 17019,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思衣·红"] = {
    icon = 17020,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思衣·粉"] = {
    icon = 17021,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思衣·蓝"] = {
    icon = 17022,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "成就系统奖励"
    },
    custom_tips = "特殊途径获得"
  },
  ["相思衣·黑"] = {
    icon = 17023,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶衣·白"] = {
    icon = 17024,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶衣·黄"] = {
    icon = 17025,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶衣·红"] = {
    icon = 17026,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶衣·蓝"] = {
    icon = 17027,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶衣·粉"] = {
    icon = 17028,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶衣·黑"] = {
    icon = 17029,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞衣·白"] = {
    icon = 17030,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞衣·黄"] = {
    icon = 17031,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞衣·红"] = {
    icon = 17032,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞衣·蓝"] = {
    icon = 17033,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞衣·粉"] = {
    icon = 17034,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞衣·黑"] = {
    icon = 17035,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 3,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容裳·白"] = {
    icon = 18000,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容裳·黄"] = {
    icon = 18001,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容裳·红"] = {
    icon = 18002,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容裳·紫"] = {
    icon = 18003,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容裳·天蓝"] = {
    icon = 18004,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["云容裳·绿"] = {
    icon = 18005,
    unit = "件",
    descript = "云想衣裳花想容",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼裳·白"] = {
    icon = 18006,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼裳·红"] = {
    icon = 18007,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼裳·粉"] = {
    icon = 18008,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼裳·蓝"] = {
    icon = 18009,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼裳·天蓝"] = {
    icon = 18010,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["烟笼裳·绿"] = {
    icon = 18011,
    unit = "件",
    descript = "烟笼寒水月笼沙",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅裳·白"] = {
    icon = 18012,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅裳·粉"] = {
    icon = 18013,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅裳·红"] = {
    icon = 18014,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅裳·绿"] = {
    icon = 18015,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅裳·蓝"] = {
    icon = 18016,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["青梅裳·黑"] = {
    icon = 18017,
    unit = "件",
    descript = "郎骑竹马来,绕床弄青梅",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思裳·白"] = {
    icon = 18018,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思裳·黄"] = {
    icon = 18019,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思裳·红"] = {
    icon = 18020,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思裳·粉"] = {
    icon = 18021,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["相思裳·蓝"] = {
    icon = 18022,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "成就系统奖励"
    },
    custom_tips = "特殊途径获得"
  },
  ["相思裳·黑"] = {
    icon = 18023,
    unit = "件",
    descript = "长相思兮长相忆，短相思兮无穷极",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶裳·白"] = {
    icon = 18024,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶裳·黄"] = {
    icon = 18025,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶裳·红"] = {
    icon = 18026,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶裳·蓝"] = {
    icon = 18027,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶裳·粉"] = {
    icon = 18028,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["戏蝶裳·黑"] = {
    icon = 18029,
    unit = "件",
    descript = "狂随戏蝶装罗髻，巧逐纖腰上舞筵",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞裳·白"] = {
    icon = 18030,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞裳·黄"] = {
    icon = 18031,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞裳·红"] = {
    icon = 18032,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞裳·蓝"] = {
    icon = 18033,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞裳·粉"] = {
    icon = 18034,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["倾舞裳·黑"] = {
    icon = 18035,
    unit = "件",
    descript = "碧玉倾香细腰舞",
    double_type = 2,
    part = 4,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["赤风剑·深蓝"] = {
    icon = 19000,
    unit = "件",
    descript = "赤风斩烈云，散做漫天霞",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["赤风剑·黄"] = {
    icon = 19001,
    unit = "件",
    descript = "赤风斩烈云，散做漫天霞",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["赤风剑·红"] = {
    icon = 19002,
    unit = "件",
    descript = "赤风斩烈云，散做漫天霞",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["赤风剑·紫"] = {
    icon = 19003,
    unit = "件",
    descript = "赤风斩烈云，散做漫天霞",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["赤风剑·白"] = {
    icon = 19004,
    unit = "件",
    descript = "赤风斩烈云，散做漫天霞",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["赤风剑·绿"] = {
    icon = 19005,
    unit = "件",
    descript = "赤风斩烈云，散做漫天霞",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鱼泉杖·黄"] = {
    icon = 19006,
    unit = "件",
    descript = "细雨鱼儿出，微风燕子斜",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鱼泉杖·红"] = {
    icon = 19007,
    unit = "件",
    descript = "细雨鱼儿出，微风燕子斜",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鱼泉杖·粉"] = {
    icon = 19008,
    unit = "件",
    descript = "细雨鱼儿出，微风燕子斜",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鱼泉杖·蓝"] = {
    icon = 19009,
    unit = "件",
    descript = "细雨鱼儿出，微风燕子斜",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鱼泉杖·天蓝"] = {
    icon = 19010,
    unit = "件",
    descript = "细雨鱼儿出，微风燕子斜",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鱼泉杖·绿"] = {
    icon = 19011,
    unit = "件",
    descript = "细雨鱼儿出，微风燕子斜",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["溅花刃·黄"] = {
    icon = 19012,
    unit = "件",
    descript = "微雨缠绵，溅花为泪",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["溅花刃·紫"] = {
    icon = 19013,
    unit = "件",
    descript = "微雨缠绵，溅花为泪",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["溅花刃·红"] = {
    icon = 19014,
    unit = "件",
    descript = "微雨缠绵，溅花为泪",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["溅花刃·天蓝"] = {
    icon = 19015,
    unit = "件",
    descript = "微雨缠绵，溅花为泪",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["溅花刃·黑"] = {
    icon = 19016,
    unit = "件",
    descript = "微雨缠绵，溅花为泪",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["溅花刃·银"] = {
    icon = 19017,
    unit = "件",
    descript = "微雨缠绵，溅花为泪",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["轻罗扇·白"] = {
    icon = 19018,
    unit = "件",
    descript = "银烛秋光冷画屏，轻罗小扇扑流萤",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["轻罗扇·黄"] = {
    icon = 19019,
    unit = "件",
    descript = "银烛秋光冷画屏，轻罗小扇扑流萤",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["轻罗扇·红"] = {
    icon = 19020,
    unit = "件",
    descript = "银烛秋光冷画屏，轻罗小扇扑流萤",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["轻罗扇·粉"] = {
    icon = 19021,
    unit = "件",
    descript = "银烛秋光冷画屏，轻罗小扇扑流萤",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["轻罗扇·蓝"] = {
    icon = 19022,
    unit = "件",
    descript = "银烛秋光冷画屏，轻罗小扇扑流萤",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "成就系统奖励"
    },
    custom_tips = "特殊途径获得"
  },
  ["轻罗扇·紫"] = {
    icon = 19023,
    unit = "件",
    descript = "银烛秋光冷画屏，轻罗小扇扑流萤",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["花语环·白"] = {
    icon = 19024,
    unit = "件",
    descript = "花落花开花自语",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["花语环·黄"] = {
    icon = 19025,
    unit = "件",
    descript = "花落花开花自语",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["花语环·红"] = {
    icon = 19026,
    unit = "件",
    descript = "花落花开花自语",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["花语环·蓝"] = {
    icon = 19027,
    unit = "件",
    descript = "花落花开花自语",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["花语环·粉"] = {
    icon = 19028,
    unit = "件",
    descript = "花落花开花自语",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["花语环·黑"] = {
    icon = 19029,
    unit = "件",
    descript = "花落花开花自语",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鸾凤杵·白"] = {
    icon = 19030,
    unit = "件",
    descript = "醉舞且摇鸾凤影",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鸾凤杵·黄"] = {
    icon = 19031,
    unit = "件",
    descript = "醉舞且摇鸾凤影",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鸾凤杵·红"] = {
    icon = 19032,
    unit = "件",
    descript = "醉舞且摇鸾凤影",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鸾凤杵·蓝"] = {
    icon = 19033,
    unit = "件",
    descript = "醉舞且摇鸾凤影",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鸾凤杵·粉"] = {
    icon = 19034,
    unit = "件",
    descript = "醉舞且摇鸾凤影",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["鸾凤杵·黑"] = {
    icon = 19035,
    unit = "件",
    descript = "醉舞且摇鸾凤影",
    double_type = 2,
    part = 5,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹雪翅·白"] = {
    icon = 23000,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹雪翅·黄"] = {
    icon = 23001,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹雪翅·红"] = {
    icon = 23002,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹雪翅·绿"] = {
    icon = 23003,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹雪翅·粉"] = {
    icon = 23004,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹雪翅·黑"] = {
    icon = 23005,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["琼华引·白"] = {
    icon = 23006,
    unit = "件",
    descript = "琼华消散暖风来，多费阳春白雪才",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["琼华引·黄"] = {
    icon = 23007,
    unit = "件",
    descript = "琼华消散暖风来，多费阳春白雪才",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["琼华引·红"] = {
    icon = 23008,
    unit = "件",
    descript = "琼华消散暖风来，多费阳春白雪才",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["琼华引·蓝"] = {
    icon = 23009,
    unit = "件",
    descript = "琼华消散暖风来，多费阳春白雪才",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["琼华引·粉"] = {
    icon = 23010,
    unit = "件",
    descript = "琼华消散暖风来，多费阳春白雪才",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["琼华引·绿"] = {
    icon = 23011,
    unit = "件",
    descript = "琼华消散暖风来，多费阳春白雪才",
    double_type = 2,
    part = 1,
    gender = 2,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客冠·褐"] = {
    icon = 16500,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客冠·红"] = {
    icon = 16501,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客冠·紫"] = {
    icon = 16502,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客冠·蓝"] = {
    icon = 16503,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客冠·天蓝"] = {
    icon = 16504,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客冠·绿"] = {
    icon = 16505,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云冠·灰"] = {
    icon = 16506,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云冠·绿"] = {
    icon = 16507,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云冠·紫"] = {
    icon = 16508,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云冠·蓝"] = {
    icon = 16509,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云冠·墨绿"] = {
    icon = 16510,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云冠·黑"] = {
    icon = 16511,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影冠·蓝"] = {
    icon = 16512,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影冠·白"] = {
    icon = 16513,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影冠·灰"] = {
    icon = 16514,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影冠·红"] = {
    icon = 16515,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影冠·绿"] = {
    icon = 16516,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影冠·黄"] = {
    icon = 16517,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌冠·白"] = {
    icon = 16518,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌冠·红"] = {
    icon = 16519,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌冠·紫"] = {
    icon = 16520,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌冠·蓝"] = {
    icon = 16521,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "成就系统奖励"
    },
    custom_tips = "特殊途径获得"
  },
  ["踏歌冠·天蓝"] = {
    icon = 16522,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌冠·黑"] = {
    icon = 16523,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧冠·白"] = {
    icon = 16524,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧冠·红"] = {
    icon = 16525,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧冠·紫"] = {
    icon = 16526,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧冠·蓝"] = {
    icon = 16527,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧冠·黄"] = {
    icon = 16528,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧冠·黑"] = {
    icon = 16529,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星冠·白"] = {
    icon = 16530,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星冠·红"] = {
    icon = 16531,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星冠·紫"] = {
    icon = 16532,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星冠·蓝"] = {
    icon = 16533,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星冠·褐"] = {
    icon = 16534,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星冠·黑"] = {
    icon = 16535,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["了无尘"] = {
    icon = 16536,
    unit = "件",
    descript = "本来无一物，何处惹尘埃",
    double_type = 2,
    part = 2,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客衫·黄"] = {
    icon = 17500,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客衫·红"] = {
    icon = 17501,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客衫·紫"] = {
    icon = 17502,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客衫·蓝"] = {
    icon = 17503,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客衫·天蓝"] = {
    icon = 17504,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客衫·绿"] = {
    icon = 17505,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云衫·灰"] = {
    icon = 17506,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云衫·绿"] = {
    icon = 17507,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云衫·紫"] = {
    icon = 17508,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云衫·蓝"] = {
    icon = 17509,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云衫·天蓝"] = {
    icon = 17510,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云衫·黑"] = {
    icon = 17511,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影衫·蓝"] = {
    icon = 17512,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影衫·天蓝"] = {
    icon = 17513,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影衫·紫"] = {
    icon = 17514,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影衫·红"] = {
    icon = 17515,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影衫·绿"] = {
    icon = 17516,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影衫·黄"] = {
    icon = 17517,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌衫·黄"] = {
    icon = 17518,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌衫·红"] = {
    icon = 17519,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌衫·紫"] = {
    icon = 17520,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌衫·蓝"] = {
    icon = 17521,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "成就系统奖励"
    },
    custom_tips = "特殊途径获得"
  },
  ["踏歌衫·天蓝"] = {
    icon = 17522,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌衫·灰"] = {
    icon = 17523,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧衫·白"] = {
    icon = 17524,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧衫·红"] = {
    icon = 17525,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧衫·紫"] = {
    icon = 17526,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧衫·蓝"] = {
    icon = 17527,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧衫·黄"] = {
    icon = 17528,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧衫·黑"] = {
    icon = 17529,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星衫·白"] = {
    icon = 17530,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星衫·红"] = {
    icon = 17531,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星衫·紫"] = {
    icon = 17532,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星衫·蓝"] = {
    icon = 17533,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星衫·黄"] = {
    icon = 17534,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星衫·黑"] = {
    icon = 17535,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 3,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客袴·黄"] = {
    icon = 18500,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客袴·红"] = {
    icon = 18501,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客袴·紫"] = {
    icon = 18502,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客袴·蓝"] = {
    icon = 18503,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客袴·天蓝"] = {
    icon = 18504,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["侠客袴·绿"] = {
    icon = 18505,
    unit = "件",
    descript = "三杯吐然诺，五岳倒为轻",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云袴·灰"] = {
    icon = 18506,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云袴·绿"] = {
    icon = 18507,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云袴·紫"] = {
    icon = 18508,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云袴·蓝"] = {
    icon = 18509,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云袴·天蓝"] = {
    icon = 18510,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["凌云袴·黑"] = {
    icon = 18511,
    unit = "件",
    descript = "好风凭借力，助我意凌云",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影袴·蓝"] = {
    icon = 18512,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影袴·天蓝"] = {
    icon = 18513,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影袴·紫"] = {
    icon = 18514,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影袴·红"] = {
    icon = 18515,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影袴·绿"] = {
    icon = 18516,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞影袴·黄"] = {
    icon = 18517,
    unit = "件",
    descript = "月落平沙，飞影霜刃寒",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌袴·黄"] = {
    icon = 18518,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌袴·红"] = {
    icon = 18519,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌袴·紫"] = {
    icon = 18520,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌袴·蓝"] = {
    icon = 18521,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "成就系统奖励"
    },
    custom_tips = "特殊途径获得"
  },
  ["踏歌袴·天蓝"] = {
    icon = 18522,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["踏歌袴·灰"] = {
    icon = 18523,
    unit = "件",
    descript = "春风踏马行歌去，万里江山总是情",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧袴·白"] = {
    icon = 18524,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧袴·红"] = {
    icon = 18525,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧袴·紫"] = {
    icon = 18526,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧袴·蓝"] = {
    icon = 18527,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧袴·黄"] = {
    icon = 18528,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["龙骧袴·黑"] = {
    icon = 18529,
    unit = "件",
    descript = "金鞍珠辔御龙骧",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星袴·白"] = {
    icon = 18530,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星袴·红"] = {
    icon = 18531,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星袴·紫"] = {
    icon = 18532,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星袴·蓝"] = {
    icon = 18533,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星袴·黄"] = {
    icon = 18534,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["飞星袴·黑"] = {
    icon = 18535,
    unit = "件",
    descript = "星飞一点千华界",
    double_type = 2,
    part = 4,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["囚龙剑·黄"] = {
    icon = 19500,
    unit = "件",
    descript = "青锋三尺，画地囚龙",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["囚龙剑·红"] = {
    icon = 19501,
    unit = "件",
    descript = "青锋三尺，画地囚龙",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["囚龙剑·紫"] = {
    icon = 19502,
    unit = "件",
    descript = "青锋三尺，画地囚龙",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["囚龙剑·深蓝"] = {
    icon = 19503,
    unit = "件",
    descript = "青锋三尺，画地囚龙",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["囚龙剑·白"] = {
    icon = 19504,
    unit = "件",
    descript = "青锋三尺，画地囚龙",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["囚龙剑·绿"] = {
    icon = 19505,
    unit = "件",
    descript = "青锋三尺，画地囚龙",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["断魄刀·黄"] = {
    icon = 19506,
    unit = "件",
    descript = "斩神鬼之魂，断妖魔之魄",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["断魄刀·红"] = {
    icon = 19507,
    unit = "件",
    descript = "斩神鬼之魂，断妖魔之魄",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["断魄刀·紫"] = {
    icon = 19508,
    unit = "件",
    descript = "斩神鬼之魂，断妖魔之魄",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["断魄刀·天蓝"] = {
    icon = 19509,
    unit = "件",
    descript = "斩神鬼之魂，断妖魔之魄",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["断魄刀·绿"] = {
    icon = 19510,
    unit = "件",
    descript = "斩神鬼之魂，断妖魔之魄",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["断魄刀·黑"] = {
    icon = 19511,
    unit = "件",
    descript = "斩神鬼之魂，断妖魔之魄",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["分云棍·蓝"] = {
    icon = 19512,
    unit = "件",
    descript = "分云见月，挥落辰星",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["分云棍·天蓝"] = {
    icon = 19513,
    unit = "件",
    descript = "分云见月，挥落辰星",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["分云棍·紫"] = {
    icon = 19514,
    unit = "件",
    descript = "分云见月，挥落辰星",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["分云棍·红"] = {
    icon = 19515,
    unit = "件",
    descript = "分云见月，挥落辰星",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["分云棍·绿"] = {
    icon = 19516,
    unit = "件",
    descript = "分云见月，挥落辰星",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["分云棍·黑"] = {
    icon = 19517,
    unit = "件",
    descript = "分云见月，挥落辰星",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["天地远·黄"] = {
    icon = 19518,
    unit = "件",
    descript = "掌边天地远，咫尺变乾坤",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["天地远·红"] = {
    icon = 19519,
    unit = "件",
    descript = "掌边天地远，咫尺变乾坤",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["天地远·紫"] = {
    icon = 19520,
    unit = "件",
    descript = "掌边天地远，咫尺变乾坤",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["天地远·蓝"] = {
    icon = 19521,
    unit = "件",
    descript = "掌边天地远，咫尺变乾坤",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "成就系统奖励"
    },
    custom_tips = "特殊途径获得"
  },
  ["天地远·白"] = {
    icon = 19522,
    unit = "件",
    descript = "掌边天地远，咫尺变乾坤",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["天地远·黑"] = {
    icon = 19523,
    unit = "件",
    descript = "掌边天地远，咫尺变乾坤",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["山河弑·白"] = {
    icon = 19524,
    unit = "件",
    descript = "志欲静干戈，俱誓裂山河",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["山河弑·红"] = {
    icon = 19525,
    unit = "件",
    descript = "志欲静干戈，俱誓裂山河",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["山河弑·紫"] = {
    icon = 19526,
    unit = "件",
    descript = "志欲静干戈，俱誓裂山河",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["山河弑·蓝"] = {
    icon = 19527,
    unit = "件",
    descript = "志欲静干戈，俱誓裂山河",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["山河弑·黄"] = {
    icon = 19528,
    unit = "件",
    descript = "志欲静干戈，俱誓裂山河",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["山河弑·黑"] = {
    icon = 19529,
    unit = "件",
    descript = "志欲静干戈，俱誓裂山河",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["半月剑·白"] = {
    icon = 19530,
    unit = "件",
    descript = "月华三尺阴，照我半轮明",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["半月剑·红"] = {
    icon = 19531,
    unit = "件",
    descript = "月华三尺阴，照我半轮明",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["半月剑·紫"] = {
    icon = 19532,
    unit = "件",
    descript = "月华三尺阴，照我半轮明",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["半月剑·蓝"] = {
    icon = 19533,
    unit = "件",
    descript = "月华三尺阴，照我半轮明",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["半月剑·黄"] = {
    icon = 19534,
    unit = "件",
    descript = "月华三尺阴，照我半轮明",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["半月剑·黑"] = {
    icon = 19535,
    unit = "件",
    descript = "月华三尺阴，照我半轮明",
    double_type = 2,
    part = 5,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹霜翅·白"] = {
    icon = 22000,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹霜翅·红"] = {
    icon = 22001,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹霜翅·紫"] = {
    icon = 22002,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹霜翅·绿"] = {
    icon = 22003,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹霜翅·黄"] = {
    icon = 22004,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["莹霜翅·黑"] = {
    icon = 22005,
    unit = "件",
    descript = "莹然玉雪凝霜色",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["业火劫·白"] = {
    icon = 22006,
    unit = "件",
    descript = "红莲业火劫，焚尽万物灵",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["业火劫·红"] = {
    icon = 22007,
    unit = "件",
    descript = "红莲业火劫，焚尽万物灵",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["业火劫·紫"] = {
    icon = 22008,
    unit = "件",
    descript = "红莲业火劫，焚尽万物灵",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["业火劫·蓝"] = {
    icon = 22009,
    unit = "件",
    descript = "红莲业火劫，焚尽万物灵",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["业火劫·黄"] = {
    icon = 22010,
    unit = "件",
    descript = "红莲业火劫，焚尽万物灵",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["业火劫·黑"] = {
    icon = 22011,
    unit = "件",
    descript = "红莲业火劫，焚尽万物灵",
    double_type = 2,
    part = 1,
    gender = 1,
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    }
  },
  ["乾坤图"] = {
    icon = 1830,
    descript = "可映照凶魂恶鬼藏匿地图的道家至宝，仅在【中元节】铲除阴魂活动中生效",
    rescourse = {
      "2018年中元节活动"
    },
    unit = "张",
    double_type = 1
  },
  ["天机仪"] = {
    icon = 1604,
    descript = "可指引凶魂恶鬼藏匿方位的道家至宝，仅在【中元节】铲除阴魂活动中生效",
    rescourse = {
      "2018年中元节活动"
    },
    unit = "件",
    double_type = 1
  },
  ["探案奖章"] = {
    icon = 20003,
    descript = "完成探案任务时获得的奖章，使用后可获得大量道行、武学奖励，不可与其他双倍效果叠加",
    rescourse = {
      "#P探案任务|李捕头#P"
    },
    unit = "枚",
    color = "蓝色",
    use_level = 50,
    level_tip = "角色等级达到#R50级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["《人口失踪》案卷宗"] = {
    icon = 2023,
    descript = "关于近来人口失踪案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】人口失踪"
  },
  ["《谁是卧底》案卷宗"] = {
    icon = 2023,
    descript = "关于谁是卧底案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】谁是卧底"
  },
  ["风车"] = {
    icon = 2024,
    descript = "不知是谁丢失的风车，似乎有些奇怪，有待深入查看一番",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    cmd = "CMD_RKSZ_PAPER_MESSAGE",
    taskName = "【探案】人口失踪",
    cardUseButtonName = "查  看"
  },
  ["桃花糕"] = {
    icon = 2025,
    descript = "不知是谁丢失的桃花糕，似乎有些奇怪，有待深入查看一番",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    cmd = "CMD_RKSZ_PAPER_MESSAGE",
    taskName = "【探案】人口失踪",
    cardUseButtonName = "查  看"
  },
  ["丑靴子"] = {
    icon = 2026,
    descript = "不知是谁丢失的丑靴子，似乎有些奇怪，有待深入查看一番",
    rescourse = {
      "探案任务"
    },
    unit = "只",
    cmd = "CMD_RKSZ_PAPER_MESSAGE",
    taskName = "【探案】人口失踪",
    cardUseButtonName = "查  看"
  },
  ["带补丁的钱袋"] = {
    icon = 2027,
    descript = "不知是谁丢失的钱袋，似乎有些奇怪，有待深入查看一番",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    cmd = "CMD_RKSZ_PAPER_MESSAGE",
    taskName = "【探案】人口失踪",
    cardUseButtonName = "查  看"
  },
  ["铲子"] = {
    icon = 2028,
    descript = "不知是谁丢失的铲子，似乎有些奇怪，有待深入查看一番",
    rescourse = {
      "探案任务"
    },
    unit = "把",
    cmd = "CMD_RKSZ_PAPER_MESSAGE",
    taskName = "【探案】人口失踪",
    cardUseButtonName = "查  看"
  },
  ["带葫芦的拐杖"] = {
    icon = 2029,
    descript = "不知是谁丢失的拐杖，似乎有些奇怪，有待深入查看一番",
    rescourse = {
      "探案任务"
    },
    unit = "根",
    cmd = "CMD_RKSZ_PAPER_MESSAGE",
    taskName = "【探案】人口失踪",
    cardUseButtonName = "查  看"
  },
  ["《江湖绿林》案卷宗"] = {
    icon = 2023,
    descript = "关于神秘来信探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】江湖绿林"
  },
  ["百合花种子"] = {
    icon = 1948,
    descript = "一包百合花的种子，可种植在#R桃柳林、官道南、官道北、十里坡、揽仙镇外和卧龙坡#n其中一个地方",
    rescourse = {
      "2018年教师节"
    },
    unit = "朵 ",
    double_type = 2
  },
  ["普通百合花"] = {
    icon = 1949,
    descript = "幸运之花，伟大的爱之含意，有深深祝福的意义。可#Y邮寄给道友师父#n或#Y赠送给门派师父#n（赠送给#Y道友师父#n会增加10点友好度）",
    rescourse = {
      "2018年教师节"
    },
    unit = "朵 ",
    double_type = 2,
    cardUseButtonName = "赠  送",
    item_class = ITEM_CLASS.BAIHE_HUA
  },
  ["赠送后普通百合花"] = {
    icon = 1949,
    descript = "幸运之花，伟大的爱之含意，有深深祝福的意义。",
    rescourse = {
      "2018年教师节"
    },
    unit = "朵 ",
    double_type = 2,
    item_class = ITEM_CLASS.BAIHE_HUA
  },
  ["精致百合花"] = {
    icon = 1949,
    descript = "幸运之花，伟大的爱之含意，有深深祝福的意义。可#Y邮寄给道友师父#n或#Y赠送给门派师父#n（赠送给#Y道友师父#n会增加10点友好度）",
    rescourse = {
      "2018年教师节"
    },
    unit = "朵 ",
    double_type = 2,
    cardUseButtonName = "赠  送",
    item_class = ITEM_CLASS.BAIHE_HUA
  },
  ["赠送后精致百合花"] = {
    icon = 1949,
    descript = "幸运之花，伟大的爱之含意，有深深祝福的意义。",
    rescourse = {
      "2018年教师节"
    },
    unit = "朵 ",
    double_type = 2,
    item_class = ITEM_CLASS.BAIHE_HUA
  },
  ["完美百合花"] = {
    icon = 1949,
    descript = "幸运之花，伟大的爱之含意，有深深祝福的意义。可#Y邮寄给道友师父#n或#Y赠送给门派师父#n（赠送给#Y道友师父#n会增加10点友好度）",
    rescourse = {
      "2018年教师节"
    },
    unit = "朵 ",
    double_type = 2,
    cardUseButtonName = "赠  送",
    item_class = ITEM_CLASS.BAIHE_HUA
  },
  ["赠送后完美百合花"] = {
    icon = 1949,
    descript = "幸运之花，伟大的爱之含意，有深深祝福的意义。",
    rescourse = {
      "2018年教师节"
    },
    unit = "朵 ",
    double_type = 2,
    item_class = ITEM_CLASS.BAIHE_HUA
  },
  ["《天外之谜》案卷宗"] = {
    icon = 2023,
    descript = "关于近来天外之谜案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    double_type = 2,
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】天外之谜"
  },
  ["天外来客的信"] = {
    icon = 2030,
    descript = "一封来自天外来客的信",
    rescourse = {
      "探案任务"
    },
    unit = "封",
    double_type = 2,
    cardUseButtonName = "查  看"
  },
  ["奇怪的盒子"] = {
    icon = 2031,
    descript = "天外来客留下的盒子，似乎需要特殊方式才能打开",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    double_type = 2,
    cardUseButtonName = "查  看"
  },
  ["碎纸及显影粉"] = {
    icon = 2032,
    descript = "一堆碎纸和一瓶显影粉，上面似乎有什么线索但无法看清",
    rescourse = {
      "探案任务"
    },
    unit = "堆",
    double_type = 2,
    cardUseButtonName = "查  看"
  },
  ["尸变阵及镇尸符"] = {
    icon = 2033,
    descript = "一个带有神奇符号的阵法",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    double_type = 2,
    cardUseButtonName = "查  看"
  },
  ["神秘的盒子"] = {
    icon = 2034,
    descript = "一个神秘的盒子，带着锁",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    double_type = 2
  },
  ["神秘的钥匙"] = {
    icon = 2035,
    descript = "一把神秘的钥匙，能用来开什么锁呢？",
    rescourse = {
      "探案任务"
    },
    unit = "把",
    double_type = 2
  },
  ["神秘的纸条"] = {
    icon = 2036,
    descript = "上面好像有什么字",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2,
    cardUseButtonName = "查  看"
  },
  ["神秘的符纸"] = {
    icon = 2037,
    descript = "一堆鬼画符，完全看不懂",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["传音符"] = {
    icon = 2038,
    descript = "开光后的传音符，听说能通过它与天外来客沟通",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["【戊戌国庆】活跃礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "2018年国庆活动"
    },
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石"
  },
  ["【戊戌国庆】登录礼包"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "2018年国庆活动"
    },
    descript = "内含188银元宝、1颗点化丹、1颗宠物强化丹"
  },
  ["【戊戌国庆】寻宝大礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2018年国庆活动"
    },
    descript = "内含6张藏宝图、6张超级藏宝图"
  },
  ["【戊戌国庆】宠物欢乐礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2018年国庆活动"
    },
    descript = "内含3瓶超级归元露、2颗宠物强化丹、2颗宠物顿悟丹、2颗点化丹"
  },
  ["【戊戌国庆】宠物进阶礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2018年国庆活动"
    },
    descript = "内含4颗风灵丸、4颗羽化丹、3颗宠物顿悟丹、6颗超级神兽丹"
  },
  ["【戊戌国庆】豪华刷道礼包"] = {
    icon = 9108,
    unit = "个",
    rescourse = {
      "2018年国庆活动"
    },
    descript = "内含14包超级仙风散、14包宠风散、8个急急如律令、4道紫气鸿蒙"
  },
  ["【戊戌国庆】装备提升礼包"] = {
    icon = 9109,
    unit = "个",
    rescourse = {
      "2018年国庆活动"
    },
    descript = "内含24块超级灵石、24块超级晶石、6块装备共鸣石"
  },
  ["【戊戌国庆】装备高级礼包"] = {
    icon = 8063,
    unit = "个",
    rescourse = {
      "2018年国庆活动"
    },
    descript = "内含3颗超级粉水晶、3颗超级绿水晶、18颗黄水晶、5颗超级圣水晶、5块装备共鸣石"
  },
  ["《镖局风云》案卷宗"] = {
    icon = 2023,
    unit = "本",
    rescourse = {
      "探案任务"
    },
    descript = "关于镖局风云案件的探案卷宗，用于记录寻找到的各个线索及备注",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】镖局风云"
  },
  ["《迷仙镇》案卷宗"] = {
    icon = 2023,
    descript = "关于近来迷仙镇案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    double_type = 2,
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】迷仙镇案"
  },
  ["尸检报告"] = {
    icon = 2039,
    descript = "小童的尸检报告，报告上明确表示：死者#RPart部位#n有瘀伤但不是致死原因，真正的致死原因为中毒死亡",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["小童叔叔的证词"] = {
    icon = 2040,
    descript = "小童叔叔亲口承认与嫂子有染，但不知道小童是否为自己亲生#R（使用道具可回顾当时的剧情）#n",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["常舌馥的证词"] = {
    icon = 2040,
    descript = "常舌馥承认是自己煽动导致童家兄弟的争执，看来那场争执与本案有关#R（使用道具可回顾当时的剧情）#n",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["小童魂魄的证词"] = {
    icon = 2040,
    descript = "小童魂魄说的话，有着他对镇中一些人的印象，招魂道士表示此物不可作为呈堂证供，但可用来吓唬怕鬼之人#R（使用道具可回顾当时的剧情）#n",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["迷仙镇训"] = {
    icon = 2043,
    descript = "迷仙镇的五大戒律#R（使用道具可回顾当时的剧情）#n",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["打铁的锤子"] = {
    icon = 2044,
    descript = "小童父母家找到的锤子",
    rescourse = {
      "探案任务"
    },
    unit = "把",
    double_type = 2
  },
  ["信石药包"] = {
    icon = 2045,
    descript = "常舌馥家找到的一包未打开的药包，上方写着“信石”",
    rescourse = {
      "探案任务"
    },
    unit = "包",
    double_type = 2
  },
  ["“父子草”药包"] = {
    icon = 2046,
    descript = "小童爷爷家找到的一包未打开的药包，上方写着“父子草”",
    rescourse = {
      "探案任务"
    },
    unit = "包",
    double_type = 2
  },
  ["叔叔家的肚兜"] = {
    icon = 2047,
    descript = "小童叔叔家找到的女子肚兜",
    rescourse = {
      "探案任务"
    },
    unit = "件",
    double_type = 2
  },
  ["带药粉的糖葫芦"] = {
    icon = 2048,
    descript = "迷仙镇中找到的糖葫芦，上方似乎有药粉，找到时周围有死老鼠",
    rescourse = {
      "探案任务"
    },
    unit = "串",
    double_type = 2
  },
  ["小童爷爷的证词"] = {
    icon = 2040,
    descript = "小童爷爷承认是自己掐伤了小童，但没说明是什么部位#R（使用道具可回顾当时的剧情）#n",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["掉落的锤子"] = {
    icon = 2044,
    descript = "在李氏渔村中捡起的东西，不知道有什么用呢？",
    rescourse = {
      "探案任务"
    },
    unit = "把",
    double_type = 2
  },
  ["变形的戒指"] = {
    icon = 2151,
    descript = "在李氏渔村中捡起的东西，不知道有什么用呢？",
    rescourse = {
      "探案任务"
    },
    unit = "枚",
    double_type = 2
  },
  ["破碎的手镯"] = {
    icon = 2152,
    descript = "在李氏渔村中捡起的东西，不知道有什么用呢？",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    double_type = 2
  },
  ["带血的手帕"] = {
    icon = 2153,
    descript = "在李氏渔村中捡起的东西，不知道有什么用呢？",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["完整的头饰"] = {
    icon = 2154,
    descript = "在李氏渔村中捡起的东西，不知道有什么用呢？",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    double_type = 2
  },
  ["酒册"] = {
    icon = 1956,
    descript = "薄薄的小本子，记录着揽仙镇的酒桌强者",
    rescourse = {
      "2018年重阳节"
    },
    unit = "本",
    double_type = 2
  },
  ["妖灵当归"] = {
    icon = 7960,
    descript = "妖界药材，焕发强烈的生命气息，具有补益气血的作用",
    rescourse = {
      "副本任务"
    },
    unit = "株",
    double_type = 0
  },
  ["妖灵山药"] = {
    icon = 7952,
    descript = "妖界药材，日干捣细筛为粉，食之大美，且愈疾而补",
    rescourse = {
      "副本任务"
    },
    unit = "块",
    double_type = 0
  },
  ["固灵花"] = {
    icon = 7951,
    descript = "妖界药材，可固妖之灵，助妖疗伤",
    rescourse = {
      "副本任务"
    },
    unit = "株",
    double_type = 0
  },
  ["中洲青年名片_男1"] = {
    icon = 1953,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_男2"] = {
    icon = 1957,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_男3"] = {
    icon = 1958,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_男4"] = {
    icon = 1959,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_男5"] = {
    icon = 1960,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_男6"] = {
    icon = 1961,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_女1"] = {
    icon = 1954,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_女2"] = {
    icon = 1962,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_女3"] = {
    icon = 1963,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_女4"] = {
    icon = 1964,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["中洲青年名片_女5"] = {
    icon = 1965,
    unit = "张",
    descript = "",
    double_type = 2,
    rescourse = {
      "2018光棍节"
    },
    before_use_cmd = "CMD_REQUEST_ZZQN_CARD_INFO"
  },
  ["三清铃"] = {
    icon = 1955,
    descript = "催动后可发出悦耳灵音，鬼魅闻之胆战心惊昏沉数日，仅在【万圣节】灵音镇魔活动中生效",
    rescourse = {
      "2018年万圣节"
    },
    unit = "串",
    double_type = 0
  },
  ["雨过天晴"] = {
    icon = 2054,
    descript = "使用后可获得雨过天晴特效围绕身边，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["蝶影翩翩"] = {
    icon = 2055,
    descript = "使用后可获得蝶影翩翩特效围绕身边，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["轻羽飞扬"] = {
    icon = 2056,
    descript = "使用后可获得轻羽飞扬特效围绕身边，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    custom_tips = "道心会员专属"
  },
  ["风花雪月"] = {
    icon = 2058,
    descript = "使用后可获得风花雪月特效围绕身边，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["星汉灿烂"] = {
    icon = 2059,
    descript = "使用后可获得星汉灿烂特效围绕身边，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["繁花盛开"] = {
    icon = 2060,
    descript = "使用后可获得繁花盛开行走特效，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["踏雪无痕"] = {
    icon = 2061,
    descript = "使用后可获得踏雪无痕行走特效，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["步步生莲"] = {
    icon = 2062,
    descript = "使用后可获得步步生莲行走特效，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["豪气冲天"] = {
    icon = 2100,
    descript = "使用后可获得豪气冲天特效围绕身边，让你充满独特魅力",
    rescourse = {
      "特殊途径产出"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["风驰电掣"] = {
    icon = 2307,
    descript = "使用后可获得风驰电掣行走特效，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    custom_tips = "周年纪念商城兑换"
  },
  ["多彩泡泡"] = {
    icon = 2051,
    descript = "解锁后可获得多彩泡泡特效围绕身边，让你充满独特魅力，夫妻在组队情况下才生效",
    rescourse = {
      "夫妻专属特效"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    custom_tips = "夫妻友好度70000解锁"
  },
  ["翩翩起舞"] = {
    icon = 2052,
    descript = "解锁后可获得翩翩起舞特效围绕身边，让你充满独特魅力，夫妻在组队情况下才生效",
    rescourse = {
      "夫妻专属特效"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    custom_tips = "夫妻友好度150000解锁"
  },
  ["浪漫玫瑰"] = {
    icon = 2053,
    descript = "解锁后可获得浪漫玫瑰特效围绕身边，让你充满独特魅力，夫妻在组队情况下才生效",
    rescourse = {
      "夫妻专属特效"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    custom_tips = "夫妻友好度250000解锁"
  },
  ["新年汪"] = {
    icon = 2063,
    descript = "使用后可获得萌萌的新年汪跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色",
    custom_tips = "特殊途径获得"
  },
  ["太小极"] = {
    icon = 2064,
    descript = "使用后可获得萌萌的太小极跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["泥泥"] = {
    icon = 2065,
    descript = "使用后可获得萌萌的泥泥跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["蓝极公主"] = {
    icon = 2066,
    descript = "使用后可获得萌萌的蓝极公主跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["灯笼宝宝"] = {
    icon = 2067,
    descript = "使用后可获得萌萌的灯笼宝宝跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["小绯"] = {
    icon = 2068,
    descript = "使用后可获得萌萌的小绯跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["小海龟"] = {
    icon = 2069,
    descript = "使用后可获得萌萌的小海龟跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["福禄猪"] = {
    icon = 2078,
    descript = "使用后可获得萌萌的福禄猪跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色",
    custom_tips = "购买特殊时装赠送"
  },
  ["金灵"] = {
    icon = 2300,
    descript = "使用后可获得萌萌的金灵跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["木心"] = {
    icon = 2301,
    descript = "使用后可获得萌萌的木心跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["水精"] = {
    icon = 2302,
    descript = "使用后可获得萌萌的水精跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["火魂"] = {
    icon = 2303,
    descript = "使用后可获得萌萌的火魂跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["土魄"] = {
    icon = 2304,
    descript = "使用后可获得萌萌的土魄跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色"
  },
  ["圣诞祝福卡"] = {
    icon = 1966,
    descript = "写着祝福语的精美卡片",
    rescourse = {
      "2018年圣诞节"
    },
    unit = "张",
    double_type = 0
  },
  ["圣诞帽"] = {
    icon = 1967,
    descript = "造型奇特，定是来自异国他乡",
    rescourse = {
      "2018年圣诞节"
    },
    unit = "顶",
    double_type = 0
  },
  ["缤纷糖果"] = {
    icon = 1596,
    descript = "圣诞节的糖果，能带给人们欢乐和喜悦",
    rescourse = {
      "2018年圣诞节"
    },
    unit = "颗",
    double_type = 0
  },
  ["未鉴定过的宝物"] = {
    icon = 9268,
    descript = "价值不明，可前往活动大使处鉴定",
    rescourse = {
      "2019年元旦"
    },
    unit = "个",
    double_type = 0
  },
  ["烟花筒·盛世繁花"] = {
    icon = 2070,
    descript = "使用后可释放烟花",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·盛世繁花#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·盛世繁花#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·盛世繁花#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·盛世繁花#Z"
    },
    unit = "个 ",
    double_type = 0,
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["烟花筒·满天星雨"] = {
    icon = 2071,
    descript = "使用后可释放烟花",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·满天星雨#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·满天星雨#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·满天星雨#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·满天星雨#Z"
    },
    unit = "个 ",
    double_type = 0,
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["烟花筒·绚丽彩焰"] = {
    icon = 2072,
    descript = "使用后可释放烟花",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·绚丽彩焰#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·绚丽彩焰#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·绚丽彩焰#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=烟花筒·绚丽彩焰#Z"
    },
    unit = "个 ",
    double_type = 0,
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["【己亥春节】新年礼包"] = {
    icon = 8009,
    descript = "内含100银元宝、1包超级仙风散、1颗超级神兽丹",
    rescourse = {
      "2019年春节活动"
    }
  },
  ["【己亥春节】登录礼包"] = {
    icon = 8010,
    descript = "内含300银元宝、1个神木鼎、1包宠风散",
    rescourse = {
      "2019年春节活动"
    }
  },
  ["【己亥春节】寻宝礼包"] = {
    icon = 8001,
    descript = "内含8张超级藏宝图",
    rescourse = {
      "2019年春节活动"
    }
  },
  ["【己亥春节】宠物提升礼包"] = {
    icon = 9107,
    descript = "内含3瓶超级归元露、8颗宠物强化丹、5颗点化丹",
    rescourse = {
      "2019年春节活动"
    }
  },
  ["【己亥春节】豪华刷道礼包"] = {
    icon = 9107,
    descript = "内含10包超级仙风散、10包宠风散、10个急急如律令",
    rescourse = {
      "2019年春节活动"
    }
  },
  ["【己亥春节】宠物进阶礼包"] = {
    icon = 9108,
    descript = "内含10颗宠物强化丹、10颗羽化丹、6颗宠物顿悟丹",
    rescourse = {
      "2019年春节活动"
    }
  },
  ["【己亥春节】装备炼化礼包"] = {
    icon = 9109,
    descript = "内含3颗超级粉水晶、12颗黄水晶、3颗超级绿水晶、2颗超级圣水晶",
    rescourse = {
      "2019年春节活动"
    }
  },
  ["【己亥春节】装备改造礼包"] = {
    icon = 8063,
    descript = "内含25块超级灵石、50块超级晶石、30块装备共鸣石",
    rescourse = {
      "2019年春节活动"
    }
  },
  ["情圣秘籍·甜言"] = {
    icon = 1971,
    descript = "纵横情场的情圣所总结的秘籍，记录了一些甜言蜜语",
    rescourse = {
      "2019年元宵节"
    },
    unit = "本 ",
    double_type = 2
  },
  ["情圣秘籍·幽默"] = {
    icon = 1972,
    descript = "纵横情场的情圣所总结的秘籍，记录了一些幽默的笑话",
    rescourse = {
      "2019年元宵节"
    },
    unit = "本 ",
    double_type = 2
  },
  ["情圣秘籍·礼物"] = {
    icon = 1973,
    descript = "纵横情场的情圣所总结的秘籍，记录了一些人气礼物",
    rescourse = {
      "2019年元宵节"
    },
    unit = "本 ",
    double_type = 2
  },
  ["约会表现攻略"] = {
    icon = 1974,
    descript = "细心制定的约会攻略",
    rescourse = {
      "2019年元宵节"
    },
    unit = "本 ",
    double_type = 2
  },
  ["镐子"] = {
    icon = 1975,
    descript = "可在春节任务中获得，在张老板处用于寻宝的物品，可挖开一格泥土或敲碎一格岩石",
    rescourse = {
      "2020年春节"
    },
    unit = "把",
    double_type = 0
  },
  ["小型炸弹"] = {
    icon = 1976,
    descript = "可在春节任务中获得，在张老板处用于寻宝的物品，可引爆一层泥土",
    rescourse = {
      "2020年春节"
    },
    unit = "支",
    double_type = 0
  },
  ["超级炸弹"] = {
    icon = 1977,
    descript = "可在春节任务中获得，在张老板处用于寻宝的物品，可引爆九宫格内的泥土、岩石",
    rescourse = {
      "2020年春节"
    },
    unit = "捆",
    double_type = 0
  },
  ["南方红豆杉"] = {
    icon = 1983,
    descript = "自然生长在海拔1000米或1500米以下的山谷、溪边。耐干旱瘠薄，不耐低洼积水",
    rescourse = {
      "2019年植树节"
    },
    unit = "棵",
    double_type = 0
  },
  ["泓森槐"] = {
    icon = 1984,
    descript = "泓森槐抗性强，防风固沙，适应南北大跨度气候区域",
    rescourse = {
      "2019年植树节"
    },
    unit = "棵",
    double_type = 0
  },
  ["马尾松"] = {
    icon = 1985,
    descript = "对土壤要求不严格，但怕水涝，在沙质土与陡峭的石山岩缝里都能生长",
    rescourse = {
      "2019年植树节"
    },
    unit = "棵",
    double_type = 0
  },
  ["柳树"] = {
    icon = 1986,
    descript = "对环境的适应性很广，喜光，喜湿，在立地条件优越的平原沃野，生长更好",
    rescourse = {
      "2019年植树节"
    },
    unit = "棵",
    double_type = 0
  },
  ["侧柏"] = {
    icon = 1987,
    descript = "侧柏能适应于一定的冷气候，抗旱能力强、对土壤要求不严",
    rescourse = {
      "2019年植树节"
    },
    unit = "棵",
    double_type = 0
  },
  ["植物手册"] = {
    icon = 1978,
    descript = "记录着绿化植物的手册，不知道是哪位道友撰写的",
    rescourse = {
      "2019年植树节"
    },
    unit = "本",
    double_type = 2
  },
  ["江洋大盗线索图"] = {
    icon = 1970,
    descript = "点击使用后可查看线索，寻找到江洋大盗的藏身之处",
    rescourse = {
      "【交友】并肩同行"
    },
    unit = "张",
    double_type = 2
  },
  ["红玫瑰"] = {
    icon = 2073,
    descript = "一支红玫瑰，可将其摆放在地面，持续时间1小时",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=红玫瑰#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=红玫瑰#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=红玫瑰#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=红玫瑰#Z"
    },
    unit = "支",
    double_type = 0,
    use_level = 35,
    level_tip = "角色等级达到#R35级#n后方可使用本道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["蓝玫瑰"] = {
    icon = 2074,
    descript = "一支蓝玫瑰，可将其摆放在地面，持续时间1小时",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=蓝玫瑰#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=蓝玫瑰#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=蓝玫瑰#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=蓝玫瑰#Z"
    },
    unit = "支",
    double_type = 0,
    use_level = 35,
    level_tip = "角色等级达到#R35级#n后方可使用本道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["白百合"] = {
    icon = 2075,
    descript = "一支白百合，可将其摆放在地面，持续时间1小时",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=白百合#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=白百合#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=白百合#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=白百合#Z"
    },
    unit = "支",
    double_type = 0,
    use_level = 35,
    level_tip = "角色等级达到#R35级#n后方可使用本道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["蜡烛"] = {
    icon = 2076,
    descript = "红色的蜡烛，可将其摆放在地面，持续时间1小时",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=蜡烛#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=蜡烛#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=蜡烛#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=蜡烛#Z"
    },
    unit = "支",
    double_type = 0,
    use_level = 35,
    level_tip = "角色等级达到#R35级#n后方可使用本道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["小酒碗"] = {
    icon = 2077,
    descript = "装着清酒的小酒碗，可将其摆放在地面，持续时间1小时",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=小酒碗#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=小酒碗#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=小酒碗#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=小酒碗#Z"
    },
    unit = "个",
    double_type = 0,
    use_level = 35,
    level_tip = "角色等级达到#R35级#n后方可使用本道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["愚人节喇叭"] = {
    icon = 9176,
    descript = "千面怪送的喇叭，用它在世界频道发言，据说有变身千面的效用",
    rescourse = {
      "2019年愚人节"
    },
    unit = "个",
    double_type = 2
  },
  ["【三周年庆】活跃礼包"] = {
    icon = 8009,
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石",
    rescourse = {
      "2019年周年庆活动"
    },
    unit = "个"
  },
  ["【三周年庆】登录礼包"] = {
    icon = 8010,
    descript = "内含188银元宝、1颗点化丹、1颗宠物强化丹",
    rescourse = {
      "2019年周年庆活动"
    },
    unit = "个"
  },
  ["【三周年庆】寻宝大礼包"] = {
    icon = 8001,
    descript = "内含6张藏宝图、6张超级藏宝图",
    rescourse = {
      "2019年周年庆活动"
    },
    unit = "个"
  },
  ["【三周年庆】宠物欢乐礼包"] = {
    icon = 9107,
    descript = "内含3瓶超级归元露、2颗宠物强化丹、2颗宠物顿悟丹、2颗点化丹",
    rescourse = {
      "2019年周年庆活动"
    },
    unit = "个"
  },
  ["【三周年庆】宠物进阶礼包"] = {
    icon = 9107,
    descript = "内含4册天书、4颗羽化丹、3颗宠物顿悟丹、6颗超级神兽丹",
    rescourse = {
      "2019年周年庆活动"
    },
    unit = "个"
  },
  ["【三周年庆】豪华刷道礼包"] = {
    icon = 9108,
    descript = "内含14包超级仙风散、14包宠风散、8个急急如律令、4道紫气鸿蒙",
    rescourse = {
      "2019年周年庆活动"
    },
    unit = "个"
  },
  ["【三周年庆】装备提升礼包"] = {
    icon = 9109,
    descript = "内含24块超级灵石、24块超级晶石、6块装备共鸣石",
    rescourse = {
      "2019年周年庆活动"
    },
    unit = "个"
  },
  ["【三周年庆】装备高级礼包"] = {
    icon = 8063,
    descript = "内含3颗超级粉水晶、3颗超级绿水晶、18颗黄水晶、5颗超级圣水晶、5块装备共鸣石",
    rescourse = {
      "2019年周年庆活动"
    },
    unit = "个"
  },
  ["2019周年蛋糕"] = {
    icon = 9711,
    unit = "块",
    descript = "一块美味的蛋糕，对修道之人大有裨益，可不要等到发霉了再吃哦",
    double_type = 0,
    rescourse = {
      "2019年周年庆活动"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。"
  },
  ["【四周年庆】活跃礼包"] = {
    icon = 8009,
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石",
    rescourse = {
      "2020年周年庆活动"
    },
    unit = "个"
  },
  ["【四周年庆】登录礼包"] = {
    icon = 8010,
    descript = "内含188银元宝、1颗点化丹、1颗宠物强化丹",
    rescourse = {
      "2020年周年庆活动"
    },
    unit = "个"
  },
  ["【四周年庆】寻宝大礼包"] = {
    icon = 8001,
    descript = "内含1张特级藏宝图、3张超级藏宝图",
    rescourse = {
      "2020年周年庆活动"
    },
    unit = "个"
  },
  ["【四周年庆】宠物欢乐礼包"] = {
    icon = 9107,
    descript = "内含7本灵海残卷、2颗宠物强化丹、2颗宠物顿悟丹、2颗点化丹",
    rescourse = {
      "2020年周年庆活动"
    },
    unit = "个"
  },
  ["【四周年庆】宠物进阶礼包"] = {
    icon = 9107,
    descript = "内含4册天书、5颗羽化丹、2颗宠物顿悟丹、4颗超级神兽丹",
    rescourse = {
      "2020年周年庆活动"
    },
    unit = "个"
  },
  ["【四周年庆】豪华刷道礼包"] = {
    icon = 9108,
    descript = "内含20包超级仙风散、14包宠风散、6个急急如律令、4道紫气鸿蒙",
    rescourse = {
      "2020年周年庆活动"
    },
    unit = "个"
  },
  ["【四周年庆】装备提升礼包"] = {
    icon = 9109,
    descript = "内含24块超级灵石、24块超级晶石、6块装备共鸣石",
    rescourse = {
      "2020年周年庆活动"
    },
    unit = "个"
  },
  ["【四周年庆】装备高级礼包"] = {
    icon = 8063,
    descript = "内含3颗超级粉水晶、3颗超级绿水晶、18颗黄水晶、5颗超级圣水晶、5块装备共鸣石",
    rescourse = {
      "2020年周年庆活动"
    },
    unit = "个"
  },
  ["2019豆沙粽"] = {
    icon = 1990,
    descript = "软糯弹牙的糯米，包裹着甜甜的豆沙馅，由厉巧手精制而成",
    rescourse = {
      "2019年端午节"
    },
    unit = "个",
    double_type = 2
  },
  ["2019烧肉粽"] = {
    icon = 1991,
    descript = "包着香菇、虾米、栗子、猪肉、蛋黄等各种馅料，由大胡子精制而成",
    rescourse = {
      "2019年端午节"
    },
    unit = "个",
    double_type = 2
  },
  ["元神碎片·餐风"] = {
    icon = 1988,
    descript = "2019年周年庆纪念宠餐风的元神碎片，集齐100个并使用后可召唤餐风",
    rescourse = {
      "2019年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·餐风#@"
    },
    unit = "片",
    double_type = 0,
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["元神碎片·饮露"] = {
    icon = 1989,
    descript = "2019年周年庆纪念宠饮露的元神碎片，集齐100个并使用后可召唤饮露",
    rescourse = {
      "2019年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·饮露#@"
    },
    unit = "片",
    double_type = 0,
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["2019百草谱"] = {
    icon = 2000,
    descript = "天机老人收集的秘籍，记载着中洲世界的奇花异草",
    rescourse = {
      "2019年端午节"
    },
    unit = "册"
  },
  ["硝石"] = {
    icon = 21000,
    descript = "无色、白色或灰色矿石，有光泽。可用于配制孔雀绿釉，还可用作五彩、粉彩的颜料，同时还是制造火药的原料之一。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 1
  },
  ["葛布"] = {
    icon = 21001,
    descript = "葛，植物名，多年生蔓草。其茎的纤维所制成的织物叫葛布，俗称“夏布”，质地细薄，作为衣料，多用于制巾。",
    rescourse = {"无"},
    unit = "匹",
    goodsId = 2
  },
  ["杜仲"] = {
    icon = 21002,
    descript = "杜仲的树皮晾干而成，味甘，性温，有补益肝肾、强筋壮骨、调理冲任、固经安胎的功效，是上品滋补药材。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 3
  },
  ["华丽丝绸"] = {
    icon = 21003,
    descript = "以蚕丝织造的纺织品，质地轻薄、柔软、滑爽、透气，辅以精工刺绣则绚丽多彩。",
    rescourse = {"无"},
    unit = "匹",
    goodsId = 4
  },
  ["麝香"] = {
    icon = 21004,
    descript = "鹿科动物麝的雄兽香腺囊中的分泌物。质较柔软，有特异的香气，是一种名贵中药材。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 5
  },
  ["玛瑙"] = {
    icon = 21005,
    descript = "是玉髓的一种，色彩有层次，有半透明或不透明的色泽，绚丽多彩，传说具有辟邪护身之功效。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 6
  },
  ["三七"] = {
    icon = 7958,
    descript = "中草药，具有显著的活血化瘀、消肿定痛功效，人参补气第一，三七补血第一，亦被称为“参中之王”。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 7
  },
  ["珍珠"] = {
    icon = 21006,
    descript = "产在珍珠贝类和珠母贝类体内，珍珠色泽温润细腻，自然形态优美，是纯洁美好的象征。",
    rescourse = {"无"},
    unit = "颗",
    goodsId = 8
  },
  ["锦布"] = {
    icon = 21007,
    descript = "一种华丽高贵的织物，外观瑰丽多彩，花纹精致高雅，花型立体生动，是富贵吉祥之象征。",
    rescourse = {"无"},
    unit = "匹",
    goodsId = 9
  },
  ["牛黄"] = {
    icon = 21008,
    descript = "牛黄是牛胆囊的胆结石，表面金黄至黄褐色，细腻而有光泽，牛黄气清香，味微苦而后甜，是一种名贵的中药材。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 10
  },
  ["熊胆"] = {
    icon = 21009,
    descript = "为黑熊或棕熊的胆囊，表面灰黑色或棕黑色，显光泽，有皱褶，囊皮薄，迎光视之，上部常呈半透明，是一种名贵的中药材。",
    rescourse = {"无"},
    unit = "颗",
    goodsId = 11
  },
  ["何首乌"] = {
    icon = 7957,
    descript = "中草药，可安神、养血、活络，解毒，补益精血、乌须发、强筋骨、补肝肾。",
    rescourse = {"无"},
    unit = "棵",
    goodsId = 12
  },
  ["黄连"] = {
    icon = 21010,
    descript = "中草药，有清热燥湿，泻火解毒之功效。其味入口极苦，有俗语云“哑巴吃黄连，有苦说不出”。",
    rescourse = {"无"},
    unit = "棵",
    goodsId = 13
  },
  ["朱砂"] = {
    icon = 21011,
    descript = "朱砂是一种色彩鲜艳的矿石，呈棕红色或红色，是烧汞炼丹的重要原料之一。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 14
  },
  ["水晶"] = {
    icon = 21012,
    descript = "水晶是一种五彩斑斓的透明晶石，颜色种类繁多，以纯色透亮，色彩动人，不含杂质者为上品。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 15
  },
  ["生绢"] = {
    icon = 21013,
    descript = "未经精练脱胶的平纹织物，朴实无华，内敛细致，即可用于衣料，又可用于作画。",
    rescourse = {"无"},
    unit = "匹",
    goodsId = 16
  },
  ["百年人参"] = {
    icon = 7214,
    descript = "名贵中药草，被称为百草之王，主补五脏，安精神，定魂魄，药龄已达百年，珍贵异常。",
    rescourse = {"无"},
    unit = "根",
    goodsId = 17
  },
  ["雄黄"] = {
    icon = 21014,
    descript = "黄色或桔红色的矿石，可入药，具有杀菌镇痛功效，亦是烧汞炼丹的材料之一。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 18
  },
  ["翡翠"] = {
    icon = 21015,
    descript = "颜色温润的玉石，颜色丰富多彩，其中绿色为上品，翡翠寓意吉祥，常被加工为如意、平安锁等。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 19
  },
  ["绸缎"] = {
    icon = 21016,
    descript = "经过精工细作的丝织物，光滑亮丽，质感细腻，以平整度高，薄厚适中的为佳。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 20
  },
  ["玄铁"] = {
    icon = 21017,
    descript = "颜色深黑，隐隐透出红光，极为沉重，开锋後削铁如泥，是打造兵器的上佳材料。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 21
  },
  ["珊瑚"] = {
    icon = 21018,
    descript = "产于深海之中，颜色绚烂，多姿多彩，烛光下熠熠生辉，是大富大贵之家装饰之上品。",
    rescourse = {"无"},
    unit = "支",
    goodsId = 22
  },
  ["百年灵芝"] = {
    icon = 7210,
    descript = "名贵中药草，是医界圣药，具有补气安神、止咳平喘、延年益寿的功效，药龄已达百年，珍贵异常。",
    rescourse = {"无"},
    unit = "朵",
    goodsId = 23
  },
  ["碧玉"] = {
    icon = 21019,
    descript = "墨绿色或深绿色的玉石，颜色深沉，手感润滑，与其他玉石追求颜色明艳不同，碧玉反而以颜色厚重，质如凝脂的墨玉为上品。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 24
  },
  ["棉麻"] = {
    icon = 21020,
    descript = "以棉和麻为原材料的纺织品，棉麻质地朴实，价格低廉，是普通布衣百姓的常用衣料。",
    rescourse = {"无"},
    unit = "匹",
    goodsId = 25
  },
  ["枸杞"] = {
    icon = 21021,
    descript = "中草药，具有养肝，滋肾，润肺之功效，原产于西域，后经由商人传入中洲。",
    rescourse = {"无"},
    unit = "袋",
    goodsId = 26
  },
  ["精金"] = {
    icon = 21022,
    descript = "经过精炼的铁矿，质地比凡铁更硬三分，同时更易锻造，是打造兵器的上佳材料。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 27
  },
  ["火玉"] = {
    icon = 21023,
    descript = "一种火红色矿石，质地坚硬，只需在打造兵刃时加入些许，即可让兵刃无坚不摧。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 28
  },
  ["水铜"] = {
    icon = 21024,
    descript = "水蓝色金属，以铜通过水炼之法精炼四十九天方可成型，水铜柔软至极却又坚韧无比，是制作软兵器的绝佳材料。",
    rescourse = {"无"},
    unit = "块",
    goodsId = 29
  },
  ["当归"] = {
    icon = 7960,
    descript = "中草药，具有补血和血，调经止痛之功效，人参昂贵而当归价格较为低廉，是人参的优良替代品。",
    rescourse = {"无"},
    unit = "支",
    goodsId = 30
  },
  ["2019年新年福袋"] = {
    icon = 8001,
    descript = "开启礼包时必定从以下奖励中随机获得1种：招财猪（变异）、召唤令·十二生肖、剑魄琴心/引天长歌（14天）、超级绿水晶、剑魄琴心/引天长歌（7天）、超级仙风散、羽化丹、超级灵石、风灵丸",
    rescourse = {
      "新年运营活动"
    },
    unit = "个 ",
    double_type = 2,
    use_level = 30,
    level_tip = "角色等级达到30级后方可使用本礼包。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["己亥年新春红包"] = {
    icon = 1939,
    descript = "恭祝各位道友新春大吉！打开红包后可获得随机数量的代金券",
    rescourse = {
      "己亥年新春运营活动"
    },
    unit = "个 ",
    double_type = 2,
    use_level = 30,
    level_tip = "角色等级达到30级后方可使用此道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["乐骑礼盒"] = {
    icon = 1665,
    descript = "打开时有较大概率获得1只限时#R3天#n的御灵无极熊、仙葫芦、玉豹、赤焰葫芦、幻鹿、凌岩豹、仙阳剑，有较小概率获得1只#R永久#n时限的御灵墨麒麟、筋斗云",
    rescourse = {
      "新服运营活动"
    },
    unit = "个 ",
    double_type = 2,
    use_level = 30,
    level_tip = "角色等级达到30级后方可使用此道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["位列仙班·年卡打折券"] = {
    icon = 2002,
    descript = "使用此道具购买位列仙班·年卡可享8.5折优惠",
    rescourse = {
      "年卡会员体验活动"
    },
    unit = "张",
    double_type = 2
  },
  ["礼花·万花争鸣"] = {
    icon = 2082,
    descript = "使用后可释放礼花·万花争鸣",
    rescourse = {
      "#Z永和杂货铺|::贾老板|$0|M=我要做买卖::GroceryStoreDlg=礼花·万花争鸣#Z",
      "#Z南北杂货铺|天墉城(76,26)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=礼花·万花争鸣#Z",
      "#Z东海杂货店|东海渔村(46,15)::杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=礼花·万花争鸣#Z",
      "#Z无名杂货店|::无名杂货店老板|$0|M=我要做买卖::GroceryStoreDlg=礼花·万花争鸣#Z"
    },
    unit = "个 ",
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用此道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["神秘画卷"] = {
    icon = 1830,
    descript = "无尽岁月前流传下来的画卷，上面还有一些神秘的数字，仅在#R【暑假】神秘数字#n活动中生效",
    rescourse = {
      "2019年暑假活动"
    },
    unit = "张"
  },
  ["神秘宝盒"] = {
    icon = 2001,
    descript = "被机关锁住的盒子，不知道里面是什么宝贝，仅在#R【暑假】神秘数字#n活动中生效",
    rescourse = {
      "2019年暑假活动"
    },
    unit = "个"
  },
  ["加时卡"] = {
    icon = 2079,
    descript = "神奇的卡牌，在文曲星答题时可以延长一倍的答题时间",
    rescourse = {""},
    unit = "张",
    double_type = 0
  },
  ["探索卡"] = {
    icon = 2080,
    descript = "神奇的卡牌，在文曲星答题时可以去掉一个错误答案",
    rescourse = {""},
    unit = "张",
    double_type = 0
  },
  ["求助卡"] = {
    icon = 2081,
    descript = "神奇的卡牌，在文曲星答题时可以发起一次帮派求助",
    rescourse = {""},
    unit = "张",
    double_type = 0
  },
  ["玉露精华"] = {
    icon = 2004,
    descript = "经过道家高人精心研制而成，在温泉场景中使用后，当前场景的所有道友可获得数值奖励加成，每个场景只能使用一次玉露精华",
    rescourse = {
      "周活动之仙池温泉"
    },
    color = "金色",
    unit = "瓶"
  },
  ["骑幻礼盒"] = {
    icon = 1578,
    descript = "打开时随机获得如下内容中的#R1项#n：超级仙风散、中级灵池、情缘盒、宠物强化丹、风灵丸、紫气鸿蒙、天神护佑、随机6阶御灵（7天）、随机8阶御灵（7天）",
    rescourse = {
      "官方运营活动"
    },
    unit = "个",
    double_type = 2,
    use_level = 30,
    level_tip = "角色等级达到30级后方可使用此道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["灵尘宝盒"] = {
    icon = 2001,
    descript = "使用后可获得随机商城道具",
    rescourse = {
      "#P段铁心|M=灵尘商店#P"
    },
    unit = "个",
    double_type = 2,
    color = "金色"
  },
  ["七夕锦囊"] = {
    icon = 9268,
    descript = "神奇的七夕锦囊，可在鹊桥之约活动中使用，切记只能在需要之时打开",
    rescourse = {
      "2019年七夕节"
    },
    unit = "袋",
    double_type = 2
  },
  ["五彩情花"] = {
    icon = 2116,
    descript = "多彩缤纷的五彩情花，在七夕期间使用后可召唤喜鹊",
    rescourse = {
      "2019年七夕节"
    },
    unit = "束",
    double_type = 2
  },
  ["红花"] = {
    icon = 2117,
    descript = "常年生长于百花谷中，据说能够与其他仙花合成五彩情花",
    rescourse = {
      "2019年七夕节"
    },
    unit = "束",
    double_type = 2
  },
  ["黄花"] = {
    icon = 2118,
    descript = "常年生长于百花谷中，据说能够与其他仙花合成五彩情花",
    rescourse = {
      "2019年七夕节"
    },
    unit = "束",
    double_type = 2
  },
  ["绿花"] = {
    icon = 2119,
    descript = "常年生长于百花谷中，据说能够与其他仙花合成五彩情花",
    rescourse = {
      "2019年七夕节"
    },
    unit = "束",
    double_type = 2
  },
  ["蓝花"] = {
    icon = 2120,
    descript = "常年生长于百花谷中，据说能够与其他仙花合成五彩情花",
    rescourse = {
      "2019年七夕节"
    },
    unit = "束",
    double_type = 2
  },
  ["紫花"] = {
    icon = 2121,
    descript = "常年生长于百花谷中，据说能够与其他仙花合成五彩情花",
    rescourse = {
      "2019年七夕节"
    },
    unit = "束",
    double_type = 2
  },
  ["轻音小调"] = {
    icon = 2090,
    descript = "使用后可获得轻音小调特效围绕身边，让你充满独特魅力",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    custom_tips = "问道好声音排名奖励"
  },
  ["浪漫巧果"] = {
    icon = 2122,
    unit = "份",
    descript = "浪漫巧果是一种七夕传统节日食俗，有着姻缘美好的寓意",
    double_type = 2,
    rescourse = {
      "2019年七夕节"
    }
  },
  ["面粉"] = {
    icon = 2101,
    unit = "",
    descript = "",
    rescourse = {
      "2019年七夕节"
    }
  },
  ["鸡蛋"] = {
    icon = 2111,
    unit = "",
    descript = "",
    rescourse = {
      "2019年七夕节"
    }
  },
  ["白糖"] = {
    icon = 2102,
    unit = "",
    descript = "",
    rescourse = {
      "2019年七夕节"
    }
  },
  ["芝麻"] = {
    icon = 2112,
    unit = "",
    descript = "",
    rescourse = {
      "2019年七夕节"
    }
  },
  ["食盐"] = {
    icon = 2113,
    unit = "",
    descript = "",
    rescourse = {
      "2019年七夕节"
    }
  },
  ["温水"] = {
    icon = 2114,
    unit = "",
    descript = "",
    rescourse = {
      "2019年七夕节"
    }
  },
  ["植物油"] = {
    icon = 2115,
    unit = "",
    descript = "",
    rescourse = {
      "2019年七夕节"
    }
  },
  ["高级召回礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "召回道友活动"
    },
    descript = "感谢您对好友的召回，开启可获得商城道具奖励，更有机会抽取十二生肖变异宠大奖"
  },
  ["回归礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "再续前缘活动"
    },
    descript = "欢迎回到问道世界，开启可获得商城道具奖励，更有机会抽取十二生肖变异宠大奖"
  },
  ["金算盘"] = {
    icon = 2093,
    unit = "个",
    descript = "",
    rescourse = {
      "娃娃武器"
    }
  },
  ["大葱"] = {
    icon = 2094,
    unit = "个",
    descript = "",
    rescourse = {
      "娃娃武器"
    }
  },
  ["冰棍"] = {
    icon = 2095,
    unit = "个",
    descript = "",
    rescourse = {
      "娃娃武器"
    }
  },
  ["糖葫芦"] = {
    icon = 2096,
    unit = "个",
    descript = "",
    rescourse = {
      "娃娃武器"
    }
  },
  ["砖头"] = {
    icon = 2097,
    unit = "个",
    descript = "",
    rescourse = {
      "娃娃武器"
    }
  },
  ["道行盛典礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "新服盛典中道行排名前1000名获得的礼包，开启可获得超级女娲石、召唤令·十二生肖等道具奖励，更有几率抽取神兽大奖",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["等级盛典礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "新服盛典中等级排名前1000名获得的礼包，开启可获得超级女娲石、召唤令·十二生肖等道具奖励，更有几率抽取神兽大奖",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["盛典礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "参与新服盛典获得的礼包，开启可获得稀有道具奖励，更有几率抽取变异大奖",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["随心时装礼盒"] = {
    icon = 1578,
    unit = "个",
    double_type = 2,
    descript = "打开时可从已发售过的所有时装中（部分专属时装除外）任意选取一件，有时候还会有未发售过的新时装，获得%s使用权限",
    rescourse = {
      "青城论道",
      "充值积分活动",
      "消费积分活动",
      "2019年全民PK"
    }
  },
  ["至尊时装礼盒"] = {
    icon = 9107,
    unit = "个",
    double_type = 2,
    descript = "打开时可从时装：龙吟水/凤鸣空、狐灵逸/狐灵娇、日耀辰辉/星垂月涌、星火昭/点红烛、踏雪寻梅/紫岚故梦中任意选取一件，获得%s使用权限",
    rescourse = {
      "线下活动"
    }
  },
  ["尊享时装礼盒"] = {
    icon = 9108,
    unit = "个",
    double_type = 2,
    descript = "打开时可从时装：千秋梦/汉宫秋、峥岚衣/水光衫、云暮风华/晓色红妆、剑魄琴心/引天长歌、镇星辰/玄冥临中任意选取一件，获得%s使用权限",
    rescourse = {
      "线下活动"
    }
  },
  ["绝版时装礼盒"] = {
    icon = 9109,
    unit = "个",
    double_type = 1,
    descript = "打开时可从时装：千秋梦/汉宫秋、龙吟水/凤鸣空、峥岚衣/水光衫、狐灵逸/狐灵娇、云暮风华/晓色红妆、雀羽极/雀羽翎、极道棋魂/仙道棋心中任意选取一件，获得%s使用权限",
    rescourse = {
      "特殊限时活动"
    }
  },
  ["商城时装礼盒"] = {
    icon = 1578,
    unit = "个",
    double_type = 2,
    descript = "内含1套自选时装%s(与礼包使用者的性别一致，与获得礼盒时商城中的出售列表范围一致)",
    rescourse = {
      "登录排队购买",
      "商城限购"
    }
  },
  ["道法残卷"] = {
    icon = 2124,
    unit = "本",
    descript = "神奇的道法残卷，记录着提升娃娃攻击类资质的秘诀。",
    rescourse = {
      "娃娃日常"
    },
    double_type = 0
  },
  ["心法残卷"] = {
    icon = 2125,
    unit = "本",
    descript = "神奇的心法残卷，记录着提升娃娃辅助类资质的秘诀。",
    rescourse = {
      "娃娃日常"
    },
    double_type = 0
  },
  ["竹马（绿色）"] = {
    icon = 2126,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用竹片、纸、布扎成马形，可用于骑乘玩耍",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:竹马:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃气血值\n(金色>紫色>蓝色)"
  },
  ["竹马（蓝色）"] = {
    icon = 2126,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用竹片、纸、布扎成马形，可用于骑乘玩耍",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:竹马:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃气血值\n(金色>紫色>蓝色)"
  },
  ["竹马（金色）"] = {
    icon = 2126,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用竹片、纸、布扎成马形，可用于骑乘玩耍",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:竹马:金色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃气血值\n(金色>紫色>蓝色)"
  },
  ["竹马（紫色）"] = {
    icon = 2126,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用竹片、纸、布扎成马形，可用于骑乘玩耍",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:竹马:紫色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃气血值\n(金色>紫色>蓝色)"
  },
  ["毽子（紫色）"] = {
    icon = 2127,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用鸡毛插在圆形的底座上制成的玩具",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:毽子:紫色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃防御值\n(金色>紫色>蓝色)"
  },
  ["毽子（绿色）"] = {
    icon = 2127,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用鸡毛插在圆形的底座上制成的玩具",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:毽子:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃防御值\n(金色>紫色>蓝色)"
  },
  ["毽子（蓝色）"] = {
    icon = 2127,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用鸡毛插在圆形的底座上制成的玩具",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:毽子:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃防御值\n(金色>紫色>蓝色)"
  },
  ["毽子（金色）"] = {
    icon = 2127,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用鸡毛插在圆形的底座上制成的玩具",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:毽子:金色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃防御值\n(金色>紫色>蓝色)"
  },
  ["蹴球（金色）"] = {
    icon = 2128,
    unit = "个",
    descript = "一种儿童期娃娃玩具，呈圆形，可在地上踢玩",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:蹴球:金色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃速度值\n(金色>紫色>蓝色)"
  },
  ["蹴球（紫色）"] = {
    icon = 2128,
    unit = "个",
    descript = "一种儿童期娃娃玩具，呈圆形，可在地上踢玩",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:蹴球:紫色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃速度值\n(金色>紫色>蓝色)"
  },
  ["蹴球（绿色）"] = {
    icon = 2128,
    unit = "个",
    descript = "一种儿童期娃娃玩具，呈圆形，可在地上踢玩",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:蹴球:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃速度值\n(金色>紫色>蓝色)"
  },
  ["蹴球（蓝色）"] = {
    icon = 2128,
    unit = "个",
    descript = "一种儿童期娃娃玩具，呈圆形，可在地上踢玩",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:蹴球:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃速度值\n(金色>紫色>蓝色)"
  },
  ["弹弓（金色）"] = {
    icon = 2129,
    unit = "颗",
    descript = "一种儿童期娃娃玩具，用树木的枝桠制作，呈“丫”字形",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:弹弓:金色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃物伤值\n(金色>紫色>蓝色)"
  },
  ["弹弓（紫色）"] = {
    icon = 2129,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用树木的枝桠制作，呈“丫”字形",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:弹弓:紫色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃物伤值\n(金色>紫色>蓝色)"
  },
  ["弹弓（绿色）"] = {
    icon = 2129,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用树木的枝桠制作，呈“丫”字形",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:弹弓:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃物伤值\n(金色>紫色>蓝色)"
  },
  ["弹弓（蓝色）"] = {
    icon = 2129,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用树木的枝桠制作，呈“丫”字形",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:弹弓:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃物伤值\n(金色>紫色>蓝色)"
  },
  ["陀螺（绿色）"] = {
    icon = 2130,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用木头制成，玩时可用绳子缠绕，用力抽绳，使直立旋转",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:陀螺:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃法伤值\n(金色>紫色>蓝色)"
  },
  ["陀螺（蓝色）"] = {
    icon = 2130,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用木头制成，玩时可用绳子缠绕，用力抽绳，使直立旋转",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:陀螺:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃法伤值\n(金色>紫色>蓝色)"
  },
  ["陀螺（紫色）"] = {
    icon = 2130,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用木头制成，玩时可用绳子缠绕，用力抽绳，使直立旋转",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:陀螺:紫色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃法伤值\n(金色>紫色>蓝色)"
  },
  ["陀螺（金色）"] = {
    icon = 2130,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用木头制成，玩时可用绳子缠绕，用力抽绳，使直立旋转",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:陀螺:金色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃法伤值\n(金色>紫色>蓝色)"
  },
  ["风筝（绿色）"] = {
    icon = 2131,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用竹片、纸铸成鸟型，于风力大的地方放飞",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:风筝:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃法力值\n(金色>紫色>蓝色)"
  },
  ["风筝（蓝色）"] = {
    icon = 2131,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用竹片、纸铸成鸟型，于风力大的地方放飞",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:风筝:蓝色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃法力值\n(金色>紫色>蓝色)"
  },
  ["风筝（金色）"] = {
    icon = 2131,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用竹片、纸铸成鸟型，于风力大的地方放飞",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:风筝:金色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃法力值\n(金色>紫色>蓝色)"
  },
  ["风筝（紫色）"] = {
    icon = 2131,
    unit = "个",
    descript = "一种儿童期娃娃玩具，用竹片、纸铸成鸟型，于风力大的地方放飞",
    rescourse = {
      "娃娃日常",
      "#@集市逛摊|MarketBuyDlg=娃娃玩具:风筝:紫色#@"
    },
    double_type = 0,
    item_class = ITEM_CLASS.JOY,
    func = "可提升娃娃法力值\n(金色>紫色>蓝色)"
  },
  ["灵视符"] = {
    icon = 2086,
    unit = "张",
    descript = "使用后可获得灵视效果，可发现周围的鬼魂",
    rescourse = {
      "2019年中元节"
    }
  },
  ["河灯"] = {
    icon = 2087,
    unit = "盏",
    descript = "使用后可点燃河灯，和已故的亲人点亮轮回之路",
    rescourse = {
      "2019年中元节"
    }
  },
  ["老虎喇叭"] = {
    icon = 2140,
    unit = "个",
    descript = "能发出虎一样的吼声，可以用来驱赶#R野狗#n或#R野狼#n",
    rescourse = {
      "2019年重阳节活动"
    }
  },
  ["猫喇叭"] = {
    icon = 2141,
    unit = "个",
    descript = "能发出猫一般的叫声，可以驱赶#R瘟疫鼠#n",
    rescourse = {
      "2019年重阳节活动"
    }
  },
  ["如意令"] = {
    icon = 2142,
    unit = "个",
    double_type = 2,
    descript = "万事顺利，吉祥如意。使用后可激活队标界面的如意令队标 ",
    rescourse = {
      "系统赠送"
    }
  },
  ["问道情"] = {
    icon = 2143,
    unit = "个",
    double_type = 2,
    color = "金色",
    descript = "山长路远，问道相伴。使用后可激活队标界面的问道情队标 ",
    rescourse = {
      "元宝购买"
    }
  },
  ["八卦阵"] = {
    icon = 2144,
    unit = "个",
    double_type = 2,
    color = "金色",
    descript = "太极生两仪，两仪生四相，四相生八卦。使用后可激活队标界面的八卦阵队标",
    rescourse = {
      "元宝购买"
    }
  },
  ["吉祥结"] = {
    icon = 2145,
    unit = "个",
    double_type = 2,
    color = "金色",
    descript = "吉祥如意，事事顺心。使用后可激活队标界面的吉祥结队标",
    rescourse = {
      "元宝购买"
    }
  },
  ["星辰奇缘"] = {
    icon = 2146,
    unit = "个",
    double_type = 2,
    color = "金色",
    descript = "夜空中最亮的星，能否听清。使用后可激活队标界面的星辰奇缘队标",
    rescourse = {
      "道心特权活动"
    },
    custom_tips = "道心会员专属"
  },
  ["月亮之上"] = {
    icon = 2148,
    unit = "个",
    double_type = 2,
    color = "金色",
    descript = "月出光在天，月亮光在地。使用后可激活队标界面的月亮之上队标",
    rescourse = {
      "元宝购买"
    }
  },
  ["大风车"] = {
    icon = 2149,
    unit = "个",
    double_type = 2,
    color = "金色",
    descript = "大风车吱呀吱哟哟地转，这里的风景呀真好看。使用后可激活队标界面的大风车队标",
    rescourse = {
      "元宝购买"
    }
  },
  ["归来兮"] = {
    icon = 2150,
    unit = "个",
    double_type = 2,
    color = "金色",
    descript = "一路风尘一路景，人生何处不归途。使用后可激活队标界面的归来兮队标",
    rescourse = {
      "新服回归活动"
    }
  },
  ["【己亥国庆】活跃礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "2019年国庆活动"
    },
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石"
  },
  ["【己亥国庆】登录礼包"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "2019年国庆活动"
    },
    descript = "内含188银元宝、1颗点化丹、1颗宠物强化丹"
  },
  ["【己亥国庆】寻宝大礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2019年国庆活动"
    },
    descript = "内含6张藏宝图、6张超级藏宝图"
  },
  ["【己亥国庆】宠物欢乐礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2019年国庆活动"
    },
    descript = "内含3瓶超级归元露、2颗宠物强化丹、2颗宠物顿悟丹、2颗点化丹"
  },
  ["【己亥国庆】宠物进阶礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2019年国庆活动"
    },
    descript = "内含4册天书、4颗羽化丹、3颗宠物顿悟丹、6颗超级神兽丹"
  },
  ["【己亥国庆】豪华刷道礼包"] = {
    icon = 9108,
    unit = "个",
    rescourse = {
      "2019年国庆活动"
    },
    descript = "内含14包超级仙风散、14包宠风散、8个急急如律令、4道紫气鸿蒙"
  },
  ["【己亥国庆】装备提升礼包"] = {
    icon = 9109,
    unit = "个",
    rescourse = {
      "2019年国庆活动"
    },
    descript = "内含24块超级灵石、24块超级晶石、6块装备共鸣石"
  },
  ["【己亥国庆】装备高级礼包"] = {
    icon = 8063,
    unit = "个",
    rescourse = {
      "2019年国庆活动"
    },
    descript = "内含3颗超级粉水晶、3颗超级绿水晶、18颗黄水晶、5颗超级圣水晶、5块装备共鸣石"
  },
  ["魂器·锋芒"] = {
    icon = 1420,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·锋芒#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["魂器·魂灯"] = {
    icon = 1421,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·魂灯#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["魂器·鬼步"] = {
    icon = 1422,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·鬼步#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["魂器·润泽"] = {
    icon = 1423,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·润泽#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["魂器·薄暮"] = {
    icon = 1424,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·薄暮#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["魂器·轮回"] = {
    icon = 1425,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·轮回#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["魂器·伏虎"] = {
    icon = 1426,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·伏虎#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["魂器·双极"] = {
    icon = 1427,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·双极#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["魂器·灵咒"] = {
    icon = 1428,
    descript = "",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=魂器:魂器·灵咒#@",
      "地府活动"
    },
    unit = "件",
    equipType = "魂器"
  },
  ["天倾石"] = {
    icon = 1717,
    descript = "传说中的天柱之石，因共工氏撞不周山而跌落九幽，融合有阴阳之力，可引动魂器中的混沌之气",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=装备道具:天倾石#@",
      "地府活动"
    },
    unit = "块",
    double_type = 1,
    use_level = 75,
    try_level_tip = "适用等级：大于等于%d级",
    apply = "HorcruxAttriRefineDlg",
    color = "金色"
  },
  ["凝神草"] = {
    icon = 2132,
    unit = "株",
    double_type = 1,
    use_level = 75,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "生长于冥界的稀有植物，百年长一分，万年方可长成，服食后可壮大鬼宠魂魄",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=宠物道具:凝神草#@",
      "地府活动"
    },
    color = "金色"
  },
  ["鬼宠亲密丹"] = {
    icon = 2133,
    unit = "颗",
    color = "金色",
    double_type = 0,
    use_level = 75,
    coin = 54,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "鬼宠使用后将获得2000点亲密度",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=宠物道具:鬼宠亲密丹#@",
      "地府活动"
    }
  },
  ["灵海残卷"] = {
    icon = 2147,
    unit = "本",
    double_type = 1,
    descript = "由阎罗王炼制，连接有地府众神通者灵识的鬼卷，集齐七卷者可求得一化外分身，护其无碍",
    rescourse = {
      "地府活动"
    },
    use_level = 75,
    try_level_tip = "适用等级：大于等于%d级",
    color = "金色"
  },
  ["冥海霞光"] = {
    icon = 2134,
    unit = "道",
    double_type = 0,
    use_level = 75,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "在冥海上极难一见的霞光，以之为引可于苍茫冥海中寻觅太阴之气",
    rescourse = {
      "#@阴气之尘兑换商店|YinHunShopDlg#@",
      "地府活动"
    },
    color = "金色"
  },
  ["冥海神光"] = {
    icon = 2135,
    unit = "道",
    double_type = 1,
    use_level = 75,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "万丈冥海霞光才能孕育而出的太初之华——冥海神光，珍稀异常",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=其他道具:冥海神光#@",
      "#@阴气之尘兑换商店|YinHunShopDlg#@",
      "地府活动"
    },
    color = "金色"
  },
  ["太阴之气"] = {
    icon = 0,
    icons = {
      ["蓝色"] = 2136,
      ["粉色"] = 2137,
      ["金色"] = 2138
    },
    unit = "道",
    double_type = 2,
    descript = "气志者，五藏之使候也，将太阴之气注入魂窍之中，可勾连魂窍，壮人神魂。",
    rescourse = {}
  },
  ["冥界宝盒"] = {
    icon = 2123,
    unit = "个",
    double_type = 2,
    descript = "牛头赠送的冥界宝盒，打开后随机获得一份珍贵道具。",
    rescourse = {
      "引魂入殿"
    }
  },
  ["白酒（祭拜水官）"] = {
    icon = 1033,
    unit = "壶",
    double_type = 2,
    cardUseButtonName = "祭  拜",
    descript = "经一系列工艺酿制而成的白酒，散发着浓浓的酒香",
    rescourse = {
      "2019年下元节活动"
    },
    cmd = "CMD_XIAYUAN_JBSG"
  },
  ["糕点（祭拜水官）"] = {
    icon = 1625,
    unit = "块",
    double_type = 2,
    cardUseButtonName = "祭  拜",
    descript = "糕点师傅精心制作的糕点，口味非常的独特",
    rescourse = {
      "2019年下元节活动"
    },
    cmd = "CMD_XIAYUAN_JBSG"
  },
  ["水果（祭拜水官）"] = {
    icon = 1022,
    unit = "块",
    double_type = 2,
    cardUseButtonName = "祭  拜",
    descript = "一盘简简单单的新鲜水果",
    rescourse = {
      "2019年下元节活动"
    },
    cmd = "CMD_XIAYUAN_JBSG"
  },
  ["强化丸·地宫"] = {
    icon = 2005,
    unit = "颗",
    double_type = 3,
    descript = "蕴含神秘力量的药丸，只在地宫中出现过，使用后可增加角色及当前出战宠物的基础属性#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["回血丸·地宫"] = {
    icon = 8028,
    unit = "颗",
    double_type = 3,
    descript = "在地宫战斗中对己方目标使用，可使其恢复100%气血值#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["复灵丸·地宫"] = {
    icon = 8027,
    unit = "颗",
    double_type = 3,
    descript = "在地宫战斗中对自己或宠物使用，可使其恢复100%法力值#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["嗜血丸·地宫"] = {
    icon = 8029,
    unit = "颗",
    double_type = 3,
    descript = "在地宫战斗中对敌方目标使用，使其血量瞬间为0倒地死亡，但对部分力量强大或处于隐身状态的敌人无效#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["初级通关令·地宫"] = {
    icon = 8065,
    unit = "块",
    double_type = 3,
    descript = "地宫1-1至2-5关卡中将之交给守门灵可直接通关，无需战斗也可获得相应奖励#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["中级通关令·地宫"] = {
    icon = 8066,
    unit = "块",
    double_type = 3,
    descript = "地宫3-1至4-4关卡中将之交给守门灵可直接通关，无需战斗也可获得相应奖励#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["清心丸·地宫"] = {
    icon = 8032,
    unit = "颗",
    double_type = 3,
    descript = "使用后可清除因鬼魂怨念带来的不利状态#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["天眼符·地宫"] = {
    icon = 1577,
    unit = "张",
    double_type = 3,
    descript = "使用后可开启当前地宫所在关卡的所有视野，使用后可在小地图查看该层地图全貌#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["驱邪符·地宫"] = {
    icon = 2038,
    unit = "张",
    double_type = 3,
    descript = "对地宫中的妖魔：伏地魔、鬼冥王、冥夜魔、噬夜魔、暗黑狼王使用，可直接将其驱散，无需战斗也可获得相应奖励\n#R（仅在地宫中生效）#n",
    rescourse = {"地宫"}
  },
  ["瑞雪礼物"] = {
    icon = 8063,
    descript = "瑞雪之树赠送的礼物，代表着祝福之意",
    rescourse = {
      "2019年瑞雪节"
    },
    unit = "份",
    double_type = 2
  },
  ["法宝亲密丹"] = {
    icon = 9064,
    unit = "颗",
    double_type = 0,
    descript = "相传是老君炼制法宝的火炉里不断熔炼天材地宝而生的灵丹，可令法宝产生灵器之愉，增加1000点法宝亲密度",
    use_level = 70,
    level_tip = "角色等级达到#R70级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "#@帮派商店|PartyShopDlg=法宝亲密丹#@",
      "#P声望商店|竞技使者|M=声望商店::ArenaStoreDlg=法宝亲密丹#P"
    }
  },
  ["伶俐鼠宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖伶俐鼠或伶俐鼠变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["笨笨牛宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖笨笨牛或笨笨牛变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["威威虎宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖威威虎或威威虎变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["跳跳兔宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖跳跳兔或跳跳兔变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["酷酷龙宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖酷酷龙或酷酷龙变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["花花蛇宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖花花蛇或花花蛇变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["溜溜马宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖溜溜马或溜溜马变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["咩咩羊宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖咩咩羊或咩咩羊变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["帅帅猴宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖帅帅猴或帅帅猴变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["蛋蛋鸡宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖蛋蛋鸡或蛋蛋鸡变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["乖乖狗宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖乖乖狗或乖乖狗变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["招财猪宝箱"] = {
    icon = 9151,
    unit = "个",
    descript = "开启后有几率抽中变异大奖招财猪或招财猪变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["疆良宝箱"] = {
    icon = 9152,
    unit = "个",
    descript = "开启后有几率抽中神兽大奖疆良或疆良变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["东山神灵宝箱"] = {
    icon = 9152,
    unit = "个",
    descript = "开启后有几率抽中神兽大奖东山神灵或东山神灵变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["玄武宝箱"] = {
    icon = 9152,
    unit = "个",
    descript = "开启后有几率抽中神兽大奖玄武或玄武变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["朱雀宝箱"] = {
    icon = 9152,
    unit = "个",
    descript = "开启后有几率抽中神兽大奖朱雀或朱雀变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["九尾狐宝箱"] = {
    icon = 9152,
    unit = "个",
    descript = "开启后有几率抽中神兽大奖九尾狐或九尾狐变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["白矖宝箱"] = {
    icon = 9152,
    unit = "个",
    descript = "开启后有几率抽中神兽大奖白矖或白矖变身卡",
    double_type = 2,
    use_level = 75,
    level_tip = "角色等级达到#R75级#n后方可使用。",
    try_level_tip = "适用等级：角色大于等于%d级",
    rescourse = {
      "新服预约活动"
    }
  },
  ["鬼卒灵魄"] = {
    icon = 12007,
    descript = "由鬼卒转化而成的灵魄，可在鬼宠洗炼中代替鬼宠作为材料",
    rescourse = {
      "#@鬼宠转化|PetAttribDlg=ghost#@",
      "#@集市逛摊|MarketBuyDlg=宠物道具:鬼卒灵魄#@"
    },
    unit = "个",
    isCanDouble = true
  },
  ["2019全民PK报名券"] = {
    icon = 1843,
    unit = "张",
    descript = "拥有者可以免除报名2019年全民PK活动所需的费用",
    double_type = 0,
    use_level = 10,
    level_tip = "角色等级达到#R10级#n后方可使用。",
    try_level_tip = "适用等级：大于等于%d级",
    rescourse = {
      "2019全民PK活动"
    }
  },
  ["好运牌"] = {
    icon = 9243,
    unit = "块",
    descript = "从周华健处领取的好运牌，使用可抽取奖励。",
    rescourse = {
      "周华健好运礼包"
    }
  },
  ["入门刷道礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "内含8包超级仙风散、4包宠风散、2个急急如律令、1道紫气鸿蒙，购买后立即获得7天高级托管（礼包价值3222元宝）",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=入门刷道礼包#@"
    }
  },
  ["豪华刷道礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "内含40包超级仙风散、16包宠风散、8个急急如律令、4道紫气鸿蒙，购买后立即获得30天高级托管（礼包价值13872元宝）",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=豪华刷道礼包#@"
    }
  },
  ["战魂"] = {
    icon = 2085,
    descript = "使用后可获得特殊的战魂特效围绕身边，让你充满独特魅力",
    func = "使用后可获得特殊的战魂特效",
    rescourse = {
      "名人堂兑换"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    custom_tips = "名人堂专属"
  },
  ["御九天"] = {
    icon = 9524,
    unit = "套",
    gender = 1,
    descript = "神之去兮升九天，斩断世间浮华梦。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "名人堂兑换"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "斩梦华",
    custom_tips = "名人堂专属",
    color = "金色"
  },
  ["斩梦华"] = {
    icon = 9525,
    unit = "套",
    gender = 2,
    descript = "神之去兮升九天，斩断世间浮华梦。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "名人堂兑换"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "御九天",
    custom_tips = "名人堂专属",
    color = "金色"
  },
  ["雀羽极"] = {
    icon = 9526,
    unit = "套",
    gender = 1,
    descript = "翠藻蔓长孔雀尾，羽绒豪放云天骄。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "雀羽翎",
    color = "金色"
  },
  ["雀羽翎"] = {
    icon = 9527,
    unit = "套",
    gender = 2,
    descript = "翠藻曼长孔雀尾，羽绒豪放云天骄。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "雀羽极",
    color = "金色"
  },
  ["望月白"] = {
    icon = 9528,
    unit = "套",
    gender = 1,
    descript = "望月独相思，雪晴霜夜时。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "周年活动",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "霜夜雪",
    color = "金色"
  },
  ["霜夜雪"] = {
    icon = 9529,
    unit = "套",
    gender = 2,
    descript = "望月独相思，雪晴霜夜时。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "周年活动",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "绝版时装活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "望月白",
    color = "金色"
  },
  ["山藏海"] = {
    icon = 9534,
    unit = "套",
    gender = 1,
    descript = "山高高兮蔽目，海茫茫兮无边，无波无澜明如镜，扶摇其上可牧云。男子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=山藏海#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "新服活动",
      "代言人信物活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "水牧云",
    color = "金色"
  },
  ["水牧云"] = {
    icon = 9535,
    unit = "套",
    gender = 2,
    descript = "山高高兮蔽目，海茫茫兮无边，无波无澜明如镜，扶摇其上可牧云。女子使用后将会身着华美的服饰",
    double_type = 2,
    rescourse = {
      "#@在线商城|OnlineMallDlg=水牧云#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:时装#@",
      "新服活动",
      "代言人信物活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "山藏海",
    color = "金色"
  },
  ["名人头像框"] = {
    icon = 2083,
    descript = "使用后可获得特殊的名人头像框使用时间，各种霸气标识将装饰你的聊天头像，让你聊天时尽显独特魅力",
    rescourse = {
      "名人堂兑换"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Icon2941.png",
    chat_icon_res_type = 1
  },
  ["名人聊天底框"] = {
    icon = 2084,
    descript = "使用后可获得特殊的名人聊天底框使用时间，各种霸气标识将装饰你的聊天底框，让你聊天时尽显独特魅力",
    rescourse = {
      "名人堂兑换"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Background0303.png",
    chat_icon_res_type = 1
  },
  ["霸叨叨"] = {
    icon = 2305,
    descript = "使用后可获得酷萌酷萌的霸叨叨跟随自身",
    rescourse = {
      "名人堂兑换"
    },
    unit = "只",
    double_type = 2,
    color = "金色",
    custom_tips = "名人堂专属"
  },
  ["名人红包令牌"] = {
    icon = 1842,
    unit = "块",
    double_type = 2,
    descript = "使用此令牌可开启名人红包活动，更多活动细节可点击使用后在活动开启界面中查看",
    rescourse = {"名人堂"}
  },
  ["【庚子春节】新年礼包"] = {
    icon = 8009,
    descript = "内含100银元宝、1包超级仙风散、2颗鬼宠亲密丹",
    rescourse = {
      "2020年春节活动"
    }
  },
  ["【庚子春节】登录礼包"] = {
    icon = 8010,
    descript = "内含300银元宝、1个神木鼎、1瓶超级归元露",
    rescourse = {
      "2020年春节活动"
    }
  },
  ["【庚子春节】寻宝礼包"] = {
    icon = 8001,
    descript = "内含10张超级藏宝图",
    rescourse = {
      "2020年春节活动"
    }
  },
  ["【庚子春节】宠物提升礼包"] = {
    icon = 9107,
    descript = "内含14本灵海残卷、8颗点化丹",
    rescourse = {
      "2020年春节活动"
    }
  },
  ["【庚子春节】豪华刷道礼包"] = {
    icon = 9107,
    descript = "内含16包超级仙风散、10包宠风散、8个急急如律令",
    rescourse = {
      "2020年春节活动"
    }
  },
  ["【庚子春节】宠物进阶礼包"] = {
    icon = 9108,
    descript = "内含8颗宠物强化丹、8颗羽化丹、3颗宠物顿悟丹",
    rescourse = {
      "2020年春节活动"
    }
  },
  ["【庚子春节】装备炼化礼包"] = {
    icon = 9109,
    descript = "内含3颗超级粉水晶、12颗黄水晶、3颗超级绿水晶、2颗超级圣水晶",
    rescourse = {
      "2020年春节活动"
    }
  },
  ["【庚子春节】装备改造礼包"] = {
    icon = 8063,
    descript = "内含20块超级灵石、50块超级晶石、25块装备共鸣石",
    rescourse = {
      "2020年春节活动"
    }
  },
  ["2020年新年红包"] = {
    icon = 1939,
    unit = "个",
    descript = "恭祝各位道友新年大吉！打开红包后可获得随机数量的银元宝",
    double_type = 0,
    rescourse = {
      "新服预约活动"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["水桶"] = {
    icon = 9244,
    unit = "个",
    descript = "一个普通的水桶，可前往河流区域取水",
    double_type = 2,
    rescourse = {
      "2020年植树节活动"
    }
  },
  ["普通的河水"] = {
    icon = 9245,
    unit = "桶",
    descript = "一桶普通的河水，不含一丝灵气",
    double_type = 2,
    rescourse = {
      "2020年植树节活动"
    }
  },
  ["金灵水"] = {
    icon = 9246,
    unit = "桶",
    descript = "一桶充满金属性灵气的水",
    double_type = 2,
    rescourse = {
      "2020年植树节活动"
    }
  },
  ["木灵水"] = {
    icon = 9247,
    unit = "桶",
    descript = "一桶充满木属性灵气的水",
    double_type = 2,
    rescourse = {
      "2020年植树节活动"
    }
  },
  ["水灵水"] = {
    icon = 9248,
    unit = "桶",
    descript = "一桶充满水属性灵气的水",
    double_type = 2,
    rescourse = {
      "2020年植树节活动"
    }
  },
  ["火灵水"] = {
    icon = 9249,
    unit = "桶",
    descript = "一桶充满火属性灵气的水",
    double_type = 2,
    rescourse = {
      "2020年植树节活动"
    }
  },
  ["土灵水"] = {
    icon = 9250,
    unit = "桶",
    descript = "一桶充满土属性灵气的水",
    double_type = 2,
    rescourse = {
      "2020年植树节活动"
    }
  },
  ["《神秘房间》案卷宗"] = {
    icon = 2023,
    descript = "关于神秘房间案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    double_type = 2,
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】神秘房间"
  },
  ["美味的草鱼"] = {
    icon = 13204,
    descript = "美味的草鱼，猫科动物最爱",
    rescourse = {
      "探案任务"
    },
    unit = "条",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["美味的玉米"] = {
    icon = 7205,
    descript = "美味的玉米，还挺填肚子的",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["神秘红水晶"] = {
    icon = 2159,
    descript = "一块红水晶，应该有什么妙用",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["神秘绿水晶"] = {
    icon = 2160,
    descript = "一块绿水晶，应该有什么妙用",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["神秘蓝水晶"] = {
    icon = 2161,
    descript = "一块蓝水晶，应该有什么妙用",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["神秘紫水晶"] = {
    icon = 2162,
    descript = "一块紫水晶，应该有什么妙用",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["奇怪的照妖镜"] = {
    icon = 1659,
    descript = "照妖镜，可看穿一些事物的本质",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["烧坏的仕女图"] = {
    icon = 2163,
    descript = "一张仕女图，上面有严重烧坏的痕迹",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["已修复的仕女图"] = {
    icon = 10100,
    descript = "经美树修复的仕女图，很是美丽，可以挂在墙上欣赏",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    item_class = ITEM_CLASS.CASE_SMFJ_JM,
    double_type = 2
  },
  ["大妖内丹"] = {
    icon = 1844,
    unit = "颗",
    descript = "妖魔内丹，充斥着妖魔的邪气，可以提交给镇魔道人净化妖魔内丹以换取奖励",
    double_type = 0,
    rescourse = {"镇魔录"},
    color = "金色"
  },
  ["妖王内丹"] = {
    icon = 1845,
    unit = "颗",
    descript = "妖魔内丹，充斥着妖魔的邪气，可以提交给镇魔道人净化妖魔内丹以换取奖励",
    double_type = 0,
    color = "金色",
    rescourse = {"镇魔录"}
  },
  ["30级中洲助力礼包"] = {
    icon = 9109,
    unit = "个",
    descript_male = "内含狐灵逸（30天）和40级中洲助力礼包",
    descript_female = "内含狐灵娇（30天）和40级中洲助力礼包",
    double_type = 2,
    rescourse = {
      "中洲助力活动"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本礼包。"
  },
  ["40级中洲助力礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含5本修炼卷轴、1个天神护佑和50级中洲助力礼包",
    double_type = 2,
    rescourse = {
      "中洲助力活动"
    },
    use_level = 40,
    level_tip = "角色等级达到#R40级#n后方可使用本礼包。"
  },
  ["50级中洲助力礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含5颗宠物强化丹、2枚如意刷道令、1个情缘盒和60级中洲助力礼包",
    double_type = 2,
    rescourse = {
      "中洲助力活动"
    },
    use_level = 50,
    level_tip = "角色等级达到#R50级#n后方可使用本礼包。"
  },
  ["60级中洲助力礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含3颗点化丹、1颗羽化丹、3颗风灵丸和70级中洲助力礼包",
    double_type = 2,
    rescourse = {
      "中洲助力活动"
    },
    use_level = 60,
    level_tip = "角色等级达到#R60级#n后方可使用本礼包。"
  },
  ["70级中洲助力礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含10包超级仙风散、6个急急如律令、6包宠风散、4道紫气鸿蒙和80级中洲助力礼包",
    double_type = 2,
    rescourse = {
      "中洲助力活动"
    },
    use_level = 70,
    level_tip = "角色等级达到#R70级#n后方可使用本礼包。"
  },
  ["80级中洲助力礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含1颗超级粉水晶、1颗超级绿水晶、3颗黄水晶和6块超级灵石",
    double_type = 2,
    rescourse = {
      "中洲助力活动"
    },
    use_level = 80,
    level_tip = "角色等级达到#R80级#n后方可使用本礼包。"
  },
  ["如意鼠"] = {
    icon = 2306,
    descript = "使用后可获得萌萌的如意鼠跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色",
    custom_tips = "购买特殊时装赠送"
  },
  ["【再续前缘】寻宝助力礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2020年回归助力"
    },
    descript = "内含6张藏宝图、6张超级藏宝图"
  },
  ["【再续前缘】守护助力礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "2020年回归助力"
    },
    descript = "内含1个天神护佑、1颗血玲珑、1颗法玲珑、1册天书"
  },
  ["【再续前缘】刷道助力礼包"] = {
    icon = 9108,
    unit = "个",
    rescourse = {
      "2020年回归助力"
    },
    descript = "内含9包超级仙风散、7包宠风散、5个急急如律令"
  },
  ["【再续前缘】装备助力礼包"] = {
    icon = 9109,
    unit = "个",
    rescourse = {
      "2020年回归助力"
    },
    descript = "内含6块超级灵石、12块超级晶石、1颗超级粉水晶、1颗超级绿水晶、6颗黄水晶"
  },
  ["《妙手回春》案卷宗"] = {
    icon = 2023,
    descript = "关于谁是卧底案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】妙手回春"
  },
  ["豪华的佩剑"] = {
    icon = 2155,
    descript = "一把豪华的佩剑，剑的主人一定很富裕。",
    rescourse = {
      "探案任务"
    },
    unit = "把",
    double_type = 2
  },
  ["东郭大夫画像"] = {
    icon = 2156,
    descript = "5年前命案的凶手的画像，脸上有一道可怕的伤疤。",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    double_type = 2
  },
  ["《水潭迷踪》案卷宗"] = {
    icon = 2023,
    descript = "关于水潭迷踪案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】水潭迷踪"
  },
  ["染血的斧头"] = {
    icon = 1856,
    descript = "一把锋利的斧头，在水潭中浸泡了数月，却依然闪着寒光",
    rescourse = {
      "探案任务"
    },
    unit = "把",
    double_type = 2
  },
  ["写给朱氏的信"] = {
    icon = 2030,
    descript = "朱如象离家后托人送回的书信",
    rescourse = {
      "探案任务"
    },
    unit = "封",
    double_type = 2,
    cmd = "CMD_STMZ_USE_ITEM"
  },
  ["写给朱太公的信"] = {
    icon = 2030,
    descript = "朱如象离家后托人送回的书信",
    rescourse = {
      "探案任务"
    },
    unit = "封",
    double_type = 2,
    cmd = "CMD_STMZ_USE_ITEM"
  },
  ["写给朱二嫂的信"] = {
    icon = 2030,
    descript = "朱如象离家后托人送回的书信",
    rescourse = {
      "探案任务"
    },
    unit = "封",
    double_type = 2,
    cmd = "CMD_STMZ_USE_ITEM"
  },
  ["写给朱大哥的信"] = {
    icon = 2030,
    descript = "朱如象离家后托人送回的书信",
    rescourse = {
      "探案任务"
    },
    unit = "封",
    double_type = 2,
    cmd = "CMD_STMZ_USE_ITEM"
  },
  ["写给朱幺妹的信"] = {
    icon = 2030,
    descript = "朱如象离家后托人送回的书信",
    rescourse = {
      "探案任务"
    },
    unit = "封",
    double_type = 2,
    cmd = "CMD_STMZ_USE_ITEM"
  },
  ["一袋大米"] = {
    icon = 1851,
    descript = "颗粒丰满肥厚，煮后软韧有劲而不粘，乃米中上品",
    rescourse = {
      "探案任务"
    },
    unit = "包",
    double_type = 2
  },
  ["一袋干粮"] = {
    icon = 1852,
    descript = "晒干的馒头，抵得几日口粮",
    rescourse = {
      "探案任务"
    },
    unit = "包",
    double_type = 2
  },
  ["一袋面粉"] = {
    icon = 1853,
    descript = "石磨研磨的面粉，淡黄色、麦香浓郁",
    rescourse = {
      "探案任务"
    },
    unit = "包",
    double_type = 2
  },
  ["一袋黄豆"] = {
    icon = 1854,
    descript = "颗粒饱满圆润，豆香扑鼻",
    rescourse = {
      "探案任务"
    },
    unit = "包",
    double_type = 2
  },
  ["一袋水果"] = {
    icon = 1855,
    descript = "应季鲜果，香气四溢",
    rescourse = {
      "探案任务"
    },
    unit = "包",
    double_type = 2
  },
  ["账簿"] = {
    icon = 1942,
    descript = "记录着赵家店铺经营明细的账簿",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    double_type = 2,
    cmd = "CMD_STMZ_USE_ITEM"
  },
  ["《缉拿山贼》案卷宗"] = {
    icon = 2023,
    descript = "关于缉拿山贼案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】缉拿山贼"
  },
  ["木尺"] = {
    icon = 1846,
    unit = "根",
    double_type = 2,
    descript = "一根扁扁的木尺，材质寻常",
    rescourse = {
      "探案任务"
    }
  },
  ["布带"] = {
    icon = 1847,
    unit = "条",
    double_type = 2,
    descript = "一条长长的带子，上面写满了奇怪的符号",
    rescourse = {
      "探案任务"
    }
  },
  ["木盒"] = {
    icon = 1848,
    unit = "个",
    double_type = 2,
    descript = "一个巴掌大小的木盒，扣的严丝合缝，不知从哪里打开",
    rescourse = {
      "探案任务"
    }
  },
  ["碎纸片"] = {
    icon = 1849,
    unit = "堆",
    double_type = 2,
    descript = "一堆碎纸片，每张上面都有一些奇怪的图案",
    rescourse = {
      "探案任务"
    }
  },
  ["黄捕头的书信"] = {
    icon = 2030,
    unit = "封",
    double_type = 2,
    descript = "黄捕头得到线索，镖车中藏有炸药，所以修书一封由郑捕头交给你",
    rescourse = {
      "探案任务"
    }
  },
  ["奇怪的木片"] = {
    icon = 1850,
    unit = "块",
    double_type = 2,
    descript = "一块半个手掌大的木片，上面有一些奇怪的痕迹",
    rescourse = {
      "探案任务"
    }
  },
  ["硫磺"] = {
    icon = 1857,
    unit = "包",
    descript = "人气大服活动#R烟花大会#n专属道具，在烟花界面与其他两种道具一起合成烟花（在烟花大会材料收集阶段参与部分日常可获得）",
    use_level = 10,
    try_level_tip = "适用等级：大于等于%d级",
    rescourse = {
      "烟花大会活动"
    }
  },
  ["碳粉"] = {
    icon = 1858,
    unit = "包",
    use_level = 10,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "人气大服活动#R烟花大会#n专属道具，在烟花界面与其他两种道具一起合成烟花（在烟花大会材料收集阶段参与部分日常可获得）",
    rescourse = {
      "烟花大会活动"
    }
  },
  ["彩色石"] = {
    icon = 1859,
    unit = "块",
    use_level = 10,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "人气大服活动#R烟花大会#n专属道具，在烟花界面与其他两种道具一起合成烟花（在烟花大会材料收集阶段参与部分日常可获得）",
    rescourse = {
      "烟花大会活动"
    }
  },
  ["人气烟花·盛世繁花"] = {
    icon = 2070,
    unit = "个",
    use_level = 10,
    item_class = ITEM_CLASS.FIREWORKS,
    cmd_para = 1,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "人气大服活动#R烟花大会#n专属道具，在燃放烟花阶段使用可释放美丽烟花，并增加#RN#n点烟花积分（通过烟花材料合成获得，燃放阶段活动大使处亦可领取部分烟花）",
    rescourse = {
      "烟花大会活动"
    }
  },
  ["人气烟花·满天星雨"] = {
    icon = 2071,
    unit = "个",
    use_level = 10,
    item_class = ITEM_CLASS.FIREWORKS,
    cmd_para = 2,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "人气大服活动#R烟花大会#n专属道具，在燃放烟花阶段使用可释放美丽烟花，并增加#RN#n点烟花积分（通过烟花材料合成获得，燃放阶段活动大使处亦可领取部分烟花）",
    rescourse = {
      "烟花大会活动"
    }
  },
  ["人气烟花·绚丽彩焰"] = {
    icon = 2072,
    unit = "个",
    use_level = 10,
    item_class = ITEM_CLASS.FIREWORKS,
    cmd_para = 3,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "人气大服活动#R烟花大会#n专属道具，在燃放烟花阶段使用可释放美丽烟花，并增加#RN#n点烟花积分（通过烟花材料合成获得，燃放阶段活动大使处亦可领取部分烟花）",
    rescourse = {
      "烟花大会活动"
    }
  },
  ["人气礼花·万花争鸣"] = {
    icon = 2157,
    unit = "个",
    use_level = 10,
    item_class = ITEM_CLASS.FIREWORKS,
    cmd_para = 4,
    try_level_tip = "适用等级：大于等于%d级",
    descript = "人气大服活动#R烟花大会#n专属道具，在燃放烟花阶段使用可释放华丽礼花，并增加#RN#n点烟花积分（燃放阶段在烟花界面中可购买）",
    rescourse = {
      "烟花大会活动"
    }
  },
  ["仙丹·下品"] = {
    icon = 2167,
    unit = "枚",
    double_type = 2,
    descript = "聚天地灵气炼制而成的仙丹，服用后可获得少量经验、道行",
    rescourse = {
      "2020年周年庆活动"
    }
  },
  ["仙丹·中品"] = {
    icon = 2168,
    unit = "枚",
    double_type = 2,
    descript = "聚天地灵气炼制而成的仙丹，服用后可获得较多经验、道行",
    rescourse = {
      "2020年周年庆活动"
    }
  },
  ["仙丹·上品"] = {
    icon = 2169,
    unit = "枚",
    double_type = 2,
    descript = "聚天地灵气炼制而成的仙丹，服用后可获得更多经验道行，还可能获得商城道具",
    rescourse = {
      "2020年周年庆活动"
    }
  },
  ["仙丹·完美"] = {
    icon = 2170,
    unit = "枚",
    double_type = 2,
    descript = "聚天地灵气炼制而成的仙丹，服用后必定可获得召唤令·梅兰竹菊一枚",
    rescourse = {
      "2020年周年庆活动"
    }
  },
  ["周年花篮"] = {
    icon = 9712,
    unit = "个",
    descript = "一个美丽的花篮，不仅能用来观赏以陶冶情操，还能助人提升修为，也有一定几率能获得稀有的元神碎片·武极，不过花期较短，请尽快使用哦",
    rescourse = {
      "2021年周年庆活动"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后才能使用周年花篮。",
    try_level_tip = "适用等级：角色大于等于%d级"
  },
  ["巅峰道行盛典礼包"] = {
    icon = 9110,
    unit = "个",
    descript = "新服盛典中道行排名前1000名获得的礼包（抽中神兽大奖者无法获得），开启后可获得超级女娲石、召唤令·十二生肖道具中的一种作为奖励",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["巅峰等级盛典礼包"] = {
    icon = 9110,
    unit = "个",
    descript = "新服盛典中等级排名前1000名获得的礼包（抽中神兽大奖者无法获得），开启后可获得超级女娲石、召唤令·十二生肖道具中的一种作为奖励",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["高级道行盛典礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "新服盛典道行排名第1001~3000名获得的礼包（抽中变异大奖者无法获得），开启后可获得黄水晶、羽化丹、超级绿水晶、超级圣水晶中的一种作为奖励",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["高级等级盛典礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "新服盛典等级排名第1001~3000名获得的礼包（抽中变异大奖者无法获得），开启后可获得黄水晶、羽化丹、超级绿水晶、超级圣水晶中的一种作为奖励",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["中级道行盛典礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "新服盛典道行排名第3001~6000名获得的礼包（抽中精怪大奖者无法获得），开启后可获得宠物强化丹、装备共鸣石、超级灵石中的一种作为奖励",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["中级等级盛典礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "新服盛典等级排名第3001~6000名获得的礼包（抽中精怪大奖者无法获得），开启后可获得宠物强化丹、装备共鸣石、超级灵石中的一种作为奖励",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["初级道行盛典礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "新服盛典道行排名6000名以外获得的礼包，开启后可获得超级归元露、超级神兽丹、超级晶石中的一种作为奖励",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["初级等级盛典礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "新服盛典等级排名6000名以外获得的礼包，开启后可获得超级归元露、超级神兽丹、超级晶石中的一种作为奖励",
    rescourse = {
      "新服盛典活动"
    }
  },
  ["张若昀的神秘宝箱"] = {
    icon = 1665,
    unit = "个",
    descript = "张若昀珍藏多年的神秘宝箱，听说箱子里藏着各种珍贵的道具",
    rescourse = {
      "神秘宝箱活动"
    },
    use_level = 20,
    level_tip = "角色等级达到#R20级#n后开放此功能。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["四周年头像框"] = {
    icon = 2098,
    descript = "使用后可获得特殊的四周年头像框使用时间，特殊的周年标识将装饰你的聊天头像，让你聊天时尽显独特魅力",
    rescourse = {
      "周年纪念商城"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Icon3151.png",
    chat_icon_res_type = 1
  },
  ["四周年聊天底框"] = {
    icon = 2099,
    descript = "使用后可获得特殊的四周年聊天底框使用时间，特殊的周年标识将装饰你的聊天底框，让你聊天时尽显独特魅力",
    rescourse = {
      "周年纪念商城"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Background0320.png",
    chat_icon_res_type = 1
  },
  ["四周年随心福袋"] = {
    icon = 8001,
    descript = "使用后随机获得四周年纪念宠元神碎片·流风或元神碎片·回雪，更有机会抽中召唤令·梅兰竹菊！",
    rescourse = {
      "周年纪念商城"
    },
    unit = "个",
    double_type = 2
  },
  ["昙花"] = {
    icon = 11006,
    unit = "束",
    descript = "赠予电台主人，提高其作品1点人气值",
    rescourse = {
      "妙音电台内购买"
    }
  },
  ["仙客来"] = {
    icon = 11007,
    unit = "束",
    descript = "赠予电台主人，提高其作品10点人气值",
    rescourse = {
      "妙音电台内购买"
    }
  },
  ["月下满天星"] = {
    icon = 11008,
    unit = "束",
    descript = "赠予电台主人，提高其作品20点人气值",
    rescourse = {
      "妙音电台内购买"
    }
  },
  ["召回礼包"] = {
    icon = 9107,
    unit = "个",
    descript = "感谢您对好友的召回，开启可获得商城道具奖励，更有机会抽取召唤令•十二生肖",
    rescourse = {
      "召回道友活动"
    }
  },
  ["钥匙扣"] = {
    icon = 1864,
    unit = "件",
    descript = "周边实物奖励，十分具有纪念价值。抽中该奖励后将收到收货信息收集邮件，请道友及时填写",
    rescourse = {
      "百宝袋活动"
    }
  },
  ["手机拉环"] = {
    icon = 1865,
    unit = "件",
    descript = "周边实物奖励，十分具有纪念价值。抽中该奖励后将收到收货信息收集邮件，请道友及时填写",
    rescourse = {
      "百宝袋活动"
    }
  },
  ["九尾狐公仔"] = {
    icon = 1866,
    unit = "件",
    descript = "周边实物奖励，十分具有纪念价值。抽中该奖励后将收到收货信息收集邮件，请道友及时填写",
    rescourse = {
      "百宝袋活动"
    }
  },
  ["太极熊公仔"] = {
    icon = 1867,
    unit = "件",
    descript = "周边实物奖励，十分具有纪念价值。抽中该奖励后将收到收货信息收集邮件，请道友及时填写",
    rescourse = {
      "百宝袋活动"
    }
  },
  ["北极熊公仔"] = {
    icon = 1869,
    unit = "件",
    descript = "周边实物奖励，十分具有纪念价值。抽中该奖励后将收到收货信息收集邮件，请道友及时填写",
    rescourse = {
      "百宝袋活动"
    }
  },
  ["混元金斗摆件"] = {
    icon = 1870,
    unit = "件",
    descript = "周边实物奖励，十分具有纪念价值。抽中该奖励后将收到收货信息收集邮件，请道友及时填写",
    rescourse = {
      "百宝袋活动"
    }
  },
  ["再续经典礼盒"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "再续前缘活动"
    },
    descript = "开启可获得商城道具奖励，更有机会抽取召唤令·十二生肖"
  },
  ["超级秋棠仙子卡"] = {
    icon = 8178,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为秋棠仙子",
    double_type = 0
  },
  ["超级镇水怪卡"] = {
    icon = 8179,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为镇水怪",
    double_type = 0
  },
  ["超级壳妖卡"] = {
    icon = 8435,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:水相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为壳妖",
    double_type = 0
  },
  ["超级符灵卡"] = {
    icon = 8436,
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=变身卡:怪物变身卡:木相性#@",
      "#@神木鼎|PracticeDlg#@"
    },
    unit = "张",
    descript = "怪物卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为符灵",
    double_type = 0
  },
  ["超级孔雀妖姬卡"] = {
    icon = 8454,
    rescourse = {
      "#@通天塔|ActivitiesDlg=日常活动#@",
      "#@集市逛摊|MarketBuyDlg=变身卡:妖王变身卡:土相性#@"
    },
    unit = "张",
    descript = "妖王卡，妖兽死亡后将其形神凝结其中，使用后可将外观变幻成为孔雀妖姬",
    double_type = 0
  },
  ["铸灵石"] = {
    icon = 9181,
    rescourse = {
      "#@附灵系统|SpiritSystemTabDlg=1#@"
    },
    unit = "颗",
    descript = "能够提升附灵阵铸造度，进而提升附灵阵等级阶位的神奇灵石",
    use_level = 130,
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["真灵精粹"] = {
    icon = 9182,
    rescourse = {
      "#@附灵系统|SpiritSystemTabDlg#@",
      "#@集市逛摊|MarketBuyDlg=其他道具:真灵精粹#@"
    },
    unit = "瓶",
    coin = 498,
    descript = "取天地灵气炼制而成，可提升附灵阵中真灵的等级",
    level_tip = "角色等级达到#R130级#n后开放该功能。",
    use_level = 130,
    try_level_tip = "适用等级：大于等于%d级",
    double_type = 1,
    color = "金色"
  },
  ["帮派功臣初级宝箱"] = {
    icon = 1860,
    rescourse = {
      "#P功勋商店|账房先生|E=功勋商店#P"
    },
    unit = "个",
    descript = "为帮派功臣准备的初级宝箱，打开可获得随机商城道具。",
    double_type = 0
  },
  ["帮派功臣中级宝箱"] = {
    icon = 1861,
    rescourse = {
      "#P功勋商店|账房先生|E=功勋商店#P"
    },
    unit = "个",
    descript = "为帮派功臣准备的中级宝箱，打开可获得随机商城道具，奖池比初级宝箱更丰厚。",
    double_type = 0
  },
  ["帮派功臣高级宝箱"] = {
    icon = 1862,
    rescourse = {
      "#P功勋商店|账房先生|E=功勋商店#P"
    },
    unit = "个",
    descript = "为帮派功臣准备的高级宝箱，打开可获得随机商城道具，奖池比中级宝箱更丰厚。",
    double_type = 0
  },
  ["帮派功臣顶级宝箱"] = {
    icon = 1863,
    rescourse = {
      "#P功勋商店|账房先生|E=功勋商店#P"
    },
    unit = "个",
    descript = "为帮派功臣准备的顶级宝箱，打开可获得随机商城道具，还有机会额外获得1枚召唤令·十二生肖。",
    double_type = 0
  },
  ["连理枝·七夕"] = {
    icon = 2174,
    rescourse = {
      "2020年七夕活动"
    },
    unit = "枝",
    descript = "在天愿作比翼鸟，在地愿为连理枝#R(2020年七夕活动专属道具)#n",
    double_type = 0
  },
  ["三生石·七夕"] = {
    icon = 2175,
    rescourse = {
      "2020年七夕活动"
    },
    unit = "块",
    descript = "三生缘分，三世情缘#R(2020年七夕活动专属道具)#n",
    double_type = 0
  },
  ["红绳·七夕"] = {
    icon = 2173,
    rescourse = {
      "2020年七夕活动"
    },
    unit = "条",
    descript = "月老的红绳，绑住天下有缘人#R(2020年七夕活动专属道具)#n",
    double_type = 0
  },
  ["食材•食神季"] = {
    icon = 2173,
    rescourse = {
      "食神季活动"
    },
    unit = "份",
    descript = "%s，小二哥搜寻中洲各地带回来的新鲜食材，食神曾叮嘱过做菜就应该用最新鲜的食材哦",
    double_type = 0,
    func = "#G食神季活动专属道具，可用于活动内的烹饪及菜谱研究#n"
  },
  ["菜肴•食神季"] = {
    icon = 2173,
    rescourse = {
      "食神季活动"
    },
    unit = "道",
    descript = "美味的%s，%d星菜肴，品质系数为#R%d#n",
    double_type = 0,
    func = "#G食神季活动专属道具，可食用获得道行、武学奖励#n"
  },
  ["鹭岛论道时装礼盒"] = {
    icon = 1578,
    unit = "个",
    double_type = 2,
    descript = "打开时可从已发售过的所有时装中（部分专属时装除外）任意选取一件，获得%s使用权限",
    rescourse = {
      "鹭岛论道"
    }
  },
  ["锦鲤时装礼盒"] = {
    icon = 1578,
    unit = "个",
    double_type = 0,
    descript = "打开时可从#R获奖时刻#n时已发售的所有时装（部分专属时装除外，但包括绝版时装，共13套）中任意选取一件，获得%s使用权限",
    rescourse = {
      "锦鲤活动"
    }
  },
  ["竞猜币"] = {
    icon = 1578,
    unit = "个",
    descript = "",
    rescourse = {
      "#@商城购买回馈|OnlineMallDlg#@",
      "#@100活跃度奖励|ActivitiesDlg#@"
    }
  },
  ["仙班月卡·高托礼包"] = {
    icon = 9108,
    unit = "个",
    descript = "内含位列仙班·月卡资格30天+高级托管时间15天(礼包价值3900元宝)\n#R高级托管#n功能45级开启，若使用礼包时不足45级，则从角色升至45级开始计时",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=仙班月卡·高托礼包#@"
    }
  },
  ["仙班季卡·高托礼包"] = {
    icon = 9109,
    unit = "个",
    descript = "内含位列仙班·季卡资格90天+高级托管时间45天(礼包价值11300元宝)\n#R高级托管#n功能45级开启，若使用礼包时不足45级，则从角色升至45级开始计时",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=仙班季卡·高托礼包#@"
    }
  },
  ["仙班年卡·高托礼包"] = {
    icon = 9110,
    unit = "个",
    descript = "内含位列仙班·年卡资格360天+高级托管时间180天(礼包价值44000元宝)\n#R高级托管#n功能45级开启，若使用礼包时不足45级，则从角色升至45级开始计时",
    double_type = 2,
    rescourse = {
      "#@商城限购|OnlineMallDlg=仙班年卡·高托礼包#@"
    }
  },
  ["榜首头像框"] = {
    icon = 2204,
    descript = "使用后可获得特殊的榜首头像框使用时间，孔雀神羽将装饰你的聊天头像，让你聊天时尽显独特魅力",
    rescourse = {
      "新服冲榜大赛"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Icon3220.png",
    chat_icon_res_type = 1
  },
  ["榜首聊天底框"] = {
    icon = 2205,
    descript = "使用后可获得特殊的榜首聊天底框使用时间，孔雀神羽将装饰你的聊天底框，让你聊天时尽显独特魅力",
    rescourse = {
      "新服冲榜大赛"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Background0322.png",
    chat_icon_res_type = 1
  },
  ["【国庆】登录礼包"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "2017年国庆节活动"
    },
    descript = "内含2颗超级神兽丹、1个火眼金睛、1颗超级黑水晶"
  },
  ["【中洲服】宠物初心礼袋"] = {
    icon = 8001,
    unit = "个",
    descript = "内含100银元宝、6颗宠物强化丹"
  },
  ["【中洲服】宠物增强礼袋"] = {
    icon = 9268,
    unit = "个",
    descript = "内含10瓶超级归元露、10颗羽化丹"
  },
  ["【中洲服】好运满满礼盒"] = {
    icon = 9110,
    unit = "个",
    descript = "内含40张超级藏宝图、30张特级藏宝图、1张十二生肖幸运券"
  },
  ["【中洲服】冲级初心礼盒"] = {
    icon = 1665,
    unit = "个",
    descript = "内含100银元宝、5包超级仙风散、8块超级晶石"
  },
  ["【中洲服】宠物进阶礼袋"] = {
    icon = 9268,
    unit = "个",
    descript = "内含12颗宠物强化丹、16颗宠物顿悟丹"
  },
  ["【中洲服】装备增强礼箱"] = {
    icon = 1578,
    unit = "个",
    descript = "内含8颗超级绿水晶、6颗超级圣水晶、3颗超级粉水晶、1张十二生肖幸运券"
  },
  ["【中洲服】宠物点化礼袋"] = {
    icon = 8001,
    unit = "个",
    descript = "内含100银元宝、5颗点化丹"
  },
  ["【中洲服】装备进阶礼箱"] = {
    icon = 1860,
    unit = "个",
    descript = "内含10块超级灵石、3颗超级绿水晶、12块超级晶石"
  },
  ["【中洲服】装备欢乐礼箱"] = {
    icon = 1863,
    unit = "个",
    descript = "内含40颗黄水晶、20块装备共鸣石、1张十二生肖幸运券"
  },
  ["【中洲服】宠物天书礼盒"] = {
    icon = 9109,
    unit = "个",
    descript = "内含100银元宝、5册天书"
  },
  ["【中洲服】装备提升礼箱"] = {
    icon = 2001,
    unit = "个",
    descript = "内含8颗黄水晶、2颗超级粉水晶"
  },
  ["【中洲服】骑宠超值礼盒"] = {
    icon = 8063,
    unit = "个",
    descript = "内含12颗风灵丸、15袋精怪诱饵、30颗宠物强化丹、1张十二生肖幸运券"
  },
  ["翠灵剑幸运券"] = {
    icon = 1872,
    unit = "张",
    use_level = 40,
    level_tip = "角色等级达到#R40级#n后方可使用。",
    rescourse = {
      "团购活动"
    },
    try_level_tip = "适用等级：大于等于%d级",
    descript = "使用后有几率获得五阶精怪大奖翠灵剑，否则随机获得怪物变身卡、中级血池、驯兽诀中的一种",
    double_type = 1
  },
  ["十二生肖幸运券"] = {
    icon = 1873,
    unit = "张",
    use_level = 65,
    level_tip = "角色等级达到#R65级#n后方可使用。",
    rescourse = {
      "团购活动"
    },
    try_level_tip = "适用等级：大于等于%d级",
    descript = "使用后有几率获得随机十二生肖大奖，否则随机获得十二生肖变身卡、天神护佑中的一种",
    double_type = 1
  },
  ["蓝色神格"] = {icon = 2176, unit = "个"},
  ["粉色神格"] = {icon = 2177, unit = "个"},
  ["金色神格"] = {icon = 2178, unit = "个"},
  ["【庚子国庆】活跃礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "2020年国庆节活动"
    },
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石"
  },
  ["【庚子国庆】登录礼包"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "2020年国庆节活动"
    },
    descript = "内含188银元宝、1颗点化丹、1颗宠物强化丹"
  },
  ["【庚子国庆】寻宝大礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2020年国庆节活动"
    },
    descript = "内含10张超级藏宝图"
  },
  ["【庚子国庆】宠物欢乐礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2020年国庆节活动"
    },
    descript = "内含2瓶超级归元露、3颗宠物强化丹、2颗宠物顿悟丹、2颗点化丹"
  },
  ["【庚子国庆】宠物进阶礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2020年国庆节活动"
    },
    descript = "内含6册天书、4颗羽化丹、3颗宠物顿悟丹"
  },
  ["【庚子国庆】豪华刷道礼包"] = {
    icon = 9108,
    unit = "个",
    rescourse = {
      "2020年国庆节活动"
    },
    descript = "内含18包超级仙风散、12包宠风散、8个急急如律令、4道紫气鸿蒙"
  },
  ["【庚子国庆】装备提升礼包"] = {
    icon = 9109,
    unit = "个",
    rescourse = {
      "2020年国庆节活动"
    },
    descript = "内含21块超级灵石、36块超级晶石、6块装备共鸣石"
  },
  ["【庚子国庆】装备高级礼包"] = {
    icon = 8063,
    unit = "个",
    rescourse = {
      "2020年国庆节活动"
    },
    descript = "内含3颗超级粉水晶、3颗超级绿水晶、18颗黄水晶、2颗超级圣水晶、15块装备共鸣石"
  },
  ["2020中秋月饼"] = {
    icon = 1622,
    rescourse = {
      "2020年中秋活动"
    },
    unit = "个",
    double_type = 1,
    descript = "一个普通的月饼，食用后可增长修为",
    fight_tip = "战斗中不可进行此操作。",
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后才能使用。"
  },
  ["2020中秋精致的月饼"] = {
    icon = 2184,
    rescourse = {
      "2020年中秋活动"
    },
    unit = "个",
    double_type = 1,
    descript = "精致的月饼，食用后可增长修为并获得道具“超级仙风散”",
    fight_tip = "战斗中不可进行此操作。",
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后才能使用。"
  },
  ["一阶妖魔令"] = {
    icon = 2179,
    rescourse = {
      "妖魔令活动"
    },
    unit = "枚",
    color = "蓝色",
    descript = "使用后可召唤妖魔怪物，战胜妖魔后可获得大量常规道行、武学奖励（不会获得月道行、月武学奖励），道具阶位越高获得的奖励越高"
  },
  ["二阶妖魔令"] = {
    icon = 2180,
    rescourse = {
      "妖魔令活动"
    },
    unit = "枚",
    color = "紫色",
    descript = "使用后可召唤妖魔怪物，战胜妖魔后可获得大量常规道行、武学奖励（不会获得月道行、月武学奖励），道具阶位越高获得的奖励越高"
  },
  ["三阶妖魔令"] = {
    icon = 2181,
    rescourse = {
      "妖魔令活动"
    },
    unit = "枚",
    color = "金色",
    descript = "使用后可召唤妖魔怪物，战胜妖魔后可获得大量常规道行、武学奖励（不会获得月道行、月武学奖励），道具阶位越高获得的奖励越高"
  },
  ["赏雪赠礼"] = {
    icon = 8063,
    descript = "团团和他的小伙伴们赠送的礼物，代表着祝福之意",
    rescourse = {
      "2020年瑞雪节活动"
    },
    unit = "份",
    double_type = 2
  },
  ["赏雪帽子"] = {
    icon = 1967,
    descript = "赏雪玩雪必备的帽子。集齐#R赏雪帽子、赏雪围巾、赏雪扫帚#n，可以前往降雪之地找团团和它的小伙伴换取#R赏雪赠礼#n",
    rescourse = {
      "2020年瑞雪节活动"
    },
    unit = "顶",
    double_type = 2
  },
  ["赏雪围巾"] = {
    icon = 2186,
    descript = "赏雪玩雪必备的围巾。集齐#R赏雪帽子、赏雪围巾、赏雪扫帚#n，可以前往降雪之地找团团和它的小伙伴换取#R赏雪赠礼#n",
    rescourse = {
      "2020年瑞雪节活动"
    },
    unit = "条",
    double_type = 2
  },
  ["赏雪扫帚"] = {
    icon = 2187,
    descript = "赏雪玩雪必备的扫帚。集齐#R赏雪帽子、赏雪围巾、赏雪扫帚#n，可以前往降雪之地找团团和它的小伙伴换取#R赏雪赠礼#n",
    rescourse = {
      "2020年瑞雪节活动"
    },
    unit = "把",
    double_type = 2
  },
  ["【口令好礼】鸿运礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["【口令好礼】仙风散礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["【口令好礼】变身卡礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["【口令好礼】福运礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["【口令好礼】好运礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["【口令好礼】幸运礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["【口令好礼】吉祥礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["【口令好礼】如意礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["【口令好礼】补给礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["口令好礼礼盒"] = {
    icon = 8009,
    descript = "多宝道人赠送的礼盒，打开后随机获得一份道具奖励。",
    rescourse = {
      "口令好礼活动"
    },
    unit = "个",
    double_type = 2
  },
  ["2021新年红包"] = {
    icon = 1939,
    descript = "恭祝各位道友新年大吉！打开红包后可随机获得1个商城道具或血池、灵池",
    rescourse = {
      "新服预约活动"
    },
    unit = "个",
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用此道具。",
    try_level_tip = "适用等级：大于等于%d级"
  },
  ["【笨笨牛】刷道加油礼包"] = {
    icon = 8001,
    rescourse = {
      "2021年礼包预售"
    },
    unit = "个",
    descript = "内含3个急急如律令"
  },
  ["【笨笨牛】升级加油礼包"] = {
    icon = 9268,
    rescourse = {
      "2021年礼包预售"
    },
    unit = "个",
    descript = "内含9包超级仙风散"
  },
  ["【笨笨牛】装备改造礼盒"] = {
    icon = 9107,
    rescourse = {
      "2021年礼包预售"
    },
    unit = "个",
    descript = "内含30块超级晶石、16块超级灵石"
  },
  ["【笨笨牛】宠物洗炼礼盒"] = {
    icon = 9108,
    rescourse = {
      "2021年礼包预售"
    },
    unit = "个",
    descript = "内含10瓶超级归元露、10颗羽化丹、6册天书"
  },
  ["【笨笨牛】装备炼化礼盒"] = {
    icon = 1578,
    rescourse = {
      "2021年礼包预售"
    },
    unit = "个",
    descript = "内含3颗超级粉水晶、6颗超级绿水晶、21颗黄水晶"
  },
  ["【笨笨牛】宠物进阶礼盒"] = {
    icon = 1665,
    rescourse = {
      "2021年礼包预售"
    },
    unit = "个",
    descript = "内含60颗宠物强化丹、12颗宠物顿悟丹、20颗点化丹"
  },
  ["幻鹿礼包"] = {
    icon = 9107,
    unit = "个",
    use_level = 60,
    descript = "内含1只幻鹿（御灵，限时3天）",
    try_level_tip = "适用等级：大于等于%d级",
    level_tip = "角色等级达到#R60级#n后方可使用本礼包。",
    rescourse = {"兑换码"}
  },
  ["【辛丑春节】新年礼包"] = {
    icon = 8009,
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["【辛丑春节】登录礼包"] = {
    icon = 8010,
    descript = "内含1块混沌玉、1颗点化丹",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["【辛丑春节】寻宝礼包"] = {
    icon = 8001,
    descript = "内含10张超级藏宝图",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["【辛丑春节】宠物提升礼包"] = {
    icon = 9107,
    descript = "内含14本灵海残卷、5颗宠物强化丹",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["【辛丑春节】豪华刷道礼包"] = {
    icon = 9107,
    descript = "内含16包超级仙风散、10包宠风散、8个急急如律令",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["【辛丑春节】宠物进阶礼包"] = {
    icon = 9108,
    descript = "内含16颗超级神兽丹、13颗羽化丹、10颗宠物顿悟丹",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["【辛丑春节】装备炼化礼包"] = {
    icon = 9109,
    descript = "内含3颗超级粉水晶、12颗黄水晶、4颗超级绿水晶",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["【辛丑春节】装备改造礼包"] = {
    icon = 8063,
    descript = "内含20块超级灵石、60块超级晶石、25块装备共鸣石、2颗超级圣水晶",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["萤石粉·围猎专用"] = {
    icon = 1829,
    unit = "包",
    descript = "太阳照射后可发出微光，夜里看起来很是明亮",
    effect_in_combat = "太阳照射后可发出微光，夜里看起来很是明亮"
  },
  ["咸鱼·围猎专用"] = {
    icon = 9241,
    unit = "条",
    descript = "盐腌渍后晒干的鱼，因保存不当而腐败变质，具有浓烈臭味，不论人或动物，皆避之不及",
    effect_in_combat = "盐腌渍后晒干的鱼，因保存不当而腐败变质，具有浓烈臭味，不论人或动物，皆避之不及"
  },
  ["火油·围猎专用"] = {
    icon = 9260,
    unit = "支",
    descript = "无色透明，极易点燃，只需零星一点，便可引发熊熊大火",
    effect_in_combat = "无色透明，极易点燃，只需零星一点，便可引发熊熊大火"
  },
  ["铁锤·围猎专用"] = {
    icon = 2044,
    unit = "把",
    descript = "锤身沉重，状如斗大，浑体漆黑，所击之物无不粉碎",
    effect_in_combat = "锤身沉重，状如斗大，浑体漆黑，所击之物无不粉碎"
  },
  ["兽夹·围猎专用"] = {
    icon = 1576,
    unit = "个",
    descript = "精钢所制，夹中猎物后其绝无逃脱的可能",
    effect_in_combat = "精钢所制，夹中猎物后其绝无逃脱的可能"
  },
  ["锣鼓·围猎专用"] = {
    icon = 9257,
    unit = "个",
    descript = "一种音响强烈、节奏鲜明的乐器，可发出巨大的声响，干扰对方的交流",
    effect_in_combat = "一种音响强烈、节奏鲜明的乐器，可发出巨大的声响，干扰对方的交流"
  },
  ["香囊·围猎专用"] = {
    icon = 1315,
    unit = "个",
    descript = "内装多种浓烈芳香气味的中草药研制的细末，有提神醒脑之奇效",
    effect_in_combat = "内装多种浓烈芳香气味的中草药研制的细末，有提神醒脑之奇效"
  },
  ["铜弩·围猎专用 "] = {
    icon = 9255,
    unit = "件",
    descript = "先人制作的带刻度以辅助瞄准的弩机，寻常之人凭此亦可百步穿杨",
    effect_in_combat = "先人制作的带刻度以辅助瞄准的弩机，寻常之人凭此亦可百步穿杨"
  },
  ["冰心珏·围猎专用"] = {
    icon = 1316,
    unit = "块",
    descript = "千年寒冰的冰芯所制，佩戴者无论身在何方，都会感到一丝凉意",
    effect_in_combat = "千年寒冰的冰芯所制，佩戴者无论身在何方，都会感到一丝凉意"
  },
  ["玄甲·围猎专用"] = {
    icon = 1228,
    unit = "件",
    descript = "以千年玄铁仿天地玄理铸就而成，质地厚重，防御极高",
    effect_in_combat = "以千年玄铁仿天地玄理铸就而成，质地厚重，防御极高"
  },
  ["斗篷·围猎专用"] = {
    icon = 9252,
    unit = "件",
    descript = "遮挡自身的举动，避免被一些聪慧的动物模仿",
    effect_in_combat = "遮挡自身的举动，避免被一些聪慧的动物模仿"
  },
  ["凤凰草·围猎专用"] = {
    icon = 7955,
    unit = "颗",
    descript = "花开季节全株散发出一种浓郁的芬芳气味，毒蛇闻之噤若寒蝉",
    effect_in_combat = "花开季节全株散发出一种浓郁的芬芳气味，毒蛇闻之噤若寒蝉"
  },
  ["围猎宝典"] = {
    icon = 9263,
    unit = "本",
    descript = "记载着历代猎人们总结下的狩猎经验的宝典",
    rescourse = {
      "2021年春节活动"
    }
  },
  ["送福牛"] = {
    icon = 2314,
    descript = "使用后可获得萌萌的送福牛跟随自身",
    rescourse = {
      "#@自定义换装|CustomDressDlg#@"
    },
    unit = "只",
    double_type = 2,
    color = "金色",
    custom_tips = "购买特殊时装赠送"
  },
  ["宴会宝箱"] = {double_type = 2},
  ["幻金石·至尊太极熊"] = {
    icon = 1920,
    descript = "一颗神奇的石头，听说里面蕴含传说中的御灵#R至尊太极熊#n的力量，可使#R9阶御灵#n（含8+1阶）转变为#R至尊太极熊#n，御灵属性会随之变化。点化、羽化、进化、强化等级等属性将保留",
    rescourse = {
      "名人争霸赛"
    },
    unit = "颗",
    double_type = 2,
    color = "金色"
  },
  ["争霸头像框"] = {
    icon = 2206,
    descript = "使用后可获得特殊的名人争霸头像框使用时间，特殊的荣誉标识将装饰你的聊天头像，让你聊天时尽显独特魅力",
    rescourse = {
      "名人争霸"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Icon3285.png",
    chat_icon_res_type = 1
  },
  ["争霸聊天底框"] = {
    icon = 2207,
    descript = "使用后可获得特殊的名人争霸聊天底框使用时间，特殊的荣誉标识将装饰你的聊天底框，让你聊天时尽显独特魅力",
    rescourse = {
      "名人争霸"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Background0325.png",
    chat_icon_res_type = 1,
    caprect = cc.rect(48, 46, 2, 2)
  },
  ["福气满满礼盒"] = {
    icon = 1665,
    descript = "春节期间，以夏为道友们带来了满满的祝福。打开礼盒可以随机获得超级女娲石、超级灵石、装备共鸣石、超级晶石、中级灵池中的一种",
    rescourse = {
      "问道陪你过大年活动"
    },
    unit = "个",
    double_type = 2
  },
  ["好运连连礼盒"] = {
    icon = 8009,
    descript = "春节期间，以夏为道友们带来了满满的祝福。打开礼盒可以随机获得天倾石、羽化丹、宠物顿悟丹、宠物强化丹、超级仙风散、中级血池中的一种",
    rescourse = {
      "问道陪你过大年活动"
    },
    unit = "个",
    double_type = 2
  },
  ["《隐身大盗》案卷宗"] = {
    icon = 2023,
    descript = "关于隐身大盗案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】隐身大盗"
  },
  ["药方"] = {
    icon = 1902,
    descript = " 一张普通的药方，记载着戏马留猴子的伤情和治疗药物",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    item_class = ITEM_CLASS.YSDD_KNOWLEDGE,
    double_type = 2
  },
  ["学识记载·鸟类"] = {
    icon = 1908,
    descript = "云游学者关于鸟类学识的记载",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    item_class = ITEM_CLASS.YSDD_KNOWLEDGE,
    double_type = 2
  },
  ["学识记载·地理"] = {
    icon = 1909,
    descript = " 云游学者关于地理学识的记载",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    item_class = ITEM_CLASS.YSDD_KNOWLEDGE,
    double_type = 2
  },
  ["学识记载·防盗"] = {
    icon = 1910,
    descript = " 云游学者关于防盗学识的记载",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    item_class = ITEM_CLASS.YSDD_KNOWLEDGE,
    double_type = 2
  },
  ["学识记载·天象"] = {
    icon = 1911,
    descript = " 云游学者关于天象学识的记载",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    item_class = ITEM_CLASS.YSDD_KNOWLEDGE,
    double_type = 2
  },
  ["学识记载·墓葬"] = {
    icon = 1912,
    descript = " 云游学者关于墓葬学识的记载",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    item_class = ITEM_CLASS.YSDD_KNOWLEDGE,
    double_type = 2
  },
  ["翎毛"] = {
    icon = 1901,
    unit = "根",
    double_type = 2,
    descript = "一根带血的飞禽翎毛，颜色红褐哑暗，有纤细横斑",
    rescourse = {
      "探案任务"
    }
  },
  ["鼠夹"] = {
    icon = 1576,
    unit = "根",
    double_type = 2,
    descript = "精钢所制，上面留有殷红的血迹",
    rescourse = {
      "探案任务"
    }
  },
  ["竹制鸟笼"] = {
    icon = 1903,
    unit = "根",
    double_type = 2,
    descript = "竹制圆顶鸟笼，虽材质普通，但做工精细，适用美观",
    rescourse = {
      "探案任务"
    }
  },
  ["红木鸟架"] = {
    icon = 1904,
    unit = "根",
    double_type = 2,
    descript = "采用上等红木精雕细琢而成，材质名贵，用于饲养大型或长尾鸟类",
    rescourse = {
      "探案任务"
    }
  },
  ["相思鸟"] = {
    icon = 1905,
    unit = "根",
    double_type = 2,
    descript = "此鸟羽衣华丽、动作活泼、姿态优美，颇受人们喜爱",
    rescourse = {
      "探案任务"
    }
  },
  ["沁色玉器"] = {
    icon = 1906,
    unit = "根",
    double_type = 2,
    descript = "表面上有大片的黄色沁花，一看就是从土里挖出的古玉",
    rescourse = {
      "探案任务"
    }
  },
  ["猫头鹰"] = {
    icon = 1907,
    unit = "只",
    double_type = 2,
    descript = "一只死掉的猫头鹰，周身红褐，羽干纹似树皮，尾巴上少了一根翎羽",
    rescourse = {
      "探案任务"
    }
  },
  ["《不翼而飞》案卷宗"] = {
    icon = 2023,
    descript = "关于不翼而飞案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】不翼而飞"
  },
  ["可疑的书信"] = {
    icon = 2124,
    unit = "封",
    descript = "从潜龙寨暗库的尸体身上搜到的书信，里边包括记录聂潜龙安排行动细节的信纸以及地图",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["扮鬼用的服装"] = {
    icon = 1875,
    unit = "套",
    descript = "一套红色的女装，穿起来好似女鬼一般，裙摆处有一些暗红色的血迹",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["青楼管事服装"] = {
    icon = 1876,
    unit = "套",
    descript = "一套青楼管事的服装，带有一丝特别的香气",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["碎瓦片"] = {
    icon = 1877,
    unit = "块",
    descript = "一块碎瓦片，边缘上有一些血迹",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["银票"] = {
    icon = 1878,
    unit = "张",
    descript = "一张价值三千两白银的银票，带有特殊香气",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["香囊"] = {
    icon = 1879,
    unit = "袋",
    descript = "一袋有特殊香气的香囊，香味虽淡，但幽然中带着点墨香，淡雅而别致",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["细绳"] = {
    icon = 1880,
    unit = "条",
    descript = "在歇马坡被劫马车后斗中找到的细绳，样式精美秀气，疑似梁家失踪的两位女子携带之物",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["阴阳符"] = {
    icon = 2086,
    unit = "张",
    descript = "茅山道士炼制的阴阳符，使用后可在梁府内变为阴身状态，可以看到鬼魂，或许还有其他用处",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["厨子的纸条"] = {
    icon = 7700,
    unit = "张",
    descript = "梁府厨子递给你的纸条，上面写着几个字，似乎在提醒谁有把柄在自己手中",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["蛇胆酒"] = {
    icon = 1624,
    unit = "壶",
    descript = "梁府厨子制作的蛇胆酒，据说有安魂定神的功效",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["草垛上的头发"] = {
    icon = 1881,
    unit = "根",
    descript = "在梁府草垛上找到的头发，看样子应该是女子的头发，闻起来有一股特别的香味",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["罗刹寨喽啰装"] = {
    icon = 1882,
    unit = "套",
    descript = "罗刹寨喽啰的统一服装",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["黑风寨喽啰装"] = {
    icon = 1883,
    unit = "套",
    descript = "黑风寨喽啰的统一服装",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["一捆随箱清单"] = {
    icon = 7701,
    unit = "捆",
    descript = "是梁府记录每箱内容的清单，摆放在潜龙寨暗库存放白银的每个箱子中，被捆在一起",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["聂潜龙的玉牌"] = {
    icon = 1884,
    unit = "块",
    descript = "聂潜龙随身佩戴的玉牌，背面刻着许多文字",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["梁飞燕的信物"] = {
    icon = 2154,
    unit = "根",
    descript = "一根精致的簪子，是梁飞燕常用之物，带有一股特别的香气",
    rescourse = {
      "探案任务"
    },
    double_type = 2
  },
  ["《青竹客栈》案卷宗"] = {
    icon = 2023,
    descript = "关于青竹镇人口失踪案件的探案卷宗，用于记录寻找到的各个线索及备注",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    double_type = 2,
    cmd = "CMD_DETECTIVE_TASK_CLUE",
    taskName = "【探案】青竹客栈"
  },
  ["客栈钥匙·探案任务"] = {
    icon = 1885,
    descript = "一串钥匙串，上边有很多钥匙",
    rescourse = {
      "探案任务"
    },
    unit = "串",
    taskName = "【探案】青竹客栈"
  },
  ["神秘镜子·探案任务"] = {
    icon = 1886,
    descript = "一个神秘镜子，上边有个类似“玉佩”图案",
    rescourse = {
      "探案任务"
    },
    unit = "个",
    taskName = "【探案】青竹客栈",
    cmd = "CMD_QZKZ_OPEN_DIALOG",
    cmd_para = 12
  },
  ["密件·探案任务"] = {
    icon = 7700,
    descript = "一张密件，上边的字都认识，但有什么用处呢",
    rescourse = {
      "探案任务"
    },
    unit = "张",
    taskName = "【探案】青竹客栈",
    cmd = "CMD_QZKZ_OPEN_DIALOG",
    cmd_para = 13
  },
  ["员外邻居的证词·探案任务"] = {
    icon = 2040,
    descript = "这份证词可以证明张员外有暴力倾向",
    rescourse = {
      "探案任务"
    },
    unit = "份",
    taskName = "【探案】青竹客栈",
    cmd = "CMD_QZKZ_OPEN_DIALOG",
    cmd_para = 14
  },
  ["信件·探案任务"] = {
    icon = 1942,
    descript = "破解青竹客栈机关后搜到的信件，似乎与陈巧玉有关",
    rescourse = {
      "探案任务"
    },
    unit = "封",
    taskName = "【探案】青竹客栈",
    cmd = "CMD_QZKZ_OPEN_DIALOG",
    cmd_para = 9
  },
  ["抄录的名册·探案任务"] = {
    icon = 1942,
    descript = "青竹客栈中抄录下来的名册，里面记录着客栈曾经工作过的人的部分信息",
    rescourse = {
      "探案任务"
    },
    unit = "本",
    taskName = "【探案】青竹客栈",
    cmd = "CMD_QZKZ_OPEN_DIALOG",
    cmd_para = 3
  },
  ["桂花酒·探案任务"] = {
    icon = 1891,
    descript = "一壶桂花酿造的酒，拿近了闻有一股浓浓的桂花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["兰花酒·探案任务"] = {
    icon = 1892,
    descript = "一壶兰花酿造的酒，拿近了闻有一股浓浓的兰花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["桃花酒·探案任务"] = {
    icon = 1893,
    descript = "一壶桃花酿造的酒，拿近了闻有一股浓浓的桃花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["梅花酒·探案任务"] = {
    icon = 1894,
    descript = "一壶梅花酿造的酒，拿近了闻有一股浓浓的梅花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["菊花酒·探案任务"] = {
    icon = 1895,
    descript = "一壶菊花酿造的酒，拿近了闻有一股浓浓的菊花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["杏花酒·探案任务"] = {
    icon = 1896,
    descript = "一壶杏花酿造的酒，拿近了闻有一股浓浓的杏花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["莲花酒·探案任务"] = {
    icon = 1897,
    descript = "一壶莲花酿造的酒，拿近了闻有一股浓浓的莲花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["茶花酒·探案任务"] = {
    icon = 1898,
    descript = "一壶茶花酿造的酒，拿近了闻有一股浓浓的茶花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["梨花酒·探案任务"] = {
    icon = 1899,
    descript = "一壶梨花酿造的酒，拿近了闻有一股浓浓的梨花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["葵花酒·探案任务"] = {
    icon = 1900,
    descript = "一壶葵花酿造的酒，拿近了闻有一股浓浓的葵花香",
    rescourse = {
      "探案任务"
    },
    unit = "壶",
    taskName = "【探案】青竹客栈"
  },
  ["工作牌-李·探案任务"] = {
    icon = 1887,
    descript = "一块普普通通的牌子，上边写着“李”",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    taskName = "【探案】青竹客栈"
  },
  ["工作牌-白·探案任务"] = {
    icon = 1888,
    descript = "一块普普通通的牌子，上边写着“白”",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    taskName = "【探案】青竹客栈"
  },
  ["工作牌-郭·探案任务"] = {
    icon = 1889,
    descript = "一块普普通通的牌子，上边写着“郭”",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    taskName = "【探案】青竹客栈"
  },
  ["工作牌-吕·探案任务"] = {
    icon = 1890,
    descript = "一块普普通通的牌子，上边写着“吕”",
    rescourse = {
      "探案任务"
    },
    unit = "块",
    taskName = "【探案】青竹客栈"
  },
  ["青团·清明节专属"] = {
    icon = 9264,
    descript = "清明节才会制作的美食，食用后可获得经验道行奖励",
    rescourse = {
      "2021年清明节活动"
    },
    unit = "粒",
    double_type = 0
  },
  ["装满水的桶"] = {
    icon = 9245,
    descript = "清明节活动#R禁火寒食#n任务道具，用于对付天墉城中的火妖",
    rescourse = {
      "2021年清明节活动"
    },
    unit = "桶",
    double_type = 2
  },
  ["【五周年庆】生肖召唤令幸运礼盒"] = {
    icon = 8009,
    descript = "使用后，有机会获得召唤令·十二生肖*1、点化丹*2、超级归元露*4、宠风散*2、超级仙风散*5中的其中一种，上述奖励均不限制交易。",
    rescourse = {
      "2021年幸运好礼"
    },
    unit = "个",
    color = "金色",
    double_type = 2
  },
  ["【五周年庆】神兽召唤令幸运礼盒"] = {
    icon = 8010,
    descript = "使用后，有机会获得召唤令·上古神兽*1、超级女娲石*1、羽化丹*2、宠物顿悟丹*3、宠物强化丹*4中的其中一种，上述奖励均不限制交易。",
    rescourse = {
      "2021年幸运好礼"
    },
    unit = "个",
    color = "金色",
    double_type = 2
  },
  ["【五周年庆】随机变异幸运礼箱"] = {
    icon = 9152,
    descript = "使用后，有机会获得十二生肖变异宠*1、超级粉水晶*1、超级绿水晶*2、超级灵石*5、急急如律令*5中的其中一种，上述奖励均不限制交易。",
    rescourse = {
      "2021年幸运好礼"
    },
    unit = "个",
    color = "金色",
    double_type = 2,
    limitTimeFormat = ""
  },
  ["梦荷·震位"] = {
    icon = 1451,
    descript = "飞行法宝梦荷的部件之一，集齐梦荷·震位、梦荷·离位和梦荷·兑位三个部件后启灵得到梦荷",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=飞行法宝:梦荷部件:梦荷·震位#@",
      "通天塔",
      "大日金乌"
    },
    unit = "个",
    double_type = 1
  },
  ["梦荷·离位"] = {
    icon = 1452,
    descript = "飞行法宝梦荷的部件之一，集齐梦荷·震位、梦荷·离位和梦荷·兑位三个部件后启灵得到梦荷",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=飞行法宝:梦荷部件:梦荷·离位#@",
      "铲除妖王",
      "地宫"
    },
    unit = "个",
    double_type = 1
  },
  ["梦荷·兑位"] = {
    icon = 1453,
    descript = "飞行法宝梦荷的部件之一，集齐梦荷·震位、梦荷·离位和梦荷·兑位三个部件后启灵得到梦荷",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=飞行法宝:梦荷部件:梦荷·兑位#@",
      "地狱深渊",
      "八仙梦境"
    },
    unit = "个",
    double_type = 1
  },
  ["梦荷"] = {
    icon = 1454,
    descript = "天地初开时，鸿蒙中一灵荷，为老祖梦中偶得之至宝。可装备至飞行法宝栏，装备后可腾云驾雾飞行",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=飞行法宝:梦荷#@"
    },
    unit = "个",
    double_type = 2,
    extra = {
      fly_char_type = FLY_CHAR_TYPE.SINGLE,
      icon = 1725,
      scale = 0.75,
      normal_scale = 1.1
    },
    materials = {
      "梦荷·震位",
      "梦荷·离位",
      "梦荷·兑位"
    },
    use_level = 75
  },
  ["御天梭"] = {
    icon = 1455,
    descript = "启灵时将梦荷融入此法宝内，装备后可腾云驾雾飞行，并且可以提升1级坐骑移动速度",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=飞行法宝:御天梭#@"
    },
    unit = "个",
    double_type = 2,
    extra = {
      fly_char_type = FLY_CHAR_TYPE.SINGLE,
      icon = 1726,
      scale = 0.75,
      add_speed = 1
    },
    materials = {
      "梦荷·震位",
      "梦荷·离位",
      "梦荷·兑位"
    },
    cost = 300,
    use_level = 75
  },
  ["墨舞青云"] = {
    icon = 1458,
    descript = "将此物与#R未启用的御天梭#n启灵，并骑乘原始阶位#R6阶#n及以上御灵后可使用，装备后可腾云驾雾飞行，并且可以提升2级坐骑移动速度",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=飞行法宝:墨舞青云:@@#@",
      "#@在线商城|OnlineMallDlg=墨舞青云·30天#@"
    },
    unit = "个",
    double_type = 2,
    extra = {
      fly_char_type = FLY_CHAR_TYPE.MULTI,
      icon = 32051,
      add_speed = 2,
      raw_capacity = 6
    },
    materials = {
      "墨舞轻云",
      "御天梭"
    },
    use_level = 75
  },
  ["裂海龙鲸"] = {
    icon = 1457,
    descript = "将此物与#R未启用的御天梭#n启灵，并骑乘原始阶位#R8阶#n及以上御灵后可使用，装备后可腾云驾雾飞行，并且可以提升2级坐骑移动速度",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=飞行法宝:裂海龙鲸:@@#@",
      "#@在线商城|OnlineMallDlg=裂海龙鲸·30天#@"
    },
    unit = "个",
    double_type = 2,
    extra = {
      fly_char_type = FLY_CHAR_TYPE.MULTI,
      icon = 32050,
      add_speed = 2,
      raw_capacity = 8
    },
    materials = {
      "裂海龙鲸",
      "御天梭"
    },
    use_level = 75
  },
  ["魔炎飞甲"] = {
    icon = 1456,
    descript = "将此物与#R未启用的御天梭#n启灵，并骑乘原始阶位#R5阶#n及以上御灵后可使用，装备后可腾云驾雾飞行，并且可以提升1级坐骑移动速度",
    rescourse = {
      "#@集市逛摊|MarketBuyDlg=飞行法宝:魔炎飞甲:@@#@",
      "【月】魔龙吞天",
      "魔龙之祸"
    },
    unit = "个",
    double_type = 2,
    extra = {
      fly_char_type = FLY_CHAR_TYPE.MULTI,
      icon = 32052,
      add_speed = 1,
      raw_capacity = 5
    },
    materials = {
      "魔炎飞甲",
      "御天梭"
    },
    use_level = 75
  },
  ["元神碎片·寒霄"] = {
    icon = 2189,
    unit = "片",
    descript = "2021年周年庆纪念宠寒霄的元神碎片，集齐100个并使用后可召唤寒霄",
    double_type = 0,
    rescourse = {
      "2021年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·寒霄#@"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["元神碎片·武极"] = {
    icon = 2188,
    unit = "片",
    descript = "2021年周年庆纪念宠武极的元神碎片，集齐100个并使用后可召唤武极",
    double_type = 0,
    rescourse = {
      "2021年周年庆活动",
      "#@集市逛摊|MarketBuyDlg=宠物道具:纪念宠元神:元神碎片·武极#@"
    },
    use_level = 30,
    level_tip = "角色等级达到#R30级#n后方可使用本道具。",
    try_level_tip = "适用等级：角色大于等于%d级",
    color = "金色"
  },
  ["【五周年庆】活跃礼包"] = {
    icon = 8009,
    unit = "个",
    rescourse = {
      "2021年周年庆活动"
    },
    descript = "内含1包宠风散、1包超级仙风散、1块超级晶石",
    double_type = 2
  },
  ["【五周年庆】登录礼包"] = {
    icon = 8010,
    unit = "个",
    rescourse = {
      "2021年周年庆活动"
    },
    descript = "内含188银元宝、1颗点化丹、1颗宠物强化丹",
    double_type = 2
  },
  ["【五周年庆】寻宝大礼包"] = {
    icon = 8001,
    unit = "个",
    rescourse = {
      "2021年周年庆活动"
    },
    descript = "内含1张特级藏宝图、3张超级藏宝图",
    double_type = 2
  },
  ["【五周年庆】宠物欢乐礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2021年周年庆活动"
    },
    descript = "内含7本灵海残卷、2颗宠物强化丹、2颗宠物顿悟丹、2颗点化丹",
    double_type = 2
  },
  ["【五周年庆】宠物进阶礼包"] = {
    icon = 9107,
    unit = "个",
    rescourse = {
      "2021年周年庆活动"
    },
    descript = "内含5册天书、3颗羽化丹、4颗宠物顿悟丹、5颗超级神兽丹",
    double_type = 2
  },
  ["【五周年庆】豪华刷道礼包"] = {
    icon = 9108,
    unit = "个",
    rescourse = {
      "2021年周年庆活动"
    },
    descript = "内含13包超级仙风散、13包宠风散、8个急急如律令、5道紫气鸿蒙",
    double_type = 2
  },
  ["【五周年庆】装备提升礼包"] = {
    icon = 9109,
    unit = "个",
    rescourse = {
      "2021年周年庆活动"
    },
    descript = "内含24块超级灵石、24块超级晶石、6块装备共鸣石",
    double_type = 2
  },
  ["【五周年庆】装备高级礼包"] = {
    icon = 8063,
    unit = "个",
    rescourse = {
      "2021年周年庆活动"
    },
    descript = "内含3颗超级粉水晶、3颗超级绿水晶、18颗黄水晶、5颗超级圣水晶、5块装备共鸣石",
    double_type = 2
  },
  ["梦荷宝箱"] = {
    icon = 9153,
    unit = "个",
    use_level = 1,
    descript = "打开后可随机获得1或3个梦荷部件的神奇宝箱",
    rescourse = {
      "#@在线商城|OnlineMallDlg=梦荷宝箱#@"
    },
    color = "金色",
    double_type = 1
  },
  ["林更新的发带"] = {
    icon = 9111,
    unit = "条",
    descript = "一条淡蓝色的发带，上方写着“九亿少女的梦”，看来是林更新遗失的发带无误了",
    rescourse = {
      "林更新信物活动"
    },
    double_type = 2
  },
  ["林更新的香囊"] = {
    icon = 9112,
    unit = "个",
    descript = "一个背面绣着“新”字的香囊，香味十分特殊，与林更新身上的香味完全一样",
    rescourse = {
      "林更新信物活动"
    },
    double_type = 2
  },
  ["林更新的佩剑"] = {
    icon = 9113,
    unit = "把",
    descript = "一把精致的小佩剑，上方还有林更新的名字，毫无磨损程度，看来不是其主要使用的武器",
    rescourse = {
      "林更新信物活动"
    },
    double_type = 2
  },
  ["林更新的自画像"] = {
    icon = 9114,
    unit = "幅",
    descript = "一幅林更新的自画像，想必其一定是对自己的外貌非常自信，才会随身携带自画像",
    rescourse = {
      "林更新信物活动"
    },
    double_type = 2
  },
  ["林更新的亲笔信"] = {
    icon = 9115,
    unit = "封",
    descript = "一封由林更新亲笔写下的书信，收信人是广大道友，看来是他来到中洲大陆后写下的书信",
    rescourse = {
      "林更新信物活动"
    },
    double_type = 2
  },
  ["林更新的宝玉"] = {
    icon = 9116,
    unit = "块",
    descript = "一块玉体通透的玉佩，上方还有林更新亲手刻下的字，这也是所有信物中看起来最珍贵的",
    rescourse = {
      "林更新信物活动"
    },
    double_type = 2
  },
  ["夏荷鲤"] = {
    icon = 9506,
    unit = "套",
    gender = 1,
    descript = "XXXXXXXXX",
    double_type = 2,
    rescourse = {
      "新服活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "夏荷锦",
    color = "金色"
  },
  ["夏荷锦"] = {
    icon = 9507,
    unit = "套",
    gender = 2,
    descript = "XXXXXXXXX",
    double_type = 2,
    rescourse = {
      "新服活动"
    },
    item_class = ITEM_CLASS.FASHION,
    relation_fashion = "夏荷鲤",
    color = "金色"
  },
  ["五周年专属礼包"] = {
    icon = 9110,
    unit = "个",
    rescourse = {
      "五周年运营活动"
    },
    descript = "问道手游五周年专属礼包，内含五周年专属头像框、聊天框以及专属称谓"
  },
  ["五周年头像框"] = {
    icon = 2208,
    descript = "使用后可获得特殊的五周年头像框使用时间，特殊的周年标识将装饰你的聊天头像，让你聊天时尽显独特魅力",
    rescourse = {
      "五周年专属礼包"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Icon3300.png",
    chat_icon_res_type = 1
  },
  ["五周年聊天底框"] = {
    icon = 2099,
    descript = "使用后可获得特殊的五周年聊天底框使用时间，特殊的周年标识将装饰你的聊天底框，让你聊天时尽显独特魅力",
    rescourse = {
      "五周年专属礼包"
    },
    unit = "个",
    double_type = 2,
    color = "金色",
    chat_icon = "FriendChannelDlg/Background0320.png",
    chat_icon_res_type = 1
  }
}
