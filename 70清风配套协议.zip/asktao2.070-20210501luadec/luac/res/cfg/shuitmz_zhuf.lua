return {
  {floor_index = 1},
  {wall_index = 2},
  {
    stmzMapSprite = 10018,
    x = 949,
    y = 725
  }
}
