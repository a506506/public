return {
  stand = {
    zip = 1,
    keyframe = 9,
    rate = 120,
    centre_x = 161,
    centre_y = 153,
    waist_x = 158,
    waist_y = 154,
    waist_x_0 = 158,
    waist_y_0 = 109,
    head_x = 160,
    head_y = 154,
    head_x_0 = 155,
    head_y_0 = 56,
    centre_x_0 = 158,
    centre_y_0 = 154,
    head_x_1 = 155,
    head_y_1 = 56,
    waist_x_1 = 158,
    waist_y_1 = 109,
    centre_x_1 = 158,
    centre_y_1 = 154
  }
}
